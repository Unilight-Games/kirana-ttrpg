#!/usr/bin/env python3
"""v1.25 (Non เคาะ 15 พ.ย. 2026): โทษยิงเกินระยะแม่นเปลี่ยนเป็น -1 CV ต่อทุก 1 เมตรที่เกิน (เดิม -1 CV ต่อ 10 เมตร นับทุก 10 เมตรที่เริ่มนับ)

แก้ข้อความใน tools/data.json ให้ตรงกับไฟล์กฎ Talent & Knowledge Proficiency.md (ทักษะ ต่อสู้ระยะไกล ระดับ 0 ถึง 3)
และคำอธิบายศัพท์ เขตไกล (Far Zone) ใน data.json กับ tools/glossary.json
รันซ้ำได้: ข้อความที่แก้แล้วจะถูกข้าม
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')
GLOSS = os.path.join(HERE, 'glossary.json')
OLD_LV = '-1 CV ต่อระยะ 10 เมตร นับทุก 10 เมตรที่เริ่มนับ'
NEW_LV = '-1 CV ต่อทุก 1 เมตรที่เกิน'
OLD_FAR = 'ลด CV ตามระยะ นับทุก 10 เมตรที่เริ่มนับ'
NEW_FAR = 'ลด 1 CV ต่อทุก 1 เมตรที่เกินระยะแม่น'


def main():
    D = json.load(open(DATA, encoding='utf-8'))
    n = 0
    k = next(x for x in D['knowledge'] if x['id'] == 'range')
    for lv, v in k['levels'].items():
        t = v.get('text') or ''
        if OLD_LV in t:
            v['text'] = t.replace(OLD_LV, NEW_LV); n += 1
        assert OLD_LV not in v['text'] and NEW_LV in v['text'], ('range level', lv, v['text'][:80])
    far = D['glossary'].get('Far Zone')
    if far and OLD_FAR in far.get('text', ''):
        far['text'] = far['text'].replace(OLD_FAR, NEW_FAR); n += 1
    assert NEW_FAR in D['glossary']['Far Zone']['text']
    blob = json.dumps(D, ensure_ascii=False)
    assert '10 เมตรที่เริ่มนับ' not in blob, 'old range rule left in data.json'
    json.dump(D, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    G = json.load(open(GLOSS, encoding='utf-8'))
    if OLD_FAR in G.get('Far Zone', {}).get('text', ''):
        G['Far Zone']['text'] = G['Far Zone']['text'].replace(OLD_FAR, NEW_FAR); n += 1
        json.dump(G, open(GLOSS, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('splice_v125: changed', n)


if __name__ == '__main__':
    main()
