#!/usr/bin/env python3
"""v1.25.2 (Non เคาะ 15 พ.ย. 2026): นิยามเกราะหลักกับเกราะรอง
"เกราะรองคือชนิดในวงเล็บ" และ "ถ้าโดนความเสียหายชนิดที่อยู่ในวงเล็บ หักทั้งเกราะหลักและเกราะรอง ถ้าเป็นชนิดอื่น หักเกราะหลักอย่างเดียว"

ต่อท้ายคำอธิบายศัพท์ เกราะ (Armor) ด้วยประโยคเดียวกับที่เพิ่มในไฟล์แกน Kirana Core System TTRPG (V.2).md
ใน tools/data.json กับ tools/glossary.json · ใช้กับไฟล์แกนด้วย: python3 tools/splice_v1252.py --rules <ไฟล์แกน>
รันซ้ำได้: ข้อความที่ต่อแล้วจะถูกข้าม
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')
GLOSS = os.path.join(HERE, 'glossary.json')
TAIL = 'Armor ก็จะมีผลอยู่กับเพียงแขนข้างซ้าย'
ADD = ('ค่าเกราะของเครื่องสวมใส่เขียนในรูป Armor A/B (ชนิด) โดย A คือเกราะหลัก (Main Armor) และ B คือเกราะรองของชนิดความเสียหายในวงเล็บ '
       'เมื่อโดนความเสียหายชนิดที่อยู่ในวงเล็บให้หักทั้งเกราะหลักและเกราะรอง หากเป็นความเสียหายชนิดอื่นให้หักเกราะหลักเพียงอย่างเดียว '
       'เช่น เกราะโซ่ถัก Armor 2/2 (Slashing) หักความเสียหาย 4 หน่วยเมื่อโดน Slashing Damage และหัก 2 หน่วยเมื่อโดนความเสียหายชนิดอื่น')


def add_to(text):
    if ADD in text:
        return text, False
    assert text.rstrip().endswith(TAIL), ('Armor text tail changed', text[-80:])
    return text.rstrip() + ' ' + ADD, True


def rules(path):
    lines = open(path, encoding='utf-8').read().split('\n')
    hit = [i for i, l in enumerate(lines) if l.startswith('**เกราะ (Armor)**')]
    assert len(hit) == 1, ('Armor paragraph', len(hit))
    lines[hit[0]], ch = add_to(lines[hit[0]])
    open(path, 'w', encoding='utf-8').write('\n'.join(lines))
    print('splice_v1252 rules: changed', int(ch), 'line', hit[0] + 1)


def main():
    D = json.load(open(DATA, encoding='utf-8'))
    D['glossary']['Armor']['text'], c1 = add_to(D['glossary']['Armor']['text'])
    json.dump(D, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    G = json.load(open(GLOSS, encoding='utf-8'))
    G['Armor']['text'], c2 = add_to(G['Armor']['text'])
    json.dump(G, open(GLOSS, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('splice_v1252: changed', int(c1) + int(c2))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--rules':
        rules(sys.argv[2])
    else:
        main()
