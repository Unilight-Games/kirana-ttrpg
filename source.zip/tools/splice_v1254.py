#!/usr/bin/env python3
"""v1.25.4 (Non เคาะ 15 พ.ย. 2026)
1. เวทที่ไม่มีตำแหน่งที่โดน (Saving Throw หรือเวทพื้นที่) หักด้วยเกราะลำตัว ("เอาตามนั้น")
2. กฎเกราะมาก่อน (เกราะหักจนเหลือ 0 ส่วนนั้นไม่เสีย Toughness) นับความเสียหายเวทด้วย ("นับรวมด้วยเลยก็ดีครับ")
3. "เวทหลายอันเน้นสร้างความเสียหายจาก Stack ซึ่งไม่คิดค่าเกราะ"

แก้คำอธิบายศัพท์ เกราะ (Armor) และ Toughness ใน tools/data.json กับ tools/glossary.json
และแก้ไฟล์แกน Kirana Core System TTRPG (V.2).md ด้วย: python3 tools/splice_v1254.py --rules <ไฟล์แกน>
ต้องรันหลัง splice_v1253.py · รันซ้ำได้: ข้อความที่แก้แล้วจะถูกข้าม
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')
GLOSS = os.path.join(HERE, 'glossary.json')
ARMOR_TAIL = 'หักความเสียหายเวท 5 หน่วย และหักความเสียหายกายภาพ 1 หน่วย เฉพาะส่วนที่สวม'
ARMOR_ADD = ('ความเสียหายเวทที่ไม่มีตำแหน่งที่โดน เช่น เวทที่ให้ทอย Saving Throw หรือเวทที่กินพื้นที่ ให้หักด้วยเกราะของลำตัว '
             'ส่วนความเสียหายที่เกิดจาก Stack ไม่หักเกราะ')
TOUGH_OLD = 'เกราะที่หักความเสียหายกายภาพจนเหลือ 0 ทำให้ส่วนนั้นไม่เสีย Toughness'
TOUGH_NEW = 'เกราะที่หักความเสียหายกายภาพหรือความเสียหายเวทจนเหลือ 0 ทำให้ส่วนนั้นไม่เสีย Toughness'
RULE_OLD = 'เว้นแต่ค่าเกราะของส่วนนั้นหักความเสียหายกายภาพของการโจมตีครั้งนั้นจนเหลือ 0'
RULE_NEW = 'เว้นแต่ค่าเกราะของส่วนนั้นหักความเสียหายกายภาพหรือความเสียหายเวทของการโจมตีครั้งนั้นจนเหลือ 0'


def add_to(text, tail, add):
    if add in text:
        return text, 0
    assert text.rstrip().endswith(tail), ('text tail changed', text[-80:])
    return text.rstrip() + ' ' + add, 1


def swap(text, old, new):
    if new in text:
        return text, 0
    assert text.count(old) == 1, ('old text', text.count(old))
    return text.replace(old, new), 1


def rules(path):
    lines = open(path, encoding='utf-8').read().split('\n')
    n = 0
    hit = [i for i, l in enumerate(lines) if l.startswith('**เกราะ (Armor)**')]
    assert len(hit) == 1
    lines[hit[0]], c = add_to(lines[hit[0]], ARMOR_TAIL, ARMOR_ADD); n += c
    hit = [i for i, l in enumerate(lines) if RULE_OLD in l or RULE_NEW in l]
    assert len(hit) == 1, ('armor-first rule line', len(hit))
    lines[hit[0]], c = swap(lines[hit[0]], RULE_OLD, RULE_NEW); n += c
    open(path, 'w', encoding='utf-8').write('\n'.join(lines))
    print('splice_v1254 rules: changed', n)


def main():
    D = json.load(open(DATA, encoding='utf-8'))
    G = json.load(open(GLOSS, encoding='utf-8'))
    n = 0
    for store in (D['glossary'], G):
        store['Armor']['text'], c = add_to(store['Armor']['text'], ARMOR_TAIL, ARMOR_ADD); n += c
        store['Toughness']['text'], c = swap(store['Toughness']['text'], TOUGH_OLD, TOUGH_NEW); n += c
    json.dump(D, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    json.dump(G, open(GLOSS, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('splice_v1254: changed', n)


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--rules':
        rules(sys.argv[2])
    else:
        main()
