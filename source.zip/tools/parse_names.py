# -*- coding: utf-8 -*-
"""v1.23 อ่านคลังคำจาก ภาษาแห่งคีรันนา.md ตามช่วงหัวข้อใน names_ways.py แล้วเขียน names.json ให้ระบบตั้งชื่อในเว็บ
ใช้: KIRANA_LANG_SRC=<path ภาษาแห่งคีรันนา.md> KIRANA_OUT=<โฟลเดอร์ผล> python3 tools/parse_names.py
ผล: names.json (ภาษา วิถี รายการหน่วยคำ คลังคำ) และ names_report.txt (บรรทัดที่อ่านไม่ออก คำที่ตัดออก สถิติ)

คำแต่ละคำเก็บเป็นแถว [รูปคำ, คำอ่าน, [ความหมาย...], ชนิดคำต่อความหมาย, เลขหมวด, ธง]
  ชนิดคำ: n นาม · v กริยา · a คุณศัพท์ · g คำที่เป็นบุคคลอยู่แล้ว (ผู้...) · ความหมายในหมวดที่ปนกันเดาจากคำกริยาและคุณศัพท์ในหมวดที่ระบุชนิดไว้
  ธง: 1 = รากศัพท์ที่ไฟล์เขียนมีขีดท้าย (aen-) · 2 = ชื่อคนในตัวอย่าง"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import names_ways as NW  # noqa: E402

SRC = os.environ.get("KIRANA_LANG_SRC")
OUT = os.environ.get("KIRANA_OUT", ".")
MAX_SENSE = 30  # ความหมายที่ยาวกว่านี้คือคำอธิบาย ไม่ใช่คำแปล
MAX_SHORTENED = 42  # คำที่มีความหมายเดียวและยาว ตัดเหลือวลีแรกได้ไม่เกินนี้
# คำหยาบหรือคำเพศที่ไม่ควรออกมาในเครื่องสุ่มชื่อ ตัดทั้งคำและแจ้งในรายงาน
CRUDE = re.compile(r"อวัยวะเพศ|ร่วมเพศ|สังวาส|อุจจาระ|ปัสสาวะ|คำด่า|คำหยาบ|คำสบถ|โสเภณี|กะหรี่")  # ระบุทั้งคำ เพราะภาษาไทยไม่เว้นคำ (ขี้ อยู่ใน เขี้ยว)

LATIN = re.compile(r"^[A-Za-zÀ-ɏḀ-ỿ'’]+(?:[ -][A-Za-zÀ-ɏḀ-ỿ'’]+)?-?$")
# คำกริยาไทยที่ใช้บ่อยในคำแปล: ความหมายที่ขึ้นต้นด้วยคำเหล่านี้นับเป็นกริยา (ความหมายของชื่อจึงเติม "การ" ให้ตอนต่อด้วย "แห่ง")
VERB_HEADS = tuple("""ร้อง เดิน มอง เห็น พูด ฟัง ได้ยิน รู้ เข้าใจ คิด ลืม ล่า ต่อสู้ สู้ ฆ่า สังหาร ทำลาย ทำให้ ทำสัญญา สร้าง ขุด สลัก เจาะ ทุบ แทง ยิง ขว้าง
บิน ว่าย ดำน้ำ ดำดิ่ง ดำรง ดำเนิน วิ่ง กระโดด ปีน ซ่อน หลบ ปกป้อง พิทักษ์ ปกครอง นำ ตาม ค้น แสวงหา เคลื่อน ไหล เติบโต เกิด ตาย หลับ ตื่น ฝัน หัวเราะ ยิ้ม
รัก เกลียด กลัว หวัง เชื่อ ภาวนา อธิษฐาน สวด ถักทอ เย็บ หลอม เผา ส่อง เปล่ง กระซิบ ตะโกน เรียก บอก ถาม ตอบ สอน เรียน อ่าน เขียน จารึก สาบาน ให้ รับ มอบ
ถวาย ปล่อย ปลด จับ ถือ ยก แบก ดึง ผลัก ผูก มัด ตัด หัก แตก ทะลวง ทะลุ ข้าม ก้าว ยืน นั่ง นอน พัก รอคอย เฝ้า ดูแล รักษา เยียวยา ชำระ ล้าง ดื่ม กิน เคี้ยว
กลืน หายใจ เต้น ขับ บรรเลง เล่น ล่องลอย ลอย จมดิ่ง จมลง ร่วง ตก เปิด ปิด ซื้อ ขาย แลก ขโมย ลอบ ท้า แพ้ ชนะ หยั่ง เจริญ ผลิ เบ่งบาน เหี่ยว จาง เลือน ดับ
ลุก ไหม้ แผด คำราม ขู่ ข่ม บัญชา สั่ง ชี้ ส่ง เลี้ยง เพาะ ปลูก เก็บ ฝัง สำรวจ สังเกต จ้อง เพ่ง ชำเลือง สดับ เงี่ยหู อดทน ยืนหยัด ต้านทาน ป้องกัน ตั้งรับ
โจมตี จู่โจม บุก ถอย กลาย ช่วย หยุด เริ่ม แบ่ง รวม ดูด สัมผัส กอด ร่วม เชื่อม แก้ไข ซ่อม เปลี่ยน แปร ฟื้น กลับ หมุน บด วาด ปั้น แกะ ซัด พัด โบก สะท้อน
ฉาย เรือง รอด""".split())
VERB_EXACT = {"มา", "ไป", "ทำ", "ดู", "อยู่", "จำ", "รอ", "ขอ", "หนี", "จม", "ตี"}
NOUN_PREFIX = ("ของ", "ขอบ", "จมูก", "จำนวน", "จำเป็น", "มาก", "มานา", "มายา", "รอย", "หนี้", "แก้ว", "แผ่นดิน", "แผ่นหลัง", "รักษ์")


def looks_verb(x):
    if x in VERB_EXACT:
        return True
    return not x.startswith(NOUN_PREFIX) and x.startswith(VERB_HEADS)


POS_TAG = {"คำนาม": "n", "คำกริยา": "v", "คำคุณศัพท์": "a", "คำคุณศัพท์/ผู้กระทำ": "g"}


def unesc(s):
    return re.sub(r"\\(.)", r"\1", s)


def key(line):
    """รูปบรรทัดสำหรับเทียบหัวข้อ: ตัด escape ตัวหนา และเครื่องหมายหัวข้อย่อยนำหน้า"""
    s = unesc(line).replace("**", "").strip()
    return re.sub(r"^\*\s+", "", s)


def balanced(s, i):
    d = 0
    for j in range(i, len(s)):
        if s[j] == "(":
            d += 1
        elif s[j] == ")":
            d -= 1
            if d == 0:
                return j + 1
    return -1


def strip_parens(t):
    prev = None
    while prev != t:
        prev = t
        t = re.sub(r"\([^()]*\)", "", t)
    return t


def clean_reading(r):
    r = strip_parens(r)
    r = re.split(r"[,/]|\sหรือ\s", r)[0]
    r = r.replace("-", "").replace("*", "").strip()
    return r if re.search(r"[฀-๿]", r) else ""


def senses_of(t):
    tag = None
    for k, v in POS_TAG.items():
        if "(" + k + ")" in t:
            tag = v
    t = t.replace("*", "")
    t = re.split(r"\s*[—–]\s*", t)[0]
    t = strip_parens(t)
    t = re.sub(r"[\"“”]", "", t).strip()
    t = re.sub(r"^ความหมาย\s*:\s*", "", t)
    out = []
    for p in re.split(r"[,;]|\.\s|\sหรือ\s|\s/\s", t):
        p = re.sub(r"\s+", " ", p).strip().strip(".").strip()
        if p and p not in out:
            out.append(p)
    return out, tag


def short(x):
    """ความหมายเดียวที่ยาวเป็นคำอธิบาย: ตัดเหลือวลีแรก (ก่อนช่องว่าง หรือก่อน 'หรือ')"""
    for cand in (x.split(" ")[0], re.split(r"หรือ", x)[0], re.split(r"หรือ", x.split(" ")[0])[0]):
        cand = cand.strip()
        if 2 <= len(cand) <= MAX_SHORTENED:
            return cand
    return ""


def parse_entry(e):
    """e = ข้อความหลังเครื่องหมายหัวข้อย่อย (unescaped) · คืน (รูปคำ[], คำอ่าน, ความหมาย[], ชนิดจากป้าย, เพศ) หรือ None"""
    e = e.strip()
    if e.startswith("**"):
        j = e.find("**", 2)
        if j < 0:
            return None
        head, tail = e[2:j].strip(), e[j + 2:]
    else:
        m = re.match(r"^([^\s(:]+)", e)
        if not m:
            return None
        head, tail = m.group(1), e[m.end():]
    if head.endswith(":"):
        head = head[:-1].strip()
    reading = ""
    k = head.find("(")
    if k >= 0:
        end = balanced(head, k)
        reading = head[k + 1:end - 1] if end > 0 else head[k + 1:]
        head = head[:k].strip()
    tail = tail.lstrip()
    if not reading and tail.startswith("("):
        end = balanced(tail, 0)
        if end > 0:
            reading, tail = tail[1:end - 1], tail[end:].lstrip()
    gender = ""
    if reading.strip() in ("f.", "m.", "f", "m"):
        gender, reading = reading.strip()[0], ""
    tail = re.sub(r"^\*\*\s*([-—–:])\s*\*\*", r"\1", tail.strip())  # raü (ราอุน)**:** ...
    tail = re.sub(r"^(?:[-—–:]\s*)+", "", tail)
    if "หมายถึง" in tail:
        tail = tail.split("หมายถึง", 1)[1].strip()
    bm = re.match(r"^\*\*(.+?)\*\*", tail)
    if bm:  # สวาลาน: **แก่นสาร, จิตวิญญาณ:** คำอธิบาย · ซีเลสเทีย: หมายถึง **ดวงดาว**
        tail = bm.group(1).strip().rstrip(":")
    forms = [f.strip().strip("*").strip() for f in head.split("/")]
    senses, tag = senses_of(tail)
    return forms, clean_reading(reading), senses, tag, gender


def inline_pairs(line):
    """คำกริยา เช่น vor (มอง, เห็น), kar (เดิน) ..."""
    s = key(line)
    s = s.split("เช่น", 1)[1] if "เช่น" in s else s
    out = []
    for m in re.finditer(r"([A-Za-zÀ-ɏ'’]+)\s*\(([^()]*)\)", s):
        sen, _ = senses_of(m.group(2))
        out.append(([m.group(1)], "", sen, None, ""))
    return out


def main():
    if not SRC or not os.path.exists(SRC):
        sys.exit("ตั้ง KIRANA_LANG_SRC ให้ชี้ไฟล์ ภาษาแห่งคีรันนา.md")
    raw = open(SRC, encoding="utf-8").read().split("\n")
    keys = [key(l) for l in raw]
    report, words, cats = [], {}, {}
    stats = {}

    def find(rx, a, b):
        for i in range(a, b):
            if re.search(rx, keys[i]):
                return i
        return -1

    for L in NW.LANGS:
        lid = L["id"]
        a = find(L["block"][0], 0, len(raw))
        assert a >= 0, ("ไม่พบหัวข้อภาษา", lid, L["block"][0])
        b = find(L["block"][1], a + 1, len(raw))
        b = len(raw) if b < 0 else b
        rows, catl, ranges = [], [], []
        excl = {x.lower() for x in L.get("exclude", [])}
        dropped = []

        def cat_ix(name):
            if name not in catl:
                catl.append(name)
            return catl.index(name)

        byword = {}

        def add_row(row):
            """คำเดียวกันจากหมวดอื่นที่ความหมายทับกัน รวมเป็นแถวเดียว (แถวแรกเป็นเจ้าของหมวด) · ความหมายไม่ทับกันคือคำพ้องรูป เก็บแยก"""
            for old in byword.get(row[0].lower(), []):
                if set(old[2]) & set(row[2]):
                    old[2].extend(x for x in row[2] if x not in old[2])
                    old[1] = old[1] or row[1]
                    return
            byword.setdefault(row[0].lower(), []).append(row)
            rows.append(row)

        cursor = a
        for sec in L["sec"]:
            sa, sb, pos, cat = sec[:4]
            opts = sec[4] if len(sec) > 4 else {}
            if opts.get("anywhere"):
                s = find(sa, a, b)
            else:
                s = find(sa, cursor, b)  # หมวดเรียงตามลำดับในไฟล์ หาต่อจากหมวดก่อนหน้า
                cursor = s + 1
            assert s >= 0, ("ไม่พบหัวข้อหมวด", lid, sa)
            if sb is None:
                entries = [(s, x) for x in inline_pairs(raw[s])]
            else:
                e = find(sb, s + 1, b)
                e = b if e < 0 else e
                ranges.append(f"{lid} · {cat}: บรรทัด {s + 1}–{e}")
                entries = []
                for i in range(s + 1, e):
                    m = re.match(r"^\s*\*\s+(.*)$", unesc(raw[i]))
                    if not m:
                        continue
                    body = m.group(1)
                    parts = body.split(" / **")
                    parts = [parts[0]] + ["**" + p for p in parts[1:]]
                    for p in parts:
                        r = parse_entry(p)
                        if r is None:
                            report.append(f"{lid} บรรทัด {i + 1}: อ่านไม่ออก · {p[:90]}")
                            continue
                        entries.append((i, r))
            ci = cat_ix(cat)
            seen = {}
            for (i, (forms, reading, senses, tag, gender)) in entries:
                for f in forms:
                    bound = f.endswith("-")
                    w = f.rstrip("-").strip()
                    if not w or not LATIN.match(f) or w.startswith("-") or " " in w:
                        if re.search(r"[A-Za-z]", f) and not re.search(r"[฀-๿]", f):
                            report.append(f"{lid} บรรทัด {i + 1}: ข้ามรูปคำ '{f}'")
                        continue
                    if any(CRUDE.search(x) for x in senses):
                        dropped.append(w + " (คำหยาบหรือคำเพศ)")
                        continue
                    if w.lower() in excl:
                        dropped.append(w)
                        continue
                    p = tag or pos
                    if lid == "az-zillinar" and cat.startswith("ตระกูลรากศัพท์") and p == "v":
                        dropped.append(w + " (กริยาผันแล้ว)")
                        continue
                    sen = [x for x in senses if len(x) <= MAX_SENSE]
                    if not sen and senses:
                        sen = [x for x in (short(senses[0]),) if x]
                    if not sen:
                        report.append(f"{lid} บรรทัด {i + 1}: '{w}' ไม่มีความหมายสั้นพอ · {senses[:2]}")
                        continue
                    if p == "agent":
                        p = "g"
                    k2 = w.lower()
                    if k2 in seen:  # คำซ้ำในหมวดเดียวกัน รวมความหมาย
                        row = seen[k2]
                        row[2].extend(x for x in sen if x not in row[2])
                        continue
                    row = [w, reading, sen, p, ci, 1 if bound else 0]
                    seen[k2] = row
                    add_row(row)
        for ad in L.get("add", []):
            p = ad["pos"]
            flag = 2 if p == "name" else 0
            add_row([ad["w"], ad["r"], list(ad["m"]), "n" if p == "name" else p, cat_ix(ad["cat"]), flag])
        for r in rows:
            if not r[1]:
                r[1] = NW.READINGS.get(lid, {}).get(r[0].lower(), "")
        words[lid], cats[lid] = rows, catl
        report.extend(ranges)
        stats[lid] = len(rows)
        if dropped:
            report.append(f"{lid}: ตัดออกตามรายการ {', '.join(dropped)}")

    # ชนิดคำต่อความหมาย: หมวดที่ปนกัน (x) เดาจากความหมายที่หมวดกริยาและคุณศัพท์ใช้ทั้งไฟล์
    V, A = set(), set()
    for rows in words.values():
        for r in rows:
            if r[3] == "v":
                V.update(r[2])
            elif r[3] == "a":
                A.update(r[2])
    for rows in words.values():
        for r in rows:
            p = r[3]
            per = []
            for x in r[2]:
                if p in ("v", "a", "g"):
                    q = p
                elif x.startswith("ผู้"):
                    q = "g"
                elif x in V:
                    q = "v"
                elif x in A:
                    q = "a"
                elif looks_verb(x):
                    q = "v"
                else:
                    q = "n"
                per.append(q)
            r[3] = "".join(per)
    # คำอ่านที่ขาด ยืมจากคำเดียวกันในภาษาเดียวกัน
    for lid, rows in words.items():
        rd = {}
        for r in rows:
            if r[1]:
                rd.setdefault(r[0].lower(), r[1])
        for r in rows:
            if not r[1] and r[0].lower() in rd:
                r[1] = rd[r[0].lower()]

    langs = []
    for L in NW.LANGS:
        o = {k: v for k, v in L.items() if k not in ("block", "sec", "exclude", "add")}
        o["ways"] = NW.WAYS[L.get("waysOf", L["id"])]
        langs.append(o)
    data = {"src": NW.SRC, "langs": langs, "lists": NW.LISTS, "kin": NW.KIN, "kinByLangPick": NW.KIN_BY_LANG_PICK,
            "cats": cats, "words": words}
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "names.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    with open(os.path.join(OUT, "names_report.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(report) + "\n")
    tot = sum(stats.values())
    print("names.json:", tot, "คำ ·", ", ".join(f"{k} {v}" for k, v in stats.items()))
    print("รายงาน:", len(report), "บรรทัด")


if __name__ == "__main__":
    main()
