# -*- coding: utf-8 -*-
"""v1.22: สร้าง data.json รุ่นใหม่โดยแทนเฉพาะหมวดที่ไฟล์กฎเปลี่ยน แล้วคงหมวดอื่นของรุ่นที่ปล่อยแล้วไว้ตามเดิม

เหตุที่มีสคริปต์นี้: build_data.py อ่านไฟล์กลาง (kins.json skills.json ฯลฯ) จากโฟลเดอร์ชั่วคราวของรอบทำงานก่อน ๆ ไฟล์พวกนั้นหายไปแล้ว
และ skills.json มีการแก้มือหลายรอบ การสร้างใหม่ทั้งชุดจึงเสี่ยงทำของที่แก้ไว้หาย สคริปต์นี้จึงทำแค่
  1) อ่าน sets.json กับ items.json ที่ parse_sets.py / parse_items.py เพิ่งสร้าง (โฟลเดอร์ใน KIRANA_OUT)
  2) แปลงคำแบบเดียวกับ build_data.py (Fortitude → VIT Saving Throw, Will → PER Saving Throw)
  3) แทน DATA.sets กับ DATA.items ใน tools/data.json แก้อภิธานศัพท์และรายชื่อชุดแนะนำของแต่ละสายตาม GLOSSARY_FIX กับ ARCH_SETS ข้างล่าง
  4) เติมประวัติข้อความไอเทม (item_history.py) เทียบกับ data.json รุ่นก่อน แล้วทำตาราง META.itemTextFix ใหม่
ใช้: KIRANA_OUT=<โฟลเดอร์ที่มี sets.json items.json> python3 tools/splice_data.py"""
import json, os, re, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import item_history as ih

OUT_DIR = os.environ["KIRANA_OUT"]
DATA_PATH = os.path.join(HERE, "data.json")
prev = json.load(open(DATA_PATH, encoding="utf-8"))


def same_fix(obj):
    """คำที่ build_data.py แทนทั้งไฟล์ก่อนเขียน data.json (ต้องตรงกัน ไม่งั้นข้อความในชุดกับคลังไอเทมจะต่างจากหมวดอื่น)"""
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    s = s.replace("Fortitude Saving Throw", "VIT Saving Throw").replace("Will Saving Throw", "PER Saving Throw")
    s = re.sub(r"ทอย Fortitude\b", "ทอย VIT Saving Throw", s)
    s = re.sub(r"ทอย Will\b", "ทอย PER Saving Throw", s)
    s = re.sub(r"\bFortitude\b", "VIT Saving Throw", s)
    assert "Fortitude" not in s
    return json.loads(s)


sets = same_fix(json.load(open(os.path.join(OUT_DIR, "sets.json"), encoding="utf-8")))
items = same_fix(json.load(open(os.path.join(OUT_DIR, "items.json"), encoding="utf-8")))

# v1.22.1 (Non สั่ง 13 พ.ย. 2026): ของที่ถูกตัดออกจากคลังแล้ว → ของที่มาแทน (renames_v1221.json) ให้ตัวละครเดิมได้ของใหม่แทนชื่อที่ไม่มีในคลังแล้ว
# migrateNames ในเว็บแทนชื่อครั้งเดียว ชื่อเก่ากว่าที่เคยชี้มาที่ชื่อที่ถูกตัดจึงต้องชี้ไปของใหม่โดยตรง
REN1221 = json.load(open(os.path.join(HERE, "renames_v1221.json"), encoding="utf-8"))
ren = dict(prev["meta"].get("itemRenames") or {})
for k, v in REN1221["items"].items():
    for kk, vv in list(ren.items()):
        if vv == k:
            ren[kk] = v
    ren[k] = v
# ชื่อไอเทมที่ย้ายแล้ว (renames_v116/117/v1221) ต้องยังตรงกับคลังไอเทมรุ่นใหม่
names = {i["name"] for i in items}
assert all(v in names for v in ren.values()) and not any(k in names for k in ren), "ตารางย้ายชื่อไอเทมไม่ตรงกับ items.json"
# น้ำหนักต่อชิ้น [เดิม, ใหม่] ต้องตรงกับคลังรุ่นก่อน (ถ้ายังมีของเดิม) และคลังรุ่นใหม่
prev_w = {i["name"]: i.get("weight") for i in prev.get("items") or []}
new_w = {i["name"]: i.get("weight") for i in items}
RW = REN1221.get("weights") or {}
for k, (w_old, w_new) in RW.items():
    assert k in REN1221["items"], k
    assert abs(float(new_w[REN1221["items"][k]]) - w_new) < 1e-9, (k, new_w[REN1221["items"][k]], w_new)
    if k in prev_w:
        assert abs(float(prev_w[k]) - w_old) < 1e-9, (k, prev_w[k], w_old)

# v1.22 (Non เคาะ 13 พ.ย. 2026): ระยะเคลื่อนที่ต่อหนึ่ง Action คือความเร็วของตัวละคร ไม่ได้คงที่ตามเขต
GLOSSARY_FIX = {
    "Speed": "ความเร็วตามวงศา ใช้เป็นระยะที่ไปได้ต่อหนึ่ง Maneuver · Dash ไปได้เท่าความเร็ว Dash ของวงศา · Run ไปได้เท่าความเร็ววิ่งของวงศา + AGI Mod · ล้มอยู่คลานได้ 1 เมตร · เหนื่อยล้าระดับ 2 ความเร็วเหลือครึ่ง",
    "Maneuver": "เคลื่อนที่หนึ่งครั้ง ระยะเท่าความเร็วของตัวละคร ไม่ได้คงที่ตามเขต · Dash ใช้ 1 Swift · Run ใช้ 1 Swift + 1 AP (ความเร็ววิ่ง + AGI Mod) · ใช้หาที่กำบังในเขตเดิมได้ · ออกจากเขตปะทะโดนโจมตีฉวยโอกาส · ขยับแล้วใช้ Overwatch และ Focus ไม่ได้ในเทิร์นนั้น",
    "Nearby Zone": "ระยะ 4-10 เมตร ยิงใส่เขตปะทะได้โดยไม่ต้องเคลื่อนที่เข้าไป",
    "Far Zone": "ระยะ 11-20+ เมตร ยิงยากขึ้น (ลด CV ตามระยะ นับทุก 10 เมตรที่เริ่มนับ ไม่ติด Disadvantage เพราะระยะ)",
}
# v1.22: ชุดเริ่มต้นเพิ่มเป็น 31 ชุด · ชุดแรกของแต่ละสายคงเดิม ชุดที่เพิ่มแทรกตามสายที่ประกาศไว้ในชุด
ARCH_SETS = {
    "Tank": ["The Vanguard", "The Templar", "The Priest", "The Miner"],
    "Fighter": ["The Samurai", "The Duelist", "The Tribal Warrior", "The Levy", "The Craftsman", "The Homesteader"],
    "Damage Dealer": ["The Gunslinger", "The Marksman", "The Frontier Rifleman", "The Hunter", "The Monster Hunter"],
    "Striker": ["The Reaver", "The Pit Fighter", "The Trench Raider", "The Gunslinger"],
    "Skirmisher": ["The Hunter", "The Sailor", "The Wanderer", "The Stalker"],
    "Rogue": ["The Convict", "The Stalker", "The Wanderer"],
    "Support": ["The Priest", "The Plague Doctor", "The Templar", "The Chef", "The Watchman"],
    "Controller": ["The Mage", "The Watchman", "The Stalker", "The Minstrel", "The Grave Keeper"],
    "Specialist": ["The Scholar", "The Alchemist", "The Monster Hunter", "The Merchant"],
    "Utility": ["The Wanderer", "The Homesteader", "The Miner", "The Sailor", "The Grave Keeper"],
}

data = json.loads(json.dumps(prev, ensure_ascii=False))
data["sets"] = sets
data["items"] = items
data["meta"]["itemRenames"] = ren          # ต้องตั้งก่อน ih.update เพราะประวัติข้อความย้ายชื่อตามตารางนี้
data["meta"]["itemRenameWeights"] = RW
for k, v in GLOSSARY_FIX.items():
    assert k in data["glossary"], k
    data["glossary"][k]["text"] = v
set_names = {s["nameEn"] for s in sets["sets"]}
for a in data["meta"]["archetypes"]:
    lst = ARCH_SETS[a["id"]]
    assert all(n in set_names for n in lst), (a["id"], [n for n in lst if n not in set_names])
    assert lst[0] == a["sets"][0], a["id"]
    a["sets"] = lst

added = ih.update(data, prev, "ก่อน build " + time.strftime("%Y-%m-%d"))
fix, st = ih.build_fix(data)
data["meta"]["itemTextFix"] = fix
out = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
open(DATA_PATH, "w", encoding="utf-8").write(out)
print("item text history: เติม", added, st)
print(len(out), "bytes ·", len(sets["sets"]), "ชุด ·", len(items), "ไอเทม ·", len(ren), "ชื่อย้าย")
