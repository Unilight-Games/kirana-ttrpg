import re, json, sys
SRC = "/mnt/user-data/uploads/Kirana Lore & TTRPG Data/Kirana TTRPG Data/Skill & Sorceries.md"
lines = open(SRC, encoding="utf-8").read().split("\n")

def clean(s):
    s = s.replace("\\", "")
    s = re.sub(r"\*\*", "", s)
    return re.sub(r"\s+", " ", s).strip()

# category by line ranges (1-based inclusive)
RANGES = [
    (107, 274, "Sorcery", "Chaos Sorcery"),
    (275, 417, "Sorcery", "Plasma & Light Sorcery"),
    (418, 526, "Sorcery", "Electric & Energy Sorcery"),
    (527, 659, "Sorcery", "Fire & Combustion Sorcery"),
    (660, 783, "Sorcery", "Wind & Air Sorcery"),
    (784, 948, "Sorcery", "Solid (Earth & Metal) Sorcery"),
    (949, 1120, "Sorcery", "Liquid (Water & Decay) Sorcery"),
    (1121, 1236, "Sorcery", "Sylvian Sorcery"),
    (1237, 1413, "Sorcery", "Ritual Sorcery"),
    (1414, 1523, "Sorcery", "Blood Sorcery (ไม่มีหัวข้อในไฟล์ต้นฉบับ)"),
    (1539, 1644, "Martial", "Unarmed & Melee Skills"),
    (1645, 1696, "Martial", "Ranged Skills"),
    (1697, 1784, "Martial", "Qi"),
    (1785, 1856, "Martial", "Stance"),
    (1857, 1900, "Martial", "Tactical & General Skills"),
    (1901, 1920, "Martial", "Special Skills"),
    (1921, 1994, "Trick", "Trick Skills"),
    (1995, 2008, "Survival", "Social & Interaction Survival"),
    (2009, 2052, "Survival", "Wilderness & Environmental Survival"),
    (2053, 2074, "Survival", "Resilience & Personal Survival"),
    (2077, 2099, "Kins Unique", "Human (ทุกสายมนุษย์)"),
    (2100, 2119, "Kins Unique", "Solrin"),
    (2120, 2139, "Kins Unique", "Lunaryn"),
    (2140, 2159, "Kins Unique", "Nightkin"),
    (2160, 2177, "Kins Unique", "Handerlaw Dwarves"),
    (2178, 2209, "Kins Unique", "Night Alves"),
    (2210, 2238, "Kins Unique", "Day Alves"),
    (2239, 2307, "Kins Unique", "Floran"),
    (2434, 2485, "Kins Unique", "Swalan"),
    (2486, 2511, "Kins Unique", "Orcarim"),
    (2512, 2529, "Kins Unique", "Faceless (ไม่มีในวงศา V.2)"),
    (2530, 2600, "Kins Unique", "Necrobug"),
]
def cat_for(n):
    for a, b, c, s in RANGES:
        if a <= n <= b:
            return c, s
    return None, None

FIELD_KEYS = {
    "ระดับ": "tier", "IP ที่ใช้เรียน": "ip", "IP": "ip", "Components": "components",
    "ประเภท": "type", "Effect": "effect", "Cost": "cost", "เงื่อนไข": "condition",
    "DC Check": "dc", "หากล้มเหลว": "onFail", "ระยะ": "range", "Range": "range",
    "ระยะเวลา": "duration", "Duration": "duration", "เวลา": "duration",
}

# detect a skill header line
HDR = re.compile(r"^\s*(?:\*\s*)?(?:#{2,4}\s*)?\*\*(.+?)\*\*\s*:?\s*$")
FIELD = re.compile(r"^\s*\*\s+\*\*([^*:]+?)\s*:?\s*\*\*\s*:?\s*(.*)$")
FIELD2 = re.compile(r"^\s*\*\s+\*\*([^*]+?):\s*([^*]*)\*\*\s*(.*)$")  # **IP ที่ใช้เรียน: 1 IP**

skills = []
cur = None
branch = None
def flush():
    global cur
    if cur:
        skills.append(cur)
    cur = None

for i, raw in enumerate(lines, 1):
    cat, sub = cat_for(i)
    if cat is None:
        continue
    line = raw.rstrip()
    if not line.strip():
        continue
    if re.match(r"^###\s*\*\*สายที่|^###\s*\*\*หมวดหมู่|^\*\*หมวดหมู่", line):
        branch = clean(re.sub(r"^#+", "", line))
        continue
    if cat == "Sorcery" and sub == "Ritual Sorcery" and line.startswith("### "):
        flush()
        cur = {"name": clean(line[4:]), "category": cat, "subcategory": sub, "branch": None, "line": i, "extra": []}
        continue
    if line.startswith("### ") or line.startswith("## ") or line.startswith("# ") or line.startswith("---"):
        if re.match(r"^\*?\s*###\s*\*\*", line) and cat == "Kins Unique":
            pass
        else:
            flush()
            continue
    hdr = re.match(r"^(?:\*\s+)?(?:#+\s*)?\*\*(.+?)\*\*\s*:?\s*$", line)
    is_field_key = False
    if hdr:
        inner = clean(hdr.group(1))
        for fk in FIELD_KEYS:
            if inner.startswith(fk): is_field_key = True
    if hdr and not is_field_key:
        name = clean(hdr.group(1))
        if name.startswith("หมวด") or name.startswith("ประเภทของ") or name.startswith("ทักษะ") or name.startswith("Necrobug"):
            flush(); continue
        flush()
        cur = {"name": name, "category": cat, "subcategory": sub, "branch": branch if cat == "Sorcery" else None, "line": i, "extra": []}
        continue
    m = FIELD2.match(line) or FIELD.match(line)
    if m and cur is not None:
        key = clean(m.group(1)).rstrip(":").strip()
        val = clean(" ".join(m.groups()[1:]))
        k = None
        for fk, mapped in FIELD_KEYS.items():
            if key.startswith(fk):
                k = mapped; break
        if k is None:
            cur["extra"].append(clean(line))
        elif k in cur and cur[k]:
            cur["extra"].append(key + ": " + val)
        else:
            cur[k] = val
        continue
    if cur is not None:
        cur["extra"].append(clean(line))
flush()

# post-process
for s in skills:
    # split name "English (Thai)" or "Thai (English)"
    n = s["name"]
    mm = re.match(r"^(.*?)\s*\((.*)\)\s*$", n)
    if mm:
        a, b = mm.group(1).strip(), mm.group(2).strip()
        if re.search(r"[ก-๙]", a) and not re.search(r"[ก-๙]", b):
            s["nameEn"], s["nameTh"] = b, a
        else:
            s["nameEn"], s["nameTh"] = a, b
    else:
        s["nameEn"], s["nameTh"] = n, ""
    if "ip" in s:
        mi = re.search(r"(\d+)", s["ip"])
        s["ipCost"] = int(mi.group(1)) if mi else None
    else:
        s["ipCost"] = None
    t = s.get("type", "")
    tags = []
    if "กระบวนท่า" in t or "Stance" in s["nameEn"]: tags.append("Stance")
    if s["subcategory"] == "Qi": tags.append("Qi")
    if "Passive" in t: tags.append("Passive")
    if "Reaction" in t: tags.append("Reaction")
    if "Cast" in t: tags.append("Cast")
    s["tags"] = tags
    s["extra"] = [e for e in s["extra"] if e]

json.dump(skills, open("/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/skills.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(skills))
from collections import Counter
c = Counter((s["category"], s["subcategory"]) for s in skills)
for k, v in sorted(c.items()): print(v, k)
print("no effect:", [s["name"] for s in skills if "effect" not in s])
print("no ip:", sum(1 for s in skills if s["ipCost"] is None))
