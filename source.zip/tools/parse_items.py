"""แปลง Item All.md → items.json (แคตตาล็อกไอเทมทั้งเกม สำหรับ GM มอบให้ผู้เล่นและค้นหา)
โครงไฟล์: หัวข้อ (## ### ####) คั่นหมวด · ไอเทมคือบรรทัดชื่อตัวหนา **ชื่อ (ไทย)** (บางทีมี #### นำหน้า หรือเป็น * **ชื่อ**)
ตามด้วยบูลเล็ต **คีย์:** ค่า (คำอธิบาย เอฟเฟค ชนิด ราคา น้ำหนัก Armor ประเภท ประสิทธิภาพ ...)
บล็อกที่ไม่มีราคา/น้ำหนัก/เอฟเฟค/Armor ถือเป็นหัวข้อหรือคำอธิบายทั่วไป ไม่ใช่ไอเทม"""
import re, json, sys, os
# v1.22: ชี้ไฟล์ต้นทางและโฟลเดอร์ผลลัพธ์ได้ด้วย KIRANA_ITEMS_SRC และ KIRANA_OUT (ค่าเดิมคงไว้)
SRC = os.environ.get("KIRANA_ITEMS_SRC", "/mnt/user-data/outputs/rules/Item All.md")  # สำเนาล่าสุดของไฟล์ในไดรฟ์
OUT = os.path.join(os.environ.get("KIRANA_OUT", "/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/"), "items.json")
lines = open(SRC, encoding="utf-8").read().split("\n")

def clean(s):
    s = s.replace("\\", "")
    s = re.sub(r"\*\*", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

HEAD = re.compile(r"^(#{1,6})\s*\**\s*(.*?)\s*\**\s*$")
# ชื่อไอเทม: **ชื่อ** ทั้งบรรทัด อาจมี #### หรือ "* " หรือเลขข้อ "1. " นำหน้า (หมวด Waist / Feet / Cape ใช้เลขข้อ: v1.14 แก้ให้อ่านได้ ได้ไอเทมเพิ่ม 40 ชิ้น)
NAME = re.compile(r"^(?:#{1,6}\s*)?(?:\*\s+|\d+\\?\.\s+)?\*\*(.+?)\*\*\s*$")
KV = re.compile(r"^\s*\*\s+\*\*(.+?):?\*\*:?\s*(.*)$")
SUBKV = re.compile(r"^\s{2,}\*\s+\*\*(.+?):?\*\*:?\s*(.*)$")

ITEM_KEYS = {"ราคา", "น้ำหนัก", "เอฟเฟค", "Armor", "ประสิทธิภาพ", "ราคาต่อซอง", "เอฟเฟคพิเศษ"}
SKIP_KEYS = {"มูลค่าชุด", "น้ำหนักแบกรวม"}  # บล็อกชุดเริ่มต้น ไม่ใช่ไอเทม

blocks = []  # [{name, level, start, kv:[(k,v)], extra:[]}]
cur = None
heads = []   # (lineno, level, text)
for i, raw in enumerate(lines):
    l = raw.rstrip()
    if not l.strip():
        continue
    km0 = KV.match(l)
    m = NAME.match(l)
    if km0 and clean(km0.group(2)):
        m = None  # บูลเล็ต **คีย์:** ค่า ที่ลงท้ายด้วยตัวหนา ไม่ใช่ชื่อไอเทม
    if m:
        # ชื่อตัวหนาบรรทัดเดียว (อาจเป็นหัวข้อหรือไอเทม)
        name = clean(m.group(1))
        if name.endswith(":") and cur is not None and not l.startswith("#"):
            cur["kv"].append([name.rstrip(":").strip(), ""]); continue  # **คีย์:** ที่ไม่มีค่าในบรรทัดเดียวกัน (ค่าอยู่ในบูลเล็ตย่อย)
        level = len(l) - len(l.lstrip("#")) if l.startswith("#") else 0
        cur = {"name": name, "level": level, "start": i + 1, "kv": [], "extra": []}
        blocks.append(cur)
        continue
    hm = HEAD.match(l)
    if hm and not KV.match(l):
        txt = clean(hm.group(2))
        if txt:
            heads.append((i + 1, len(hm.group(1)), txt))
            cur = {"name": txt, "level": len(hm.group(1)), "start": i + 1, "kv": [], "extra": [], "head": True}
            blocks.append(cur)
        continue
    if cur is None:
        continue
    km = KV.match(l)
    if km:
        k = clean(km.group(1)).rstrip(":").strip(); v = clean(km.group(2))
        if k in ITEM_KEYS or k in SKIP_KEYS or k in ("คำอธิบาย", "ระดับ", "การใช้งานเชิงกลยุทธ์", "ชนิด", "ชนิดอาวุธ", "ประเภท", "ลักษณะ", "จำนวนในซอง", "ความทนทาน", "Durability", "เงื่อนไข", "ข้อจำกัด", "การใช้งาน", "ระดับ", "Tier", "หมายเหตุ", "Slot", "ช่องสวมใส่"):
            cur["kv"].append([k, v])
        else:
            # บูลเล็ตย่อยตัวหนาอื่น ๆ (เช่น ชื่อคุณสมบัติพิเศษ) ต่อท้ายเอฟเฟค
            cur["extra"].append((k + ": " + v).strip(": "))
        continue
    # บรรทัดตัวเอียงทั้งบรรทัด (*…*) คือหมายเหตุของหมวด ไม่ใช่คำอธิบายต่อของไอเทมก่อนหน้า
    if re.match(r"^\*[^*\s].*[^*\s]\*\s*$", l.strip()):
        continue
    # บรรทัดอธิบายต่อเนื่อง (ไม่มีตัวหนา)
    t = clean(l.lstrip("*").strip())
    if t and not t.startswith("---") and cur["kv"]:
        cur["extra"].append(t)

def is_item(b):
    keys = {k for k, v in b["kv"]}
    if keys & SKIP_KEYS: return False
    return bool(keys & ITEM_KEYS)

# หมวดจากหัวข้อ: ไล่หาหัวข้อล่าสุดที่ไม่ใช่ไอเทม ระดับ ≤ 3 และระดับ 4
TOP_FIX = [  # ช่วงบรรทัด → หมวดใหญ่ (ไฟล์ไม่มีหัวข้อหมวดใหญ่ให้บางช่วง · v1.22.1 ตรวจกับไฟล์ 13 พ.ย. 2026 หลังตัดหนังยางเหวี่ยงหิน (Sling Shot) 9 บรรทัดออกจากหมวดอาวุธระยะไกล)
    (3, 100, "คุณสมบัติ"), (101, 658, "ชุดเริ่มต้น"), (659, 1058, "อาวุธประชิด"), (1059, 1257, "อาวุธระยะไกล"),
    (1258, 1383, "กระสุน"), (1384, 1432, "อาวุธเวทมนตร์"), (1433, 1542, "โล่"), (1543, 1910, "เครื่องมือและอุปกรณ์"),
    (1911, 2012, "เกราะลำตัว"), (2013, 2393, "เกราะส่วนย่อย"), (2394, 2441, "แหวน"), (2442, 2808, "เสื้อผ้าและหมวก"),
    (2809, 2948, "หมวกเกราะ"), (2949, 3280, "วัตถุดิบอาหาร"), (3281, 3750, "วัตถุดิบเล่นแร่แปรธาตุ"), (3751, 3905, "เสบียงและเครื่องดื่ม"),
    (3906, 3988, "ไอเทมเวทมนตร์"), (3989, 4118, "อาวุธเทคโนโลยี"), (4119, 99999, "อุปกรณ์พิเศษ"),
]
# v1.26: บรรทัดแรกของแต่ละช่วงใน TOP_FIX ใช้เป็นหมุด ค้นตามลำดับจากบนลงล่าง ช่วงหมวดจึงยังถูกแม้ไฟล์มีบรรทัดเพิ่ม (เช่นบูลเล็ต ระดับ ของ splice_v126.py)
TOP_ANCHOR = [
    "## คุณสมบัติที่ส่งผลต่อความเสียหาย", "## **ชุดของเริ่มต้น (Starter Set)**", "### **ระดับอาวุธ 1 (Weapon Tier 1\\)**",
    "### **ระดับอาวุธ 1 (Weapon Tier 1\\)**", "### **ลูกศร (Arrows)**", "### **อาวุธเวทมนตร์และอาวุธพิเศษ (Sorcery & Special Weapons)**",
    "### **หมวดโล่ (Shields)**", "### **1\\. เครื่องมือยังชีพและเก็บทรัพยากร", "### **1\\. เสื้อบุเกราะแกมเบสัน (Field Gambeson)**",
    "### ", "**1\\. แหวนตราประจำตระกูล (Signet Ring)**", "**เสื้อเชมิสผ้าฝ้าย (Cotton Chemise)**", "### **หมวดหมวกเกราะ (Helmets)**",
    "## **วัตถุดิบหลัก (Main Ingredient)**", "## **วัตถุดิบหลัก (Main Ingredient)**", "**เสบียง (Ration)**",
    "**รองเท้าบูทอักขระวายุ (Syr Boots)**", "**คทาเพลิง (Fire Mace)**", "**ปืนยิงตาข่ายไฟฟ้า (Electric Net Gun)**",
]
def _anchored_ranges():
    starts = []; pos = 0
    for a in TOP_ANCHOR:
        for j in range(pos, len(lines)):
            t = lines[j].rstrip()
            if (t == a.rstrip()) if a.strip() == "###" else t.startswith(a):
                starts.append(j + 1); pos = j + 1; break
        else:
            return None
    ends = [x - 1 for x in starts[1:]] + [99999]
    return [(a, b, c) for a, b, (_, _, c) in zip(starts, ends, TOP_FIX)]
TOP_RANGES = _anchored_ranges() or TOP_FIX
def top_of(line):
    for a, b, c in TOP_RANGES:
        if a <= line <= b: return c
    return "อื่น ๆ"

items = []
seen = set()
last_sub = ""; last_sub_line = 0
for b in blocks:
    if not is_item(b):
        if b["name"] and (b.get("head") or b["level"] or not b["kv"]):
            last_sub = b["name"]; last_sub_line = b["start"]
        continue
    if top_of(last_sub_line) != top_of(b["start"]): last_sub = ""  # หัวข้อย่อยค้างจากหมวดก่อน
    kv = dict()
    for k, v in b["kv"]:
        kv[k] = (kv.get(k, "") + " " + v).strip() if k in kv else v
    name = re.sub(r"^\d+\s*\.\s*", "", b["name"]).strip()
    if not name or name.lower() in seen: continue
    seen.add(name.lower())
    eff = []
    for k in ("ประสิทธิภาพ", "เอฟเฟค", "เอฟเฟคพิเศษ"):
        if kv.get(k) and kv[k] not in ("-", "—"): eff.append(kv[k])
    if kv.get("Armor"): eff.insert(0, "Armor " + kv["Armor"])
    for k in ("ชนิดอาวุธ", "ชนิด", "ประเภท"):
        if kv.get(k): eff.append(("ประเภท: " if k == "ประเภท" else "ชนิด: ") + kv[k])
    if b["extra"]: eff.append(" ".join(b["extra"])[:400])
    w = kv.get("น้ำหนัก", "")
    wm = re.search(r"(\d+(?:\.\d+)?)", w)
    price = kv.get("ราคา") or kv.get("ราคาต่อซอง") or ""
    items.append({
        "name": name, "cat": top_of(b["start"]), "sub": last_sub if last_sub != name else "",
        "desc": kv.get("คำอธิบาย") or kv.get("ลักษณะ") or "",
        "effect": " · ".join(eff)[:700], "weight": float(wm.group(1)) if wm else 0, "price": price,
        "slot": kv.get("ประเภท", ""), "src": "Item All",
    })
    tm = re.match(r"\s*(?:Tier\s*)?(\d)", kv.get("ระดับ", "")) if kv.get("ระดับ") else None
    if tm: items[-1]["tier"] = int(tm.group(1))
    elif "พิเศษ" in kv.get("ระดับ", ""): items[-1]["tier"] = "S"

json.dump(items, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
from collections import Counter
print(len(items), "items")
print(Counter(i["cat"] for i in items))
if "-v" in sys.argv:
    for i in items[:12]: print(i["name"], "|", i["cat"], "|", i["sub"], "|", i["weight"], "|", i["price"], "|", i["effect"][:80])
