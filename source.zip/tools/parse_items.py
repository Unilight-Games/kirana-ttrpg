"""แปลง Item All.md → items.json (แคตตาล็อกไอเทมทั้งเกม สำหรับ GM มอบให้ผู้เล่นและค้นหา)
โครงไฟล์: หัวข้อ (## ### ####) คั่นหมวด · ไอเทมคือบรรทัดชื่อตัวหนา **ชื่อ (ไทย)** (บางทีมี #### นำหน้า หรือเป็น * **ชื่อ**)
ตามด้วยบูลเล็ต **คีย์:** ค่า (คำอธิบาย เอฟเฟค ชนิด ราคา น้ำหนัก Armor ประเภท ประสิทธิภาพ ...)
บล็อกที่ไม่มีราคา/น้ำหนัก/เอฟเฟค/Armor ถือเป็นหัวข้อหรือคำอธิบายทั่วไป ไม่ใช่ไอเทม"""
import re, json, sys, os
# v1.22: ชี้ไฟล์ต้นทางและโฟลเดอร์ผลลัพธ์ได้ด้วย KIRANA_ITEMS_SRC และ KIRANA_OUT (ค่าเดิมคงไว้)
SRC = os.environ.get("KIRANA_ITEMS_SRC", "/mnt/user-data/outputs/rules/Item All.md")  # สำเนาล่าสุดของไฟล์ในไดรฟ์
OUT = os.path.join(os.environ.get("KIRANA_OUT", "/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/"), "items.json")
lines = open(SRC, encoding="utf-8").read().split("\n")

def clean(s):
    s = s.replace("\\", "")
    s = re.sub(r"\*\*", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

HEAD = re.compile(r"^(#{1,6})\s*\**\s*(.*?)\s*\**\s*$")
# ชื่อไอเทม: **ชื่อ** ทั้งบรรทัด อาจมี #### หรือ "* " หรือเลขข้อ "1. " นำหน้า (หมวด Waist / Feet / Cape ใช้เลขข้อ: v1.14 แก้ให้อ่านได้ ได้ไอเทมเพิ่ม 40 ชิ้น)
NAME = re.compile(r"^(?:#{1,6}\s*)?(?:\*\s+|\d+\\?\.\s+)?\*\*(.+?)\*\*\s*$")
KV = re.compile(r"^\s*\*\s+\*\*(.+?):?\*\*:?\s*(.*)$")
SUBKV = re.compile(r"^\s{2,}\*\s+\*\*(.+?):?\*\*:?\s*(.*)$")

ITEM_KEYS = {"ราคา", "น้ำหนัก", "เอฟเฟค", "Armor", "ประสิทธิภาพ", "ราคาต่อซอง", "เอฟเฟคพิเศษ"}
SKIP_KEYS = {"มูลค่าชุด", "น้ำหนักแบกรวม"}  # บล็อกชุดเริ่มต้น ไม่ใช่ไอเทม

blocks = []  # [{name, level, start, kv:[(k,v)], extra:[]}]
cur = None
heads = []   # (lineno, level, text)
for i, raw in enumerate(lines):
    l = raw.rstrip()
    if not l.strip():
        continue
    km0 = KV.match(l)
    m = NAME.match(l)
    if km0 and clean(km0.group(2)):
        m = None  # บูลเล็ต **คีย์:** ค่า ที่ลงท้ายด้วยตัวหนา ไม่ใช่ชื่อไอเทม
    if m:
        # ชื่อตัวหนาบรรทัดเดียว (อาจเป็นหัวข้อหรือไอเทม)
        name = clean(m.group(1))
        if name.endswith(":") and cur is not None and not l.startswith("#"):
            cur["kv"].append([name.rstrip(":").strip(), ""]); continue  # **คีย์:** ที่ไม่มีค่าในบรรทัดเดียวกัน (ค่าอยู่ในบูลเล็ตย่อย)
        level = len(l) - len(l.lstrip("#")) if l.startswith("#") else 0
        cur = {"name": name, "level": level, "start": i + 1, "kv": [], "extra": []}
        blocks.append(cur)
        continue
    hm = HEAD.match(l)
    if hm and not KV.match(l):
        txt = clean(hm.group(2))
        if txt:
            heads.append((i + 1, len(hm.group(1)), txt))
            cur = {"name": txt, "level": len(hm.group(1)), "start": i + 1, "kv": [], "extra": [], "head": True}
            blocks.append(cur)
        continue
    if cur is None:
        continue
    km = KV.match(l)
    if km:
        k = clean(km.group(1)).rstrip(":").strip(); v = clean(km.group(2))
        if k in ITEM_KEYS or k in SKIP_KEYS or k in ("คำอธิบาย", "การใช้งานเชิงกลยุทธ์", "ชนิด", "ชนิดอาวุธ", "ประเภท", "ลักษณะ", "จำนวนในซอง", "ความทนทาน", "Durability", "เงื่อนไข", "ข้อจำกัด", "การใช้งาน", "ระดับ", "Tier", "หมายเหตุ", "Slot", "ช่องสวมใส่"):
            cur["kv"].append([k, v])
        else:
            # บูลเล็ตย่อยตัวหนาอื่น ๆ (เช่น ชื่อคุณสมบัติพิเศษ) ต่อท้ายเอฟเฟค
            cur["extra"].append((k + ": " + v).strip(": "))
        continue
    # บรรทัดตัวเอียงทั้งบรรทัด (*…*) คือหมายเหตุของหมวด ไม่ใช่คำอธิบายต่อของไอเทมก่อนหน้า
    if re.match(r"^\*[^*\s].*[^*\s]\*\s*$", l.strip()):
        continue
    # บรรทัดอธิบายต่อเนื่อง (ไม่มีตัวหนา)
    t = clean(l.lstrip("*").strip())
    if t and not t.startswith("---") and cur["kv"]:
        cur["extra"].append(t)

def is_item(b):
    keys = {k for k, v in b["kv"]}
    if keys & SKIP_KEYS: return False
    return bool(keys & ITEM_KEYS)

# หมวดจากหัวข้อ: ไล่หาหัวข้อล่าสุดที่ไม่ใช่ไอเทม ระดับ ≤ 3 และระดับ 4
TOP_FIX = [  # ช่วงบรรทัด → หมวดใหญ่ (ไฟล์ไม่มีหัวข้อหมวดใหญ่ให้บางช่วง · v1.22 ตรวจกับไฟล์ 13 พ.ย. 2026 หลังเพิ่มชุดเริ่มต้น 14 ชุดและอาวุธระดับ 1-2 อีก 16 ชิ้น)
    (3, 100, "คุณสมบัติ"), (101, 658, "ชุดเริ่มต้น"), (659, 1058, "อาวุธประชิด"), (1059, 1266, "อาวุธระยะไกล"),
    (1267, 1392, "กระสุน"), (1393, 1441, "อาวุธเวทมนตร์"), (1442, 1551, "โล่"), (1552, 1919, "เครื่องมือและอุปกรณ์"),
    (1920, 2021, "เกราะลำตัว"), (2022, 2402, "เกราะส่วนย่อย"), (2403, 2450, "แหวน"), (2451, 2817, "เสื้อผ้าและหมวก"),
    (2818, 2957, "หมวกเกราะ"), (2958, 3289, "วัตถุดิบอาหาร"), (3290, 3759, "วัตถุดิบเล่นแร่แปรธาตุ"), (3760, 3914, "เสบียงและเครื่องดื่ม"),
    (3915, 3997, "ไอเทมเวทมนตร์"), (3998, 4127, "อาวุธเทคโนโลยี"), (4128, 99999, "อุปกรณ์พิเศษ"),
]
def top_of(line):
    for a, b, c in TOP_FIX:
        if a <= line <= b: return c
    return "อื่น ๆ"

items = []
seen = set()
last_sub = ""; last_sub_line = 0
for b in blocks:
    if not is_item(b):
        if b["name"] and (b.get("head") or b["level"] or not b["kv"]):
            last_sub = b["name"]; last_sub_line = b["start"]
        continue
    if top_of(last_sub_line) != top_of(b["start"]): last_sub = ""  # หัวข้อย่อยค้างจากหมวดก่อน
    kv = dict()
    for k, v in b["kv"]:
        kv[k] = (kv.get(k, "") + " " + v).strip() if k in kv else v
    name = re.sub(r"^\d+\s*\.\s*", "", b["name"]).strip()
    if not name or name.lower() in seen: continue
    seen.add(name.lower())
    eff = []
    for k in ("ประสิทธิภาพ", "เอฟเฟค", "เอฟเฟคพิเศษ"):
        if kv.get(k) and kv[k] not in ("-", "—"): eff.append(kv[k])
    if kv.get("Armor"): eff.insert(0, "Armor " + kv["Armor"])
    for k in ("ชนิดอาวุธ", "ชนิด", "ประเภท"):
        if kv.get(k): eff.append(("ประเภท: " if k == "ประเภท" else "ชนิด: ") + kv[k])
    if b["extra"]: eff.append(" ".join(b["extra"])[:400])
    w = kv.get("น้ำหนัก", "")
    wm = re.search(r"(\d+(?:\.\d+)?)", w)
    price = kv.get("ราคา") or kv.get("ราคาต่อซอง") or ""
    items.append({
        "name": name, "cat": top_of(b["start"]), "sub": last_sub if last_sub != name else "",
        "desc": kv.get("คำอธิบาย") or kv.get("ลักษณะ") or "",
        "effect": " · ".join(eff)[:700], "weight": float(wm.group(1)) if wm else 0, "price": price,
        "slot": kv.get("ประเภท", ""), "src": "Item All",
    })

json.dump(items, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
from collections import Counter
print(len(items), "items")
print(Counter(i["cat"] for i in items))
if "-v" in sys.argv:
    for i in items[:12]: print(i["name"], "|", i["cat"], "|", i["sub"], "|", i["weight"], "|", i["price"], "|", i["effect"][:80])
