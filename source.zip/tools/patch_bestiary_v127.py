"""v1.27 (Non เคาะ 16 พ.ย. 2026): แก้ Fauna, Enemy & Companion.md ให้ตรงกฎเดียวกับตัวละครผู้เล่น
  "2. ใช้กฎเดียวกัน" · "3. เอาตามที่เห็นสมควร" · "5. ในจอมโหดเปลี่ยนเป็น Battle Axe และ Hide Armor แทน ส่วนที่เหลือเอาตามที่คุณเห็นสมควร"
  1) Reflex Might Sight ในบรรทัดค่าสถานะ = ปัดลง(Mod / 2) + 1 ของ AGI STR PER · Initiative = PER Mod (คู่มือสร้างอสูรในไฟล์แกน)
  2) ขนาดใหญ่ได้ +1 All Toughness ตามคู่มือและตารางขนาด: บรรทัดที่เขียน "+2 จาก Size" กับตัวขนาดใหญ่แก้เป็น +1
  3) จอมโหด: ขวานยักษ์ (Greataxe) เป็น ขวานศึก (Battle Axe) ค่าโจมตีตาม Item All · เกราะหนังสัตว์เสริมเหล็ก (Reinforced Hide Armor) เป็น เกราะหนังฟอก (Hide Armor)
  4) กองกำลังอาสา: เสื้อผ้าชาวบ้าน (Common Clothes) เป็นเสื้อทูนิคกับกางเกงผ้าทอหยาบของ Item All (ชุดของชาวนาและผู้ตั้งรกรากชายแดน)
  5) (Non สั่ง "แก้ไขตามเห็นสมควรแล้วอัปขึ้นได้เลยครับ" 16 พ.ย.) ผู้คนที่สวมเกราะสี่ตัว ยามรักษาการณ์ พลทหารราบ อัศวินเกราะโซ่ กองประจัญบาน
     ลบ +X All Armor ออกจากบรรทัดค่าสถานะ ค่านั้นย่อมาจากเกราะที่สวม เกราะคิดรายส่วนจากยุทโธปกรณ์ที่สวมแบบเดียวกับผู้คนตัวอื่นและตัวละครผู้เล่น
ใช้: python3 tools/patch_bestiary_v127.py <เข้า.md> <ออก.md> <diff>
สคริปต์หยุดถ้าหาข้อความที่จะแก้ไม่เจอครบ และรันซ้ำบนไฟล์ที่แก้แล้วได้ (ไม่มีอะไรเปลี่ยน)"""
import sys, re, math, difflib, json, subprocess, os, tempfile

SRC, OUT, DIFF = sys.argv[1], sys.argv[2], sys.argv[3]
text = open(SRC, encoding="utf-8").read()
L = text.split("\n")
problems = []

# อ่านสแตตบล็อกด้วยตัวอ่านของเว็บ เพื่อได้ช่วงบรรทัดของแต่ละตัวกับค่าพลังดัดแปลง
here = os.path.dirname(os.path.abspath(__file__))
tmp = tempfile.mktemp(suffix=".json")
subprocess.run([sys.executable, os.path.join(here, "parse_bestiary.py"), SRC, tmp], check=True, stdout=subprocess.DEVNULL)
B = json.load(open(tmp, encoding="utf-8")); os.remove(tmp)
heads = sorted(e["line"] - 1 for e in B["entries"])

def fmt(v):
    return ("\\+" if v >= 0 else "\\-") + str(abs(v))
def val(s):
    s = s.replace("\\", "").replace(" ", "").replace("−", "-")
    return int(s)

ARMORED = ("Militia Watchman", "Imperial Infantryman", "Chainmail Knight", "Landsknecht")
changed = []
for e in B["entries"]:
    a = e["line"] - 1
    nxt = [x for x in heads if x > a]
    b = nxt[0] if nxt else len(L)
    idx = next((i for i in range(a, b) if "ค่าสถานะ" in L[i] and re.search(r"HP\s*\d", L[i])), None)
    if idx is None:
        problems.append(e["en"] + ": ไม่เจอบรรทัดค่าสถานะ"); continue
    line = L[idx]; m = e["mods"]
    want = {"Reflex": math.floor(m.get("AGI", 0) / 2) + 1, "Might": math.floor(m.get("STR", 0) / 2) + 1,
            "Sight": math.floor(m.get("PER", 0) / 2) + 1, "Initiative": m.get("PER", 0)}
    for k, w in want.items():
        rx = re.compile(r"(\b" + k + r"\s*)((?:\\[+\-]|[+\-−])?\s*\d+)")
        mm = rx.search(line)
        if not mm: continue  # ตัวที่เอกสารไม่ได้เขียนค่านั้นไว้ (เช่น Sight ของสัตว์ส่วนใหญ่)
        if val(mm.group(2)) != w:
            changed.append(f"{e['en']}: {k} {mm.group(2).replace(chr(92), '')} → {fmt(w).replace(chr(92), '')}")
            line = line[:mm.start(2)] + fmt(w) + line[mm.end(2):]
    if e["size"] == "Large":
        mm = re.search(r"Toughness\s*(\*\*)?(\d+)(\*\*)?\s*\((\d+)\+2 จาก Size\)", line)
        if mm:
            base = int(mm.group(4)); tot = base + 1
            changed.append(f"{e['en']}: Toughness {mm.group(2)} ({base}+2 จาก Size) → {tot} ({base}+1 จาก Size)")
            line = line[:mm.start()] + f"Toughness {mm.group(1) or ''}{tot}{mm.group(3) or ''} ({base}+1 จาก Size)" + line[mm.end():]
    if e["en"] in ARMORED:
        mm = re.search(r",\s*\\\+(\d+)\s*All Armor", line)
        if mm:
            changed.append(f"{e['en']}: ลบ +{mm.group(1)} All Armor (เกราะคิดรายส่วนจากยุทโธปกรณ์ที่สวม)")
            line = line[:mm.start()] + line[mm.end():]
        if "All Armor" in line:
            problems.append(e["en"] + ": ยังเหลือ All Armor ในบรรทัดค่าสถานะ")
    L[idx] = line

for en in ARMORED:
    if not any(e["en"] == en for e in B["entries"]): problems.append("ไม่เจอสแตตบล็อก " + en)

def swap(old, new, label):
    global L
    t = "\n".join(L)
    n = t.count(old)
    if n == 0:
        if t.count(new): return  # แก้ไปแล้ว
        problems.append("ไม่เจอ: " + label); return
    if n > 1:
        problems.append(f"เจอ {n} ที่: " + label); return
    L = t.replace(old, new).split("\n"); changed.append(label)

swap("  * **ขวานยักษ์ (Greataxe):** CV Bonus \\+3, Damage 1d6 \\+ Might Slashing (มีคุณสมบัติ **Cleave**, **Guard Break**)",
     "  * **ขวานศึก (Battle Axe):** CV Bonus \\+3, Damage 3 PDMG (Slashing) (มีคุณสมบัติ **Guard Break**, Attack On-Hit จะติด **Unbalanced**, \\+1 Toughness Damage)",
     "จอมโหด: การโจมตีด้วยขวานศึก (Battle Axe) ตาม Item All")
swap("การโจมตีด้วย **ขวานยักษ์ (Greataxe)** ครั้งแรก", "การโจมตีด้วย **ขวานศึก (Battle Axe)** ครั้งแรก", "จอมโหด: พุ่งเข้าชาร์จอ้างถึงขวานศึก (Battle Axe)")
swap("* **ขวานยักษ์ (Greataxe) (1-3)**", "* **ขวานศึก (Battle Axe) (1-3)**", "จอมโหด: ยุทโธปกรณ์ 1-3 เป็นขวานศึก (Battle Axe)")
swap("* **เกราะหนังสัตว์เสริมเหล็ก (Reinforced Hide Armor)** **(4-6)**", "* **เกราะหนังฟอก (Hide Armor)** **(4-6)**", "จอมโหด: ยุทโธปกรณ์ 4-6 เป็นเกราะหนังฟอก (Hide Armor)")
swap("  * เสื้อผ้าชาวบ้าน (Common Clothes) และ หมวกคออิฟผ้าลินิน (Linen Coif) (5-6)",
     "  * เสื้อทูนิคผ้าทอหยาบ (Rough-Woven Tunic) และ กางเกงผ้าทอหยาบ (Rough-Woven Trousers) และ หมวกคออิฟผ้าลินิน (Linen Coif) (5-6)",
     "กองกำลังอาสา: เสื้อผ้าชาวบ้าน (Common Clothes) เป็นเสื้อทูนิคกับกางเกงผ้าทอหยาบ")

out = "\n".join(L)
for left in ("Greataxe", "Reinforced Hide Armor", "Common Clothes"):
    if left in out: problems.append("ยังเหลือคำว่า " + left)
if problems:
    print("หยุด:"); [print(" -", p) for p in problems]; sys.exit(1)
open(OUT, "w", encoding="utf-8", newline="").write(out)
d = difflib.unified_diff(text.split("\n"), out.split("\n"), "ก่อนแก้", "หลังแก้", lineterm="", n=0)
open(DIFF, "w", encoding="utf-8").write("\n".join(d) + "\n")
print(f"แก้ {len(changed)} จุด"); [print(" -", c) for c in changed]
