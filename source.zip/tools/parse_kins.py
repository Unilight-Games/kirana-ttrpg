import re, json
SRC = "/mnt/user-data/uploads/Kirana Lore & TTRPG Data/Kirana TTRPG Data/Kins of Kirana V.2.md"
raw = open(SRC, encoding="utf-8").read().split("\n")
lines = [("" if len(l) > 5000 else l) for l in raw]

KINS = [  # (start line 1-based, id, display name)
    (29, "lunaryn", "Lunaryn / Blood Moon"),
    (242, "solrin", "Sun Flare Order / Solrin"),
    (371, "nightkin", "Nightkin"),
    (485, "rimmen", "The Rimmen (ริมเมน หรือ คนชายขอบ)"),
    (593, "norlan", "Norlan / Nord (ชาวนอร์ลัน หรือ ชาวนอร์ท)"),
    (699, "day-alves", "Alves / Day Alves"),
    (805, "night-alves", "Night Alves"),
    (991, "handerlaw-dwarves", "Handerlaw Dwarves"),
    (1104, "swalan", "Swalan"),
    (1217, "floran", "Floran"),
    (1322, "orcarim", "Orcarim"),
    (1431, "necrobug", "Necrobug / Mok'Nars"),
]
END = 1564  # Beastman starts (excluded)

def clean(s):
    s = re.sub(r"!\[\]\[image\d+\]", "", s)
    s = s.replace("\\", "")
    s = re.sub(r"\*\*", "", s)
    s = s.replace("`", "")
    return re.sub(r"\s+", " ", s).strip()

STATS = ["STR", "AGI", "VIT", "PER", "INF", "INT"]
def parse_stat_line(s):
    out = {}
    for m in re.finditer(r"([+-]?\d+)\s*(STR|AGI|VIT|PER|INF|INT|Extra)", s):
        out[m.group(2)] = int(m.group(1))
    return out

# archetype lines (**แนวทาง:**) precede the kin header they describe
arche = {}
for i, l in enumerate(lines, 1):
    if l.startswith("**แนวทาง:**"):
        # find next kin start after i
        nxt = [k for k in KINS if k[0] > i]
        if nxt:
            arche[nxt[0][1]] = clean(l.split(":", 1)[1])

kins = []
for idx, (start, kid, name) in enumerate(KINS):
    end = KINS[idx + 1][0] - 1 if idx + 1 < len(KINS) else END - 1
    k = {"id": kid, "name": name, "intro": [], "raw": {}, "extra": 0, "age": "", "size": "", "speed": "", "languages": "",
         "benefits": [], "traits": [], "hindrances": [], "starterSkills": [], "childhood": [], "specialChildhood": [],
         "adulthood": [], "specialAdulthood": [], "archetype": arche.get(kid, ""), "misc": []}
    state = "intro"
    bg = None
    bglist = None
    for n in range(start, end + 1):
        l = lines[n - 1].rstrip()
        c = clean(l)
        c = re.sub(r"^(#+\s*|\*\s+|>\s+)+", "", c)
        if n == start or not c or c == "---":
            continue
        if l.startswith("**แนวทาง:**"):
            continue
        # section switches
        low = c.lower()
        if re.match(r"^(#+\s*)?\*\*Benefits\*\*", l) or c == "Benefits":
            state = "benefits"; continue
        if re.match(r"^#+\s*\*\*Traits\*\*", l) or c == "Traits":
            state = "traits"; continue
        if c.rstrip(":") in ("Hindrances", "อุปสรรค (Hindrances)"):
            state = "hindrances"; continue
        if c == "Starter Skill":
            state = "starterSkills"; continue
        if re.match(r"^###\s*\*\*Special Childhood\*\*", l):
            state = "bg"; bglist = k["specialChildhood"]; bg = None; continue
        if re.match(r"^###\s*\*\*Special Adulthood\*\*", l):
            state = "bg"; bglist = k["specialAdulthood"]; bg = None; continue
        if re.match(r"^###\s*\*\*Childhood\*\*", l):
            state = "bg"; bglist = k["childhood"]; bg = None; continue
        if re.match(r"^###\s*\*\*Adulthood\*\*", l):
            state = "bg"; bglist = k["adulthood"]; bg = None; continue
        if state == "bg":
            m = re.match(r"^(?:#+\s*)?\*\*([A-Z]+\d+)\*\*\s*$", l.strip())
            if m:
                bg = {"code": m.group(1), "name": "", "nameEn": "", "stats": {}, "text": []}
                bglist.append(bg); continue
            if bg is None:
                k["misc"].append(c); continue
            if not bg["name"]:
                nm = re.match(r"^(.*?)\s*\((.*?)\)\s*$", c)
                if nm:
                    bg["name"], bg["nameEn"] = nm.group(1).strip(), nm.group(2).strip()
                else:
                    bg["name"] = c
                continue
            if c.startswith("Raw Stats") or (not bg["stats"] and not bg["text"] and re.match(r"^[+-]?\d+\s*(STR|AGI|VIT|PER|INF|INT)", c)):
                if "ใดก็ได้" in c:
                    mm = re.search(r"([+-]?\d+)\s*ค่าพลังหลักใดก็ได้\s*(\d+)", c)
                    bg["statsChoice"] = {"each": int(mm.group(1)), "count": int(mm.group(2))} if mm else {"each": 1, "count": 4}
                    bg["statsNote"] = c.split(":",1)[-1].strip()
                else:
                    bg["stats"] = parse_stat_line(c)
                continue
            bg["text"].append(c.lstrip("> ").strip())
            continue
        # meta bullets
        if c.startswith("Raw Starter Stat"):
            st = parse_stat_line(c)
            k["extra"] = st.pop("Extra", 0)
            k["raw"] = st; state = "meta"; continue
        for key, field in [("อายุขัย", "age"), ("ขนาด", "size"), ("ความเร็ว", "speed"), ("ภาษา", "languages")]:
            if c.startswith(key):
                k[field] = c.split(":", 1)[1].strip() if ":" in c else c
                state = "meta"; break
        else:
            if state == "intro":
                k["intro"].append(c)
            elif state in ("benefits", "traits", "hindrances", "starterSkills"):
                item = c.lstrip("* ").strip()
                if l.lstrip().startswith("*") or not k[state]:
                    k[state].append(item)
                else:
                    k[state][-1] += " " + item
            else:
                k["misc"].append(c)
    # split "Name (En): desc" for benefits/traits/hindrances
    for sec in ("benefits", "traits", "hindrances"):
        out = []
        for it in k[sec]:
            m = re.match(r"^(.*?)\s*\((.*?)\)\s*:\s*(.*)$", it)
            if m:
                out.append({"name": m.group(1).strip(), "nameEn": m.group(2).strip(), "text": m.group(3).strip()})
            else:
                m2 = re.match(r"^(.*?):\s*(.*)$", it)
                out.append({"name": m2.group(1).strip() if m2 else it, "nameEn": "", "text": m2.group(2).strip() if m2 else ""})
        k[sec] = out
    ss = []
    for it in k["starterSkills"]:
        m = re.match(r"^\[(.*?)\]\s*(.*)$", it)
        cond, nm = (m.group(1), m.group(2)) if m else ("", it)
        ss.append({"condition": cond.strip(), "name": nm.strip()})
    k["starterSkills"] = ss
    for bl in ("childhood", "specialChildhood", "adulthood", "specialAdulthood"):
        for b in k[bl]:
            b["text"] = " ".join(b["text"]).strip()
    kins.append(k)

json.dump(kins, open("/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/kins.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for k in kins:
    print(k["id"], k["raw"], "X", k["extra"], "| B", len(k["benefits"]), "T", len(k["traits"]), "H", len(k["hindrances"]), "S", len(k["starterSkills"]),
          "| C", len(k["childhood"]), "CS", len(k["specialChildhood"]), "A", len(k["adulthood"]), "AS", len(k["specialAdulthood"]), "| arch", k["archetype"], "| misc", len(k["misc"]), "| intro", len(k["intro"]))
    for bl in ("childhood", "specialChildhood", "adulthood", "specialAdulthood"):
        for b in k[bl]:
            if not b["stats"] or not b["name"]:
                print("   !!", bl, b["code"], b["name"], b["stats"])
