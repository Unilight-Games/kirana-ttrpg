# -*- coding: utf-8 -*-
"""v1.27 (Non สั่ง 16 พ.ย. 2026): ใส่แม่แบบสัตว์และผู้คนจาก Fauna, Enemy & Companion ลง data.json เป็น DATA.bestiary (รันซ้ำได้)

  python3 tools/parse_bestiary.py "<Fauna, Enemy & Companion.md>" tools/bestiary.json
  python3 tools/splice_v127.py
  python3 tools/build.py

หมวดอื่นของ data.json ไม่ถูกแตะ"""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
B = json.load(open(os.path.join(HERE, "bestiary.json"), encoding="utf-8"))
for e in B["entries"]:
    e.pop("line", None)
D = json.load(open(os.path.join(HERE, "data.json"), encoding="utf-8"))
D["bestiary"] = B
json.dump(D, open(os.path.join(HERE, "data.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print("bestiary", len(B["entries"]), "รายการ ·", sum(1 for e in B["entries"] if e["type"] == "fauna"), "สัตว์ ·", sum(1 for e in B["entries"] if e["type"] == "humanoid"), "ผู้คน")
