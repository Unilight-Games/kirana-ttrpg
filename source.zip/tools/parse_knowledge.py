import re, json
SRC = "/mnt/user-data/uploads/Kirana Lore & TTRPG Data/Kirana TTRPG Data/Talent & Knowledge Proficiency.md"
lines = open(SRC, encoding="utf-8").read().split("\n")
def clean(s):
    s = s.replace("\\", "").replace("เเ", "แ")
    s = re.sub(r"\*\*", "", s)
    return re.sub(r"\s+", " ", s).strip()

KN_HDR = re.compile(r"^(?:#+\s*)?\*\*([A-Z][A-Za-z &]+?)\s+([ก-๙\s]+?)\s*\((\w+),\s*(\w+)\)\*\*\s*$")
knowledge = []
cur = None; lvl = None
for i, raw in enumerate(lines, 1):
    if i < 62: continue
    l = raw.rstrip()
    if not l.strip(): continue
    m = KN_HDR.match(l)
    if m:
        cur = {"id": m.group(1).strip().lower().replace(" & ", "-").replace(" ", "-"), "nameEn": m.group(1).strip(), "nameTh": m.group(2).strip(),
               "stats": [m.group(3), m.group(4)], "levels": {}}
        knowledge.append(cur); lvl = None; continue
    if cur is None: continue
    c = clean(l)
    ml = re.match(r"^(?:\*\s+)?Level\s+(\d)\s*:\s*(.*)$", c)
    if ml:
        lvl = ml.group(1)
        cur["levels"][lvl] = {"text": ml.group(2).strip(), "proficiencies": [], "profLabel": ""}
        continue
    if lvl is None: continue
    L = cur["levels"][lvl]
    if re.match(r"^(?:\*\s+)?เลือก", c):
        L["profLabel"] = c.lstrip("* ").rstrip(":"); continue
    mp = re.match(r"^\s*(?:\d+\.|\*)\s+\*\*(.+?)\s*:?\s*\*\*\s*:?\s*(.*)$", l)
    if mp:
        L["proficiencies"].append({"name": clean(mp.group(1)).rstrip(":").strip(), "text": clean(mp.group(2))})
        continue
    if L["proficiencies"]:
        L["proficiencies"][-1]["text"] += " " + c.lstrip("* ")
    else:
        L["text"] += " " + c.lstrip("* ")

json.dump(knowledge, open("/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/knowledge.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for k in knowledge:
    print(k["id"], k["stats"], {lv: (len(v["text"]), len(v["proficiencies"])) for lv, v in k["levels"].items()})
print(len(knowledge))
