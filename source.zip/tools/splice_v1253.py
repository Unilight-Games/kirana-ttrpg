#!/usr/bin/env python3
"""v1.25.3 (Non เคาะ 15 พ.ย. 2026): "Sorceries Resistance กันเฉพาะส่วนที่สวม" และ "เกราะหลักหักความเสียหายเวทด้วย"

ต่อท้ายคำอธิบายศัพท์ เกราะ (Armor) และ ป้องกัน (Resistance) ด้วยประโยคเดียวกับที่เพิ่มในไฟล์แกน Kirana Core System TTRPG (V.2).md
ใน tools/data.json กับ tools/glossary.json · ใช้กับไฟล์แกนด้วย: python3 tools/splice_v1253.py --rules <ไฟล์แกน>
ต้องรันหลัง splice_v1252.py · รันซ้ำได้: ข้อความที่ต่อแล้วจะถูกข้าม
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')
GLOSS = os.path.join(HERE, 'glossary.json')
SPEC = {
    'Armor': ('**เกราะ (Armor)**', 'และหัก 2 หน่วยเมื่อโดนความเสียหายชนิดอื่น',
              'เกราะหลักหักความเสียหายเวทด้วย (ความเสียหายที่ Sorceries Resistance ป้องกัน เช่น Fire Damage, Frost Damage) '
              'ส่วน Sorceries Resistance ที่อยู่ในวงเล็บของค่าเกราะกันเฉพาะส่วนที่สวม '
              'เช่น ใยอาคมอัมบราไลต์ Armor 1/4 (Sorceries Resistance) หักความเสียหายเวท 5 หน่วย และหักความเสียหายกายภาพ 1 หน่วย เฉพาะส่วนที่สวม'),
    'Resistance': ('**ป้องกัน (Resistance)**', 'ที่เสริมการป้องกันแบบจำเพาะ',
                   'ทั้งนี้ Sorceries Resistance ที่มากับค่าเกราะของเครื่องสวมใส่ (เขียนในวงเล็บ เช่น Armor 0/1 (Sorceries Resistance)) '
                   'กันเฉพาะส่วนที่สวม ดูหัวข้อ เกราะ (Armor)'),
}


def add_to(text, tail, add):
    if add in text:
        return text, False
    assert text.rstrip().endswith(tail), ('text tail changed', text[-80:])
    return text.rstrip() + ' ' + add, True


def rules(path):
    lines = open(path, encoding='utf-8').read().split('\n')
    n = 0
    for key, (head, tail, add) in SPEC.items():
        hit = [i for i, l in enumerate(lines) if l.startswith(head)]
        assert len(hit) == 1, (key, len(hit))
        lines[hit[0]], ch = add_to(lines[hit[0]], tail, add)
        n += ch
    open(path, 'w', encoding='utf-8').write('\n'.join(lines))
    print('splice_v1253 rules: changed', n)


def main():
    D = json.load(open(DATA, encoding='utf-8'))
    G = json.load(open(GLOSS, encoding='utf-8'))
    n = 0
    for key, (head, tail, add) in SPEC.items():
        D['glossary'][key]['text'], c1 = add_to(D['glossary'][key]['text'], tail, add)
        G[key]['text'], c2 = add_to(G[key]['text'], tail, add)
        n += c1 + c2
    json.dump(D, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    json.dump(G, open(GLOSS, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('splice_v1253: changed', n)


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--rules':
        rules(sys.argv[2])
    else:
        main()
