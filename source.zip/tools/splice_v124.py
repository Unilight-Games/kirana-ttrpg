#!/usr/bin/env python3
"""v1.24 (Non สั่ง 15 พ.ย. 2026): แก้ tools/data.json ตาม tools/traits_v124.json

1. Trait วงศา (traits, benefits, hindrances) ที่มีประโยคบรรยายนำหน้ากติกา ย้ายประโยคนั้นไปช่อง flavor
   เกณฑ์เดียวกับ v1.16 หัวข้อ 3: ย้ายเฉพาะประโยคที่ตัดออกแล้ว Effect ยังตัดสินได้ครบ
   คำเชื่อมตรงรอยต่อ (ทำให้, ด้วยเหตุนี้, ใน) ตัดทิ้งตามที่ระบุใน drop
2. พื้นหลังที่มี Trait (ชื่ออังกฤษ): ... ได้ช่อง traitEn, traitTh และ text เหลือเฉพาะ Effect
   ข้อความก่อนคำว่า Trait (เช่น เลือกได้เฉพาะเพศหญิง) ย้ายไปช่อง note
   Flavor ของ Trait พื้นหลังใช้เกณฑ์เดียวกับข้อ 1
3. พื้นหลังที่เขียนว่า ได้รับ Skill (ชื่อ) ได้ช่อง grantSkills ส่วน ได้รับ Kins Unique Skill ใด ๆ ของเผ่านี้ 1 Skill ได้ grantPick
4. คำพิมพ์ผิดที่เจอระหว่างทาง แก้ตาม typos (ชื่ออังกฤษของ Trait แก้ตาม enFix)

รันซ้ำได้: รายการที่แก้แล้วจะถูกข้ามหลังตรวจว่าตรงกับที่ควรเป็น
"""
import json, re, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')
MAP = os.path.join(HERE, 'traits_v124.json')
BG_GROUPS = ('childhood', 'specialChildhood', 'adulthood', 'specialAdulthood')
TRAIT_RX = re.compile(r'^(?P<pre>.*?)Trait\s*\((?P<inner>[^()]+)\)\s*:\s*', re.S)
GRANT_RX = re.compile(r'ได้รับ Skill \(([^()]+)\)')


def ws(s):
    return re.sub(r'\s+', ' ', s or '').strip()


def cut(text, fl, drop):
    """ตัด fl ออกจาก text แล้วต่อสองฝั่งเข้าหากัน คืน (effect, True) ถ้าเจอ"""
    t = ws(text)
    i = t.find(fl)
    if i < 0:
        return t, False
    before, after = t[:i].rstrip(), t[i + len(fl):].lstrip()
    if drop and after.startswith(drop):
        after = after[len(drop):].lstrip()
    return ws(before + ' ' + after), True


def main():
    D = json.load(open(DATA, encoding='utf-8'))
    M = json.load(open(MAP, encoding='utf-8'))
    typos = M.get('typos', [])
    stats = {'kinFlavor': 0, 'bgTrait': 0, 'bgFlavor': 0, 'grant': 0, 'typo': 0, 'skip': 0}
    seen_kin, seen_bg = set(), set()

    def fix_typos(s):
        for a, b in typos:
            if a in s:
                s = s.replace(a, b)
                stats['typo'] += 1
        return s

    for k in D['kins']:
        # ---- 1) Trait วงศา ----
        for grp in ('traits', 'benefits', 'hindrances'):
            for i, t in enumerate(k.get(grp) or []):
                t['text'] = fix_typos(t.get('text') or '')
                key = f"{k['id']}|{grp}|{i}"
                spec = M['kin'].get(key)
                if not spec:
                    continue
                seen_kin.add(key)
                if t.get('flavor'):
                    assert t['flavor'] == spec['flavor'], (key, t['flavor'])
                    stats['skip'] += 1
                    continue
                eff, ok = cut(t['text'], spec['flavor'], spec.get('drop'))
                assert ok, ('kin flavor not found', key, t['text'][:80])
                assert eff, ('kin effect empty', key)
                t['flavor'], t['text'] = spec['flavor'], eff
                stats['kinFlavor'] += 1
        # ---- 2-3) พื้นหลัง ----
        for grp in BG_GROUPS:
            for b in k.get(grp) or []:
                key = f"{k['id']}|{b['code']}"
                b['text'] = fix_typos(b.get('text') or '')
                grants = GRANT_RX.findall(b['text'])
                if grants and not b.get('traitEn'):
                    b['grantSkills'] = grants
                    stats['grant'] += 1
                if key in M.get('grantPick', {}):
                    b['grantPick'] = M['grantPick'][key]
                    stats['grant'] += 1
                spec = M['bg'].get(key)
                if not spec:
                    continue
                seen_bg.add(key)
                if b.get('traitEn'):
                    assert b['traitTh'] == spec['th'], key
                    stats['skip'] += 1
                    continue
                m = TRAIT_RX.match(b['text'])
                assert m, ('no Trait label', key, b['text'][:80])
                inner = ws(m.group('inner').replace('\\-', '-'))
                th0 = None
                if ' - ' in inner:  # ท้าทายจ่าฝูง - Alpha's Challenge
                    th0, inner = [x.strip() for x in inner.split(' - ', 1)]
                en = M.get('enFix', {}).get(inner, inner)
                if th0:
                    assert th0 == spec['th'], (key, th0, spec['th'])
                pre = ws(m.group('pre'))
                eff = ws(b['text'][m.end():])
                if spec.get('flavor'):
                    eff, ok = cut(eff, spec['flavor'], spec.get('drop'))
                    assert ok, ('bg flavor not found', key, eff[:80])
                    b['flavor'] = spec['flavor']
                    stats['bgFlavor'] += 1
                assert eff, ('bg effect empty', key)
                b['traitTh'], b['traitEn'], b['text'] = spec['th'], en, eff
                if pre:
                    b['note'] = pre
                stats['bgTrait'] += 1

    miss_k = set(M['kin']) - seen_kin
    miss_b = set(M['bg']) - seen_bg
    assert not miss_k, ('kin keys not in data', miss_k)
    assert not miss_b, ('bg keys not in data', miss_b)
    # ทุกพื้นหลังที่ยังขึ้นต้นด้วย Trait ( ต้องได้ชื่อแล้ว
    left = [f"{k['id']}|{b['code']}" for k in D['kins'] for g in BG_GROUPS for b in (k.get(g) or []) if 'Trait (' in (b.get('text') or '')]
    assert not left, ('Trait label left in text', left)
    # ชื่อไทยของ Trait พื้นหลังห้ามซ้ำกันเอง
    names = [v['th'] for v in M['bg'].values()]
    dup = sorted({n for n in names if names.count(n) > 1})
    assert not dup, ('duplicate Thai trait names', dup)
    json.dump(D, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print('splice_v124:', stats)


if __name__ == '__main__':
    main()
