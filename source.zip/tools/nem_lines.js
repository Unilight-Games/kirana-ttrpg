#!/usr/bin/env node
'use strict';
/* ===== คำพูดของเนเมสไซอาร์: ดึงออกจากซอร์สเป็นตาราง =====
 * อ่าน src/tutorial.js, src/coach.js, src/main.js แล้วเก็บทุกข้อความที่ขึ้นในกล่องคำพูดของนาง
 * ออกมาเป็นแถวที่มี ID คงที่ และตรวจสองอย่างทุกครั้งที่รัน
 *   1) ครบ  ข้อความภาษาไทยทุกชิ้นใน coachCompute ต้องเป็นแถว หรืออยู่ในรายการที่ยกเว้นไว้ชัดเจน
 *   2) ตรง  ทุกแถวประกอบกลับเป็นซอร์สเดิมได้ตรงทุกตัวอักษร (ฐานของการนำข้อความที่แก้แล้วกลับเข้าเว็บ)
 * ใช้: node tools/nem_lines.js --out <โฟลเดอร์> [--notes <ไฟล์ json>] [--debug]   ได้ nem_lines.json และ nem_lines.csv
 *      node tools/nem_lines.js --apply <ไฟล์ json ของ [{id, text?, mood?}]>   เขียนข้อความและสีหน้าที่แก้กลับเข้า src
 * ต้องมี acorn (npm i acorn) */
const fs = require('fs'), path = require('path');
function loadAcorn(){ for (const p of ['acorn', '/opt/npm-tools/node_modules/acorn', '/opt/node-tools/node_modules/acorn']){ try { return require(p); } catch (e){} } throw new Error('ต้องมี acorn: npm i acorn'); }
const acorn = loadAcorn();
const ROOT = path.resolve(__dirname, '..');
const argv = process.argv.slice(2);
const outDir = argv.includes('--out') ? argv[argv.indexOf('--out') + 1] : process.cwd();
const FILES = { tutorial: 'tutorial.js', coach: 'coach.js', main: 'main.js', figures: 'figures.js' };
const SRC = {}, AST = {};
for (const [k, f] of Object.entries(FILES)){ SRC[k] = fs.readFileSync(path.join(ROOT, 'src', f), 'utf8'); AST[k] = acorn.parse(SRC[k], { ecmaVersion: 'latest', sourceType: 'script' }); }
const DATA = JSON.parse(fs.readFileSync(path.join(ROOT, 'tools', 'data.json'), 'utf8'));
const TH = /[฀-๿]/;
const fail = (m) => { console.error('ผิดพลาด: ' + m); process.exit(1); };
const must = (c, m) => { if (!c) fail(m); };
function walk(n, fn, anc){ anc = anc || []; if (!n || typeof n.type !== 'string') return; fn(n, anc); const next = anc.concat([n]); for (const k of Object.keys(n)){ if (k === 'type' || k === 'start' || k === 'end') continue; const v = n[k]; if (Array.isArray(v)){ for (const c of v) walk(c, fn, next); } else if (v && typeof v.type === 'string') walk(v, fn, next); } }
function topConst(file, name){ for (const n of AST[file].body) if (n.type === 'VariableDeclaration') for (const d of n.declarations) if (d.id.name === name) return d.init; fail(`ไม่พบ const ${name} ใน ${FILES[file]}`); }
function topFn(file, name){ const n = AST[file].body.find(x => x.type === 'FunctionDeclaration' && x.id.name === name); must(n, `ไม่พบ function ${name} ใน ${FILES[file]}`); return n; }
const keyOf = p => p.key.type === 'Identifier' ? p.key.name : p.key.value;
const prop = (obj, k) => obj.properties.find(p => keyOf(p) === k);
const isStr = n => !!n && n.type === 'Literal' && typeof n.value === 'string';
const srcOf = (file, n) => SRC[file].slice(n.start, n.end);
const evalLit = (file, n) => new Function('return ' + srcOf(file, n))();

/* ---------- สีหน้า ---------- */
const MOODS = { smile: 'ยิ้ม', explain: 'อธิบาย', ask: 'ถาม', think: 'ครุ่นคิด', smirk: 'ยิ้มเจ้าเล่ห์', guilty: 'ยิ้มแหย', shush: 'จุ๊ปาก', surprise: 'ตกใจ', panic: 'ลนลาน', mad: 'โกรธ' };
const moodLabel = m => m ? `${MOODS[m]} (${m})` : '';
const NEM = evalLit('tutorial', topConst('tutorial', 'NEM'));
must(JSON.stringify(NEM.moods.slice().sort()) === JSON.stringify(Object.keys(MOODS).sort()), 'รายการสีหน้าใน NEM.moods ไม่ตรงกับที่สคริปต์รู้จัก');

/* ---------- แถว ---------- */
const rows = [];
function splitWs(v){ const lead = /^\s*/.exec(v)[0]; const rest = v.slice(lead.length); const trail = /\s*$/.exec(rest)[0]; return { lead, trail, text: rest.slice(0, rest.length - trail.length) }; }
function strRow(file, node, meta){
  must(isStr(node), `${meta.id}: ไม่ใช่สตริง`);
  const w = splitWs(node.value);
  const r = Object.assign({ file: FILES[file], start: node.start, end: node.end, type: 'str', quote: SRC[file][node.start], lead: w.lead, trail: w.trail, text: w.text, ph: [], mood: '', note: '' }, meta);
  rows.push(r); return r;
}
function tplRow(file, node, meta, nameOf){
  must(node.type === 'TemplateLiteral', `${meta.id}: ไม่ใช่เทมเพลต`);
  const ph = []; let text = '';
  node.quasis.forEach((q, i) => {
    must(!/[{}]/.test(q.value.cooked), `${meta.id}: มีปีกกาอยู่ในข้อความเดิม`);
    text += q.value.cooked;
    if (i < node.expressions.length){ const e = node.expressions[i]; const p = nameOf(e, srcOf(file, e)); must(!/[{}]/.test(p.name), `${meta.id}: ชื่อ ${p.name} มีปีกกา`);
      const dup = ph.find(x => x.name === p.name); if (dup) must(dup.src === p.src, `${meta.id}: ชื่อ {${p.name}} ชี้ไปสองนิพจน์`); else ph.push(p);
      text += '{' + p.name + '}'; }
  });
  const w = splitWs(text);
  const r = Object.assign({ file: FILES[file], start: node.start, end: node.end, type: 'tpl', lead: w.lead, trail: w.trail, text: w.text, ph, mood: '', note: '' }, meta);
  rows.push(r); return r;
}
/* ประกอบข้อความในตารางกลับเป็นลิเทอรัลในซอร์ส */
function render(r, text){
  const body = r.lead + text + r.trail;
  if (r.type === 'str'){ const q = r.quote; return q + body.replace(/\\/g, '\\\\').split(q).join('\\' + q).replace(/\n/g, '\\n') + q; }
  const esc = s => s.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
  let out = '', last = 0, m; const re = /\{([^{}]+)\}/g;
  while ((m = re.exec(body))){ const p = r.ph.find(x => x.name === m[1]); must(p, `${r.id}: ไม่รู้จัก {${m[1]}}`); out += esc(body.slice(last, m.index)) + '${' + p.src + '}'; last = re.lastIndex; }
  return '`' + out + esc(body.slice(last)) + '`';
}

/* ---------- 1) ป้ายชื่อ ---------- */
{ const o = topConst('tutorial', 'NEM');
  strRow('tutorial', prop(o, 'name').value, { id: 'N-name', group: 'ป้ายชื่อ', kind: 'ป้ายชื่อ', where: 'ป้ายชื่อบนกล่องคำพูดทุกแห่ง · ชื่อ', note: 'บรรทัด H-1 กับ T-welcome-02 และปุ่มบนหน้าแรกก็เอ่ยชื่อนี้ด้วย' });
  strRow('tutorial', prop(o, 'title').value, { id: 'N-title', group: 'ป้ายชื่อ', kind: 'ป้ายชื่อ', where: 'ป้ายชื่อบนกล่องคำพูดทุกแห่ง · ฉายาที่ต่อท้ายชื่อ', note: 'บรรทัด T-welcome-02 ก็เอ่ยฉายานี้ด้วย' }); }

/* ---------- 2) หน้าแรก ---------- */
{ const found = [];
  walk(topFn('main', 'renderHome'), (n) => { if (n.type === 'CallExpression' && n.callee.type === 'Identifier' && n.callee.name === 'T' && n.arguments.length === 1 && isStr(n.arguments[0])) found.push(n.arguments[0]); });
  must(found.length === 2, `หน้าแรกควรมีคำพูดสองย่อหน้า แต่พบ ${found.length}`);
  found.forEach((n, i) => strRow('main', n, { id: `H-${i + 1}`, group: 'หน้าแรก', kind: 'คำพูด', where: `หน้าแรก · กล่องคำพูดใต้ภาพเปิด ย่อหน้า ${i + 1} จาก 2`, mood: i === 0 ? 'smile' : '', note: i === 0 ? 'สีหน้านี้เป็นของภาพเปิดหน้าแรกทั้งกล่อง' : '' })); }

/* ---------- 3) สอนเล่น ---------- */
const FIG_TITLE = {};
for (const p of topConst('figures', 'FIGS').properties){ let title = null; walk(p.value, (n) => { if (title === null && n.type === 'CallExpression' && n.callee.type === 'Identifier' && n.callee.name === 'figTitle'){ const a = n.arguments[0]; title = isStr(a) ? a.value : (a.type === 'LogicalExpression' && isStr(a.right) ? a.right.value : ''); } }); FIG_TITLE[keyOf(p)] = title || ''; }
function figText(spec){ if (spec == null) return 'ไม่มีภาพประกอบข้างคำพูด'; const p = typeof spec === 'string' ? { t: spec } : spec; must(Object.prototype.hasOwnProperty.call(FIG_TITLE, p.t), `ไม่รู้จักภาพประกอบ ${p.t}`); let t = (p.t === 'grid' && p.title) ? p.title : FIG_TITLE[p.t]; if (p.t === 'steps' && p.cur != null) t += ` (เน้นขั้นที่ ${p.cur + 1})`; return 'ภาพข้างคำพูด: ' + t; }
const HASH = { '#chars': 'ตัวละครของฉัน', '#wizard': 'วิซาร์ดสร้างตัวละคร', '#table': 'โต๊ะเล่น' };
const lessonsNode = topConst('tutorial', 'LESSONS');
const LESSONS = evalLit('tutorial', lessonsNode);
let tutorLines = 0;
LESSONS.forEach((L, li) => {
  const on = lessonsNode.elements[li]; const n = li + 1; const nn = String(n).padStart(2, '0'); const group = `สอนเล่น ${nn} ${L.nav}`;
  strRow('tutorial', prop(on, 'title').value, { id: `T-${L.id}-title`, group, kind: 'ชื่อบท', where: `บท ${n} · ชื่อบท เป็นหัวเรื่องเหนือฉาก` });
  strRow('tutorial', prop(on, 'nav').value, { id: `T-${L.id}-nav`, group, kind: 'ชื่อในสารบัญ', where: `บท ${n} · ชื่อในสารบัญบทเรียน` });
  const ln = prop(on, 'lines').value.elements; must(ln.length === L.lines.length, `บท ${L.id}: จำนวนบรรทัดไม่ตรง`);
  const figFor = (i) => { for (let k = i; k >= 0; k--){ const f = L.lines[k][2]; if (f !== undefined) return f; } return null; };
  ln.forEach((el, j) => { const [moodN, textN] = el.elements; must(isStr(moodN) && MOODS[moodN.value], `บท ${L.id} บรรทัด ${j + 1}: สีหน้าไม่รู้จัก`);
    strRow('tutorial', textN, { id: `T-${L.id}-${String(j + 1).padStart(2, '0')}`, group, kind: 'คำพูด', where: `บท ${n} ${L.nav} · บรรทัด ${j + 1} จาก ${ln.length}`, mood: moodN.value, moodAt: [moodN.start, moodN.end], note: figText(figFor(j)) }); tutorLines++; });
  if (L.tryLabel){ must(HASH[L.tryHash], `บท ${L.id}: ไม่รู้จักปลายทาง ${L.tryHash}`);
    strRow('tutorial', prop(on, 'tryLabel').value, { id: `T-${L.id}-try`, group, kind: 'ปุ่มท้ายบท', where: `บท ${n} · ปุ่มท้ายบท ขึ้นต่อจากคำว่า ลองทำ:`, note: `กดแล้วไปหน้า${HASH[L.tryHash]}${L.tryNew ? ' โดยเริ่มตัวละครใหม่' : ''}` }); }
});

/* ---------- 4) โค้ชในวิซาร์ด ---------- */
const STEP = ['วงศา', 'พื้นหลัง', 'บุคลิก', 'Extra', 'พรสวรรค์', 'คำนวณ', 'รายละเอียด', 'ชุดเริ่มต้น'];
const stepName = n => n ? `ขั้น ${n} ${STEP[n - 1]}` : 'ทุกขั้น';
const A = (id, step, when, mood, extra) => Object.assign({ id, step, when, mood: mood || '', kind: 'คำพูด' }, extra || {});
const PICK = { kind: 'ตัวเลือกสุ่ม' }, TAIL = { kind: 'ส่วนต่อท้าย' }, INS = { kind: 'ส่วนแทรก' };
/* เรียงตามลำดับที่ข้อความภาษาไทยปรากฏใน coachCompute ทุกชิ้นต้องมีคู่ในรายการนี้ */
const ANN = [
  A('W1-01a', 1, 'ยังไม่ได้เลือกวงศา', 'ask', PICK),
  A('W1-01b', 1, 'ยังไม่ได้เลือกวงศา', 'ask', PICK),
  A('W1-01c', 1, 'ยังไม่ได้เลือกวงศา', 'ask', PICK),
  A('W1-02', 1, 'เลือกวงศาแล้ว แต่วงศานั้นไม่มีบรรทัดสายการเล่นของตัวเอง', '', { note: 'บรรทัดสำรอง ตอนนี้ทั้งสิบสองวงศามีบรรทัดสายการเล่นครบ บรรทัดนี้จึงยังไม่เคยขึ้นจริง' }),
  A('W1-03', 1, 'วงศาที่เลือกมีขนาดตัวให้เลือกมากกว่าหนึ่งแบบ', ''),
  { skip: ' หรือ ' },
  A('W1-04', 1, 'เลือก Lunaryn และเลือกวงศาที่จะยืมใน Descendants of Evolver แล้ว', 'smirk'),
  A('W2-01', 2, 'ยังไม่ได้เลือกวงศา', 'guilty'),
  A('W2-02', 2, 'ยังไม่ได้เลือกพื้นหลังสักใบ', 'explain', { note: 'พูดจบแล้วต่อด้วยบรรทัดเรื่องราวของวงศาที่เลือก คือแถว K ที่ลงท้ายด้วย story' }),
  A('W2-03', 2, 'เลือกพื้นหลังแล้ว พูดใบละหนึ่งครั้ง วัยเด็กก่อนแล้วตามด้วยวัยผู้ใหญ่', 'explain', { moodFrom: 12, note: 'สีหน้านี้ใช้ตอนพูดถึงใบวัยเด็ก ตอนพูดถึงใบวัยผู้ใหญ่ใช้สีหน้าที่ค้างอยู่' }),
  A('W2-03a', 2, 'ต่อท้าย W2-03 เมื่อแต้มจากใบนั้นพาค่าพลังไปลงเลขคู่', '', TAIL),
  A('W2-03b', 2, 'ต่อท้าย W2-03 เมื่อไม่มีค่าไหนลงเลขคู่', '', TAIL),
  { skip: 'วัยเด็ก' },
  { skip: 'วัยผู้ใหญ่' },
  A('W2-04', 2, 'เลือกครบสองใบ และสองใบให้แต้มค่าพลังตัวเดียวกัน', 'smirk'),
  A('W2-05', 2, 'เลือกครบสองใบ และสองใบให้แต้มคนละค่า', 'think'),
  A('W2-06a', 2, 'เลือกครบสองใบ', 'ask', PICK),
  A('W2-06b', 2, 'เลือกครบสองใบ', 'ask', PICK),
  A('W2-06c', 2, 'เลือกครบสองใบ', 'ask', PICK),
  A('W2-07', 2, 'เลือกครบสองใบ แต่ใบวัยเด็กให้เลือกค่าพลังเองและยังเลือกไม่ครบ', 'panic'),
  A('W2-08', 2, 'เลือกวัยเด็กแล้ว ยังไม่ได้เลือกวัยผู้ใหญ่', 'ask'),
  A('W2-09', 2, 'เลือกวัยผู้ใหญ่แล้ว ยังไม่ได้เลือกวัยเด็ก', 'ask'),
  A('W3-01a', 3, 'ยังไม่ได้แจกค่าบุคลิกภาพเลยสักคู่', 'ask', PICK),
  A('W3-01b', 3, 'ยังไม่ได้แจกค่าบุคลิกภาพเลยสักคู่', 'ask', PICK),
  A('W3-01c', 3, 'ยังไม่ได้แจกค่าบุคลิกภาพเลยสักคู่', 'ask', PICK),
  A('W3-02', 3, 'แจกไปบ้างแล้ว แต่ยังไม่ครบหกคู่', ''),
  A('W3-03', 3, 'แจกครบหกคู่ และเลือกวงศาไว้แล้ว', 'smile'),
  A('W3-03a', 3, 'แทรกใน W3-03 เมื่อมีบทบาทอันดับสอง', '', INS),
  { skip: ' หรือ ' },
  A('W3-03b', 3, 'แทรกใน W3-03 เมื่อมีชุดเริ่มต้นที่เข้ากับบทบาท', '', INS),
  A('W3-04', 3, 'แจกครบแล้ว ได้เลือดเย็น 2 ขึ้นไป และรักตัวเอง 2 ขึ้นไป', 'shush'),
  A('W3-05', 3, 'แจกครบแล้ว ได้กล้าหาญ 2 ขึ้นไป และเห็นแก่ส่วนรวม 2 ขึ้นไป', 'guilty'),
  A('W3-06', 3, 'แจกครบแล้ว ได้ระแวดระวัง 2 ขึ้นไป และตรรกะ 2 ขึ้นไป', 'smirk'),
  A('W3-07', 3, 'แจกครบแล้ว ได้ไร้ระเบียบ 2 ขึ้นไป และสัญชาตญาณ 2 ขึ้นไป', 'surprise'),
  A('W4-01', 4, 'ยังไม่ได้เลือกวงศา', 'guilty'),
  A('W4-02', 4, 'ยังมีแต้ม Extra เหลือ', 'explain'),
  A('W4-02a', 4, 'ต่อท้าย W4-02 เมื่อมีค่าพลังที่ขาดอีกแต้มเดียวจะถึงเลขคู่', '', TAIL),
  A('W4-02b', 4, 'ต่อท้าย W4-02 เมื่อทุกค่าเป็นเลขคู่อยู่แล้ว', '', TAIL),
  A('W4-03', 4, 'ยังมีแต้มเหลือ และแจกบุคลิกภาพครบแล้ว', ''),
  A('W4-04', 4, 'ยังมีแต้มเหลือ และค่าพลังที่ต่ำสุดมี Mod ตั้งแต่ −2 ลงไป', 'think'),
  A('W4-05', 4, 'ใช้แต้ม Extra เกินที่มี', 'panic'),
  { skip: ' และ ' },
  A('W4-06', 4, 'ใช้แต้มครบพอดี', 'smile'),
  A('W4-07', 4, 'ใช้แต้มครบพอดี และยังมีค่าพลังค้างที่เลขคี่', 'smirk'),
  A('W4-08', 4, 'ใช้แต้มครบพอดี และทุกค่าลงเลขคู่', ''),
  A('W4-09', 4, 'ใช้แต้มครบพอดี และ HP ไม่เกิน 7', 'panic'),
  A('W4-10', 4, 'ใช้แต้มครบพอดี และ Sanity ไม่เกิน 4', 'shush'),
  A('W5-01', 5, 'ยังไม่ได้เลือก Talent', 'explain'),
  { skip: ' และ ' },
  A('W5-01a', 5, 'แทรกใน W5-01 เมื่อแจกบุคลิกภาพครบและมีสาย Talent ที่เข้ากับนิสัย', '', INS),
  { skip: ' หรือ ' },
  A('W5-02', 5, 'ยังไม่ได้เลือก Talent พูดต่อจาก W5-01', 'ask'),
  A('W5-03', 5, 'เลือก Talent แล้ว แต่ยังเลือกของในขั้นนี้ไม่ครบ', 'ask', { note: 'ข้อความที่มาเติมเป็นคำเตือนของวิซาร์ดเอง ใช้ร่วมกับปุ่มไปขั้นถัดไป จึงไม่อยู่ในตารางนี้' }),
  A('W5-04', 5, 'เลือก Talent แล้ว และเลือกของในขั้นนี้ครบ', 'smile'),
  { skip: ' และอื่น ๆ' },
  A('W6-01', 6, 'ขึ้นทุกครั้งที่มาถึงขั้นนี้', 'explain'),
  A('W6-02', 6, 'HP ไม่เกิน 8', 'guilty'),
  A('W6-03', 6, 'HP ตั้งแต่ 14 ขึ้นไป', 'smirk'),
  A('W6-04', 6, 'INF Mod ติดลบ', 'think'),
  A('W6-05', 6, 'Toughness ตั้งแต่ 4 ขึ้นไป', ''),
  A('W6-06', 6, 'แบกได้ไม่ถึง 24 กิโลกรัม', 'panic'),
  A('W7-01a', 7, 'ยังไม่ได้ตั้งชื่อ', 'ask', PICK),
  A('W7-01b', 7, 'ยังไม่ได้ตั้งชื่อ', 'ask', PICK),
  A('W7-01c', 7, 'ยังไม่ได้ตั้งชื่อ', 'ask', PICK),
  A('W7-02a', 7, 'ตั้งชื่อแล้ว', 'smile', PICK),
  A('W7-02b', 7, 'ตั้งชื่อแล้ว', 'smile', PICK),
  A('W7-02c', 7, 'ตั้งชื่อแล้ว', 'smile', PICK),
  A('W7-03', 7, 'ยังไม่ได้เขียนเรื่องราว และเลือกพื้นหลังครบสองใบแล้ว', 'think'),
  A('W7-03a', 7, 'แทรกใน W7-03 เมื่อวงศามีข้อเสีย (Hindrance)', '', INS),
  A('W7-04', 7, 'ช่องหวาดกลัวยังว่าง', ''),
  A('W7-05', 7, 'กรอกช่องเอกลักษณ์แล้ว', 'smirk'),
  A('W8-01', 8, 'ยังไม่ได้เลือกชุดเริ่มต้น', 'explain'),
  A('W8-01a', 8, 'แทรกใน W8-01 เมื่อแจกบุคลิกภาพครบและมีชุดที่เข้ากับนิสัย', '', INS),
  A('W8-02', 8, 'ยังไม่ได้เลือกชุด และแบกได้ไม่ถึง 30 กิโลกรัม', 'think'),
  A('W8-03', 8, 'เลือกชุดแล้ว และสายของชุดตรงกับบทบาทที่อ่านได้จากนิสัย', 'smile', { moodBranch: 0 }),
  A('W8-04', 8, 'เลือกชุดแล้ว และสายของชุดไม่ตรงกับนิสัย หรือยังแจกบุคลิกภาพไม่ครบ', 'think', { moodBranch: 1 }),
  A('W8-04a', 8, 'แทรกใน W8-04 เมื่อแจกบุคลิกภาพครบแล้ว', '', INS),
  A('W8-05', 8, 'เลือกชุดแล้ว และน้ำหนักชุดรวมชุดยังชีพเกินที่แบกได้', 'panic'),
  A('W8-06', 8, 'เลือกชุดแล้ว และแบกไหว', ''),
  A('W8-07', 8, 'ชุดที่เลือกมีรายชื่อพื้นหลังที่เข้าคู่กัน', 'ask'),
  A('W8-08', 8, 'เลือกชุดแล้ว เป็นบรรทัดปิดท้ายของขั้น', 'smile'),
  A('W0-01', 0, 'บรรทัดสำรอง ใช้เมื่อขั้นนั้นไม่มีอะไรให้พูด', 'smile'),
];
/* ชื่อที่ใช้แทนค่าที่เว็บเติมให้ตอนพูด: [นิพจน์ในซอร์ส, ชื่อในปีกกา, คำอธิบาย] */
const PH = [
  ["hi[0]", 'ค่าสูงสุด', 'ชื่อค่าพลังที่สูงที่สุดของวงศา เช่น STR'],
  ["kin.raw[hi[0]]", 'เลขค่าสูงสุด', 'ค่าดิบของค่านั้น เช่น 14'],
  ["lo", 'ค่าต่ำสุด', 'ชื่อค่าพลังที่ต่ำที่สุดของวงศา เช่น INF'],
  ["kin.raw[lo]", 'เลขค่าต่ำสุด', 'ค่าดิบของค่านั้น เช่น 6'],
  ["kin.sizes.join(' หรือ ')", 'ขนาดที่เลือกได้', 'รายชื่อขนาด คั่นด้วยคำว่า หรือ เช่น Small หรือ Medium'],
  ["KIN[c.evolver.kin] ? KIN[c.evolver.kin].name : c.evolver.kin", 'วงศาที่ยืม', 'ชื่อวงศาที่เลือกยืม เช่น Nightkin'],
  ["label", 'ช่วงวัย', 'คำว่า วัยเด็ก หรือ วัยผู้ใหญ่'],
  ["b.name", 'ชื่อพื้นหลัง', 'ชื่อใบพื้นหลังที่เลือก'],
  ["txt", 'แต้มที่ได้', 'แต้มค่าพลังจากใบนั้น เช่น +2 STR +1 VIT'],
  ["hits.join(' ')", 'ค่าที่ลงเลขคู่', 'ชื่อค่าพลังที่ลงเลขคู่ เช่น STR VIT'],
  ["both.join(' ')", 'ค่าที่ซ้อนกัน', 'ชื่อค่าพลังที่ทั้งสองใบให้ เช่น AGI'],
  ["ch.name", 'พื้นหลังวัยเด็ก', 'ชื่อใบวัยเด็กที่เลือก'],
  ["ad.name", 'พื้นหลังวัยผู้ใหญ่', 'ชื่อใบวัยผู้ใหญ่ที่เลือก'],
  ["ch.statsChoice.count", 'จำนวนค่าที่ต้องเลือก', 'ตัวเลข เช่น 2'],
  ["bs.left.join(', ')", 'ค่าที่ยังไม่ได้แจก', 'ตัวเลขบุคลิกภาพที่ยังเหลือ เช่น 2, 1, 0'],
  ["bs.left.length", 'จำนวนคู่ที่เหลือ', 'ตัวเลข เช่น 3'],
  ["t.th", 'บทบาทหลัก', 'ชื่อไทยของบทบาทที่เข้ากับนิสัยที่สุด เช่น แทงค์'],
  ["t2.th", 'บทบาทรอง', 'ชื่อไทยของบทบาทอันดับสอง เช่น ไฟท์เตอร์'],
  ["t.talent.map(x=>x==='EDU'?'Educated':x).join(' หรือ ')", 'สายที่เข้าทาง', 'ชื่อสาย Talent ของบทบาทหลัก คั่นด้วยคำว่า หรือ เช่น VIT หรือ STR'],
  ["prof.sets.join(', ')", 'ชุดที่เข้ากับนิสัย', 'ชื่อชุดเริ่มต้นไม่เกินสามชุด เช่น The Vanguard, The Priest'],
  ["d.extraLeft", 'แต้มเหลือ', 'จำนวนแต้ม Extra ที่ยังไม่ได้แจก'],
  ["nearMod.map(s=>`${s} ${d.raw[s]}`).join(' · ')", 'ค่าที่ขาดอีกแต้มเดียว', 'ค่าพลังที่เป็นเลขคี่ เช่น STR 13 · PER 11'],
  ["prof.top[0].id", 'บทบาทหลักอังกฤษ', 'ชื่ออังกฤษของบทบาทหลัก เช่น Tank'],
  ["weakest", 'ค่าที่อ่อนสุด', 'ชื่อค่าพลังที่ต่ำที่สุดของตัวละคร เช่น INF'],
  ["d.raw[weakest]", 'เลขค่าที่อ่อนสุด', 'ค่าดิบของค่านั้น เช่น 6'],
  ["signed(d.mod[weakest])", 'Mod ค่าที่อ่อนสุด', 'เช่น -2'],
  ["-d.extraLeft", 'แต้มที่ใช้เกิน', 'ตัวเลข เช่น 2'],
  ["hiList", 'ค่าที่นำ', 'ชื่อค่าพลังที่ Mod สูงสุด คั่นด้วยคำว่า และ เช่น STR และ VIT'],
  ["signed(d.mod[d.highest[0]])", 'Mod ค่าที่นำ', 'เช่น +2'],
  ["oddStats.map(s=>`${s} ${d.raw[s]}`).join(' · ')", 'ค่าที่ค้างเลขคี่', 'เช่น AGI 11 · INT 9'],
  ["d.hp", 'HP', 'HP ของตัวละคร'],
  ["d.mp", 'MP', 'MP ของตัวละคร'],
  ["d.sanity", 'Sanity', 'Sanity ของตัวละคร'],
  ["d.toughness", 'Toughness', 'Toughness ต่ออวัยวะ'],
  ["d.capacity", 'น้ำหนักที่แบกได้', 'ตัวเลขกิโลกรัม เช่น 36'],
  ["d.highest.join(' และ ')", 'ค่าที่นำ', 'ชื่อค่าพลังที่ Mod สูงสุด คั่นด้วยคำว่า และ เช่น STR และ VIT'],
  ["prof.talentHint.map(t=>t==='EDU'?'Educated':t).join(' หรือ ')", 'สายที่แนะนำ', 'ชื่อสาย Talent ที่เข้ากับนิสัย คั่นด้วยคำว่า หรือ เช่น VIT หรือ Educated'],
  ["blocker", 'สิ่งที่ยังขาด', 'คำเตือนของวิซาร์ด เช่น ขั้น 2 ของ Talent: เลือกทักษะให้ครบ 2'],
  ["sk.length", 'จำนวนทักษะ', 'ตัวเลข เช่น 5'],
  ["sk.length ? ` ${sk.slice(0,4).map(skTh).join(', ')}${sk.length>4?' และอื่น ๆ':''}` : ''", 'รายชื่อทักษะ', 'ชื่อไทยของทักษะสี่อย่างแรก คั่นด้วยจุลภาค ถ้ามีเกินสี่จะต่อท้ายว่า และอื่น ๆ เว็บเว้นวรรคหน้ารายชื่อให้เอง'],
  ["c.name.trim()", 'ชื่อตัวละคร', 'ชื่อที่ผู้เล่นตั้ง'],
  ["kinT.hindrances[0].name", 'ข้อเสียแรกของวงศา', 'ชื่อ Hindrance ตัวแรกของวงศา เช่น วิถีแห่งเกียรติ'],
  ["set.nameEn", 'ชื่อชุด', 'ชื่ออังกฤษของชุดที่เลือก เช่น The Vanguard'],
  ["prof.top[0].th", 'บทบาทหลัก', 'ชื่อไทยของบทบาทที่เข้ากับนิสัยที่สุด เช่น แทงค์'],
  ["set.archetype", 'สายของชุด', 'เช่น Rogue / Skirmisher'],
  ["setWt", 'น้ำหนักชุด', 'ตัวเลขกิโลกรัม เช่น 8.3 (v1.22: น้ำหนักของทางเลือกที่เลือกจริง)'],
  ["set.backgrounds.split(',')[0].trim()", 'พื้นหลังที่เข้ากับชุด', 'ชื่อพื้นหลังแรกในรายการของชุด เช่น ผู้ปลดแอกทาส (Slave Liberator)'],
];
const PHMAP = new Map(PH.map(([s, name, desc]) => [s.replace(/\s+/g, ' '), { name, desc }]));

const fnNode = topFn('coach', 'coachCompute');
const entries = [];
walk(fnNode, (n, anc) => {
  const str = isStr(n), tpl = n.type === 'TemplateLiteral';
  if (!str && !tpl) return;
  const own = str ? n.value : n.quasis.map(q => q.value.cooked).join('');
  if (!TH.test(own)) return;
  const rev = anc.slice().reverse();
  const say = rev.find(a => a.type === 'CallExpression' && a.callee.type === 'Identifier' && a.callee.name === 'say');
  const parent = anc[anc.length - 1], grand = anc[anc.length - 2];
  const pick = parent && parent.type === 'ArrayExpression' && grand && grand.type === 'CallExpression' && grand.callee.name === 'coachPick' ? { i: parent.elements.indexOf(n), n: parent.elements.length } : null;
  const sw = rev.find(a => a.type === 'SwitchCase');
  entries.push({ node: n, str, say, pick, own, caseStep: sw ? sw.test.value : null });
});
must(entries.length === ANN.length, `coachCompute มีข้อความภาษาไทย ${entries.length} ชิ้น แต่คำอธิบายประกอบมี ${ANN.length} ชิ้น ซอร์สเปลี่ยนไปแล้ว ต้องปรับรายการ ANN`);
entries.forEach((e, i) => { e.ann = ANN[i]; });
entries.forEach((e, i) => {
  const a = e.ann;
  if (a.skip !== undefined){ must(e.str && e.node.value === a.skip, `ชิ้นที่ ${i}: คาดว่าเป็นคำเชื่อม "${a.skip}" แต่พบ "${e.own}"`); return; }
  must(a.step === 0 ? e.caseStep === null : e.caseStep === a.step - 1, `${a.id}: อยู่ผิดขั้น (ซอร์สอยู่ case ${e.caseStep})`);
  must(!!e.pick === (a.kind === 'ตัวเลือกสุ่ม'), `${a.id}: ชนิดตัวเลือกสุ่มไม่ตรงกับซอร์ส`);
  // สีหน้า: เทียบกับอาร์กิวเมนต์แรกของ say() ที่ครอบอยู่ ส่วนต่อท้ายกับส่วนแทรกไม่มีสีหน้าของตัวเอง
  if (a.kind === 'ส่วนต่อท้าย' || a.kind === 'ส่วนแทรก'){ must(a.mood === '', `${a.id}: ส่วนต่อท้ายและส่วนแทรกไม่มีสีหน้า`); return; }
  const sayOf = a.moodFrom !== undefined ? entries[a.moodFrom].say : e.say;
  must(sayOf, `${a.id}: ไม่ได้อยู่ใน say()`);
  const m0 = sayOf.arguments[0]; const ms = srcOf('coach', m0);
  if (isStr(m0)){ must(a.mood === m0.value, `${a.id}: สีหน้าในคำอธิบาย (${a.mood}) ไม่ตรงกับซอร์ส (${m0.value})`); a.moodAt = [m0.start, m0.end]; }
  else if (m0.type === 'Literal' && m0.value === null) must(a.mood === '', `${a.id}: ซอร์สใช้สีหน้าที่ค้างอยู่ แต่คำอธิบายใส่ ${a.mood}`);
  else if (m0.type === 'ConditionalExpression' && a.moodBranch !== undefined){ const b = a.moodBranch === 0 ? m0.consequent : m0.alternate; must(isStr(b) && b.value === a.mood, `${a.id}: สีหน้าตามเงื่อนไขไม่ตรง (${ms})`); a.moodAt = [b.start, b.end]; }
  else must(a.mood === '', `${a.id}: สีหน้าในซอร์สเป็น ${ms} ต้องเว้นว่าง`);
});
const nameOfCoach = (e, s) => {
  const kids = entries.filter(x => x.node.start >= e.start && x.node.end <= e.end && x.ann.id);
  if (kids.length){ const ids = kids.map(k => k.ann.id).join(' '); return { name: 'แทรก ' + ids, src: s, desc: `จุดที่ส่วนแทรกจะมาลงเมื่อเข้าเงื่อนไข ดูแถว ${ids}` }; }
  const d = PHMAP.get(s.replace(/\s+/g, ' ')); must(d, `ยังไม่ได้ตั้งชื่อให้นิพจน์ ${s}`); return { name: d.name, src: s, desc: d.desc };
};
const coachRows = new Map();
function coachMeta(e){ const a = e.ann; const pickTxt = e.pick ? ` (สุ่ม 1 ใน ${e.pick.n})` : '';
  const notes = []; if (a.note) notes.push(a.note); if (e.pick) notes.push(`เว็บสุ่มหนึ่งใน ${e.pick.n} บรรทัดของกลุ่มนี้ แล้วใช้บรรทัดเดิมตลอดสำหรับตัวละครตัวนั้น`);
  return { id: a.id, group: a.step ? `โค้ช ${stepName(a.step)}` : 'โค้ช ทุกขั้น', kind: a.kind, where: `${stepName(a.step)} · ${a.when}${pickTxt}`, mood: a.mood, moodAt: a.moodAt || null, note: notes.join('\n') }; }

/* ตารางคงที่ของโค้ช */
const kinNode = topConst('coach', 'COACH_KIN'), talNode = topConst('coach', 'COACH_TALENT'), persNode = topConst('coach', 'COACH_PERS3');
const kinName = k => k.name.split('/')[0].replace(/\(.*$/, '').trim();
must(JSON.stringify(kinNode.properties.map(keyOf).sort()) === JSON.stringify(DATA.kins.map(k => k.id).sort()), 'รายชื่อวงศาใน COACH_KIN ไม่ตรงกับข้อมูลวงศา');
const KIN_PART = [['joke', 1, 'บรรทัดที่ 1 แซว'], ['play', 1, 'บรรทัดที่ 2 สายการเล่น'], ['combo', 1, 'บรรทัดที่ 3 คอมโบ'], ['story', 2, 'เรื่องราว']];
function pushKinRows(){ for (const k of DATA.kins){ const o = prop(kinNode, k.id).value; const moodN = prop(o, 'mood').value; must(isStr(moodN) && MOODS[moodN.value], `วงศา ${k.id}: สีหน้าไม่รู้จัก`);
  const smP = prop(o, 'storyMood'); const smN = smP ? smP.value : null; if (smN) must(isStr(smN) && MOODS[smN.value], `วงศา ${k.id}: สีหน้าของบรรทัดเรื่องราวไม่รู้จัก`);
  for (const [part, step, label] of KIN_PART){ const first = part === 'joke', story = part === 'story';
    strRow('coach', prop(o, part).value, { id: `K-${k.id}-${part}`, group: 'โค้ช บรรทัดประจำวงศา', kind: 'คำพูด',
      where: story ? `${stepName(2)} · เลือก ${kinName(k)} และยังไม่ได้เลือกพื้นหลังสักใบ · ${label}` : `${stepName(1)} · เลือก ${kinName(k)} · ${label}`,
      mood: first ? moodN.value : (story && smN ? smN.value : ''), moodAt: first ? [moodN.start, moodN.end] : (story && smN ? [smN.start, smN.end] : null),
      moodInsertAt: story && !smN ? prop(o, 'story').start : null,
      note: first ? 'สีหน้านี้ใช้กับสามบรรทัดแรกของวงศานี้' : (story ? (smN ? 'พูดต่อจาก W2-02' : 'พูดต่อจาก W2-02 ด้วยสีหน้าที่ค้างอยู่ เลือกสีหน้าให้บรรทัดนี้ได้') : '') }); } } }
const TAL_PH = { mp: 'MP ของตัวละคร', sanity: 'Sanity ของตัวละคร', reflex: 'Reflex พร้อมเครื่องหมาย เช่น +1', might: 'Might พร้อมเครื่องหมาย เช่น +2', hp: 'HP ของตัวละคร', tough: 'Toughness ต่ออวัยวะ' };
function pushTalentRows(){ must(JSON.stringify(talNode.properties.map(keyOf).sort()) === JSON.stringify(DATA.talents.map(t => t.key).sort()), 'รายชื่อ Talent ใน COACH_TALENT ไม่ตรงกับข้อมูล');
  for (const p of talNode.properties){ const key = keyOf(p); const moodN = prop(p.value, 'mood').value; must(isStr(moodN) && MOODS[moodN.value], `Talent ${key}: สีหน้าไม่รู้จัก`);
    const r = strRow('coach', prop(p.value, 'text').value, { id: `TL-${key}`, group: `โค้ช ${stepName(5)}`, kind: 'คำพูด', where: `${stepName(5)} · เลือก Talent ${key === 'EDU' ? 'Educated' : 'สาย ' + key} แล้ว`, mood: moodN.value, moodAt: [moodN.start, moodN.end] });
    const used = [...new Set((r.text.match(/\{[^{}]+\}/g) || []).map(x => x.slice(1, -1)))]; for (const u of used){ must(TAL_PH[u], `Talent ${key}: ไม่รู้จัก {${u}}`); r.ph.push({ name: u, src: null, desc: TAL_PH[u] }); } } }
function pushPersRows(){ const axes = DATA.meta.personality; must(JSON.stringify(persNode.properties.map(keyOf)) === JSON.stringify(axes.map(a => a.id)), 'แกนบุคลิกภาพใน COACH_PERS3 ไม่ตรงกับข้อมูล');
  for (const ax of axes){ const arr = prop(persNode, ax.id).value.elements; must(arr.length === 2, `แกน ${ax.id}: ต้องมีสองฝั่ง`);
    arr.forEach((el, i) => { must(el.type === 'ObjectExpression', `แกน ${ax.id}: แต่ละฝั่งต้องเป็น {mood, text}`); const moodN = prop(el, 'mood').value, textN = prop(el, 'text').value; must(isStr(moodN) && MOODS[moodN.value], `แกน ${ax.id}: สีหน้าไม่รู้จัก`);
      strRow('coach', textN, { id: `P-${ax.id}-${i === 0 ? 'L' : 'R'}`, group: `โค้ช ${stepName(3)}`, kind: 'คำพูด', where: `${stepName(3)} · ให้ค่า 3 กับฝั่ง ${i === 0 ? ax.leftTh : ax.rightTh}`, mood: moodN.value, moodAt: [moodN.start, moodN.end] }); }); } }

entries.forEach((e) => {
  const a = e.ann; if (a.skip !== undefined) return;
  const meta = coachMeta(e);
  const r = e.str ? strRow('coach', e.node, meta) : tplRow('coach', e.node, meta, nameOfCoach);
  coachRows.set(a.id, r);
  if (a.id === 'W1-01c') pushKinRows();
  if (a.id === 'W3-01c') pushPersRows();
  if (a.id === 'W5-02') pushTalentRows();
});

/* ---------- ชื่อไทยของคำอังกฤษที่บรรทัดของโค้ชเอ่ยถึง ----------
 * เก็บเฉพาะของที่หน้าเว็บแสดงชื่อไทยขึ้นก่อน: Trait, Benefit, Hindrance, Starter Skill ของวงศา ความสามารถจาก Talent ทักษะ และสาขาความรู้
 * ชุดเริ่มต้นไม่นับ เพราะหน้าเว็บแสดงชื่ออังกฤษขึ้นก่อนอยู่แล้ว */
const NAME = new Map();
const addName = (en, th) => { if (!en || !th) return; en = String(en).trim(); th = String(th).trim(); if (en.length < 4 || !/[A-Za-z]/.test(en) || !TH.test(th)) return; if (!NAME.has(en)) NAME.set(en, th); };
for (const k of DATA.kins){ for (const t of [...(k.traits || []), ...(k.benefits || []), ...(k.hindrances || [])]) addName(t.nameEn, t.name);
  for (const s of (k.starterSkills || [])){ const m = /^(.*?)\s*\(([^()]+)\)\s*$/.exec(s.name || ''); if (m) addName(m[2], m[1]); } }
for (const t of DATA.talents) for (const st of t.steps){ const re = /([\u0E00-\u0E7F]+)\s*\(([A-Z][A-Za-z' &-]+)\)/g; let m; while ((m = re.exec(st.text || ''))) addName(m[2], m[1]); }
for (const s of DATA.skills) if (/\s/.test(s.nameEn || '')) addName(s.nameEn, s.nameTh);
for (const k of DATA.knowledge) addName(k.nameEn, k.nameTh);
const NAME_KEYS = [...NAME.keys()].sort((a, b) => b.length - a.length);
const rxEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function namesIn(text){ const hits = []; const taken = [];
  for (const en of NAME_KEYS){ const re = new RegExp('(?<![A-Za-z])' + rxEsc(en) + '(?![A-Za-z])', 'g'); let m;
    while ((m = re.exec(text))){ const a = m.index, b = a + en.length; if (taken.some(([x, y]) => a < y && b > x)) continue; taken.push([a, b]); if (!hits.some(h => h.en === en)) hits.push({ en, th: NAME.get(en), at: a }); } }
  return hits.sort((x, y) => x.at - y.at); }
const unknownNames = [];
for (const r of rows){ if (!/^(K-|TL-|W)/.test(r.id)) continue; const hits = namesIn(r.text); r.names = hits;
  if (hits.length){ const line = 'หน้าเว็บเรียกว่า: ' + hits.map(h => `${h.th} (${h.en})`).join(' · '); r.note = r.note ? r.note + '\n' + line : line; }
  // วลีอังกฤษขึ้นต้นตัวใหญ่ตั้งแต่สองคำขึ้นไปที่หาในข้อมูลไม่เจอ
  const stripped = hits.reduce((t, h) => t.split(h.en).join(' '), r.text.replace(/\{[^{}]*\}/g, ' '));
  for (const m of stripped.matchAll(/(?<![A-Za-z])([A-Z][A-Za-z'-]+(?: (?:of|as|the|&|[A-Z][A-Za-z'-]+))+)(?![A-Za-z])/g)) unknownNames.push([r.id, m[1]]); }

/* หมายเหตุเพิ่มรายแถวจากไฟล์ภายนอก: --notes <ไฟล์ json ของ { ID: ข้อความ }> */
if (argv.includes('--notes')){ const extra = JSON.parse(fs.readFileSync(argv[argv.indexOf('--notes') + 1], 'utf8'));
  for (const [id, t] of Object.entries(extra)){ const r = rows.find(x => x.id === id); must(r, `--notes: ไม่มีแถว ${id}`); r.note = r.note ? r.note + '\n' + t : t; } }

/* ---------- ตรวจ ---------- */
const ids = new Set(); for (const r of rows){ must(!ids.has(r.id), `ID ซ้ำ ${r.id}`); ids.add(r.id); }
for (const r of rows){ const fileKey = Object.keys(FILES).find(k => FILES[k] === r.file); const back = render(r, r.text); const orig = SRC[fileKey].slice(r.start, r.end);
  must(back === orig, `${r.id}: ประกอบกลับไม่ตรงซอร์ส\n  ได้   ${back}\n  ซอร์ส ${orig}`);
  must(r.text.length > 0 && TH.test(r.text + 'ก') , `${r.id}: ข้อความว่าง`);
  must(!/^[=+\-@']/.test(r.text) && !/^[\d.,/: -]+$/.test(r.text) && !/^(true|false)$/i.test(r.text), `${r.id}: ข้อความจะถูกตารางตีความเป็นอย่างอื่น`);
  if (r.mood) must(MOODS[r.mood], `${r.id}: สีหน้า ${r.mood}`); }
must(tutorLines === LESSONS.reduce((s, L) => s + L.lines.length, 0), 'จำนวนบรรทัดสอนเล่นไม่ตรง');

/* ---------- นำข้อความที่แก้แล้วกลับเข้าซอร์ส: --apply <ไฟล์ json ของ [{id, text?, mood?}]> ----------
 * text คือข้อความในช่องคำพูดของตาราง (ค่าเติมอยู่ในปีกกาตามชื่อเดิม) mood คือรหัสสีหน้า เช่น smile
 * สีหน้าที่หลายแถวใช้ลิเทอรัลเดียวกันในโค้ด ต้องเปลี่ยนเป็นค่าเดียวกันพร้อมกันทั้งกลุ่ม ไม่อย่างนั้นสคริปต์จะหยุดให้แยกโค้ดก่อน */
if (argv.includes('--apply')){
  const edits = JSON.parse(fs.readFileSync(argv[argv.indexOf('--apply') + 1], 'utf8'));
  const byId = new Map(rows.map(r => [r.id, r]));
  const reps = {}; const add = (file, a, b, t) => { (reps[file] = reps[file] || []).push([a, b, t]); };
  const shared = new Map(); for (const r of rows) if (r.moodAt){ const k = r.file + ':' + r.moodAt[0]; if (!shared.has(k)) shared.set(k, []); shared.get(k).push(r.id); }
  const moodDone = new Set(); let nText = 0, nMood = 0;
  /* v1.20: คำพูดที่ Non สั่งแก้ตรง ๆ ในแชทหลังชีทฉบับล่าสุด (tools/nem_overrides.json) · ถ้าชีทที่นำเข้ายังถือข้อความก่อนแก้ (was) อยู่
   * แปลว่าแถวนั้นในชีทตามไม่ทันเว็บ ให้คงข้อความของเว็บไว้ ไม่ดึงของเก่ากลับมา · ถ้าชีทเป็นข้อความอื่น ถือว่า Non แก้ซ้ำในชีท ชีทชนะ */
  const ovrPath = path.join(__dirname, 'nem_overrides.json');
  const OVR = new Map((fs.existsSync(ovrPath) ? JSON.parse(fs.readFileSync(ovrPath, 'utf8')).rows : []).map(o => [o.id, o]));
  for (const e0 of edits){ let e = e0; const r = byId.get(e.id); must(r, `--apply: ไม่มีแถว ${e.id}`);
    const ov = OVR.get(e.id);
    if (ov && e.text !== undefined && e.text.trim() === ov.was && r.text !== ov.was){ console.log(`ข้าม ${e.id}: ชีทยังเป็นข้อความก่อนที่สั่งแก้ในแชตเมื่อ ${ov.at} คงข้อความของเว็บไว้`); e = Object.assign({}, e); delete e.text; }
    if (e.text !== undefined && e.text.trim() !== r.text){ must(e.text.trim().length > 0, `${e.id}: ข้อความว่าง`); add(r.file, r.start, r.end, render(r, e.text.trim())); nText++; }
    if (e.mood !== undefined && e.mood !== r.mood){
      must(MOODS[e.mood], `${e.id}: สีหน้า "${e.mood}" ไม่รู้จัก (ลบสีหน้าออกต้องแก้โค้ดเอง)`);
      if (r.moodAt){ const k = r.file + ':' + r.moodAt[0];
        for (const other of shared.get(k)) if (other !== e.id){ const oe = edits.find(x => x.id === other); must(oe && oe.mood === e.mood, `${e.id}: สีหน้านี้ใช้ลิเทอรัลเดียวกับ ${other} ต้องเปลี่ยนเป็นค่าเดียวกันพร้อมกัน หรือแยกโค้ดก่อน`); }
        if (!moodDone.has(k)){ moodDone.add(k); add(r.file, r.moodAt[0], r.moodAt[1], `'${e.mood}'`); } nMood++; }
      else if (r.moodInsertAt != null){ add(r.file, r.moodInsertAt, r.moodInsertAt, `storyMood:'${e.mood}', `); nMood++; }
      else fail(`${e.id}: แถวนี้ไม่มีสีหน้าของตัวเองในโค้ด ต้องแก้โค้ดเอง`);
    } }
  for (const [file, list] of Object.entries(reps)){ const key = Object.keys(FILES).find(k => FILES[k] === file); let out = SRC[key]; list.sort((a, b) => b[0] - a[0]);
    for (let i = 1; i < list.length; i++) must(list[i][1] <= list[i - 1][0], `--apply: ช่วงแก้ซ้อนกันใน ${file}`);
    for (const [a, b, t] of list) out = out.slice(0, a) + t + out.slice(b);
    acorn.parse(out, { ecmaVersion: 'latest', sourceType: 'script' }); fs.writeFileSync(path.join(ROOT, 'src', file), out); }
  console.log(`นำกลับแล้ว: ข้อความ ${nText} แถว สีหน้า ${nMood} แถว ในไฟล์ ${Object.keys(reps).join(', ')} รันสคริปต์อีกครั้งเพื่อตรวจ`);
  process.exit(0);
}

/* ---------- ออกไฟล์ ---------- */
rows.forEach((r, i) => { r.order = i + 1; });
const phText = r => r.ph.map(p => `{${p.name}} ${p.desc}`).join('\n');
const noteText = r => [r.note, r.lead ? 'เว็บเว้นวรรคหน้าส่วนนี้ให้เอง' : ''].filter(Boolean).join('\n');
const HEAD = ['ID', 'อยู่ตรงไหน พูดเมื่อไร', 'คำพูด (แก้ที่ช่องนี้)', 'สีหน้า', 'สถานะ', 'ค่าที่เว็บเติมให้ (อย่าแก้ในปีกกา)', 'หมายเหตุ', 'หมวด', 'ชนิด', 'ลำดับ', 'คำพูดเดิม (อย่าแก้)', 'สีหน้าเดิม'];
const table = rows.map(r => [r.id, r.where, r.text, moodLabel(r.mood), '', phText(r), noteText(r), r.group, r.kind, String(r.order), r.text, moodLabel(r.mood)]);
for (const row of table) row.forEach((c, i) => { if (i === 9 || c === '') return; must(!/^[=+\-@']/.test(c) && !/^[\d.,/: %$-]+$/.test(c) && !/^(true|false)$/i.test(c), `${row[0]} คอลัมน์ ${HEAD[i]}: ตารางจะตีความ "${c.slice(0, 30)}" เป็นอย่างอื่น`); });
const csvCell = s => '"' + String(s).replace(/"/g, '""') + '"';
const csv = [HEAD, ...table].map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'nem_lines.csv'), csv);
fs.writeFileSync(path.join(outDir, 'nem_lines.json'), JSON.stringify({ head: HEAD, moods: MOODS, rows }, null, 1));

/* ---------- สรุป ---------- */
const by = (f) => rows.reduce((m, r) => { const k = f(r); m[k] = (m[k] || 0) + 1; return m; }, {});
console.log('แถวทั้งหมด', rows.length);
console.log('ตามชนิด', JSON.stringify(by(r => r.kind)));
console.log('ตามหมวด', JSON.stringify(by(r => r.group.replace(/ \d\d .*$/, '').replace(/ ขั้น.*$/, ''))));
console.log('สอนเล่น', LESSONS.length, 'บท', tutorLines, 'บรรทัด');
console.log('coachCompute', entries.length, 'ชิ้น เป็นแถว', entries.filter(e => e.ann.id).length, 'ยกเว้น', entries.filter(e => e.ann.skip !== undefined).length);
console.log('ตัวอักษรรวมของคำพูด', rows.reduce((s, r) => s + r.text.length, 0));
console.log('แถวที่มีค่าเติม', rows.filter(r => r.ph.length).length, '· แถวที่เอ่ยชื่ออังกฤษของสิ่งที่หน้าเว็บแสดงชื่อไทยขึ้นก่อน', rows.filter(r => r.names && r.names.length).length);
if (argv.includes('--debug') && unknownNames.length) console.log('วลีอังกฤษที่หาในข้อมูลไม่เจอ:\n' + unknownNames.map(([id, n]) => `  ${id}: ${n}`).join('\n'));
console.log('ตรวจผ่าน: ครบและประกอบกลับตรงซอร์สทุกแถว');
