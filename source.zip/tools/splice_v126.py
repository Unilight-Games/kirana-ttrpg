#!/usr/bin/env python3
"""v1.26 (ร่าง · Non เคาะ 16 พ.ย. 2026)
คลังทักษะ ข้อ ข: "สร้างหัวข้อเวทโลหิต เป็นสายตัวเองขึ้นมา"
  1. ทักษะ Blood Sorcery ทั้ง 13 ตัวเป็นประเภทของตัวเอง ตัดหมายเหตุของตัวแปลงไฟล์ออก
  2. ล้างหัวข้อย่อย กายาอสูร (The Untamed Form) ของ Sylvian ที่ค้างติดมากับ Blood Sorcery และ Requiem
คลังไอเทม ข้อ ก: "จัดลำดับให้ผมได้เลย" · ข้อ ข: "จัดเป็นอาวุธระดับพิเศษ" · ข้อ ค: "เอาตามนั้นครับ"
  3. เกราะลำตัว: ตามตัวอย่างในไฟล์แกน บทเศรษฐศาสตร์ ข้อ 1 (Hide 1, Chain Hauberk 2, Cuirass 3, Harness Plate 4) แล้วเทียบชิ้นที่เหลือเข้าระดับ
  4. เกราะส่วนย่อย: ตามช่วงราคาของไฟล์แกน (1–10 เกรฟ Tier 1, 11–20 Tier 2, 21–30 Tier 3, 31 ขึ้นไป Tier 4)
  5. อาวุธเทคโนโลยีและอาวุธเวทมนตร์: ระดับพิเศษ
วิธีใช้
  python3 tools/splice_v126.py                              แก้ tools/data.json
  python3 tools/splice_v126.py --skills <ต้นฉบับ.md> <ปลายทาง.md>   สำเนา Skill & Sorceries ที่มีหัวข้อ Blood Sorcery
  python3 tools/splice_v126.py --items <ต้นฉบับ.md> <ปลายทาง.md>    สำเนา Item All ที่มีบูลเล็ต ระดับ
รันซ้ำได้ ส่วนที่แก้แล้วจะถูกข้าม
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')
BLOOD = 'Blood Sorcery'
UNTAMED = 'หมวดหมู่: กายาอสูร (The Untamed Form)'
BODY_TIER = {
    'เสื้อบุเกราะแกมเบสัน (Field Gambeson)': 1, 'เกราะหนังเคลือบเงา (Leather Armor)': 1, 'เกราะหนังฟอก (Hide Armor)': 1,
    'เกราะโซ่ถัก (Chain Hauberk / Chain Mail)': 2, "เกราะบริกันดีน (Free Company's Brigandine)": 2,
    'เกราะแผ่นเหล็กลอริคา (Lorica Segmentata)': 2, 'เกราะเกล็ด (Scale Armor)': 2, 'เกราะลาเมลาร์ (Lamellar Armor)': 2,
    'เกราะแผ่นช่วงอก (Cuirass)': 3, 'เกราะโซ่สี่กระจก (Mail and Plate Armor)': 3,
    'เกราะแผ่นเต็มยศ (Harness Plate Armor)': 4, 'ใยอาคมอัมบราไลต์ (Umbralite Arcane-Weave)': 'S',
}
SPECIAL_CATS = ('อาวุธเทคโนโลยี', 'อาวุธเวทมนตร์')
TIER_LABEL = {1: 'Tier 1 ของสามัญ (Common Tier)', 2: 'Tier 2 ของทหาร (Military Tier)', 3: 'Tier 3 ของชั้นยอด (Masterwork Tier)',
              4: 'Tier 4 ของในตำนาน (Legendary Tier)', 'S': 'ระดับพิเศษ ของเวทมนตร์และของพิเศษ (Sorcerous & Special)'}


def price_tier(price):
    m = re.search(r'(\d+)', str(price or ''))
    if not m:
        return None
    p = int(m.group(1))
    return 1 if p <= 10 else 2 if p <= 20 else 3 if p <= 30 else 4


def tier_for(it):
    if it.get('cat') == 'เกราะลำตัว':
        return BODY_TIER.get(it['name'])
    if it.get('cat') == 'เกราะส่วนย่อย':
        return price_tier(it.get('price'))
    if it.get('cat') in SPECIAL_CATS:
        return 'S'
    return None


def data():
    d = json.load(open(DATA, encoding='utf-8'))
    n_sk = n_it = 0
    for s in d['skills']:
        if s.get('subcategory', '').startswith(BLOOD) and (s['subcategory'] != BLOOD or s.get('branch')):
            s['subcategory'] = BLOOD; s['branch'] = None; n_sk += 1
        elif s.get('nameEn') == 'Requiem' and s.get('branch') == UNTAMED:
            s['branch'] = None; n_sk += 1
    body = [i for i in d['items'] if i.get('cat') == 'เกราะลำตัว']
    missing = [i['name'] for i in body if i['name'] not in BODY_TIER]
    assert not missing, ('เกราะลำตัวที่ยังไม่มีระดับ', missing)
    for it in d['items']:
        t = tier_for(it)
        if t is not None and it.get('tier') != t:
            it['tier'] = t; n_it += 1
    json.dump(d, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print(f'data.json: ทักษะ {n_sk} ตัว · ไอเทม {n_it} ชิ้น')


def skills_copy(src, dst):
    lines = open(src, encoding='utf-8').read().split('\n')
    text = '\n'.join(lines)
    if '## **Blood Sorcery: เวทโลหิต**' in text:
        print('ไฟล์ทักษะมีหัวข้อ Blood Sorcery แล้ว'); open(dst, 'w', encoding='utf-8').write(text); return
    desc = ('ศาสตร์ที่แคสเซท จันทราร้อยเรียง หนึ่งในเจ็ดจันทรา คิดค้นขึ้น ใช้ควบคุมโลหิตและพลังชีวิต ปั้นเลือดเป็นหอก เกราะ โซ่ กรงขัง '
            'และอาวุธ ถ่ายเทพลังชีวิตเพื่อเยียวยาหรือชุบชีวิต บางเวทจ่ายด้วย HP ของผู้ร่ายเอง')
    out = []; done = {'toc': 0, 'types': 0, 'head': 0}; i = 0
    while i < len(lines):
        ln = lines[i]; out.append(ln)
        if ln.startswith('* **Ritual Sorcery (เวทพิธีกรรม หรือ คุณไสย):** ') and not done['toc']:
            out.append('* **Blood Sorcery (เวทโลหิต):** ' + desc); done['toc'] = 1
        elif ln.startswith('* **Ritual Sorcery (เวทพิธีกรรม หรือ คุณไสย):**') and done['toc'] and not done['types']:
            i += 1; out.append(lines[i])  # บรรทัดคำอธิบายของ Ritual Sorcery
            out.append('* **Blood Sorcery (เวทโลหิต)**  ')
            out.append('  * ' + desc); done['types'] = 1
        i += 1
    for j, ln in enumerate(out):
        if ln.startswith('* **เศษเสี้ยวโลหิต (Blood Shard)**'):
            out[j:j] = ['## **Blood Sorcery: เวทโลหิต**', '']; done['head'] = 1; break
    assert all(done.values()), done
    open(dst, 'w', encoding='utf-8').write('\n'.join(out))
    print('สำเนาไฟล์ทักษะ:', dst, done)


def items_copy(src, dst):
    sys.path.insert(0, HERE)
    lines = open(src, encoding='utf-8').read().split('\n')
    if any('**ระดับ:**' in ln for ln in lines):
        print('Item All มีบูลเล็ต ระดับ แล้ว'); open(dst, 'w', encoding='utf-8').write('\n'.join(lines)); return
    d = json.load(open(DATA, encoding='utf-8'))
    want = {i['name']: i['tier'] for i in d['items'] if i.get('tier') is not None}
    name_rx = re.compile(r'^(?:#{1,6}\s*)?(?:\*\s+|\d+\\?\.\s+)?\*\*(?:\d+\\?\.\s*)?(.+?)\*\*\s*$')
    price_rx = re.compile(r'^(\s*)\*\s+\*\*ราคา:?\*\*')
    out = []; cur = None; placed = set()
    for ln in lines:
        kv_like = re.match(r'^\s*\*\s+\*\*[^*]+?:?\*\*:?\s*\S', ln)  # บูลเล็ต **คีย์:** ค่า ที่ลงท้ายด้วยตัวหนา ไม่ใช่ชื่อไอเทม
        m = name_rx.match(ln.strip()) if not (price_rx.match(ln) or kv_like) else None
        if m:
            nm = re.sub(r'\\', '', m.group(1)).strip()
            cur = nm if nm in want else None
        pm = price_rx.match(ln)
        if pm and cur and cur not in placed:
            out.append(f'{pm.group(1)}* **ระดับ:** {TIER_LABEL[want[cur]]}  '); placed.add(cur)
        out.append(ln)
    miss = sorted(set(want) - placed)
    assert not miss, ('หาบรรทัดราคาไม่เจอ', miss)
    open(dst, 'w', encoding='utf-8').write('\n'.join(out))
    print('สำเนา Item All:', dst, len(placed), 'ชิ้น')


if __name__ == '__main__':
    a = sys.argv[1:]
    if a[:1] == ['--skills']:
        skills_copy(a[1], a[2])
    elif a[:1] == ['--items']:
        items_copy(a[1], a[2])
    else:
        data()
