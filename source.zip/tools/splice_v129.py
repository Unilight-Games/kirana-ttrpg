#!/usr/bin/env python3
"""v1.29 (Non เคาะ 16 พ.ย. 2026) คำตัดสินกฎที่เปลี่ยนข้อความในข้อมูลของเว็บและในไฟล์กฎ
1. "แก้ระยะลด CV เป็น ทุกๆ 2 เมตร -1 CV แทน" (แทนข้อ 27 เดิมที่ลด 1 CV ต่อทุก 1 เมตร)
2. "fixed ว่าการโจมตีระยะใกล้จะเพิ่ม Damage ตาม Might ส่วนอาวุธระยะไกลจะเพิ่ม Damage ตาม Sight" (ธนูจึงบวก Sight)
3. "ตอน parry คนที่ทำการเล็ง ให้ parry ส่วนที่เขาทอยได้ ไม่ใช่ส่วนที่เขาเล็ง"
4. "เมื่อโจมตีหรือร่ายเวทจะหลุดออกจากสถานะซ่อนตัว และการโจมตีจากสถานะซ่อนตัวจะถูกนับว่าเป็น Perfect Strike"

แก้ tools/data.json กับ tools/glossary.json: python3 tools/splice_v129.py
แก้ไฟล์กฎ (ไฟล์แกน Talent Starter Set Item All) ในโฟลเดอร์ที่ระบุ: python3 tools/splice_v129.py --rules <โฟลเดอร์>
รันซ้ำได้: ข้อความที่แก้แล้วจะถูกข้าม ข้อความต้นทางที่หาไม่เจอทำให้สคริปต์หยุด
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')
GLOSS = os.path.join(HERE, 'glossary.json')

# (เก่า, ใหม่) ของคำอธิบายศัพท์
GLOSSARY_SWAPS = {
    'Far Zone': [('ลด 1 CV ต่อทุก 1 เมตรที่เกินระยะแม่น', 'ลด 1 CV ต่อทุก 2 เมตรที่เกินระยะแม่น')],
    'Parry': [('ถ้าผู้โจมตีเล็งด้วย Focus (Precise) ใช้กลุ่มของตำแหน่งที่ประกาศ', 'ผู้โจมตีเล็งด้วย Focus (Precise) ก็ยังใช้กลุ่มของเลขที่ทอยได้')],
    'Focus': [('ตำแหน่งที่ประกาศใช้แทนตำแหน่งจากหน้าเต๋า', 'ตำแหน่งที่ประกาศใช้แทนตำแหน่งจากหน้าเต๋า ส่วนฝ่ายรับที่ Parry ยังดูกลุ่มจากเลขที่ทอยได้')],
    'Hidden': [('การสิ้นสุด: เมื่อตัวละครทำการโจมตี หรือทำสิ่งที่เปิดเผยตำแหน่งของตนเอง', 'การสิ้นสุด: เมื่อตัวละครทำการโจมตี ร่ายเวท หรือทำสิ่งที่เปิดเผยตำแหน่งของตนเอง')],
    'Sight': [('ค่าที่ใช้กับ Focus (Precise) และการโจมตีระยะไกล', 'ค่าที่ใช้กับ Focus (Precise) และบวกความเสียหายของอาวุธระยะไกล')],
}
RANGE_OLD, RANGE_NEW = '-1 CV ต่อทุก 1 เมตรที่เกิน', '-1 CV ต่อทุก 2 เมตรที่เกิน'
BOW_OLD = 'ธนูโค้งกลับต้องการ STR 12 ใช้ Might ยิงได้ทุกเทิร์น'
BOW_NEW = 'ธนูโค้งกลับต้องการ STR 12 ใช้ Sight เช่นกัน ยิงได้ทุกเทิร์น'

# ไฟล์กฎ: (ชื่อไฟล์, [(เก่า, ใหม่, จำนวนครั้ง)])
RULE_SWAPS = {
    'Kirana Core System TTRPG (V.2).md': [
        ('**หากเป็นอาวุธระยะประชิดหรือใช้แรง (เช่น ดาบ ธนู):** Weapon Damage \\+ Might',
         '**หากเป็นการโจมตีระยะประชิด (เช่น ดาบ ขวาน มือเปล่า):** Weapon Damage \\+ Might', 1),
        ('**หากเป็นอาวุธระยะไกลที่ใช้ความแม่นยำมากกว่าแรง (เช่น หน้าไม้ ปืน):** Weapon Damage \\+ Sight',
         '**หากเป็นอาวุธระยะไกล (เช่น ธนู หน้าไม้ ปืน):** Weapon Damage \\+ Sight', 1),
        ('หากผู้โจมตีประกาศตำแหน่งด้วย Focus (Precise) ให้ใช้กลุ่มของตำแหน่งที่ประกาศ',
         'แม้ผู้โจมตีประกาศตำแหน่งด้วย Focus (Precise) การ Parry ยังตัดสินจากกลุ่มของเลขที่ผู้โจมตีทอยได้ ไม่ใช้ตำแหน่งที่ประกาศ', 1),
        ('ระยะที่เกินความแม่นยำหัก 1 CV ต่อทุก 1 เมตรที่เกิน (เกิน 4 เมตรหัก 4 CV เกิน 10 เมตรหัก 10 CV)',
         'ระยะที่เกินความแม่นยำหัก 1 CV ต่อทุก 2 เมตรที่เกิน (เกิน 4 เมตรหัก 2 CV เกิน 10 เมตรหัก 5 CV)', 1),
        ('**การสิ้นสุด:** เมื่อตัวละครทำการโจมตี หรือทำสิ่งที่เปิดเผยตำแหน่งของตนเอง',
         '**การสิ้นสุด:** เมื่อตัวละครทำการโจมตี ร่ายเวท หรือทำสิ่งที่เปิดเผยตำแหน่งของตนเอง', 1),
    ],
    'Talent & Knowledge Proficiency.md': [
        ('\\-1 CV ต่อทุก 1 เมตรที่เกิน', '\\-1 CV ต่อทุก 2 เมตรที่เกิน', 4),
    ],
    'Starter Set - ชุดไอเทมเริ่มต้น.md': [(BOW_OLD, BOW_NEW, 1)],
    'Item All.md': [(BOW_OLD, BOW_NEW, 1)],
}


def swap(text, old, new, count=1):
    """แทน old ด้วย new: เจอ new อยู่แล้ว = ข้าม (new บางอันมี old เป็นส่วนหนึ่ง จึงต้องดู new ก่อน) · ไม่งั้นต้องเจอ old ครบ count ครั้ง"""
    if new in text:
        return text, 0
    assert text.count(old) == count, ('old text count', text.count(old), 'want', count, old[:70])
    return text.replace(old, new), count


def rules(folder):
    total = 0
    for name, pairs in RULE_SWAPS.items():
        path = os.path.join(folder, name)
        if not os.path.exists(path):
            print('splice_v129 rules: ไม่พบไฟล์', name, '(ข้าม)')
            continue
        s = open(path, encoding='utf-8').read()
        n = 0
        for old, new, cnt in pairs:
            s, c = swap(s, old, new, cnt)
            n += c
        open(path, 'w', encoding='utf-8').write(s)
        print('splice_v129 rules:', name, 'changed', n)
        total += n
    return total


def main():
    D = json.load(open(DATA, encoding='utf-8'))
    G = json.load(open(GLOSS, encoding='utf-8'))
    n = 0
    for store in (D['glossary'], G):
        for key, pairs in GLOSSARY_SWAPS.items():
            for old, new in pairs:
                store[key]['text'], c = swap(store[key]['text'], old, new)
                n += c
    rng = [k for k in D['knowledge'] if k['id'] == 'range']
    assert len(rng) == 1
    for lv, L in rng[0]['levels'].items():
        L['text'], c = swap(L['text'], RANGE_OLD, RANGE_NEW)
        n += c
    def walk(o):
        k = 0
        if isinstance(o, dict):
            for key, v in o.items():
                if isinstance(v, str):
                    if BOW_OLD in v:
                        o[key], c = swap(v, BOW_OLD, BOW_NEW)
                        k += c
                else:
                    k += walk(v)
        elif isinstance(o, list):
            for v in o:
                k += walk(v)
        return k
    n += walk(D['sets'])
    json.dump(D, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    json.dump(G, open(GLOSS, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('splice_v129 data: changed', n)


if __name__ == '__main__':
    if len(sys.argv) >= 3 and sys.argv[1] == '--rules':
        rules(sys.argv[2])
    else:
        main()
