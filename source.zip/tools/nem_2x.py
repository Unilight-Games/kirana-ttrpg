# -*- coding: utf-8 -*-
"""รูปเนเมสไซอาร์สำหรับเว็บ ทำจากไฟล์ต้นฉบับ PNG ของ Non (v1.21)

ต้นฉบับ: assets/Nemessiah/nem-<สีหน้า>.png (Clip Studio Paint, sRGB, ผืน 2546×2458 ทุกไฟล์)
ไฟล์ต้นฉบับอยู่ในโฟลเดอร์ของ Non เท่านั้น ไม่ได้ขึ้น GitHub

ทุกสีหน้าใช้กรอบเดียวกัน คือจุด (420, 240) ถึง (1920, 2040) ของผืนต้นฉบับ ขนาด 1500×1800 สัดส่วน 5:6
ตัวละครจึงยืนที่เดิมเวลาเปลี่ยนสีหน้า และกรอบนี้ตรงกับรูปชุดเดิมของ v1.0 (วัดย้อนจากรูปเดิมด้วยการเทียบภาพ)
CSS ของหน้าแรก หน้าสอนเล่น และโค้ชในวิซาร์ดกำหนดความสูงของรูปไว้ ขนาดไฟล์จึงไม่เปลี่ยนเลย์เอาต์ ขอแค่สัดส่วนคง 5:6

ได้สองไฟล์ต่อสีหน้า
  assets/nem-<สีหน้า>.webp      360×432    ภาพย่อในบันทึกบทพูด และไฟล์สำรองเมื่อโหลดไฟล์หลักไม่ได้
  assets/nem-<สีหน้า>-2x.webp   1080×1296  ไฟล์หลักที่หน้าเว็บโหลดก่อน (ชื่อ -2x มาจากโค้ด v1.20 ขนาดจริงคือ 3 เท่าของไฟล์เล็ก)
1296 พิกเซลพอสำหรับหน้าสอนเล่นที่วาดรูปสูงราว 594 px คูณขนาด UI สูงสุด 145% และการขยายจอของ Windows 150%

ย่อด้วย Lanczos บนสีที่คูณค่าโปร่งใสแล้ว ขอบตัวละครจึงไม่มีสีรั่ว และตัวกรองอ่านพิกเซลนอกกรอบด้วย ขอบล่างที่ตัดผ่านชุดจึงไม่จาง
เข้ารหัสด้วย cwebp (-sharp_yuv ช่วยให้เส้นแดงสลับขาวบนผ้าคลุมไม่ซีด) ถ้าไม่มี cwebp ในเครื่องจะใช้ Pillow แทน

ใช้: python3 tools/nem_2x.py [โฟลเดอร์ assets]   (ค่าตั้งต้นคือ ../assets) เขียนทับไฟล์ webp ทั้ง 20 ไฟล์"""
import os, sys, shutil, subprocess, tempfile
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
D = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "assets")
SRC = os.path.join(D, "Nemessiah")
MOODS = ["ask", "explain", "guilty", "mad", "panic", "shush", "smile", "smirk", "surprise", "think"]
CANVAS = (2546, 2458)
BOX = (420, 240, 1920, 2040)
OUT = [("", (360, 432)), ("-2x", (1080, 1296))]
QUALITY = 90


def shrink(im, size):
    a = np.asarray(im.convert("RGBA")).astype(np.float32) / 255.0
    al = a[..., 3]
    chans = [a[..., i] * al for i in range(3)] + [al]
    res = [np.asarray(Image.fromarray(np.ascontiguousarray(c), "F").resize(size, Image.LANCZOS, box=BOX)) for c in chans]
    al2 = np.clip(res[3], 0.0, 1.0)
    al2[al2 < 0.5 / 255.0] = 0.0
    safe = np.maximum(al2, 1e-4)
    rgb = np.stack([np.where(al2 > 0, r / safe, 0.0) for r in res[:3]], axis=-1).clip(0.0, 1.0)
    out = np.concatenate([rgb, al2[..., None]], axis=-1)
    return Image.fromarray((out * 255.0 + 0.5).astype(np.uint8), "RGBA")


def save_webp(im, path, tmpdir):
    cw = shutil.which("cwebp")
    if cw:
        tmp = os.path.join(tmpdir, "in.png")
        im.save(tmp, "PNG")
        subprocess.run([cw, "-quiet", "-q", str(QUALITY), "-m", "6", "-sharp_yuv", "-af",
                        "-alpha_q", "100", "-alpha_filter", "best", "-metadata", "none", tmp, "-o", path], check=True)
        return "cwebp"
    im.save(path, "WEBP", quality=QUALITY, method=6)
    return "Pillow"


if __name__ == "__main__":
    n = 0
    with tempfile.TemporaryDirectory() as tmpdir:
        for m in MOODS:
            p = os.path.join(SRC, f"nem-{m}.png")
            if not os.path.exists(p):
                sys.exit(f"ไม่พบ {p}")
            im = Image.open(p)
            if im.size != CANVAS:
                sys.exit(f"{os.path.basename(p)} มีผืน {im.size[0]}×{im.size[1]} ไม่ใช่ {CANVAS[0]}×{CANVAS[1]} ต้องวัดกรอบ BOX ใหม่ก่อน")
            for suf, size in OUT:
                out = os.path.join(D, f"nem-{m}{suf}.webp")
                how = save_webp(shrink(im, size), out, tmpdir)
                print(f"nem-{m}.png -> {os.path.basename(out)} {size[0]}×{size[1]} {os.path.getsize(out)} bytes ({how})")
                n += 1
    print(n, "ไฟล์")
