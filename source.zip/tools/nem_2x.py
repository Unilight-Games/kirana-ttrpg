# -*- coding: utf-8 -*-
"""รูปเนเมสไซอาร์ขนาด 2 เท่าสำหรับจอที่วาดรูปใหญ่กว่าไฟล์ (v1.20)

ไฟล์ต้นฉบับ assets/nem-<สีหน้า>.webp มีขนาด 360×432 แต่หน้าสอนเล่นวาดรูปสูงราว 594 px
บวกขนาด UI 115% และการขยายจอของ Windows (125 ถึง 150%) เบราว์เซอร์จึงต้องยืดรูป 1.6 ถึง 2.4 เท่า ภาพจึงเบลอ
สคริปต์นี้ขยายรูปล่วงหน้า 2 เท่าด้วย Lanczos (คูณสีด้วยค่าโปร่งใสก่อน ขอบจึงไม่มีสีรั่ว) แล้วเร่งความคมเฉพาะเนื้อในของตัวละคร
ไม่ได้วาดรายละเอียดเพิ่ม เส้นทุกเส้นมาจากไฟล์เดิม ถ้ามีไฟล์ต้นฉบับที่ใหญ่กว่า (แนะนำ 1080×1296 ขึ้นไป) ให้วางทับ nem-<สีหน้า>-2x.webp ได้เลย

ใช้: python3 nem_2x.py [โฟลเดอร์ assets]   (ค่าตั้งต้นคือ ../assets) ได้ไฟล์ nem-<สีหน้า>-2x.webp ข้างไฟล์เดิม"""
import os, sys, glob
import numpy as np
from PIL import Image, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
D = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "assets")


def up2(im):
    arr = np.asarray(im.convert("RGBA")).astype(np.float32) / 255.0
    rgb, al = arr[..., :3], arr[..., 3:4]
    pm = np.concatenate([rgb * al, al], axis=-1)
    w, h = im.size
    chans = [Image.fromarray((pm[..., i] * 255.0 + 0.5).clip(0, 255).astype(np.uint8), "L").resize((w * 2, h * 2), Image.LANCZOS) for i in range(4)]
    up = np.stack([np.asarray(c).astype(np.float32) / 255.0 for c in chans], axis=-1)
    al2 = up[..., 3:4]
    rgb2 = np.where(al2 > 1e-3, up[..., :3] / np.maximum(al2, 1e-3), 0.0).clip(0, 1)
    base = Image.fromarray((rgb2 * 255.0 + 0.5).clip(0, 255).astype(np.uint8), "RGB")
    sharp = np.asarray(base.filter(ImageFilter.UnsharpMask(radius=1.6, percent=85, threshold=2))).astype(np.float32) / 255.0
    # เร่งคมเฉพาะเนื้อใน: น้ำหนัก = ค่าโปร่งใสต่ำสุดในรัศมี 3 พิกเซล ขอบตัวละครจึงไม่เกิดเส้นขาว
    amin = np.asarray(Image.fromarray((al2[..., 0] * 255.0).astype(np.uint8), "L").filter(ImageFilter.MinFilter(7))).astype(np.float32)[..., None] / 255.0
    out_rgb = rgb2 + (sharp - rgb2) * amin
    out = np.concatenate([out_rgb, al2], axis=-1)
    return Image.fromarray((out * 255.0 + 0.5).clip(0, 255).astype(np.uint8), "RGBA")


if __name__ == "__main__":
    n = 0
    for p in sorted(glob.glob(os.path.join(D, "nem-*.webp"))):
        if p.endswith("-2x.webp"):
            continue
        im = Image.open(p)
        out = p[:-5] + "-2x.webp"
        up2(im).save(out, "WEBP", quality=90, method=6)
        print(os.path.basename(p), im.size, "->", os.path.basename(out), os.path.getsize(out), "bytes")
        n += 1
    print(n, "ไฟล์")
