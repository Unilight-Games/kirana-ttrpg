import json, pathlib
root = pathlib.Path(__file__).parent
src = root / "src"
data = open("/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/data.json", encoding="utf-8").read()
# JSON inside <script type=application/json>: escape closing tags
data = data.replace("</", "<\\/")
app = "\n".join(open(src / f, encoding="utf-8").read() for f in ["core.js", "ui.js", "auth.js", "wizard.js", "sheet.js", "hud.js", "ipshop.js", "map.js", "table.js", "main.js"])
assert "</script" not in app
html = open(src / "shell.html", encoding="utf-8").read().replace("__DATA__", data).replace("__APP__", app)
out = root / "dist" / "index.html"
out.parent.mkdir(exist_ok=True)
out.write_text(html, encoding="utf-8")
print(out, len(html.encode("utf-8")), "bytes")
