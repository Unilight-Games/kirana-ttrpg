#!/usr/bin/env python3
"""v1.24: แก้ไฟล์กฎ Kins of Kirana V.2.md ให้ตรงกับเว็บ (tools/traits_v124.json)

1. Trait วงศาที่มี Flavor: ย้ายประโยค Flavor มาไว้หลังชื่อ Trait เป็นตัวเอียง *...* แล้วตามด้วย Effect
   (ตัดคำเชื่อมตรงรอยต่อตาม drop) ถ้อยคำอื่นคงเดิมทุกตัวอักษร
2. Trait พื้นหลัง: ป้าย Trait (ชื่ออังกฤษ) เปลี่ยนเป็น ชื่อไทย (ชื่ออังกฤษ) ในรูปแบบเดิมของบรรทัด (ตัวหนา/ไม่หนา, มี > หรือไม่มี)
   Trait พื้นหลังที่มี Flavor ทำแบบข้อ 1
3. คำพิมพ์ผิดตาม typos และชื่ออังกฤษตาม enFix

ใช้: python3 tools/patch_kins_v124.py <ไฟล์ต้นทาง> <ไฟล์ปลายทาง> <ไฟล์สำรองบรรทัดที่แก้>
ข้ามบรรทัดยาวเกิน 5000 ตัวอักษร (ภาพ base64) ไม่แตะ
"""
import json, re, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
M = json.load(open(os.path.join(HERE, 'traits_v124.json'), encoding='utf-8'))
D = json.load(open(os.path.join(HERE, 'data.json'), encoding='utf-8'))
PUNCT = set("-+()[]|*_.!#'’:&,")


def loose(s):
    """regex ที่ทนเครื่องหมาย \\ หน้าวรรคตอน, ' กับ ’ และช่องว่างหลายตัว"""
    out = []
    for ch in s:
        if ch == ' ':
            out.append(r'\s+')
        elif ch in ("'", '’'):
            out.append(r"\\?['’]")
        elif ch in PUNCT:
            out.append(r'\\?' + re.escape(ch))
        else:
            out.append(re.escape(ch))
    return ''.join(out)


def wrap_flavor(line, label_rx, flavor, drop):
    """ย้าย flavor ไปหลังป้าย label เป็นตัวเอียง คืนบรรทัดใหม่หรือ None ถ้าไม่เจอ"""
    m = re.search(label_rx, line)
    if not m:
        return None
    head, rest = line[:m.end()], line[m.end():]
    trail = re.search(r'\s*$', rest).group(0)
    body = rest[:len(rest) - len(trail)] if trail else rest
    f = re.search(loose(flavor), body)
    if not f:
        return None
    raw_flavor = f.group(0)
    before, after = body[:f.start()].rstrip(), body[f.end():].lstrip()
    if drop and after.startswith(drop):
        after = after[len(drop):].lstrip()
    effect = re.sub(r'\s{2,}', ' ', (before + ' ' + after).strip())
    return f"{head.rstrip()} *{raw_flavor}* {effect}{trail}"


def main(src, dst, bak):
    lines = open(src, encoding='utf-8').read().split('\n')
    orig = list(lines)
    small = [i for i, l in enumerate(lines) if len(l) <= 5000]
    log = []

    # ---- 1) Trait วงศา ----
    K = {k['id']: k for k in D['kins']}
    done_kin = {}
    for key, spec in M['kin'].items():
        kid, grp, idx = key.split('|')
        t = K[kid][grp][int(idx)]
        label_rx = r'\*\*' + loose(t['name']) + r'\s*\(' + loose(t['nameEn']) + r'\)\s*:\s*\*\*'
        sig = (t['name'], t['nameEn'], spec['flavor'])
        if sig in done_kin:
            continue  # ชื่อและ Flavor เดียวกันหลายวงศา (เช่น รากเหง้าแห่งผู้รอดชีวิต) แก้ทุกบรรทัดในรอบแรกแล้ว
        n = 0
        for i in small:
            if re.search(label_rx, lines[i]) and not re.search(r'\*\s*' + loose(spec['flavor']) + r'\s*\*', lines[i]):
                new = wrap_flavor(lines[i], label_rx, spec['flavor'], spec.get('drop'))
                if new:
                    lines[i] = new; n += 1; log.append(i)
        expect = sum(1 for k in D['kins'] for g in ('traits', 'benefits', 'hindrances') for x in (k.get(g) or [])
                     if (x['name'], x['nameEn'], x.get('flavor')) == sig)
        assert n == expect, ('kin flavor lines', key, n, expect)
        done_kin[sig] = n

    # ---- 2) Trait พื้นหลัง ----
    BG = {}
    for k in D['kins']:
        for g in ('childhood', 'specialChildhood', 'adulthood', 'specialAdulthood'):
            for b in k.get(g) or []:
                BG[f"{k['id']}|{b['code']}"] = b
    enfix_rev = {v: k for k, v in M.get('enFix', {}).items()}
    for key, spec in M['bg'].items():
        b = BG[key]
        en_old = enfix_rev.get(b['traitEn'], b['traitEn'])
        inner = loose(en_old) if key != 'orcarim|C5' else loose(spec['th']) + r'\s*\\?-\s*' + loose(en_old)
        rx = r'(\*\*)?Trait\s*\(' + inner + r'\)\s*:\s*(\*\*)?'
        hits = [i for i in small if re.search(rx, lines[i])]
        assert len(hits) == 1, ('bg label lines', key, len(hits))
        i = hits[0]
        def rep(m):
            bold = m.group(1) or ''
            close = m.group(2) or ''
            return f"{bold}{spec['th']} ({b['traitEn']}):{close} " if close else f"{bold}{spec['th']} ({b['traitEn']}): "
        new = re.sub(rx, rep, lines[i], count=1)
        new = re.sub(r'(:\*\*|:) {2,}', r'\1 ', new)
        if spec.get('flavor'):
            label_rx = loose(spec['th']) + r'\s*\(' + loose(b['traitEn']) + r'\)\s*:\s*(\*\*)?'
            w = wrap_flavor(new, label_rx, spec['flavor'], spec.get('drop'))
            assert w, ('bg flavor', key)
            new = w
        lines[i] = new
        log.append(i)

    # ---- 3) คำพิมพ์ผิด ----
    for a, bb in M.get('typos', []):
        hit = [i for i in small if a in lines[i]]
        assert hit, ('typo not found', a)
        for i in hit:
            lines[i] = lines[i].replace(a, bb); log.append(i)

    changed = sorted(set(i for i in log if lines[i] != orig[i]))
    open(dst, 'w', encoding='utf-8').write('\n'.join(lines))
    with open(bak, 'w', encoding='utf-8') as f:
        f.write('# Kins of Kirana V.2.md · บรรทัดที่ v1.24 แก้ (ก่อนแก้ 2026-11-15)\n\n')
        f.write('ไฟล์เต็มใหญ่ 55 MB เพราะมีภาพฝังอยู่ จึงสำรองเฉพาะบรรทัดที่แก้ เลขบรรทัดนับจาก 1 คืนค่าได้ด้วยการวางบรรทัดเดิมกลับที่เลขเดียวกัน (จำนวนบรรทัดของไฟล์ไม่เปลี่ยน)\n\n')
        for i in changed:
            f.write(f'## บรรทัด {i + 1}\n\nก่อนแก้:\n\n```\n{orig[i]}\n```\n\nหลังแก้:\n\n```\n{lines[i]}\n```\n\n')
    print('patch_kins_v124: changed lines', len(changed), '| kin flavor groups', len(done_kin), '| bg traits', len(M['bg']))


if __name__ == '__main__':
    main(*sys.argv[1:4])
