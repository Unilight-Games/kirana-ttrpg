#!/usr/bin/env python3
"""v1.31 (Non เคาะ 17 พ.ย. 2026 ข้อ 8 ถึง 12) ข้อมูลวงศาให้ตรงกับ Astral Sea Lore
8. "ยึดตาม Astral Sea ครับ" ส่วนสูงบุตรราตรี (ไนท์คิน) 1.56 ถึง 1.68 เมตร ไนท์เอลฟ์ 1.67 ถึง 1.8 เมตร
9. "สวาลานสูง 1.64 ถึง 1.8 ครับ พวกเขาไม่แก่ แต่ถ้าขาดพลังงานชีวิตตัวจะแก่เร็วมากจนตายได้ครับ (หากได้รับพลังงานชีวิตจะกลับมาหนุ่มสาวดังเดิม)"
ข้อ 10 ถึง 12 แก้ในบทความเผ่า (src/races.js) และไฟล์ลอร์ ไม่มีข้อความในข้อมูลวงศา

แก้ tools/data.json: python3 tools/splice_v131.py
แก้ไฟล์ Kins of Kirana V.2.md ในโฟลเดอร์ที่ระบุ: python3 tools/splice_v131.py --rules <โฟลเดอร์>
รันซ้ำได้: ข้อความที่แก้แล้วจะถูกข้าม ข้อความต้นทางที่หาไม่เจอทำให้สคริปต์หยุด
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data.json')

# วงศา: (id, ช่อง, เก่า, ใหม่)
KIN_SWAPS = [
    ('nightkin', 'size',
     'ไนท์คินมีรูปร่างและขนาดใกล้เคียงกับมนุษย์ โดยมีส่วนสูงเฉลี่ยระหว่าง 1.65 ถึง 1.8 เมตร',
     'ไนท์คินมีรูปร่างและขนาดใกล้เคียงกับมนุษย์ โดยมีส่วนสูงเฉลี่ยระหว่าง 1.56 ถึง 1.68 เมตร'),
    ('night-alves', 'size',
     'ไนท์เอลฟ์มีรูปร่างสมส่วนใกล้เคียงมนุษย์ มีความสูงเฉลี่ยระหว่าง 1.56 ถึง 1.68 เมตร',
     'ไนท์เอลฟ์มีรูปร่างสมส่วนใกล้เคียงมนุษย์ มีความสูงเฉลี่ยระหว่าง 1.67 ถึง 1.8 เมตร'),
    ('swalan', 'age',
     'สวาลานไม่แก่ชราจากกาลเวลาและไม่สามารถตายจากความชราได้',
     'สวาลานไม่แก่ชราจากกาลเวลา และจะแก่ลงอย่างรวดเร็วจนถึงแก่ความตายได้ก็ต่อเมื่อขาดพลังชีวิตมาหล่อเลี้ยง เมื่อได้รับพลังชีวิตอีกครั้ง ร่างกายจะกลับคืนสู่ความหนุ่มสาวดังเดิม'),
    ('swalan', 'size',
     'สวาลานมีรูปร่างและขนาดเหมือนมนุษย์ มีส่วนสูงเฉลี่ย 1.74 ถึง 1.80 เมตร',
     'สวาลานมีรูปร่างและขนาดเหมือนมนุษย์ มีส่วนสูงเฉลี่ย 1.64 ถึง 1.80 เมตร'),
]
KINS_FILE = 'Kins of Kirana V.2.md'


def swap(text, old, new):
    """แทน old ด้วย new: เจอ new อยู่แล้ว = ข้าม · ไม่งั้นต้องเจอ old 1 ครั้งพอดี"""
    if new in text:
        return text, 0
    assert text.count(old) == 1, ('old text count', text.count(old), old[:60])
    return text.replace(old, new), 1


def rules(folder):
    path = os.path.join(folder, KINS_FILE)
    s = open(path, encoding='utf-8').read()
    n = 0
    for _, _, old, new in KIN_SWAPS:
        s, c = swap(s, old, new)
        n += c
    open(path, 'w', encoding='utf-8').write(s)
    print('splice_v131 rules:', KINS_FILE, 'changed', n)


def main():
    D = json.load(open(DATA, encoding='utf-8'))
    kins = {k['id']: k for k in D['kins']}
    n = 0
    for kid, field, old, new in KIN_SWAPS:
        kins[kid][field], c = swap(kins[kid][field], old, new)
        n += c
    json.dump(D, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print('splice_v131 data: changed', n)


if __name__ == '__main__':
    if len(sys.argv) >= 3 and sys.argv[1] == '--rules':
        rules(sys.argv[2])
    else:
        main()
