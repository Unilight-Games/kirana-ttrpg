import re, json, os
# v1.22: ชี้ไฟล์ต้นทางและโฟลเดอร์ผลลัพธ์ได้ด้วย KIRANA_SETS_SRC และ KIRANA_OUT (ค่าเดิมคงไว้)
SRC = os.environ.get("KIRANA_SETS_SRC", "/mnt/user-data/outputs/rules/Starter Set - ชุดไอเทมเริ่มต้น.md")  # สำเนาล่าสุดของไฟล์ในไดรฟ์ (v1.20: ชี้มาที่สำเนาที่แก้แล้ว)
lines = open(SRC, encoding="utf-8").read().split("\n")
def clean(s):
    s = re.sub(r"\*\*", "", s)
    return re.sub(r"\s+", " ", s).strip()

sets = []
cur = None
common = {"items": [], "money": 15}
in_common = False
for i, l in enumerate(lines, 1):
    if l.startswith("## 2."):
        in_common = True; continue
    if l.startswith("## 3."):
        in_common = False
    if in_common and l.startswith("|") and not l.startswith("|---") and "ไอเทม" not in l:
        cells = [clean(c) for c in l.strip("|").split("|")]
        if cells[0].startswith("รวม"): continue
        common["items"].append({"name": cells[0], "price": cells[1], "weight": cells[2], "effect": cells[3]})
    m = re.match(r"^### 4\.(\d+)\s+(.*?)\s*\((.*?)\)\s*$", l)
    if m:
        cur = {"id": int(m.group(1)), "nameEn": m.group(2).strip(), "nameTh": m.group(3).strip(), "archetype": "", "desc": "", "items": [],
               "total": "", "totalWeight": "", "income": "", "outfit": "", "backgrounds": "", "notes": ""}
        sets.append(cur); continue
    if l.startswith("## 5."):
        cur = None
    if cur is None: continue
    c = clean(l)
    if not c: continue
    if c.startswith("แนวทาง:"):
        cur["archetype"] = c.split(":", 1)[1].strip(); continue
    if l.startswith("|"):
        if l.startswith("|---") or "ไอเทม" in c: continue
        cells = [clean(x) for x in l.strip().strip("|").split("|")]
        if cells[0].startswith("รวม"):
            cur["total"], cur["totalWeight"] = cells[1], cells[2]; continue
        name = cells[0]
        flags = []
        if "(ข้อ 6)" in name: flags.append("ข้อ 6")
        if "(ข้อยกเว้นข้อ 4)" in name: flags.append("ข้อยกเว้นข้อ 4")
        name = re.sub(r"\((ข้อ 6|ข้อยกเว้นข้อ 4)\)", "", name).strip()
        cur["items"].append({"name": name, "price": cells[1], "weight": cells[2], "effect": cells[3] if len(cells) > 3 else "", "flags": flags})
        continue
    for key, f in [("ตั้งตัวด้วย", "income"), ("แต่งกายแนะนำ", "outfit"), ("พื้นหลังที่เข้าชุด", "backgrounds"), ("หมายเหตุ", "notes")]:
        if c.lstrip("- ").startswith(key):
            cur[f] = c.lstrip("- ").split(":", 1)[1].strip(); break
    else:
        if not cur["items"] and not cur["desc"]:
            cur["desc"] = c
        elif not cur["items"]:
            cur["desc"] += " " + c

out = {"common": common, "sets": sets, "rules": []}
# rules list from section 1
sec = False
for l in lines:
    if l.startswith("## 1."): sec = True; continue
    if l.startswith("## 2."): break
    if sec and re.match(r"^\d+\.", l.strip()):
        out["rules"].append(clean(re.sub(r"^\d+\.\s*", "", l.strip())))
json.dump(out, open(os.path.join(os.environ.get("KIRANA_OUT", "/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/"), "sets.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(sets), len(common["items"]), len(out["rules"]))
for s in sets: print(s["id"], s["nameEn"], s["archetype"], len(s["items"]), s["total"], s["totalWeight"], bool(s["desc"]), bool(s["backgrounds"]))
