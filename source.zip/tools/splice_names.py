# -*- coding: utf-8 -*-
"""v1.23: ใส่คลังคำตั้งชื่อ (names.json ที่ parse_names.py เพิ่งสร้าง) ลง tools/data.json เป็น DATA.names
หมวดอื่นใน data.json ไม่ถูกแตะ · splice_data.py คัดลอก data.json รุ่นก่อนทั้งก้อน DATA.names จึงอยู่ต่อเมื่อแก้ไฟล์กฎรอบหน้า
ใช้: KIRANA_OUT=<โฟลเดอร์ที่มี names.json> python3 tools/splice_names.py"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(HERE, "data.json")
names = json.load(open(os.path.join(os.environ["KIRANA_OUT"], "names.json"), encoding="utf-8"))
data = json.load(open(DATA_PATH, encoding="utf-8"))
before = {k: len(json.dumps(v, ensure_ascii=False)) for k, v in data.items() if k != "names"}
data["names"] = names
after = {k: len(json.dumps(v, ensure_ascii=False)) for k, v in data.items() if k != "names"}
assert before == after, "หมวดอื่นใน data.json เปลี่ยน"
open(DATA_PATH, "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
print("DATA.names:", sum(len(v) for v in names["words"].values()), "คำ ·", len(names["langs"]), "ภาษา ·",
      sum(len(L["ways"]) for L in names["langs"]), "วิถี")
