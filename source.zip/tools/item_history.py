# -*- coding: utf-8 -*-
"""ข้อความเอฟเฟกต์รุ่นเก่าของไอเทมมาตรฐาน (v1.20)

ตัวละครเก็บ "สำเนา" ของไอเทมไว้ในกระเป๋าและช่องสวมใส่ ({name, effect, weight}) ตอนได้ของมา
เมื่อไฟล์กฎแก้ข้อความของไอเทมชิ้นนั้นทีหลัง สำเนาในตัวละครจะค้างเป็นข้อความเก่า
(เช่น โล่ฮีตเตอร์ของชุด The Vanguard ที่สร้างก่อน v1.6 ยังเขียนว่า 2 PDMG)

ไฟล์ item_text_history.json เก็บข้อความเก่าทุกข้อความที่เคยขึ้นเว็บ แยกตามที่มาของสำเนา
  s = ไอเทมในชุดเริ่มต้น (line = ชื่อชุด)   c = ชุดยังชีพ   i = คลังไอเทม (Item All.md)
build_data.py เรียก update() ทุกครั้งที่สร้างข้อมูล: ข้อความของรุ่นที่ปล่อยล่าสุดซึ่งต่างจากข้อความใหม่จะถูกเติมเข้าประวัติเอง
แล้ว build_fix() ทำตาราง META.itemTextFix = {texts:[ข้อความปัจจุบัน], map:{ชื่อไอเทม:{กุญแจของข้อความเก่า: ลำดับใน texts}}}
ฝั่งเว็บ (migrateItemText ใน src/ui.js) เทียบชื่อตรงตัวและกุญแจของข้อความตรงตัวเท่านั้น ของที่ผู้เล่นพิมพ์เองหรือแก้เองจึงไม่ถูกแตะ

ใช้เอง: python3 item_history.py seed <data.json รุ่นปัจจุบัน> <data.json รุ่นเก่า ...>   (ทำครั้งเดียวตอนเริ่มเก็บประวัติ)"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
HIST = os.path.join(HERE, "item_text_history.json")


def clean_alt(n):
    return re.sub(r"\s*ต้องการ\s+[A-Z]+\s*\d+\s*$", "", re.sub(r"^หรือ\s+", "", str(n or ""))).strip()


def requirement(n):
    m = re.search(r"ต้องการ\s+([A-Z]+)\s*(\d+)", str(n or ""))
    return f"{m.group(1)} {m.group(2)}" if m else None


def stored_name(n):
    """ชื่อที่ตัวละครเก็บ (ตรงกับ cleanAltName + ตัด (เสนอ) และ ×N ใน src/ui.js กับ src/sheet.js)"""
    return re.sub(r"\s*×\s*\d+", "", re.sub(r"\(เสนอ\)\s*", "", clean_alt(n))).strip()


def forms(data):
    """ทุกสำเนาที่ตัวละครจะได้จากข้อมูลรุ่นนี้ → (kind, line, ชื่อที่เก็บ, เอฟเฟกต์ที่เก็บ)"""
    sets = data.get("sets") or {}
    if isinstance(sets, dict):
        for s in sets.get("sets") or []:
            for it in s.get("items") or []:
                r = requirement(it.get("name"))
                yield ("s", s.get("nameEn") or "", stored_name(it.get("name")), (it.get("effect") or "") + (f" · ต้องการ {r}" if r else ""))
        for it in (sets.get("common") or {}).get("items") or []:
            yield ("c", "common", stored_name(it.get("name")), it.get("effect") or "")
    for it in data.get("items") or []:
        yield ("i", "catalog", stored_name(it.get("name")), it.get("effect") or "")


def txt_key(s):
    """ต้องให้ผลตรงกับ txtKey() ใน src/ui.js: FNV-1a 32 บิตบนหน่วย UTF-16 ต่อด้วยความยาว (ฐาน 36)"""
    b = s.encode("utf-16-le")
    h = 0x811C9DC5
    for i in range(0, len(b), 2):
        h ^= b[i] | (b[i + 1] << 8)
        h = (h * 0x01000193) & 0xFFFFFFFF
    return _b36(h) + "." + _b36(len(b) // 2)


def _b36(n):
    d = "0123456789abcdefghijklmnopqrstuvwxyz"
    if n == 0:
        return "0"
    out = ""
    while n:
        n, r = divmod(n, 36)
        out = d[r] + out
    return out


def load():
    if not os.path.exists(HIST):
        return {"about": "ข้อความเอฟเฟกต์รุ่นเก่าของไอเทมมาตรฐานที่เคยขึ้นเว็บ ดู tools/item_history.py · kind: s ชุดเริ่มต้น c ชุดยังชีพ i คลังไอเทม", "old": []}
    return json.load(open(HIST, encoding="utf-8"))


def save(h):
    h["old"].sort(key=lambda e: (e["name"], e["kind"], e["line"], e["text"]))
    json.dump(h, open(HIST, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def _renamer(data):
    ir = (data.get("meta") or {}).get("itemRenames") or {}

    def now(n):
        seen = set()
        while n in ir and n not in seen:
            seen.add(n)
            n = ir[n]
        return n
    return now


def _current(data):
    cur = {}
    for k, line, n, e in forms(data):
        cur[(k, line, n)] = e
    return cur


def update(data, prev, label):
    """เติมข้อความของรุ่นก่อน (prev) ที่ต่างจากรุ่นใหม่ (data) เข้าประวัติ · คืนจำนวนที่เติม"""
    h = load()
    now = _renamer(data)
    cur = _current(data)
    have = {(e["kind"], e["line"], now(e["name"]), e["text"]) for e in h["old"]}
    added = 0
    for k, line, n, e in forms(prev or {}):
        key = (k, line, now(n))
        if not e or cur.get(key) == e or (k, line, now(n), e) in have:
            continue
        h["old"].append({"kind": k, "line": line, "name": now(n), "text": e, "seen": label})
        have.add((k, line, now(n), e))
        added += 1
    for e in h["old"]:
        e["name"] = now(e["name"])
    save(h)
    return added


def build_fix(data):
    """ตารางที่เว็บใช้ย้ายข้อความเก่าในตัวละครเป็นข้อความปัจจุบัน"""
    h = load()
    now = _renamer(data)
    cur = _current(data)
    cur_texts = {}
    for (k, line, n), e in cur.items():
        cur_texts.setdefault(n, set()).add(e)
    pairs = {}      # name -> {key: ข้อความใหม่}
    clash = set()
    skipped = 0
    for e in h["old"]:
        n = now(e["name"])
        tgt = cur.get((e["kind"], e["line"], n))
        if tgt is None:   # ไอเทมถูกถอดจากชุดนั้นแล้ว: ใช้ข้อความของแหล่งชนิดเดียวกันถ้ามีแบบเดียว
            same = {v for (k, line, nn), v in cur.items() if k == e["kind"] and nn == n}
            tgt = next(iter(same)) if len(same) == 1 else None
        if tgt is None or tgt == e["text"] or e["text"] in cur_texts.get(n, ()):
            skipped += 1
            continue
        key = txt_key(e["text"])
        d = pairs.setdefault(n, {})
        if key in d and d[key] != tgt:
            clash.add((n, key))
        d[key] = tgt
    for n, key in clash:      # ข้อความเก่าเดียวกันชี้ไปข้อความใหม่สองแบบ: ไม่ย้าย
        pairs[n].pop(key, None)
    texts = sorted({t for d in pairs.values() for t in d.values()})
    idx = {t: i for i, t in enumerate(texts)}
    fix = {"texts": texts, "map": {n: {k: idx[t] for k, t in sorted(d.items())} for n, d in sorted(pairs.items()) if d}}
    return fix, {"old": len(h["old"]), "names": len(fix["map"]), "keys": sum(len(d) for d in fix["map"].values()), "texts": len(texts), "clash": len(clash), "skipped": skipped}


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "seed":
        cur = json.load(open(sys.argv[2], encoding="utf-8"))
        n = 0
        for p in sys.argv[3:]:
            lab = os.path.basename(p).replace("data.", "").replace(".json", "")
            n += update(cur, json.load(open(p, encoding="utf-8")), lab)
        fix, st = build_fix(cur)
        print("เติม", n, "ข้อความ", st)
    else:
        print(__doc__)
