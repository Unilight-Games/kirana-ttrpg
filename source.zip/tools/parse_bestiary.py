# -*- coding: utf-8 -*-
"""v1.27 (Non สั่ง 16 พ.ย. 2026): อ่านสแตตบล็อกจาก Fauna, Enemy & Companion.md เป็นข้อมูลแม่แบบ NPC ของเว็บ

  python3 tools/parse_bestiary.py "<Fauna, Enemy & Companion.md>" tools/bestiary.json

ผลลัพธ์ {v, sizes, groups, entries} · entries หนึ่งรายการต่อสัตว์หรือ NPC หนึ่งตัวในเอกสาร
  type fauna (หัวข้อ # Tiny ถึง # Huge) หรือ humanoid (ใต้ # NPC แยกกลุ่ม Imperial Bandit Freelance)
  name en size speed mods hp mp tgh ap init reflex might sight armorAll statsExtra
  attacks [{name, text}] defend (parry evade both none) defendNote reactions abilities [{name, text}]
  drops [{t: g c u x e, r, name, qty, note}] · g ได้แน่นอน · c ทอย 1d6 ตามช่วง · u ทอย 1d6 ถ้าออกตาม r · x ทอย 1d10 ถ้าออกตาม r · e ยุทโธปกรณ์ทอย 1d6 ตามช่วง
  equip [ชื่อของที่สวมหรือถือ] · concept แนวคิดของตัวละคร
สคริปต์หยุดพร้อมบอกจุดที่อ่านไม่ออก ถ้าจำนวนรายการหรือช่องสำคัญไม่ครบ"""
import json, re, sys

SRC = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/uploads/Kirana Lore & TTRPG Data/Kirana TTRPG Data/Fauna, Enemy & Companion.md"
OUT = sys.argv[2] if len(sys.argv) > 2 else None

def unesc(s):
    return re.sub(r"\\([-+=.#*_()\[\]!>|])", r"\1", s)
def plain(s):
    s = unesc(s).replace("**", "").replace("***", "")
    s = re.sub(r"(?<!\w)\*(?!\s)([^*]+?)\*(?!\w)", r"\1", s)  # ตัวเอียง *ข้อความ*
    return re.sub(r"\s+", " ", s).strip()

raw = open(SRC, encoding="utf-8").read().split("\n")
L = [unesc(x.rstrip()) for x in raw]

SIZE_MAP = [("จิ๋ว", "Tiny"), ("Tiny", "Tiny"), ("เล็ก", "Small"), ("Small", "Small"), ("ปานกลาง", "Medium"), ("กลาง", "Medium"), ("Medium", "Medium"),
            ("มหึมา", "Huge"), ("Huge", "Huge"), ("ใหญ่", "Large"), ("Large", "Large")]
def size_of(v):
    for k, s in SIZE_MAP:
        if k in v: return s
    return None

# ---- ตารางขนาด ----
sizes = []
for x in L:
    m = re.match(r"^\|\s*\*\*(Tiny|Small|Medium|Large|Huge)\*\*\s*\|\s*([^|]+)\|\s*([^|]+)\|\s*([^|]+)\|\s*([^|]+)\|", x)
    if m:
        k, th, tg, ar, note = [plain(g) for g in m.groups()]
        sizes.append({"key": k, "th": th, "tgh": 0 if tg in ("-", "") else tg, "armor": 0 if ar in ("-", "") else ar, "note": note})
assert [s["key"] for s in sizes] == ["Tiny", "Small", "Medium", "Large", "Huge"], sizes
# หัวข้อ Tiny เขียน -1 All Toughness ไว้ใต้หัวข้อ แต่ตารางเว้นไว้ เก็บตามข้อความใต้หัวข้อ
for i, x in enumerate(L):
    if x.strip() == "# Tiny":
        blk = " ".join(L[i:i+6])
        if "-1 All Toughness" in blk: sizes[0]["tgh"] = "-1 All Toughness"

# ---- ขอบเขตของแต่ละส่วน ----
npc_at = next(i for i, x in enumerate(L) if x.strip() == "# NPC")
size_heads = {i: x.strip()[2:] for i, x in enumerate(L) if i < npc_at and re.match(r"^# (Tiny|Small|Medium|Large|Huge)\s*$", x.strip())}
group_heads = {i: x.strip()[2:] for i, x in enumerate(L) if i > npc_at and re.match(r"^# \S", x.strip())}

def next_nonempty(i):
    j = i + 1
    while j < len(L) and not L[j].strip(): j += 1
    return j

starts = []
for i, x in enumerate(L):
    if i < npc_at:
        m = re.match(r"^\* \*\*([^*]+)\*\*\s*$", x)
        if m and re.match(r"^\s+\* \*\*ขนาด", L[next_nonempty(i)]):
            starts.append((i, "fauna", m.group(1)))
    else:
        m = re.match(r"^### \*\*(?:\d+\.\s*)?([^*]+)\*\*\s*$", x)
        if m and any("ขนาด" in L[j] for j in range(i + 1, min(len(L), i + 12))):
            starts.append((i, "humanoid", m.group(1)))

def section_of(i, heads):
    best = None
    for k, v in heads.items():
        if k <= i and (best is None or k > best[0]): best = (k, v)
    return best[1] if best else None

def split_name(s):
    s = plain(s)
    s = re.sub(r"\s+-\s+.*$", "", s)  # "นักปล้นสดม (Raider) - หน่วยรบพื้นฐาน"
    m = re.match(r"^(.*?)\s*\(([^()]*[A-Za-z][^()]*)\)\s*(.*)$", s)
    if m: return s, m.group(1).strip(), m.group(2).strip()
    return s, s, ""

KV = re.compile(r"^(\s*)\*\s+\*\*([^*]+?)\*\*\s*(.*)$")
def kv(line):
    m = KV.match(line)
    if not m: return None
    ind, key, val = len(m.group(1)), m.group(2).strip(), m.group(3).strip()
    if key.endswith(":"): key = key[:-1].strip()
    elif val.startswith(":"): val = val[1:].strip()
    elif ":" in key and not val:
        key, val = [p.strip() for p in key.split(":", 1)]
    return ind, key, val

ITEM_QTY = re.compile(r"^(\d+d\d+(?:\s*[+\-]\s*\d+)?|\d+(?:-\d+)?|X)\s*(.*)$")
def item_of(text):
    """ชื่อของ (ชื่ออังกฤษ) จำนวน หน่วย (หมายเหตุ) -> {name, qty, note}"""
    t = plain(text).rstrip(".")
    t = re.sub(r"^\d+(?:-\d+)?:\s*", "", t)
    m = re.match(r"^(\d+(?:d\d+)?)\s+(.*)$", t)  # "15 เหรียญ"
    if m and not re.search(r"\([A-Za-z]", m.group(2)[:4]):
        return {"name": m.group(2), "qty": m.group(1), "note": ""}
    m = re.match(r"^(.*?\([^()]*[A-Za-z][^()]*\))\s*(.*)$", t)
    name, rest = (m.group(1), m.group(2)) if m else (t, "")
    if not m:
        m2 = re.match(r"^(.*?)\s+(\d+d\d+(?:\s*[+\-]\s*\d+)?|\d+|X)\s+(\S+)\s*(.*)$", t)
        if m2: return {"name": m2.group(1), "qty": m2.group(2).replace(" ", ""), "note": (m2.group(3) + " " + m2.group(4)).strip()}
        return {"name": t, "qty": "", "note": ""}
    q = ITEM_QTY.match(rest)
    if q and rest:
        return {"name": name.strip(), "qty": q.group(1).replace(" ", ""), "note": q.group(2).strip()}
    return {"name": name.strip(), "qty": "", "note": rest.strip()}

def trigger_of(text):
    m = re.search(r"หากออก\s*(\d+(?:\s*-\s*\d+)?)", text)
    return m.group(1).replace(" ", "") if m else ""
def die_of(text, dflt):
    m = re.search(r"ทอย\s*(1d\d+)|\((1d\d+)", text)
    return (m.group(1) or m.group(2)) if m else dflt

DEF = [("Parry หรือ Evade", "both"), ("Parry", "parry"), ("Evade", "evade"), ("None", "none")]
def defend_of(text):
    for k, v in DEF:
        if k in text: return v
    return ""

def parse_entry(a, b, typ, title):
    full, th, en = split_name(title)
    e = {"type": typ, "name": full, "th": th, "en": en, "size": None, "speed": "", "mods": {}, "hp": None, "mp": 0, "tgh": None, "ap": None,
         "init": 0, "reflex": None, "might": None, "sight": None, "armorAll": 0, "statsExtra": "", "attacks": [], "defend": "", "defendNote": "",
         "reactions": [], "abilities": [], "drops": [], "equip": [], "concept": "", "line": a + 1}
    if typ == "fauna": e["sizeGroup"] = section_of(a, size_heads)
    else: e["group"] = section_of(a, group_heads)
    mode = None; sub = None; drop = None; concept = []; last = None
    i = a + 1
    while i < b:
        x = L[i]; s = x.strip(); i += 1
        if not s or s in ("---", "###", "### ---") or s.startswith("# "): continue
        # แนวคิด และย่อหน้าก่อนช่องขนาด (NPC)
        if typ == "humanoid" and e["size"] is None:
            m = re.match(r"^\*?\s*\*\*แนวคิด:?\*\*:?\s*(.*)$", s)
            if m: concept.append(plain(m.group(1))); continue
            if not s.startswith("* **ขนาด"):
                if not s.startswith("* **") and not s.startswith("#"): concept.append(plain(s)); continue
        # หัวข้อของดรอปแบบตัวหนาทั้งบรรทัด (สัตว์)
        hm = re.match(r"^\*?\s*\*\*(ของ[^*]*?(?:Drop|ได้แน่นอน)[^*]*?):?\*\*:?\s*(.*)$", s)
        if hm:
            head = plain(hm.group(1))
            mode = "drops"; last = None
            if "Guaranteed" in head or "แน่นอน" in head: drop = ("g", "")
            elif "Rare" in head or "หายากมาก" in head: drop = ("x", trigger_of(head))
            elif "Uncommon" in head or "หายาก" in head: drop = ("u", trigger_of(head))
            else: drop = ("c", "")
            continue
        # หัวยุทโธปกรณ์แบบตัวหนาทั้งบรรทัดที่ไม่ได้ขึ้นด้วยจุด (กลุ่ม Bandit: "**ยุทโธปกรณ์ (Equipment - ...): ทอย 1d6**")
        if re.match(r"^\*\*ยุทโธปกรณ์", s):
            mode = "drops"; drop = ("e", ""); last = None; continue
        r = kv(x)
        if r:
            ind, key, val = r
            if mode == "drops" and drop and drop[0] in ("c", "e") and re.match(r"^\d+(?:-\d+)?$", key):
                for part in re.split(r"\s+และ\s+", val):
                    it = item_of(part); it.update({"t": drop[0], "r": key}); e["drops"].append(it); last = it
                continue
            if key.startswith("ระดับวัตถุดิบ") and last is not None:
                last["note"] = (last["note"] + " · " if last["note"] else "") + "ระดับวัตถุดิบ: " + plain(val); continue
            if key == "ขนาด": e["size"] = size_of(val); mode = None; continue
            if key in ("Speed", "ความเร็ว"): e["speed"] = plain(val).replace("ความเร็วในการ", ""); mode = None; continue
            if key.startswith("ค่าพลังดัดแปลง"):
                for st, v in re.findall(r"(STR|AGI|VIT|PER|INF|INT)\s*Mod\s*([+\-−]?\s*\d+)", val):
                    e["mods"][st] = int(v.replace("−", "-").replace(" ", "").replace("+", ""))
                mode = None; continue
            if key.startswith("ค่าสถานะ"):
                v = plain(val); extra = []
                if "(" in key: extra.append(plain(key[key.index("("):]))
                def num(rx, cast=int):
                    m = re.search(rx, v); return cast(m.group(1).replace(" ", "").replace("+", "")) if m else None
                e["hp"] = num(r"HP\s*(\d+)"); e["mp"] = num(r"MP\s*(\d+)") or 0; e["tgh"] = num(r"Toughness\s*(\d+)"); e["ap"] = num(r"AP\s*(\d+)")
                e["init"] = num(r"Initiative\s*([+\-]?\s*\d+)") or 0; e["reflex"] = num(r"Reflex\s*([+\-]?\s*\d+)"); e["might"] = num(r"Might\s*([+\-]?\s*\d+)"); e["sight"] = num(r"Sight\s*([+\-]?\s*\d+)")
                e["armorAll"] = num(r"([+\-]?\d+)\s*All Armor") or 0
                m = re.search(r"Toughness\s*\d+\s*(\([^)]*\))", v)
                if m: extra.append("Toughness " + m.group(1))
                for m in re.finditer(r"([+\-]?\d+\s*Sorcer\w*\s*Resist\w*)", v): extra.append(m.group(1))
                e["statsExtra"] = " · ".join(extra); mode = None; continue
            if key.startswith("การโจมตี"):
                mode = "attacks"; last = None
                if ":" in key or val:
                    nm = key.split(":", 1)[1].strip() if ":" in key else ""
                    if nm: e["attacks"].append({"name": plain(nm), "text": plain(val)}); last = e["attacks"][-1]
                    elif val: e["attacks"].append({"name": "", "text": plain(val)}); last = e["attacks"][-1]
                continue
            if key.startswith("Reaction") or key.startswith("ปฏิกิริยา"):
                mode = "reactions"; last = None; e["defend"] = defend_of(key + " " + val) or e["defend"]; continue
            if key.startswith("ป้องกัน") and mode == "reactions":
                e["defend"] = defend_of(val) or e["defend"]; e["defendNote"] = plain(val); continue
            if key.startswith("ความสามารถพิเศษ"): mode = "abilities"; last = None; continue
            if key.startswith("ยุทโธปกรณ์"):
                mode = "drops"; drop = ("e", ""); last = None
                pack = plain(val).replace("ทอย 1d6", "").strip(" :")
                if pack and not pack.startswith("ทอย"): e["equipPack"] = pack
                continue
            if key.startswith("ของที่อาจได้รับ"): mode = "drops2"; continue
            if mode == "drops2":
                k2 = plain(key)
                t = "g" if k2.startswith("Guaranteed") else "x" if k2.startswith("Rare") else "u" if k2.startswith("Uncommon") else "c" if k2.startswith("Common") else None
                if t is None: continue
                trig = trigger_of(k2)
                if t == "c":
                    for part in re.split(r";\s*", plain(val)):
                        m = re.match(r"^(\d+(?:-\d+)?):\s*(.*)$", part.strip())
                        if m: it = item_of(m.group(2)); it.update({"t": "c", "r": m.group(1)}); e["drops"].append(it)
                else:
                    for part in re.split(r",\s*(?![^()]*\))", plain(val)):
                        if part.strip(): it = item_of(part); it.update({"t": t, "r": trig}); e["drops"].append(it)
                continue
            if mode == "drops" and drop and drop[0] == "e" and key in ("อาวุธ", "ชุดเกราะ", "อุปกรณ์"):
                for part in re.split(r",\s*(?![^()]*\))", plain(val)):
                    if part.strip(): e["equip"].append(item_of(part)["name"])
                continue
            # ความสามารถหรือ Reaction พิเศษ
            if mode in ("reactions", "abilities"):
                if ind >= 2 or key[:1] not in ("ประเ", "เง", "ผล"):
                    if mode == "abilities" and ind == 0 and last is not None and key in ("ประเภท", "เงื่อนไข", "ผลกระทบ", "การหลุดพ้นจากการถูกกลืน", "หมายเหตุ"):
                        last["text"] = (last["text"] + " · " + key + ": " + plain(val)).strip(" ·"); continue
                    tgt = e["reactions"] if mode == "reactions" else e["abilities"]
                    tgt.append({"name": plain(key), "text": plain(val)}); last = tgt[-1]; continue
            if mode == "attacks":
                e["attacks"].append({"name": plain(key), "text": plain(val)}); last = e["attacks"][-1]; continue
            if mode == "drops" and drop:
                it = item_of(key + (" " + val if val else "")); it.update({"t": drop[0], "r": drop[1]})
                m = re.search(r"\((\d+(?:-\d+)?)\)\s*$", plain(key + " " + val))
                if drop[0] == "e" and m:  # ช่วงแต้มท้ายบรรทัด เช่น "กระบองไม้ (Wood Club) (1-3)" ตัดออกจากชื่อและหมายเหตุ
                    it = item_of(re.sub(r"\(\d+(?:-\d+)?\)\s*$", "", plain(key + " " + val)).strip()); it.update({"t": "e", "r": m.group(1)})
                e["drops"].append(it); last = it; continue
            continue
        # บรรทัดรายการที่ไม่มีตัวหนาเป็นหัว
        m = re.match(r"^(\s*)\*\s+(.*)$", x)
        if m:
            ind, txt = len(m.group(1)), m.group(2).strip()
            lab = plain(txt)
            # หัวช่องที่ไม่ได้ทำตัวหนา (Omni Raptor Dunkator และอีกหลายตัว)
            if re.match(r"^การโจมตี\s*:", lab):
                mode = "attacks"; last = None; rest = lab.split(":", 1)[1].strip()
                if rest:
                    nm = re.match(r"^(.*?\))\s*:\s*(.*)$", rest)
                    e["attacks"].append({"name": nm.group(1), "text": nm.group(2)} if nm else {"name": "", "text": rest}); last = e["attacks"][-1]
                continue
            if re.match(r"^(Reaction|ปฏิกิริยา)", lab): mode = "reactions"; last = None; e["defend"] = defend_of(lab) or e["defend"]; continue
            if re.match(r"^ความสามารถพิเศษ", lab): mode = "abilities"; last = None; continue
            if mode == "attacks":
                nm = re.match(r"^(.*?\))\s*:\s*(.*)$", plain(txt))
                if nm: e["attacks"].append({"name": nm.group(1), "text": nm.group(2)}); last = e["attacks"][-1]
                elif last is not None: last["text"] = (last["text"] + " " + plain(txt)).strip()
                continue
            if mode == "drops" and drop:
                t = plain(txt)
                if drop[0] in ("c", "e"):
                    mr = re.match(r"^(\d+(?:-\d+)?):\s*(.*)$", t)
                    if mr:
                        for part in re.split(r"\s+และ\s+", mr.group(2)):
                            it = item_of(part); it.update({"t": drop[0], "r": mr.group(1)}); e["drops"].append(it); last = it
                        continue
                    if drop[0] == "e":
                        mr = re.search(r"\((\d+(?:-\d+)?)\)\s*$", t)
                        if mr:
                            body = re.sub(r"\(\d+(?:-\d+)?\)\s*$", "", t).strip()
                            for part in re.split(r"\s+และ\s+", body):
                                it = item_of(part); it.update({"t": "e", "r": mr.group(1)}); e["drops"].append(it); last = it
                            continue
                it = item_of(t); it.update({"t": drop[0], "r": drop[1]}); e["drops"].append(it); last = it; continue
            if mode in ("reactions", "abilities") and last is not None:
                last["text"] = (last["text"] + " " + plain(txt)).strip(); continue
            continue
        # บรรทัดต่อของการโจมตีที่ย่อหน้าไว้
        if mode == "attacks" and last is not None and x.startswith("   "):
            last["text"] = (last["text"] + " " + plain(s)).strip(); continue
        if typ == "humanoid" and e["size"] is None: concept.append(plain(s))
    e["concept"] = " ".join(c for c in concept if c).strip()
    # ชื่อของที่สวมใส่ (จากตารางยุทโธปกรณ์ถ้าไม่มีรายการชุด)
    if not e["equip"]:
        e["equip"] = [d["name"] for d in e["drops"] if d["t"] == "e"]
    e["attacks"] = [a for a in e["attacks"] if a["name"] or a["text"]]
    return e

entries = []
bounds = [s[0] for s in starts] + [len(L)]
for k, (a, typ, title) in enumerate(starts):
    b = bounds[k + 1]
    for j in range(a + 1, b):
        if L[j].strip().startswith("# "): b = j; break
    entries.append(parse_entry(a, b, typ, title))

# ---- กลุ่ม NPC: ตารางปรับระดับความท้าทาย และการสวมบทบาท ----
groups = []
gkeys = sorted(group_heads.items())
for gi, (gl, gname) in enumerate(gkeys):
    if gname == "NPC": continue
    end = gkeys[gi + 1][0] if gi + 1 < len(gkeys) else len(L)
    first = min([s[0] for s in starts if gl < s[0] < end] or [end])
    scaling = []
    for x in L[gl:first]:
        m = re.match(r"^\|\s*\*\*([^*]+)\*\*\s*\(?([^)|]*)\)?\s*\|\s*([^|]+)\|\s*([^|]+)\|", x)
        if m: scaling.append({"tier": plain(m.group(1) + (" (" + m.group(2).strip() + ")" if m.group(2).strip() else "")), "desc": plain(m.group(3)), "adj": plain(m.group(4))})
    rp = []; on = False
    for x in L[gl:first]:
        if "การสวมบทบาท" in x: on = True; continue
        if on:
            t = plain(re.sub(r"^\s*\*\s*(#+\s*)?", "", x)).strip("# ")
            if t and t != "---": rp.append(t)
    groups.append({"key": gname, "scaling": scaling, "roleplay": rp})

# ---- ตรวจความครบ ----
fa = [e for e in entries if e["type"] == "fauna"]; hu = [e for e in entries if e["type"] == "humanoid"]
problems = []
for e in entries:
    for f in ("size", "hp", "tgh"):
        if e[f] in (None, ""): problems.append(f"{e['name']}: ไม่มี {f}")
    if len(e["mods"]) != 6: problems.append(f"{e['name']}: ค่าพลังดัดแปลง {len(e['mods'])} ค่า")
    if not e["attacks"]: problems.append(f"{e['name']}: ไม่มีการโจมตี")
    if not e["defend"]: problems.append(f"{e['name']}: ไม่รู้วิธีป้องกัน")
    if not e["abilities"]: problems.append(f"{e['name']}: ไม่มีความสามารถพิเศษ")
    if not any(d["t"] == "g" for d in e["drops"]): problems.append(f"{e['name']}: ไม่มีของที่ได้แน่นอน")
print(f"สัตว์ {len(fa)} · ผู้คน {len(hu)} · กลุ่ม {[g['key'] for g in groups]}")
print("ความสามารถพิเศษ", sum(len(e["abilities"]) for e in entries), "· Reaction พิเศษ", sum(len(e["reactions"]) for e in entries), "· การโจมตี", sum(len(e["attacks"]) for e in entries), "· ของดรอป", sum(len(e["drops"]) for e in entries))
if problems:
    print("\n".join(problems)); sys.exit(1)
out = {"v": 1, "src": "Fauna, Enemy & Companion.md", "sizes": sizes, "groups": groups, "entries": entries}
if OUT: json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1); print("เขียน", OUT)
