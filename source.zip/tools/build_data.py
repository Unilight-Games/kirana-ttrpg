import json, re
S = "/tmp/claude-0/-home-claude/f0543027-ed97-59e5-9bde-8d27fc4affc6/scratchpad/"
kins = json.load(open(S + "kins.json", encoding="utf-8"))
skills = json.load(open(S + "skills.json", encoding="utf-8"))
knowledge = json.load(open(S + "knowledge.json", encoding="utf-8"))
sets = json.load(open(S + "sets.json", encoding="utf-8"))

HUMAN = {"lunaryn", "solrin", "nightkin", "rimmen", "norlan"}
KIN_SKILL_GROUP = {"Lunaryn": "lunaryn", "Solrin": "solrin", "Nightkin": "nightkin", "Handerlaw Dwarves": "handerlaw-dwarves",
                   "Night Alves": "night-alves", "Day Alves": "day-alves", "Floran": "floran", "Swalan": "swalan",
                   "Orcarim": "orcarim", "Necrobug": "necrobug"}

for k in kins:
    sz = []
    for key, lab in [("Small", "Small"), ("Medium", "Medium"), ("Large", "Large"), ("Huge", "Huge")]:
        if re.search(r"\(" + key + r"\)|\b" + key + r"\b", k["size"]):
            sz.append(lab)
    if not sz:
        sz = ["Medium"]
    k["sizes"] = sz
    for s in k["starterSkills"]:
        s["name"] = re.sub(r"//.*?//", "", s["name"]).strip()
    k["notes"] = k.pop("misc")
    # knowledge grants from benefits (hand-encoded from benefit texts)
    g = []
    if k["id"] in ("lunaryn", "solrin", "nightkin", "norlan"):
        g.append({"source": "Survivor's Legacy", "count": 1, "maxLevel": 2})
    if k["id"] == "rimmen":
        g.append({"source": "Cross-Cultural Adaptation", "fixed": "connection", "maxLevel": 2})
        g.append({"source": "Cross-Cultural Adaptation", "count": 1, "maxLevel": 2})
        k["adaptationChoice"] = ["Cold", "Hot", "Moisture"]
    if k["id"] == "handerlaw-dwarves":
        g.append({"source": "Mountain Craftsman", "fixed": "crafting", "maxLevel": 2})
    k["knowledgeGrants"] = g
    k["evolver"] = k["id"] == "lunaryn"
    k["uniqueGroups"] = (["Human (ทุกสายมนุษย์)"] if k["id"] in HUMAN else []) + [n for n, i in KIN_SKILL_GROUP.items() if i == k["id"]]

for s in skills:
    s.pop("line", None)
    s.pop("name", None)

GRANTED = [
    {"nameEn": "Nimble Grace", "nameTh": "พรสวรรค์อันปราดเปรียว", "category": "Granted", "subcategory": "Talent AGI", "type": "Passive",
     "effect": "การกระโดด วิ่ง คลานและปีนป่าย (8 DC) โดยไม่มีอุปสรรคหรือสิ่งที่ต้องไล่ล่า Auto Success, หลังใช้สกิล Kins Unique จะลบล้างสถานะ Unbalanced", "ipCost": None, "tags": ["Passive"], "extra": []},
    {"nameEn": "Robust", "nameTh": "ทรหด", "category": "Granted", "subcategory": "Talent VIT", "type": "Passive",
     "effect": "+2 Heat Insulation, Cold Insulation และ Moisture Insulation, +1 Sorcery Res.", "ipCost": None, "tags": ["Passive"], "extra": []},
    {"nameEn": "Observation Mastery", "nameTh": "สายตานักสังเกต", "category": "Granted", "subcategory": "Talent PER", "type": "Basic Action, 4 MP, 1 ครั้งต่อวัน",
     "effect": "มองเห็นคุณสมบัติผิดปกติของวัตถุ จุดอ่อนโดยคร่าว ๆ ของศัตรู พฤติกรรมการเคลื่อนไหวของศัตรู สมบัติหรือกับดักที่อยู่ในแผนที่ในระยะสายตามองเห็น ทอย PER Check โดยนับว่าการกระทำนั้นจะเป็น Auto Success ทันที", "ipCost": None, "tags": [], "extra": []},
    {"nameEn": "Interceptor", "nameTh": "ผู้สกัดกั้น", "category": "Granted", "subcategory": "Talent PER", "type": "Trait",
     "effect": "เมื่อเป้าหมายทำ Action ใดๆ คุณสามารถทอย 10 AGI Check หากสำเร็จ คุณจะสามารถใช้ 1 Action Point (จ่ายจาก Pool ของตัวเอง) นอกเทิร์นของตัวเองได้รอบละครั้ง โดยถือว่าการกระทำของคุณเกิดก่อน", "ipCost": None, "tags": [], "extra": []},
]
skills += GRANTED

# Talents (from Talent & Knowledge Proficiency.md, บรรทัด 1-60)
TALENTS = [
    {"key": "INT", "label": "พรสวรรค์สาย INT", "steps": [
        {"kind": "skills", "count": 2, "pools": ["Sorcery:Novice", "Kins Unique", "Qi"], "text": "เลือก Sorceries (เฉพาะ Novice), Kins Unique หรือ Qi มาใช้ได้ 2 Skill โดยคละได้"},
        {"kind": "knowledge", "count": 1, "from": ["sorceries", "alchemy"], "text": "Level Up Sorceries Knowledge หรือ Alchemy Knowledge 1 ระดับ"},
        {"kind": "knowledge", "count": 1, "exclude": ["sorceries", "alchemy"], "text": "Level Up Knowledge 1 ระดับ ที่ไม่ใช่ Sorceries และ Alchemy"}]},
    {"key": "PER", "label": "พรสวรรค์สาย PER", "steps": [
        {"kind": "choice", "count": 1, "options": ["Observation Mastery", "Interceptor"], "text": "เลือกได้ 1 อย่าง: Observation Mastery หรือ Interceptor"},
        {"kind": "knowledge", "fixed": "range", "text": "ได้รับ 1 Range Knowledge Level"},
        {"kind": "skills", "count": 1, "pools": ["Kins Unique", "Survival", "Trick"], "text": "เลือก Kins Unique, Survival หรือ Tricks มาใช้ได้ 1 Skill"}]},
    {"key": "INF", "label": "พรสวรรค์สาย INF", "steps": [
        {"kind": "knowledge", "count": 2, "from": ["connection", "lore"], "repeat": True, "text": "Level Up 2 Connection หรือ Lore Knowledge (คละได้)"},
        {"kind": "skills", "count": 1, "pools": ["*"], "text": "เลือก Skill (ระดับใด ๆ) 1 Skill มาไว้ใช้งาน"},
        {"kind": "grant", "skill": "Tactical Expert", "text": "ได้รับ Skill (Cast) Tactical Expert"}]},
    {"key": "AGI", "label": "พรสวรรค์สาย AGI", "steps": [
        {"kind": "grant", "skill": "Nimble Grace", "altPools": ["Tactical & General Skills"], "text": "ได้ Passive Skill พรสวรรค์อันปราดเปรียว (Nimble Grace) แต่ถ้ามี Nimble Grace อยู่แล้วจะได้เลือก 1 Tactical & General Skills ใด ๆ แทน"},
        {"kind": "skills", "count": 2, "pools": ["Qi", "Trick", "Unarmed & Melee Skills"], "text": "เลือกทักษะ 2 ทักษะจาก Qi, Trick หรือ Unarmed & Melee Skills (คละได้)"},
        {"kind": "knowledge", "count": 1, "from": ["burglary", "nature-survival"], "text": "Level Up 1 Burglary Knowledge Level หรือ 1 Nature & Survival Knowledge Level"}]},
    {"key": "STR", "label": "พรสวรรค์สาย STR", "steps": [
        {"kind": "skills", "count": 1, "pools": ["Qi", "Stance"], "text": "เลือกทักษะ Qi หรือ Stance มา 1 Skill"},
        {"kind": "skills", "count": 1, "pools": ["Martial:notQiStance", "Kins Unique"], "text": "เลือกทักษะ Martial (ที่ไม่ใช่ Qi หรือ Stance) 1 อย่าง หรือ Kins Unique 1 Skill"},
        {"kind": "knowledge", "fixed": "melee", "text": "Level Up Melee Knowledge 1 ระดับ"}]},
    {"key": "VIT", "label": "พรสวรรค์สาย VIT", "steps": [
        {"kind": "grant", "skill": "Robust", "text": "ได้ Passive Skill Robust: +2 Heat Insulation, Cold Insulation และ Moisture Insulation, +1 Sorcery Res."},
        {"kind": "skills", "count": 2, "pools": ["Kins Unique", "Stance", "Qi"], "text": "เลือกทักษะ Kins Unique, Stance หรือ Qi มาใช้ได้ 2 Skill (คละได้)"},
        {"kind": "knowledge", "count": 1, "from": ["nature-survival", "scavenging"], "text": "Level Up Nature & Survival หรือ Scavenging Knowledge 1 ระดับ"}]},
    {"key": "EDU", "label": "Educated (เลือกแทนสายค่าพลัง)", "steps": [
        {"kind": "knowledge", "count": 1, "maxBefore": 1, "text": "Level Up 1 Knowledge ที่ต้องการ (ห้ามใส่ใน Knowledge ที่มีระดับ 2 ขึ้นไป)"},
        {"kind": "skills", "count": 2, "pools": ["Sorcery:Novice", "Martial", "Survival"], "text": "เลือกทักษะ Sorceries (เฉพาะ Novice), Martial หรือ Survival 2 อย่าง"}]},
]

META = {
    "stats": [
        {"key": "STR", "th": "พละกำลัง", "use": "ต่อสู้ประชิด พังประตู ยก แบก ทุ่ม (Might)"},
        {"key": "AGI", "th": "ความคล่องแคล่ว", "use": "หลบหลีก (Evade) ซ่อนตัว อาวุธระยะไกล งานละเอียดของมือ"},
        {"key": "VIT", "th": "ความแข็งแรง", "use": "HP ต้านพิษ โรค ความเหนื่อยล้า สภาพอากาศ"},
        {"key": "PER", "th": "การรับรู้", "use": "สังเกต ค้นหา ปฏิกิริยา ลำดับเทิร์น มองทะลุภาพลวงตา"},
        {"key": "INF", "th": "อิทธิพล/บารมี", "use": "โน้มน้าว ข่มขู่ หลอกลวง สั่งการ ขวัญกำลังใจ และ Sanity"},
        {"key": "INT", "th": "ปัญญา", "use": "ความรู้ ความจำ เทคโนโลยี เหตุผล และเวทมนตร์"}],
    "personality": [
        {"id": "logic", "left": "Logic", "leftTh": "ตรรกะ", "leftUse": "วิเคราะห์ วางแผน ใช้เครื่องมือวิทยาศาสตร์", "right": "Instinct", "rightTh": "สัญชาตญาณ", "rightUse": "เอาตัวรอดตามสัญชาตญาณ ตอบสนองฉับพลันแบบไม่คิด"},
        {"id": "confront", "left": "Confront", "leftTh": "เผชิญหน้า", "leftUse": "พุ่งเข้าชนปัญหา ต่อสู้ ท้าทายตรง ๆ", "right": "Avoid", "rightTh": "หลบเลี่ยง", "rightUse": "วิ่งหนี หลีกเลี่ยงการปะทะ"},
        {"id": "brave", "left": "Brave", "leftTh": "กล้าหาญ", "leftUse": "สำรวจ ค้นหาความจริง สืบสวนสิ่งลี้ลับโดยไม่กลัว", "right": "Cautious", "rightTh": "ระแวดระวัง", "rightUse": "ระวังตัว จับผิดคำโกหก ป้องกันการซุ่มโจมตี"},
        {"id": "others", "left": "Others", "leftTh": "เห็นแก่ส่วนรวม", "leftUse": "ปกป้องเพื่อน ช่วยเหลือผู้คน รับการโจมตีแทน", "right": "Self", "rightTh": "รักตัวเอง", "rightUse": "เอาตัวรอดคนเดียว ทิ้งคนอื่น เห็นแก่ตัว"},
        {"id": "compassion", "left": "Compassionate", "leftTh": "เห็นอกเห็นใจ", "leftUse": "เยียวยาจิตใจ โน้มน้าวด้วยความเห็นอกเห็นใจ", "right": "Ruthless", "rightTh": "เลือดเย็น", "rightUse": "ตัดสินใจเด็ดขาด สังหาร ทำลายโดยไม่ลังเล"},
        {"id": "order", "left": "Order", "leftTh": "เจ้าระเบียบ", "leftUse": "ทำตามกฎ วินัย อ้างอำนาจ จัดระบบ", "right": "Chaos", "rightTh": "ไร้ระเบียบ", "rightUse": "แหกกฎ สร้างความวุ่นวาย คาดเดาไม่ได้ วิธีนอกคอก"}],
    "personalityBudget": [3, 2, 2, 1, 1, 0],
    "dc": [["ง่าย (Easy)", 5], ["ปานกลาง (Medium)", 7], ["ยาก (Hard)", 10], ["ยากมาก (Very Hard)", 12], ["เกือบเป็นไปไม่ได้ (Nearly Impossible)", 14]],
    "ipTable": [["จาก -5 ถึง +0", "3 IP ต่อขั้น"], ["+0 ไป +1", "3 IP"], ["+1 ไป +2", "4 IP"], ["+2 ไป +3", "5 IP"], ["+3 ไป +4", "6 IP"], ["+4 ไป +5", "7 IP"], ["Knowledge Level Up", "4 IP แล้ว +2 IP ตาม Level ที่มีก่อนหน้า"]],
    "bodyParts": [["head", "ศีรษะ"], ["torso", "ลำตัว"], ["armL", "แขนซ้าย"], ["armR", "แขนขวา"], ["legL", "ขาซ้าย"], ["legR", "ขาขวา"]],
    "hitLocation": "[2,3,11,12 = หัว] [4,9 ทอย 1d6: 1-3 ขาขวา, 4-6 แขนขวา] [5,10 ทอย 1d6: 1-3 ขาซ้าย, 4-6 แขนซ้าย] [6,7,8 = ลำตัว]",
}

GL = json.load(open(S + "glossary.json", encoding="utf-8"))
GL2 = {}
for k, v in GL.items():
    kk = re.sub(r"\s*\(.*?\)\s*$", "", k).strip()
    GL2[kk] = v
    if k == "Perfect Parry / Perfect Evade":
        GL2["Perfect Parry"] = v; GL2["Perfect Evade"] = v
    if k == "Critical Failed": GL2["Critical Failure"] = v
GL2["Saving Throw"]["th"] = GL2["Saving Throw"].get("th") or "ทอยป้องกัน"
META["archetypes"] = [
    {"id": "Tank", "th": "แทงค์", "weights": {"VIT": 3, "STR": 2, "PER": 1}, "talent": ["VIT", "STR"], "sets": ["The Vanguard", "The Priest"]},
    {"id": "Fighter", "th": "ไฟท์เตอร์", "weights": {"STR": 3, "VIT": 2, "AGI": 1}, "talent": ["STR", "VIT"], "sets": ["The Samurai", "The Craftsman"]},
    {"id": "Damage Dealer", "th": "ดาเมจดีลเลอร์", "weights": {"STR": 3, "AGI": 2, "PER": 1}, "talent": ["STR", "AGI"], "sets": ["The Gunslinger", "The Hunter"]},
    {"id": "Striker", "th": "สไตรเกอร์", "weights": {"AGI": 3, "STR": 2, "PER": 1}, "talent": ["AGI", "STR"], "sets": ["The Reaver", "The Gunslinger"]},
    {"id": "Skirmisher", "th": "สเคอร์มิชเชอร์", "weights": {"AGI": 3, "PER": 2, "VIT": 1}, "talent": ["AGI", "PER"], "sets": ["The Hunter", "The Wanderer"]},
    {"id": "Rogue", "th": "โร้ค", "weights": {"AGI": 3, "PER": 2, "INF": 1}, "talent": ["AGI", "PER"], "sets": ["The Convict", "The Wanderer"]},
    {"id": "Support", "th": "ซัพพอร์ต", "weights": {"INF": 3, "INT": 2, "VIT": 1}, "talent": ["INF", "INT"], "sets": ["The Priest", "The Plague Doctor", "The Chef"]},
    {"id": "Controller", "th": "คอนโทรลเลอร์", "weights": {"INT": 3, "INF": 2, "PER": 1}, "talent": ["INT", "INF"], "sets": ["The Mage", "The Minstrel", "The Grave Keeper"]},
    {"id": "Specialist", "th": "สเปเชียลลิสต์", "weights": {"INT": 3, "PER": 2, "INF": 1}, "talent": ["INT", "EDU"], "sets": ["The Scholar", "The Alchemist", "The Merchant"]},
    {"id": "Utility", "th": "ยูทิลิตี้", "weights": {"PER": 2, "INT": 2, "AGI": 1, "INF": 1}, "talent": ["PER", "EDU"], "sets": ["The Wanderer", "The Grave Keeper"]},
]
DATA = {"glossary": GL2, "kins": kins, "skills": skills, "knowledge": knowledge, "sets": sets, "talents": TALENTS, "meta": META,
        "source": {"kins": "Kins of Kirana V.2.md (7 พ.ย. 2026)", "core": "Kirana Core System TTRPG (V.2).md", "skills": "Skill & Sorceries.md", "knowledge": "Talent & Knowledge Proficiency.md", "sets": "Starter Set - ชุดไอเทมเริ่มต้น.md"}}
# ผู้ใช้เคาะ 7 พ.ย. 2026: Fortitude → VIT Saving Throw, Will → PER Saving Throw ทุกที่ (ชีทและเอกสาร)
GL2.pop("Fortitude", None); GL2.pop("Will", None)
GL2["VIT Saving Throw"] = {"th": "ทอยป้องกันทางกาย", "text": "ทอยป้องกันด้วย VIT Mod ต้านพิษ โรค ความเหนื่อยล้า และผลทางกาย (เดิมเรียก Fortitude)", "cat": "ศัพท์ระบบ"}
GL2["PER Saving Throw"] = {"th": "ทอยป้องกันทางใจ", "text": "ทอยป้องกันด้วย PER Mod ต้านความกลัว มายา และผลทางจิต ใช้เป็นค่าตั้งรับให้คนอื่นทอยแข่งได้ (เดิมเรียก Will)", "cat": "ศัพท์ระบบ"}
out = json.dumps(DATA, ensure_ascii=False, separators=(",", ":"))
out = out.replace("Fortitude Saving Throw", "VIT Saving Throw").replace("Will Saving Throw", "PER Saving Throw")
out = re.sub(r"ทอย Fortitude\b", "ทอย VIT Saving Throw", out); out = re.sub(r"ทอย Will\b", "ทอย PER Saving Throw", out)
out = re.sub(r"\bFortitude\b", "VIT Saving Throw", out)
assert "Fortitude" not in out
open(S + "data.json", "w", encoding="utf-8").write(out)
print(len(out), "bytes", len(skills), "skills")
