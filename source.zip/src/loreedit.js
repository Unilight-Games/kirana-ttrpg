/* ===== v1.26 (ร่าง ยังไม่ขึ้นเว็บ · Non สั่ง 16 พ.ย. 2026): แก้ข้อความตำนานจากในเว็บ เฉพาะหลังบ้าน =====
 * "ทำให้ผู้พัฒนาสามารถแก้ข้อความได้จากในเว็บด้วย โดยสิ่งนี้จะมีเฉพาะหลังบ้านที่เห็นและทำได้"
 * แก้ได้: บทความทุกบทในตำนาน คำโปรยของแต่ละมหายุค และคำนำหน้าแรก · เพิ่มบทความใหม่ชนิดหัวข้อ บุคคล ฝ่าย สถานที่
 * ที่เก็บ: Firestore codex/lore อ่านได้ทุกคน เขียนได้เฉพาะผู้พัฒนา (ต้องเผยแพร่กฎ match /codex/{doc} ใน firestore.rules ก่อน)
 *   ระหว่างที่กฎยังไม่ขึ้น หรือเปิดไฟล์จากเครื่อง ร่างเก็บไว้ใน localStorage ของเครื่องนั้นและเห็นเฉพาะเครื่องนั้น
 * เก็บเฉพาะส่วนที่แก้ {v, at, by, byName, articles:{id: บทความทั้งบท}, eras:{id:{title,en,note,blurb}}, intro, log}
 *   Firestore ไม่รับอาร์เรย์ซ้อนอาร์เรย์ บทความแต่ละบทจึงเก็บเป็นสตริง JSON (loreWire) ขนาดเอกสารเพดาน 1 MiB
 *   ตอนนี้ตำนานทั้ง 50 บทรวมกันราว 420 KB แก้ทุกบทพร้อมกันก็ยังไม่ชนเพดาน
 * ทุกครั้งที่โหลด ข้อมูลผ่านตัวกรองโครงสร้าง และทุกข้อความแสดงผลเป็นข้อความล้วน (h() ใส่ textContent)
 * ผู้ที่แก้ได้: เว็บที่ต่อ Firebase คือบัญชีใน devUids · ไฟล์ที่เปิดในเครื่องโดยไม่มี firebase-config.js คือเจ้าของเครื่อง
 *   ถ้าเว็บตั้งค่า Firebase ไว้แต่เชื่อมไม่ติด จะไม่มีใครเห็นหลังบ้าน */
const LORE_BASE = { articles: JSON.parse(JSON.stringify(LORE)), eras: JSON.parse(JSON.stringify(LORE_ERAS)), intro: LORE_INTRO };
const LORE_ID_RX = /^[a-z0-9]{2,24}$/;
const LORE_NEW_KINDS = ['topic','person','faction','place'];
function loreStr(x, max){ return typeof x === 'string' ? x.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max) : ''; }
function loreSanitizeArticle(a, id){
  if (!a || typeof a !== 'object') return null;
  const base = LORE_BASE.articles[id];
  const kind = base ? base.kind : (LORE_NEW_KINDS.includes(a.kind) ? a.kind : null);
  if (!kind) return null;
  const out = { kind, title: loreStr(a.title, 120) || (base ? base.title : id), en: loreStr(a.en, 160), sub: loreStr(a.sub, 240), lead: loreStr(a.lead, 2400) };
  if (base && base.era) out.era = base.era; else if (!base && LORE_ERAS.some(e=>e.id===a.era)) out.era = a.era;
  if (kind !== 'event'){ const p = base ? (a.parent === undefined ? base.parent : a.parent) : a.parent; if (p && LORE_BASE.articles[p] && LORE_BASE.articles[p].kind === 'event') out.parent = p; }
  out.box = (Array.isArray(a.box) ? a.box : []).slice(0, 24).map(r=>Array.isArray(r) ? [loreStr(r[0], 80), loreStr(r[1], 700)] : null).filter(r=>r && r[0] && r[1]);
  out.body = (Array.isArray(a.body) ? a.body : []).slice(0, 200).map(b=>{
    if (!Array.isArray(b)) return null;
    if (b[0]==='h'){ const s = loreStr(b[1], 160); return s ? ['h', s] : null; }
    if (b[0]==='p'){ const s = loreStr(b[1], 8000); return s ? ['p', s] : null; }
    if (b[0]==='ul'){ const xs = (Array.isArray(b[1]) ? b[1] : []).slice(0, 40).map(x=>loreStr(x, 4000)).filter(Boolean); return xs.length ? ['ul', xs] : null; }
    if (b[0]==='q'){ const s = loreStr(b[1], 4000); const c = loreStr(b[2], 300); return s ? (c ? ['q', s, c] : ['q', s]) : null; }
    if (b[0]==='fig') return typeof b[1]==='string' && LORE_FIGS[b[1]] ? ['fig', b[1]] : null;
    return null; }).filter(Boolean);
  const br = (Array.isArray(a.branches) ? a.branches : []).filter(x=>typeof x==='string' && LORE_ID_RX.test(x)).slice(0, 16);
  if (br.length) out.branches = br;
  if (a.game && typeof a.game === 'object'){ const g = {}; const list = (xs, max)=>(Array.isArray(xs) ? xs : []).map(x=>loreStr(x, max)).filter(Boolean).slice(0, 16);
    for (const [k, max] of [['kins',40],['items',140],['skills',80]]){ const xs = list(a.game[k], max); if (xs.length) g[k] = xs; }
    if (Object.keys(g).length) out.game = g; }
  return out; }
function loreSanitize(d){
  if (!d || typeof d !== 'object') return null;
  const out = { v:1, at: +d.at || 0, by: loreStr(d.by, 128), byName: loreStr(d.byName, 80), articles:{}, eras:{}, intro: loreStr(d.intro, 1500) || null, log: [] };
  for (const [id, raw] of Object.entries(d.articles && typeof d.articles==='object' ? d.articles : {})){ if (!LORE_ID_RX.test(id)) continue;
    let a = raw; if (typeof a === 'string'){ try { a = JSON.parse(a); } catch(e){ continue; } }
    const x = loreSanitizeArticle(a, id); if (x) out.articles[id] = x; }
  for (const e of LORE_BASE.eras){ const o = d.eras && d.eras[e.id]; if (!o || typeof o !== 'object') continue; const x = {};
    for (const [f, max] of [['title',120],['en',120],['note',120],['blurb',1500]]) if (typeof o[f]==='string') x[f] = loreStr(o[f], max);
    if (Object.keys(x).length) out.eras[e.id] = x; }
  out.log = (Array.isArray(d.log) ? d.log : []).slice(0, 40).map(x=>x && typeof x==='object' ? {at: +x.at || 0, by: loreStr(x.by, 80), what: loreStr(x.what, 200)} : null).filter(Boolean);
  return out; }

/* ---- เนื้อบทความ <-> ข้อความรูปแบบง่าย ----
 * ## หัวข้อย่อย · ย่อหน้าคั่นด้วยบรรทัดว่าง · ขีด (-) นำหน้ารายการ · > คำพูด ตามด้วย >> ผู้พูด (ถ้ามี) · ::fig รหัสแผนผัง
 * ย่อหน้าที่บังเอิญขึ้นต้นด้วยเครื่องหมายเหล่านี้จะมี \ นำหน้า */
const LORE_MARK_RX = /^(## |::fig |- |> |>> |\\)/;
function loreBodyToText(body){
  return (body||[]).map(b=>{
    if (b[0]==='h') return '## ' + b[1];
    if (b[0]==='p') return LORE_MARK_RX.test(b[1]) ? '\\' + b[1] : b[1];
    if (b[0]==='ul') return b[1].map(x=>'- ' + x).join('\n');
    if (b[0]==='q') return '> ' + b[1] + (b[2] ? '\n>> ' + b[2] : '');
    if (b[0]==='fig') return '::fig ' + b[1];
    return ''; }).filter(Boolean).join('\n\n'); }
function loreTextToBody(text){
  const body = [];
  for (const raw of String(text||'').replace(/\r/g, '').split(/\n[ \t]*\n/)){
    const lines = raw.split('\n').map(x=>x.trim()).filter(Boolean); let i = 0;
    while (i < lines.length){ const ln = lines[i];
      if (ln.startsWith('## ')){ body.push(['h', ln.slice(3).trim()]); i++; continue; }
      if (ln.startsWith('::fig ')){ body.push(['fig', ln.slice(6).trim()]); i++; continue; }
      if (ln.startsWith('- ')){ const xs = []; while (i < lines.length && lines[i].startsWith('- ')) xs.push(lines[i++].slice(2).trim()); body.push(['ul', xs]); continue; }
      if (ln.startsWith('> ')){ const q = []; while (i < lines.length && lines[i].startsWith('> ')) q.push(lines[i++].slice(2).trim()); let cite = '';
        if (i < lines.length && lines[i].startsWith('>> ')) cite = lines[i++].slice(3).trim(); body.push(cite ? ['q', q.join(' '), cite] : ['q', q.join(' ')]); continue; }
      if (ln.startsWith('>> ')){ i++; continue; }
      const p = []; while (i < lines.length && !/^(## |::fig |- |> |>> )/.test(lines[i])){ let s = lines[i++]; if (s.startsWith('\\')) s = s.slice(1); p.push(s); }
      if (p.length) body.push(['p', p.join(' ')]); } }
  return body; }
function loreBoxToText(box){ return (box||[]).map(([k, v])=>k + ' = ' + v).join('\n'); }
function loreTextToBox(text){ return String(text||'').split('\n').map(x=>x.trim()).filter(Boolean).map(ln=>{ const i = ln.indexOf(' = '); return i > 0 ? [ln.slice(0, i).trim(), ln.slice(i + 3).trim()] : null; }).filter(r=>r && r[0] && r[1]); }
function loreList(s){ return String(s||'').split(/[,\n]/).map(x=>x.trim()).filter(Boolean); }

/* ตรวจลิงก์และรหัสก่อนบันทึก: คืนรายการคำเตือน (ไม่บังคับ) */
function loreCheck(a, id){
  const warn = []; const known = new Set(Object.keys(LORE)); known.add(id);
  const txt = JSON.stringify([a.lead, a.box, a.body]);
  for (const m of txt.matchAll(/\[\[([^\]|]+)(?:\|[^\]]*)?\]\]/g)) if (!known.has(m[1])) warn.push(`ลิงก์ [[${m[1]}]] ไม่มีบทความรหัสนี้ จะแสดงเป็นข้อความธรรมดา`);
  for (const b of a.body||[]) if (b[0]==='fig' && !LORE_FIGS[b[1]]) warn.push(`แผนผัง ${b[1]} ไม่มีในเว็บ (มี ${Object.keys(LORE_FIGS).join(' ')})`);
  for (const b of a.branches||[]) if (!known.has(b)) warn.push(`แตกแขนง ${b} ไม่มีบทความรหัสนี้`);
  const g = a.game || {};
  for (const k of g.kins||[]) if (!KIN[k]) warn.push(`วงศา ${k} ไม่มีในข้อมูล (มี ${Object.keys(KIN).join(' ')})`);
  for (const n of g.items||[]) if (!(DATA.items||[]).some(it=>it.name===n)) warn.push(`ไอเทม "${n}" ไม่ตรงกับชื่อในคลังไอเทม`);
  for (const s of g.skills||[]) if (!DATA.skills.some(sk=>skSubBase(sk.subcategory)===skSubBase(s))) warn.push(`ประเภททักษะ "${s}" ไม่มีในคลังทักษะ`);
  if (!a.title) warn.push('ยังไม่มีชื่อบทความ');
  return [...new Set(warn)]; }

const LoreEdit = {
  KEY: 'kirana.codex.lore.v1',
  remote: null, local: null, status: 'idle', error: '',
  canEdit(){ if (!Store.ready) return false; if (Store.backend === 'firebase') return !!Store.isDevUid; if (Store.backend) return false;
    return !(window.KIRANA_FIREBASE && window.KIRANA_FIREBASE.projectId); },
  ref(){ return Store.backend === 'firebase' && Store.db ? Store.db.doc('codex/lore') : null; },
  readLocal(){ try { return loreSanitize(JSON.parse(localStorage.getItem(this.KEY) || 'null')); } catch(e){ return null; } },
  writeLocal(d){ try { if (d) localStorage.setItem(this.KEY, JSON.stringify(d)); else localStorage.removeItem(this.KEY); return true; } catch(e){ return false; } },
  async boot(){
    const ref = this.ref();
    if (ref){ try { const s = await ref.get(); this.remote = s.exists ? loreSanitize(s.data()) : null; this.status = 'web'; }
      catch(e){ this.status = 'noread'; this.error = (e && e.code) || String(e); console.warn('codex read', e); } }
    else this.status = 'local';
    this.local = this.canEdit() ? this.readLocal() : null;
    this.apply(); },
  /* ร่างในเครื่องคือข้อมูลทั้งชุดที่สร้างจากข้อมูลบนเว็บตอนบันทึก จึงใช้แทนกันได้ทั้งชุด */
  effective(){ return (this.canEdit() && this.local) || this.remote || null; },
  apply(){
    for (const k of Object.keys(LORE)) if (!LORE_BASE.articles[k]) delete LORE[k];
    for (const [k, a] of Object.entries(LORE_BASE.articles)) LORE[k] = JSON.parse(JSON.stringify(a));
    LORE_ERAS.forEach((e, i)=>Object.assign(e, JSON.parse(JSON.stringify(LORE_BASE.eras[i]))));
    LORE_INTRO = LORE_BASE.intro;
    const d = this.effective();
    if (d){ for (const [k, a] of Object.entries(d.articles)) LORE[k] = JSON.parse(JSON.stringify(a));
      for (const e of LORE_ERAS){ const o = d.eras[e.id]; if (o) for (const f of ['title','en','note','blurb']) if (o[f]) e[f] = o[f]; }
      if (d.intro) LORE_INTRO = d.intro; }
    LORE_BACK = null; },
  edited(id){ const d = this.effective(); return !!(d && d.articles[id]); },
  added(id){ return !LORE_BASE.articles[id] && !!LORE[id]; },
  /* อ่านฉบับล่าสุดบนเว็บก่อนเขียนทุกครั้ง ผู้พัฒนาสองคนแก้คนละบทจึงไม่ทับกัน (ถ้ามีร่างค้างในเครื่อง ใช้ร่างเป็นฐาน) */
  async save(what, mutate){
    if (!this.canEdit()) return {where:'denied'};
    const ref = this.ref();
    if (ref && !this.local){ try { const s = await ref.get(); this.remote = s.exists ? loreSanitize(s.data()) : null; } catch(e){} }
    const next = JSON.parse(JSON.stringify(this.local || this.remote || {v:1, articles:{}, eras:{}, intro:null, log:[]}));
    mutate(next);
    next.at = Date.now(); next.by = Store.me || ''; next.byName = Store.displayName || (Store.backend ? '' : 'เครื่องนี้');
    next.log = [{at: next.at, by: next.byName || next.by || 'ผู้พัฒนา', what}, ...(next.log||[])].slice(0, 40);
    const clean = loreSanitize(next); const wire = loreWire(clean); const bytes = new Blob([JSON.stringify(wire)]).size;
    if (bytes > 1000000) return {where:'toolarge', bytes};
    if (ref){ try { await ref.set(wire); this.remote = clean; this.local = null; this.writeLocal(null); this.status = 'web'; this.error = ''; this.apply(); return {where:'web'}; }
      catch(e){ this.error = (e && e.code) || String(e); this.local = clean; this.writeLocal(clean); this.status = 'draft'; this.apply(); return {where:'draft', code: this.error}; } }
    this.local = clean; this.writeLocal(clean); this.apply(); return {where:'local'}; },
  async pushDraft(){ const ref = this.ref(); if (!ref || !this.local) return {where:'none'};
    try { await ref.set(loreWire(this.local)); this.remote = this.local; this.local = null; this.writeLocal(null); this.status = 'web'; this.error = ''; this.apply(); return {where:'web'}; }
    catch(e){ this.error = (e && e.code) || String(e); return {where:'draft', code: this.error}; } },
  dropDraft(){ this.local = null; this.writeLocal(null); this.apply(); },
};
function loreWire(d){ const w = JSON.parse(JSON.stringify(d)); w.articles = {}; for (const [k, a] of Object.entries(d.articles)) w.articles[k] = JSON.stringify(a); return w; }
function loreSaveToast(r){
  toast(r.where === 'web' ? 'บันทึกขึ้นเว็บแล้ว ทุกคนเห็นข้อความใหม่' :
    r.where === 'draft' ? `เขียนขึ้นเว็บไม่ได้ (${r.code}) เก็บเป็นร่างในเครื่องนี้แล้ว ต้องเผยแพร่กฎ codex ใน firestore.rules ก่อน` :
    r.where === 'toolarge' ? `ข้อความที่แก้รวมกัน ${Math.round(r.bytes/1024)} KB เกินเพดานเอกสารละ 1 MB ของฐานข้อมูล ยังไม่ได้บันทึก` :
    r.where === 'denied' ? 'บัญชีนี้แก้ตำนานไม่ได้' :
    'บันทึกในเครื่องนี้แล้ว (ไฟล์ในเครื่องไม่มีฐานข้อมูล)'); }

/* ---- ปุ่มบนหน้าบทความ: เห็นเฉพาะผู้พัฒนา ---- */
function loreDevBar(id){
  if (!LoreEdit.canEdit()) return null;
  return h('div',{class:'lore-devbar'}, h('span',{class:'lore-devtag',text:'หลังบ้าน'}),
    LoreEdit.edited(id) ? h('span',{class:'dim',text: LoreEdit.added(id) ? 'บทความที่เพิ่มจากหลังบ้าน' : 'ฉบับแก้จากหลังบ้าน'}) : h('span',{class:'dim',text:'ฉบับต้นฉบับในโค้ด'}),
    h('button',{class:'small',onclick:()=>{ location.hash = '#loreedit-' + id; },text:'✎ แก้ข้อความบทนี้'})); }

/* ---- หน้าแก้บทความ #loreedit-<id> และ #loreedit-new ---- */
function renderLoreEdit(arg){
  const root = clear($('#v-lore'));
  if (!Store.ready){ root.append(h('div',{class:'card dim',text:'กำลังตรวจสิทธิ์ผู้พัฒนา…'})); return; }
  if (!LoreEdit.canEdit()){ location.hash = arg && LORE[arg] ? '#lore-' + arg : '#lore'; return; }
  const isNew = arg === 'new' || !LORE[arg];
  const base = !isNew ? LORE_BASE.articles[arg] : null;
  const cur = isNew ? {kind:'topic', title:'', en:'', sub:'', lead:'', box:[], body:[]} : JSON.parse(JSON.stringify(LORE[arg]));
  const f = {};
  const field = (label, el, hint)=>h('label',{class:'le-field'}, h('span',{class:'le-lab',text:label}), el, hint ? h('span',{class:'dim le-hint',text:hint}) : null);
  f.id = h('input',{value: isNew ? (arg && arg !== 'new' ? arg : '') : arg, placeholder:'เช่น lotusflame (a-z 0-9 ยาว 2-24 ตัว)', disabled: !isNew});
  f.kind = h('select',{disabled: !!base}, (base && base.kind==='event' ? [['event','เหตุการณ์']] : LORE_NEW_KINDS.map(k=>[k, LORE_KIND[k][0]])).map(([v, l])=>h('option',{value:v, selected: cur.kind===v, text:l})));
  const events = LORE_ERAS.flatMap(e=>e.events);
  f.parent = h('select',{disabled: cur.kind==='event'}, h('option',{value:'', text:'ไม่สังกัดเหตุการณ์'}), events.map(x=>h('option',{value:x, selected: cur.parent===x, text: LORE[x].title})));
  f.era = h('select',{disabled: !!base}, h('option',{value:'', text:'ไม่ระบุยุค'}), LORE_ERAS.map(e=>h('option',{value:e.id, selected: cur.era===e.id, text:e.title})));
  f.title = h('input',{value: cur.title}); f.en = h('input',{value: cur.en||''}); f.sub = h('input',{value: cur.sub||''});
  f.lead = h('textarea',{rows:3}); f.lead.value = cur.lead||'';
  f.box = h('textarea',{rows:5, class:'le-mono'}); f.box.value = loreBoxToText(cur.box);
  f.body = h('textarea',{rows:22, class:'le-mono le-body'}); f.body.value = loreBodyToText(cur.body);
  f.branches = h('input',{value: (cur.branches||[]).join(', ')});
  f.kins = h('input',{value: ((cur.game||{}).kins||[]).join(', ')});
  f.items = h('textarea',{rows:2}); f.items.value = ((cur.game||{}).items||[]).join('\n');
  f.skills = h('input',{value: ((cur.game||{}).skills||[]).join(', ')});
  const read = ()=>{ const a = { kind: f.kind.value, title: f.title.value.trim(), en: f.en.value.trim(), sub: f.sub.value.trim(), lead: f.lead.value.trim(),
      box: loreTextToBox(f.box.value), body: loreTextToBody(f.body.value) };
    if (f.era.value) a.era = f.era.value; if (a.kind !== 'event' && f.parent.value) a.parent = f.parent.value;
    const br = loreList(f.branches.value); if (br.length) a.branches = br;
    const g = {}; const k = loreList(f.kins.value), it = String(f.items.value).split('\n').map(x=>x.trim()).filter(Boolean), sk = loreList(f.skills.value);
    if (k.length) g.kins = k; if (it.length) g.items = it; if (sk.length) g.skills = sk; if (Object.keys(g).length) a.game = g;
    return a; };
  const warnBox = h('div',{class:'le-warn'}); const prev = h('div',{class:'le-preview'});
  let tm = 0;
  const preview = ()=>{ clearTimeout(tm); tm = setTimeout(()=>{ const id = isNew ? (f.id.value.trim() || 'new') : arg; const a = loreSanitizeArticle(read(), isNew ? '__new__' : arg) || read();
    clear(warnBox); const w = loreCheck(a, id); if (isNew && !LORE_ID_RX.test(f.id.value.trim())) w.unshift('รหัสบทความต้องเป็น a-z และ 0-9 ยาว 2 ถึง 24 ตัว'); else if (isNew && LORE[f.id.value.trim()]) w.unshift('รหัสนี้มีบทความอยู่แล้ว');
    if (w.length) warnBox.append(h('b',{text:'ตรวจพบ'}), h('ul',null, w.map(x=>h('li',{text:x}))));
    clear(prev); prev.append(h('div',{class:'kicker',text:'ตัวอย่างหน้าบทความ'}), warnBox); const holder = h('div'); prev.append(holder);
    try { loreArticle(holder, id, a); } catch(e){ holder.append(h('div',{class:'card dim',text:'แสดงตัวอย่างไม่ได้: ' + e.message})); } }, 250); };
  for (const el of Object.values(f)) el.addEventListener('input', preview);
  /* บันทึกโดยไม่ได้แก้อะไร = ไม่เก็บฉบับแก้ บทความกลับไปอ่านจากต้นฉบับในโค้ด */
  const same = (x, id)=>!!LORE_BASE.articles[id] && JSON.stringify(loreSanitizeArticle(x, id)) === JSON.stringify(loreSanitizeArticle(LORE_BASE.articles[id], id));
  const saveBtn = h('button',{class:'primary',text: isNew ? 'เพิ่มบทความ' : 'บันทึก'});
  const doSave = async ()=>{ const id = isNew ? f.id.value.trim() : arg;
    if (!LORE_ID_RX.test(id) || id === 'new'){ toast('รหัสบทความต้องเป็น a-z และ 0-9 ยาว 2 ถึง 24 ตัว และห้ามใช้คำว่า new'); return; }
    if (isNew && LORE[id]){ toast('รหัสนี้มีบทความอยู่แล้ว'); return; }
    const a = read(); if (!a.title){ toast('ใส่ชื่อบทความก่อน'); return; }
    saveBtn.disabled = true;
    const r = await LoreEdit.save((isNew ? 'เพิ่มบทความ ' : 'แก้บทความ ') + a.title, d=>{ if (same(a, id)) delete d.articles[id]; else d.articles[id] = a; });
    saveBtn.disabled = false; loreSaveToast(r);
    if (r.where === 'web' || r.where === 'draft' || r.where === 'local') location.hash = '#lore-' + id; };
  saveBtn.onclick = doSave;
  const actions = h('div',{class:'row le-actions'}, saveBtn, h('button',{class:'ghost',onclick:()=>{ location.hash = isNew ? '#dev' : '#lore-' + arg; },text:'ยกเลิก'}),
    !isNew && base && LoreEdit.edited(arg) ? h('button',{class:'ghost',onclick:async()=>{ if (!confirm('คืนบทความนี้เป็นฉบับต้นฉบับในโค้ด ข้อความที่แก้จะหายไป')) return;
      loreSaveToast(await LoreEdit.save('คืนต้นฉบับ ' + base.title, d=>{ delete d.articles[arg]; })); location.hash = '#lore-' + arg; },text:'คืนต้นฉบับ'}) : null,
    !isNew && !base ? h('button',{class:'ghost danger',onclick:async()=>{ if (!confirm('ลบบทความที่เพิ่มจากหลังบ้านบทนี้')) return;
      loreSaveToast(await LoreEdit.save('ลบบทความ ' + cur.title, d=>{ delete d.articles[arg]; })); location.hash = '#lore'; },text:'ลบบทความนี้'}) : null);
  root.append(h('div',{class:'lore-crumbs',role:'navigation','aria-label':'ตำแหน่ง'}, h('a',{href:'#lore',text:'ตำนาน'}), h('span',{class:'sep',text:' › '}), h('a',{href:'#dev',text:'หลังบ้าน'}), h('span',{class:'sep',text:' › '}), h('span',{class:'cur',text: isNew ? 'เพิ่มบทความใหม่' : 'แก้ ' + cur.title})));
  root.append(h('div',{class:'le-head'}, h('span',{class:'lore-devtag',text:'หลังบ้าน · เห็นเฉพาะผู้พัฒนา'}), h('h1',{class:'gothic',text: isNew ? 'เพิ่มบทความใหม่' : cur.title}),
    h('p',{class:'dim',text: LoreEdit.ref() ? 'บันทึกแล้วขึ้นเว็บทันที ถ้าเขียนขึ้นเว็บไม่ได้ ข้อความจะเก็บเป็นร่างในเครื่องนี้' : 'เปิดจากไฟล์ในเครื่อง ข้อความที่บันทึกเก็บในเบราว์เซอร์เครื่องนี้'})));
  const help = h('details',{class:'le-help'}, h('summary',{text:'วิธีเขียนเนื้อบทความ'}), h('ul',null,
    h('li',{text:'ย่อหน้าหนึ่งเขียนเป็นบรรทัดเดียว และเว้นบรรทัดว่างระหว่างย่อหน้า'}),
    h('li',{text:'บรรทัดที่ขึ้นต้นด้วย ## คือหัวข้อย่อย · บรรทัดที่ขึ้นต้นด้วยขีด (-) และเว้นวรรค คือรายการ'}),
    h('li',{text:'บรรทัดที่ขึ้นต้นด้วย > คือคำพูดยกมา บรรทัดถัดไปที่ขึ้นต้นด้วย >> คือชื่อผู้พูด'}),
    h('li',{text:'[[รหัส]] หรือ [[รหัส|ข้อความ]] คือลิงก์ไปบทความอื่น · ::fig รหัส คือแผนผัง (' + Object.keys(LORE_FIGS).join(' ') + ')'}),
    h('li',{text:'กล่องข้อมูล: บรรทัดละหนึ่งแถว เขียนว่า หัวข้อ = ค่า'})));
  const ids = h('datalist',{id:'le-ids'}, Object.keys(LORE).map(x=>h('option',{value:x, label: LORE[x].title})));
  const form = h('div',{class:'le-form card'},
    h('div',{class:'le-grid'}, field('รหัสบทความ', f.id, isNew ? 'ใช้ในลิงก์ #lore-รหัส แก้ภายหลังไม่ได้' : ''), field('ชนิด', f.kind), field('สังกัดเหตุการณ์', f.parent), field('มหายุค', f.era)),
    h('div',{class:'le-grid'}, field('ชื่อ', f.title), field('ชื่ออังกฤษ', f.en)), field('คำโปรยใต้ชื่อ', f.sub), field('บทนำ', f.lead), field('กล่องข้อมูล', f.box, 'หัวข้อ = ค่า บรรทัดละแถว'),
    help, field('เนื้อบทความ', f.body), field('แตกแขนง (รหัสบทความ คั่นด้วยจุลภาค)', f.branches),
    h('div',{class:'le-grid'}, field('ในเกม: วงศา (รหัส)', f.kins), field('ในเกม: ประเภททักษะ', f.skills)), field('ในเกม: ไอเทม (ชื่อเต็มบรรทัดละชิ้น)', f.items), actions, ids);
  f.branches.setAttribute('list', 'le-ids');
  root.append(h('div',{class:'le-wrap'}, form, prev));
  preview();
}

/* ---- การ์ดในหลังบ้าน (#dev) ---- */
function loreDevCard(){
  if (!LoreEdit.canEdit()) return null;
  const card = h('div',{class:'card le-dev'}); const d = LoreEdit.effective();
  const statusText = LoreEdit.ref()
    ? (LoreEdit.local ? `มีร่างในเครื่องนี้ที่ยังไม่ขึ้นเว็บ${LoreEdit.error ? ' (' + LoreEdit.error + ')' : ''} ต้องเผยแพร่กฎ codex ใน firestore.rules ก่อน` : LoreEdit.status === 'noread' ? `อ่านข้อความจากเว็บไม่ได้ (${LoreEdit.error}) กฎ codex อาจยังไม่ขึ้น` : 'ข้อความที่แก้เก็บบนเว็บ (codex/lore) ทุกคนเห็นทันที')
    : 'เปิดจากไฟล์ในเครื่อง ข้อความที่แก้เก็บในเบราว์เซอร์นี้';
  card.append(h('h2',{text:'แก้ข้อความตำนาน'}), h('p',{class:'dim',style:'font-size:13px;margin:2px 0 10px',text: statusText}));
  const pick = h('select',null, LORE_ERAS.map(e=>h('optgroup',{label:e.title}, e.events.map(x=>h('option',{value:x, text:LORE[x].title})))),
    LORE_KIND_ORDER.map(k=>h('optgroup',{label:LORE_KIND[k][0]}, Object.keys(LORE).filter(x=>LORE[x].kind===k).map(x=>h('option',{value:x, text: LORE[x].title + (LoreEdit.edited(x) ? ' (แก้แล้ว)' : '')})))));
  card.append(h('div',{class:'row'}, pick, h('button',{class:'primary',onclick:()=>{ location.hash = '#loreedit-' + pick.value; },text:'✎ แก้บทความนี้'}), h('button',{onclick:()=>{ location.hash = '#loreedit-new'; },text:'+ เพิ่มบทความใหม่'})));
  if (LoreEdit.local && LoreEdit.ref()) card.append(h('div',{class:'row',style:'margin-top:8px'},
    h('button',{onclick:async()=>{ const r = await LoreEdit.pushDraft(); loreSaveToast(r); renderDev(); },text:'ส่งร่างขึ้นเว็บอีกครั้ง'}),
    h('button',{class:'ghost',onclick:()=>{ if (confirm('ทิ้งร่างในเครื่องนี้ แล้วใช้ข้อความบนเว็บ')){ LoreEdit.dropDraft(); renderDev(); } },text:'ทิ้งร่างในเครื่อง'})));
  const ed = d ? Object.keys(d.articles) : [];
  card.append(h('h3',{text:`บทความที่แก้แล้ว ${ed.length} บท`}), ed.length ? h('ul',{class:'le-list'}, ed.map(x=>h('li',null, h('a',{href:'#lore-'+x,text:LORE[x] ? LORE[x].title : x}), LORE_BASE.articles[x] ? null : h('span',{class:'tag stat',text:'เพิ่มใหม่'}), ' ', h('a',{class:'dim',href:'#loreedit-'+x,text:'แก้'})))) : h('p',{class:'dim',text:'ยังไม่มี ทุกบทแสดงฉบับต้นฉบับในโค้ด'}));
  // คำนำและคำโปรยมหายุค
  const intro = h('textarea',{rows:3}); intro.value = LORE_INTRO;
  const eraF = LORE_ERAS.map(e=>{ const t = h('input',{value:e.title}); const b = h('textarea',{rows:2}); b.value = e.blurb; return {id:e.id, t, b}; });
  card.append(h('h3',{text:'คำนำหน้าตำนานและคำโปรยของแต่ละมหายุค'}), h('label',{class:'le-field'}, h('span',{class:'le-lab',text:'คำนำหน้าแรก'}), intro),
    ...eraF.map(x=>h('div',{class:'le-grid'}, h('label',{class:'le-field'}, h('span',{class:'le-lab',text:'ชื่อยุค'}), x.t), h('label',{class:'le-field'}, h('span',{class:'le-lab',text:'คำโปรย'}), x.b))),
    h('div',{class:'row'}, h('button',{class:'primary',onclick:async()=>{ const r = await LoreEdit.save('แก้คำนำและคำโปรยมหายุค', dd=>{
        dd.intro = intro.value.trim() !== LORE_BASE.intro ? intro.value.trim() : null;
        for (const x of eraF){ const be = LORE_BASE.eras.find(e=>e.id===x.id); const o = {}; if (x.t.value.trim() !== be.title) o.title = x.t.value.trim(); if (x.b.value.trim() !== be.blurb) o.blurb = x.b.value.trim();
          if (Object.keys(o).length) dd.eras[x.id] = o; else delete dd.eras[x.id]; } }); loreSaveToast(r); renderDev(); },text:'บันทึกคำนำและคำโปรย'})));
  // ส่งออกและนำเข้า
  const file = h('input',{type:'file',accept:'application/json',style:'display:none',onchange:async()=>{ const fl = file.files[0]; if (!fl) return;
    try { const j = loreSanitize(JSON.parse(await fl.text())); if (!j) throw new Error('ไม่ใช่ไฟล์ข้อความตำนาน');
      if (!confirm(`นำเข้า ${Object.keys(j.articles).length} บทความ แทนข้อความที่แก้ทั้งหมดตอนนี้`)) return;
      loreSaveToast(await LoreEdit.save('นำเข้าจากไฟล์', dd=>{ dd.articles = j.articles; dd.eras = j.eras; dd.intro = j.intro; })); renderDev(); }
    catch(e){ toast('นำเข้าไม่ได้: ' + e.message); } }});
  card.append(h('h3',{text:'สำรองข้อมูล'}), h('div',{class:'row'},
    h('button',{onclick:()=>{ const blob = new Blob([JSON.stringify(LoreEdit.effective() || {v:1, articles:{}, eras:{}, intro:null}, null, 1)], {type:'application/json'});
      const a = h('a',{href:URL.createObjectURL(blob), download:'kirana-lore-edits.json'}); document.body.append(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 500); },text:'ส่งออกข้อความที่แก้ (JSON)'}),
    h('button',{onclick:()=>file.click(),text:'นำเข้าจากไฟล์'}), file));
  if (d && d.log && d.log.length) card.append(h('h3',{text:'ประวัติการแก้ล่าสุด'}), h('ul',{class:'le-list dim'}, d.log.slice(0, 12).map(x=>h('li',{text:`${new Date(x.at).toLocaleString('th-TH')} · ${x.by} · ${x.what}`}))));
  return card; }
