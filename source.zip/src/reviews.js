/* ===== ดาวและคอมเมนต์ของผลงานที่เผยแพร่: แผนที่ NPC และ Asset (v1.19 ผู้ใช้สั่ง 12 พ.ย. 2026) =====
 * หนึ่งบัญชีมีสมุดรีวิวหนึ่งเล่ม เก็บทุกรีวิวที่บัญชีนั้นเขียน:
 *   maps/rvbook-<uid> = {id, type:'reviews', published:true, ownerId, ownerName, items:{<รหัสผลงาน>:{t, s, x, n, o, at, ed?}}, createdAt, updatedAt}
 *   t ชนิดผลงาน (map | npc | asset) · s ดาว 0 ถึง 5 (0 คือไม่ให้ดาว) · x ข้อความ · n ชื่อผลงานตอนรีวิว · o เจ้าของผลงานตอนรีวิว · at เวลาเขียนครั้งแรก · ed เวลาแก้ล่าสุด
 * เหตุที่เก็บเป็นสมุดของคนรีวิว:
 *   1) Rules ของ maps ให้แต่ละบัญชีเขียนได้เฉพาะเอกสารของตัวเอง คนให้ดาวจึงเขียนลงเอกสารของผลงานโดยตรงไม่ได้ ส่วนสมุดของตัวเองเขียนได้ทันทีโดยไม่ต้องเผยแพร่ Rules ชุดใหม่
 *   2) published:true ทำให้ทุกคนที่ล็อกอินอ่านได้ตาม Rules เดิม · type:'reviews' ทำให้คลังแผนที่ (isMapDoc) กับคลัง NPC / Asset (libClean) มองข้ามเอกสารนี้
 *   3) รวมคะแนนทั้งเว็บด้วยคำค้นเดียว จำนวนเอกสารที่อ่านเท่ากับจำนวนคนที่เคยรีวิว
 * ทุกอย่างที่อ่านจากฐานข้อมูลถือเป็นข้อมูลที่ไม่น่าไว้ใจ (Rules ไม่ตรวจชนิดข้อมูล): rvCleanBook บังคับชนิด ความยาว และจำนวนก่อนใช้ ข้อความแสดงด้วย textContent เท่านั้น
 * หน้าเว็บกันคะแนนเพี้ยนไว้สี่ชั้น: หนึ่งบัญชีนับหนึ่งสมุด · หนึ่งสมุดมีหนึ่งรายการต่อผลงาน · รีวิวของเจ้าของผลงานไม่นับ · บัญชีนิรนามให้ดาวไม่ได้
 *   Rules v1.7 (เผยแพร่ 13 พ.ย. 2026) ปิดช่องที่เคยปลอมสมุดได้แล้ว: สมุดต้องใช้รหัส rvbook-<uid> ของคนเขียน ต้องเป็นบัญชีที่ไม่ใช่นิรนาม และ ownerId กับ type แก้ภายหลังไม่ได้
 * โหมดออฟไลน์ไม่มีรีวิว เพราะไม่มีผลงานของคนอื่นให้รีวิว */
const RV_TEXT_MAX = 400;   // ความยาวคอมเมนต์สูงสุด (ตัวอักษร)
const RV_BOOK_MAX = 300;   // จำนวนรีวิวสูงสุดต่อสมุดหนึ่งเล่ม เอกสาร Firestore มีเพดาน 1 MiB
const RV_PRIOR = { n: 3, mean: 3 }; // "ดาวสูงสุด" เรียงด้วยคะแนนถ่วง: ทุกผลงานเริ่มจากดาว 3 จำนวน 3 เสียงสมมติ ผลงานที่มีคนให้ดาวน้อยจึงยังไม่แซงผลงานที่มีคนให้ดาวมาก
const RV_CACHE_MS = 60000; // อายุแคชของสมุดทั้งเว็บ
const RV_DEV_LIST = 60;    // จำนวนรีวิวล่าสุดที่หน้าต่างของผู้พัฒนาแสดง
const RV_ID_RX = /^(?!__)[A-Za-z0-9_-]{1,64}$/; // รหัสผลงานที่รับ (Firestore สงวนชื่อฟิลด์แบบ __x__ จึงไม่รับรหัสที่ขึ้นต้นด้วยขีดล่างสองตัว)
const RV_SORTS = [['new','เรียง: ล่าสุด'], ['top','เรียง: ดาวสูงสุด'], ['most','เรียง: รีวิวมากสุด']];
function rvStr(v){ return typeof v === 'string' ? v : ''; }
function rvTime(v){ const n = +v; return Number.isFinite(n) && n > 0 && n < 8.64e15 ? n : 0; }
function rvType(x){ return x && (x.type === 'npc' || x.type === 'asset') ? x.type : 'map'; }
function rvTypeLabel(t){ return t === 'npc' ? 'NPC' : t === 'asset' ? 'Asset' : 'แผนที่'; }
function rvBookId(u){ return 'rvbook-' + u; }
/* รหัสสมุดที่ยอมรับ: rvbook-<ownerId> หรือรหัสสำรอง rvbook-<ownerId>~<สุ่ม> (ใช้เมื่อรหัสตามแบบมีคนอื่นสร้างเอกสารทับไว้) */
function rvIsBookId(id, owner){ if (typeof id !== 'string' || typeof owner !== 'string' || !owner) return false; const base = rvBookId(owner); return id === base || (id.startsWith(base + '~') && /^[a-z0-9]{1,12}$/.test(id.slice(base.length + 1))); }
function rvCleanEntry(e){
  if (!e || typeof e !== 'object') return null;
  const s = libInt(e.s, 0, 5); const x = rvStr(e.x).trim().slice(0, RV_TEXT_MAX);
  if (!s && !x) return null;
  const o = { t: e.t === 'npc' || e.t === 'asset' ? e.t : 'map', s, x, n: rvStr(e.n).slice(0, 80), o: rvStr(e.o).slice(0, 128), at: rvTime(e.at) };
  const ed = rvTime(e.ed); if (ed) o.ed = ed;
  return o;
}
function rvCleanBook(b){
  if (!b || typeof b !== 'object' || b.type !== 'reviews' || b.published !== true) return null;
  const owner = rvStr(b.ownerId); if (!owner || owner.length > 128 || !rvIsBookId(b.id, owner)) return null;
  const items = Object.create(null); let k = 0; // ไม่มีต้นแบบ: รหัสผลงานอย่าง __proto__ จากเอกสารปลอมจึงเป็นแค่คีย์ธรรมดา
  if (b.items && typeof b.items === 'object' && !Array.isArray(b.items)) for (const tid of Object.keys(b.items)){ if (k >= RV_BOOK_MAX) break; if (!RV_ID_RX.test(tid)) continue; const c = rvCleanEntry(b.items[tid]); if (c){ items[tid] = c; k++; } }
  return { id: b.id, ownerId: owner, ownerName: rvStr(b.ownerName).trim().slice(0, 80), items, createdAt: rvTime(b.createdAt), updatedAt: rvTime(b.updatedAt) };
}
function rvPermDenied(e){ return /permission/i.test(String((e && (e.code || e.message)) || '')); }

const ReviewLib = {
  books: [], byTarget: new Map(), loaded: false, failed: false, at: 0, p: null,
  isAnon(){ return Store.backend === 'firebase' && !!Store.authUser && !!Store.authUser.isAnonymous; },
  /* ใครให้ดาวหรือคอมเมนต์ได้: ต้องออนไลน์ ผลงานต้องเผยแพร่อยู่ ต้องเป็นผลงานของคนอื่น และบัญชีต้องเป็นบัญชี Google
   * (บัญชีนิรนามสร้างใหม่ได้ไม่จำกัด ถ้ารับไว้คะแนนจะปั๊มได้) คืน null เมื่อให้ได้ หรือ {code, text} บอกเหตุที่ให้ไม่ได้ */
  blocker(target){
    if (!Store.db) return { code:'offline', text:'ดาวและคอมเมนต์ใช้ได้เมื่อเชื่อมต่อกับเว็บ' };
    if (!Store.me) return { code:'nouser', text:'ยังไม่ได้เข้าสู่ระบบ' };
    if (!target || !target.published) return { code:'private', text:'ผลงานนี้ยังไม่ได้เผยแพร่ จึงยังไม่มีดาวหรือคอมเมนต์' };
    if (!RV_ID_RX.test(rvStr(target.id))) return { code:'badid', text:'ผลงานนี้รับดาวและคอมเมนต์ไม่ได้ รหัสของผลงานไม่ตรงรูปแบบที่ระบบใช้' };
    if (target.ownerId === Store.me) return { code:'own', text:'นี่คือผลงานของคุณ ผู้สร้างให้ดาวหรือคอมเมนต์ผลงานตัวเองไม่ได้ อ่านเสียงตอบรับได้ด้านล่าง' };
    if (this.isAnon()) return { code:'anon', text:'เข้าสู่ระบบด้วย Google ก่อน จึงจะให้ดาวหรือคอมเมนต์ได้ บัญชีนิรนามอ่านได้อย่างเดียว' };
    return null;
  },
  /* โหลดสมุดของทุกคน (แคชหนึ่งนาที) · ฐานข้อมูลที่ไม่รับเงื่อนไขซ้อนจะถอยไปใช้คำค้นเดียวกับคลังแผนที่แล้วกรองเอง */
  async load(force){
    if (!Store.db){ this.books = []; this.index(); this.loaded = true; return this.books; }
    if (!force && this.loaded && Date.now() - this.at < RV_CACHE_MS) return this.books;
    if (this.p) return this.p;
    this.p = (async ()=>{
      let docs = null;
      try { docs = snapDocs(await Store.db.collection('maps').where('published','==',true).where('type','==','reviews').limit(1000).get()); }
      catch(e){ try { docs = snapDocs(await Store.db.collection('maps').where('published','==',true).limit(1000).get()); } catch(e2){ console.warn('reviews', e2); } }
      if (docs){ this.books = docs.map(rvCleanBook).filter(Boolean); this.at = Date.now(); this.failed = false; this.index(); } else this.failed = true;
      this.loaded = true; this.p = null; return this.books;
    })();
    return this.p;
  },
  /* หนึ่งบัญชีนับหนึ่งสมุด: ถ้าบัญชีเดียวมีหลายเล่ม (รหัสสำรอง) ใช้เล่มที่แก้ล่าสุด */
  index(){
    const best = new Map();
    for (const b of this.books){ const cur = best.get(b.ownerId); if (!cur || b.updatedAt > cur.updatedAt) best.set(b.ownerId, b); }
    const by = new Map();
    for (const b of best.values()) for (const tid of Object.keys(b.items)){ const e = b.items[tid]; if (!by.has(tid)) by.set(tid, []); by.get(tid).push({ uid: b.ownerId, name: b.ownerName || 'ผู้เล่น', bookId: b.id, tid, t: e.t, n: e.n, s: e.s, x: e.x, at: e.at, ed: e.ed || 0 }); }
    this.byTarget = by;
  },
  /* รีวิวของผลงานหนึ่งชิ้น: ไม่นับของเจ้าของผลงานเอง · ของฉันขึ้นก่อน แล้วเรียงจากใหม่ไปเก่า */
  list(target){
    if (!target) return [];
    const me = Store.me; const when = (r)=> r.ed || r.at;
    return (this.byTarget.get(target.id) || []).filter(r => r.uid !== target.ownerId).sort((a,b)=> ((b.uid===me) - (a.uid===me)) || (when(b) - when(a)));
  },
  summary(target){
    const dist = [0,0,0,0,0,0]; let sum = 0, n = 0, comments = 0; const l = this.list(target);
    for (const r of l){ if (r.s){ dist[r.s]++; sum += r.s; n++; } if (r.x) comments++; }
    return { total: l.length, n, sum, avg: n ? sum / n : 0, comments, dist };
  },
  /* คะแนนถ่วงสำหรับการเรียง: (3 เสียงสมมติ × ดาว 3 + ดาวจริงรวม) ÷ (3 + จำนวนคนให้ดาว) · ผลงานที่ยังไม่มีดาวได้ 3 พอดี */
  score(target){ const s = this.summary(target); return (RV_PRIOR.n * RV_PRIOR.mean + s.sum) / (RV_PRIOR.n + s.n); },
  sorted(arr, mode){
    const byNew = (a,b)=> (b.updatedAt||0) - (a.updatedAt||0);
    if (mode === 'top'){ const sc = new Map(arr.map(x => [x.id, this.score(x)])); return arr.slice().sort((a,b)=> (sc.get(b.id) - sc.get(a.id)) || byNew(a,b)); }
    if (mode === 'most'){ const n = new Map(arr.map(x => [x.id, this.summary(x).total])); return arr.slice().sort((a,b)=> (n.get(b.id) - n.get(a.id)) || byNew(a,b)); }
    return arr.slice().sort(byNew);
  },
  myBook(){ const me = Store.me; if (!me) return null; let best = null; for (const b of this.books) if (b.ownerId === me && (!best || b.updatedAt > best.updatedAt)) best = b; return best; },
  mine(target){ const b = this.myBook(); return (b && target && b.items[target.id]) || null; },
  myCount(){ const b = this.myBook(); return b ? Object.keys(b.items).length : 0; },
  /* อ่านสมุดของฉันจากฐานข้อมูลก่อนเขียนทุกครั้ง กันทับการแก้จากอีกเครื่อง · ใช้คำค้นด้วย ownerId เพราะ Rules ไม่ให้เปิดเอกสารที่ยังไม่มีอยู่ตรง ๆ */
  async freshMyBook(){
    const me = Store.me; let docs;
    try { docs = snapDocs(await Store.db.collection('maps').where('ownerId','==',me).where('type','==','reviews').get()); }
    catch(e){ docs = snapDocs(await Store.db.collection('maps').where('ownerId','==',me).get()); }
    let best = null; for (const b of docs.map(rvCleanBook).filter(Boolean)) if (b.ownerId === me && (!best || b.updatedAt > best.updatedAt)) best = b;
    return best;
  },
  bookDoc(book, id, touch){ return { id, type:'reviews', published:true, ownerId: book.ownerId, ownerName: book.ownerName || '', items: JSON.parse(JSON.stringify(book.items)), createdAt: book.createdAt || Date.now(), updatedAt: touch ? Date.now() : (book.updatedAt || Date.now()) }; },
  /* เขียนสมุดของฉัน · สมุดเล่มแรกใช้รหัสตามแบบ ถ้าเขียนไม่ได้เพราะมีเอกสารของคนอื่นใช้รหัสนั้นอยู่ จะสร้างด้วยรหัสสำรองแทน */
  async putBook(book, isNew){
    let doc = this.bookDoc(book, book.id, true);
    try { await Store.db.doc('maps/' + doc.id).set(doc); }
    catch(e){ if (!isNew || doc.id !== rvBookId(book.ownerId) || !rvPermDenied(e)) throw e;
      doc = this.bookDoc(book, rvBookId(book.ownerId) + '~' + uid().slice(0, 8), true); await Store.db.doc('maps/' + doc.id).set(doc); }
    return doc;
  },
  adopt(doc){ const b = rvCleanBook(doc); this.books = this.books.filter(x => x.ownerId !== doc.ownerId); if (b) this.books.push(b); this.index(); },
  async save(target, stars, text){
    const blk = this.blocker(target); if (blk){ toast(blk.text); return false; }
    const s = libInt(stars, 0, 5), x = rvStr(text).trim().slice(0, RV_TEXT_MAX);
    if (!s && !x){ toast('ให้ดาวอย่างน้อยหนึ่งดวง หรือเขียนคอมเมนต์ก่อนบันทึก'); return false; }
    try {
      const me = Store.me; let book = await this.freshMyBook(); const isNew = !book;
      if (!book) book = { id: rvBookId(me), ownerId: me, ownerName: '', items: Object.create(null), createdAt: Date.now(), updatedAt: 0 };
      const prev = book.items[target.id]; const now = Date.now();
      if (!prev && Object.keys(book.items).length >= RV_BOOK_MAX){ toast(`สมุดรีวิวของคุณเต็มแล้ว (${RV_BOOK_MAX} รายการ) ลบรีวิวเก่าออกก่อน`); return false; }
      const e = { t: rvType(target), s, x, n: rvStr(target.name).slice(0, 80), o: rvStr(target.ownerId).slice(0, 128), at: prev && prev.at ? prev.at : now }; if (prev) e.ed = now;
      book.items[target.id] = e; book.ownerName = Store.displayName || book.ownerName || '';
      this.adopt(await this.putBook(book, isNew)); return true;
    } catch(err){ console.warn('save review', err); toast('บันทึกดาวและคอมเมนต์ไม่ได้ (สิทธิ์ไม่พอ หรือการเชื่อมต่อมีปัญหา)'); return false; }
  },
  /* ลบรีวิวของฉันออกจากผลงานหนึ่งชิ้น (ใช้ได้แม้ผลงานนั้นเลิกเผยแพร่หรือโดนลบไปแล้ว) · สมุดที่ว่างแล้วลบทั้งเล่ม */
  async remove(targetId){
    if (!Store.db || !Store.me) return false;
    try { const book = await this.freshMyBook();
      if (book && book.items[targetId]){ delete book.items[targetId];
        if (!Object.keys(book.items).length){ await Store.db.doc('maps/' + book.id).delete(); this.books = this.books.filter(x => x.ownerId !== book.ownerId); this.index(); }
        else this.adopt(await this.putBook(book, false)); }
      else if (book) this.adopt(this.bookDoc(book, book.id, false));
      else { this.books = this.books.filter(x => x.ownerId !== Store.me); this.index(); }
      return true;
    } catch(e){ console.warn('remove review', e); toast('ลบดาวและคอมเมนต์ไม่ได้'); return false; }
  },
  /* ผู้พัฒนาลบรีวิวของคนอื่น (Rules ให้ผู้พัฒนาแก้เอกสารใน maps ได้ทุกฉบับ) */
  async devRemove(rv){
    if (!Store.db || !Store.isDevUid || !rv) return false;
    try { const book = rvCleanBook(docData(await Store.db.doc('maps/' + rv.bookId).get()));
      if (book && book.items[rv.tid]){ delete book.items[rv.tid];
        if (!Object.keys(book.items).length) await Store.db.doc('maps/' + book.id).delete();
        else await Store.db.doc('maps/' + book.id).set(this.bookDoc(book, book.id, false)); }
      await this.load(true); return true;
    } catch(e){ console.warn('dev remove review', e); toast('ลบรีวิวนี้ไม่ได้'); return false; }
  },
};

/* ---- ชิ้นส่วนหน้าจอ ---- */
/* แถบดาวห้าดวง เติมสีตามค่าเฉลี่ย (ชั้นทองซ้อนบนชั้นจาง ตัดความกว้างตามสัดส่วน) */
function rvStarsEl(avg, cls){ const v = Math.max(0, Math.min(5, +avg || 0));
  return h('span',{class:'rvstars' + (cls ? ' ' + cls : ''), role:'img', 'aria-label':`${v.toFixed(1)} จาก 5 ดาว`}, h('span',{class:'rvs-bg','aria-hidden':'true',text:'★★★★★'}), h('span',{class:'rvs-fg','aria-hidden':'true',style:`width:${(v / 5 * 100).toFixed(1)}%`,text:'★★★★★'})); }
function rvDate(r){ const t = r.ed || r.at; return t ? new Date(t).toLocaleDateString('th-TH') + (r.ed ? ' (แก้ไข)' : '') : ''; }
/* ป้ายสรุปบนการ์ดของผลงานที่เผยแพร่: กดเพื่อเปิดหน้าต่างดาวและคอมเมนต์ */
function rvChip(target, onChange){
  if (!Store.db || !target || !target.published) return null;
  const b = h('button',{class:'small ghost rvchip', type:'button', dataset:{id: target.id}, title:'เปิดดูดาวและคอมเมนต์ของผลงานนี้', onclick:(e)=>{ e.stopPropagation(); openReviews(target, onChange); }});
  const fill = ()=>{ clear(b);
    if (!ReviewLib.loaded){ b.append(h('span',{class:'dim',text:'★ กำลังโหลด…'})); return; }
    if (ReviewLib.failed && !ReviewLib.at){ b.append(h('span',{class:'dim',text:'★ โหลดดาวไม่ได้'})); return; }
    const s = ReviewLib.summary(target);
    if (s.n) b.append(rvStarsEl(s.avg), h('b',{class:'num',text: s.avg.toFixed(1)}), h('span',{class:'dim num',text:`(${s.n})`}));
    else b.append(h('span',{class:'dim',text:'☆ ยังไม่มีดาว'}));
    if (s.comments) b.append(h('span',{class:'dim num',text:`· 💬 ${s.comments}`})); };
  fill();
  if (!ReviewLib.loaded) ReviewLib.load().then(()=>{ if (b.isConnected) fill(); }); // หน้าที่ไม่ได้โหลดรีวิวเอง (เช่นดูภาพย่อจากตัวแก้ไขแผนที่) ป้ายจะเติมตัวเองเมื่อโหลดเสร็จ
  return b;
}
/* ตัวเลือกการเรียงของแท็บค้นหา (lib = MapLib หรือ NpcLib จำค่าไว้ใน lib.sort) */
function rvSortSelect(lib, redraw){
  if (!Store.db) return null;
  const sel = h('select',{class:'rvsort','aria-label':'เรียงลำดับ',title:'ดาวสูงสุดเรียงตามดาวเฉลี่ยที่ถ่วงด้วยจำนวนคนให้ดาว ผลงานที่มีคนให้ดาวน้อยจะยังไม่แซงผลงานที่มีคนให้ดาวมาก'}, RV_SORTS.map(([k,l])=>h('option',{value:k,selected:(lib.sort||'new')===k,text:l})));
  sel.onchange = ()=>{ lib.sort = sel.value; redraw(); };
  return sel;
}
function rvMineLabel(){ const n = ReviewLib.myCount(); return n ? `รีวิวของฉัน (${n})` : 'รีวิวของฉัน'; }
function rvMineButton(onChange){ if (!Store.db) return null; return h('button',{class:'small ghost rvminebtn',type:'button',title:'ดู แก้ หรือลบดาวและคอมเมนต์ทั้งหมดที่คุณเคยให้',onclick:()=>openMyReviews(onChange),text: rvMineLabel()}); }
function rvModalOpenFor(id){ const b = $('#modal .rvbox'); return !!b && !$('#modal').classList.contains('hidden') && b.dataset.id === id; }

/* ---- หน้าต่างดาวและคอมเมนต์ของผลงานหนึ่งชิ้น ---- */
function openReviews(target, onChange){
  const st = { stars: 0, text: '', touched: false, busy: false };
  const seed = ()=>{ const m = ReviewLib.mine(target); st.stars = m ? m.s : 0; st.text = m ? m.x : ''; };
  seed();
  const changed = ()=>{ if (typeof onChange === 'function') try { onChange(); } catch(e){ console.warn(e); } };
  const draw = ()=>{
    const sum = ReviewLib.summary(target), list = ReviewLib.list(target), mine = ReviewLib.mine(target), blk = ReviewLib.blocker(target);
    const box = h('div',{class:'rvbox',dataset:{id: target.id}});
    box.append(h('h3',{text:'ดาวและคอมเมนต์'}), h('div',{class:'dim',style:'font-size:12.5px',text:`${rvTypeLabel(rvType(target))} "${target.name || '(ไม่มีชื่อ)'}"${target.ownerName ? ' โดย ' + target.ownerName : ''}`}));
    box.append(h('div',{class:'rvsum'},
      h('div',{class:'rvavg'}, sum.n ? h('b',{class:'num',text: sum.avg.toFixed(1)}) : null, rvStarsEl(sum.avg, 'big'),
        h('div',{class:'dim',style:'font-size:12.5px',text: !ReviewLib.loaded ? 'กำลังโหลดดาวและคอมเมนต์…' : ReviewLib.failed ? 'โหลดดาวและคอมเมนต์ไม่ได้ ลองเปิดใหม่อีกครั้ง' : sum.n ? `${sum.n} คนให้ดาว · ${sum.comments} คอมเมนต์` : sum.comments ? `ยังไม่มีดาว · ${sum.comments} คอมเมนต์` : 'ยังไม่มีใครให้ดาว'})),
      h('div',{class:'rvdist'}, [5,4,3,2,1].map(k=>h('div',{class:'rvbar'}, h('span',{class:'num',text: k + '★'}), h('i',null, h('b',{style:`width:${sum.n ? Math.round(sum.dist[k] / sum.n * 100) : 0}%`})), h('span',{class:'num dim',text: String(sum.dist[k])}))))));
    if (blk){
      box.append(h('div',{class:'infobox rvblk',dataset:{code: blk.code}}, blk.text, blk.code === 'anon' && Store.login ? h('div',{style:'margin-top:6px'}, h('button',{class:'small primary',onclick:()=>Store.login(),text:'เข้าสู่ระบบ Google'})) : null));
    } else {
      const label = h('span',{class:'dim rvpicked',style:'font-size:12.5px;margin-left:6px'});
      const clearBtn = h('button',{class:'small ghost rvclear',type:'button',onclick:()=>{ st.stars = 0; st.touched = true; paint(); },text:'ล้างดาว'});
      const btns = [1,2,3,4,5].map(k=>h('button',{class:'rvstarbtn',type:'button',dataset:{s: k},'aria-label':`ให้ ${k} ดาว`,onclick:()=>{ st.stars = k; st.touched = true; paint(); }}));
      const paint = ()=>{ btns.forEach((b,i)=>{ const on = i < st.stars; b.classList.toggle('on', on); b.textContent = on ? '★' : '☆'; b.setAttribute('aria-pressed', String(i + 1 === st.stars)); }); label.textContent = st.stars ? `${st.stars} ดาว` : 'ยังไม่ให้ดาว'; clearBtn.style.visibility = st.stars ? 'visible' : 'hidden'; };
      const count = h('span',{class:'dim num rvcount',style:'font-size:12px'});
      const ta = h('textarea',{class:'rvtextin',maxlength: RV_TEXT_MAX,placeholder:'เล่าว่าใช้ที่โต๊ะแล้วเป็นอย่างไร จุดไหนดี จุดไหนควรแก้ (ไม่บังคับ)','aria-label':'คอมเมนต์'}); ta.value = st.text;
      const tick = ()=>{ count.textContent = `${ta.value.length}/${RV_TEXT_MAX}`; }; ta.oninput = ()=>{ st.text = ta.value; st.touched = true; tick(); };
      const saveBtn = h('button',{class:'primary small rvsave',type:'button',text: mine ? 'บันทึกการแก้ไข' : 'บันทึก'});
      saveBtn.onclick = async ()=>{ if (st.busy) return; st.busy = true; saveBtn.disabled = true;
        const okSave = await ReviewLib.save(target, st.stars, ta.value); st.busy = false;
        if (okSave){ st.touched = false; seed(); toast('บันทึกดาวและคอมเมนต์แล้ว'); changed(); if (rvModalOpenFor(target.id)) draw(); } else saveBtn.disabled = false; };
      const delBtn = mine ? h('button',{class:'small ghost rvdel',type:'button',onclick:async()=>{ if (st.busy || !confirm('ลบดาวและคอมเมนต์ของคุณออกจากผลงานนี้?')) return; st.busy = true; const okDel = await ReviewLib.remove(target.id); st.busy = false; if (okDel){ st.touched = false; seed(); toast('ลบดาวและคอมเมนต์ของคุณแล้ว'); changed(); if (rvModalOpenFor(target.id)) draw(); } },text:'ลบของฉัน'}) : null;
      box.append(h('div',{class:'rvmine'}, h('div',{class:'kicker',text: mine ? 'ดาวและคอมเมนต์ของคุณ' : 'ให้ดาวและคอมเมนต์'}),
        h('div',{class:'rvpick',role:'group','aria-label':'ให้ดาว'}, btns, label, clearBtn), ta,
        h('div',{class:'row',style:'margin-top:6px'}, saveBtn, delBtn, count),
        h('div',{class:'dim',style:'font-size:12px;margin-top:6px',text:`ทุกคนที่เข้าสู่ระบบเห็นดาวและคอมเมนต์นี้พร้อมชื่อที่แสดงของคุณ (${Store.displayName || 'ผู้เล่น'}) แก้หรือลบได้ทุกเมื่อ`})));
      paint(); tick();
    }
    const lst = h('div',{class:'rvlist'});
    if (!list.length && ReviewLib.loaded && !ReviewLib.failed) lst.append(h('div',{class:'dim rvempty',style:'font-size:13px',text: blk ? 'ยังไม่มีใครให้ดาวหรือคอมเมนต์ผลงานนี้' : 'ยังไม่มีใครให้ดาวหรือคอมเมนต์ เป็นคนแรกได้เลย'}));
    for (const r of list) lst.append(h('div',{class:'rvitem' + (r.uid === Store.me ? ' me' : ''),dataset:{uid: r.uid}},
      h('div',{class:'rvhead'}, h('b',{class:'rvname',title: Store.isDevUid ? 'UID ' + r.uid : null,text: r.name}), r.uid === Store.me ? tag('ของคุณ','prop') : null, r.s ? rvStarsEl(r.s) : h('span',{class:'dim',style:'font-size:12px',text:'ไม่ได้ให้ดาว'}), h('span',{class:'dim rvdate',text: rvDate(r)}),
        Store.isDevUid && r.uid !== Store.me ? h('button',{class:'small ghost rvmod',type:'button',title:'ลบรีวิวนี้ในฐานะผู้พัฒนา',onclick:async()=>{ if (!confirm(`ลบดาวและคอมเมนต์ของ "${r.name}" ออกจากผลงานนี้?`)) return; if (await ReviewLib.devRemove(r)){ toast('ลบรีวิวนั้นแล้ว'); changed(); if (rvModalOpenFor(target.id)) draw(); } },text:'ลบ (ผู้พัฒนา)'}) : null),
      r.x ? h('p',{class:'rvtext',text: r.x}) : null));
    box.append(h('div',{class:'kicker',style:'margin-top:12px',text:`เสียงตอบรับ (${list.length})`}), lst);
    modal(box);
  };
  draw();
  // แคชเก่าหรือยังไม่เคยโหลด: โหลดแล้ววาดใหม่ เว้นแต่ผู้ใช้เริ่มพิมพ์ไปแล้ว (ไม่วาดทับสิ่งที่กำลังพิมพ์ รายการจะสดอีกครั้งเมื่อกดบันทึก)
  const before = ReviewLib.at, wasLoaded = ReviewLib.loaded;
  ReviewLib.load().then(()=>{ const fresh = ReviewLib.at !== before; if (fresh) changed(); if (!rvModalOpenFor(target.id) || st.touched) return; if (!fresh && wasLoaded && !ReviewLib.failed) return; seed(); draw(); });
}

/* ---- หน้าต่างรีวิวของฉัน: ทุกรายการในสมุด รวมถึงผลงานที่เลิกเผยแพร่หรือโดนลบไปแล้ว (ลบข้อมูลของตัวเองได้เสมอ) ---- */
function rvFindTarget(id){ return (typeof MapLib !== 'undefined' && (MapLib.pub.find(x=>x.id===id) || MapLib.mine.find(x=>x.id===id))) || (typeof NpcLib !== 'undefined' && (NpcLib.pub.find(x=>x.id===id) || NpcLib.mine.find(x=>x.id===id))) || null; }
function openMyReviews(onChange){
  const changed = ()=>{ if (typeof onChange === 'function') try { onChange(); } catch(e){ console.warn(e); } };
  const draw = ()=>{
    const book = ReviewLib.myBook(); const rows = book ? Object.keys(book.items).map(tid => Object.assign({ tid }, book.items[tid])).sort((a,b)=> (b.ed || b.at) - (a.ed || a.at)) : [];
    const box = h('div',{class:'rvbox rvmybox',dataset:{id:'@mine'}}, h('h3',{text:'รีวิวของฉัน'}), h('div',{class:'dim',style:'font-size:12.5px',text:'ดาวและคอมเมนต์ทั้งหมดที่คุณเคยให้ ลบได้ทุกรายการ รวมถึงของผลงานที่เลิกเผยแพร่ไปแล้ว'}));
    const lst = h('div',{class:'rvlist'});
    if (!ReviewLib.loaded) lst.append(h('div',{class:'dim',text:'กำลังโหลด…'}));
    else if (!rows.length) lst.append(h('div',{class:'dim rvempty',style:'font-size:13px',text: ReviewLib.isAnon() ? 'บัญชีนิรนามยังให้ดาวหรือคอมเมนต์ไม่ได้ เข้าสู่ระบบด้วย Google ก่อน' : 'คุณยังไม่เคยให้ดาวหรือคอมเมนต์ผลงานไหน'}));
    for (const r of rows){ const target = rvFindTarget(r.tid); const live = !!(target && target.published && target.ownerId !== Store.me);
      lst.append(h('div',{class:'rvitem',dataset:{tid: r.tid}},
        h('div',{class:'rvhead'}, tag(rvTypeLabel(r.t), r.t === 'map' ? null : r.t === 'asset' ? 'prop' : 'neg'), h('b',{class:'rvname',text: r.n || '(ไม่มีชื่อ)'}), r.s ? rvStarsEl(r.s) : h('span',{class:'dim',style:'font-size:12px',text:'ไม่ได้ให้ดาว'}), h('span',{class:'dim rvdate',text: rvDate(r)}),
          live ? h('button',{class:'small ghost rvopen',type:'button',onclick:()=>openReviews(target, onChange),text:'แก้'}) : null,
          h('button',{class:'small ghost rvdel',type:'button',onclick:async()=>{ if (!confirm(`ลบดาวและคอมเมนต์ที่คุณให้ "${r.n || 'ผลงานนี้'}"?`)) return; if (await ReviewLib.remove(r.tid)){ toast('ลบแล้ว'); changed(); if (rvModalOpenFor('@mine')) draw(); } },text:'ลบ'})),
        r.x ? h('p',{class:'rvtext',text: r.x}) : null)); }
    box.append(lst);
    if (Store.isDevUid && ReviewLib.loaded){ // ผู้พัฒนา: รีวิวล่าสุดของทุกคนในที่เดียว จะได้ไม่ต้องเปิดดูทีละผลงาน
      const all = []; for (const arr of ReviewLib.byTarget.values()) for (const r of arr) if (r.uid !== Store.me) all.push(r);
      all.sort((a,b)=> (b.ed || b.at) - (a.ed || a.at)); const shown = all.slice(0, RV_DEV_LIST);
      const dl = h('div',{class:'rvlist rvall'});
      for (const r of shown) dl.append(h('div',{class:'rvitem',dataset:{uid: r.uid, tid: r.tid}},
        h('div',{class:'rvhead'}, tag(rvTypeLabel(r.t), r.t === 'map' ? null : r.t === 'asset' ? 'prop' : 'neg'), h('b',{class:'rvname',title:'UID ' + r.uid,text: r.name}), h('span',{class:'dim rvto',style:'font-size:12.5px',text:`ถึง "${r.n || r.tid}"`}), r.s ? rvStarsEl(r.s) : h('span',{class:'dim',style:'font-size:12px',text:'ไม่ได้ให้ดาว'}), h('span',{class:'dim rvdate',text: rvDate(r)}),
          h('button',{class:'small ghost rvmod',type:'button',title:'ลบรีวิวนี้ในฐานะผู้พัฒนา',onclick:async()=>{ if (!confirm(`ลบดาวและคอมเมนต์ของ "${r.name}" ที่ให้ "${r.n || r.tid}"?`)) return; if (await ReviewLib.devRemove(r)){ toast('ลบรีวิวนั้นแล้ว'); changed(); if (rvModalOpenFor('@mine')) draw(); } },text:'ลบ (ผู้พัฒนา)'})),
        r.x ? h('p',{class:'rvtext',text: r.x}) : null));
      box.append(h('div',{class:'kicker',style:'margin-top:14px',text:'รีวิวล่าสุดทั้งเว็บ (มุมมองผู้พัฒนา)'}), h('div',{class:'dim rvallnote',style:'font-size:12px',text: all.length > shown.length ? `แสดง ${shown.length} รายการล่าสุด จากทั้งหมด ${all.length} รายการ` : `ทั้งหมด ${all.length} รายการ`}), dl);
    }
    modal(box);
  };
  draw();
  ReviewLib.load(true).then(()=>{ if (rvModalOpenFor('@mine')) draw(); });
}
