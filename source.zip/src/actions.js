/* ===== v1.29 (Non สั่ง 16 พ.ย. 2026): Action Track ของโต๊ะเล่น =====
 * "ทำตัว Action Track ให้ด้วยว่าผู้เล่นใช้ Action ไหนไปบ้างแล้ว (แอคชันไหนที่ใช้ไปแล้วจะถูกขีดฆ่า)
 *  โดยทำให้ GM สามารถกดแจก Action ได้ด้วยการคลิ๊กที่ปุ่ม Action ที่ต้องการแจกคืน" และ "การกดเล็งต้องเสีย Swift Action"
 * กฎ (ไฟล์แกน บทระบบการต่อสู้ ข้อ 2): ทุกเทิร์นได้ 1 Swift Action 1 Basic Action และ 1 Cast Action · Reaction ทำได้ไม่จำกัด
 *   Swift: Maneuver (Dash) · Focus · Observe · Reload · สกิลบางอย่าง · Run = Swift + 1 AP · Basic: Attack · Grab · Overwatch · ใช้ไอเทม · Assist · Use Knowledge · สกิล
 *   Cast: ร่าย Skill หรือ Sorcery ประเภท Cast เทิร์นละครั้ง · Perfect Parry / Perfect Evade ได้ Swift Action เพิ่ม 1 ทันที
 * ข้อมูลอยู่บนหมาก (ร่างแฝดที่ใช้เทิร์นร่วมกันใช้ช่องของหมากนำ): t.act = {u:{s,b,c,a} ที่ใช้ไป, x:{...} ที่ได้เพิ่ม, f:{mv ช่องที่เดินแล้ว, run, melee, focus}}
 * เริ่มเทิร์นของหมาก = ล้างที่ใช้ไป · จบเทิร์น = Action ที่ได้เพิ่มแต่ไม่ได้ใช้หมดอายุ · นอกฉากต่อสู้ไม่มีการนับ
 * NPC ที่สแตตบล็อกเขียน AP n: ได้ Swift 1 กับ AP n ช่อง (ช่อง AP ใช้แทนทั้ง Basic และ Cast) ข้อนี้เว็บตีความเอง เอกสาร Fauna เขียนแค่จำนวน AP
 * ค่าจากห้องถือว่าไม่น่าไว้ใจ: อ่านผ่าน cbInt และจำกัดช่วงทุกครั้ง */
const ACT_DEF = {
  s: {label: 'Swift', full: 'Swift Action', ico: '⚡'},
  b: {label: 'Basic', full: 'Basic Action', ico: '⚔'},
  c: {label: 'Cast', full: 'Cast Action', ico: '✦'},
  a: {label: 'AP', full: 'Action Point', ico: '●'},
};
const ACT_ORDER = ['s', 'b', 'c', 'a'];
const Act = {
  pop: null,
  on(r){ r = r || Table.room; return !!(r && r.enc && r.enc.active); },
  curId(r){ r = r || Table.room; return this.on(r) ? ((r.enc.order || [])[r.enc.turnIdx] || null) : null; },
  /* หมากที่ถือช่อง Action: ร่างแฝดที่ใช้เทิร์นร่วมกันชี้ไปที่หมากนำ */
  holder(t){ if (!t) return null; const r = Table.room; if (t.turnWith && r){ const lead = (r.tokens || []).find(x=>x.id === t.turnWith); if (lead) return lead; } return t; },
  isTurn(t, r){ const cur = this.curId(r); if (!cur || !t) return false; return t.id === cur || t.turnWith === cur; },
  base(t){ const hd = this.holder(t); const ap = (hd && !hd.charId && hd.kind === 'npc') ? Math.max(0, Math.min(9, cbInt(hd.ap))) : 0; return ap > 0 ? {s: 1, a: ap} : {s: 1, b: 1, c: 1}; },
  st(t){ const hd = this.holder(t); const a = hd && hd.act && typeof hd.act === 'object' ? hd.act : null; const ob = (v)=>(v && typeof v === 'object') ? v : {}; return {u: ob(a && a.u), x: ob(a && a.x), f: ob(a && a.f)}; },
  ensure(t){ const hd = this.holder(t); if (!hd.act || typeof hd.act !== 'object') hd.act = {u: {}, x: {}, f: {}}; for (const k of ['u', 'x', 'f']) if (!hd.act[k] || typeof hd.act[k] !== 'object') hd.act[k] = {}; return hd.act; },
  /* ช่องที่ใช้จริงของ Action ชนิด k: NPC แบบ AP ใช้ช่อง a แทน Basic และ Cast */
  kindFor(t, k){ const b = this.base(t); return ((k === 'b' || k === 'c') && b.a != null) ? 'a' : k; },
  total(t, k){ k = this.kindFor(t, k); const b = this.base(t); const s = this.st(t); return Math.max(0, Math.min(9, cbInt(b[k]) + Math.max(0, cbInt(s.x[k])))); },
  used(t, k){ k = this.kindFor(t, k); return Math.max(0, Math.min(this.total(t, k), cbInt(this.st(t).u[k]))); },
  left(t, k){ return Math.max(0, this.total(t, k) - this.used(t, k)); },
  flag(t, key){ return this.st(t).f[key]; },
  setFlag(t, key, v){ if (!this.on()) return; this.ensure(t).f[key] = v; },
  name(t, k){ return ACT_DEF[this.kindFor(t, k)].full; },
  /* เหตุที่หมากทำ Action ไม่ได้เลย (สภาวะ) */
  locked(t){ if (!t) return null; const has = (id)=>(t.conds || []).some(c=>c.id === id); if (has('Stunned')) return 'ติด Stunned ทำ Action ในเทิร์นของตนไม่ได้'; if (has('Incapacitated')) return 'ติด Incapacitated ทำ Action ไม่ได้'; return null; },
  /* ใช้ Action หนึ่งช่อง · คืน true เมื่อใช้ได้ (นอกฉากต่อสู้ไม่นับ คืน true เสมอ) · o.force = ใช้แม้หมด (GM ตัดสิน) · ไม่บันทึกห้องเอง คนเรียกบันทึก */
  spend(t, k, o){
    o = o || {}; if (!this.on() || !t) return true; const kk = this.kindFor(t, k);
    if (this.left(t, kk) <= 0 && !o.force) return false;
    const a = this.ensure(t); a.u[kk] = Math.min(9, cbInt(a.u[kk]) + 1);
    if (!o.keepOw){ const hd = this.holder(t); if (hd.ow) delete hd.ow; } // ทำ Action อื่นนอกจาก Overwatch สถานะ Overwatch ถูกลบล้าง
    return true;
  },
  /* GM คืน Action ที่ใช้ไปแล้วหนึ่งช่อง */
  giveBack(t, k){ if (!this.on() || !t) return false; const kk = this.kindFor(t, k); const a = this.ensure(t); if (cbInt(a.u[kk]) <= 0) return false; a.u[kk] = cbInt(a.u[kk]) - 1; return true; },
  /* ได้ Action เพิ่ม (Perfect Defense · สกิล · GM แจก) */
  grant(t, k, n){ if (!this.on() || !t) return false; const kk = this.kindFor(t, k); const a = this.ensure(t); a.x[kk] = Math.max(0, Math.min(6, cbInt(a.x[kk]) + (n || 1))); return true; },
  /* หมากทุกตัวที่ใช้เทิร์นเดียวกับ t (ร่างแฝด) */
  group(r, t){ const hd = this.holder(t); return hd ? (r.tokens || []).filter(x=>x === hd || x.turnWith === hd.id) : []; },
  markManeuver(t){ if (!this.on()) return; const a = this.ensure(t); a.f.mv = Math.max(1, cbInt(a.f.mv)); },
  /* จำนวน Action ที่ใช้ไปในเทิร์นนี้ (พิษคิดความเสียหายจากค่านี้) */
  usedCount(t){ const s = this.st(t); return ACT_ORDER.reduce((n, k)=>n + Math.max(0, cbInt(s.u[k])), 0); },
  /* สภาวะที่หมดอายุตามเทิร์นของผู้ติด: c.ends = {on:'start'|'end', n} ลดทีละ 1 เมื่อถึงจังหวะนั้น เหลือ 0 จึงหลุด */
  expire(r, x, on, lines){ const gone = []; x.conds = (x.conds || []).filter(c=>{ if (!c || !c.ends || c.ends.on !== on) return true; c.ends.n = cbInt(c.ends.n, 1) - 1; if (c.ends.n > 0) return true; gone.push(c); return false; }); for (const c of gone){ for (const sb of twinMindSiblings(x, c.id)) sb.conds = (sb.conds || []).filter(k=>k.id !== c.id); lines.push(`พ้นจากสภาวะ ${c.id} (${on === 'start' ? 'เริ่มเทิร์น' : 'จบเทิร์น'})`); } },
  /* ความเสียหายจากสภาวะ (ไฟล์แกน บทสภาวะ): ไม่หักเกราะ เพราะเป็นความเสียหายจาก Stack */
  hurt(x, n, type, lines, label){ if (n <= 0 || typeof Combat === 'undefined') return; const res = Combat.damage(x, {raw: n, dtype: type, physical: type === 'Physical', noArmor: true}); lines.push(`${label} ทำความเสียหาย ${n} ${type}: ${res.lines.filter(l=>!/ไม่หักเกราะ/.test(l)).join(' · ')}`); x.vitalsAt = Date.now(); },
  startTurn(r, t){
    if (!t) return; const hd = this.holder(t); const keep = this.st(t).x; hd.act = {u: {}, x: Object.assign({}, keep), f: {}};
    // สภาวะที่ผูกกับเทิร์นของหมากนี้ (เช่น Rooted จากพันธนาการเงา "จนถึงเทิร์นถัดไปของคุณ") หลุดเมื่อเทิร์นของมันเริ่ม
    for (const o of r.tokens || []){ const gone = (o.conds || []).filter(c=>c && c.until && (c.until === t.id || c.until === hd.id)); if (!gone.length) continue; o.conds = (o.conds || []).filter(c=>!gone.includes(c)); if (!o.hidden) Table.post({kind: 'sys', who: '', text: `${o.name} พ้นจากสภาวะ ${gone.map(c=>c.id).join(', ')} (ถึงเทิร์นของ ${t.name})`}); }
    for (const x of this.group(r, t)){ delete x.ow; delete x.tactic; const lines = []; this.expire(r, x, 'start', lines);
      const cs = x.conds || []; const bl = cs.find(c=>c.id === 'Bleeding'); const bu = cs.find(c=>c.id === 'Burning');
      if (bl){ const lv = Math.max(1, Math.min(99, cbInt(bl.lv, 1))); const deep = cs.some(c=>c.id === 'Deepwound'); this.hurt(x, lv * (deep ? 2 : 1), 'Physical', lines, `🩸 Bleeding ${lv}${deep ? ' (Deepwound ×2)' : ''}`);
        const nlv = Math.floor(lv / 2); if (nlv <= 0){ x.conds = (x.conds || []).filter(c=>c !== bl); lines.push('Bleeding หมดระดับ'); } else { bl.lv = nlv; lines.push(`Bleeding เหลือระดับ ${nlv}`); } }
      if (bu){ const lv = Math.max(1, Math.min(99, cbInt(bu.lv, 1))); const add = Math.floor(Math.max(0, cbInt(x.hpMax)) / 10); this.hurt(x, lv + add, 'Fire', lines, `🔥 Burning ${lv}${add ? ` บวก ${add} จาก Max HP ${cbInt(x.hpMax)}` : ''}`); }
      const sole = (x.used || {})['sticky:sole']; // ติดไว้ตอน HP ลดต่ำกว่าครึ่งครั้งแรกของการต่อสู้ (combat.js) มีผลตั้งแต่เทิร์นถัดจากนั้น
      if (sole && sole.k !== r.enc.round + ':' + r.enc.turnIdx && typeof Feats !== 'undefined' && Feats.has(x, 'Sole Survivor') && this.grant(x, 'b', 1)) lines.push('ผู้รอดชีวิตคนสุดท้าย: ได้ Basic Action เพิ่ม 1 ในเทิร์นนี้');
      const lock = this.locked(x); if (lock) lines.push(lock);
      if (lines.length) Table.post({kind: 'sys', who: '', text: `เริ่มเทิร์นของ ${x.name}: ${lines.join(' · ')}`, gmOnly: !!x.hidden}); }
  },
  endTurn(r, t){
    if (!t) return; const hd = this.holder(t); const acts = this.usedCount(t);
    for (const x of this.group(r, t)){ const lines = []; const po = (x.conds || []).find(c=>c.id === 'Poisoned');
      if (po){ const lv = Math.max(1, Math.min(99, cbInt(po.lv, 1))); if (acts > 0) this.hurt(x, lv * acts, 'Poison', lines, `☠️ Poisoned ${lv} คูณ ${acts} Action ที่ใช้ในเทิร์นนี้`); else lines.push(`Poisoned ${lv}: เทิร์นนี้ไม่ได้ใช้ Action จึงไม่เสีย HP จากพิษ`); lines.push('ทอย VIT Saving Throw (DC 10) ผ่านแล้วหายจากพิษ'); }
      this.expire(r, x, 'end', lines);
      if (cbInt(this.st(t).f.mv) > 0) delete x.still; else x.still = 1; // ไม่ได้ Maneuver ในเทิร์นนี้: ใช้กับ Patient Ambush Way of the Sun และ Stand Behind Me
      if (lines.length) Table.post({kind: 'sys', who: '', text: `จบเทิร์นของ ${x.name}: ${lines.join(' · ')}`, gmOnly: !!x.hidden}); }
    if (hd.act && typeof hd.act === 'object') hd.act.x = {};
  },
  /* แผนการใช้ Action ของการย้ายหมากหนึ่งครั้งในฉากต่อสู้ (ไฟล์แกน: Dash ใช้ 1 Swift · Run ใช้ 1 Swift บวก 1 AP)
   * คืน null = ไม่นับ (นอกฉากต่อสู้) · {block} = ย้ายไม่ได้ · {wait} = รอผู้เล่นเลือก AP ของ Run · {note, commit()} = ย้ายได้ commit หักช่องให้
   * นับระยะสะสมของเทิร์น (f.mv เป็นจำนวนช่อง) ย้ายหลายจังหวะในระยะ Dash เดียวจึงเสีย Swift ครั้งเดียว · GM ย้ายได้เสมอ ถ้าช่องหมดจะไม่หัก
   * NPC ไม่มีความเร็วในชีท จึงหักแค่ Swift ของการย้ายครั้งแรก ไม่จำกัดระยะ */
  movePlan(r, t, to, gm, opt, retry){
    if (!this.on(r) || !t || t.kind === 'asset' || t.inside) return null; gm = !!gm || Table.localMode; opt = opt || {};
    if (!this.isTurn(t, r)) return {note: ' · นอกเทิร์นของหมากนี้ ไม่หัก Action', commit(){}};
    const lock = this.locked(t); if (lock && !gm) return {block: `${t.name} ${lock}`};
    let ms = null; try { ms = tokenMoveSpeed(t); } catch(e){ ms = null; }
    const reach = moveReach(r, t, 60, null).get(to.x + ',' + to.y); const cost = Math.max(1, reach == null ? cellDist(t, to) : reach);
    const st = this.st(t); const done = Math.max(0, cbInt(st.f.mv)); const total = done + cost; const first = done <= 0;
    let kind = 'dash'; if (ms && ms.dashCells != null && total > ms.dashCells) kind = (ms.runCells != null && total <= ms.runCells) ? 'run' : 'far';
    const noS = first && this.left(t, 's') <= 0;
    if (noS && !gm) return {block: `Swift Action ของ ${t.name} ใช้ไปแล้วในเทิร์นนี้ จึงเคลื่อนที่ไม่ได้ (ขอให้ GM คืน Action ถ้าเคลื่อนที่ได้)`};
    if (kind === 'far' && !gm) return {block: `ไกลเกินระยะของเทิร์นนี้: ${t.name} เดินไปแล้ว ${done * CELL_M} ม. ช่องนี้ต้องใช้อีก ${cost * CELL_M} ม. (${ms.run != null ? 'Run ได้ ' + fmtM(ms.run) : 'Dash ได้ ' + fmtM(ms.dash)} ม.)`};
    let runKind = null;
    if (kind === 'run' && !st.f.run){ const b = this.base(t); const opts = (b.a != null ? ['a'] : ['b', 'c']).filter(k=>this.left(t, k) > 0);
      if (!opts.length){ if (!gm) return {block: `Run ต้องใช้ Swift Action บวก 1 AP แต่ ${b.a != null ? 'AP' : 'Basic และ Cast Action'} ของ ${t.name} ใช้ไปแล้ว ไปได้แค่ระยะ Dash`}; }
      else if (opts.length === 1) runKind = opts[0];
      else if (opt.runAp && opts.includes(opt.runAp)) runKind = opt.runAp;
      else { const pick = (k)=>h('button',{class:'primary runpick-' + k,onclick:()=>{ modal(null); retry({runAp: k}); },text:`ใช้ ${ACT_DEF[k].full}`});
        modal(h('div',{class:'pickbox runpick'}, h('h3',{text:`🏃 ${t.name} จะ Run`}), h('p',{class:'desc',text:`ช่องนี้เกินระยะ Dash (${fmtM(ms.dash)} ม.) ต้อง Run ซึ่งใช้ Swift Action บวก 1 AP เลือก Action ที่จะจ่ายเป็น AP`}), h('div',{class:'row',style:'justify-content:center;gap:8px'}, opts.map(pick), h('button',{class:'ghost',onclick:()=>modal(null),text:'ยกเลิก'}))));
        return {wait: true}; } }
    const self = this; const paidS = first && !noS; const bits = [];
    if (kind === 'far') bits.push('GM ย้ายเกินระยะ Run'); else bits.push(kind === 'run' ? 'Run' : (first ? 'Dash' : 'Dash ต่อ'));
    if (ms) bits.push(`รวม ${total * CELL_M} ม. ในเทิร์นนี้`);
    const used = []; if (paidS) used.push(ACT_DEF.s.full); if (runKind) used.push(ACT_DEF[runKind].full);
    if (used.length) bits.push('ใช้ ' + used.join(' และ ')); else if (noS) bits.push('GM ย้ายโดยไม่หัก Action (Swift ใช้ไปแล้ว)');
    return {note: ' · ' + bits.join(' · '), commit(){ if (paidS) self.spend(t, 's'); if (runKind){ self.spend(t, runKind); } const a = self.ensure(t); a.f.mv = Math.min(99, total); if (runKind || kind === 'run') a.f.run = 1; }};
  },
  /* อายุตั้งต้นของสภาวะที่ระบบใส่ให้จากผลโจมตีหรือทักษะ (ไฟล์แกน: Stunned Unbalanced Deepwound สิ้นสุดเมื่อจบเทิร์นถัดไปของผู้ติด) */
  defaultEnds(t, id){ const r = Table.room; if (!this.on(r) || !['Stunned', 'Unbalanced', 'Deepwound'].includes(id)) return null; return {on: 'end', n: this.isTurn(t, r) ? 2 : 1}; },
  /* ล้างช่อง Action และธงชั่วคราวของความสามารถ (เริ่มทอย Initiative หรือจบการต่อสู้) · จิตอาฆาตกับกระบวนท่าไม่ได้ล้างที่นี่ */
  clearAll(r){ for (const t of (r && r.tokens) || []) for (const k of ['act', 'ow', 'rof', 'iflame', 'missed', 'bmps', 'boto', 'tactic', 'fabs', 'still', 'ablaze', 'pd', 'rhythm']) delete t[k]; },
  /* GM กดเทิร์นถัดไป: จบเทิร์นของหมากเดิม เริ่มเทิร์นของหมากใหม่ */
  onAdvance(r, prevId, nextId){ const find = (id)=>(r.tokens || []).find(x=>x.id === id) || null; this.endTurn(r, find(prevId)); this.startTurn(r, find(nextId)); },
  closePop(){ if (this.pop){ this.pop.remove(); this.pop = null; document.removeEventListener('pointerdown', this._out, true); } },
  /* เมนูลอยข้างปุ่ม: items = [{label, tip, fn, off}] */
  menu(anchor, title, items){
    this.closePop(); const box = h('div',{class:'actmenu',role:'menu'}, title ? h('div',{class:'kicker',text:title}) : null);
    for (const it of items){ if (!it) continue; const b = h('button',{class:'actmi' + (it.off ? ' off' : ''),role:'menuitem',title:it.tip || null,disabled: !!it.off,onclick:()=>{ this.closePop(); it.fn(); }}, h('span',{text:it.label}), it.note ? h('span',{class:'dim',text:it.note}) : null); box.append(b); }
    document.body.append(box); this.pop = box;
    const z = uiZoom(); const rc = anchor.getBoundingClientRect(); const bw = box.offsetWidth, bh = box.offsetHeight; const W = vw(), H = vh();
    let x = rc.left / z, y = rc.bottom / z + 4; if (x + bw > W - 6) x = Math.max(6, W - bw - 6); if (y + bh > H - 6) y = Math.max(6, rc.top / z - bh - 4);
    box.style.left = x + 'px'; box.style.top = y + 'px';
    this._out = (e)=>{ if (this.pop && !this.pop.contains(e.target)) this.closePop(); }; setTimeout(()=>document.addEventListener('pointerdown', this._out, true), 0);
  },
  say(t, text){ if (!t || t.hidden) return; Table.post({kind: 'sys', who: '', text}); },
  /* ใช้ Action แบบกดเอง: หักช่อง ประกาศในแชต บันทึกห้อง */
  manual(t, k, what, fn){
    const r = Table.room; if (!r) return; const gm = Table.isGM() || Table.localMode;
    if (!this.spend(t, k, {force: false})){ toast(`${this.name(t, k)} ของ ${t.name} ใช้ไปแล้วในเทิร์นนี้` + (gm ? ' คลิกช่องที่ขีดฆ่าเพื่อคืนก่อน' : ' ขอให้ GM คืน Action ถ้าทำได้')); return false; }
    if (fn) fn(); this.say(t, `${t.name} ใช้ ${this.name(t, k)}: ${what}`); Table.save(); return true;
  },
  /* รายการในเมนูของช่อง Action ที่ยังไม่ใช้ */
  itemsFor(t, k){
    const r = Table.room; const has = (id)=>(t.conds || []).find(c=>c.id === id) || null; const out = []; const kk = this.kindFor(t, k);
    const moved = !!this.flag(t, 'mv'); const lock = this.locked(t);
    if (lock){ out.push({label: lock, off: true, fn(){}}); if (!(Table.isGM() || Table.localMode)) return out; }
    if (kk === 's'){
      const prone = has('Prone'), unb = has('Unbalanced'), burn = has('Burning');
      if (prone && prone.auto !== 'cling') out.push({label: '🧍 ลุกขึ้นยืน (หาย Prone)', tip: 'ใช้ 1 Maneuver เพื่อลุกขึ้นยืน', fn: ()=>{ if (this.manual(t, 's', 'ลุกขึ้นยืน (Maneuver)', ()=>this.markManeuver(t))) removeCond(t, r, prone, 'ลุกขึ้นยืน'); }});
      if (unb) out.push({label: '🌀 ตั้งหลัก (หาย Unbalanced)', tip: 'ใช้ 1 Maneuver เพื่อตั้งหลัก', fn: ()=>{ if (this.manual(t, 's', 'ตั้งหลัก (Maneuver)', ()=>this.markManeuver(t))) removeCond(t, r, unb, 'ตั้งหลัก'); }});
      if (burn) out.push({label: `🔥 กลิ้งดับไฟ (Burning ${burn.lv || 1} ลด 1)`, tip: 'การ Maneuver 1 ครั้งลด Burning 1', fn: ()=>{ if (this.manual(t, 's', 'Maneuver ลด Burning 1', ()=>this.markManeuver(t))) adjustCond(t, r, burn, -1); }});
      out.push({label: '🏃 Maneuver (Dash)', note: ' ลากหมากไปช่องที่ต้องการ', tip: 'ลากหมากบนแผนที่ ระบบหัก Swift Action ให้เมื่อย้าย · Run ใช้ Swift บวก 1 AP', fn: ()=>toast('ลากหมากไปช่องที่ต้องการ ระบบหัก Swift Action ให้เมื่อย้าย')});
      out.push({label: '🎯 Focus แล้วโจมตี', tip: 'เล็งตำแหน่ง (Precise) Non-Lethal หรือเทคนิคของอาวุธ เลือกในหน้าต่างโจมตี ใช้ไม่ได้ถ้าเคลื่อนที่ไปแล้วในเทิร์นนี้', fn: ()=>{ if (typeof Combat !== 'undefined') Combat.openAttack(t.id, null, {focus: true}); }});
      out.push({label: '👁 Observe (สังเกต)', fn: ()=>this.manual(t, 's', 'Observe')});
      out.push({label: '🔄 Reload (บรรจุกระสุน)', fn: ()=>this.manual(t, 's', 'Reload')});
      out.push({label: '⚡ ใช้กับอย่างอื่น', tip: 'ใช้ Swift Action กับสิ่งที่ไม่อยู่ในรายการ เช่น สื่อสาร หรือสกิลที่ใช้ Swift Action', fn: ()=>this.manual(t, 's', 'อย่างอื่น')});
    } else {
      const basic = kk === 'b' || kk === 'a', cast = kk === 'c' || kk === 'a';
      if (basic){
        out.push({label: '⚔ โจมตี', fn: ()=>{ if (typeof Combat !== 'undefined') Combat.openAttack(t.id); }});
        out.push({label: '🤼 Grab (จับ)', tip: 'ทอย STR Challenge AGI หรือ STR ชนะแล้วเป้าติด Grappled', fn: ()=>{ if (typeof SkillUse !== 'undefined') SkillUse.basic(t.id, 'grab'); }});
        out.push({label: '🛡 Overwatch', off: moved, tip: moved ? 'เคลื่อนที่ไปแล้วในเทิร์นนี้ จึงใช้ Overwatch ไม่ได้' : 'ตั้งท่าป้องกัน: ศัตรูที่เข้าเขตปะทะโดน Opportunity Attack ก่อน การโจมตีที่เล็งมายังคุณติด Disadvantage', fn: ()=>{ if (this.manualKeepOw(t, kk, 'Overwatch')){ this.holder(t).ow = 1; Table.save(); } }});
        out.push({label: '🧰 ใช้ไอเทม', tip: 'ใช้ไอเทมในสายคาดตัวหรือที่เตรียมไว้นอกกระเป๋า ผลของไอเทมปรับที่ชีท', fn: ()=>this.manual(t, kk, 'Use Item')});
        out.push({label: '🤝 Assist (ช่วยเหลือ)', fn: ()=>this.manual(t, kk, 'Assist')});
        out.push({label: '📖 Use Knowledge', tip: 'ทอย Check เพื่อใช้ความรู้ ทอยได้จากหน้าต่างทอยเต๋า', fn: ()=>this.manual(t, kk, 'Use Knowledge')});
      }
      if (cast) out.push({label: '✦ ร่าย Skill หรือ Sorcery', note: ' เลือกจากแถบสกิล', fn: ()=>{ if (typeof SkillUse !== 'undefined') SkillUse.focusBar(t.id); }});
      out.push({label: `${ACT_DEF[kk].ico} ใช้กับอย่างอื่น`, fn: ()=>this.manual(t, kk, 'อย่างอื่น')});
    }
    return out;
  },
  manualKeepOw(t, k, what){ const r = Table.room; if (!r) return false; const gm = Table.isGM() || Table.localMode; if (!this.spend(t, k, {keepOw: true})){ toast(`${this.name(t, k)} ของ ${t.name} ใช้ไปแล้วในเทิร์นนี้` + (gm ? ' คลิกช่องที่ขีดฆ่าเพื่อคืนก่อน' : '')); return false; } this.say(t, `${t.name} ใช้ ${this.name(t, k)}: ${what}`); return true; },
  click(t, k, isUsed, el){
    const r = Table.room; if (!r || !this.on(r)) return; const gm = Table.isGM() || Table.localMode; const can = (typeof Combat !== 'undefined') ? Combat.controls(t) : gm; const nm = this.name(t, k);
    if (isUsed){
      if (!gm){ toast(`${nm} ของ ${t.name} ใช้ไปแล้ว GM เป็นคนคืน Action ได้`); return; }
      if (this.giveBack(t, k)){ this.say(t, `GM คืน ${nm} ให้ ${t.name}`); Table.save(); }
      return;
    }
    if (!can){ toast(`${nm} ของ ${t.name} ยังไม่ได้ใช้`); return; }
    this.menu(el, `${nm} ของ ${t.name}`, this.itemsFor(t, k));
  },
  /* แถบช่อง Action ของหมาก: ที่ใช้ไปแล้วขีดฆ่า · o.big = แสดงชื่อเต็มพร้อมปุ่มแจกของ GM */
  chips(t, r, o){
    o = o || {}; r = r || Table.room; if (!this.on(r) || !t || t.kind === 'asset' || t.inside) return null;
    const gm = Table.isGM() || Table.localMode; const base = this.base(t); const s = this.st(t); const myTurn = this.isTurn(t, r);
    const box = h('span',{class:'acttrack' + (o.big ? ' big' : '') + (myTurn ? ' turn' : ''),dataset:{tok:t.id},role:'group','aria-label':`Action ของ ${t.name}`});
    for (const k of ACT_ORDER){ if (base[k] == null && cbInt(s.x[k]) <= 0) continue; const tot = this.total(t, k), used = this.used(t, k); const d = ACT_DEF[k];
      for (let i = 0; i < tot; i++){ const isUsed = i < used; const extra = i >= cbInt(base[k]);
        const tip = isUsed ? `${d.full} ใช้ไปแล้ว` + (gm ? ' · คลิกเพื่อคืน Action นี้' : '') : `${d.full}${extra ? ' (ได้เพิ่ม)' : ''} ยังไม่ได้ใช้` + (myTurn ? '' : ' · ยังไม่ถึงเทิร์นของหมากนี้');
        // แถวย่อในลำดับเทิร์น: ช่องที่ยังไม่ใช้เป็นป้ายเฉย ๆ (คลิกแล้วเลือกหมากตามปกติ) ช่องที่ใช้แล้วเป็นปุ่มให้ GM คืน · แผงหมากและแผงบังคับ (big) เป็นปุ่มทุกช่อง
        const live = !!o.big || (isUsed && gm);
        const b = h(live ? 'button' : 'span',{class:`actchip k-${k}` + (isUsed ? ' used' : '') + (extra ? ' extra' : '') + (live ? '' : ' still'),dataset:{k, used: isUsed ? '1' : '0'},title:tip,'aria-label':tip,onclick: live ? (e)=>{ e.stopPropagation(); this.click(t, k, isUsed, b); } : null}, h('i',{text:d.ico}), h('span',{text: o.big ? d.label : d.label.charAt(0)}));
        box.append(b); } }
    if (gm && o.big){ const add = h('button',{class:'actchip add',title:'แจก Action เพิ่มให้หมากนี้ (ใช้ได้ถึงจบเทิร์นของมัน)',onclick:(e)=>{ e.stopPropagation(); const mk = (k)=>({label: `+ ${ACT_DEF[this.kindFor(t, k)].full}`, fn: ()=>{ if (this.grant(t, k, 1)){ this.say(t, `GM แจก ${this.name(t, k)} เพิ่มให้ ${t.name}`); Table.save(); } }}); const ks = base.a != null ? ['s', 'a'] : ['s', 'b', 'c']; this.menu(add, `แจก Action ให้ ${t.name}`, ks.map(mk)); },text:'+'}); box.append(add); }
    if (this.holder(t).ow) box.append(h('span',{class:'tag prop acttag',title:'ตั้ง Overwatch อยู่: การโจมตีที่เล็งมายังหมากนี้ติด Disadvantage',text:'🛡 Overwatch'}));
    return box;
  },
};
