/* ===== Online table: rooms, 20×20 grid combat map, encounter order, shared chat & dice, fate clocks ===== */
function newRoom(name){ const id = uid(); return {id, name, gmId: Store.me||'local', gmName: Store.displayName||'', gmKey: uid().slice(0,6).toUpperCase(), hasKey:false, createdAt:Date.now(), updatedAt:Date.now(), map: generateMap('field', id), tokens:[], enc:{active:false, round:0, turnIdx:0, order:[]}, clocks:[], scene:''}; }
/* ห้องรุ่นเก่าที่ใช้โซน: สร้างแผนที่ให้ และวางหมากเดิมลงกริด (GM บันทึกครั้งถัดไปจึงติดถาวร) */
function migrateRoom(r){ if (!r) return r; if (!r.map){ r.map = generateMap('field', r.id); } if (!r.tokens) r.tokens = []; for (const t of r.tokens){ if (t.x==null || t.y==null){ const pos = freeCell(r.map, r.tokens, t.kind==='npc' ? [0,1,2,3] : [16,17,18,19]); t.x = pos.x; t.y = pos.y; } } delete r.zones; return r; }
function gmKeys(){ try { return JSON.parse(localStorage.getItem('kirana.gmkeys')||'{}'); } catch(e){ return {}; } }
function rememberGmKey(roomId, key){ const k = gmKeys(); k[roomId] = key; try { localStorage.setItem('kirana.gmkeys', JSON.stringify(k)); } catch(e){} }

const Table = {
  roomId:null, room:null, chat:[], unsub:[], peers:[], localMode:false, writing:false, pending:null, presence:null,
  rollLock:null, rolling:false, seenRolls:new Set(), chatReady:false,
  roomChars:[], sel:null, brush:null, hover:null,
  isGM(){ if (!this.room) return false; if (this.localMode || this.room.gmId===Store.me || Store.isOwner) return true; const k = gmKeys()[this.room.id]; return !!(k && this.room.gmKey && k===this.room.gmKey); },
  async open(id){
    this.close(); this.roomId = id; this.localMode = !Store.db;
    if (this.localMode){ const rooms = loadLocalRooms(); const lr = rooms.find(r=>r.id===id)||null; if (lr && lr.joinKey && !gmKeys()[id] && localStorage.getItem('kirana.joined.'+id)!==lr.joinKey){ const k = prompt('ห้องนี้ล็อกด้วยรหัส กรอกรหัสเข้าห้อง'); if (k!==lr.joinKey){ toast('รหัสไม่ถูกต้อง'); location.hash='#table'; return; } localStorage.setItem('kirana.joined.'+id, k); } this.room = migrateRoom(lr); this.chat = loadLocalChat(id); renderTable(); return; }
    // ห้องที่ล็อกด้วยรหัส: ดูล็อบบี้ก่อน ถ้ายังไม่เป็นสมาชิกให้กรอกรหัส
    try {
      const lb = docData(await Store.db.doc('lobby/'+id).get());
      if (lb && lb.hasKey && lb.gmId !== Store.me && !Store.isDevUid){
        const mem = await Store.db.doc(`rooms/${id}/members/${Store.me}`).get().catch(()=>null);
        if (!mem || !mem.exists){ this.room = null; renderTable(); const ok = await askRoomKey(id, lb); if (!ok){ location.hash = '#table'; return; } }
      }
    } catch(e){ console.warn('lobby', e); }
    if (this.roomId !== id) return;
    try {
      const u1 = Store.db.doc('rooms/'+id).onSnapshot(snap => { const d = docData(snap); if (d){ this.room = migrateRoom(d); renderTable(); } }, err=>{ console.warn(err); toast('อ่านห้องไม่ได้'); });
      const u4 = Store.db.collection('rooms/'+id+'/chars').onSnapshot(snap => { this.roomChars = snapDocs(snap).filter(Boolean); if (location.hash.startsWith('#sheet-')) { const sid = location.hash.slice(7); if (!Store.chars.some(c=>c.id===sid) && this.roomChars.some(c=>c.id===sid)) renderSheet(sid); } }, err=>console.warn('roomchars', err));
      this.unsub.push(u4);
      let q = Store.db.collection('rooms/'+id+'/chat');
      try { q = q.orderBy('ts','desc').limit(120); } catch(e){}
      const u2 = q.onSnapshot(snap => { const docs = snapDocs(snap).filter(Boolean); docs.sort((a,b)=>(b.ts||0)-(a.ts||0)); this.chat = docs.slice(0,120); renderChatOnly(); this.detectNewRolls(); }, err=>console.warn('chat', err));
      const u3 = Store.db.doc('rooms/'+id+'/meta/roll').onSnapshot(snap => { this.rollLock = docData(snap); updateRollLockUI(); }, err=>console.warn('rolllock', err));
      this.unsub.push(u1,u2,u3);
    } catch(e){ console.warn(e); toast('เชื่อมต่อห้องไม่ได้'); }
    if (Store.room){ try { const r = await Store.room.join('kirana-'+id); this.presence = r; const me = Store.me||'guest'; r.presence({who: me, name: Store.displayName||'', at: Date.now()}); r.onPeers(p=>{ this.peers = Array.isArray(p)? p : Object.values(p||{}); renderPeers(); }); } catch(e){ console.warn('room', e); } }
    renderTable();
  },
  close(){ for (const u of this.unsub) try{ typeof u==='function' && u(); }catch(e){} this.unsub=[]; if (this.presence){ try{ this.presence.leave(); }catch(e){} this.presence=null; } this.roomId=null; this.room=null; this.chat=[]; this.peers=[]; this.roomChars=[]; this.sel=null; this.brush=null; this.rollLock=null; this.rolling=false; this.seenRolls=new Set(); this.chatReady=false; DiceShow.clear(); updateRollLockUI(); },
  /* ---- ด่านล็อกการทอย: ทอยได้ทีละคน ระหว่างเต๋าเด้งอยู่บนจอทุกคน คนอื่นกดทอยไม่ได้ ---- */
  lockActive(lk){ lk = lk===undefined ? this.rollLock : lk; return !!(lk && lk.at && (Date.now() - lk.at) < ROLL_LOCK_TTL); },
  lockedByOther(){ return this.lockActive() && this.rollLock.by !== (Store.me||'local'); },
  async claimRollLock(who, label){
    const me = Store.me||'local'; const lock = {by: me, who, label: label||'', at: Date.now()};
    if (this.localMode) { this.rollLock = lock; return true; }
    try {
      if (FB){ // Firestore transaction: อ่าน-เช็ก-เขียนในรอบเดียว กันสองคนกดพร้อมกัน
        const ref = FB.F.doc(FB.fdb, `rooms/${this.roomId}/meta/roll`);
        return await FB.F.runTransaction(FB.fdb, async tx => { const sn = await tx.get(ref); const cur = sn.exists() ? sn.data() : null; if (this.lockActive(cur) && cur.by !== me) return false; tx.set(ref, lock); return true; });
      }
      const ref = Store.db.doc(`rooms/${this.roomId}/meta/roll`); const sn = await ref.get(); const cur = docData(sn); if (this.lockActive(cur) && cur.by !== me) return false; await ref.set(lock); return true;
    } catch(e){ console.warn('claim lock', e); return true; } // ล็อกล้มเหลว (สิทธิ์/เน็ต) ไม่ควรขวางการเล่น
  },
  async releaseRollLock(){
    const me = Store.me||'local'; if (!this.rollLock || this.rollLock.by !== me) return;
    if (this.localMode){ this.rollLock = null; updateRollLockUI(); return; }
    try { await Store.db.doc(`rooms/${this.roomId}/meta/roll`).set({by:null, who:null, label:'', at:0}); } catch(e){ console.warn('release lock', e); }
  },
  /* guardedRoll(who, run): run() ทอยจริงและโพสต์ เรียกเมื่อได้ล็อกแล้วเท่านั้น */
  async guardedRoll(who, run, label){
    if (!this.roomId){ run(); return; }
    if (this.rolling){ toast('รอเต๋าหยุดก่อน'); return; }
    if (this.lockedByOther()){ toast(`${this.rollLock.who||'ผู้เล่นอีกคน'} กำลังทอยอยู่ รอให้เต๋าหยุดก่อน`); return; }
    this.rolling = true; updateRollLockUI();
    const ok = await this.claimRollLock(who, label);
    if (!ok){ this.rolling = false; updateRollLockUI(); toast(`${(this.rollLock&&this.rollLock.who)||'ผู้เล่นอีกคน'} กดทอยก่อนคุณเสี้ยววินาที รอให้เต๋าหยุดก่อน`); return; }
    // run() อาจเป็น async (ทอยแล้วให้เลือกลูก) ระหว่างรอ ต่ออายุล็อกทุก 3 วิ ไม่ให้หมดอายุก่อนเลือกเสร็จ
    const me = Store.me||'local'; const touch = setInterval(()=>{ if (!this.localMode && this.roomId) Store.db.doc(`rooms/${this.roomId}/meta/roll`).set({by:me, who, label:label||'', at:Date.now()}).catch(()=>{}); }, 3000);
    try { const res = run(); if (res && typeof res.then === 'function') await res; } catch(e){ console.warn(e); }
    clearInterval(touch);
    setTimeout(()=>{ this.rolling = false; this.releaseRollLock(); updateRollLockUI(); }, ROLL_SHOW_MS);
  },
  detectNewRolls(){
    if (!this.chatReady){ this.chatReady = true; for (const m of this.chat) this.seenRolls.add(m.id); return; }
    const gm = this.isGM(); const now = Date.now();
    const fresh = this.chat.filter(m => m.kind==='roll' && m.roll && !this.seenRolls.has(m.id)).sort((a,b)=>(a.ts||0)-(b.ts||0));
    for (const m of fresh){ this.seenRolls.add(m.id); if (m.gmOnly && !gm && m.authorId!==Store.me) continue; if (now - (m.ts||0) > 20000) continue; DiceShow.enqueue(m); }
  },
  async save(){ // one write at a time; latest state wins
    const r = this.room; if (!r) return; r.updatedAt = Date.now();
    if (this.localMode){ const rooms = loadLocalRooms(); const i=rooms.findIndex(x=>x.id===r.id); if(i>=0) rooms[i]=r; else rooms.push(r); saveLocalRooms(rooms); renderTable(); return; }
    renderTable();
    if (this.writing){ this.pending = true; return; }
    this.writing = true;
    try { await Store.db.doc('rooms/'+r.id).set(JSON.parse(JSON.stringify(r))); Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)).catch(()=>{}); } catch(e){ console.warn('save room', e); toast('บันทึกห้องไม่ได้ (สิทธิ์ไม่พอ?)'); }
    this.writing = false; if (this.pending){ this.pending=false; this.save(); }
  },
  async post(msg){
    msg.id = uid(); msg.ts = Date.now(); msg.authorId = Store.me||'local';
    if (this.localMode){ this.chat.unshift(msg); this.chat = this.chat.slice(0,200); saveLocalChat(this.roomId, this.chat); renderChatOnly(); if (msg.kind==='roll') DiceShow.enqueue(msg); return; }
    try { await Store.db.doc(`rooms/${this.roomId}/chat/${msg.id}`).set(msg); } catch(e){ console.warn(e); toast('ส่งข้อความไม่ได้ (สิทธิ์ไม่พอ?)'); }
  },
  postRoll(e, c){ if (!this.roomId) return; this.post({kind:'roll', who: c? c.name : (this.isGM()?'GM':'ผู้เล่น'), text:e.label, roll:{dice:e.r.dice, kept:e.r.kept, keptIdx:e.r.keptIdx, sum:e.r.sum, crit:e.r.crit, double:e.r.double, mode:e.mode, chosen:!!e.r.chosen}, mod:e.mod, pm:e.pm, persSide:e.persSide, total:e.total, judge:e.judge, dc:e.dc, gmOnly:false}); },
};
const ROLL_SHOW_MS = 4200;      // เต๋าค้างบนจอ
const ROLL_LOCK_TTL = 8000;     // ล็อกหมดอายุเองถ้าคนทอยหลุดก่อนปล่อย
/* ---- ป๊อปอัปเต๋าเด้งหน้าทุกคนในห้อง (ต่อคิวถ้ามาหลายอัน) ---- */
const DiceShow = {
  q:[], cur:null, timer:null,
  enqueue(m){ this.q.push(m); if (!this.cur) this.next(); },
  clear(){ this.q=[]; if (this.timer) clearTimeout(this.timer); this.timer=null; this.cur=null; const o=$('#dice-overlay'); if (o){ clear(o); o.classList.add('hidden'); } },
  next(){
    const m = this.q.shift(); if (!m){ this.cur=null; return; }
    this.cur = m; const o = $('#dice-overlay'); if (!o) return;
    clear(o); o.classList.remove('hidden');
    const r = m.roll; const dice = r.dice||[]; const keptIdx = r.keptIdx||[];
    const dieEls = dice.map((v,i)=>h('div',{class:'bigdie tumble'+(keptIdx.includes(i)?'':' drop')}, h('span',{text:'?'})));
    const box = h('div',{class:'dicebox'}, h('div',{class:'dice-who'}, h('span',{class:'who',text:m.who||''}), ' ', h('b',{text:m.text||'ทอยเต๋า'}), r.mode&&r.mode!=='normal'? [' ', tag(r.mode==='adv'?'Advantage':'Disadvantage', r.mode==='adv'?'ok':'neg')]:null, r.chosen? [' ', tag('เลือกลูกเอง','prop')]:null, m.gmOnly? [' ', h('span',{class:'gm',text:'ลับ'})]:null),
      h('div',{class:'dice-row'}, dieEls), h('div',{class:'dice-total',text:''}), h('div',{class:'dice-judge',text:''}));
    o.append(box);
    // หมุนหน้าเต๋าสุ่มสักพักแล้วหยุดทีละลูก
    let tick = 0; const spin = setInterval(()=>{ tick++; dieEls.forEach((el,i)=>{ if (tick < 10 + i*4) el.firstChild.textContent = 1 + Math.floor(Math.random()*6); else { el.firstChild.textContent = dice[i]; el.classList.remove('tumble'); } }); if (tick >= 10 + dice.length*4){ clearInterval(spin); settle(); } }, 70);
    const settle = ()=>{ const tot = box.querySelector('.dice-total'); const parts = [`${(r.kept||[]).join('+')}`]; if (m.mod) parts.push(signed(m.mod)); if (m.pm) parts.push(`${m.persSide||''} ${signed(m.pm)}`); tot.textContent = parts.join(' ') + ' = ' + m.total; tot.classList.add('show'); const j = box.querySelector('.dice-judge'); if (m.judge){ j.textContent = m.judge.text||''; j.className = 'dice-judge show ' + (m.judge.cls||''); } if (m.dc!=null) j.textContent += ` (DC ${m.dc})`; if (r.crit==='success' || r.double) box.classList.add('crit'); };
    this.timer = setTimeout(()=>{ o.classList.add('hidden'); clear(o); this.cur=null; this.next(); }, ROLL_SHOW_MS);
  }
};
function updateRollLockUI(){
  const other = Table.roomId && Table.lockedByOther();
  const busy = !!(Table.roomId && (Table.rolling || other));
  document.body.classList.toggle('roll-locked', busy);
  const b = $('#roll-lock-banner'); if (!b) return;
  if (other){ b.textContent = `${Table.rollLock.who||'ผู้เล่นอีกคน'} กำลังทอยเต๋า… รอให้เต๋าหยุดก่อน`; b.classList.remove('hidden'); }
  else if (Table.rolling){ b.textContent = 'เต๋าของคุณกำลังทอย…'; b.classList.remove('hidden'); }
  else b.classList.add('hidden');
}
setInterval(()=>{ if (Table.roomId && Table.rollLock && !Table.lockActive() && document.body.classList.contains('roll-locked') && !Table.rolling) updateRollLockUI(); }, 1000);
function loadLocalRooms(){ try{ return JSON.parse(localStorage.getItem('kirana.rooms.v1')||'[]'); }catch(e){ return []; } }
function saveLocalRooms(r){ try{ localStorage.setItem('kirana.rooms.v1', JSON.stringify(r)); }catch(e){} }
function loadLocalChat(id){ try{ return JSON.parse(localStorage.getItem('kirana.chat.'+id)||'[]'); }catch(e){ return []; } }
function saveLocalChat(id, c){ try{ localStorage.setItem('kirana.chat.'+id, JSON.stringify(c)); }catch(e){} }

let roomsCache = []; let roomsUnsub = null;
/* ---- ล็อบบี้: ข้อมูลห้องที่ทุกคนเห็นได้ (ชื่อ GM มีรหัสไหม) แยกจากตัวห้องซึ่งอาจล็อกด้วยรหัส ---- */
function lobbyDoc(r){ return { id:r.id, name:r.name||'', gmId:r.gmId||'', gmName:r.gmName||'', hasKey:!!r.hasKey, tokens:(r.tokens||[]).length, encActive:!!(r.enc&&r.enc.active), round:(r.enc&&r.enc.round)||0, scene:(r.scene||'').slice(0,100), updatedAt:r.updatedAt||Date.now() }; }
async function joinRoomWithKey(id, key){ const me = Store.me; await Store.db.doc(`rooms/${id}/members/${me}`).set({ uid: me, name: Store.displayName||'', key: String(key), at: Date.now() }); try { await Store.db.doc(`rooms/${id}/members/${me}`).set({ uid: me, name: Store.displayName||'', at: Date.now() }); } catch(e){} }
async function setRoomKey(r, key){ // GM เท่านั้น: key ว่าง = ปลดล็อก
  if (!Store.db){ r.joinKey = key || null; r.hasKey = !!key; Table.save(); return; }
  if (key){ await Store.db.doc('roomsecrets/'+r.id).set({ value: String(key), roomId: r.id, at: Date.now() }); r.hasKey = true; await Table.save(); try { await joinRoomWithKey(r.id, key); } catch(e){} }
  else { r.hasKey = false; await Table.save(); try { await Store.db.doc('roomsecrets/'+r.id).delete(); } catch(e){} }
}
/* ลบสำเนาชีทของหมากที่ถูกเอาออกจากบอร์ด (เจ้าของ: เลิกซิงก์ด้วย) */
function dropTokenCopy(r, t){ if (!t || !t.charId) return; const mine = Store.chars.find(c=>c.id===t.charId && Store.isMine(c)); if (mine) Store.unshareFromRoom(mine, r.id); else if (Store.db) Store.db.doc(`rooms/${r.id}/chars/${t.charId}`).delete().catch(()=>{}); }
async function deleteCollection(path){ if (!Store.db) return; try { const snap = await Store.db.collection(path).get(); await Promise.all(snap.docs.map(d => Store.db.doc(path+'/'+d.id).delete().catch(()=>{}))); } catch(e){ console.warn('delete', path, e); } }
async function deleteRoomDeep(r){
  for (const t of r.tokens||[]) { const mine = Store.chars.find(c=>c.id===t.charId && Store.isMine(c)); if (mine) Store.unshareFromRoom(mine, r.id); }
  if (!Store.db) return;
  for (const sub of ['chars','chat','members','meta','presence']) await deleteCollection(`rooms/${r.id}/${sub}`);
  try { await Store.db.doc('lobby/'+r.id).delete(); } catch(e){}
  try { await Store.db.doc('roomsecrets/'+r.id).delete(); } catch(e){}
  try { await Store.db.doc('rooms/'+r.id).delete(); } catch(e){ toast('ลบห้องไม่ได้'); }
}
function roomKeyModal(r){
  const inp = h('input',{placeholder:'รหัสเข้าห้อง (4 ตัวขึ้นไป)',style:'min-width:220px',value:''});
  modal(h('div',null, h('h3',{text:'รหัสเข้าห้อง'}), h('p',{class:'desc'}, r.hasKey ? 'ห้องนี้มีรหัสอยู่แล้ว ผู้เล่นต้องกรอกรหัสก่อนเข้าครั้งแรก (บัญชีที่เข้าแล้วไม่ต้องกรอกซ้ำ) รหัสใหม่ใช้กับคนที่ยังไม่เคยเข้า' : 'ตั้งรหัสแล้ว คนที่มีแค่ลิงก์จะเข้าห้องไม่ได้จนกว่าจะกรอกรหัสถูก แชต หมาก และสำเนาชีทในห้องอ่านได้เฉพาะคนในห้อง'),
    h('div',{class:'row',style:'margin-top:8px'}, inp, h('button',{class:'primary small',onclick:async()=>{ const k = inp.value.trim(); if (k.length < 4){ toast('รหัสสั้นเกินไป'); return; } try { await setRoomKey(r, k); toast('ตั้งรหัสเข้าห้องแล้ว'); modal(null); renderTable(); } catch(e){ console.warn(e); toast('ตั้งรหัสไม่ได้ (ต้องเป็น GM ที่สร้างห้อง และ Rules ต้องเป็นรุ่น v1.2)'); } },text: r.hasKey ? 'เปลี่ยนรหัส' : 'ตั้งรหัส'}),
      r.hasKey ? h('button',{class:'small ghost',onclick:async()=>{ try { await setRoomKey(r, ''); toast('ปลดรหัสแล้ว ห้องเปิดให้ทุกคนที่มีลิงก์'); modal(null); renderTable(); } catch(e){ toast('ปลดรหัสไม่ได้'); } },text:'ปลดรหัส'}) : null)));
}
function askRoomKey(id, lobby){
  return new Promise(resolve => {
    const inp = h('input',{placeholder:'รหัสเข้าห้อง',style:'min-width:220px'});
    const go = async ()=>{ const k = inp.value.trim(); if (!k) return; try { await joinRoomWithKey(id, k); modal(null); resolve(true); } catch(e){ console.warn(e); toast('รหัสไม่ถูกต้อง'); } };
    inp.onkeydown = (e)=>{ if (e.key==='Enter') go(); };
    modal(h('div',null, h('h3',{text:`ห้อง "${lobby.name||''}" ล็อกด้วยรหัส`}), h('p',{class:'desc',text:`GM: ${lobby.gmName||'-'} · ขอรหัสเข้าห้องจาก GM แล้วกรอกครั้งเดียว บัญชีนี้จะเข้าได้ตลอด`}), h('div',{class:'row',style:'margin-top:8px'}, inp, h('button',{class:'primary small',onclick:go,text:'เข้าห้อง'}), h('button',{class:'small ghost',onclick:()=>{ modal(null); resolve(false); },text:'ยกเลิก'}))));
    setTimeout(()=>inp.focus(), 50);
  });
}
function renderTableHome(){
  const root = clear($('#v-table'));
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'โต๊ะเล่น'}), h('p',{text:'ห้องหนึ่งคือหนึ่งโต๊ะ GM สร้างห้องแล้วส่งลิงก์ ผู้เล่นวางตัวละครลงแผนที่ 20×20 ทอยเต๋าร่วมกันในแชต'}))));
  if (!Store.db){
    root.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'ตอนนี้ไม่มีการเชื่อมต่อฐานข้อมูล (เปิดไฟล์ออฟไลน์ หรือเชื่อม Firebase ไม่สำเร็จ) ห้องที่สร้างจะอยู่ในเครื่องนี้เท่านั้น ใช้ทดลองแผนที่และทอยเต๋าได้ แต่คนอื่นจะไม่เห็น'));
  } else if (Store.canWrite===false){
    root.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'คุณเปิดเพจแบบดูอย่างเดียว: อ่านห้องได้แต่ย้ายตัวละครหรือส่งข้อความไม่ได้ ขอให้เจ้าของเพจแชร์ให้คุณเป็น Contributor'));
  }
  const nameInp = h('input',{placeholder:'ชื่อห้อง เช่น คืนวันสถาปนา',style:'min-width:240px'});
  root.append(h('div',{class:'card',style:'margin-bottom:14px'}, h('div',{class:'row'}, nameInp, h('button',{class:'primary',onclick:async()=>{ const nm = nameInp.value.trim()||'โต๊ะใหม่'; const r = newRoom(nm); rememberGmKey(r.id, r.gmKey); if (!Store.db){ const rooms=loadLocalRooms(); rooms.push(r); saveLocalRooms(rooms); } else { try{ await Store.db.doc('rooms/'+r.id).set(r); await Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)); }catch(e){ toast('สร้างห้องไม่ได้ (สิทธิ์ไม่พอ?)'); return; } } location.hash='#room-'+r.id; },text:'สร้างห้อง (คุณเป็น GM)'}))));
  const list = h('div',{class:'grid two'});
  const draw = (rooms)=>{ clear(list); if(!rooms.length) list.append(h('div',{class:'card dim',text:'ยังไม่มีห้อง'})); for (const r of rooms.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0))) list.append(h('div',{class:'card pick',onclick:()=>{location.hash='#room-'+r.id;}}, h('h3',{text:r.name||'(ไม่มีชื่อ)'}), h('div',{class:'gives'}, tag(`${Array.isArray(r.tokens)? r.tokens.length : (r.tokens||0)} ตัวละครบนบอร์ด`), (r.encActive || (r.enc&&r.enc.active))? tag(`กำลังสู้ รอบ ${r.round||(r.enc&&r.enc.round)||0}`,'neg') : null, r.hasKey ? tag('🔒 มีรหัส','warn') : null, (r.gmId===Store.me||!Store.db||gmKeys()[r.id])? tag('คุณเป็น GM','prop'):null), h('div',{class:'desc',text: (r.gmName? 'GM: '+r.gmName+' · ' : '') + (r.scene? r.scene.slice(0,100) : '')}))); };
  root.append(list);
  if (!Store.db) draw(loadLocalRooms());
  else { draw(roomsCache); if (!roomsUnsub){ const merge = (a, b)=>{ const m = new Map(); for (const x of [...a, ...b]) if (x && x.id && !m.has(x.id)) m.set(x.id, x); return [...m.values()]; }; let lobbyList = [], legacy = []; const refresh = ()=>{ roomsCache = merge(lobbyList, legacy); if (location.hash==='#table') renderTableHome(); };
      try{ roomsUnsub = Store.db.collection('lobby').onSnapshot(snap=>{ lobbyList = snapDocs(snap).filter(Boolean); refresh(); }, e=>console.warn('lobby', e)); }catch(e){ console.warn(e); }
      try{ Store.db.collection('rooms').onSnapshot(snap=>{ legacy = snapDocs(snap).filter(Boolean).map(r=>Object.assign(lobbyDoc(r), {legacy:true})); refresh(); }, e=>{ /* Rules รุ่นใหม่ไม่ให้ query ห้องตรง ๆ ใช้ล็อบบี้แทน */ }); }catch(e){} } }
}

function renderTable(){
  if (!Table.roomId || location.hash!=='#room-'+Table.roomId) return;
  const root = clear($('#v-table'));
  const r = Table.room;
  if (!r){ root.append(h('div',{class:'card',text: Table.localMode ? 'ไม่พบห้องนี้ในเครื่อง (ถ้าเป็นห้องออนไลน์ รอการเชื่อมต่อสักครู่)' : 'กำลังเปิดห้อง… (ถ้าค้างนาน แปลว่าไม่พบห้องนี้)'}), h('button',{style:'margin-top:10px',onclick:()=>{location.hash='#table';},text:'← กลับรายการห้อง'})); return; }
  const gm = Table.isGM();
  const myChars = Store.chars.filter(c=>c.done && Store.isMine(c));
  // หมากของฉันที่ยังไม่มีสำเนาชีทในห้อง (วางไว้ตั้งแต่รุ่นก่อน) → แชร์ให้ GM เห็นได้
  if (!Table.localMode) for (const t of r.tokens||[]) if (t.charId && t.ownerId===Store.me && !Table.roomChars.some(x=>x.id===t.charId)){ const c = Store.chars.find(x=>x.id===t.charId); if (c && !(c.roomIds||[]).includes(r.id)) Store.shareToRoom(c, r.id); }
  // ห้องรุ่นก่อนไม่มีเอกสารล็อบบี้: GM เขียนให้ครั้งแรกที่เปิด
  if (gm && !Table.localMode && Table.lobbyWritten !== r.id){ Table.lobbyWritten = r.id; Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)).catch(()=>{}); }
  // ตัวละครของฉันที่ยังซิงก์กับห้องนี้แต่หมากถูกเอาออกไปแล้ว → เลิกซิงก์และลบสำเนา
  if (!Table.localMode) for (const c of Store.chars) if (Store.isMine(c) && (c.roomIds||[]).includes(r.id) && !(r.tokens||[]).some(t=>t.charId===c.id)) Store.unshareFromRoom(c, r.id);
  // header
  const gmKeyBtn = gm && r.gmKey ? h('button',{class:'small ghost',title:'รหัสสำหรับเข้าเป็น GM จากเครื่องอื่น',onclick:()=>{ modal(h('div',null, h('h3',{text:'รหัส GM ของห้องนี้'}), h('p',{class:'desc',text:'ใช้เมื่อคุณเปิดห้องจากเครื่องหรือเบราว์เซอร์อื่น: กด "เข้าเป็น GM" แล้วกรอกรหัสนี้ อย่าให้ผู้เล่นเห็น'}), h('div',{style:'font-family:var(--font-display);font-size:28px;letter-spacing:4px',text:r.gmKey}))); },text:'รหัส GM'}) : null;
  const becomeGm = !gm && r.gmKey ? h('button',{class:'small ghost',onclick:()=>{ const k=(prompt('กรอกรหัส GM ของห้องนี้')||'').trim().toUpperCase(); if(!k) return; if (k===r.gmKey){ rememberGmKey(r.id,k); toast('คุณเป็น GM ของห้องนี้แล้ว'); renderTable(); } else toast('รหัสไม่ถูกต้อง'); },text:'เข้าเป็น GM'}) : null;
  const keyBtn = gm ? h('button',{class:'small ghost'+(r.hasKey?' on':''),title:'ตั้งรหัสให้ผู้เล่นต้องกรอกก่อนเข้าห้อง',onclick:()=>roomKeyModal(r),text: r.hasKey ? '🔒 รหัสเข้าห้อง' : 'ตั้งรหัสเข้าห้อง'}) : (r.hasKey ? tag('🔒 ห้องมีรหัส') : null);
  const shareBtn = h('button',{class:'small ghost',onclick:()=>{ const url = location.href.split('#')[0] + '#room-' + r.id; navigator.clipboard.writeText(url).then(()=>toast('คัดลอกลิงก์ห้องแล้ว')).catch(()=>modal(h('div',null, h('h3',{text:'ลิงก์ห้อง'}), h('input',{style:'width:100%',value:url,readonly:true})))); },text:'ลิงก์ห้อง'});
  const head = h('div',{class:'stephead'}, h('div',null, h('h2',{text:r.name}), h('p',null, gm? tag('คุณเป็น GM','prop') : tag('ผู้เล่น'), ' ', h('span',{id:'peers',class:'dim',style:'font-size:13px'}), Table.localMode? [' ', tag('ห้องในเครื่องนี้','warn')] : null)),
    h('div',{class:'row'}, shareBtn, keyBtn, gmKeyBtn, becomeGm, gm? h('button',{class:'small ghost',onclick:async()=>{ if(!confirm(`ลบห้อง "${r.name}" ถาวร? แชต บอร์ด และสำเนาชีทในห้องจะหายทั้งหมด`)) return; const id=r.id; const snapshot = JSON.parse(JSON.stringify(r)); Table.close(); if (!Store.db){ saveLocalRooms(loadLocalRooms().filter(x=>x.id!==id)); for (const t of snapshot.tokens||[]){ const mine = Store.chars.find(c=>c.id===t.charId); if (mine) Store.unshareFromRoom(mine, id); } } else { toast('กำลังลบห้องและสำเนาชีท…'); await deleteRoomDeep(snapshot); } location.hash='#table'; },text:'ลบห้อง'}) : null, h('button',{class:'small ghost',onclick:()=>{ Table.close(); location.hash='#table'; },text:'← ออกจากห้อง'})));
  root.append(head);
  const left = h('div'); const right = h('div');
  // scene text
  if (gm){ const ta = h('textarea',{placeholder:'บรรยายฉาก (ผู้เล่นเห็น)'}); ta.value = r.scene||''; ta.onblur = ()=>{ if (ta.value!==(r.scene||'')){ r.scene = ta.value; Table.save(); } }; left.append(h('div',{class:'card',style:'margin-bottom:12px'}, h('label',{text:'ฉาก'}), ta)); }
  else if (r.scene) left.append(h('div',{class:'card',style:'margin-bottom:12px'}, h('div',{class:'kicker',text:'ฉาก'}), h('p',{style:'margin:4px 0 0',text:r.scene})));
  // add token controls
  const addRow = h('div',{class:'row',style:'margin-bottom:10px'});
  if (myChars.length){ const sel = h('select',null, myChars.map(c=>h('option',{value:c.id,text:c.name}))); addRow.append(sel, h('button',{class:'small primary',onclick:()=>placeCharacter(Store.get(sel.value), r),text:'วางตัวละครลงบอร์ด'})); }
  else addRow.append(h('span',{class:'dim',style:'font-size:13px',text:'ยังไม่มีตัวละครที่พร้อมเล่น สร้างในหน้า "สร้างตัวละคร" ก่อน'}));
  if (gm){ const nm=h('input',{placeholder:'ชื่อ NPC/ศัตรู',style:'width:150px'}); const hp=h('input',{type:'number',placeholder:'HP',style:'width:70px',value:10}); const ini=h('input',{type:'number',placeholder:'Init',style:'width:70px',value:0}); addRow.append(nm,hp,ini, h('button',{class:'small',onclick:()=>{ const n=nm.value.trim()||'ศัตรู'; const pos = freeCell(r.map, r.tokens, [0,1,2,3]); r.tokens.push({id:uid(), name:n, kind:'npc', x:pos.x, y:pos.y, hp:+hp.value||10, hpMax:+hp.value||10, san:0, sanMax:0, init:+ini.value||0, hidden:true, note:''}); Table.save(); },text:'+ NPC (ซ่อนไว้ก่อน)'})); }
  left.append(addRow);
  // ---- แผนที่ต่อสู้ 20×20 ----
  left.append(mapPanel(r, gm));
  left.append(h('p',{class:'dim',style:'font-size:12px;margin-top:8px',text:`1 ช่อง = ${CELL_M} เมตร · ติดกัน (รวมทแยง) = เขตปะทะ · ไม่เกิน 25 ม. = เขตใกล้เคียง · ไกลกว่านั้น = เขตไกล · Maneuver: ใกล้เคียง→ปะทะ 1 Swift · ปะทะ→ใกล้เคียง 1 Swift (โดนโจมตีฉวยโอกาส) · ใกล้เคียง→ไกล Swift + 1 AP · ช่องช้า (น้ำตื้น หิมะ โคลน เศษหิน) นับ 2 ช่อง`}));
  // encounter panel
  const enc = h('div',{class:'card',style:'margin-bottom:12px'});
  enc.append(h('h3',null, 'ลำดับเทิร์น ', r.enc.active? tag(`รอบ ${r.enc.round}`,'neg') : tag('ยังไม่เริ่ม')));
  if (r.enc.active){
    const ol = h('ol',{class:'init'});
    r.enc.order.forEach((tid,i)=>{ const t=r.tokens.find(x=>x.id===tid); if(!t) return; if (!gm && t.hidden) return; ol.append(h('li',{class:i===r.enc.turnIdx?'cur':''}, h('span',{text:t.name}), h('span',{class:'num dim',text:`Init ${t.initRoll??'?'}`}))); });
    enc.append(ol);
    if (gm) enc.append(h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary small',onclick:()=>{ r.enc.turnIdx++; if (r.enc.turnIdx>=r.enc.order.length){ r.enc.turnIdx=0; r.enc.round++; } Table.save(); const t=r.tokens.find(x=>x.id===r.enc.order[r.enc.turnIdx]); if (t && !t.hidden) Table.post({kind:'sys',who:'',text:`เทิร์นของ ${t.name} (รอบ ${r.enc.round})`}); },text:'เทิร์นถัดไป →'}), h('button',{class:'small',onclick:()=>rollInitiative(r),text:'ทอย Initiative ใหม่'}), h('button',{class:'small ghost',onclick:()=>{ r.enc={active:false,round:0,turnIdx:0,order:[]}; Table.save(); Table.post({kind:'sys',who:'',text:'จบฉากต่อสู้'}); },text:'จบการต่อสู้'})));
    else { const t=r.tokens.find(x=>x.id===cur); if (t && t.ownerId===Store.me) enc.append(h('div',{class:'okbox',style:'margin-top:8px',text:'ถึงเทิร์นของคุณ: 1 Swift, 1 Basic, 1 Cast'})); }
  } else if (gm) enc.append(h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary small',onclick:()=>rollInitiative(r),text:'เริ่มการต่อสู้ (ทอย 2d6 + Initiative ทุกคน)'})));
  enc.append(h('p',{class:'dim',style:'font-size:12px;margin:8px 0 0',text:'ฉาก = 1 นาที · เทิร์น = 6 วินาที · ซุ่มโจมตีได้เทิร์นก่อนเสมอ · ทอยใหม่เมื่อเปลี่ยนฉาก'}));
  right.append(enc);
  // clocks
  const ck = h('div',{class:'card',style:'margin-bottom:12px'}, h('h3',{text:'นาฬิกาชะตากรรม (Fate Clock)'}));
  const ckrow = h('div',{class:'row',style:'margin-top:8px;align-items:flex-start'});
  for (const cl of r.clocks||[]) ckrow.append(clockEl(cl, r, gm));
  ck.append(ckrow);
  if (gm){ const nm=h('input',{placeholder:'ชื่อนาฬิกา',style:'width:140px'}); const seg=h('select',null,[4,6,8,10,12].map(n=>h('option',{value:n,text:n+' ช่อง'}))); ck.append(h('div',{class:'row',style:'margin-top:8px'}, nm, seg, h('button',{class:'small',onclick:()=>{ r.clocks=r.clocks||[]; r.clocks.push({id:uid(),name:nm.value.trim()||'นาฬิกา',seg:+seg.value,fill:0}); Table.save(); },text:'+ นาฬิกา'}))); }
  right.append(ck);
  // chat + dice
  const chatBox = h('div',{class:'card chat'}, h('h3',{text:'แชตและการทอยของโต๊ะ'}), h('div',{class:'log',id:'chatlog'}));
  const who = h('select',{id:'chat-who'}, h('option',{value:'',text: gm?'GM'+(Store.displayName?' ('+Store.displayName+')':'') : (Store.displayName||'ผู้เล่น')}), myChars.map(c=>h('option',{value:c.id,text:c.name})));
  const inp = h('input',{placeholder:'พิมพ์ข้อความ หรือ /r 2d6+2 · /adv · /dis · /gm (ลับ)',style:'flex:1;min-width:160px'});
  const send = ()=>{ const txt = inp.value.trim(); if(!txt) return; inp.value=''; const c = Store.get(who.value); const name = c? c.name : (gm?'GM':(Store.displayName||'ผู้เล่น')); handleChatInput(txt, name, c, gm); };
  inp.onkeydown = (e)=>{ if (e.key==='Enter' && !e.isComposing){ e.preventDefault(); send(); } };
  chatBox.append(h('div',{class:'row'}, who, inp, h('button',{class:'primary small',onclick:send,text:'ส่ง'})));
  const quick = h('div',{class:'row'});
  const selChar = ()=>Store.get(who.value);
  const whoName = ()=>{ const c=selChar(); return c? c.name : (gm?'GM':(Store.displayName||'ผู้เล่น')); };
  const qroll = (label, kind)=>{ const c=selChar(); Table.guardedRoll(whoName(), ()=>Table.postRoll(doRoll({label, kind, c}), c), label); };
  quick.append(h('button',{class:'small rollbtn',onclick:()=>qroll('2d6','check'),text:'2d6'}), h('button',{class:'small rollbtn',onclick:()=>qroll('Attack Roll','attack'),text:'Attack (CV)'}), h('button',{class:'small rollbtn',onclick:()=>qroll('Luck Saving Throw','luck'),text:'Luck'}),
    ...(gm? [h('button',{class:'small ghost rollbtn',onclick:()=>{ Table.guardedRoll('GM', ()=>{ const e=doRoll({label:'ทอยลับของ GM'}); Table.post({kind:'roll',who:'GM',text:e.label,roll:{dice:e.r.dice,kept:e.r.kept,keptIdx:e.r.keptIdx,sum:e.r.sum,crit:e.r.crit,double:e.r.double,mode:e.mode},mod:0,pm:0,total:e.total,judge:e.judge,gmOnly:true}); }, 'ทอยลับ'); },text:'ทอยลับ (GM)'})] : []));
  chatBox.append(quick);
  chatBox.append(h('div',{id:'roll-lock-banner',class:'lockbanner hidden'}));
  // แผงทอยเต็มของตัวละครที่เลือก (Stat Check, Saving Throw, Knowledge) ทอยผ่านด่านล็อกเดียวกัน
  const panelHost = h('div',{style:'margin-top:8px'});
  const drawPanel = ()=>{ clear(panelHost); const c = selChar(); if (!c) { panelHost.append(h('p',{class:'dim',style:'font-size:12px;margin:0',text:'เลือกตัวละครในช่องด้านบนเพื่อเปิดแผงทอย Stat Check / Saving Throw'})); return; } panelHost.append(dicePanel(c, (e)=>Table.postRoll(e, c), {guard:(run,label)=>Table.guardedRoll(c.name, run, label), noLog:true})); };
  who.addEventListener('change', drawPanel); drawPanel();
  chatBox.append(panelHost);
  right.append(chatBox);
  updateRollLockUI();
  root.append(h('div',{class:'table-wrap'}, left, right));
  renderChatOnly(); renderPeers();
}
/* วางตัวละครของฉันลงบอร์ด: สร้างหมาก + แชร์สำเนาชีทเข้าห้อง (ผู้เล่นคนอื่นและ GM จึงเห็นชีทได้เฉพาะในแคมเปญนี้) */
async function placeCharacter(c, r){
  if (!c) return;
  if (r.tokens.some(t=>t.charId===c.id)){ toast('ตัวละครนี้อยู่บนบอร์ดแล้ว'); return; }
  const d = compute(c); const thumb = await makeThumb(c.portrait);
  const pos = freeCell(r.map, r.tokens, [16,17,18,19]);
  r.tokens.push({id:uid(), name:c.name, kind:'pc', charId:c.id, ownerId:Store.me||'local', ownerName: Store.displayName||'', x:pos.x, y:pos.y, hp:(c.current&&c.current.hp)??d.hp, hpMax:d.hp, san:(c.current&&c.current.sanity)??d.sanity, sanMax:d.sanity, init:d.initiative, hidden:false, note:'', thumb: thumb||null});
  Table.save(); Table.post({kind:'sys', who:'', text:`${c.name} เข้าร่วมฉาก`});
  Store.shareToRoom(c, r.id);
}
function mapPanel(r, gm){
  const wrap = h('div',{class:'mapwrap'});
  const map = r.map;
  // แถบควบคุมแผนที่ (GM)
  if (gm){
    const kindSel = h('select',null, MAP_KINDS.map(([k,l])=>h('option',{value:k,selected:k===map.kind,text:l})));
    const ctl = h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px',text:'สถานที่'}), kindSel,
      h('button',{class:'small primary',onclick:()=>{ r.map = generateMap(kindSel.value, uid()); Table.sel=null; Table.save(); Table.post({kind:'sys',who:'GM',text:`เปลี่ยนฉากต่อสู้เป็น ${MAP_KINDS.find(x=>x[0]===kindSel.value)[1]}`}); for (const t of r.tokens){ const pos = freeCell(r.map, r.tokens.filter(x=>x!==t), t.kind==='npc'?[0,1,2,3]:[16,17,18,19]); t.x=pos.x; t.y=pos.y; } Table.save(); },text:'สุ่มแผนที่ใหม่'}),
      h('button',{class:'small',onclick:()=>{ r.map = generateMap(map.kind, uid()); for (const t of r.tokens){ const pos = freeCell(r.map, r.tokens.filter(x=>x!==t), t.kind==='npc'?[0,1,2,3]:[16,17,18,19]); t.x=pos.x; t.y=pos.y; } Table.save(); },text:'สุ่มใหม่ (สถานที่เดิม)'}));
    const brushSel = h('select',{title:'พู่กัน: เลือกชนิดพื้นแล้วคลิกช่องเพื่อแก้แผนที่'}, h('option',{value:'',text:'พู่กัน: ปิด'}), Object.entries(TILE).map(([k,v])=>h('option',{value:k,selected:Table.brush===k,text:`${v.th}`})));
    brushSel.onchange = ()=>{ Table.brush = brushSel.value||null; Table.sel=null; renderTable(); };
    ctl.append(brushSel, h('button',{class:'small ghost',onclick:()=>{ if(!confirm('เอาหมากทุกตัวออกจากบอร์ด? (สำเนาชีทในห้องจะถูกลบด้วย)')) return; for (const t of r.tokens) dropTokenCopy(r, t); r.tokens=[]; r.enc={active:false,round:0,turnIdx:0,order:[]}; Table.save(); },text:'ล้างหมาก'}));
    wrap.append(ctl);
  } else wrap.append(h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px'}, 'สถานที่: ', h('b',{text:(MAP_KINDS.find(x=>x[0]===map.kind)||['','?'])[1]}))));
  const grid = h('div',{class:'gridmap'+(Table.brush?' painting':'')});
  const selTok = Table.sel ? r.tokens.find(t=>t.id===Table.sel) : null;
  const visible = (t)=> gm || !t.hidden || t.ownerId===Store.me;
  const byPos = {}; for (const t of r.tokens) if (visible(t)) byPos[t.x+','+t.y] = t;
  const cur = r.enc.active ? r.enc.order[r.enc.turnIdx] : null;
  for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){
    const ch = mapCell(map,x,y); const tile = TILE[ch]||TILE['.'];
    const cell = h('div',{class:'cell t-'+(ch.replace(/[^A-Za-z]/g, m=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[m]||'ground'))),title:`(${x},${y}) ${tile.th}`,dataset:{x,y}});
    if (selTok && !(selTok.x===x && selTok.y===y)){ const dist = cellDist(selTok,{x,y}); const band = rangeBand(dist); cell.classList.add('rng-'+band.id); if (tile.pass && !byPos[x+','+y] && (gm || selTok.ownerId===Store.me)) cell.classList.add('canmove'); }
    cell.onclick = ()=>{
      if (Table.brush && gm){ setMapCell(r.map, x, y, Table.brush); Table.save(); return; }
      const t = byPos[x+','+y];
      if (t){ if (Table.sel===t.id) Table.sel=null; else if (selTok && selTok.id!==t.id){ const dist = cellDist(selTok,t); const band = rangeBand(dist); toast(`${selTok.name} → ${t.name}: ${dist} ช่อง (~${band.m} ม.) ${band.label}`); Table.sel = (gm || t.ownerId===Store.me) ? t.id : Table.sel; } else Table.sel = t.id; renderTable(); return; }
      if (selTok && (gm || selTok.ownerId===Store.me)){ if (!tile.pass){ toast('ผ่านช่องนี้ไม่ได้ ('+tile.th+')'); return; } const dist = cellDist(selTok,{x,y}); selTok.x=x; selTok.y=y; Table.save(); if (!selTok.hidden) Table.post({kind:'sys',who:'',text:`${selTok.name} เคลื่อนที่ ${dist} ช่อง ไป (${x},${y})${tile.pass===2?' ('+tile.th+')':''}`}); return; }
      Table.sel = null; renderTable();
    };
    const t = byPos[x+','+y];
    if (t){ const tk = h('div',{class:`gtok ${t.kind}${t.hidden?' hid':''}${cur===t.id?' turn':''}${Table.sel===t.id?' sel':''}${t.hp<=0?' down':''}`,title:`${t.name} HP ${t.hp}/${t.hpMax}`}); if (t.thumb) tk.append(h('img',{src:t.thumb,alt:t.name})); else tk.append(h('span',{class:'ini',text:(t.name||'?').slice(0,2)})); const pct = t.hpMax? Math.max(0,Math.min(100,t.hp/t.hpMax*100)) : 0; tk.append(h('i',{class:'hpbar',style:`--p:${pct}%`})); cell.append(tk); }
    grid.append(cell);
  }
  wrap.append(grid);
  // ตำนานพื้นที่ปรากฏ
  const used = [...new Set(map.cells.split(''))].filter(k=>TILE[k]);
  wrap.append(h('div',{class:'legend'}, used.map(k=>h('span',{class:'lg'}, h('i',{class:'sw t-'+(k.replace(/[^A-Za-z]/g, m=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[m]||'ground')))}), TILE[k].th))));
  // รายชื่อหมาก + แผงหมากที่เลือก
  const list = h('div',{class:'toklist'});
  for (const t of r.tokens.filter(visible)) list.append(tokenRow(t, r, gm, cur===t.id));
  if (!r.tokens.filter(visible).length) list.append(h('div',{class:'dim',style:'font-size:13px',text:'ยังไม่มีหมากบนบอร์ด'}));
  wrap.append(list);
  return wrap;
}
function tokenRow(t, r, gm, isTurn){
  const mine = t.ownerId===Store.me || gm || Table.localMode;
  const el = h('div',{class:`tok ${t.kind}${t.hidden?' hid':''}${isTurn?' turn':''}${Table.sel===t.id?' sel':''}`,onclick:(e)=>{ if (e.target.closest('button,select,input,a')) return; Table.sel = Table.sel===t.id? null : t.id; renderTable(); }},
    t.thumb ? h('img',{class:'av',src:t.thumb,alt:''}) : h('div',{class:'av',text:(t.name||'?').slice(0,2)}),
    h('div',{class:'nm'}, h('div',null, t.name + (t.hidden?' (ซ่อน)':''), t.ownerName? h('span',{class:'dim',style:'font-size:11px',text:' · '+t.ownerName}):null), h('div',{class:'mini'}, h('span',{class:'num',text:`HP ${t.hp}/${t.hpMax}`}), t.sanMax? h('span',{class:'num',text:`SAN ${t.san}/${t.sanMax}`}):null, h('span',{class:'num',text:`Init ${signed(t.init||0)}`}), h('span',{class:'num dim',text:`(${t.x},${t.y})`}))));
  if (mine){
    const ctl = h('div',{class:'ctl'});
    ctl.append(h('button',{class:'small',title:'HP -1',onclick:()=>{t.hp--; Table.save();},text:'−'}), h('button',{class:'small',title:'HP +1',onclick:()=>{t.hp=Math.min(t.hpMax,t.hp+1); Table.save();},text:'+'}));
    if (t.charId && (gm || t.ownerId===Store.me || Store.isDevUid)) ctl.append(h('button',{class:'small ghost',title:'เปิดชีท',onclick:()=>{ location.hash='#sheet-'+t.charId; },text:'ชีท'}));
    if (gm){ ctl.append(h('button',{class:'small ghost',title:t.hidden?'เปิดเผย':'ซ่อน',onclick:()=>{t.hidden=!t.hidden; Table.save(); if(!t.hidden) Table.post({kind:'sys',who:'',text:`${t.name} ปรากฏตัวที่ (${t.x},${t.y})`});},text:t.hidden?'👁':'🙈'}), h('button',{class:'small ghost',title:'เอาออกจากบอร์ด (ลบสำเนาชีทในห้องด้วย)',onclick:()=>{ r.tokens=r.tokens.filter(x=>x!==t); r.enc.order=r.enc.order.filter(x=>x!==t.id); if (Table.sel===t.id) Table.sel=null; dropTokenCopy(r, t); Table.save(); },text:'✕'})); }
    else if (t.ownerId===Store.me) ctl.append(h('button',{class:'small ghost',title:'ถอนตัวละครออกจากบอร์ด (GM จะไม่เห็นชีทอีก)',onclick:()=>{ r.tokens=r.tokens.filter(x=>x!==t); r.enc.order=r.enc.order.filter(x=>x!==t.id); if (Table.sel===t.id) Table.sel=null; dropTokenCopy(r, t); Table.save(); },text:'✕'}));
    el.append(ctl);
  }
  return el;
}
function rollInitiative(r){
  const lines=[];
  for (const t of r.tokens){ const rr = roll2d6(); t.initRoll = rr.sum + (t.init||0); lines.push(`${t.hidden?'(ซ่อน) ':''}${t.name}: ${rr.kept[0]}+${rr.kept[1]} ${signed(t.init||0)} = ${t.initRoll}`); }
  r.enc.order = r.tokens.filter(t=>t.initRoll!=null).sort((a,b)=>b.initRoll-a.initRoll).map(t=>t.id);
  r.enc.active = true; r.enc.round = 1; r.enc.turnIdx = 0;
  Table.save();
  Table.post({kind:'sys',who:'GM',text:'เริ่มการต่อสู้ ทอย Initiative: '+lines.filter(l=>!l.startsWith('(ซ่อน)')).join(' · ')});
  if (lines.some(l=>l.startsWith('(ซ่อน)'))) Table.post({kind:'sys',who:'GM',text:'ฝั่งที่ซ่อน: '+lines.filter(l=>l.startsWith('(ซ่อน)')).join(' · '),gmOnly:true});
}
function clockEl(cl, r, gm){
  const size=72, cx=36, cy=36, R=30;
  const svg = document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('width',size); svg.setAttribute('height',size); svg.setAttribute('viewBox',`0 0 ${size} ${size}`);
  for (let i=0;i<cl.seg;i++){ const a0 = -Math.PI/2 + i*2*Math.PI/cl.seg, a1 = a0 + 2*Math.PI/cl.seg; const p = document.createElementNS('http://www.w3.org/2000/svg','path'); const x0=cx+R*Math.cos(a0), y0=cy+R*Math.sin(a0), x1=cx+R*Math.cos(a1), y1=cy+R*Math.sin(a1); p.setAttribute('d',`M${cx},${cy} L${x0},${y0} A${R},${R} 0 0 1 ${x1},${y1} Z`); p.setAttribute('fill', i<cl.fill? 'var(--blood)':'var(--ink)'); p.setAttribute('stroke','var(--line-2)'); p.setAttribute('stroke-width','1'); if (gm){ p.style.cursor='pointer'; p.addEventListener('click',()=>{ cl.fill = (i<cl.fill)? i : i+1; Table.save(); }); } svg.append(p); }
  return h('div',{class:'clock',style:'text-align:center;font-size:12px'}, svg, h('div',{text:`${cl.name} ${cl.fill}/${cl.seg}`}), gm? h('button',{class:'small ghost',onclick:()=>{ r.clocks=r.clocks.filter(x=>x.id!==cl.id); Table.save(); },text:'ลบ'}):null);
}
function handleChatInput(txt, name, c, gm){
  let gmOnly=false, mode='normal', rest=txt;
  const toks = rest.split(/\s+/);
  while (toks.length && toks[0].startsWith('/')){
    const cmd = toks.shift().toLowerCase();
    if (cmd==='/gm' || cmd==='/gmr') gmOnly=true; else if (cmd==='/adv') mode='adv'; else if (cmd==='/dis') mode='dis'; else if (cmd==='/r' || cmd==='/roll'){ const expr = toks.join(' ') || '2d6'; const m = expr.match(/^(\d*)d6\s*([+-]\s*\d+)?\s*(.*)$/i); let mod = 0, label = expr; if (m){ mod = m[2]? parseInt(m[2].replace(/\s/g,''),10):0; label = (m[3]||'').trim() || expr; if (m[1] && +m[1]===3) mode = mode==='normal'?'adv':mode; } else { const n = parseInt(expr,10); if (!isNaN(n)) mod=n; }
      Table.guardedRoll(name, ()=>{ const e = doRoll({label, mod, c, mode}); e.who = name; Table.post({kind:'roll',who:name,text:e.label,roll:{dice:e.r.dice,kept:e.r.kept,keptIdx:e.r.keptIdx,sum:e.r.sum,crit:e.r.crit,double:e.r.double,mode:e.mode},mod:e.mod,pm:0,total:e.total,judge:e.judge,dc:null,gmOnly}); }, label); return; }
    else { toks.unshift(cmd); break; }
  }
  rest = toks.join(' ');
  if (!rest) return;
  Table.post({kind:'say', who:name, text:rest, gmOnly});
}
function renderChatOnly(){
  const log = document.getElementById('chatlog'); if (!log) return; clear(log);
  const gm = Table.isGM();
  const items = Table.chat.filter(m => !m.gmOnly || gm || m.authorId===Store.me);
  if (!items.length) log.append(h('div',{class:'dim',text:'ยังไม่มีข้อความ'}));
  for (const m of items){
    const time = new Date(m.ts||0).toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'});
    if (m.kind==='roll' && m.roll){
      const r = {dice:m.roll.dice||[], kept:m.roll.kept||[], keptIdx:m.roll.keptIdx||[], sum:m.roll.sum, crit:m.roll.crit, double:m.roll.double, mode:m.roll.mode||'normal'};
      log.append(h('div',{class:'e'}, h('div',{class:'row',style:'gap:6px'}, h('span',{class:'who',text:m.who||''}), h('b',{text:m.text||''}), r.mode!=='normal'? tag(r.mode==='adv'?'Advantage':'Disadvantage', r.mode==='adv'?'ok':'neg'):null, m.roll.chosen? tag('เลือกลูกเอง','prop'):null, m.dc!=null? tag('DC '+m.dc):null, m.gmOnly? h('span',{class:'gm',text:'ลับ'}):null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
        h('div',{class:'row',style:'gap:8px;margin-top:2px'}, renderDice(r), h('span',{class:'dim num',text:`${r.kept[0]}+${r.kept[1]}` + (m.mod? ` ${signed(m.mod)}`:'') + (m.pm? ` ${m.persSide} ${signed(m.pm)}`:'')}), h('b',{class:'num',text:'= '+m.total}), m.judge? h('span',{class:m.judge.cls||'',text:m.judge.text||''}):null)));
    } else if (m.kind==='sys') log.append(h('div',{class:'e dim',style:'font-size:12px'}, m.gmOnly? h('span',{class:'gm',text:'ลับ '}):null, h('span',{text:m.text||''}), h('span',{class:'dim',style:'font-size:11px;float:right',text:time})));
    else log.append(h('div',{class:'e'}, h('span',{class:'who',text:(m.who||'')+': '}), h('span',{text:m.text||''}), m.gmOnly? h('span',{class:'gm',text:' (ลับ)'}):null, h('span',{class:'dim',style:'font-size:11px;float:right',text:time})));
  }
}
function renderPeers(){ const p = document.getElementById('peers'); if (!p) return; const n = Table.peers.length; const names = Table.peers.map(x=>x.name||'').filter(Boolean); p.textContent = n ? `ออนไลน์ในห้อง ${n} คน${names.length? ': '+names.join(', ') : ''}` : ''; }
