/* ===== Online table: rooms, 20×20 grid combat map, encounter order, shared chat & dice, fate clocks ===== */
function newRoom(name){ const id = uid(); return {id, name, gmId: Store.me||'local', gmName: Store.displayName||'', gmKey: uid().slice(0,6).toUpperCase(), hasKey:false, createdAt:Date.now(), updatedAt:Date.now(), map: generateMap('field', id), tokens:[], enc:{active:false, round:0, turnIdx:0, order:[]}, clocks:[], scene:''}; }
/* ห้องรุ่นเก่าที่ใช้โซน: สร้างแผนที่ให้ และวางหมากเดิมลงกริด (GM บันทึกครั้งถัดไปจึงติดถาวร) */
function migrateRoom(r){ if (!r) return r; if (!r.map){ r.map = generateMap('field', r.id); } if (!r.tokens) r.tokens = []; for (const t of r.tokens){ if (t.x==null || t.y==null){ const pos = freeCell(r.map, r.tokens, t.kind==='npc' ? [0,1,2,3] : [16,17,18,19]); t.x = pos.x; t.y = pos.y; } } delete r.zones; return r; }
function gmKeys(){ try { return JSON.parse(localStorage.getItem('kirana.gmkeys')||'{}'); } catch(e){ return {}; } }
function rememberGmKey(roomId, key){ const k = gmKeys(); k[roomId] = key; try { localStorage.setItem('kirana.gmkeys', JSON.stringify(k)); } catch(e){} }

const Table = {
  roomId:null, room:null, chat:[], unsub:[], peers:[], localMode:false, writing:false, pending:null, presence:null,
  rollLock:null, rolling:false, seenRolls:new Set(), chatReady:false,
  roomChars:[], sel:null, brush:null, hover:null, chatWho:null, diceWho:null,
  isGM(){ if (!this.room) return false; if (this.localMode || this.room.gmId===Store.me || Store.isOwner) return true; const k = gmKeys()[this.room.id]; return !!(k && this.room.gmKey && k===this.room.gmKey); },
  async open(id){
    this.close(); this.roomId = id; this.localMode = !Store.db;
    if (this.localMode){ const rooms = loadLocalRooms(); const lr = rooms.find(r=>r.id===id)||null; if (lr && lr.joinKey && !gmKeys()[id] && localStorage.getItem('kirana.joined.'+id)!==lr.joinKey){ const k = prompt('ห้องนี้ล็อกด้วยรหัส กรอกรหัสเข้าห้อง'); if (k!==lr.joinKey){ toast('รหัสไม่ถูกต้อง'); location.hash='#table'; return; } localStorage.setItem('kirana.joined.'+id, k); } this.room = migrateRoom(lr); this.chat = loadLocalChat(id); renderTable(); return; }
    // ห้องที่ล็อกด้วยรหัส: ดูล็อบบี้ก่อน ถ้ายังไม่เป็นสมาชิกให้กรอกรหัส
    try {
      const lb = docData(await Store.db.doc('lobby/'+id).get());
      if (lb && lb.hasKey && lb.gmId !== Store.me && !Store.isDevUid){
        const mem = await Store.db.doc(`rooms/${id}/members/${Store.me}`).get().catch(()=>null);
        if (!mem || !mem.exists){ this.room = null; renderTable(); const ok = await askRoomKey(id, lb); if (!ok){ location.hash = '#table'; return; } }
      }
    } catch(e){ console.warn('lobby', e); }
    if (this.roomId !== id) return;
    try {
      const u1 = Store.db.doc('rooms/'+id).onSnapshot(snap => { const d = docData(snap); if (d){ this.room = migrateRoom(d); renderTable(); } }, err=>{ console.warn(err); toast('อ่านห้องไม่ได้'); });
      const u4 = Store.db.collection('rooms/'+id+'/chars').onSnapshot(snap => { this.roomChars = snapDocs(snap).filter(Boolean); if (location.hash.startsWith('#sheet-')) { const sid = location.hash.slice(7); if (!Store.chars.some(c=>c.id===sid) && this.roomChars.some(c=>c.id===sid)) renderSheet(sid); } }, err=>console.warn('roomchars', err));
      this.unsub.push(u4);
      const u5 = Store.db.collection('rooms/'+id+'/gifts').onSnapshot(snap => { for (const g of snapDocs(snap).filter(Boolean)) applyGift(id, g); }, err=>console.warn('gifts', err));
      this.unsub.push(u5);
      let q = Store.db.collection('rooms/'+id+'/chat');
      try { q = q.orderBy('ts','desc').limit(120); } catch(e){}
      const u2 = q.onSnapshot(snap => { const docs = snapDocs(snap).filter(Boolean); docs.sort((a,b)=>(b.ts||0)-(a.ts||0)); this.chat = docs.slice(0,120); renderChatOnly(); this.detectNewRolls(); }, err=>console.warn('chat', err));
      const u3 = Store.db.doc('rooms/'+id+'/meta/roll').onSnapshot(snap => { this.rollLock = docData(snap); updateRollLockUI(); }, err=>console.warn('rolllock', err));
      this.unsub.push(u1,u2,u3);
    } catch(e){ console.warn(e); toast('เชื่อมต่อห้องไม่ได้'); }
    if (Store.room){ try { const r = await Store.room.join('kirana-'+id); this.presence = r; const me = Store.me||'guest'; r.presence({who: me, name: Store.displayName||'', at: Date.now()}); r.onPeers(p=>{ this.peers = Array.isArray(p)? p : Object.values(p||{}); renderPeers(); }); } catch(e){ console.warn('room', e); } }
    renderTable();
  },
  close(){ for (const u of this.unsub) try{ typeof u==='function' && u(); }catch(e){} this.unsub=[]; if (this.presence){ try{ this.presence.leave(); }catch(e){} this.presence=null; } this.roomId=null; this.room=null; this.chat=[]; this.peers=[]; this.roomChars=[]; this.sel=null; this.brush=null; this.chatWho=null; this.diceWho=null; this.rollLock=null; this.rolling=false; this.seenRolls=new Set(); this.chatReady=false; DiceShow.clear(); updateRollLockUI(); clearTwins(); },
  /* ---- ด่านล็อกการทอย: ทอยได้ทีละคน ระหว่างเต๋าเด้งอยู่บนจอทุกคน คนอื่นกดทอยไม่ได้ ---- */
  lockActive(lk){ lk = lk===undefined ? this.rollLock : lk; return !!(lk && lk.at && (Date.now() - lk.at) < ROLL_LOCK_TTL); },
  lockedByOther(){ return this.lockActive() && this.rollLock.by !== (Store.me||'local'); },
  async claimRollLock(who, label){
    const me = Store.me||'local'; const lock = {by: me, who, label: label||'', at: Date.now()};
    if (this.localMode) { this.rollLock = lock; return true; }
    try {
      if (FB){ // Firestore transaction: อ่าน-เช็ก-เขียนในรอบเดียว กันสองคนกดพร้อมกัน
        const ref = FB.F.doc(FB.fdb, `rooms/${this.roomId}/meta/roll`);
        return await FB.F.runTransaction(FB.fdb, async tx => { const sn = await tx.get(ref); const cur = sn.exists() ? sn.data() : null; if (this.lockActive(cur) && cur.by !== me) return false; tx.set(ref, lock); return true; });
      }
      const ref = Store.db.doc(`rooms/${this.roomId}/meta/roll`); const sn = await ref.get(); const cur = docData(sn); if (this.lockActive(cur) && cur.by !== me) return false; await ref.set(lock); return true;
    } catch(e){ console.warn('claim lock', e); return true; } // ล็อกล้มเหลว (สิทธิ์/เน็ต) ไม่ควรขวางการเล่น
  },
  async releaseRollLock(){
    const me = Store.me||'local'; if (!this.rollLock || this.rollLock.by !== me) return;
    if (this.localMode){ this.rollLock = null; updateRollLockUI(); return; }
    try { await Store.db.doc(`rooms/${this.roomId}/meta/roll`).set({by:null, who:null, label:'', at:0}); } catch(e){ console.warn('release lock', e); }
  },
  /* guardedRoll(who, run): run() ทอยจริงและโพสต์ เรียกเมื่อได้ล็อกแล้วเท่านั้น */
  async guardedRoll(who, run, label){
    if (!this.roomId){ run(); return; }
    if (this.rolling){ toast('รอเต๋าหยุดก่อน'); return; }
    if (this.lockedByOther()){ toast(`${this.rollLock.who||'ผู้เล่นอีกคน'} กำลังทอยอยู่ รอให้เต๋าหยุดก่อน`); return; }
    this.rolling = true; updateRollLockUI();
    const ok = await this.claimRollLock(who, label);
    if (!ok){ this.rolling = false; updateRollLockUI(); toast(`${(this.rollLock&&this.rollLock.who)||'ผู้เล่นอีกคน'} กดทอยก่อนคุณเสี้ยววินาที รอให้เต๋าหยุดก่อน`); return; }
    // run() อาจเป็น async (ทอยแล้วให้เลือกลูก) ระหว่างรอ ต่ออายุล็อกทุก 3 วิ ไม่ให้หมดอายุก่อนเลือกเสร็จ
    const me = Store.me||'local'; const touch = setInterval(()=>{ if (!this.localMode && this.roomId) Store.db.doc(`rooms/${this.roomId}/meta/roll`).set({by:me, who, label:label||'', at:Date.now()}).catch(()=>{}); }, 3000);
    try { const res = run(); if (res && typeof res.then === 'function') await res; } catch(e){ console.warn(e); }
    clearInterval(touch);
    setTimeout(()=>{ this.rolling = false; this.releaseRollLock(); updateRollLockUI(); }, ROLL_SHOW_MS);
  },
  detectNewRolls(){
    if (!this.chatReady){ this.chatReady = true; for (const m of this.chat) this.seenRolls.add(m.id); return; }
    const gm = this.isGM(); const now = Date.now();
    const fresh = this.chat.filter(m => m.kind==='roll' && m.roll && !this.seenRolls.has(m.id)).sort((a,b)=>(a.ts||0)-(b.ts||0));
    for (const m of fresh){ this.seenRolls.add(m.id); if (m.gmOnly && !gm && m.authorId!==Store.me) continue; if (now - (m.ts||0) > 20000) continue; DiceShow.enqueue(m); }
  },
  async save(){ // one write at a time; latest state wins
    const r = this.room; if (!r) return; r.updatedAt = Date.now();
    if (this.localMode){ const rooms = loadLocalRooms(); const i=rooms.findIndex(x=>x.id===r.id); if(i>=0) rooms[i]=r; else rooms.push(r); saveLocalRooms(rooms); renderTable(); return; }
    renderTable();
    if (this.writing){ this.pending = true; return; }
    this.writing = true;
    try { await Store.db.doc('rooms/'+r.id).set(JSON.parse(JSON.stringify(r))); Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)).catch(()=>{}); } catch(e){ console.warn('save room', e); toast('บันทึกห้องไม่ได้ (สิทธิ์ไม่พอ?)'); }
    this.writing = false; if (this.pending){ this.pending=false; this.save(); }
  },
  async post(msg){
    msg.id = uid(); msg.ts = Date.now(); msg.authorId = Store.me||'local';
    if (this.localMode){ this.chat.unshift(msg); this.chat = this.chat.slice(0,200); saveLocalChat(this.roomId, this.chat); renderChatOnly(); if (msg.kind==='roll') DiceShow.enqueue(msg); return; }
    try { await Store.db.doc(`rooms/${this.roomId}/chat/${msg.id}`).set(msg); } catch(e){ console.warn(e); toast('ส่งข้อความไม่ได้ (สิทธิ์ไม่พอ?)'); }
  },
  postRoll(e, c){ if (!this.roomId) return; this.post({kind:'roll', who: c? c.name : (this.isGM()?'GM':'ผู้เล่น'), text:e.label, roll:{dice:e.r.dice, kept:e.r.kept, keptIdx:e.r.keptIdx, sum:e.r.sum, crit:e.r.crit, double:e.r.double, mode:e.mode, chosen:!!e.r.chosen}, mod:e.mod, pm:e.pm, persSide:e.persSide, total:e.total, judge:e.judge, dc:e.dc, gmOnly:false}); },
};
const ROLL_SHOW_MS = 4200;      // เต๋าค้างบนจอ
const ROLL_LOCK_TTL = 8000;     // ล็อกหมดอายุเองถ้าคนทอยหลุดก่อนปล่อย
/* ---- ป๊อปอัปเต๋าเด้งหน้าทุกคนในห้อง (ต่อคิวถ้ามาหลายอัน) ---- */
const DiceShow = {
  q:[], cur:null, timer:null,
  enqueue(m){ this.q.push(m); if (!this.cur) this.next(); },
  clear(){ this.q=[]; if (this.timer) clearTimeout(this.timer); this.timer=null; this.cur=null; const o=$('#dice-overlay'); if (o){ clear(o); o.classList.add('hidden'); } },
  next(){
    const m = this.q.shift(); if (!m){ this.cur=null; return; }
    this.cur = m; const o = $('#dice-overlay'); if (!o) return;
    clear(o); o.classList.remove('hidden');
    const r = m.roll; const dice = r.dice||[]; const keptIdx = r.keptIdx||[];
    const dieEls = dice.map((v,i)=>h('div',{class:'bigdie tumble'+(keptIdx.includes(i)?'':' drop')}, h('span',{text:'?'})));
    const box = h('div',{class:'dicebox'}, h('div',{class:'dice-who'}, h('span',{class:'who',text:m.who||''}), ' ', h('b',{text:m.text||'ทอยเต๋า'}), r.mode&&r.mode!=='normal'? [' ', tag(r.mode==='adv'?'Advantage':'Disadvantage', r.mode==='adv'?'ok':'neg')]:null, r.chosen? [' ', tag('เลือกลูกเอง','prop')]:null, m.gmOnly? [' ', h('span',{class:'gm',text:'ลับ'})]:null),
      h('div',{class:'dice-row'}, dieEls), h('div',{class:'dice-total',text:''}), h('div',{class:'dice-judge',text:''}));
    o.append(box);
    // หมุนหน้าเต๋าสุ่มสักพักแล้วหยุดทีละลูก
    let tick = 0; const spin = setInterval(()=>{ tick++; dieEls.forEach((el,i)=>{ if (tick < 10 + i*4) el.firstChild.textContent = 1 + Math.floor(Math.random()*6); else { el.firstChild.textContent = dice[i]; el.classList.remove('tumble'); } }); if (tick >= 10 + dice.length*4){ clearInterval(spin); settle(); } }, 70);
    const settle = ()=>{ const tot = box.querySelector('.dice-total'); const parts = [`${(r.kept||[]).join('+')}`]; if (m.mod) parts.push(signed(m.mod)); if (m.pm) parts.push(`${m.persSide||''} ${signed(m.pm)}`); tot.textContent = parts.join(' ') + ' = ' + m.total; tot.classList.add('show'); const j = box.querySelector('.dice-judge'); if (m.judge){ j.textContent = m.judge.text||''; j.className = 'dice-judge show ' + (m.judge.cls||''); } if (m.dc!=null) j.textContent += ` (DC ${m.dc})`; if (r.crit==='success' || r.double) box.classList.add('crit'); };
    this.timer = setTimeout(()=>{ o.classList.add('hidden'); clear(o); this.cur=null; this.next(); }, ROLL_SHOW_MS);
  }
};
function updateRollLockUI(){
  const other = Table.roomId && Table.lockedByOther();
  const busy = !!(Table.roomId && (Table.rolling || other));
  document.body.classList.toggle('roll-locked', busy);
  for (const b of document.querySelectorAll('#roll-lock-banner, .lockbanner[data-lock]')){ // ป้ายในแชตและในหน้าต่างทอยเต๋า
    if (other){ b.textContent = `${Table.rollLock.who||'ผู้เล่นอีกคน'} กำลังทอยเต๋า… รอให้เต๋าหยุดก่อน`; b.classList.remove('hidden'); }
    else if (Table.rolling){ b.textContent = 'เต๋าของคุณกำลังทอย…'; b.classList.remove('hidden'); }
    else b.classList.add('hidden');
  }
}
setInterval(()=>{ if (Table.roomId && Table.rollLock && !Table.lockActive() && document.body.classList.contains('roll-locked') && !Table.rolling) updateRollLockUI(); }, 1000);
function loadLocalRooms(){ try{ return JSON.parse(localStorage.getItem('kirana.rooms.v1')||'[]'); }catch(e){ return []; } }
function saveLocalRooms(r){ try{ localStorage.setItem('kirana.rooms.v1', JSON.stringify(r)); }catch(e){} }
function loadLocalChat(id){ try{ return JSON.parse(localStorage.getItem('kirana.chat.'+id)||'[]'); }catch(e){ return []; } }
function saveLocalChat(id, c){ try{ localStorage.setItem('kirana.chat.'+id, JSON.stringify(c)); }catch(e){} }

let roomsCache = []; let roomsUnsub = null;
/* ---- ล็อบบี้: ข้อมูลห้องที่ทุกคนเห็นได้ (ชื่อ GM มีรหัสไหม) แยกจากตัวห้องซึ่งอาจล็อกด้วยรหัส ---- */
function lobbyDoc(r){ return { id:r.id, name:r.name||'', gmId:r.gmId||'', gmName:r.gmName||'', hasKey:!!r.hasKey, tokens:(r.tokens||[]).length, encActive:!!(r.enc&&r.enc.active), round:(r.enc&&r.enc.round)||0, light:r.light||'low', scene:(r.scene||'').slice(0,100), updatedAt:r.updatedAt||Date.now() }; }
async function joinRoomWithKey(id, key){ const me = Store.me; await Store.db.doc(`rooms/${id}/members/${me}`).set({ uid: me, name: Store.displayName||'', key: String(key), at: Date.now() }); try { await Store.db.doc(`rooms/${id}/members/${me}`).set({ uid: me, name: Store.displayName||'', at: Date.now() }); } catch(e){} }
async function setRoomKey(r, key){ // GM เท่านั้น: key ว่าง = ปลดล็อก
  if (!Store.db){ r.joinKey = key || null; r.hasKey = !!key; Table.save(); return; }
  if (key){ await Store.db.doc('roomsecrets/'+r.id).set({ value: String(key), roomId: r.id, at: Date.now() }); r.hasKey = true; await Table.save(); try { await joinRoomWithKey(r.id, key); } catch(e){} }
  else { r.hasKey = false; await Table.save(); try { await Store.db.doc('roomsecrets/'+r.id).delete(); } catch(e){} }
}
/* ลบสำเนาชีทของหมากที่ถูกเอาออกจากบอร์ด (เจ้าของ: เลิกซิงก์ด้วย) */
function dropTokenCopy(r, t){ if (!t || !t.charId) return; const mine = Store.chars.find(c=>c.id===t.charId && Store.isMine(c)); if (mine) Store.unshareFromRoom(mine, r.id); else if (Store.db) Store.db.doc(`rooms/${r.id}/chars/${t.charId}`).delete().catch(()=>{}); }
async function deleteCollection(path){ if (!Store.db) return; try { const snap = await Store.db.collection(path).get(); await Promise.all(snap.docs.map(d => Store.db.doc(path+'/'+d.id).delete().catch(()=>{}))); } catch(e){ console.warn('delete', path, e); } }
async function deleteRoomDeep(r){
  for (const t of r.tokens||[]) { const mine = Store.chars.find(c=>c.id===t.charId && Store.isMine(c)); if (mine) Store.unshareFromRoom(mine, r.id); }
  if (!Store.db) return;
  for (const sub of ['chars','chat','members','meta','presence']) await deleteCollection(`rooms/${r.id}/${sub}`);
  try { await Store.db.doc('lobby/'+r.id).delete(); } catch(e){}
  try { await Store.db.doc('roomsecrets/'+r.id).delete(); } catch(e){}
  try { await Store.db.doc('rooms/'+r.id).delete(); } catch(e){ toast('ลบห้องไม่ได้'); }
}
function roomKeyModal(r){
  const inp = h('input',{placeholder:'รหัสเข้าห้อง (4 ตัวขึ้นไป)',style:'min-width:220px',value:''});
  modal(h('div',null, h('h3',{text:'รหัสเข้าห้อง'}), h('p',{class:'desc'}, r.hasKey ? 'ห้องนี้มีรหัสอยู่แล้ว ผู้เล่นต้องกรอกรหัสก่อนเข้าครั้งแรก (บัญชีที่เข้าแล้วไม่ต้องกรอกซ้ำ) รหัสใหม่ใช้กับคนที่ยังไม่เคยเข้า' : 'ตั้งรหัสแล้ว คนที่มีแค่ลิงก์จะเข้าห้องไม่ได้จนกว่าจะกรอกรหัสถูก แชต หมาก และสำเนาชีทในห้องอ่านได้เฉพาะคนในห้อง'),
    h('div',{class:'row',style:'margin-top:8px'}, inp, h('button',{class:'primary small',onclick:async()=>{ const k = inp.value.trim(); if (k.length < 4){ toast('รหัสสั้นเกินไป'); return; } try { await setRoomKey(r, k); toast('ตั้งรหัสเข้าห้องแล้ว'); modal(null); renderTable(); } catch(e){ console.warn(e); toast('ตั้งรหัสไม่ได้ (ต้องเป็น GM ที่สร้างห้อง และ Rules ต้องเป็นรุ่น v1.2)'); } },text: r.hasKey ? 'เปลี่ยนรหัส' : 'ตั้งรหัส'}),
      r.hasKey ? h('button',{class:'small ghost',onclick:async()=>{ try { await setRoomKey(r, ''); toast('ปลดรหัสแล้ว ห้องเปิดให้ทุกคนที่มีลิงก์'); modal(null); renderTable(); } catch(e){ toast('ปลดรหัสไม่ได้'); } },text:'ปลดรหัส'}) : null)));
}
function askRoomKey(id, lobby){
  return new Promise(resolve => {
    const inp = h('input',{placeholder:'รหัสเข้าห้อง',style:'min-width:220px'});
    const go = async ()=>{ const k = inp.value.trim(); if (!k) return; try { await joinRoomWithKey(id, k); modal(null); resolve(true); } catch(e){ console.warn(e); toast('รหัสไม่ถูกต้อง'); } };
    inp.onkeydown = (e)=>{ if (e.key==='Enter') go(); };
    modal(h('div',null, h('h3',{text:`ห้อง "${lobby.name||''}" ล็อกด้วยรหัส`}), h('p',{class:'desc',text:`GM: ${lobby.gmName||'-'} · ขอรหัสเข้าห้องจาก GM แล้วกรอกครั้งเดียว บัญชีนี้จะเข้าได้ตลอด`}), h('div',{class:'row',style:'margin-top:8px'}, inp, h('button',{class:'primary small',onclick:go,text:'เข้าห้อง'}), h('button',{class:'small ghost',onclick:()=>{ modal(null); resolve(false); },text:'ยกเลิก'}))));
    setTimeout(()=>inp.focus(), 50);
  });
}

/* ===== สถานะ (Condition) บนหมาก: GM แปะ มีไอคอน เอฟเฟกต์ นับเทิร์น ซ้อนระดับได้ และผูกกับหมากต้นเหตุได้ ===== */
const COND_ICON = { 'Stunned':'💫','Unbalanced':'🌀','Prone':'🛌','Bleeding':'🩸','Deepwound':'🩹','Burning':'🔥','Poisoned':'☠️','Rooted':'🌿','Grappled':'🤝','Incapacitated':'💤','Exhaustion':'😮‍💨','Deafened':'🔇','Blinded':'🕶️','Frightened':'😨','Fight or Flight':'⚡','Charmed':'💗','Confused':'❓','Silenced':'🤐','Cover':'🛡️','Hidden':'👁️‍🗨️','Invisible':'👻','Devoured':'🦷','Marked':'🎯','Starving':'🍽️','Suffocating':'😵','Intoxicated':'🍺','Haunted':'🕯️','Sundered':'💔' };
/* สถานะที่มีระดับและซ้อนทับได้ (ไฟล์แกน: Bleeding 1,2,3 · Burning ตามระดับ · Poisoned ตามระดับพิษ · Exhaustion 1-6 · Starving 1-3) */
const COND_STACK = new Set(['Bleeding','Burning','Poisoned','Exhaustion','Starving']);
/* สถานะที่ต้องมีหมากอีกตัวเป็นต้นเหตุ: หวาดกลัว ต้องมนตร์ ถูกจับ ถูกกลืนกิน (ตีตรา ระบุได้แต่ไม่บังคับ) */
const COND_BOUND = { 'Frightened':'ต้นตอของความกลัว', 'Charmed':'ผู้ร่ายมนตร์', 'Grappled':'ผู้ที่จับ', 'Devoured':'ผู้กลืนกิน', 'Marked':'ผู้ตีตรา' };
const COND_BOUND_OPTIONAL = new Set(['Marked']);
function condList(){ return Object.entries(GLOSSARY).filter(([k,v])=>/Condition/.test(v.cat||'')).map(([k,v])=>({id:k, th:v.th||'', text:v.text||''})); }
function condIcon(id){ return COND_ICON[id] || '✦'; }
function condClass(id){ return String(id).toLowerCase().replace(/[^a-z]+/g,'-'); }
function condSource(r, c){ return c && c.by ? (r.tokens||[]).find(t=>t.id===c.by) || null : null; }
function condLabel(c, r){ let s = condIcon(c.id)+' '+c.id; if (COND_STACK.has(c.id)) s += ' '+(c.lv||1); if (c.by){ const src = condSource(r, c); s += ' ← '+(src ? src.name : (c.byName||'?')); } if (c.turns) s += ' ⏱'+c.turns; return s; }
function condChips(t, r, gm){
  const cs = t.conds||[]; if (!cs.length) return null;
  return h('div',{class:'conds'}, cs.map(c=>{ const g = GLOSSARY[c.id]||{};
    const chip = h('span',{class:'cond c-'+condClass(c.id), title:(g.th? g.th+': ' : '')+(g.text||'') + (gm? ' (คลิกชื่อเพื่อเอาออก)':'')});
    chip.append(h('span',{class:'cl', onclick: gm ? (e)=>{ e.stopPropagation(); removeCond(t, r, c); } : null, text: condLabel(c, r)}));
    if (gm && COND_STACK.has(c.id)) chip.append(h('button',{class:'cadj',title:'ลดระดับ 1',onclick:(e)=>{ e.stopPropagation(); adjustCond(t, r, c, -1); },text:'−'}), h('button',{class:'cadj',title:'เพิ่มระดับ 1',onclick:(e)=>{ e.stopPropagation(); adjustCond(t, r, c, +1); },text:'+'}));
    return chip; }));
}
function adjustCond(t, r, c, d){ c.lv = (c.lv||1) + d; if (c.lv <= 0){ removeCond(t, r, c); return; } Table.save(); Table.post({kind:'sys',who:'',text:`${t.name}: ${condIcon(c.id)} ${c.id} ${d>0?'เพิ่มเป็น':'ลดเหลือ'}ระดับ ${c.lv}`}); }
function removeCond(t, r, c, why){ t.conds = (t.conds||[]).filter(x=>x!==c); if (c.id==='Devoured') releaseDevoured(r, t); Table.save(); Table.post({kind:'sys',who:'',text:`${t.name} พ้นจากสภาวะ ${c.id}${why? ' ('+why+')':''}${c.id==='Devoured'? ' และโผล่ออกมาที่ ('+t.x+','+t.y+')':''}`}); }
function applyCond(t, r, id, o){
  t.conds = t.conds||[]; const ex = t.conds.find(c=>c.id===id);
  if (ex){ if (!COND_STACK.has(id)){ toast('ติดสถานะนี้อยู่แล้ว'); return false; } ex.lv = (ex.lv||1) + (o.lv||1); if (o.turns) ex.turns = o.turns; Table.save(); Table.post({kind:'sys',who:'',text:`${t.name}: ${condIcon(id)} ${id} ซ้อนเป็นระดับ ${ex.lv}`}); return true; }
  const c = {id, turns: o.turns||null, at: Date.now()}; if (COND_STACK.has(id)) c.lv = o.lv||1; if (o.by){ c.by = o.by.id; c.byName = o.by.name; }
  t.conds.push(c); if (id==='Devoured' && o.by) devourToken(r, t, o.by);
  Table.save(); Table.post({kind:'sys',who:'',text:`${t.name} ติดสภาวะ ${condIcon(id)} ${id}${c.lv? ' ระดับ '+c.lv:''}${o.by? ' โดย '+o.by.name:''}${c.turns? ' '+c.turns+' เทิร์น':''}${id==='Devoured'? ' หมากถูกดูดเข้าไปในตัว '+(o.by? o.by.name:'ผู้กลืน'):''}`}); return true;
}
/* ถูกกลืนกิน: หมากหายเข้าไปอยู่ในตัวผู้กลืน (ตำแหน่งตามผู้กลืนเสมอ) และโผล่ออกมาข้าง ๆ เมื่อสถานะหลุด */
function devourToken(r, t, eater){ t.inside = eater.id; t.x = eater.x; t.y = eater.y; }
function adjacentFree(r, around, self){ for (let d=1; d<=4; d++) for (let dy=-d; dy<=d; dy++) for (let dx=-d; dx<=d; dx++){ if (Math.max(Math.abs(dx),Math.abs(dy))!==d) continue; const x=around.x+dx, y=around.y+dy; if (!inb(x,y) || !cellStandable(r.map,x,y)) continue; if ((r.tokens||[]).some(o=>o!==self && !o.inside && o.x===x && o.y===y)) continue; return {x,y}; } return {x:around.x, y:around.y}; }
function releaseDevoured(r, t){ const eater = (r.tokens||[]).find(x=>x.id===t.inside); t.inside = null; if (!eater) return; const spot = adjacentFree(r, eater, t); t.x = spot.x; t.y = spot.y; }
function syncDevoured(r, eater){ for (const t of r.tokens||[]) if (t.inside===eater.id){ t.x = eater.x; t.y = eater.y; } }
/* หมากออกจากบอร์ด: ของที่อยู่ในท้องถูกคายออก และสถานะที่มันเป็นต้นเหตุจบลง (ผู้จับปล่อย ต้นตอความกลัวหายไป ผู้ร่ายจากไป) */
function detachToken(r, gone){ for (const t of r.tokens||[]){ if (t===gone) continue; if (t.inside===gone.id){ t.inside = null; const spot = adjacentFree(r, gone, t); t.x = spot.x; t.y = spot.y; Table.post({kind:'sys',who:'',text:`${t.name} หลุดออกจากตัว ${gone.name}`}); t.conds = (t.conds||[]).filter(c=>c.id!=='Devoured'); } const before = (t.conds||[]).length; t.conds = (t.conds||[]).filter(c=>c.by!==gone.id); if ((t.conds||[]).length !== before) Table.post({kind:'sys',who:'',text:`${t.name} พ้นจากสภาวะที่ ${gone.name} เป็นต้นเหตุ`}); } }
/* ข้อห้ามเคลื่อนที่จากสถานะที่ผูกกับหมากอื่น (ผู้เล่น) · GM เดินได้เสมอแต่จะได้ข้อความเตือน */
function moveBlocked(r, t, to){ if (t.inside) return 'ถูกกลืนอยู่ ออกมาไม่ได้จนกว่าจะหลุดจากสภาวะ Devoured'; for (const c of t.conds||[]){ const src = condSource(r, c); if (!src) continue; if (c.id==='Grappled' && cellDist(src, to) > 1) return `ถูก ${src.name} จับอยู่ ออกจากเขตปะทะไม่ได้ (ต้องชนะ STR Challenge ก่อน)`; if (c.id==='Rooted' && cellDist(src, to) > 1) return `ถูกยึดติดกับ ${src.name} ออกจากเขตปะทะไม่ได้`; if (c.id==='Frightened' && cellDist(src, to) < cellDist(src, t)) return `หวาดกลัว ${src.name} อยู่ ขยับเข้าใกล้กว่านี้ไม่ได้`; } return null; }
function tickConditions(r){ for (const t of r.tokens||[]){ if (!t.conds) continue; const gone=[]; t.conds = t.conds.filter(c=>{ if (c.turns==null) return true; c.turns--; if (c.turns<=0){ gone.push(c); return false; } return true; }); for (const g of gone){ if (g.id==='Devoured') releaseDevoured(r, t); Table.post({kind:'sys',who:'',text:`${t.name} พ้นจากสภาวะ ${g.id} (ครบเวลา)`}); } } }
function condModal(t, r){
  const list = condList(); const sel = h('select',null, list.map(c=>h('option',{value:c.id,text:`${condIcon(c.id)} ${c.id} ${c.th? '· '+c.th:''}`})));
  const turns = h('input',{type:'number',min:1,max:20,placeholder:'เทิร์น (ว่าง = จนกว่าจะเอาออก)',style:'width:200px'});
  const lv = h('input',{type:'number',min:1,max:9,value:1,style:'width:70px',title:'ระดับ'});
  const lvWrap = h('label',{class:'row',style:'gap:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'ระดับ'}), lv);
  const others = (r.tokens||[]).filter(x=>x!==t);
  const by = h('select',null, h('option',{value:'',text:'— เลือกหมากต้นเหตุ —'}), others.map(x=>h('option',{value:x.id,text:`${x.name}${x.hidden?' (ซ่อน)':''}`})));
  const byWrap = h('label',{class:'row',style:'gap:4px;align-items:center'}, h('span',{class:'dim by-l',style:'font-size:12px'}), by);
  const desc = h('div',{class:'desc',style:'margin-top:6px;font-size:12.5px'});
  const upd = ()=>{ const id = sel.value; const c = list.find(x=>x.id===id); clear(desc); desc.append(T(c? c.text : '')); lvWrap.classList.toggle('hidden', !COND_STACK.has(id)); const bound = !!COND_BOUND[id]; byWrap.classList.toggle('hidden', !bound); byWrap.querySelector('.by-l').textContent = bound ? COND_BOUND[id] + (COND_BOUND_OPTIONAL.has(id) ? ' (ถ้ามี)' : '') : ''; };
  sel.onchange = upd; upd();
  const apply = ()=>{ const id = sel.value; const src = others.find(x=>x.id===by.value) || null; if (COND_BOUND[id] && !COND_BOUND_OPTIONAL.has(id) && !src){ toast(`สถานะ ${id} ต้องระบุว่าใครเป็น${COND_BOUND[id]}`); return; } if (id==='Devoured' && src && src.inside){ toast('ผู้กลืนเองก็ถูกกลืนอยู่'); return; } if (applyCond(t, r, id, {turns: turns.value? +turns.value : null, lv: +lv.value||1, by: src})) modal(null); };
  modal(h('div',null, h('h3',{text:`แปะสถานะให้ ${t.name}`}), h('div',{class:'row',style:'margin-top:8px'}, sel, turns, lvWrap, byWrap, h('button',{class:'primary small',onclick:apply,text:'แปะ'})), desc,
    h('p',{class:'dim',style:'font-size:12px;margin-top:6px',text:'สถานะที่มีระดับ (Bleeding Burning Poisoned Exhaustion Starving) ซ้อนกันได้ กดปุ่ม + − ที่ชิปในฉากเพื่อปรับระดับ · ถูกกลืนกิน: หมากจะถูกดูดเข้าไปในตัวผู้กลืนและเดินตามไปจนกว่าจะหลุด'}),
    (t.conds||[]).length ? h('div',{style:'margin-top:10px'}, h('b',{text:'สถานะที่ติดอยู่ (คลิกชื่อเพื่อเอาออก)'}), condChips(t, r, true)) : null));
}
/* ===== GM ใส่ไอเทมให้ผู้เล่น: เขียนไว้ที่ rooms/<rid>/gifts แล้วเครื่องของเจ้าของรับเข้ากระเป๋าเอง ===== */
let itemCatalogCache = null;
function itemCatalog(){ if (itemCatalogCache) return itemCatalogCache; const out = []; const seen = new Set(); const add = (it, src, cat, sub)=>{ const name = cleanAltName(it.name).replace(/\(เสนอ\)\s*/,'').replace(/\s*×\s*\d+/,'').trim(); const key = name.toLowerCase(); if (!name || seen.has(key)) return; seen.add(key); out.push({name, effect: it.effect||'', desc: it.desc||'', weight: parseFloat(it.weight)||0, price: it.price||'', src, cat: cat||'', sub: sub||''}); };
  for (const it of DATA.items||[]) add(it, 'Item All', it.cat, it.sub);
  for (const it of DATA.sets.common.items) add(it, 'ชุดยังชีพ', 'ชุดเริ่มต้น', 'ชุดยังชีพ'); for (const st of DATA.sets.sets) for (const it of st.items) add(it, st.nameEn, 'ชุดเริ่มต้น', st.nameEn);
  itemCatalogCache = out; return out; }
function itemCats(){ return [...new Set(itemCatalog().map(i=>i.cat).filter(Boolean))]; }
async function sendGift(r, t, item){
  const gift = { id: uid(), toCharId: t.charId, toName: t.name, item: {name:item.name, effect:item.effect||'', weight:+item.weight||0, qty:+item.qty||1}, from: Store.displayName||'GM', fromId: Store.me||'local', at: Date.now() };
  if (Table.localMode || !Store.db){ applyGift(r.id, gift, true); } else { try { await Store.db.doc(`rooms/${r.id}/gifts/${gift.id}`).set(gift); } catch(e){ toast('ส่งไอเทมไม่ได้ (สิทธิ์ไม่พอ?)'); return; } }
  Table.post({kind:'sys',who:'GM',text:`GM มอบ ${item.name}${gift.item.qty>1? ' ×'+gift.item.qty:''} ให้ ${t.name}`});
  toast(`ส่ง ${item.name} ให้ ${t.name} แล้ว`);
}
const giftsApplied = new Set();
function applyGift(rid, g, force){
  if (!g || giftsApplied.has(g.id)) return;
  const c = Store.chars.find(x=>x.id===g.toCharId && (force || Store.isMine(x)));
  if (!c) return; // ไม่ใช่ตัวละครของฉัน เจ้าของจะรับเอง
  giftsApplied.add(g.id);
  if (!c.inventory) ensureSheetState(c, compute(c)); // ชีทที่ยังไม่เคยเปิด: เติมชุดเริ่มต้นก่อน ไม่งั้นของเริ่มต้นจะหาย
  c.inventory = c.inventory || [];
  const it = g.item||{}; const ex = c.inventory.find(x=>x.name===it.name && (x.effect||'')===(it.effect||''));
  if (ex) ex.qty = (ex.qty||1) + (it.qty||1); else c.inventory.push({name:it.name, effect:it.effect||'', qty:it.qty||1, weight:it.weight||0});
  Store.upsert(c);
  toast(`${g.from||'GM'} ให้ ${it.name}${it.qty>1?' ×'+it.qty:''} แก่ ${c.name} แล้ว (อยู่ในกระเป๋า)`);
  if (Store.db && !force) Store.db.doc(`rooms/${rid}/gifts/${g.id}`).delete().catch(()=>{});
  if (location.hash==='#sheet-'+c.id) renderSheet(c.id);
}
function giveItemModal(t, r){
  const cat = itemCatalog(); const q = h('input',{placeholder:'ค้นหาไอเทม (ชื่อหรือคุณสมบัติ)',style:'min-width:240px'}); const list = h('div',{class:'giftlist'});
  const catSel = h('select',null, h('option',{value:'',text:`ทุกหมวด (${cat.length})`}), itemCats().map(k=>h('option',{value:k,text:`${k} (${cat.filter(i=>i.cat===k).length})`})));
  const custom = { name: h('input',{placeholder:'ชื่อไอเทม',style:'min-width:180px'}), effect: h('input',{placeholder:'คุณสมบัติ',style:'min-width:220px'}), weight: h('input',{type:'number',step:'0.1',placeholder:'กก.',style:'width:70px'}), qty: h('input',{type:'number',min:1,value:1,style:'width:60px'}) };
  const draw = ()=>{ clear(list); const k = q.value.trim().toLowerCase(); const ck = catSel.value; const all = cat.filter(it => (!ck || it.cat===ck) && (!k || it.name.toLowerCase().includes(k) || (it.effect||'').toLowerCase().includes(k) || (it.desc||'').toLowerCase().includes(k))); const hits = all.slice(0, 60); if (!hits.length) list.append(h('div',{class:'dim',text:'ไม่พบ ใช้ช่อง "ไอเทมกำหนดเอง" ด้านล่างได้'})); for (const it of hits) list.append(h('div',{class:'gift'}, h('div',null, h('b',{text:it.name}), h('span',{class:'dim',style:'font-size:11px',text:` · ${it.weight} กก.${it.price? ' · '+it.price:''} · ${it.sub||it.src}`}), it.desc? h('div',{class:'dim',style:'font-size:11.5px'}, it.desc.slice(0,140)) : null, h('div',{class:'desc',style:'font-size:12px'}, T(it.effect))), h('button',{class:'small primary',onclick:()=>{ sendGift(r, t, it); modal(null); },text:'ให้'}))); if (all.length > hits.length) list.append(h('div',{class:'dim',style:'font-size:12px',text:`แสดง ${hits.length} จาก ${all.length} พิมพ์ค้นหาเพิ่มเพื่อกรอง`})); };
  q.oninput = draw; catSel.onchange = draw; draw();
  modal(h('div',null, h('h3',{text:`ใส่ไอเทมลงกระเป๋าของ ${t.name}`}), h('p',{class:'dim',style:'font-size:12.5px',text:'ของจะไปอยู่ในกระเป๋าของตัวละครทันทีที่เครื่องของเจ้าของออนไลน์ (เจ้าของเห็นข้อความแจ้ง) · รายการจาก Item All ทั้งไฟล์และชุดเริ่มต้น'}), h('div',{class:'row',style:'margin-bottom:6px'}, catSel, q), list,
    h('div',{class:'card',style:'margin-top:10px'}, h('h4',{text:'ไอเทมกำหนดเอง'}), h('div',{class:'row',style:'margin-top:6px'}, custom.name, custom.effect, custom.weight, custom.qty, h('button',{class:'small primary',onclick:()=>{ const name = custom.name.value.trim(); if (!name){ toast('ใส่ชื่อไอเทม'); return; } sendGift(r, t, {name, effect: custom.effect.value.trim(), weight: +custom.weight.value||0, qty: +custom.qty.value||1}); modal(null); },text:'ให้'})))));
  setTimeout(()=>q.focus(), 50);
}
function renderTableHome(){
  const root = clear($('#v-table'));
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'โต๊ะเล่น'}), h('p',{text:'ห้องหนึ่งคือโต๊ะหนึ่งตัว GM สร้างห้องแล้วส่งลิงก์ให้เพื่อน ผู้เล่นวางตัวละครลงแผนที่ 20×20 แล้วทอยเต๋าด้วยกันในแชต อยากเตรียมแผนที่ไว้ก่อน ไปที่หน้า "แผนที่" ได้เลย'}))));
  if (!Store.db){
    root.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'ตอนนี้ไม่มีการเชื่อมต่อฐานข้อมูล (เปิดไฟล์ออฟไลน์ หรือเชื่อม Firebase ไม่สำเร็จ) ห้องที่สร้างจะอยู่ในเครื่องนี้เท่านั้น ใช้ทดลองแผนที่และทอยเต๋าได้ แต่คนอื่นจะไม่เห็น'));
  } else if (Store.canWrite===false){
    root.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'คุณเปิดเพจแบบดูอย่างเดียว: อ่านห้องได้แต่ย้ายตัวละครหรือส่งข้อความไม่ได้ ขอให้เจ้าของเพจแชร์ให้คุณเป็น Contributor'));
  }
  const nameInp = h('input',{placeholder:'ชื่อห้อง เช่น คืนวันสถาปนา',style:'min-width:240px'});
  root.append(h('div',{class:'card',style:'margin-bottom:14px'}, h('div',{class:'row'}, nameInp, h('button',{class:'primary',onclick:async()=>{ const nm = nameInp.value.trim()||'โต๊ะใหม่'; const r = newRoom(nm); rememberGmKey(r.id, r.gmKey); if (!Store.db){ const rooms=loadLocalRooms(); rooms.push(r); saveLocalRooms(rooms); } else { try{ await Store.db.doc('rooms/'+r.id).set(r); await Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)); }catch(e){ toast('สร้างห้องไม่ได้ (สิทธิ์ไม่พอ?)'); return; } } location.hash='#room-'+r.id; },text:'สร้างห้อง (คุณเป็น GM)'}))));
  const list = h('div',{class:'grid two'});
  const draw = (rooms)=>{ clear(list); if(!rooms.length) list.append(h('div',{class:'card dim',text:'ยังไม่มีห้อง'})); for (const r of rooms.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0))) list.append(h('div',{class:'card pick',onclick:()=>{location.hash='#room-'+r.id;}}, h('h3',{text:r.name||'(ไม่มีชื่อ)'}), h('div',{class:'gives'}, tag(`${Array.isArray(r.tokens)? r.tokens.length : (r.tokens||0)} ตัวละครบนบอร์ด`), (r.encActive || (r.enc&&r.enc.active))? tag(`กำลังสู้ รอบ ${r.round||(r.enc&&r.enc.round)||0}`,'neg') : null, r.hasKey ? tag('🔒 มีรหัส','warn') : null, (r.gmId===Store.me||!Store.db||gmKeys()[r.id])? tag('คุณเป็น GM','prop'):null), h('div',{class:'desc',text: (r.gmName? 'GM: '+r.gmName+' · ' : '') + (r.scene? r.scene.slice(0,100) : '')}))); };
  root.append(list);
  if (!Store.db) draw(loadLocalRooms());
  else { draw(roomsCache); if (!roomsUnsub){ const merge = (a, b)=>{ const m = new Map(); for (const x of [...a, ...b]) if (x && x.id && !m.has(x.id)) m.set(x.id, x); return [...m.values()]; }; let lobbyList = [], legacy = []; const refresh = ()=>{ roomsCache = merge(lobbyList, legacy); if (location.hash==='#table') renderTableHome(); };
      try{ roomsUnsub = Store.db.collection('lobby').onSnapshot(snap=>{ lobbyList = snapDocs(snap).filter(Boolean); refresh(); }, e=>console.warn('lobby', e)); }catch(e){ console.warn(e); }
      try{ Store.db.collection('rooms').onSnapshot(snap=>{ legacy = snapDocs(snap).filter(Boolean).map(r=>Object.assign(lobbyDoc(r), {legacy:true})); refresh(); }, e=>{ /* Rules รุ่นใหม่ไม่ให้ query ห้องตรง ๆ ใช้ล็อบบี้แทน */ }); }catch(e){} } }
}

function renderTable(){
  if (!Table.roomId || location.hash!=='#room-'+Table.roomId) return;
  // จำช่องที่กำลังพิมพ์อยู่ (แชต ฉาก ชื่อ NPC) เพื่อไม่ให้การพิมพ์ถูกตัดเมื่อห้องอัปเดต
  const ae = document.activeElement; const scopes = [$('#v-table'), $('#twins')].filter(Boolean); const keep = (ae && scopes.some(sc=>sc.contains(ae)) && /^(INPUT|TEXTAREA)$/.test(ae.tagName)) ? {ph: ae.getAttribute('placeholder')||'', tag: ae.tagName, value: ae.value, s: ae.selectionStart, e: ae.selectionEnd} : null;
  try { renderTableInner(); } catch(err){ console.error('renderTable', err); const root = $('#v-table'); root.append(h('div',{class:'warnbox',style:'margin-top:10px'}, 'แสดงห้องไม่สำเร็จ: '+(err && err.message||err), ' ', h('button',{class:'small',onclick:()=>renderTable(),text:'ลองใหม่'}))); }
  if (keep){ const el = scopes.flatMap(sc=>[...sc.querySelectorAll(keep.tag.toLowerCase())]).find(x=>(x.getAttribute('placeholder')||'')===keep.ph); if (el && el !== document.activeElement){ if (keep.value && el.value !== keep.value) el.value = keep.value; try { el.focus({preventScroll:true}); el.setSelectionRange(keep.s, keep.e); } catch(e){} } }
}
function renderTableInner(){
  const root = clearKeep($('#v-table'));
  const r = Table.room;
  if (!r){ clearTwins(); root.append(h('div',{class:'card',text: Table.localMode ? 'ไม่พบห้องนี้ในเครื่อง (ถ้าเป็นห้องออนไลน์ รอการเชื่อมต่อสักครู่)' : 'กำลังเปิดห้อง… (ถ้าค้างนาน แปลว่าไม่พบห้องนี้)'}), h('button',{style:'margin-top:10px',onclick:()=>{location.hash='#table';},text:'← กลับรายการห้อง'})); return; }
  const gm = Table.isGM();
  const myChars = Store.chars.filter(c=>c.done && Store.isMine(c));
  // หมากของฉันที่ยังไม่มีสำเนาชีทในห้อง (วางไว้ตั้งแต่รุ่นก่อน) → แชร์ให้ GM เห็นได้
  if (!Table.localMode) for (const t of r.tokens||[]) if (t.charId && t.ownerId===Store.me && !Table.roomChars.some(x=>x.id===t.charId)){ const c = Store.chars.find(x=>x.id===t.charId); if (c && !(c.roomIds||[]).includes(r.id)) Store.shareToRoom(c, r.id); }
  // ห้องรุ่นก่อนไม่มีเอกสารล็อบบี้: GM เขียนให้ครั้งแรกที่เปิด
  if (gm && !Table.localMode && Table.lobbyWritten !== r.id){ Table.lobbyWritten = r.id; Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)).catch(()=>{}); }
  // ตัวละครของฉันที่ยังซิงก์กับห้องนี้แต่หมากถูกเอาออกไปแล้ว → เลิกซิงก์และลบสำเนา
  if (!Table.localMode) for (const c of Store.chars) if (Store.isMine(c) && (c.roomIds||[]).includes(r.id) && !(r.tokens||[]).some(t=>t.charId===c.id)) Store.unshareFromRoom(c, r.id);
  // HP/Sanity ของหมากกับชีทต้องตรงกัน (ฝั่งที่แก้ล่าสุดชนะ) ถ้าหมากต้องอัปเดตตามชีท ให้บันทึกห้องแล้ววาดใหม่
  if (syncVitalsWithSheets(r) && !Table._vitalsSaving){ Table._vitalsSaving = true; Table.save(); Table._vitalsSaving = false; return; }
  // header
  const gmKeyBtn = gm && r.gmKey ? h('button',{class:'small ghost',title:'รหัสสำหรับเข้าเป็น GM จากเครื่องอื่น',onclick:()=>{ modal(h('div',null, h('h3',{text:'รหัส GM ของห้องนี้'}), h('p',{class:'desc',text:'ใช้เมื่อคุณเปิดห้องจากเครื่องหรือเบราว์เซอร์อื่น: กด "เข้าเป็น GM" แล้วกรอกรหัสนี้ อย่าให้ผู้เล่นเห็น'}), h('div',{style:'font-family:var(--font-display);font-size:28px;letter-spacing:4px',text:r.gmKey}))); },text:'รหัส GM'}) : null;
  const becomeGm = !gm && r.gmKey ? h('button',{class:'small ghost',onclick:()=>{ const k=(prompt('กรอกรหัส GM ของห้องนี้')||'').trim().toUpperCase(); if(!k) return; if (k===r.gmKey){ rememberGmKey(r.id,k); toast('คุณเป็น GM ของห้องนี้แล้ว'); renderTable(); } else toast('รหัสไม่ถูกต้อง'); },text:'เข้าเป็น GM'}) : null;
  const keyBtn = gm ? h('button',{class:'small ghost'+(r.hasKey?' on':''),title:'ตั้งรหัสให้ผู้เล่นต้องกรอกก่อนเข้าห้อง',onclick:()=>roomKeyModal(r),text: r.hasKey ? '🔒 รหัสเข้าห้อง' : 'ตั้งรหัสเข้าห้อง'}) : (r.hasKey ? tag('🔒 ห้องมีรหัส') : null);
  const mySheetBtns = (r.tokens||[]).filter(t=>t.charId && (t.ownerId===Store.me || Table.localMode)).map(t=>h('button',{class:'small',title:'เปิดชีทตัวละครของคุณ (มีปุ่มกลับโต๊ะที่หัวชีท)',onclick:()=>{ location.hash='#sheet-'+t.charId; },text:'📜 ชีท: '+t.name}));
  const shareBtn = h('button',{class:'small ghost',onclick:()=>{ const url = location.href.split('#')[0] + '#room-' + r.id; navigator.clipboard.writeText(url).then(()=>toast('คัดลอกลิงก์ห้องแล้ว')).catch(()=>modal(h('div',null, h('h3',{text:'ลิงก์ห้อง'}), h('input',{style:'width:100%',value:url,readonly:true})))); },text:'ลิงก์ห้อง'});
  const head = h('div',{class:'stephead'}, h('div',null, h('h2',{text:r.name}), h('p',null, gm? tag('คุณเป็น GM','prop') : tag('ผู้เล่น'), ' ', h('span',{id:'peers',class:'dim',style:'font-size:13px'}), Table.localMode? [' ', tag('ห้องในเครื่องนี้','warn')] : null)),
    h('div',{class:'row'}, ...mySheetBtns, shareBtn, keyBtn, gmKeyBtn, becomeGm, gm? h('button',{class:'small ghost',onclick:async()=>{ if(!confirm(`ลบห้อง "${r.name}" ถาวร? แชต บอร์ด และสำเนาชีทในห้องจะหายทั้งหมด`)) return; const id=r.id; const snapshot = JSON.parse(JSON.stringify(r)); Table.close(); if (!Store.db){ saveLocalRooms(loadLocalRooms().filter(x=>x.id!==id)); for (const t of snapshot.tokens||[]){ const mine = Store.chars.find(c=>c.id===t.charId); if (mine) Store.unshareFromRoom(mine, id); } } else { toast('กำลังลบห้องและสำเนาชีท…'); await deleteRoomDeep(snapshot); } location.hash='#table'; },text:'ลบห้อง'}) : null, h('button',{class:'small ghost',onclick:()=>{ Table.close(); location.hash='#table'; },text:'← ออกจากห้อง'})));
  root.append(head);
  const left = h('div'); const right = h('div');
  // scene text
  if (gm){ const ta = h('textarea',{placeholder:'บรรยายฉาก (ผู้เล่นเห็น)'}); ta.value = r.scene||''; ta.onblur = ()=>{ if (ta.value!==(r.scene||'')){ r.scene = ta.value; Table.save(); } }; left.append(h('div',{class:'card',style:'margin-bottom:12px'}, h('label',{text:'ฉาก'}), ta)); }
  else if (r.scene) left.append(h('div',{class:'card',style:'margin-bottom:12px'}, h('div',{class:'kicker',text:'ฉาก'}), h('p',{style:'margin:4px 0 0',text:r.scene})));
  // add token controls
  const addRow = h('div',{class:'row',style:'margin-bottom:10px'});
  if (myChars.length){ const sel = h('select',null, myChars.map(c=>h('option',{value:c.id,text:c.name}))); addRow.append(sel, h('button',{class:'small primary',onclick:()=>placeCharacter(Store.get(sel.value), r),text:'วางตัวละครลงบอร์ด'})); }
  else addRow.append(h('span',{class:'dim',style:'font-size:13px',text:'ยังไม่มีตัวละครที่พร้อมเล่น สร้างในหน้า "สร้างตัวละคร" ก่อน'}));
  if (gm){ const nm=h('input',{placeholder:'ชื่อ NPC/ศัตรู',style:'width:150px'}); const hp=h('input',{type:'number',style:'width:64px',value:10,title:'HP สูงสุด'}); const ini=h('input',{type:'number',style:'width:56px',value:0,title:'Initiative (บวกกับ 2d6 ตอนจัดลำดับเทิร์น)'}); const nv=h('input',{type:'checkbox',title:'มองเห็นในความมืด (Dark Vision)'});
    addRow.append(nm, h('label',{class:'fld'}, h('span',{text:'HP สูงสุด'}), hp), h('label',{class:'fld'}, h('span',{text:'Initiative'}), ini), h('label',{class:'fld chk',title:'มองเห็นในความมืด (Dark Vision) ไม่ติดตาบอดในที่มืด'}, nv, h('span',{text:'Dark Vision'})), h('button',{class:'small',onclick:()=>{ const n=nm.value.trim()||'ศัตรู'; const pos = freeCell(r.map, r.tokens, [0,1,2,3]); r.tokens.push({id:uid(), name:n, kind:'npc', x:pos.x, y:pos.y, hp:+hp.value||10, hpMax:+hp.value||10, san:0, sanMax:0, init:+ini.value||0, hidden:true, note:'', desc:'', nv: nv.checked, torch:false, aquatic:false, inWater:false}); Table.save(); },text:'+ NPC (ซ่อนไว้ก่อน)'})); }
  left.append(addRow);
  // ---- แผนที่ต่อสู้ 20×20 ----
  left.append(mapPanel(r, gm));
  left.append(h('p',{class:'dim',style:'font-size:12px;margin-top:8px',text:`หนึ่งช่องคือ ${CELL_M} เมตร ช่องที่ติดกัน (รวมทแยง) คือเขตปะทะ ไม่เกิน 25 เมตรคือเขตใกล้เคียง ไกลกว่านั้นคือเขตไกล จากใกล้เคียงเข้าปะทะใช้ 1 Swift ถอยออกจากปะทะก็ 1 Swift แต่โดนโจมตีฉวยโอกาส จากใกล้เคียงไปไกลใช้ Swift บวก 1 AP ช่องเดินช้า (น้ำตื้น หิมะ โคลน เศษหิน) นับเป็นสองช่อง น้ำลึกว่ายได้แต่เสียเทิร์นที่ลงไป และโจมตีไม่ได้จนกว่าจะขึ้นฝั่ง (สัตว์น้ำยกเว้น) · ลากหมากเพื่อย้าย คลิกหมากเพื่อดูโซนและระยะมองเห็น`}));
  // หน้าปัด: ลำดับเทิร์นและหมาก + หมากที่เลือก (ฝังคอลัมน์ขวา กด ⇱ ปลดลอยได้ ปิดไม่ได้)
  right.append(h('div',{style:'margin-bottom:12px'}, twinDock(r, gm)));
  // clocks
  const ck = h('div',{class:'card',style:'margin-bottom:12px'}, h('h3',{text:'นาฬิกาชะตากรรม (Fate Clock)'}));
  const ckrow = h('div',{class:'row',style:'margin-top:8px;align-items:flex-start'});
  for (const cl of r.clocks||[]) ckrow.append(clockEl(cl, r, gm));
  ck.append(ckrow);
  if (gm){ const nm=h('input',{placeholder:'ชื่อนาฬิกา',style:'width:140px'}); const seg=h('select',null,[4,6,8,10,12].map(n=>h('option',{value:n,text:n+' ช่อง'}))); ck.append(h('div',{class:'row',style:'margin-top:8px'}, nm, seg, h('button',{class:'small',onclick:()=>{ r.clocks=r.clocks||[]; r.clocks.push({id:uid(),name:nm.value.trim()||'นาฬิกา',seg:+seg.value,fill:0}); Table.save(); },text:'+ นาฬิกา'}))); }
  right.append(ck);
  // แชตและบันทึกการทอย อยู่ใต้แผนที่ (ผู้ใช้เคาะ 9 พ.ย. 2026) ปุ่มทอยย้ายไปหน้าต่างลอย 🎲 ที่แท็บมุมจอ
  const chatBox = h('div',{class:'card chat',style:'margin-top:12px'}, h('h3',{class:'row',style:'justify-content:space-between'}, h('span',{text:'แชตและบันทึกการทอยของโต๊ะ'}), h('button',{class:'small ghost rollbtn',title:'เปิดหน้าต่างทอยเต๋า (แท็บ 🎲 มุมจอ)',onclick:()=>{ TWin.dice = true; TWin.persist(); renderTwins(r, gm); },text:'🎲 ทอยเต๋า'})), h('div',{class:'log',id:'chatlog'}));
  const who = h('select',{id:'chat-who'}, h('option',{value:'',text: gm?'GM'+(Store.displayName?' ('+Store.displayName+')':'') : (Store.displayName||'ผู้เล่น')}), myChars.map(c=>h('option',{value:c.id,text:c.name})));
  if (Table.chatWho && myChars.some(c=>c.id===Table.chatWho)) who.value = Table.chatWho; who.onchange = ()=>{ Table.chatWho = who.value; };
  const inp = h('input',{placeholder:'พิมพ์ข้อความ หรือ /r 2d6+2 · /adv · /dis · /gm (ลับ)',style:'flex:1;min-width:160px'});
  const send = ()=>{ const txt = inp.value.trim(); if(!txt) return; inp.value=''; const c = Store.get(who.value); const name = c? c.name : (gm?'GM':(Store.displayName||'ผู้เล่น')); handleChatInput(txt, name, c, gm); };
  inp.onkeydown = (e)=>{ if (e.key==='Enter' && !e.isComposing){ e.preventDefault(); send(); } };
  chatBox.append(h('div',{class:'row'}, who, inp, h('button',{class:'primary small',onclick:send,text:'ส่ง'})));
  chatBox.append(h('div',{id:'roll-lock-banner',class:'lockbanner hidden'}));
  left.append(chatBox);
  updateRollLockUI();
  root.append(h('div',{class:'table-wrap'}, left, right));
  renderChatOnly(); renderPeers();
  renderTwins(r, gm);
}
/* วางตัวละครของฉันลงบอร์ด: สร้างหมาก + แชร์สำเนาชีทเข้าห้อง (ผู้เล่นคนอื่นและ GM จึงเห็นชีทได้เฉพาะในแคมเปญนี้) */
async function placeCharacter(c, r){
  if (!c) return;
  if (r.tokens.some(t=>t.charId===c.id)){ toast('ตัวละครนี้อยู่บนบอร์ดแล้ว'); return; }
  const d = compute(c); const thumb = await makeThumb(c.portrait);
  const pos = freeCell(r.map, r.tokens, [16,17,18,19]);
  r.tokens.push({id:uid(), name:c.name, kind:'pc', charId:c.id, ownerId:Store.me||'local', ownerName: Store.displayName||'', x:pos.x, y:pos.y, hp:(c.current&&c.current.hp)??d.hp, hpMax:d.hp, san:(c.current&&c.current.sanity)??d.sanity, sanMax:d.sanity, tough: Object.assign({}, (c.current&&c.current.tough)||{}), init:d.initiative, hidden:false, note:'', desc:'', thumb: thumb||null, nv: charHasNightVision(c), torch:false, aquatic:false, inWater:false, vitalsAt:(c.current&&c.current.at)||Date.now()});
  Table.save(); Table.post({kind:'sys', who:'', text:`${c.name} เข้าร่วมฉาก`});
  Store.shareToRoom(c, r.id);
}
/* ===== หน้าปัดในห้อง (ลำดับเทิร์นและหมาก · หมากที่เลือก · ทอยเต๋า) ย้าย/ย่อขยายได้เหมือนหน้าต่างกระเป๋าและถุงย่าม =====
   v1.7: หน้าต่างคงอยู่ข้ามการวาดใหม่ (เปลี่ยนแค่เนื้อใน) ตำแหน่งมาจากการลากเท่านั้น จึงไม่เด้งไปมุมจอ · ลำดับเทิร์นกับหมากที่เลือกปิดไม่ได้ (ผู้ใช้เคาะ 9 พ.ย. 2026) */
const TWin = {
  float: {order:false, tok:false}, pos: {}, collapsed: {}, dice: false, dock: null,
  load(){ try { const s = JSON.parse(localStorage.getItem('kirana.twin')||'{}'); this.float = Object.assign({order:false, tok:false}, s.float||{}); this.pos = s.pos||{}; this.collapsed = s.collapsed||{}; this.dice = !!s.dice; this.dock = s.dock||null; for (const k of Object.keys(this.pos)){ const p = this.pos[k]; if (!p || !(p.w>0) || !(p.x>=0) || !(p.y>=0)) delete this.pos[k]; } } catch(e){} },
  persist(){ try { localStorage.setItem('kirana.twin', JSON.stringify({float:this.float, pos:this.pos, collapsed:this.collapsed, dice:this.dice, dock:this.dock})); } catch(e){} },
};
TWin.load();
const TWIN_TITLE = {order:'⚔ ลำดับเทิร์นและหมาก', tok:'🎯 หมากที่เลือก', dice:'🎲 ทอยเต๋า'};
function isNarrow(){ return vw() < 900; }
function twinsRoot(){ let root = $('#twins'); if (!root){ root = h('div',{id:'twins'}); document.body.append(root); } return root; }
function clearTwins(){ const root = $('#twins'); if (root) clear(root); }
function renderTwins(r, gm){
  const root = twinsRoot();
  const inRoom = r && location.hash === '#room-'+r.id;
  if (!inRoom){ clear(root); return; }
  const want = [];
  if (!isNarrow()){ if (TWin.float.order) want.push(['order', ()=>orderBody(r, gm), null]); if (TWin.float.tok) want.push(['tok', ()=>tokBody(r, gm), null]); }
  if (TWin.dice) want.push(['dice', ()=>diceBody(r, gm), diceKey(r, gm)]);
  for (const el of [...root.querySelectorAll('.twin')]) if (!want.some(([k])=>el.classList.contains('twin-'+k))) el.remove();
  for (const [key, build, cacheKey] of want){
    let win = root.querySelector('.twin-'+key);
    if (!win){ win = twin(key); root.append(win); }
    if (cacheKey && win.dataset.key === cacheKey) continue; // เนื้อในเดิมใช้ได้ ไม่ต้องสร้างใหม่ (แผงทอยจำโหมด/บุคลิกภาพที่ตั้งไว้)
    if (cacheKey) win.dataset.key = cacheKey;
    fillTwin(win, build());
  }
  // แท็บทอยเต๋าลอย (เหมือน dock ในชีท) อยู่เสมอขณะอยู่ในห้อง
  let dock = root.querySelector('.rdock'); if (!dock){ dock = roomDock(); root.append(dock); }
  dock.querySelector('.hud-btn').classList.toggle('on', !!TWin.dice);
  for (const el of root.querySelectorAll('.twin, .rdock')) clampToViewport(el);
}
/* เปลี่ยนเนื้อในหน้าต่าง เก็บตำแหน่งเลื่อนและช่องที่กำลังพิมพ์ไว้ */
function fillTwin(win, body){
  const b = win.querySelector('.hud-body'); const top = b.scrollTop;
  const ae = document.activeElement; const keep = (ae && b.contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) ? {ph: ae.getAttribute('placeholder')||'', tag: ae.tagName, value: ae.value, s: ae.selectionStart, e: ae.selectionEnd} : null;
  clear(b); b.append(body); b.scrollTop = top;
  if (keep){ const el = [...b.querySelectorAll(keep.tag.toLowerCase())].find(x=>(x.getAttribute('placeholder')||'')===keep.ph); if (el){ if (keep.tag!=='SELECT' && keep.value && el.value !== keep.value) el.value = keep.value; try { el.focus({preventScroll:true}); if (keep.tag!=='SELECT') el.setSelectionRange(keep.s, keep.e); } catch(e){} } }
}
function twin(key){
  const win = h('div',{class:'hud-win twin twin-'+key+(key==='dice'?' dice':'')+(TWin.collapsed[key]?' collapsed':'')});
  const collapseBtn = h('button',{class:'hud-x',title: TWin.collapsed[key] ? 'ขยาย' : 'ย่อ',onclick:()=>{ TWin.collapsed[key] = !TWin.collapsed[key]; TWin.persist(); win.classList.toggle('collapsed', !!TWin.collapsed[key]); collapseBtn.title = TWin.collapsed[key] ? 'ขยาย' : 'ย่อ'; collapseBtn.firstChild.textContent = TWin.collapsed[key] ? '▢' : '–'; if (!TWin.collapsed[key] && TWin.pos[key] && TWin.pos[key].h) win.style.height = TWin.pos[key].h+'px'; }}, h('span',{text: TWin.collapsed[key] ? '▢' : '–'}));
  const head = h('div',{class:'hud-head'}, key==='dice' ? svgEl('dice') : null, h('b',{text: key==='dice' ? 'ทอยเต๋า' : TWIN_TITLE[key]}), collapseBtn);
  if (key==='dice') head.append(h('button',{class:'hud-x',title:'ปิด (เปิดใหม่ได้ที่แท็บ 🎲 มุมจอ)',onclick:()=>{ TWin.dice = false; TWin.persist(); renderTwins(Table.room, Table.isGM()); }}, svgEl('close')));
  else head.append(h('button',{class:'hud-x',title:'เก็บกลับเข้าคอลัมน์ขวา',onclick:()=>{ TWin.float[key] = false; TWin.persist(); renderTable(); }}, h('span',{text:'⇲'})));
  const b = h('div',{class:'hud-body'});
  win.append(head, b);
  const p = TWin.pos[key];
  if (p){ win.style.left = p.x+'px'; win.style.top = p.y+'px'; win.style.right = 'auto'; win.style.bottom = 'auto'; if (p.w) win.style.width = p.w+'px'; if (p.h && !TWin.collapsed[key]) win.style.height = p.h+'px'; }
  else if (key==='dice'){ win.style.right = '14px'; win.style.bottom = '96px'; win.style.top = 'auto'; }
  else if (key==='tok'){ win.style.right = '14px'; win.style.top = '84px'; }
  else { win.style.right = TWin.float.tok ? '390px' : '14px'; win.style.top = '84px'; } // ลำดับเทิร์นอยู่ซ้ายของหมากที่เลือกเมื่อลอยทั้งคู่
  // ขนาดจากการย่อขยายด้วยมือเท่านั้น: หน้าต่างที่หลุดจาก DOM หรือยุบอยู่มีขนาด 0 ต้องไม่ถูกจำ (ตัวการที่ทำให้เด้งไปมุมซ้ายบนใน v1.6)
  let first = true; new ResizeObserver(()=>{ if (first){ first=false; return; } if (!win.isConnected || TWin.collapsed[key] || !win.offsetWidth || !win.offsetHeight) return; const cur = TWin.pos[key]; if (cur && cur.w===win.offsetWidth && cur.h===win.offsetHeight) return; const rct = win.getBoundingClientRect(); const z = uiZoom(); TWin.pos[key] = {x: Math.max(0, Math.round(rct.left/z)), y: Math.max(0, Math.round(rct.top/z)), w: win.offsetWidth, h: win.offsetHeight}; TWin.persist(); }).observe(win);
  makeDraggable(win, head, (pp)=>{ TWin.pos[key] = {...(TWin.pos[key]||{w: win.offsetWidth, h: win.offsetHeight}), x: Math.round(pp.x), y: Math.round(pp.y)}; TWin.persist(); });
  return win;
}
/* ดันหน้าต่าง/แท็บที่หลุดขอบจอกลับเข้ามา (ไม่รีเซ็ตตำแหน่ง) */
function clampToViewport(el){
  const r0 = el.getBoundingClientRect(); if (!r0.width) return; const z = uiZoom();
  const rct = {left:r0.left/z, top:r0.top/z, width:r0.width/z, height:r0.height/z}; // พิกัดหลัง zoom ให้ตรงกับ style.left/top
  const maxX = Math.max(4, vw() - rct.width - 4), maxY = Math.max(4, vh() - Math.min(rct.height, 120) - 4);
  if (rct.left >= 0 && rct.top >= 0 && rct.left <= maxX && rct.top <= maxY) return;
  const x = Math.min(maxX, Math.max(4, rct.left)), y = Math.min(maxY, Math.max(4, rct.top));
  el.style.left = x+'px'; el.style.top = y+'px'; el.style.right = 'auto'; el.style.bottom = 'auto';
}
window.addEventListener('resize', ()=>{ const root = $('#twins'); if (root) for (const el of root.querySelectorAll('.twin, .rdock')) clampToViewport(el); });
/* แท็บทอยเต๋ามุมจอ: ปุ่มเดียวแบบ dock ในชีท ลากย้ายได้ กดเปิด/ปิดหน้าต่างทอย ป้ายทองคือผลทอยล่าสุดของฉัน */
function roomDock(){
  const dock = h('div',{class:'hud-dock rdock'});
  const btn = h('button',{class:'hud-btn'+(TWin.dice?' on':''),title:'ทอยเต๋า',onclick:()=>{ if (dock.dataset.justDragged) return; TWin.dice = !TWin.dice; TWin.persist(); renderTwins(Table.room, Table.isGM()); }}, svgEl('dice'), h('span',{class:'lbl',text:'ทอยเต๋า'}), h('span',{class:'badge gold hidden'}));
  dock.append(h('div',{class:'hud-grip',title:'ลากเพื่อย้าย'}, svgEl('grip')), btn);
  if (TWin.dock && TWin.dock.x>=0 && TWin.dock.y>=0){ dock.style.left = TWin.dock.x+'px'; dock.style.top = TWin.dock.y+'px'; dock.style.right = 'auto'; dock.style.bottom = 'auto'; }
  makeDraggable(dock, dock, (p)=>{ TWin.dock = {x: Math.round(p.x), y: Math.round(p.y)}; TWin.persist(); });
  return dock;
}
function diceBadge(total){ const bd = document.querySelector('#twins .rdock .badge'); if (!bd) return; bd.textContent = String(total); bd.classList.remove('hidden'); }
function diceKey(r, gm){ const mine = Store.chars.filter(c=>c.done && Store.isMine(c)); return (gm?'gm':'pl') + '|' + (Table.localMode?'L':'F') + '|' + mine.map(c=>c.id+':'+c.name+':'+(c.updatedAt||0)).join(','); }
/* เนื้อในหน้าต่างทอยเต๋า: เลือกตัวละครที่ทอยในนาม ปุ่มทอยด่วน (2d6 / Attack / Luck / ทอยลับ GM) และแผงทอยเต็มแบบเดียวกับในชีท */
function diceBody(r, gm){
  const myChars = Store.chars.filter(c=>c.done && Store.isMine(c));
  const box = h('div',{class:'twin-dice'});
  if (Table.diceWho==null){ const sel = Table.sel ? (r.tokens||[]).find(x=>x.id===Table.sel) : null; Table.diceWho = (sel && sel.charId && myChars.some(c=>c.id===sel.charId)) ? sel.charId : (myChars[0] ? myChars[0].id : ''); }
  const who = h('select',{style:'min-width:160px'}, h('option',{value:'',text: gm?'GM'+(Store.displayName?' ('+Store.displayName+')':'') : (Store.displayName||'ผู้เล่น')}), myChars.map(c=>h('option',{value:c.id,text:c.name})));
  who.value = myChars.some(c=>c.id===Table.diceWho) ? Table.diceWho : '';
  const selChar = ()=>Store.get(who.value);
  const whoName = ()=>{ const c=selChar(); return c? c.name : (gm?'GM':(Store.displayName||'ผู้เล่น')); };
  const onRoll = (e, c)=>{ Table.postRoll(e, c); diceBadge(e.total); };
  const qroll = (label, kind)=>{ const c=selChar(); if (kind==='attack' && c){ const blk = Table.attackBlocked(c); if (blk){ toast(blk); return; } } Table.guardedRoll(whoName(), ()=>onRoll(doRoll({label, kind, c}), c), label); };
  const quick = h('div',{class:'row'}, h('button',{class:'small rollbtn',onclick:()=>qroll('2d6','check'),text:'2d6'}), h('button',{class:'small rollbtn',onclick:()=>qroll('Attack Roll','attack'),text:'Attack (CV)'}), h('button',{class:'small rollbtn',onclick:()=>qroll('Luck Saving Throw','luck'),text:'Luck'}),
    ...(gm? [h('button',{class:'small ghost rollbtn',onclick:()=>{ Table.guardedRoll('GM', ()=>{ const e=doRoll({label:'ทอยลับของ GM'}); Table.post({kind:'roll',who:'GM',text:e.label,roll:{dice:e.r.dice,kept:e.r.kept,keptIdx:e.r.keptIdx,sum:e.r.sum,crit:e.r.crit,double:e.r.double,mode:e.mode},mod:0,pm:0,total:e.total,judge:e.judge,gmOnly:true}); diceBadge(e.total); }, 'ทอยลับ'); },text:'ทอยลับ (GM)'})] : []));
  box.append(h('div',{class:'row',style:'margin-bottom:6px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'ทอยในนาม'}), who), quick, h('div',{class:'lockbanner hidden',dataset:{lock:'1'}}));
  const panelHost = h('div',{style:'margin-top:8px'});
  const drawPanel = ()=>{ clear(panelHost); const c = selChar(); if (!c){ panelHost.append(h('p',{class:'dim',style:'font-size:12px;margin:0',text:'เลือกตัวละครด้านบนเพื่อเปิดแผงทอย Stat Check / Saving Throw / ความรู้ ผลทอยเด้งให้ทุกคนในห้องเห็น'})); return; } const p = dicePanel(c, (e)=>onRoll(e, c), {guard:(run,label)=>Table.guardedRoll(c.name, run, label), noLog:true}); p.classList.remove('card'); p.classList.add('hud-dice'); panelHost.append(p); };
  who.addEventListener('change', ()=>{ Table.diceWho = who.value; drawPanel(); }); drawPanel();
  box.append(panelHost);
  updateRollLockUI();
  return box;
}
/* หน้าปัดในคอลัมน์ขวา: ฝังเป็นการ์ดเสมอ กด ⇱ เพื่อปลดเป็นหน้าต่างลอยที่ลากและย่อขยายได้ (จำตำแหน่งไว้) · จอแคบฝังเสมอ · ไม่มีปุ่มปิด */
function twinDock(r, gm){
  const wrap = h('div',{class:'twindock-wrap'});
  const panel = (key, body)=>{ const floating = TWin.float[key] && !isNarrow();
    const head = h('h3',{class:'row',style:'justify-content:space-between'}, h('span',{text:TWIN_TITLE[key].replace(/^\S+\s/,'')}), isNarrow() ? null : h('button',{class:'small ghost',title: floating ? 'เก็บกลับเข้าคอลัมน์' : 'ปลดเป็นหน้าต่างลอย ลากวางที่ไหนก็ได้',onclick:()=>{ TWin.float[key] = !TWin.float[key]; TWin.persist(); renderTable(); },text: floating ? '⇲ เก็บกลับ' : '⇱ ลอย'}));
    return h('div',{class:'card twin-card',style:'margin-top:8px'}, head, floating ? h('p',{class:'dim',style:'font-size:12px;margin:4px 0 0',text:'กำลังลอยอยู่เป็นหน้าต่างบนจอ ลากหัวหน้าต่างเพื่อย้าย'}) : body); };
  wrap.append(panel('order', orderBody(r, gm)), panel('tok', tokBody(r, gm)));
  return wrap;
}
/* ลำดับที่ใช้แสดงหมาก: ตามลำดับเทิร์นเมื่อเริ่มสู้แล้ว ที่เหลือต่อท้าย (ผู้ใช้เคาะ 9 พ.ย. 2026) */
function orderedTokens(r){ const toks = r.tokens||[]; if (!r.enc || !r.enc.active) return toks.slice(); const order = r.enc.order||[]; const inOrder = order.map(id=>toks.find(t=>t.id===id)).filter(Boolean); return [...inOrder, ...toks.filter(t=>!order.includes(t.id))]; }
function orderBody(r, gm){
  const box = h('div',{class:'twin-order'});
  const enc = r.enc||{active:false, round:0, turnIdx:0, order:[]};
  const head = h('div',{class:'row',style:'gap:6px;margin-bottom:6px'}, enc.active ? tag(`รอบ ${enc.round}`,'neg') : tag('ยังไม่เริ่มสู้'));
  if (gm){ if (enc.active) head.append(h('button',{class:'primary small',onclick:()=>{ enc.turnIdx++; if (enc.turnIdx>=enc.order.length){ enc.turnIdx=0; enc.round++; tickConditions(r); } Table.save(); const t=r.tokens.find(x=>x.id===enc.order[enc.turnIdx]); if (t && !t.hidden) Table.post({kind:'sys',who:'',text:`เทิร์นของ ${t.name} (รอบ ${enc.round})`}); },text:'เทิร์นถัดไป →'}), h('button',{class:'small',onclick:()=>rollInitiative(r),text:'ทอยใหม่'}), h('button',{class:'small ghost',onclick:()=>{ r.enc={active:false,round:0,turnIdx:0,order:[]}; for (const t of r.tokens) delete t.initRoll; Table.save(); Table.post({kind:'sys',who:'',text:'จบฉากต่อสู้'}); },text:'จบการต่อสู้'}));
    else head.append(h('button',{class:'primary small',onclick:()=>rollInitiative(r),text:'เริ่มการต่อสู้ (ทอย 2d6 + Initiative)'})); }
  else if (enc.active){ const t=r.tokens.find(x=>x.id===enc.order[enc.turnIdx]); if (t && t.ownerId===Store.me) head.append(tag('ถึงเทิร์นของคุณ: 1 Swift 1 Basic 1 Cast','ok')); }
  box.append(head);
  const gmView = gm; const vis = gm ? null : computeVisibility(r, Store.me);
  const canSee = (t)=> (gmView || !t.hidden || t.ownerId===Store.me) && (!vis || t.ownerId===Store.me || vis.has(t.x+','+t.y));
  const cur = enc.active ? enc.order[enc.turnIdx] : null;
  const list = h('div',{class:'toklist compact'});
  const toks = orderedTokens(r).filter(canSee);
  toks.forEach((t, i)=>{
    const inOrder = enc.active && (enc.order||[]).includes(t.id);
    const row = h('div',{class:`tok ${t.kind}${t.hidden?' hid':''}${cur===t.id?' turn':''}${Table.sel===t.id?' sel':''}`,onclick:(e)=>{ if (e.target.closest('button,select,input,a')) return; Table.sel = Table.sel===t.id ? null : t.id; renderTable(); }},
      inOrder ? h('span',{class:'ord num',text:String(i+1)}) : h('span',{class:'ord dim',text:'·'}),
      t.thumb ? h('img',{class:'av',src:t.thumb,alt:''}) : h('div',{class:'av',text:(t.name||'?').slice(0,2)}),
      h('div',{class:'nm'}, h('div',null, h('span',{text:t.name}), t.hidden? h('span',{class:'dim',text:' (ซ่อน)'}):null, t.inside? h('span',{class:'dim',text:' 🦷'}):null, t.inWater? h('span',{title:'อยู่ในน้ำลึก',text:' 🌊'}):null),
        h('div',{class:'mini'}, h('span',{class:'num',text:`HP ${t.hp}/${t.hpMax}`}), t.sanMax? h('span',{class:'num',text:`SAN ${t.san}/${t.sanMax}`}):null, enc.active && t.initRoll!=null ? h('span',{class:'num',title:'ผลทอย Initiative',text:`⚡${t.initRoll}`}) : h('span',{class:'num dim',text:`Init ${signed(t.init||0)}`}), (t.conds||[]).length ? h('span',{text:(t.conds||[]).map(c=>condIcon(c.id)).join('')}) : null)));
    list.append(row);
  });
  if (!toks.length) list.append(h('div',{class:'dim',style:'font-size:13px',text:'ยังไม่มีหมากบนบอร์ด'}));
  box.append(list);
  box.append(h('p',{class:'dim',style:'font-size:11.5px;margin:8px 0 0',text:'ฉากหนึ่งยาว 1 นาที เทิร์นละ 6 วินาที ฝ่ายซุ่มโจมตีได้เริ่มก่อนเสมอ ทอยลำดับใหม่เมื่อเปลี่ยนฉาก · คลิกชื่อเพื่อเลือกหมาก'}));
  return box;
}
/* ---- หน้าต่างหมากที่เลือก: ค่าชีวิต สถานะ ปุ่มควบคุม คำอธิบาย และแผงต่อสู้ของตัวละคร (เจ้าของหรือ GM) ---- */
function tokBody(r, gm){
  const t = Table.sel ? (r.tokens||[]).find(x=>x.id===Table.sel) : null;
  if (!t) return h('p',{class:'dim',style:'font-size:13px;margin:0',text:'คลิกหมากบนบอร์ดหรือชื่อในลำดับเทิร์นเพื่อดูรายละเอียด · ลากหมากของคุณไปวางช่องอื่นเพื่อเคลื่อนที่'});
  const mine = t.ownerId===Store.me || gm || Table.localMode;
  const box = h('div',{class:'twin-tok'});
  const eater = t.inside ? r.tokens.find(o=>o.id===t.inside) : null;
  box.append(h('div',{class:'row',style:'gap:8px;align-items:center'}, t.thumb ? h('img',{class:'av big',src:t.thumb,alt:''}) : h('div',{class:'av big',text:(t.name||'?').slice(0,2)}),
    h('div',{style:'flex:1;min-width:0'}, h('div',{style:'font-weight:600'}, t.name, t.hidden? h('span',{class:'dim',text:' (ซ่อน)'}):null), h('div',{class:'mini'}, tag(t.kind==='pc' ? 'ตัวละคร' : 'NPC', t.kind==='pc'?'stat':'neg'), t.ownerName? h('span',{class:'dim',text:t.ownerName}):null, eater ? h('span',{class:'tag neg',text:'🦷 อยู่ในตัว '+eater.name}) : h('span',{class:'num dim',text:`(${t.x},${t.y})`}), t.inWater? tag('🌊 ในน้ำลึก','warn'):null, t.aquatic? tag('🐟 สัตว์น้ำ','stat'):null, t.nv? tag('👁 Dark Vision'):null, t.torch? tag('🔥 แหล่งแสง','prop'):null))));
  // ค่าชีวิต
  const vital = (label, key, maxKey, cls)=>{ const v = t[key]||0, mx = t[maxKey]||0; return h('div',{class:'vital'}, h('span',{class:'vl '+cls,text:label}), mine ? h('button',{class:'small',title:label+' −1',onclick:()=>{ tokenVitals(t, key, v-1); Table.save(); }},'−') : null, h('b',{class:'num',text:`${v} / ${mx}`}), mine ? h('button',{class:'small',title:label+' +1',onclick:()=>{ tokenVitals(t, key, Math.min(mx, v+1)); Table.save(); }},'+') : null, mine ? h('input',{type:'number',value:v,style:'width:56px',onchange:(e)=>{ tokenVitals(t, key, +e.target.value||0); Table.save(); }}) : null); };
  // NPC: Toughness ค่าเดียว GM ลดได้จากโต๊ะ (ตัวละครผู้เล่นใช้ตารางต่ออวัยวะในแผงต่อสู้ด้านล่าง)
  const npcTough = (!t.charId && gm) ? h('div',{class:'vital'}, h('span',{class:'vl',text:'Toughness'}), h('button',{class:'small',title:'Toughness −1',onclick:()=>{ t.tgh = Math.max(0, (t.tgh??t.tghMax??1) - 1); if (t.tghMax==null) t.tghMax = Math.max(1, t.tgh+1); Table.save(); }},'−'), h('b',{class:'num'+((t.tgh??1)<=0?' bad':''),text: t.tgh==null ? (t.tghMax!=null ? `${t.tghMax} / ${t.tghMax}` : '- / -') : `${t.tgh} / ${t.tghMax??'-'}`}), h('button',{class:'small',title:'Toughness +1',onclick:()=>{ const mx = t.tghMax??1; t.tgh = Math.min(mx, (t.tgh??mx) + 1); if (t.tghMax==null) t.tghMax = mx; Table.save(); }},'+'), h('input',{type:'number',min:0,value:t.tghMax??'',placeholder:'สูงสุด',title:'Toughness สูงสุดของ NPC นี้',style:'width:64px',onchange:(e)=>{ const mx = Math.max(0, +e.target.value||0); t.tghMax = mx; if (t.tgh==null || t.tgh>mx) t.tgh = mx; Table.save(); }})) : (!t.charId && t.tghMax!=null ? h('div',{class:'vital'}, h('span',{class:'vl',text:'Toughness'}), h('b',{class:'num'+((t.tgh??1)<=0?' bad':''),text:`${t.tgh??t.tghMax} / ${t.tghMax}`})) : null);
  box.append(h('div',{class:'vitals'}, vital('HP','hp','hpMax','hp'), t.sanMax ? vital('Sanity','san','sanMax','san') : null, npcTough, h('div',{class:'vital'}, h('span',{class:'vl',text:'Init'}), h('b',{class:'num',text:signed(t.init||0)}), r.enc&&r.enc.active&&t.initRoll!=null ? h('span',{class:'dim',text:`ทอยได้ ${t.initRoll}`}) : null)));
  if (t.charId && t.kind==='pc') box.append(h('p',{class:'dim',style:'font-size:11px;margin:2px 0 0',text:'HP และ Sanity ซิงก์กับชีทของเจ้าของ ฝั่งที่แก้ล่าสุดเป็นค่าที่ใช้'}));
  // สถานะ
  const condRow = h('div',{class:'row',style:'gap:6px;margin-top:6px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'สถานะ'}), condChips(t, r, gm) || h('span',{class:'dim',style:'font-size:12px',text:'ไม่มี'}), gm ? h('button',{class:'small ghost',onclick:()=>condModal(t, r),text:'+ สถานะ'}) : null);
  box.append(condRow);
  // ปุ่มควบคุม
  if (mine){
    const ctl = h('div',{class:'row',style:'gap:4px;margin-top:8px'});
    if (t.charId && (gm || t.ownerId===Store.me || Store.isDevUid)) ctl.append(h('button',{class:'small',onclick:()=>{ location.hash='#sheet-'+t.charId; },text:'📜 ชีท'}));
    ctl.append(h('button',{class:'small ghost'+(t.torch?' on':''),title:'ถือแหล่งแสง (คบเพลิง ตะเกียง) ส่องรอบตัว 4 ช่องในที่มืด',onclick:()=>{ t.torch=!t.torch; Table.save(); if (!t.hidden) Table.post({kind:'sys',who:'',text:`${t.name} ${t.torch?'จุดแหล่งแสง':'ดับแหล่งแสง'}`}); },text:'🔥 แสง'}));
    if (gm) ctl.append(h('button',{class:'small ghost'+(t.nv?' on':''),title:'มองเห็นในความมืด (Dark Vision)',onclick:()=>{ t.nv=!t.nv; Table.save(); },text:'👁 Dark Vision'}));
    if (gm) ctl.append(h('button',{class:'small ghost'+(t.aquatic?' on':''),title:'สัตว์น้ำ/เงือก: อยู่ในน้ำลึกแล้วยังโจมตีได้และไม่เสียเทิร์น',onclick:()=>{ t.aquatic=!t.aquatic; Table.save(); },text:'🐟 สัตว์น้ำ'}));
    if (gm && t.charId) ctl.append(h('button',{class:'small ghost',title:'ใส่ไอเทมลงกระเป๋าของตัวละครนี้',onclick:()=>giveItemModal(t, r),text:'🎁 ไอเทม'}));
    if (gm) ctl.append(h('button',{class:'small ghost',title:t.hidden?'เปิดเผยให้ผู้เล่นเห็น':'ซ่อนจากผู้เล่น',onclick:()=>{t.hidden=!t.hidden; Table.save(); if(!t.hidden) Table.post({kind:'sys',who:'',text:`${t.name} ปรากฏตัวที่ (${t.x},${t.y})`});},text:t.hidden?'👁 เปิดเผย':'🙈 ซ่อน'}));
    ctl.append(h('button',{class:'small ghost',style:'margin-left:auto',title: gm ? 'เอาออกจากบอร์ด (ลบสำเนาชีทในห้องด้วย)' : 'ถอนตัวละครออกจากบอร์ด (GM จะไม่เห็นชีทอีก)',onclick:()=>{ if (!confirm(`เอา ${t.name} ออกจากบอร์ด?`)) return; detachToken(r, t); r.tokens=r.tokens.filter(x=>x!==t); r.enc.order=(r.enc.order||[]).filter(x=>x!==t.id); if (Table.sel===t.id) Table.sel=null; dropTokenCopy(r, t); Table.save(); },text:'✕ เอาออก'}));
    box.append(ctl);
  }
  // คำอธิบาย (ผู้เล่นเห็น) และบันทึก GM (ลับ)
  if (gm){
    const desc = h('textarea',{placeholder:'คำอธิบายหมากนี้ที่ผู้เล่นเห็น (รูปร่าง ท่าทาง สิ่งที่สังเกตได้)',style:'min-height:48px;font-size:12.5px'}); desc.value = t.desc||''; desc.onblur = ()=>{ if (desc.value !== (t.desc||'')){ t.desc = desc.value; Table.save(); } };
    const note = h('textarea',{placeholder:'บันทึกลับของ GM (สแตต แผนการ จุดอ่อน) ผู้เล่นไม่เห็น',style:'min-height:48px;font-size:12.5px'}); note.value = t.note||''; note.onblur = ()=>{ if (note.value !== (t.note||'')){ t.note = note.value; Table.save(); } };
    box.append(h('div',{style:'margin-top:8px'}, h('div',{class:'kicker',text:'คำอธิบาย (ผู้เล่นเห็น)'}), desc), h('div',{style:'margin-top:6px'}, h('div',{class:'kicker',text:'บันทึก GM (ลับ)'}), note));
  } else if (t.desc) box.append(h('p',{class:'desc',style:'margin:8px 0 0;font-size:13px',text:t.desc}));
  // แผงต่อสู้ของตัวละคร
  if (t.charId){ const c = Store.get(t.charId); if (c && (Store.isMine(c) || gm || Store.isDevUid)) box.append(combatPanel(c, t, gm)); }
  return box;
}
/* ค่าที่ผู้เล่นต้องใช้ตอนสู้: อาวุธ + Might เอฟเฟกต์ Toughness เกราะ สกิลและ Trait ที่เกี่ยวกับการต่อสู้ (ผู้ใช้เคาะ 9 พ.ย. 2026) */
const COMBAT_RX = /Attack|Parry|Evade|Damage|\bCV\b|Might|Sight|Defend|โจมตี|ป้องกัน|Reaction|Swift|Toughness|Armor|เกราะ|Cover|Perfect|Initiative|Reflex|Unbalanced|Guard Break|PDMG|หลบ|Melee|Range|ประชิด|ระยะไกล|Grab|Stance|กระบวนท่า/;
function combatPanel(c, t, gm){
  const box = h('div',{class:'combat-panel'});
  const min = c.shareMode==='min' && !Store.isMine(c);
  let d = null; try { d = compute(c); } catch(e){}
  if (Store.isMine(c) && d) { ensureSheetState(c, d); d = compute(c); }
  const cur = c.current || {};
  box.append(h('div',{class:'kicker',style:'margin-top:10px',text:'ค่าสำหรับการต่อสู้'}));
  if (d) box.append(h('div',{class:'gives'}, tag(`Might ${signed(d.might)}`,'stat sc sc-STR'), tag(`Sight ${signed(d.sight)}`,'stat sc sc-PER'), tag(`Reflex ${signed(d.reflex)}`,'stat sc sc-AGI'), tag(`Parry Dice ${d.parryDice}`,'stat sc sc-VIT'), tag(`Initiative ${signed(d.initiative)}`,'stat sc sc-PER'), tag(`Passive PER ${d.passivePer}`,'stat sc sc-PER')));
  // อาวุธ
  if (!min){ const eq = c.equip||{}; const ws = (typeof WEAPON_SLOTS!=='undefined' ? WEAPON_SLOTS : ['weapon1','weapon2','shield']).map(k=>[k, eq[k]]).filter(([k,e])=>e && (e.name||'').trim());
    const wbox = h('div',{class:'cp-sec'}, h('b',{text:'สายคาดอาวุธ'}));
    if (!ws.length) wbox.append(h('div',{class:'dim',style:'font-size:12px',text:'ยังไม่ได้สวมอาวุธ (สวมได้ในถุงย่ามที่ชีท)'}));
    for (const [k,e] of ws){ const eff = String(e.effect||''); const dmg = (eff.match(/(\d+)\s*PDMG/)||[])[1]; const pd = (eff.match(/\+(\d+)\s*Parry Dice/)||[])[1];
      wbox.append(h('div',{class:'cp-w'}, h('div',null, h('span',{class:'dim',style:'font-size:11px',text:(k==='shield'?'โล่/มือรอง':k==='weapon1'?'อาวุธหลัก':'อาวุธรอง')+' '}), h('b',{class:hueCls(e.name, eff).trim(),text:e.name.replace(/\s*\(.*?\)\s*/g,' ').trim()}), dmg && d ? h('span',{class:'num',style:'margin-left:6px',text:` ${dmg} PDMG + Might ${signed(d.might)} = ${+dmg + d.might}`}) : null, pd ? h('span',{class:'num dim',style:'margin-left:6px',text:` +${pd} Parry Dice`}) : null),
        eff ? h('details',null, h('summary',{text:'เอฟเฟกต์'}), h('div',{class:'desc',style:'font-size:12px'}, T(eff))) : null)); }
    box.append(wbox); }
  // Toughness + เกราะ
  const tb = h('table',{class:'t cp-t'}, h('thead',null, h('tr',null, h('th',{text:'อวัยวะ'}), h('th',{text:'Toughness'}), h('th',{text:'เกราะ A/B'}))));
  // Toughness ต่ออวัยวะ: เจ้าของหรือ GM กด ± ได้จากโต๊ะ (ผู้ใช้เคาะ 9 พ.ย. 2026) ค่าอยู่บนหมาก (t.tough) แล้วซิงก์เข้าชีทเหมือน HP/Sanity
  const mine = gm || t.ownerId===Store.me || Table.localMode; const tmax = d ? d.toughness : null;
  const tval = (k)=>{ const v = (t.tough||{})[k]; if (v!=null) return v; const cv = (cur.tough||{})[k]; if (cv!=null) return cv; return tmax; };
  const setT = (k, v)=>{ if (!t.tough) t.tough = {}; for (const [kk] of DATA.meta.bodyParts) if (t.tough[kk]==null){ const cv = tval(kk); if (cv!=null) t.tough[kk] = cv; } t.tough[k] = Math.max(0, tmax!=null ? Math.min(tmax, v) : v); t.vitalsAt = Date.now(); Table.save(); };
  for (const [k,label] of DATA.meta.bodyParts){ const v = tval(k);
    tb.append(h('tr',null, h('td',{text:label}), h('td',{class:'num'+((v??1) <= 0 ? ' bad' : '')}, mine && v!=null ? h('button',{class:'small tadj',title:label+' Toughness −1',onclick:()=>setT(k, v-1)},'−') : null, h('span',{text: v==null ? '-' : (tmax!=null ? `${v}/${tmax}` : String(v))}), mine && v!=null ? h('button',{class:'small tadj',title:label+' Toughness +1',onclick:()=>setT(k, v+1)},'+') : null), h('td',{class:'num',text:(c.armor||{})[k]||'-'}))); }
  box.append(h('div',{class:'cp-sec'}, h('b',{text:'Toughness และเกราะ'}), h('div',{class:'tablewrap'}, tb), mine ? h('p',{class:'dim',style:'font-size:11px;margin:4px 0 0',text:'Toughness ที่แก้ตรงนี้ซิงก์เข้าชีทของเจ้าของเหมือน HP และ Sanity'}) : null));
  if (min){ box.append(h('p',{class:'dim',style:'font-size:11.5px',text:'เจ้าของแชร์เฉพาะค่าหลัก อาวุธ สกิล และ Trait ไม่เปิดเผย'})); return box; }
  // สกิลและ Trait ที่เกี่ยวกับการต่อสู้
  const kin = c.kin ? KIN[c.kin] : null;
  const skills = (typeof allSkills==='function' ? allSkills(c) : (c.skills||[])).map(n=>SKILL_BY_NAME[n]).filter(sk=>sk && COMBAT_RX.test((sk.type||'')+' '+(sk.effect||'')));
  const traits = []; if (kin){ for (const x of [...(kin.traits||[]), ...(kin.benefits||[])]) if (COMBAT_RX.test(x.text||'')) traits.push({name:`${x.name} (${x.nameEn||''})`, text:x.text, cls:'ok'}); for (const x of kin.hindrances||[]) if (COMBAT_RX.test(x.text||'')) traits.push({name:`${x.name} (${x.nameEn||''})`, text:x.text, cls:'neg'}); for (const code of [c.childhood, c.adulthood]){ const b = findBg(kin, code); if (b && b.text && COMBAT_RX.test(b.text)) traits.push({name:b.name, text:b.text, cls:'prop'}); } }
  const sbox = h('div',{class:'cp-sec'}, h('b',{text:`สกิลที่ใช้ในการต่อสู้ (${skills.length})`}));
  for (const sk of skills) sbox.append(h('details',{class:'cp-d'}, h('summary',null, h('span',{class:hueCls(sk.nameEn, sk.type, sk.effect).trim(),text:sk.nameEn}), h('span',{class:'dim',style:'font-size:11px',text:` ${sk.type? sk.type.slice(0,30) : ''}${sk.cost? ' · '+sk.cost : ''}`})), h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect||''))));
  if (!skills.length) sbox.append(h('div',{class:'dim',style:'font-size:12px',text:'ไม่มี'}));
  const tbox = h('div',{class:'cp-sec'}, h('b',{text:`Trait ที่เกี่ยวกับการต่อสู้ (${traits.length})`}));
  for (const tr of traits) tbox.append(h('details',{class:'cp-d'}, h('summary',null, h('span',{class:hueCls(tr.name, tr.text).trim(),text:tr.name})), h('div',{class:'desc',style:'font-size:12px'}, T(tr.text))));
  if (!traits.length) tbox.append(h('div',{class:'dim',style:'font-size:12px',text:'ไม่มี'}));
  box.append(sbox, tbox);
  return box;
}
/* ---- ซิงก์ HP/Sanity ระหว่างหมากกับชีท: ฝั่งที่แก้ล่าสุดชนะ (token.vitalsAt เทียบ c.current.at) ---- */
function tokenVitals(t, key, value){ t[key] = value; t.vitalsAt = Date.now(); }
function toughEq(a, b){ a = a||{}; b = b||{}; for (const [k] of DATA.meta.bodyParts) if ((a[k]??null) !== (b[k]??null)) return false; return true; }
function syncVitalsWithSheets(r){
  let roomChanged = false;
  for (const t of r.tokens||[]){ if (!t.charId || t.kind!=='pc') continue; const c = Store.chars.find(x=>x.id===t.charId && Store.isMine(x)); if (!c || !c.current) continue; const cur = c.current; const ta = t.vitalsAt||0, ca = cur.at||0;
    const same = t.hp === cur.hp && t.san === cur.sanity && t.tough && toughEq(t.tough, cur.tough);
    if (same) continue;
    if (ta > ca){ cur.hp = t.hp; cur.sanity = t.san; if (t.tough) cur.tough = Object.assign({}, cur.tough||{}, t.tough); else { t.tough = Object.assign({}, cur.tough||{}); roomChanged = true; } cur.at = ta; Store.upsert(c); if (location.hash==='#sheet-'+c.id) renderSheet(c.id); }
    else { t.hp = cur.hp; t.san = cur.sanity; t.tough = Object.assign({}, cur.tough||{}); t.vitalsAt = ca || Date.now(); roomChanged = true; } }
  return roomChanged;
}
function pushVitalsFromSheet(c){ const r = Table.room; if (!r) return; const t = (r.tokens||[]).find(x=>x.charId===c.id); if (!t) return; const cur = c.current||{}; if (t.hp===cur.hp && t.san===cur.sanity && t.tough && toughEq(t.tough, cur.tough)) return; t.hp = cur.hp; t.san = cur.sanity; t.tough = Object.assign({}, cur.tough||{}); t.vitalsAt = cur.at||Date.now(); Table.save(); }
/* ---- น้ำลึก: ว่ายได้ ลงไปแล้วเสียเทิร์น และประกาศโจมตีไม่ได้ เว้นสัตว์น้ำ (ผู้ใช้เคาะ 9 พ.ย. 2026) ---- */
Table.attackBlocked = function(c){ const r = this.room; if (!r || !c) return null; const t = (r.tokens||[]).find(x=>x.charId===c.id); if (!t) return null; if (t.inWater && !t.aquatic) return `${t.name} อยู่ในน้ำลึก ประกาศโจมตีไม่ได้จนกว่าจะขึ้นฝั่ง`; if (t.inside) return `${t.name} ถูกกลืนอยู่ โจมตีได้เฉพาะจากข้างใน (GM ตัดสิน)`; return null; };
/* ---- เคลื่อนหมาก (ลากวาง): ตรวจพื้น ข้อห้ามจากสถานะ หมากซ้อน น้ำลึก แล้วบันทึก ---- */
function tryMoveToken(r, t, x, y, gm, fogged){
  const tile = TILE[mapCell(r.map,x,y)]||TILE['.'];
  if (!tile.pass){ toast('ผ่านช่องนี้ไม่ได้ ('+tile.th+')'); return false; }
  const block = moveBlocked(r, t, {x,y}); if (block){ if (!gm || t.inside){ toast(block); return false; } toast('GM ย้ายข้ามข้อห้าม: '+block); }
  if (r.tokens.some(o=>o!==t && !o.inside && o.x===x && o.y===y)){ toast(fogged ? 'มีอะไรบางอย่างอยู่ตรงนั้นในความมืด เดินเข้าไปไม่ได้' : 'มีหมากอยู่ตรงนั้นแล้ว'); return false; }
  const dist = cellDist(t,{x,y}); const wasWater = !!t.inWater; t.x=x; t.y=y; t.inWater = !!tile.swim; syncDevoured(r, t); Table.save();
  if (!t.hidden){ Table.post({kind:'sys',who:'',text:`${t.name} เคลื่อนที่ ${dist} ช่อง ไป (${x},${y})${tile.pass===2?' ('+tile.th+')':''}${tile.swim? ' ลงน้ำลึก' : (wasWater ? ' ขึ้นจากน้ำ' : '')}`}); if (tile.swim && !wasWater && !t.aquatic) Table.post({kind:'sys',who:'',text:`${t.name} ว่ายอยู่ในน้ำลึก: เสียเทิร์นนี้ไปกับการว่าย และประกาศโจมตีไม่ได้จนกว่าจะขึ้นฝั่ง`}); }
  return true;
}
function cellAtPoint(grid, cx, cy){ const el = document.elementFromPoint(cx, cy); const cell = el && el.closest ? el.closest('.cell') : null; return cell && grid.contains(cell) ? cell : null; }
/* ลากหมากด้วย pointer: ขยับเกิน 6px = ลาก (ปล่อยบนช่อง = ย้าย) · ปล่อยโดยไม่ขยับ = เลือกหมาก (โชว์โซนและระยะมองเห็น) */
function enableTokenDrag(tk, t, r, grid, gm, fogSet){
  tk.style.touchAction = 'none'; tk.classList.add('grab');
  tk.addEventListener('click', (e)=>e.stopPropagation());
  tk.addEventListener('pointerdown', (e)=>{
    if (e.button!==0) return; e.preventDefault(); e.stopPropagation();
    const pid = e.pointerId; const start = {x:e.clientX, y:e.clientY}; let ghost = null, moved = false, lastCell = null;
    try { tk.setPointerCapture(pid); } catch(x){}
    const onMove = (ev)=>{ if (ev.pointerId!==pid) return; const dx = ev.clientX-start.x, dy = ev.clientY-start.y; if (!moved && Math.hypot(dx,dy) < 6) return;
      if (!moved){ moved = true; const z = uiZoom(); const rct = tk.getBoundingClientRect(); ghost = tk.cloneNode(true); ghost.classList.add('ghost'); Object.assign(ghost.style, {position:'fixed', left:(rct.left/z)+'px', top:(rct.top/z)+'px', width:(rct.width/z)+'px', height:(rct.height/z)+'px', inset:'auto', zIndex:1000, pointerEvents:'none', opacity:.9, margin:0}); ghost.dataset.z = String(z); ghost.dataset.ox = String((rct.left - start.x)/z); ghost.dataset.oy = String((rct.top - start.y)/z); document.body.append(ghost); tk.classList.add('lifting'); }
      { const z = parseFloat(ghost.dataset.z)||1; ghost.style.left = (ev.clientX/z + parseFloat(ghost.dataset.ox))+'px'; ghost.style.top = (ev.clientY/z + parseFloat(ghost.dataset.oy))+'px'; }
      const cell = cellAtPoint(grid, ev.clientX, ev.clientY); if (cell !== lastCell){ if (lastCell) lastCell.classList.remove('drop'); if (cell) cell.classList.add('drop'); lastCell = cell; } };
    const onUp = (ev)=>{ if (ev.pointerId!==pid) return; tk.removeEventListener('pointermove', onMove); tk.removeEventListener('pointerup', onUp); tk.removeEventListener('pointercancel', onUp); try { tk.releasePointerCapture(pid); } catch(x){} if (ghost) ghost.remove(); tk.classList.remove('lifting'); if (lastCell) lastCell.classList.remove('drop');
      if (!moved || ev.type==='pointercancel'){ if (!moved) selectToken(t, r, gm); return; }
      const cell = cellAtPoint(grid, ev.clientX, ev.clientY); if (!cell) return; const x = +cell.dataset.x, y = +cell.dataset.y; if (x===t.x && y===t.y) return;
      tryMoveToken(r, t, x, y, gm, !!(fogSet && !fogSet.has(x+','+y))); };
    tk.addEventListener('pointermove', onMove); tk.addEventListener('pointerup', onUp); tk.addEventListener('pointercancel', onUp);
  });
}
function selectToken(t, r, gm){
  const selTok = Table.sel ? r.tokens.find(x=>x.id===Table.sel) : null;
  if (Table.sel===t.id) Table.sel = null;
  else if (selTok && selTok.id!==t.id){ const dist = cellDist(selTok,t); const band = rangeBand(dist); toast(`${selTok.name} → ${t.name}: ${dist} ช่อง (~${band.m} ม.) ${band.label}`); Table.sel = t.id; }
  else Table.sel = t.id;
  renderTable();
}
function mapPanel(r, gm){
  const wrap = h('div',{class:'mapwrap'});
  const map = r.map;
  // แถบควบคุมแผนที่ (GM)
  if (gm){
    const kindSel = h('select',null, MAP_KINDS.map(([k,l])=>h('option',{value:k,selected:k===map.kind,text:l})));
    const reseat = ()=>{ for (const t of r.tokens){ if (t.inside) continue; const pos = freeCell(r.map, r.tokens.filter(x=>x!==t), t.kind==='npc'?[0,1,2,3]:[16,17,18,19]); t.x=pos.x; t.y=pos.y; t.inWater=false; syncDevoured(r, t); } };
    const ctl = h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px',text:'สถานที่'}), kindSel,
      h('button',{class:'small primary',onclick:()=>{ r.map = generateMap(kindSel.value, uid()); Table.sel=null; reseat(); Table.save(); Table.post({kind:'sys',who:'GM',text:`เปลี่ยนฉากต่อสู้เป็น ${MAP_KINDS.find(x=>x[0]===kindSel.value)[1]}`}); },text:'สุ่มแผนที่ใหม่'}),
      h('button',{class:'small',onclick:()=>{ r.map = generateMap(map.kind, uid()); reseat(); Table.save(); },text:'สุ่มใหม่ (สถานที่เดิม)'}));
    const brushSel = h('select',{title:'พู่กัน: เลือกชนิดพื้นแล้วคลิกช่องเพื่อแก้แผนที่'}, h('option',{value:'',text:'พู่กัน: ปิด'}), Object.entries(TILE).map(([k,v])=>h('option',{value:k,selected:Table.brush===k,text:`${v.th}`})));
    brushSel.onchange = ()=>{ Table.brush = brushSel.value||null; Table.sel=null; renderTable(); };
    ctl.append(brushSel, h('button',{class:'small ghost',onclick:()=>{ if(!confirm('เอาหมากทุกตัวออกจากบอร์ด? (สำเนาชีทในห้องจะถูกลบด้วย)')) return; for (const t of r.tokens) dropTokenCopy(r, t); r.tokens=[]; r.enc={active:false,round:0,turnIdx:0,order:[]}; Table.save(); },text:'ล้างหมาก'}));
    wrap.append(ctl);
    const lightSel = h('select',{title:'ระดับแสงของฉาก มีผลต่อระยะที่ผู้เล่นมองเห็นบนบอร์ด'}, LIGHTS.map(([k,l])=>h('option',{value:k,selected:k===(r.light||'low'),text:l})));
    lightSel.onchange = ()=>{ r.light = lightSel.value; Table.save(); Table.post({kind:'sys',who:'GM',text:`แสงในฉากเปลี่ยนเป็น ${lightLabel(r.light)}`}); };
    wrap.append(h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px',text:'💡 แสง'}), lightSel, h('span',{class:'dim',style:'font-size:11.5px;flex:1;min-width:160px',text:LIGHT_NOTE[r.light||'low']||''}),
      h('button',{class:'small ghost',title:'โหลดแผนที่ที่เตรียมไว้จากคลังแผนที่ของคุณ',onclick:()=>openMapLibraryPicker(r),text:'📚 คลังแผนที่'}),
      h('button',{class:'small ghost',title:'เก็บแผนที่ของห้องนี้ (พื้น แสง และ NPC) เข้าคลังแผนที่ส่วนตัว',onclick:()=>saveRoomMapToLibrary(r),text:'💾 เก็บเข้าคลัง'}),
      map.image ? h('button',{class:'small ghost'+(map.image.hidden?'':' on'),title:'ซ่อน/แสดงภาพประกอบแผนที่',onclick:()=>{ map.image.hidden = !map.image.hidden; Table.save(); },text:'🖼 ภาพ'}) : null));
  } else wrap.append(h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px'}, 'สถานที่: ', h('b',{text:(MAP_KINDS.find(x=>x[0]===map.kind)||['','?'])[1]}), ' · 💡 ', h('b',{text:lightLabel(r.light||'low')})), h('span',{class:'dim',style:'font-size:11.5px',text:LIGHT_NOTE[r.light||'low']||''})));
  const light = r.light||'low';
  const vis = gm ? null : computeVisibility(r, Store.me); // null = เห็นทั้งบอร์ด
  const gridwrap = h('div',{class:'gridwrap'});
  const grid = h('div',{class:'gridmap'+(Table.brush?' painting':'')+(light==='dark'||light==='abyss'?' dark-scene':'')+(light==='dim'?' dim-scene':'')});
  if (!gm && light==='dark' && vis){ const mine = r.tokens.filter(t=>t.ownerId===Store.me && !t.inside); if (mine.length && mine.every(t=>t.nv)) grid.classList.add('nightvision'); }
  const selTok = Table.sel ? r.tokens.find(t=>t.id===Table.sel) : null;
  const canSee = (t)=> (gm || !t.hidden || t.ownerId===Store.me) && (!vis || t.ownerId===Store.me || vis.has(t.x+','+t.y));
  const visible = (t)=> canSee(t) && !t.inside;
  const byPos = {}; for (const t of r.tokens) if (visible(t)) byPos[t.x+','+t.y] = t;
  const cur = r.enc.active ? r.enc.order[r.enc.turnIdx] : null;
  const sight = selTok && !selTok.inside && (gm || selTok.ownerId===Store.me) ? tokenSight(r, selTok) : null; // ระยะมองเห็นของหมากที่เลือก
  for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){
    const ch = mapCell(map,x,y); const tile = TILE[ch]||TILE['.'];
    const fog = !!(vis && !vis.has(x+','+y));
    const cell = h('div',{class:'cell t-'+(ch.replace(/[^A-Za-z]/g, m=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[m]||'ground')))+(fog?' fog':''),title: fog ? `(${x},${y}) มองไม่เห็น` : `(${x},${y}) ${tile.th}`,dataset:{x,y}});
    if (selTok && !(selTok.x===x && selTok.y===y)){ const dist = cellDist(selTok,{x,y}); const band = rangeBand(dist); cell.classList.add('rng-'+band.id); if (sight && !fog && !sight.has(x+','+y)) cell.classList.add('nosight'); }
    cell.onclick = ()=>{
      if (Table.brush && gm){ setMapCell(r.map, x, y, Table.brush); Table.save(); return; }
      if (byPos[x+','+y]) return; // หมากจัดการคลิกเอง (เลือก/ลาก)
      if (Table.sel){ Table.sel = null; renderTable(); }
    };
    const t = byPos[x+','+y];
    if (t){ const conds = (t.conds||[]); const inside = r.tokens.filter(o=>o.inside===t.id && canSee(o));
      const tk = h('div',{class:`gtok ${t.kind}${t.hidden?' hid':''}${cur===t.id?' turn':''}${Table.sel===t.id?' sel':''}${t.hp<=0?' down':''}${t.torch?' torch':''}${t.inWater?' water':''}` + conds.map(c=>' c-'+condClass(c.id)).join(''),title:`${t.name} HP ${t.hp}/${t.hpMax}` + (conds.length ? ' · ' + conds.map(c=>condLabel(c, r)).join(', ') : '') + (inside.length ? ' · ในท้อง: '+inside.map(o=>o.name).join(', ') : '') + (t.inWater ? ' · ในน้ำลึก' : '') + ((gm || t.ownerId===Store.me) ? ' · ลากเพื่อย้าย คลิกเพื่อดูโซนและระยะมองเห็น' : '')});
      if (t.thumb) tk.append(h('img',{src:t.thumb,alt:t.name,draggable:'false'})); else tk.append(h('span',{class:'ini',text:(t.name||'?').slice(0,2)}));
      const pct = t.hpMax? Math.max(0,Math.min(100,t.hp/t.hpMax*100)) : 0; tk.append(h('i',{class:'hpbar',style:`--p:${pct}%`}));
      if (conds.length) tk.append(h('div',{class:'cbadges'}, conds.slice(0,3).map(c=>h('span',{text:condIcon(c.id)+(COND_STACK.has(c.id)? (c.lv||1) : '')}))));
      if (inside.length) tk.append(h('span',{class:'devbadge',text:'🦷'+inside.length}));
      if (t.torch) tk.append(h('span',{class:'torchbadge',text:'🔥'}));
      if (r.enc.active && t.initRoll!=null) tk.append(h('span',{class:'initbadge num',title:'ลำดับ Initiative',text:String(t.initRoll)}));
      if (gm || t.ownerId===Store.me) enableTokenDrag(tk, t, r, grid, gm, vis); else tk.addEventListener('click', (e)=>{ e.stopPropagation(); selectToken(t, r, gm); });
      cell.append(tk); }
    grid.append(cell);
  }
  gridwrap.append(grid);
  if (map.image && map.image.data && !map.image.hidden) gridwrap.append(mapImageOverlay(map.image, null));
  wrap.append(gridwrap);
  // ตำนานพื้นที่ปรากฏ
  const used = [...new Set(map.cells.split(''))].filter(k=>TILE[k]);
  wrap.append(h('div',{class:'legend'}, used.map(k=>h('span',{class:'lg'}, h('i',{class:'sw t-'+(k.replace(/[^A-Za-z]/g, m=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[m]||'ground')))}), TILE[k].th)), selTok ? h('span',{class:'lg dim',text:'· แดง = เขตปะทะ · ทอง = ใกล้เคียง · ช่องมืดลง = พ้นระยะมองเห็นของหมากที่เลือก'}) : null));
  if (vis && !gm) wrap.append(h('p',{class:'dim',style:'font-size:12px;margin:6px 0 0',text:`💡 ${lightLabel(light)}: ช่องมืดคือส่วนที่หมากของคุณมองไม่เห็น (กำแพง หิน บ้าน ต้นไม้ และเสา บังสายตา) ${light==='abyss' ? 'เห็นได้แค่ช่องติดตัว' : light==='dark' ? 'ถ้าไม่มี Dark Vision เห็นแค่ช่องติดตัว แหล่งแสง 🔥 ส่องรอบตัว 4 ช่อง' : light==='dim' ? 'เห็นได้ 12 ช่อง (25 ม.) ถ้าไม่มี Dark Vision' : ''}`}));
  return wrap;
}
/* ภาพประกอบบนแผนที่ (PNG ที่เจ้าของคลังใส่ไว้) วางทับกริดตามตำแหน่งหน่วยช่อง · onEdit = โหมดลาก/ย่อขยาย (ตัวแก้ไขแผนที่) */
function mapImageOverlay(img, onEdit){
  const el = h('div',{class:'mapimg'+(onEdit?' editable':'')});
  const place = ()=>{ el.style.left = (img.x/MAP_W*100)+'%'; el.style.top = (img.y/MAP_H*100)+'%'; el.style.width = (img.w/MAP_W*100)+'%'; el.style.height = (img.h/MAP_H*100)+'%'; el.style.opacity = img.opacity==null ? .9 : img.opacity; };
  el.style.backgroundImage = `url(${img.data})`; place();
  if (onEdit){
    const handle = h('div',{class:'mapimg-handle',title:'ลากเพื่อย่อขยาย'}); el.append(handle);
    const parentRect = ()=> el.parentElement.getBoundingClientRect();
    el.addEventListener('pointerdown', (e)=>{ if (e.button!==0 || e.target===handle) return; e.preventDefault(); e.stopPropagation(); const pr = parentRect(); const sx = e.clientX, sy = e.clientY, ox = img.x, oy = img.y; const pid = e.pointerId; el.setPointerCapture(pid);
      const mv = (ev)=>{ if (ev.pointerId!==pid) return; img.x = Math.round((ox + (ev.clientX-sx)/pr.width*MAP_W)*4)/4; img.y = Math.round((oy + (ev.clientY-sy)/pr.height*MAP_H)*4)/4; place(); };
      const up = (ev)=>{ if (ev.pointerId!==pid) return; el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); try{ el.releasePointerCapture(pid);}catch(x){} onEdit(); };
      el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up); });
    handle.addEventListener('pointerdown', (e)=>{ if (e.button!==0) return; e.preventDefault(); e.stopPropagation(); const pr = parentRect(); const sx = e.clientX, sy = e.clientY, ow = img.w, oh = img.h; const ratio = oh/ow; const pid = e.pointerId; handle.setPointerCapture(pid);
      const mv = (ev)=>{ if (ev.pointerId!==pid) return; const nw = Math.max(1, ow + (ev.clientX-sx)/pr.width*MAP_W); img.w = Math.round(nw*4)/4; img.h = ev.shiftKey ? Math.max(1, Math.round((oh + (ev.clientY-sy)/pr.height*MAP_H)*4)/4) : Math.round(img.w*ratio*4)/4; place(); };
      const up = (ev)=>{ if (ev.pointerId!==pid) return; handle.removeEventListener('pointermove', mv); handle.removeEventListener('pointerup', up); try{ handle.releasePointerCapture(pid);}catch(x){} onEdit(); };
      handle.addEventListener('pointermove', mv); handle.addEventListener('pointerup', up); });
  }
  return el;
}
function rollInitiative(r){
  const lines=[];
  for (const t of r.tokens){ const rr = roll2d6(); t.initRoll = rr.sum + (t.init||0); lines.push(`${t.hidden?'(ซ่อน) ':''}${t.name}: ${rr.kept[0]}+${rr.kept[1]} ${signed(t.init||0)} = ${t.initRoll}`); }
  r.enc.order = r.tokens.filter(t=>t.initRoll!=null).sort((a,b)=>b.initRoll-a.initRoll).map(t=>t.id);
  r.enc.active = true; r.enc.round = 1; r.enc.turnIdx = 0;
  Table.save();
  Table.post({kind:'sys',who:'GM',text:'เริ่มการต่อสู้ ทอย Initiative: '+lines.filter(l=>!l.startsWith('(ซ่อน)')).join(' · ')});
  if (lines.some(l=>l.startsWith('(ซ่อน)'))) Table.post({kind:'sys',who:'GM',text:'ฝั่งที่ซ่อน: '+lines.filter(l=>l.startsWith('(ซ่อน)')).join(' · '),gmOnly:true});
}
function clockEl(cl, r, gm){
  const size=72, cx=36, cy=36, R=30;
  const svg = document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('width',size); svg.setAttribute('height',size); svg.setAttribute('viewBox',`0 0 ${size} ${size}`);
  for (let i=0;i<cl.seg;i++){ const a0 = -Math.PI/2 + i*2*Math.PI/cl.seg, a1 = a0 + 2*Math.PI/cl.seg; const p = document.createElementNS('http://www.w3.org/2000/svg','path'); const x0=cx+R*Math.cos(a0), y0=cy+R*Math.sin(a0), x1=cx+R*Math.cos(a1), y1=cy+R*Math.sin(a1); p.setAttribute('d',`M${cx},${cy} L${x0},${y0} A${R},${R} 0 0 1 ${x1},${y1} Z`); p.setAttribute('fill', i<cl.fill? 'var(--blood)':'var(--ink)'); p.setAttribute('stroke','var(--line-2)'); p.setAttribute('stroke-width','1'); if (gm){ p.style.cursor='pointer'; p.addEventListener('click',()=>{ cl.fill = (i<cl.fill)? i : i+1; Table.save(); }); } svg.append(p); }
  return h('div',{class:'clock',style:'text-align:center;font-size:12px'}, svg, h('div',{text:`${cl.name} ${cl.fill}/${cl.seg}`}), gm? h('button',{class:'small ghost',onclick:()=>{ r.clocks=r.clocks.filter(x=>x.id!==cl.id); Table.save(); },text:'ลบ'}):null);
}
function handleChatInput(txt, name, c, gm){
  let gmOnly=false, mode='normal', rest=txt;
  const toks = rest.split(/\s+/);
  while (toks.length && toks[0].startsWith('/')){
    const cmd = toks.shift().toLowerCase();
    if (cmd==='/gm' || cmd==='/gmr') gmOnly=true; else if (cmd==='/adv') mode='adv'; else if (cmd==='/dis') mode='dis'; else if (cmd==='/r' || cmd==='/roll'){ const expr = toks.join(' ') || '2d6'; const m = expr.match(/^(\d*)d6\s*([+-]\s*\d+)?\s*(.*)$/i); let mod = 0, label = expr; if (m){ mod = m[2]? parseInt(m[2].replace(/\s/g,''),10):0; label = (m[3]||'').trim() || expr; if (m[1] && +m[1]===3) mode = mode==='normal'?'adv':mode; } else { const n = parseInt(expr,10); if (!isNaN(n)) mod=n; }
      Table.guardedRoll(name, ()=>{ const e = doRoll({label, mod, c, mode}); e.who = name; Table.post({kind:'roll',who:name,text:e.label,roll:{dice:e.r.dice,kept:e.r.kept,keptIdx:e.r.keptIdx,sum:e.r.sum,crit:e.r.crit,double:e.r.double,mode:e.mode},mod:e.mod,pm:0,total:e.total,judge:e.judge,dc:null,gmOnly}); }, label); return; }
    else { toks.unshift(cmd); break; }
  }
  rest = toks.join(' ');
  if (!rest) return;
  Table.post({kind:'say', who:name, text:rest, gmOnly});
}
function renderChatOnly(){
  const log = document.getElementById('chatlog'); if (!log) return; clear(log);
  const gm = Table.isGM();
  const items = Table.chat.filter(m => !m.gmOnly || gm || m.authorId===Store.me);
  if (!items.length) log.append(h('div',{class:'dim',text:'ยังไม่มีข้อความ'}));
  for (const m of items){
    const time = new Date(m.ts||0).toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'});
    if (m.kind==='roll' && m.roll){
      const r = {dice:m.roll.dice||[], kept:m.roll.kept||[], keptIdx:m.roll.keptIdx||[], sum:m.roll.sum, crit:m.roll.crit, double:m.roll.double, mode:m.roll.mode||'normal'};
      log.append(h('div',{class:'e'}, h('div',{class:'row',style:'gap:6px'}, h('span',{class:'who',text:m.who||''}), h('b',{text:m.text||''}), r.mode!=='normal'? tag(r.mode==='adv'?'Advantage':'Disadvantage', r.mode==='adv'?'ok':'neg'):null, m.roll.chosen? tag('เลือกลูกเอง','prop'):null, m.dc!=null? tag('DC '+m.dc):null, m.gmOnly? h('span',{class:'gm',text:'ลับ'}):null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
        h('div',{class:'row',style:'gap:8px;margin-top:2px'}, renderDice(r), h('span',{class:'dim num',text:`${r.kept[0]}+${r.kept[1]}` + (m.mod? ` ${signed(m.mod)}`:'') + (m.pm? ` ${m.persSide} ${signed(m.pm)}`:'')}), h('b',{class:'num',text:'= '+m.total}), m.judge? h('span',{class:m.judge.cls||'',text:m.judge.text||''}):null)));
    } else if (m.kind==='sys') log.append(h('div',{class:'e dim',style:'font-size:12px'}, m.gmOnly? h('span',{class:'gm',text:'ลับ '}):null, h('span',{text:m.text||''}), h('span',{class:'dim',style:'font-size:11px;float:right',text:time})));
    else log.append(h('div',{class:'e'}, h('span',{class:'who',text:(m.who||'')+': '}), h('span',{text:m.text||''}), m.gmOnly? h('span',{class:'gm',text:' (ลับ)'}):null, h('span',{class:'dim',style:'font-size:11px;float:right',text:time})));
  }
}
function renderPeers(){ const p = document.getElementById('peers'); if (!p) return; const n = Table.peers.length; const names = Table.peers.map(x=>x.name||'').filter(Boolean); p.textContent = n ? `ออนไลน์ในห้อง ${n} คน${names.length? ': '+names.join(', ') : ''}` : ''; }
