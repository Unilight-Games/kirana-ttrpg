/* ===== Online table: rooms, 20×20 grid combat map, encounter order, shared chat & dice, fate clocks ===== */
function newRoom(name){ const id = uid(); return {id, name, gmId: Store.me||'local', gmName: Store.displayName||'', gmKey: uid().slice(0,6).toUpperCase(), hasKey:false, createdAt:Date.now(), updatedAt:Date.now(), map: generateMap('field', id), tokens:[], enc:{active:false, round:0, turnIdx:0, order:[]}, clocks:[], scene:''}; }
/* ห้องรุ่นเก่าที่ใช้โซน: สร้างแผนที่ให้ และวางหมากเดิมลงกริด (GM บันทึกครั้งถัดไปจึงติดถาวร) */
function migrateRoom(r){ if (!r) return r; if (!r.map){ r.map = generateMap('field', r.id); } if (!r.tokens) r.tokens = []; for (const t of r.tokens){ if (t.x==null || t.y==null){ const pos = freeCell(r.map, r.tokens, t.kind==='npc' ? [0,1,2,3] : [16,17,18,19]); t.x = pos.x; t.y = pos.y; } } delete r.zones; return r; }
function gmKeys(){ try { return JSON.parse(localStorage.getItem('kirana.gmkeys')||'{}'); } catch(e){ return {}; } }
function rememberGmKey(roomId, key){ const k = gmKeys(); k[roomId] = key; try { localStorage.setItem('kirana.gmkeys', JSON.stringify(k)); } catch(e){} }

const Table = {
  roomId:null, room:null, chat:[], unsub:[], peers:[], localMode:false, writing:false, pending:null, presence:null,
  rollLock:null, rolling:false, seenRolls:new Set(), chatReady:false,
  roomChars:[], sel:null, brush:null, hover:null, chatWho:null, diceWho:null,
  isGM(){ if (!this.room) return false; if (this.localMode || this.room.gmId===Store.me || Store.isOwner) return true; const k = gmKeys()[this.room.id]; return !!(k && this.room.gmKey && k===this.room.gmKey); },
  async open(id){
    this.close(); this.roomId = id; this.localMode = !Store.db;
    if (this.localMode){ const rooms = loadLocalRooms(); const lr = rooms.find(r=>r.id===id)||null; if (lr && lr.joinKey && !gmKeys()[id] && localStorage.getItem('kirana.joined.'+id)!==lr.joinKey){ const k = prompt('ห้องนี้ล็อกด้วยรหัส กรอกรหัสเข้าห้อง'); if (k!==lr.joinKey){ toast('รหัสไม่ถูกต้อง'); location.hash='#table'; return; } localStorage.setItem('kirana.joined.'+id, k); } this.room = migrateRoom(lr); this.chat = loadLocalChat(id); renderTable(); return; }
    // ห้องที่ล็อกด้วยรหัส: ดูล็อบบี้ก่อน ถ้ายังไม่เป็นสมาชิกให้กรอกรหัส
    try {
      const lb = docData(await Store.db.doc('lobby/'+id).get());
      if (lb && lb.hasKey && lb.gmId !== Store.me && !Store.isDevUid){
        const mem = await Store.db.doc(`rooms/${id}/members/${Store.me}`).get().catch(()=>null);
        if (!mem || !mem.exists){ this.room = null; renderTable(); const ok = await askRoomKey(id, lb); if (!ok){ location.hash = '#table'; return; } }
      }
    } catch(e){ console.warn('lobby', e); }
    if (this.roomId !== id) return;
    try {
      const u1 = Store.db.doc('rooms/'+id).onSnapshot(snap => { const d = docData(snap); if (d){ this.room = migrateRoom(d); renderTable(); } }, err=>{ console.warn(err); toast('อ่านห้องไม่ได้'); });
      const u4 = Store.db.collection('rooms/'+id+'/chars').onSnapshot(snap => { this.roomChars = snapDocs(snap).filter(Boolean); if (location.hash.startsWith('#sheet-')) { const sid = location.hash.slice(7); if (!Store.chars.some(c=>c.id===sid) && this.roomChars.some(c=>c.id===sid)) renderSheet(sid); } }, err=>console.warn('roomchars', err));
      this.unsub.push(u4);
      const u5 = Store.db.collection('rooms/'+id+'/gifts').onSnapshot(snap => { for (const g of snapDocs(snap).filter(Boolean)) applyGift(id, g); }, err=>console.warn('gifts', err));
      this.unsub.push(u5);
      let q = Store.db.collection('rooms/'+id+'/chat');
      try { q = q.orderBy('ts','desc').limit(120); } catch(e){}
      const u2 = q.onSnapshot(snap => { const docs = snapDocs(snap).filter(Boolean); docs.sort((a,b)=>(b.ts||0)-(a.ts||0)); this.chat = docs.slice(0,120); renderChatOnly(); this.detectNewRolls(); }, err=>console.warn('chat', err));
      const u3 = Store.db.doc('rooms/'+id+'/meta/roll').onSnapshot(snap => { this.rollLock = docData(snap); updateRollLockUI(); }, err=>console.warn('rolllock', err));
      this.unsub.push(u1,u2,u3);
    } catch(e){ console.warn(e); toast('เชื่อมต่อห้องไม่ได้'); }
    if (Store.room){ try { const r = await Store.room.join('kirana-'+id); this.presence = r; const me = Store.me||'guest'; r.presence({who: me, name: Store.displayName||'', at: Date.now()}); r.onPeers(p=>{ this.peers = Array.isArray(p)? p : Object.values(p||{}); renderPeers(); }); } catch(e){ console.warn('room', e); } }
    renderTable();
  },
  close(){ for (const u of this.unsub) try{ typeof u==='function' && u(); }catch(e){} this.unsub=[]; if (this.presence){ try{ this.presence.leave(); }catch(e){} this.presence=null; } this.roomId=null; this.room=null; this.chat=[]; this.peers=[]; this.roomChars=[]; this.sel=null; this.brush=null; this.chatWho=null; this.diceWho=null; this.rollLock=null; this.rolling=false; this.seenRolls=new Set(); this.chatReady=false; DiceShow.clear(); updateRollLockUI(); clearTwins(); },
  /* ---- ด่านล็อกการทอย: ทอยได้ทีละคน ระหว่างเต๋าเด้งอยู่บนจอทุกคน คนอื่นกดทอยไม่ได้ ---- */
  lockActive(lk){ lk = lk===undefined ? this.rollLock : lk; return !!(lk && lk.at && (Date.now() - lk.at) < ROLL_LOCK_TTL); },
  lockedByOther(){ return this.lockActive() && this.rollLock.by !== (Store.me||'local'); },
  async claimRollLock(who, label){
    const me = Store.me||'local'; const lock = {by: me, who, label: label||'', at: Date.now()};
    if (this.localMode) { this.rollLock = lock; return true; }
    try {
      if (FB){ // Firestore transaction: อ่าน-เช็ก-เขียนในรอบเดียว กันสองคนกดพร้อมกัน
        const ref = FB.F.doc(FB.fdb, `rooms/${this.roomId}/meta/roll`);
        return await FB.F.runTransaction(FB.fdb, async tx => { const sn = await tx.get(ref); const cur = sn.exists() ? sn.data() : null; if (this.lockActive(cur) && cur.by !== me) return false; tx.set(ref, lock); return true; });
      }
      const ref = Store.db.doc(`rooms/${this.roomId}/meta/roll`); const sn = await ref.get(); const cur = docData(sn); if (this.lockActive(cur) && cur.by !== me) return false; await ref.set(lock); return true;
    } catch(e){ console.warn('claim lock', e); return true; } // ล็อกล้มเหลว (สิทธิ์/เน็ต) ไม่ควรขวางการเล่น
  },
  async releaseRollLock(){
    const me = Store.me||'local'; if (!this.rollLock || this.rollLock.by !== me) return;
    if (this.localMode){ this.rollLock = null; updateRollLockUI(); return; }
    try { await Store.db.doc(`rooms/${this.roomId}/meta/roll`).set({by:null, who:null, label:'', at:0}); } catch(e){ console.warn('release lock', e); }
  },
  /* guardedRoll(who, run): run() ทอยจริงและโพสต์ เรียกเมื่อได้ล็อกแล้วเท่านั้น */
  async guardedRoll(who, run, label){
    if (!this.roomId){ run(); return; }
    if (this.rolling){ toast('รอเต๋าหยุดก่อน'); return; }
    if (this.lockedByOther()){ toast(`${this.rollLock.who||'ผู้เล่นอีกคน'} กำลังทอยอยู่ รอให้เต๋าหยุดก่อน`); return; }
    this.rolling = true; updateRollLockUI();
    const ok = await this.claimRollLock(who, label);
    if (!ok){ this.rolling = false; updateRollLockUI(); toast(`${(this.rollLock&&this.rollLock.who)||'ผู้เล่นอีกคน'} กดทอยก่อนคุณเสี้ยววินาที รอให้เต๋าหยุดก่อน`); return; }
    // run() อาจเป็น async (ทอยแล้วให้เลือกลูก) ระหว่างรอ ต่ออายุล็อกทุก 3 วิ ไม่ให้หมดอายุก่อนเลือกเสร็จ
    const me = Store.me||'local'; const touch = setInterval(()=>{ if (!this.localMode && this.roomId) Store.db.doc(`rooms/${this.roomId}/meta/roll`).set({by:me, who, label:label||'', at:Date.now()}).catch(()=>{}); }, 3000);
    try { const res = run(); if (res && typeof res.then === 'function') await res; } catch(e){ console.warn(e); }
    clearInterval(touch);
    setTimeout(()=>{ this.rolling = false; this.releaseRollLock(); updateRollLockUI(); }, ROLL_SHOW_MS);
  },
  detectNewRolls(){
    if (!this.chatReady){ this.chatReady = true; for (const m of this.chat) this.seenRolls.add(m.id); return; }
    const gm = this.isGM(); const now = Date.now();
    const fresh = this.chat.filter(m => m.kind==='roll' && m.roll && !this.seenRolls.has(m.id)).sort((a,b)=>(a.ts||0)-(b.ts||0));
    for (const m of fresh){ this.seenRolls.add(m.id); if (m.gmOnly && !gm && m.authorId!==Store.me) continue; if (now - (m.ts||0) > 20000) continue; DiceShow.enqueue(m); }
    for (const m of this.chat){ if (m.kind!=='pick' || this.seenRolls.has(m.id)) continue; this.seenRolls.add(m.id); if (now - (m.ts||0) > 20000 || m.authorId===Store.me || (m.gmOnly && !gm)) continue; toast(`${m.who||'อีกฝ่าย'} โจมตีแบบ Disadvantage รอฝ่ายรับเลือก 2 ลูกในแชต`); }
  },
  async save(){ // one write at a time; latest state wins
    const r = this.room; if (!r) return; r.updatedAt = Date.now();
    if (this.localMode){ const rooms = loadLocalRooms(); const i=rooms.findIndex(x=>x.id===r.id); if(i>=0) rooms[i]=r; else rooms.push(r); saveLocalRooms(rooms); renderTable(); return; }
    renderTable();
    if (this.writing){ this.pending = true; return; }
    this.writing = true;
    try { await Store.db.doc('rooms/'+r.id).set(JSON.parse(JSON.stringify(r))); Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)).catch(()=>{}); } catch(e){ console.warn('save room', e); toast('บันทึกห้องไม่ได้ (สิทธิ์ไม่พอ?)'); }
    this.writing = false; if (this.pending){ this.pending=false; this.save(); }
  },
  async post(msg){
    msg.id = msg.fixedId || uid(); delete msg.fixedId; msg.ts = Date.now(); msg.authorId = Store.me||'local'; // fixedId: ผลของการเลือกเต๋าให้การโจมตีใช้ id ตายตัว สองคนกดพร้อมกันจึงเหลือผลเดียว
    if (this.localMode){ this.chat.unshift(msg); this.chat = this.chat.slice(0,200); saveLocalChat(this.roomId, this.chat); renderChatOnly(); if (msg.kind==='roll') DiceShow.enqueue(msg); return; }
    try { await Store.db.doc(`rooms/${this.roomId}/chat/${msg.id}`).set(JSON.parse(JSON.stringify(msg))); } catch(e){ console.warn(e); toast('ส่งข้อความไม่ได้ (สิทธิ์ไม่พอ?)'); } // ผ่าน JSON ก่อนเขียน: Firestore ไม่รับค่า undefined ในเอกสาร
  },
  postRoll(e, c){ if (!this.roomId) return; this.post({kind:'roll', who: c? c.name : (this.isGM()?'GM':'ผู้เล่น'), text:e.label, roll:{dice:e.r.dice, kept:e.r.kept, keptIdx:e.r.keptIdx, sum:e.r.sum, crit:e.r.crit, double:e.r.double, mode:e.mode, chosen:!!e.r.chosen}, mod:e.mod, pm:e.pm, persSide:e.persSide, total:e.total, judge:e.judge, dc:e.dc, atk:e.atk||null, def:e.def||null, gmOnly:false}); },
  /* v1.15 โจมตีแบบ Disadvantage: ผู้โจมตีทอยแล้วโพสต์เต๋าทั้งหมด ฝ่ายรับ (หรือ GM) กดเลือก 2 ลูกจากข้อความนั้น ผลจริงโพสต์เป็นข้อความทอยอีกอันที่อ้าง pickOf */
  postPick(o){ if (!this.roomId) return; this.post({kind:'pick', who: o.who || (o.c ? o.c.name : (this.isGM()?'GM':'ผู้เล่น')), text:o.label||'Attack Roll', dice:(o.dice||[]).slice(), cvMod:o.cvMod||0, loc:o.loc||null, gmOnly:!!o.gmOnly}); },
  pickDone(m){ return this.chat.some(x=>x.pickOf===m.id); },
  canPick(m){ return this.localMode || this.isGM() || m.authorId !== (Store.me||'local'); },
  resolvePick(m){
    if (this.pickDone(m)){ toast('การโจมตีนี้มีคนเลือกเต๋าไปแล้ว'); return; }
    if (!this.canPick(m)){ toast('การโจมตีแบบ Disadvantage ให้ฝ่ายรับหรือ GM เป็นคนเลือก'); return; }
    const dice = m.dice||[]; const by = Store.displayName || (this.isGM() ? 'GM' : 'ผู้เล่น');
    rollChoose(dice.length, 'dis', `${m.who||''}: ${m.text||'Attack Roll'} (เลือก 2 จาก ${dice.length} ลูกให้ผู้โจมตี)`, {kind:'attack', dice, cvMod:m.cvMod||0, loc:m.loc||null, forDefender:true}).then(r=>{
      if (this.pickDone(m)){ toast('มีคนเลือกเต๋าให้การโจมตีนี้ไปก่อนแล้ว'); return; }
      const av = attackVerdict(r, {cvMod:m.cvMod||0, loc:m.loc||null});
      this.post({kind:'roll', who:m.who, text:`${m.text||'Attack Roll'} · ${by} เลือกให้`, roll:{dice:r.dice, kept:r.kept, keptIdx:r.keptIdx, sum:r.sum, crit:null, double:r.double, mode:'dis', chosen:true}, mod:m.cvMod||0, pm:0, total:av.cv, judge:{cls:av.cls, text:av.text}, atk:{sum:av.sum, cv:av.cv, part:av.part||null, precise:av.precise, cvMod:m.cvMod||0, pick:'def'}, pickOf:m.id, pickedBy:by, gmOnly:!!m.gmOnly, fixedId:'pick-'+m.id});
    });
  },
  /* การทอยโจมตีล่าสุดในแชต (ที่ฉันมองเห็น) ใช้เติมช่องป้องกัน: ผลรวมเต๋า CV และตำแหน่งที่เล็ง */
  lastAttack(){ const gm = this.isGM(); let best = null; for (const m of this.chat){ if (m.kind!=='roll' || !m.atk) continue; if (m.gmOnly && !gm && m.authorId!==Store.me) continue; if (!best || (m.ts||0) > (best.ts||0)) best = m; } return best ? Object.assign({who: best.who, ts: best.ts}, best.atk) : null; },
};
/* ชื่อการทอยเป็น Parry หรือ Evade ไหม (ตัวเลขที่แนบมาคือผลโจมตีของอีกฝ่าย ไม่ใช่ DC) */
function isDefenseRollText(text){ return /^(.*· )?(Parry|Evade)(\b|$)/.test(String(text||'')); }
const ROLL_SHOW_MS = 4200;      // เต๋าค้างบนจอ
const ROLL_LOCK_TTL = 8000;     // ล็อกหมดอายุเองถ้าคนทอยหลุดก่อนปล่อย
/* ---- ป๊อปอัปเต๋าเด้งหน้าทุกคนในห้อง (ต่อคิวถ้ามาหลายอัน) ---- */
const DiceShow = {
  q:[], cur:null, timer:null,
  enqueue(m){ this.q.push(m); if (!this.cur) this.next(); },
  clear(){ this.q=[]; if (this.timer) clearTimeout(this.timer); this.timer=null; this.cur=null; const o=$('#dice-overlay'); if (o){ clear(o); o.classList.add('hidden'); } },
  next(){
    const m = this.q.shift(); if (!m){ this.cur=null; return; }
    this.cur = m; const o = $('#dice-overlay'); if (!o) return;
    clear(o); o.classList.remove('hidden');
    const r = m.roll; const dice = r.dice||[]; const keptIdx = r.keptIdx||[];
    const dieEls = dice.map((v,i)=>h('div',{class:'bigdie tumble'+(keptIdx.includes(i)?'':' drop')}, h('span',{text:'?'})));
    const box = h('div',{class:'dicebox'}, h('div',{class:'dice-who'}, chatWho(m), ' ', h('b',{text:m.text||'ทอยเต๋า'}), r.mode&&r.mode!=='normal'? [' ', tag(r.mode==='adv'?'Advantage':'Disadvantage', r.mode==='adv'?'ok':'neg')]:null, (m.atk && m.atk.pick==='def') ? [' ', tag('ฝ่ายรับเลือก','neg')] : (r.chosen? [' ', tag('เลือกลูกเอง','prop')]:null), m.gmOnly? [' ', h('span',{class:'gm',text:'ลับ'})]:null),
      h('div',{class:'dice-row'}, dieEls), h('div',{class:'dice-total',text:''}), h('div',{class:'dice-judge',text:''}));
    o.append(box);
    // หมุนหน้าเต๋าสุ่มสักพักแล้วหยุดทีละลูก
    let tick = 0; const spin = setInterval(()=>{ tick++; dieEls.forEach((el,i)=>{ if (tick < 10 + i*4) el.firstChild.textContent = 1 + Math.floor(Math.random()*(r.sides||6)); else { el.firstChild.textContent = dice[i]; el.classList.remove('tumble'); } }); if (tick >= 10 + dice.length*4){ clearInterval(spin); settle(); } }, 70);
    const settle = ()=>{ const tot = box.querySelector('.dice-total'); const parts = [`${(r.kept||[]).join('+')}`]; if (m.mod) parts.push(signed(m.mod)); if (m.pm) parts.push(`${m.persSide||''} ${signed(m.pm)}`); tot.textContent = parts.join(' ') + ' = ' + m.total; tot.classList.add('show'); const j = box.querySelector('.dice-judge'); if (m.judge){ j.textContent = m.judge.text||''; j.className = 'dice-judge show ' + (m.judge.cls||''); } if (m.dc!=null) j.textContent += isDefenseRollText(m.text) ? ` (โจมตีมา ${m.dc})` : ` (DC ${m.dc})`; if (r.crit==='success' || r.double) box.classList.add('crit'); };
    this.timer = setTimeout(()=>{ o.classList.add('hidden'); clear(o); this.cur=null; this.next(); }, ROLL_SHOW_MS);
  }
};
function updateRollLockUI(){
  const other = Table.roomId && Table.lockedByOther();
  const busy = !!(Table.roomId && (Table.rolling || other));
  document.body.classList.toggle('roll-locked', busy);
  for (const b of document.querySelectorAll('#roll-lock-banner, .lockbanner[data-lock]')){ // ป้ายในแชตและในหน้าต่างทอยเต๋า
    if (other){ b.textContent = `${Table.rollLock.who||'ผู้เล่นอีกคน'} กำลังทอยเต๋า… รอให้เต๋าหยุดก่อน`; b.classList.remove('hidden'); }
    else if (Table.rolling){ b.textContent = 'เต๋าของคุณกำลังทอย…'; b.classList.remove('hidden'); }
    else b.classList.add('hidden');
  }
}
setInterval(()=>{ if (Table.roomId && Table.rollLock && !Table.lockActive() && document.body.classList.contains('roll-locked') && !Table.rolling) updateRollLockUI(); }, 1000);
function loadLocalRooms(){ try{ return JSON.parse(localStorage.getItem('kirana.rooms.v1')||'[]'); }catch(e){ return []; } }
function saveLocalRooms(r){ try{ localStorage.setItem('kirana.rooms.v1', JSON.stringify(r)); }catch(e){} }
function loadLocalChat(id){ try{ return JSON.parse(localStorage.getItem('kirana.chat.'+id)||'[]'); }catch(e){ return []; } }
function saveLocalChat(id, c){ try{ localStorage.setItem('kirana.chat.'+id, JSON.stringify(c)); }catch(e){} }

let roomsCache = []; let roomsUnsub = null;
/* ---- ล็อบบี้: ข้อมูลห้องที่ทุกคนเห็นได้ (ชื่อ GM มีรหัสไหม) แยกจากตัวห้องซึ่งอาจล็อกด้วยรหัส ---- */
function lobbyDoc(r){ return { id:r.id, name:r.name||'', gmId:r.gmId||'', gmName:r.gmName||'', hasKey:!!r.hasKey, tokens:(r.tokens||[]).length, encActive:!!(r.enc&&r.enc.active), round:(r.enc&&r.enc.round)||0, light:r.light||'low', scene:(r.scene||'').slice(0,100), updatedAt:r.updatedAt||Date.now() }; }
async function joinRoomWithKey(id, key){ const me = Store.me; await Store.db.doc(`rooms/${id}/members/${me}`).set({ uid: me, name: Store.displayName||'', key: String(key), at: Date.now() }); try { await Store.db.doc(`rooms/${id}/members/${me}`).set({ uid: me, name: Store.displayName||'', at: Date.now() }); } catch(e){} }
async function setRoomKey(r, key){ // GM เท่านั้น: key ว่าง = ปลดล็อก
  if (!Store.db){ r.joinKey = key || null; r.hasKey = !!key; Table.save(); return; }
  if (key){ await Store.db.doc('roomsecrets/'+r.id).set({ value: String(key), roomId: r.id, at: Date.now() }); r.hasKey = true; await Table.save(); try { await joinRoomWithKey(r.id, key); } catch(e){} }
  else { r.hasKey = false; await Table.save(); try { await Store.db.doc('roomsecrets/'+r.id).delete(); } catch(e){} }
}
/* ลบสำเนาชีทของหมากที่ถูกเอาออกจากบอร์ด (เจ้าของ: เลิกซิงก์ด้วย) */
function dropTokenCopy(r, t){ if (!t || !t.charId) return; if ((r.tokens||[]).some(x=>x!==t && x.charId===t.charId)) return; /* แฝด: อีกร่างยังอยู่บนบอร์ด เก็บสำเนาชีทไว้ */ const mine = Store.chars.find(c=>c.id===t.charId && Store.isMine(c)); if (mine) Store.unshareFromRoom(mine, r.id); else if (Store.db) Store.db.doc(`rooms/${r.id}/chars/${t.charId}`).delete().catch(()=>{}); }
async function deleteCollection(path){ if (!Store.db) return; try { const snap = await Store.db.collection(path).get(); await Promise.all(snap.docs.map(d => Store.db.doc(path+'/'+d.id).delete().catch(()=>{}))); } catch(e){ console.warn('delete', path, e); } }
async function deleteRoomDeep(r){
  for (const t of r.tokens||[]) { const mine = Store.chars.find(c=>c.id===t.charId && Store.isMine(c)); if (mine) Store.unshareFromRoom(mine, r.id); }
  if (!Store.db) return;
  for (const sub of ['chars','chat','members','meta','presence']) await deleteCollection(`rooms/${r.id}/${sub}`);
  try { await Store.db.doc('lobby/'+r.id).delete(); } catch(e){}
  try { await Store.db.doc('roomsecrets/'+r.id).delete(); } catch(e){}
  try { await Store.db.doc('rooms/'+r.id).delete(); } catch(e){ toast('ลบห้องไม่ได้'); }
}
function roomKeyModal(r){
  const inp = h('input',{placeholder:'รหัสเข้าห้อง (4 ตัวขึ้นไป)',style:'min-width:220px',value:''});
  modal(h('div',null, h('h3',{text:'รหัสเข้าห้อง'}), h('p',{class:'desc'}, r.hasKey ? 'ห้องนี้มีรหัสอยู่แล้ว ผู้เล่นต้องกรอกรหัสก่อนเข้าครั้งแรก (บัญชีที่เข้าแล้วไม่ต้องกรอกซ้ำ) รหัสใหม่ใช้กับคนที่ยังไม่เคยเข้า' : 'ตั้งรหัสแล้ว คนที่มีแค่ลิงก์จะเข้าห้องไม่ได้จนกว่าจะกรอกรหัสถูก แชต หมาก และสำเนาชีทในห้องอ่านได้เฉพาะคนในห้อง'),
    h('div',{class:'row',style:'margin-top:8px'}, inp, h('button',{class:'primary small',onclick:async()=>{ const k = inp.value.trim(); if (k.length < 4){ toast('รหัสสั้นเกินไป'); return; } try { await setRoomKey(r, k); toast('ตั้งรหัสเข้าห้องแล้ว'); modal(null); renderTable(); } catch(e){ console.warn(e); toast('ตั้งรหัสไม่ได้ (ต้องเป็น GM ที่สร้างห้อง และ Rules ต้องเป็นรุ่น v1.2)'); } },text: r.hasKey ? 'เปลี่ยนรหัส' : 'ตั้งรหัส'}),
      r.hasKey ? h('button',{class:'small ghost',onclick:async()=>{ try { await setRoomKey(r, ''); toast('ปลดรหัสแล้ว ห้องเปิดให้ทุกคนที่มีลิงก์'); modal(null); renderTable(); } catch(e){ toast('ปลดรหัสไม่ได้'); } },text:'ปลดรหัส'}) : null)));
}
function askRoomKey(id, lobby){
  return new Promise(resolve => {
    const inp = h('input',{placeholder:'รหัสเข้าห้อง',style:'min-width:220px'});
    const go = async ()=>{ const k = inp.value.trim(); if (!k) return; try { await joinRoomWithKey(id, k); modal(null); resolve(true); } catch(e){ console.warn(e); toast('รหัสไม่ถูกต้อง'); } };
    inp.onkeydown = (e)=>{ if (e.key==='Enter') go(); };
    modal(h('div',null, h('h3',{text:`ห้อง "${lobby.name||''}" ล็อกด้วยรหัส`}), h('p',{class:'desc',text:`GM: ${lobby.gmName||'-'} · ขอรหัสเข้าห้องจาก GM แล้วกรอกครั้งเดียว บัญชีนี้จะเข้าได้ตลอด`}), h('div',{class:'row',style:'margin-top:8px'}, inp, h('button',{class:'primary small',onclick:go,text:'เข้าห้อง'}), h('button',{class:'small ghost',onclick:()=>{ modal(null); resolve(false); },text:'ยกเลิก'}))));
    setTimeout(()=>inp.focus(), 50);
  });
}

/* ===== สถานะ (Condition) บนหมาก: GM แปะ มีไอคอน เอฟเฟกต์ นับเทิร์น ซ้อนระดับได้ และผูกกับหมากต้นเหตุได้ ===== */
const COND_ICON = { 'Stunned':'💫','Unbalanced':'🌀','Prone':'🛌','Bleeding':'🩸','Deepwound':'🩹','Burning':'🔥','Poisoned':'☠️','Rooted':'🌿','Grappled':'🤝','Incapacitated':'💤','Exhaustion':'😮‍💨','Deafened':'🔇','Blinded':'🕶️','Frightened':'😨','Fight or Flight':'⚡','Charmed':'💗','Confused':'❓','Silenced':'🤐','Cover':'🛡️','Hidden':'👁️‍🗨️','Invisible':'👻','Devoured':'🦷','Marked':'🎯','Starving':'🍽️','Suffocating':'😵','Intoxicated':'🍺','Haunted':'🕯️','Sundered':'💔' };
/* สถานะที่มีระดับและซ้อนทับได้ (ไฟล์แกน: Bleeding 1,2,3 · Burning ตามระดับ · Poisoned ตามระดับพิษ · Exhaustion 1-6 · Starving 1-3) */
const COND_STACK = new Set(['Bleeding','Burning','Poisoned','Exhaustion','Starving']);
/* สถานะที่ต้องมีหมากอีกตัวเป็นต้นเหตุ: หวาดกลัว ต้องมนตร์ ถูกจับ ถูกกลืนกิน (ตีตรา ระบุได้แต่ไม่บังคับ) */
const COND_BOUND = { 'Frightened':'ต้นตอของความกลัว', 'Charmed':'ผู้ร่ายมนตร์', 'Grappled':'ผู้ที่จับ', 'Devoured':'ผู้กลืนกิน', 'Marked':'ผู้ตีตรา' };
const COND_BOUND_OPTIONAL = new Set(['Marked']);
function condList(){ return Object.entries(GLOSSARY).filter(([k,v])=>/Condition/.test(v.cat||'')).map(([k,v])=>({id:k, th:v.th||'', text:v.text||''})); }
function condIcon(id){ return COND_ICON[id] || '✦'; }
function condClass(id){ return String(id).toLowerCase().replace(/[^a-z]+/g,'-'); }
function condSource(r, c){ return c && c.by ? (r.tokens||[]).find(t=>t.id===c.by) || null : null; }
function condLabel(c, r){ let s = condIcon(c.id)+' '+c.id; if (COND_STACK.has(c.id)) s += ' '+(c.lv||1); if (c.by){ const src = condSource(r, c); s += ' ← '+(src ? src.name : (c.byName||'?')); } if (c.turns) s += ' ⏱'+c.turns; return s; }
function condChips(t, r, gm){
  const cs = t.conds||[]; if (!cs.length) return null;
  return h('div',{class:'conds'}, cs.map(c=>{ const g = GLOSSARY[c.id]||{};
    const chip = h('span',{class:'cond c-'+condClass(c.id), title:(g.th? g.th+': ' : '')+(g.text||'') + (gm? ' (คลิกชื่อเพื่อเอาออก)':'')});
    chip.append(h('span',{class:'cl', onclick: gm ? (e)=>{ e.stopPropagation(); if (c.auto==='cling'){ toast('Prone นี้มาจากการเกาะขอบเหว/หน้าผา ย้ายหมากขึ้นมาก่อนถึงจะหาย'); return; } removeCond(t, r, c); } : null, text: condLabel(c, r) + (c.auto==='cling' ? ' (เกาะขอบ)' : '')}));
    if (gm && COND_STACK.has(c.id)) chip.append(h('button',{class:'cadj',title:'ลดระดับ 1',onclick:(e)=>{ e.stopPropagation(); adjustCond(t, r, c, -1); },text:'−'}), h('button',{class:'cadj',title:'เพิ่มระดับ 1',onclick:(e)=>{ e.stopPropagation(); adjustCond(t, r, c, +1); },text:'+'}));
    return chip; }));
}
function adjustCond(t, r, c, d){ c.lv = (c.lv||1) + d; if (c.lv <= 0){ removeCond(t, r, c); return; } Table.save(); Table.post({kind:'sys',who:'',text:`${t.name}: ${condIcon(c.id)} ${c.id} ${d>0?'เพิ่มเป็น':'ลดเหลือ'}ระดับ ${c.lv}`}); }
/* v1.15 แฝด (Fatal Connection): สภาวะทางจิตใจติดและหายพร้อมกันทั้งสองร่าง */
const TWIN_MIND_CONDS = new Set(['Frightened','Fight or Flight','Charmed','Confused','Haunted','Sundered']);
function twinMindSiblings(t, id){ return (t && t.body && TWIN_MIND_CONDS.has(id)) ? siblingTokens(t).filter(x=>x.body) : []; }
function removeCond(t, r, c, why){ t.conds = (t.conds||[]).filter(x=>x!==c); for (const sb of twinMindSiblings(t, c.id)) sb.conds = (sb.conds||[]).filter(x=>x.id!==c.id); if (c.id==='Devoured') releaseDevoured(r, t); Table.save(); Table.post({kind:'sys',who:'',text:`${t.name} พ้นจากสภาวะ ${c.id}${why? ' ('+why+')':''}${c.id==='Devoured'? ' และโผล่ออกมาที่ ('+t.x+','+t.y+')':''}`}); }
function applyCond(t, r, id, o){
  t.conds = t.conds||[]; const ex = t.conds.find(c=>c.id===id);
  if (ex){ if (!COND_STACK.has(id)){ toast('ติดสถานะนี้อยู่แล้ว'); return false; } ex.lv = (ex.lv||1) + (o.lv||1); if (o.turns) ex.turns = o.turns; Table.save(); Table.post({kind:'sys',who:'',text:`${t.name}: ${condIcon(id)} ${id} ซ้อนเป็นระดับ ${ex.lv}`}); return true; }
  const c = {id, turns: o.turns||null, at: Date.now()}; if (COND_STACK.has(id)) c.lv = o.lv||1; if (o.by){ c.by = o.by.id; c.byName = o.by.name; }
  t.conds.push(c); if (id==='Devoured' && o.by) devourToken(r, t, o.by);
  for (const sb of twinMindSiblings(t, id)){ sb.conds = sb.conds||[]; if (!sb.conds.some(x=>x.id===id)) sb.conds.push(Object.assign({}, c, {twin:true})); }
  Table.save(); Table.post({kind:'sys',who:'',text:`${t.name} ติดสภาวะ ${condIcon(id)} ${id}${c.lv? ' ระดับ '+c.lv:''}${o.by? ' โดย '+o.by.name:''}${c.turns? ' '+c.turns+' เทิร์น':''}${id==='Devoured'? ' หมากถูกดูดเข้าไปในตัว '+(o.by? o.by.name:'ผู้กลืน'):''}`}); return true;
}
/* ถูกกลืนกิน: หมากหายเข้าไปอยู่ในตัวผู้กลืน (ตำแหน่งตามผู้กลืนเสมอ) และโผล่ออกมาข้าง ๆ เมื่อสถานะหลุด */
function devourToken(r, t, eater){ t.inside = eater.id; t.x = eater.x; t.y = eater.y; }
function adjacentFree(r, around, self){ for (let d=1; d<=4; d++) for (let dy=-d; dy<=d; dy++) for (let dx=-d; dx<=d; dx++){ if (Math.max(Math.abs(dx),Math.abs(dy))!==d) continue; const x=around.x+dx, y=around.y+dy; if (!inb(x,y) || !cellStandable(r.map,x,y)) continue; if ((r.tokens||[]).some(o=>o!==self && !o.inside && o.x===x && o.y===y)) continue; return {x,y}; } return {x:around.x, y:around.y}; }
function releaseDevoured(r, t){ const eater = (r.tokens||[]).find(x=>x.id===t.inside); t.inside = null; if (!eater) return; const spot = adjacentFree(r, eater, t); t.x = spot.x; t.y = spot.y; }
function syncDevoured(r, eater){ for (const t of r.tokens||[]) if (t.inside===eater.id){ t.x = eater.x; t.y = eater.y; } }
/* หมากออกจากบอร์ด: ของที่อยู่ในท้องถูกคายออก และสถานะที่มันเป็นต้นเหตุจบลง (ผู้จับปล่อย ต้นตอความกลัวหายไป ผู้ร่ายจากไป) */
function detachToken(r, gone){ for (const t of r.tokens||[]){ if (t===gone) continue; if (t.inside===gone.id){ t.inside = null; const spot = adjacentFree(r, gone, t); t.x = spot.x; t.y = spot.y; Table.post({kind:'sys',who:'',text:`${t.name} หลุดออกจากตัว ${gone.name}`}); t.conds = (t.conds||[]).filter(c=>c.id!=='Devoured'); } const before = (t.conds||[]).length; t.conds = (t.conds||[]).filter(c=>c.by!==gone.id); if ((t.conds||[]).length !== before) Table.post({kind:'sys',who:'',text:`${t.name} พ้นจากสภาวะที่ ${gone.name} เป็นต้นเหตุ`}); } }
/* v1.22: ระยะเคลื่อนที่ต่อ Maneuver ของหมาก คิดจากตัวละครที่ผูกอยู่ (NPC กับ Asset ไม่มีวงศา GM กำหนดเอง) และสถานะบนหมาก */
function tokenMoveSpeed(t){ if (!t || !t.charId) return null; const c = Store.get(t.charId); if (!c || !c.kin || !KIN[c.kin]) return null; try { return moveSpeed(c, compute(c), t.conds); } catch(e){ return null; } }
/* ข้อห้ามเคลื่อนที่จากสถานะที่ผูกกับหมากอื่น (ผู้เล่น) · GM เดินได้เสมอแต่จะได้ข้อความเตือน */
function moveBlocked(r, t, to){ if (t.inside) return 'ถูกกลืนอยู่ ออกมาไม่ได้จนกว่าจะหลุดจากสภาวะ Devoured'; for (const c of t.conds||[]){ const src = condSource(r, c); if (!src) continue; if (c.id==='Grappled' && cellDist(src, to) > 1) return `ถูก ${src.name} จับอยู่ ออกจากเขตปะทะไม่ได้ (ต้องชนะ STR Challenge ก่อน)`; if (c.id==='Rooted' && cellDist(src, to) > 1) return `ถูกยึดติดกับ ${src.name} ออกจากเขตปะทะไม่ได้`; if (c.id==='Frightened' && cellDist(src, to) < cellDist(src, t)) return `หวาดกลัว ${src.name} อยู่ ขยับเข้าใกล้กว่านี้ไม่ได้`; } return null; }
function tickConditions(r){ for (const t of r.tokens||[]){ if (!t.conds) continue; const gone=[]; t.conds = t.conds.filter(c=>{ if (c.turns==null) return true; c.turns--; if (c.turns<=0){ gone.push(c); return false; } return true; }); for (const g of gone){ if (g.id==='Devoured') releaseDevoured(r, t); Table.post({kind:'sys',who:'',text:`${t.name} พ้นจากสภาวะ ${g.id} (ครบเวลา)`}); } } }
function condModal(t, r){
  const list = condList(); const sel = h('select',null, list.map(c=>h('option',{value:c.id,text:`${condIcon(c.id)} ${c.id} ${c.th? '· '+c.th:''}`})));
  const turns = h('input',{type:'number',min:1,max:20,placeholder:'เทิร์น (ว่าง = จนกว่าจะเอาออก)',style:'width:200px'});
  const lv = h('input',{type:'number',min:1,max:9,value:1,style:'width:70px',title:'ระดับ'});
  const lvWrap = h('label',{class:'row',style:'gap:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'ระดับ'}), lv);
  const others = (r.tokens||[]).filter(x=>x!==t);
  const by = h('select',null, h('option',{value:'',text:'— เลือกหมากต้นเหตุ —'}), others.map(x=>h('option',{value:x.id,text:`${x.name}${x.hidden?' (ซ่อน)':''}`})));
  const byWrap = h('label',{class:'row',style:'gap:4px;align-items:center'}, h('span',{class:'dim by-l',style:'font-size:12px'}), by);
  const desc = h('div',{class:'desc',style:'margin-top:6px;font-size:12.5px'});
  const upd = ()=>{ const id = sel.value; const c = list.find(x=>x.id===id); clear(desc); desc.append(T(c? c.text : '')); lvWrap.classList.toggle('hidden', !COND_STACK.has(id)); const bound = !!COND_BOUND[id]; byWrap.classList.toggle('hidden', !bound); byWrap.querySelector('.by-l').textContent = bound ? COND_BOUND[id] + (COND_BOUND_OPTIONAL.has(id) ? ' (ถ้ามี)' : '') : ''; };
  sel.onchange = upd; upd();
  const apply = ()=>{ const id = sel.value; const src = others.find(x=>x.id===by.value) || null; if (COND_BOUND[id] && !COND_BOUND_OPTIONAL.has(id) && !src){ toast(`สถานะ ${id} ต้องระบุว่าใครเป็น${COND_BOUND[id]}`); return; } if (id==='Devoured' && src && src.inside){ toast('ผู้กลืนเองก็ถูกกลืนอยู่'); return; } if (applyCond(t, r, id, {turns: turns.value? +turns.value : null, lv: +lv.value||1, by: src})) modal(null); };
  modal(h('div',null, h('h3',{text:`แปะสถานะให้ ${t.name}`}), h('div',{class:'row',style:'margin-top:8px'}, sel, turns, lvWrap, byWrap, h('button',{class:'primary small',onclick:apply,text:'แปะ'})), desc,
    h('p',{class:'dim',style:'font-size:12px;margin-top:6px',text:'สถานะที่มีระดับ (Bleeding Burning Poisoned Exhaustion Starving) ซ้อนกันได้ กดปุ่ม + − ที่ชิปในฉากเพื่อปรับระดับ · ถูกกลืนกิน: หมากจะถูกดูดเข้าไปในตัวผู้กลืนและเดินตามไปจนกว่าจะหลุด'}),
    (t.conds||[]).length ? h('div',{style:'margin-top:10px'}, h('b',{text:'สถานะที่ติดอยู่ (คลิกชื่อเพื่อเอาออก)'}), condChips(t, r, true)) : null));
}
/* ===== GM ใส่ไอเทมให้ผู้เล่น: เขียนไว้ที่ rooms/<rid>/gifts แล้วเครื่องของเจ้าของรับเข้ากระเป๋าเอง ===== */
let itemCatalogCache = null;
function itemCatalog(){ if (itemCatalogCache) return itemCatalogCache; const out = []; const seen = new Set(); const add = (it, src, cat, sub)=>{ const name = cleanAltName(it.name).replace(/\(เสนอ\)\s*/,'').replace(/\s*×\s*\d+/,'').trim(); const key = name.toLowerCase(); if (!name || seen.has(key)) return; seen.add(key); const qm = String(it.name||'').match(/×\s*(\d+)/); out.push({name, effect: it.effect||'', desc: it.desc||'', weight: stackUnitWeight(it.weight, qm ? +qm[1] : 1), price: it.price||'', src, cat: cat||'', sub: sub||''}); }; // v1.22: แถว × n ของชุดเริ่มต้นเก็บน้ำหนักทั้งกอง แคตตาล็อกใช้น้ำหนักต่อชิ้น
  for (const it of DATA.items||[]) add(it, 'Item All', it.cat, it.sub);
  for (const it of DATA.sets.common.items) add(it, 'ชุดยังชีพ', 'ชุดเริ่มต้น', 'ชุดยังชีพ'); for (const st of DATA.sets.sets) for (const it of st.items) add(it, st.nameEn, 'ชุดเริ่มต้น', st.nameEn);
  itemCatalogCache = out; return out; }
function itemCats(){ return [...new Set(itemCatalog().map(i=>i.cat).filter(Boolean))]; }
async function sendGift(r, t, item){
  const gift = { id: uid(), toCharId: t.charId, toName: t.name, body: bodyOf(t), item: {name:item.name, effect:item.effect||'', weight:+item.weight||0, qty:+item.qty||1}, from: Store.displayName||'GM', fromId: Store.me||'local', at: Date.now() };
  if (Table.localMode || !Store.db){ applyGift(r.id, gift, true); } else { try { await Store.db.doc(`rooms/${r.id}/gifts/${gift.id}`).set(gift); } catch(e){ toast('ส่งไอเทมไม่ได้ (สิทธิ์ไม่พอ?)'); return; } }
  Table.post({kind:'sys',who:'GM',text:`GM มอบ ${item.name}${gift.item.qty>1? ' ×'+gift.item.qty:''} ให้ ${t.name}`});
  toast(`ส่ง ${item.name} ให้ ${t.name} แล้ว`);
}
const giftsApplied = new Set();
function applyGift(rid, g, force){
  if (!g || giftsApplied.has(g.id)) return;
  const c = Store.chars.find(x=>x.id===g.toCharId && (force || Store.isMine(x)));
  if (!c) return; // ไม่ใช่ตัวละครของฉัน เจ้าของจะรับเอง
  giftsApplied.add(g.id);
  if (!c.inventory) ensureSheetState(c, compute(c)); // ชีทที่ยังไม่เคยเปิด: เติมชุดเริ่มต้นก่อน ไม่งั้นของเริ่มต้นจะหาย
  c.inventory = c.inventory || [];
  const toB = g.body==='B' && isTwinborn(c); const bag = bagOf(c, toB ? 'B' : 'A'); // แฝด: ของลงกระเป๋าของร่างที่ GM กดให้
  const it = g.item||{}; const ex = bag.find(x=>x.name===it.name && (x.effect||'')===(it.effect||''));
  if (ex) ex.qty = (ex.qty||1) + (it.qty||1); else bag.push({name:it.name, effect:it.effect||'', qty:it.qty||1, weight:it.weight||0});
  Store.upsert(c);
  toast(`${g.from||'GM'} ให้ ${it.name}${it.qty>1?' ×'+it.qty:''} แก่ ${toB ? bodyName(c,'B') : c.name} แล้ว (อยู่ในกระเป๋า${toB ? 'ของร่าง B' : ''})`);
  if (Store.db && !force) Store.db.doc(`rooms/${rid}/gifts/${g.id}`).delete().catch(()=>{});
  if (location.hash==='#sheet-'+c.id) renderSheet(c.id);
}
function giveItemModal(t, r){
  const cat = itemCatalog(); const q = h('input',{placeholder:'ค้นหาไอเทม (ชื่อหรือคุณสมบัติ)',style:'min-width:240px'}); const list = h('div',{class:'giftlist'});
  const catSel = h('select',null, h('option',{value:'',text:`ทุกหมวด (${cat.length})`}), itemCats().map(k=>h('option',{value:k,text:`${k} (${cat.filter(i=>i.cat===k).length})`})));
  const custom = { name: h('input',{placeholder:'ชื่อไอเทม',style:'min-width:180px'}), effect: h('input',{placeholder:'คุณสมบัติ',style:'min-width:220px'}), weight: h('input',{type:'number',step:'0.1',placeholder:'กก.',style:'width:70px'}), qty: h('input',{type:'number',min:1,value:1,style:'width:60px'}) };
  const draw = ()=>{ clear(list); const k = q.value.trim().toLowerCase(); const ck = catSel.value; const all = cat.filter(it => (!ck || it.cat===ck) && (!k || it.name.toLowerCase().includes(k) || (it.effect||'').toLowerCase().includes(k) || (it.desc||'').toLowerCase().includes(k))); const hits = all.slice(0, 60); if (!hits.length) list.append(h('div',{class:'dim',text:'ไม่พบ ใช้ช่อง "ไอเทมกำหนดเอง" ด้านล่างได้'})); for (const it of hits) list.append(h('div',{class:'gift'}, h('div',null, h('b',{text:it.name}), h('span',{class:'dim',style:'font-size:11px',text:` · ${it.weight} กก.${it.price? ' · '+it.price:''} · ${it.sub||it.src}`}), it.desc? h('div',{class:'dim',style:'font-size:11.5px'}, it.desc.slice(0,140)) : null, h('div',{class:'desc',style:'font-size:12px'}, T(it.effect))), h('button',{class:'small primary',onclick:()=>{ sendGift(r, t, it); modal(null); },text:'ให้'}))); if (all.length > hits.length) list.append(h('div',{class:'dim',style:'font-size:12px',text:`แสดง ${hits.length} จาก ${all.length} พิมพ์ค้นหาเพิ่มเพื่อกรอง`})); };
  q.oninput = draw; catSel.onchange = draw; draw();
  modal(h('div',null, h('h3',{text:`ใส่ไอเทมลงกระเป๋าของ ${t.name}`}), h('p',{class:'dim',style:'font-size:12.5px',text:'ของจะไปอยู่ในกระเป๋าของตัวละครทันทีที่เครื่องของเจ้าของออนไลน์ (เจ้าของเห็นข้อความแจ้ง) · รายการจาก Item All ทั้งไฟล์และชุดเริ่มต้น'}), h('div',{class:'row',style:'margin-bottom:6px'}, catSel, q), list,
    h('div',{class:'card',style:'margin-top:10px'}, h('h4',{text:'ไอเทมกำหนดเอง'}), h('div',{class:'row',style:'margin-top:6px'}, custom.name, custom.effect, custom.weight, custom.qty, h('button',{class:'small primary',onclick:()=>{ const name = custom.name.value.trim(); if (!name){ toast('ใส่ชื่อไอเทม'); return; } sendGift(r, t, {name, effect: custom.effect.value.trim(), weight: +custom.weight.value||0, qty: +custom.qty.value||1}); modal(null); },text:'ให้'})))));
  setTimeout(()=>q.focus(), 50);
}
function renderTableHome(){
  /* v1.20: โครงของหน้าสร้างครั้งเดียว แล้ววาดใหม่เฉพาะรายการห้อง · เดิมทุกครั้งที่ล็อบบี้อัปเดต ทั้งหน้าถูกล้างแล้วสร้างใหม่
   * ช่องที่กำลังพิมพ์ (ชื่อห้อง แชตกลาง) จึงโดนล้างไปด้วย · โครงถูกสร้างใหม่เมื่อสถานะการเชื่อมต่อหรือบัญชีเปลี่ยน */
  const root = $('#v-table');
  const sig = [Store.db ? 1 : 0, Store.canWrite===false ? 1 : 0, Store.me || ''].join(':');
  let home = root.querySelector(':scope > .lobby-home');
  if (!home || home.dataset.sig !== sig){
    clear(root); home = h('div',{class:'lobby-home',dataset:{sig}}); root.append(home);
    home.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'โต๊ะเล่น'}), h('p',{text:'ห้องหนึ่งคือโต๊ะหนึ่งตัว GM สร้างห้องแล้วส่งลิงก์ให้เพื่อน ผู้เล่นวางตัวละครลงแผนที่ 20×20 แล้วทอยเต๋าด้วยกันในแชต อยากเตรียมแผนที่ไว้ก่อน ไปที่หน้า "แผนที่" ได้เลย'}))));
    if (!Store.db){
      home.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'ตอนนี้ไม่มีการเชื่อมต่อฐานข้อมูล (เปิดไฟล์ออฟไลน์ หรือเชื่อม Firebase ไม่สำเร็จ) ห้องที่สร้างจะอยู่ในเครื่องนี้เท่านั้น ใช้ทดลองแผนที่และทอยเต๋าได้ แต่คนอื่นจะไม่เห็น'));
    } else if (Store.canWrite===false){
      home.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'คุณเปิดเพจแบบดูอย่างเดียว: อ่านห้องได้แต่ย้ายตัวละครหรือส่งข้อความไม่ได้ ขอให้เจ้าของเพจแชร์ให้คุณเป็น Contributor'));
    }
    const nameInp = h('input',{placeholder:'ชื่อห้อง เช่น คืนวันสถาปนา',style:'min-width:240px'});
    home.append(h('div',{class:'card',style:'margin-bottom:14px'}, h('div',{class:'row'}, nameInp, h('button',{class:'primary',onclick:async()=>{ const nm = nameInp.value.trim()||'โต๊ะใหม่'; const r = newRoom(nm); rememberGmKey(r.id, r.gmKey); if (!Store.db){ const rooms=loadLocalRooms(); rooms.push(r); saveLocalRooms(rooms); } else { try{ await Store.db.doc('rooms/'+r.id).set(r); await Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)); }catch(e){ toast('สร้างห้องไม่ได้ (สิทธิ์ไม่พอ?)'); return; } } location.hash='#room-'+r.id; },text:'สร้างห้อง (คุณเป็น GM)'}))));
    home.append(h('div',{class:'lobby-wrap'}, h('div',{class:'lobby-rooms'}, h('div',{class:'grid two',id:'lobby-list'})), h('div',{class:'lobby-chat'})));
  }
  const list = home.querySelector('#lobby-list');
  const draw = (rooms)=>{ clear(list); if(!rooms.length) list.append(h('div',{class:'card dim',text:'ยังไม่มีห้อง'})); for (const r of rooms.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0))) list.append(h('div',{class:'card pick',onclick:()=>{location.hash='#room-'+r.id;}}, h('h3',{text:r.name||'(ไม่มีชื่อ)'}), h('div',{class:'gives'}, tag(`${Array.isArray(r.tokens)? r.tokens.length : (r.tokens||0)} ตัวละครบนบอร์ด`), (r.encActive || (r.enc&&r.enc.active))? tag(`กำลังสู้ รอบ ${r.round||(r.enc&&r.enc.round)||0}`,'neg') : null, r.hasKey ? tag('🔒 มีรหัส','warn') : null, (r.gmId===Store.me||!Store.db||gmKeys()[r.id])? tag('คุณเป็น GM','prop'):null), h('div',{class:'desc',text: (r.gmName? 'GM: '+r.gmName+' · ' : '') + (r.scene? r.scene.slice(0,100) : '')}))); };
  GChat.mount(home.querySelector('.lobby-chat')); // แชตกลาง (social.js) ใช้ element เดิมทุกครั้ง
  if (!Store.db) draw(loadLocalRooms());
  else { draw(roomsCache); if (!roomsUnsub){ const merge = (a, b)=>{ const m = new Map(); for (const x of [...a, ...b]) if (x && x.id && !m.has(x.id)) m.set(x.id, x); return [...m.values()]; }; let lobbyList = [], legacy = []; const refresh = ()=>{ roomsCache = merge(lobbyList, legacy); if (location.hash==='#table') renderTableHome(); };
      try{ roomsUnsub = Store.db.collection('lobby').onSnapshot(snap=>{ lobbyList = snapDocs(snap).filter(Boolean); refresh(); }, e=>console.warn('lobby', e)); }catch(e){ console.warn(e); }
      try{ Store.db.collection('rooms').onSnapshot(snap=>{ legacy = snapDocs(snap).filter(Boolean).map(r=>Object.assign(lobbyDoc(r), {legacy:true})); refresh(); }, e=>{ /* Rules รุ่นใหม่ไม่ให้ query ห้องตรง ๆ ใช้ล็อบบี้แทน */ }); }catch(e){} } }
}
function renderTable(){
  if (!Table.roomId || location.hash!=='#room-'+Table.roomId) return;
  // จำช่องที่กำลังพิมพ์อยู่ (แชต ฉาก ชื่อ NPC) เพื่อไม่ให้การพิมพ์ถูกตัดเมื่อห้องอัปเดต
  const ae = document.activeElement; const scopes = [$('#v-table'), $('#twins')].filter(Boolean); const keep = (ae && scopes.some(sc=>sc.contains(ae)) && /^(INPUT|TEXTAREA)$/.test(ae.tagName)) ? {ph: ae.getAttribute('placeholder')||'', tag: ae.tagName, value: ae.value, s: ae.selectionStart, e: ae.selectionEnd} : null;
  try { renderTableInner(); } catch(err){ console.error('renderTable', err); const root = $('#v-table'); root.append(h('div',{class:'warnbox',style:'margin-top:10px'}, 'แสดงห้องไม่สำเร็จ: '+(err && err.message||err), ' ', h('button',{class:'small',onclick:()=>renderTable(),text:'ลองใหม่'}))); }
  if (keep){ const el = scopes.flatMap(sc=>[...sc.querySelectorAll(keep.tag.toLowerCase())]).find(x=>(x.getAttribute('placeholder')||'')===keep.ph); if (el && el !== document.activeElement){ if (keep.value && el.value !== keep.value) el.value = keep.value; try { el.focus({preventScroll:true}); el.setSelectionRange(keep.s, keep.e); } catch(e){} } }
}
function renderTableInner(){
  const root = clearKeep($('#v-table'));
  const r = Table.room;
  if (!r){ clearTwins(); root.append(h('div',{class:'card',text: Table.localMode ? 'ไม่พบห้องนี้ในเครื่อง (ถ้าเป็นห้องออนไลน์ รอการเชื่อมต่อสักครู่)' : 'กำลังเปิดห้อง… (ถ้าค้างนาน แปลว่าไม่พบห้องนี้)'}), h('button',{style:'margin-top:10px',onclick:()=>{location.hash='#table';},text:'← กลับรายการห้อง'})); return; }
  const gm = Table.isGM();
  const myChars = Store.chars.filter(c=>c.done && Store.isMine(c));
  // หมากของฉันที่ยังไม่มีสำเนาชีทในห้อง (วางไว้ตั้งแต่รุ่นก่อน) → แชร์ให้ GM เห็นได้
  if (!Table.localMode) for (const t of r.tokens||[]) if (t.charId && t.ownerId===Store.me && !Table.roomChars.some(x=>x.id===t.charId)){ const c = Store.chars.find(x=>x.id===t.charId); if (c && !(c.roomIds||[]).includes(r.id)) Store.shareToRoom(c, r.id); }
  // ห้องรุ่นก่อนไม่มีเอกสารล็อบบี้: GM เขียนให้ครั้งแรกที่เปิด
  if (gm && !Table.localMode && Table.lobbyWritten !== r.id){ Table.lobbyWritten = r.id; Store.db.doc('lobby/'+r.id).set(lobbyDoc(r)).catch(()=>{}); }
  // ตัวละครของฉันที่ยังซิงก์กับห้องนี้แต่หมากถูกเอาออกไปแล้ว → เลิกซิงก์และลบสำเนา
  if (!Table.localMode) for (const c of Store.chars) if (Store.isMine(c) && (c.roomIds||[]).includes(r.id) && !(r.tokens||[]).some(t=>t.charId===c.id)) Store.unshareFromRoom(c, r.id);
  // HP/Sanity ของหมากกับชีทต้องตรงกัน (ฝั่งที่แก้ล่าสุดชนะ) ถ้าหมากต้องอัปเดตตามชีท ให้บันทึกห้องแล้ววาดใหม่
  if (syncVitalsWithSheets(r) && !Table._vitalsSaving){ Table._vitalsSaving = true; Table.save(); Table._vitalsSaving = false; return; }
  mirrorTwinbornFromTokens(r);
  if (gm && enforceCling(r) && !Table._clingSaving){ Table._clingSaving = true; Table.save(); Table._clingSaving = false; return; } // เกาะขอบเหว = Prone เสมอ (GM เป็นคนเขียนห้อง)
  // header
  const gmKeyBtn = gm && r.gmKey ? h('button',{class:'small ghost',title:'รหัสสำหรับเข้าเป็น GM จากเครื่องอื่น',onclick:()=>{ modal(h('div',null, h('h3',{text:'รหัส GM ของห้องนี้'}), h('p',{class:'desc',text:'ใช้เมื่อคุณเปิดห้องจากเครื่องหรือเบราว์เซอร์อื่น: กด "เข้าเป็น GM" แล้วกรอกรหัสนี้ อย่าให้ผู้เล่นเห็น'}), h('div',{style:'font-family:var(--font-display);font-size:28px;letter-spacing:4px',text:r.gmKey}))); },text:'รหัส GM'}) : null;
  const becomeGm = !gm && r.gmKey ? h('button',{class:'small ghost',onclick:()=>{ const k=(prompt('กรอกรหัส GM ของห้องนี้')||'').trim().toUpperCase(); if(!k) return; if (k===r.gmKey){ rememberGmKey(r.id,k); toast('คุณเป็น GM ของห้องนี้แล้ว'); renderTable(); } else toast('รหัสไม่ถูกต้อง'); },text:'เข้าเป็น GM'}) : null;
  const keyBtn = gm ? h('button',{class:'small ghost'+(r.hasKey?' on':''),title:'ตั้งรหัสให้ผู้เล่นต้องกรอกก่อนเข้าห้อง',onclick:()=>roomKeyModal(r),text: r.hasKey ? '🔒 รหัสเข้าห้อง' : 'ตั้งรหัสเข้าห้อง'}) : (r.hasKey ? tag('🔒 ห้องมีรหัส') : null);
  const mySheetBtns = (r.tokens||[]).filter((t,i,arr)=>t.charId && (t.ownerId===Store.me || Table.localMode) && arr.findIndex(x=>x.charId===t.charId)===i).map(t=>h('button',{class:'small',title:'เปิดชีทตัวละครของคุณ (มีปุ่มกลับโต๊ะที่หัวชีท)',onclick:()=>{ location.hash='#sheet-'+t.charId; },text:'📜 ชีท: '+((Store.get(t.charId)||{}).name||t.name)}));
  const shareBtn = h('button',{class:'small ghost',onclick:()=>{ const url = location.href.split('#')[0] + '#room-' + r.id; navigator.clipboard.writeText(url).then(()=>toast('คัดลอกลิงก์ห้องแล้ว')).catch(()=>modal(h('div',null, h('h3',{text:'ลิงก์ห้อง'}), h('input',{style:'width:100%',value:url,readonly:true})))); },text:'ลิงก์ห้อง'});
  const head = h('div',{class:'stephead'}, h('div',null, h('h2',{text:r.name}), h('p',null, gm? tag('คุณเป็น GM','prop') : tag('ผู้เล่น'), ' ', h('span',{id:'peers',class:'dim',style:'font-size:13px'}), Table.localMode? [' ', tag('ห้องในเครื่องนี้','warn')] : null)),
    h('div',{class:'row'}, ...mySheetBtns, shareBtn, keyBtn, gmKeyBtn, becomeGm, gm? h('button',{class:'small ghost',onclick:async()=>{ if(!confirm(`ลบห้อง "${r.name}" ถาวร? แชต บอร์ด และสำเนาชีทในห้องจะหายทั้งหมด`)) return; const id=r.id; const snapshot = JSON.parse(JSON.stringify(r)); Table.close(); if (!Store.db){ saveLocalRooms(loadLocalRooms().filter(x=>x.id!==id)); for (const t of snapshot.tokens||[]){ const mine = Store.chars.find(c=>c.id===t.charId); if (mine) Store.unshareFromRoom(mine, id); } } else { toast('กำลังลบห้องและสำเนาชีท…'); await deleteRoomDeep(snapshot); } location.hash='#table'; },text:'ลบห้อง'}) : null, h('button',{class:'small ghost',onclick:()=>{ Table.close(); location.hash='#table'; },text:'← ออกจากห้อง'})));
  root.append(head);
  const left = h('div'); const right = h('div');
  // scene text
  if (gm){ const ta = h('textarea',{placeholder:'บรรยายฉาก (ผู้เล่นเห็น)'}); ta.value = r.scene||''; ta.onblur = ()=>{ if (ta.value!==(r.scene||'')){ r.scene = ta.value; Table.save(); } }; left.append(h('div',{class:'card',style:'margin-bottom:12px'}, h('label',{text:'ฉาก'}), ta)); }
  else if (r.scene) left.append(h('div',{class:'card',style:'margin-bottom:12px'}, h('div',{class:'kicker',text:'ฉาก'}), h('p',{style:'margin:4px 0 0',text:r.scene})));
  // add token controls
  const addRow = h('div',{class:'row',style:'margin-bottom:10px'});
  if (myChars.length){ const sel = h('select',null, myChars.map(c=>h('option',{value:c.id,text:c.name}))); addRow.append(sel, h('button',{class:'small primary',onclick:()=>placeCharacter(Store.get(sel.value), r),text:'วางตัวละครลงบอร์ด'})); }
  else addRow.append(h('span',{class:'dim',style:'font-size:13px',text:'ยังไม่มีตัวละครที่พร้อมเล่น สร้างในหน้า "สร้างตัวละคร" ก่อน'}));
  if (gm){ const nm=h('input',{placeholder:'ชื่อ NPC/ศัตรู',style:'width:150px'}); const hp=h('input',{type:'number',style:'width:64px',value:10,title:'HP สูงสุด'}); const ini=h('input',{type:'number',style:'width:56px',value:0,title:'Initiative (บวกกับ 2d6 ตอนจัดลำดับเทิร์น)'}); const nv=h('input',{type:'checkbox',title:'มองเห็นในความมืด (Dark Vision)'});
    addRow.append(nm, h('label',{class:'fld'}, h('span',{text:'HP สูงสุด'}), hp), h('label',{class:'fld'}, h('span',{text:'Initiative'}), ini), h('label',{class:'fld chk',title:'มองเห็นในความมืด (Dark Vision) ไม่ติดตาบอดในที่มืด'}, nv, h('span',{text:'Dark Vision'})), h('button',{class:'small',onclick:()=>{ const n=nm.value.trim()||'ศัตรู'; const pos = freeCell(r.map, r.tokens, [0,1,2,3]); r.tokens.push({id:uid(), name:n, kind:'npc', x:pos.x, y:pos.y, hp:+hp.value||10, hpMax:+hp.value||10, san:0, sanMax:0, init:+ini.value||0, hidden:true, note:'', desc:'', nv: nv.checked, torch:false, aquatic:false, inWater:false, climb:false}); Table.save(); },text:'+ NPC (ซ่อนไว้ก่อน)'}),
      h('button',{class:'small ghost libopen',title:'วาง NPC หรือ Asset ที่เตรียมไว้จากคลังของคุณลงบอร์ด',onclick:()=>openNpcLibraryPicker(r),text:'📚 คลัง NPC / Asset'})); }
  left.append(addRow);
  // ---- แผนที่ต่อสู้ 20×20 ----
  left.append(mapPanel(r, gm));
  left.append(h('p',{class:'dim',style:'font-size:12px;margin-top:8px',text:`หนึ่งช่องคือ ${CELL_M} เมตร ช่องที่ติดกัน (รวมทแยง) คือเขตปะทะ ไม่เกิน ${NEAR_MAX_M} เมตร (${NEAR_MAX_M/CELL_M} ช่อง) คือเขตใกล้เคียง ไกลกว่านั้นคือเขตไกล ยิงไปเขตไกลโดนลด CV ตามระยะ ระยะที่เดินได้ต่อ 1 Maneuver คือความเร็วของตัวละคร Dash (1 Swift) ไปได้เท่าความเร็ว Dash ของวงศา Run (1 Swift บวก 1 AP) ไปได้เท่าความเร็ววิ่งบวก AGI Mod คลิกหมากของคุณแล้วจุดกลางช่องจะบอกช่องที่ไปถึง จุดทึบคือ Dash วงแหวนคือ Run ถอยออกจากเขตปะทะโดนโจมตีฉวยโอกาส ช่องเดินช้า (น้ำตื้น หิมะ โคลน เศษหิน) นับเป็นสองช่อง น้ำลึกว่ายได้แต่เสียเทิร์นที่ลงไป และโจมตีไม่ได้จนกว่าจะขึ้นฝั่ง (สัตว์น้ำยกเว้น) · ต้นไม้ เสา เหว และขอบหน้าผาเข้าได้เฉพาะหมากที่ติ๊ก 🧗 ปีนป่าย เกาะขอบเหวหรือหน้าผาอยู่ = ติด Prone ตลอด · ลากหมากเพื่อย้าย คลิกหมากเพื่อดูโซนและระยะมองเห็น`}));
  // หน้าปัด: ลำดับเทิร์นและหมาก + หมากที่เลือก (ฝังคอลัมน์ขวา กด ⇱ ปลดลอยได้ ปิดไม่ได้)
  right.append(h('div',{style:'margin-bottom:12px'}, twinDock(r, gm)));
  // clocks
  const ck = h('div',{class:'card',style:'margin-bottom:12px'}, h('h3',{text:'นาฬิกาชะตากรรม (Fate Clock)'}));
  const ckrow = h('div',{class:'row',style:'margin-top:8px;align-items:flex-start'});
  for (const cl of r.clocks||[]) ckrow.append(clockEl(cl, r, gm));
  ck.append(ckrow);
  if (gm){ const nm=h('input',{placeholder:'ชื่อนาฬิกา',style:'width:140px'}); const seg=h('select',null,[4,6,8,10,12].map(n=>h('option',{value:n,text:n+' ช่อง'}))); ck.append(h('div',{class:'row',style:'margin-top:8px'}, nm, seg, h('button',{class:'small',onclick:()=>{ r.clocks=r.clocks||[]; r.clocks.push({id:uid(),name:nm.value.trim()||'นาฬิกา',seg:+seg.value,fill:0}); Table.save(); },text:'+ นาฬิกา'}))); }
  right.append(ck);
  // แชตและบันทึกการทอย อยู่ใต้แผนที่ (ผู้ใช้เคาะ 9 พ.ย. 2026) ปุ่มทอยย้ายไปหน้าต่างลอย 🎲 ที่แท็บมุมจอ
  const chatBox = h('div',{class:'card chat',style:'margin-top:12px'}, h('h3',{class:'row',style:'justify-content:space-between'}, h('span',{text:'แชตและบันทึกการทอยของโต๊ะ'}), h('button',{class:'small ghost rollbtn',title:'เปิดหน้าต่างทอยเต๋า (แท็บ 🎲 มุมจอ)',onclick:()=>{ TWin.dice = true; TWin.persist(); renderTwins(r, gm); },text:'🎲 ทอยเต๋า'})), h('div',{class:'log',id:'chatlog'}));
  const who = h('select',{id:'chat-who'}, h('option',{value:'',text: gm?'GM'+(Store.displayName?' ('+Store.displayName+')':'') : (Store.displayName||'ผู้เล่น')}), myChars.map(c=>h('option',{value:c.id,text:c.name})));
  if (Table.chatWho && myChars.some(c=>c.id===Table.chatWho)) who.value = Table.chatWho; who.onchange = ()=>{ Table.chatWho = who.value; };
  const inp = h('input',{placeholder:'พิมพ์ข้อความ หรือ /r 2d6+3 · /r 3d6 dis · /parry 4 dc 9 · /gm r … (ลับ) · /help',style:'flex:1;min-width:160px'});
  const send = ()=>{ const txt = inp.value.trim(); if(!txt) return; inp.value=''; const c = Store.get(who.value); const name = c? c.name : (gm?'GM':(Store.displayName||'ผู้เล่น')); handleChatInput(txt, name, c, gm); };
  inp.onkeydown = (e)=>{ if (e.key==='Enter' && !e.isComposing){ e.preventDefault(); send(); } };
  chatBox.append(h('div',{class:'row'}, who, inp, h('button',{class:'primary small',onclick:send,text:'ส่ง'})));
  chatBox.append(h('div',{id:'roll-lock-banner',class:'lockbanner hidden'}));
  left.append(chatBox);
  updateRollLockUI();
  root.append(h('div',{class:'table-wrap'}, left, right));
  renderChatOnly(); renderPeers();
  renderTwins(r, gm);
}
/* วางตัวละครของฉันลงบอร์ด: สร้างหมาก + แชร์สำเนาชีทเข้าห้อง (ผู้เล่นคนอื่นและ GM จึงเห็นชีทได้เฉพาะในแคมเปญนี้) */
async function placeCharacter(c, r){
  if (!c) return;
  // Twinborn: สองร่าง สองหมาก (ร่าง B ถือ HP ของตัวเอง) วางร่างที่ยังไม่อยู่บนบอร์ด · ตัวละครทั่วไปมีหมากเดียว
  const twin = isTwinborn(c); const have = r.tokens.filter(t=>t.charId===c.id).map(bodyOf);
  const need = (twin ? ['A','B'] : ['A']).filter(b=>!have.includes(b));
  if (!need.length){ toast(twin ? 'แฝดทั้งสองร่างอยู่บนบอร์ดแล้ว' : 'ตัวละครนี้อยู่บนบอร์ดแล้ว'); return; }
  let d = compute(c); if (twin && Store.isMine(c)){ ensureSheetState(c, d); d = compute(c); }
  const thumb = await makeThumb(c.portrait); const cur = c.current||{}; const st = twinbornState(c);
  if (twin) for (const t of r.tokens) if (t.charId===c.id && !t.body) t.body = 'A'; // หมากที่วางไว้ก่อน v1.14 ยังไม่มีป้ายร่าง
  for (const body of need){
    let pos = null; const sib = r.tokens.find(t=>t.charId===c.id && !t.inside); // ร่างที่สองยืนติดร่างแรกถ้ามีช่องว่าง
    if (sib){ for (const [dx,dy] of [[1,0],[-1,0],[0,-1],[0,1],[1,-1],[-1,-1],[1,1],[-1,1]]){ const x = sib.x+dx, y = sib.y+dy; if (inb(x,y) && cellStandable(r.map,x,y) && !r.tokens.some(t=>!t.inside && t.x===x && t.y===y)){ pos = {x,y}; break; } } }
    if (!pos) pos = freeCell(r.map, r.tokens, [16,17,18,19]);
    const tok = {id:uid(), name: twin ? bodyName(c, body) : c.name, kind:'pc', charId:c.id, ownerId:Store.me||'local', ownerName: Store.displayName||'', x:pos.x, y:pos.y, hp:(body==='B' ? cur.hp2 : cur.hp)??d.hp, hpMax:d.hp, san:cur.sanity??d.sanity, sanMax:d.sanity, tough: Object.assign({}, cur.tough||{}), init:d.initiative, hidden:false, note:'', desc:'', thumb: thumb||null, nv: charHasNightVision(c), torch:false, aquatic:false, inWater:false, climb:false, vitalsAt:cur.at||Date.now()};
    if (twin){ tok.body = body; tok.gmRun = st.apart && st.control !== body; }
    r.tokens.push(tok);
  }
  Table.save(); Table.post({kind:'sys', who:'', text: twin ? (need.length===2 ? `${c.name} เข้าร่วมฉากทั้งสองร่าง` : `${bodyName(c, need[0])} เข้าร่วมฉาก`) : `${c.name} เข้าร่วมฉาก`});
  Store.shareToRoom(c, r.id);
}
/* ===== หน้าปัดในห้อง (ลำดับเทิร์นและหมาก · หมากที่เลือก · ทอยเต๋า) ย้าย/ย่อขยายได้เหมือนหน้าต่างกระเป๋าและถุงย่าม =====
   v1.7: หน้าต่างคงอยู่ข้ามการวาดใหม่ (เปลี่ยนแค่เนื้อใน) ตำแหน่งมาจากการลากเท่านั้น จึงไม่เด้งไปมุมจอ · ลำดับเทิร์นกับหมากที่เลือกปิดไม่ได้ (ผู้ใช้เคาะ 9 พ.ย. 2026) */
const TWin = {
  float: {order:false, tok:false}, pos: {}, collapsed: {}, dice: false, dock: null,
  load(){ try { const s = JSON.parse(localStorage.getItem('kirana.twin')||'{}'); this.float = Object.assign({order:false, tok:false}, s.float||{}); this.pos = s.pos||{}; this.collapsed = s.collapsed||{}; this.dice = !!s.dice; this.dock = s.dock||null; for (const k of Object.keys(this.pos)){ const p = this.pos[k]; if (!p || !(p.w>0) || !(p.x>=0) || !(p.y>=0)) delete this.pos[k]; } } catch(e){} },
  persist(){ try { localStorage.setItem('kirana.twin', JSON.stringify({float:this.float, pos:this.pos, collapsed:this.collapsed, dice:this.dice, dock:this.dock})); } catch(e){} },
};
TWin.load();
const TWIN_TITLE = {order:'⚔ ลำดับเทิร์นและหมาก', tok:'🎯 หมากที่เลือก', dice:'🎲 ทอยเต๋า'};
function isNarrow(){ return vw() < 900; }
function twinsRoot(){ let root = $('#twins'); if (!root){ root = h('div',{id:'twins'}); document.body.append(root); } return root; }
function clearTwins(){ const root = $('#twins'); if (root) clear(root); }
function renderTwins(r, gm){
  const root = twinsRoot();
  const inRoom = r && location.hash === '#room-'+r.id;
  if (!inRoom){ clear(root); return; }
  const want = [];
  if (!isNarrow()){ if (TWin.float.order) want.push(['order', ()=>orderBody(r, gm), null]); if (TWin.float.tok) want.push(['tok', ()=>tokBody(r, gm), null]); }
  if (TWin.dice) want.push(['dice', ()=>diceBody(r, gm), diceKey(r, gm)]);
  for (const el of [...root.querySelectorAll('.twin')]) if (!want.some(([k])=>el.classList.contains('twin-'+k))) el.remove();
  for (const [key, build, cacheKey] of want){
    let win = root.querySelector('.twin-'+key);
    if (!win){ win = twin(key); root.append(win); }
    if (cacheKey && win.dataset.key === cacheKey) continue; // เนื้อในเดิมใช้ได้ ไม่ต้องสร้างใหม่ (แผงทอยจำโหมด/บุคลิกภาพที่ตั้งไว้)
    if (cacheKey) win.dataset.key = cacheKey;
    fillTwin(win, build());
  }
  // แท็บทอยเต๋าลอย (เหมือน dock ในชีท) อยู่เสมอขณะอยู่ในห้อง
  let dock = root.querySelector('.rdock'); if (!dock){ dock = roomDock(); root.append(dock); }
  dock.querySelector('.hud-btn').classList.toggle('on', !!TWin.dice);
  for (const el of root.querySelectorAll('.twin, .rdock')) clampToViewport(el);
}
/* เปลี่ยนเนื้อในหน้าต่าง เก็บตำแหน่งเลื่อนและช่องที่กำลังพิมพ์ไว้ */
function fillTwin(win, body){
  const b = win.querySelector('.hud-body'); const top = b.scrollTop;
  const ae = document.activeElement; const keep = (ae && b.contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) ? {ph: ae.getAttribute('placeholder')||'', tag: ae.tagName, value: ae.value, s: ae.selectionStart, e: ae.selectionEnd} : null;
  clear(b); b.append(body); b.scrollTop = top;
  if (keep){ const el = [...b.querySelectorAll(keep.tag.toLowerCase())].find(x=>(x.getAttribute('placeholder')||'')===keep.ph); if (el){ if (keep.tag!=='SELECT' && keep.value && el.value !== keep.value) el.value = keep.value; try { el.focus({preventScroll:true}); if (keep.tag!=='SELECT') el.setSelectionRange(keep.s, keep.e); } catch(e){} } }
}
function twin(key){
  const win = h('div',{class:'hud-win twin twin-'+key+(key==='dice'?' dice':'')+(TWin.collapsed[key]?' collapsed':'')});
  const collapseBtn = h('button',{class:'hud-x',title: TWin.collapsed[key] ? 'ขยาย' : 'ย่อ',onclick:()=>{ TWin.collapsed[key] = !TWin.collapsed[key]; TWin.persist(); win.classList.toggle('collapsed', !!TWin.collapsed[key]); collapseBtn.title = TWin.collapsed[key] ? 'ขยาย' : 'ย่อ'; collapseBtn.firstChild.textContent = TWin.collapsed[key] ? '▢' : '–'; if (!TWin.collapsed[key] && TWin.pos[key] && TWin.pos[key].h) win.style.height = TWin.pos[key].h+'px'; }}, h('span',{text: TWin.collapsed[key] ? '▢' : '–'}));
  const head = h('div',{class:'hud-head'}, key==='dice' ? svgEl('dice') : null, h('b',{text: key==='dice' ? 'ทอยเต๋า' : TWIN_TITLE[key]}), collapseBtn);
  if (key==='dice') head.append(h('button',{class:'hud-x',title:'ปิด (เปิดใหม่ได้ที่แท็บ 🎲 มุมจอ)',onclick:()=>{ TWin.dice = false; TWin.persist(); renderTwins(Table.room, Table.isGM()); }}, svgEl('close')));
  else head.append(h('button',{class:'hud-x',title:'เก็บกลับเข้าคอลัมน์ขวา',onclick:()=>{ TWin.float[key] = false; TWin.persist(); renderTable(); }}, h('span',{text:'⇲'})));
  const b = h('div',{class:'hud-body'});
  win.append(head, b);
  const p = TWin.pos[key];
  if (p){ win.style.left = p.x+'px'; win.style.top = p.y+'px'; win.style.right = 'auto'; win.style.bottom = 'auto'; if (p.w) win.style.width = p.w+'px'; if (p.h && !TWin.collapsed[key]) win.style.height = p.h+'px'; }
  else if (key==='dice'){ win.style.right = '14px'; win.style.bottom = '96px'; win.style.top = 'auto'; }
  else if (key==='tok'){ win.style.right = '14px'; win.style.top = '84px'; }
  else { win.style.right = TWin.float.tok ? '390px' : '14px'; win.style.top = '84px'; } // ลำดับเทิร์นอยู่ซ้ายของหมากที่เลือกเมื่อลอยทั้งคู่
  // ขนาดจากการย่อขยายด้วยมือเท่านั้น: หน้าต่างที่หลุดจาก DOM หรือยุบอยู่มีขนาด 0 ต้องไม่ถูกจำ (ตัวการที่ทำให้เด้งไปมุมซ้ายบนใน v1.6)
  let first = true; new ResizeObserver(()=>{ if (first){ first=false; return; } if (!win.isConnected || TWin.collapsed[key] || !win.offsetWidth || !win.offsetHeight) return; const cur = TWin.pos[key]; if (cur && cur.w===win.offsetWidth && cur.h===win.offsetHeight) return; const rct = win.getBoundingClientRect(); const z = uiZoom(); TWin.pos[key] = {x: Math.max(0, Math.round(rct.left/z)), y: Math.max(0, Math.round(rct.top/z)), w: win.offsetWidth, h: win.offsetHeight}; TWin.persist(); }).observe(win);
  makeDraggable(win, head, (pp)=>{ TWin.pos[key] = {...(TWin.pos[key]||{w: win.offsetWidth, h: win.offsetHeight}), x: Math.round(pp.x), y: Math.round(pp.y)}; TWin.persist(); });
  return win;
}
/* ดันหน้าต่าง/แท็บที่หลุดขอบจอกลับเข้ามา (ไม่รีเซ็ตตำแหน่ง) */
function clampToViewport(el){
  const r0 = el.getBoundingClientRect(); if (!r0.width) return; const z = uiZoom();
  const rct = {left:r0.left/z, top:r0.top/z, width:r0.width/z, height:r0.height/z}; // พิกัดหลัง zoom ให้ตรงกับ style.left/top
  const maxX = Math.max(4, vw() - rct.width - 4), maxY = Math.max(4, vh() - Math.min(rct.height, 120) - 4);
  if (rct.left >= 0 && rct.top >= 0 && rct.left <= maxX && rct.top <= maxY) return;
  const x = Math.min(maxX, Math.max(4, rct.left)), y = Math.min(maxY, Math.max(4, rct.top));
  el.style.left = x+'px'; el.style.top = y+'px'; el.style.right = 'auto'; el.style.bottom = 'auto';
}
window.addEventListener('resize', ()=>{ const root = $('#twins'); if (root) for (const el of root.querySelectorAll('.twin, .rdock')) clampToViewport(el); });
/* แท็บทอยเต๋ามุมจอ: ปุ่มเดียวแบบ dock ในชีท ลากย้ายได้ กดเปิด/ปิดหน้าต่างทอย ป้ายทองคือผลทอยล่าสุดของฉัน */
function roomDock(){
  const dock = h('div',{class:'hud-dock rdock'});
  const btn = h('button',{class:'hud-btn'+(TWin.dice?' on':''),title:'ทอยเต๋า',onclick:()=>{ if (dock.dataset.justDragged) return; TWin.dice = !TWin.dice; TWin.persist(); renderTwins(Table.room, Table.isGM()); }}, svgEl('dice'), h('span',{class:'lbl',text:'ทอยเต๋า'}), h('span',{class:'badge gold hidden'}));
  dock.append(h('div',{class:'hud-grip',title:'ลากเพื่อย้าย'}, svgEl('grip')), btn);
  if (TWin.dock && TWin.dock.x>=0 && TWin.dock.y>=0){ dock.style.left = TWin.dock.x+'px'; dock.style.top = TWin.dock.y+'px'; dock.style.right = 'auto'; dock.style.bottom = 'auto'; }
  makeDraggable(dock, dock, (p)=>{ TWin.dock = {x: Math.round(p.x), y: Math.round(p.y)}; TWin.persist(); });
  return dock;
}
function diceBadge(total){ const bd = document.querySelector('#twins .rdock .badge'); if (!bd) return; bd.textContent = String(total); bd.classList.remove('hidden'); }
function diceKey(r, gm){ const mine = Store.chars.filter(c=>c.done && Store.isMine(c)); return (gm?'gm':'pl') + '|' + (Table.localMode?'L':'F') + '|' + mine.map(c=>c.id+':'+c.name+':'+(c.updatedAt||0)).join(','); }
/* เนื้อในหน้าต่างทอยเต๋า: เลือกตัวละครที่ทอยในนาม ปุ่มทอยด่วน (2d6 / Attack / Luck / ทอยลับ GM) และแผงทอยเต็มแบบเดียวกับในชีท */
function diceBody(r, gm){
  const myChars = Store.chars.filter(c=>c.done && Store.isMine(c));
  const box = h('div',{class:'twin-dice'});
  if (Table.diceWho==null){ const sel = Table.sel ? (r.tokens||[]).find(x=>x.id===Table.sel) : null; Table.diceWho = (sel && sel.charId && myChars.some(c=>c.id===sel.charId)) ? sel.charId : (myChars[0] ? myChars[0].id : ''); }
  const who = h('select',{style:'min-width:160px'}, h('option',{value:'',text: gm?'GM'+(Store.displayName?' ('+Store.displayName+')':'') : (Store.displayName||'ผู้เล่น')}), myChars.map(c=>h('option',{value:c.id,text:c.name})));
  who.value = myChars.some(c=>c.id===Table.diceWho) ? Table.diceWho : '';
  const selChar = ()=>Store.get(who.value);
  const whoName = ()=>{ const c=selChar(); return c? c.name : (gm?'GM':(Store.displayName||'ผู้เล่น')); };
  const onRoll = (e, c)=>{ Table.postRoll(e, c); diceBadge(e.total); };
  const qroll = (label, kind)=>{ const c=selChar(); if (kind==='attack' && c){ const blk = Table.attackBlocked(c); if (blk){ toast(blk); return; } } Table.guardedRoll(whoName(), ()=>onRoll(doRoll({label, kind, c}), c), label); };
  const quick = h('div',{class:'row'}, h('button',{class:'small rollbtn',onclick:()=>qroll('2d6','check'),text:'2d6'}), h('button',{class:'small rollbtn',onclick:()=>qroll('Attack Roll','attack'),text:'Attack (CV)'}), h('button',{class:'small rollbtn',onclick:()=>qroll('Luck Saving Throw','luck'),text:'Luck'}),
    ...(gm? [h('button',{class:'small ghost rollbtn',onclick:()=>{ Table.guardedRoll('GM', ()=>{ const e=doRoll({label:'ทอยลับของ GM'}); Table.post({kind:'roll',who:'GM',text:e.label,roll:{dice:e.r.dice,kept:e.r.kept,keptIdx:e.r.keptIdx,sum:e.r.sum,crit:e.r.crit,double:e.r.double,mode:e.mode},mod:0,pm:0,total:e.total,judge:e.judge,gmOnly:true}); diceBadge(e.total); }, 'ทอยลับ'); },text:'ทอยลับ (GM)'})] : []));
  // ช่องคำสั่งทอย (ผู้ใช้ขอ 9 พ.ย. 2026): พิมพ์ 3d6 dis · 2d6+3 · 1d20 · 4d6kh3 · dc10 แล้ว Enter · GM ติ๊ก "ลับ" ได้
  const cmd = h('input',{placeholder:'คำสั่งทอย เช่น 3d6 dis · 2d6+3 · attack cv+2 · parry 4 dc 9 · evade adv · 1d20 · dc 10 ชื่อการทอย',style:'flex:1;min-width:220px'});
  const secret = gm ? h('input',{type:'checkbox',title:'ผลทอยเห็นเฉพาะ GM'}) : null;
  const runCmd = ()=>{ const txt = cmd.value.trim(); if (!txt) return; runRollCommand(txt, whoName(), selChar(), !!(secret && secret.checked), 'normal'); cmd.value=''; cmd.focus(); };
  cmd.onkeydown = (e)=>{ if (e.key==='Enter' && !e.isComposing){ e.preventDefault(); runCmd(); } };
  const cmdRow = h('div',{class:'row dicecmd',style:'margin-top:6px'}, cmd, h('button',{class:'small primary',onclick:runCmd,text:'ทอย'}), secret ? h('label',{class:'fld chk',title:'ผลทอยเห็นเฉพาะ GM'}, secret, h('span',{text:'ลับ'})) : null, h('button',{class:'small ghost',title:'คำสั่งที่ใช้ได้',onclick:rollHelpModal,text:'?'}));
  box.append(h('div',{class:'row',style:'margin-bottom:6px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'ทอยในนาม'}), who), quick, cmdRow, h('div',{class:'lockbanner hidden',dataset:{lock:'1'}}));
  const panelHost = h('div',{style:'margin-top:8px'});
  const drawPanel = ()=>{ clear(panelHost); const c = selChar(); if (!c){ panelHost.append(h('p',{class:'dim',style:'font-size:12px;margin:0',text:'เลือกตัวละครด้านบนเพื่อเปิดแผงทอย Stat Check / Saving Throw / ความรู้ ผลทอยเด้งให้ทุกคนในห้องเห็น'})); return; } const p = dicePanel(c, (e)=>onRoll(e, c), {guard:(run,label)=>Table.guardedRoll(c.name, run, label), noLog:true, pendingPick:(o)=>Table.postPick(o), lastAttack:()=>Table.lastAttack()}); p.classList.remove('card'); p.classList.add('hud-dice'); panelHost.append(p); };
  who.addEventListener('change', ()=>{ Table.diceWho = who.value; drawPanel(); }); drawPanel();
  box.append(panelHost);
  updateRollLockUI();
  return box;
}
/* หน้าปัดในคอลัมน์ขวา: ฝังเป็นการ์ดเสมอ กด ⇱ เพื่อปลดเป็นหน้าต่างลอยที่ลากและย่อขยายได้ (จำตำแหน่งไว้) · จอแคบฝังเสมอ · ไม่มีปุ่มปิด */
function twinDock(r, gm){
  const wrap = h('div',{class:'twindock-wrap'});
  const panel = (key, body)=>{ const floating = TWin.float[key] && !isNarrow();
    const head = h('h3',{class:'row',style:'justify-content:space-between'}, h('span',{text:TWIN_TITLE[key].replace(/^\S+\s/,'')}), isNarrow() ? null : h('button',{class:'small ghost',title: floating ? 'เก็บกลับเข้าคอลัมน์' : 'ปลดเป็นหน้าต่างลอย ลากวางที่ไหนก็ได้',onclick:()=>{ TWin.float[key] = !TWin.float[key]; TWin.persist(); renderTable(); },text: floating ? '⇲ เก็บกลับ' : '⇱ ลอย'}));
    return h('div',{class:'card twin-card',style:'margin-top:8px'}, head, floating ? h('p',{class:'dim',style:'font-size:12px;margin:4px 0 0',text:'กำลังลอยอยู่เป็นหน้าต่างบนจอ ลากหัวหน้าต่างเพื่อย้าย'}) : body); };
  wrap.append(panel('order', orderBody(r, gm)), panel('tok', tokBody(r, gm)));
  return wrap;
}
/* ลำดับที่ใช้แสดงหมาก: ตามลำดับเทิร์นเมื่อเริ่มสู้แล้ว ที่เหลือต่อท้าย (ผู้ใช้เคาะ 9 พ.ย. 2026) */
function tokInitials(t){ return t.kind==='asset' ? (t.icon||'📦') : (t.name||'?').slice(0,2); } // Asset ใช้อีโมจิ หมากอื่นใช้อักษรย่อ
/* รูปแทนตัวของหมากในรายการและแผงหมาก: ภาพ → ไอคอนจากคลังไอคอน (สีตามที่ตั้ง) → อักษรย่อหรืออีโมจิ */
function tokAvatar(t, cls){ if (t.thumb) return h('img',{class:cls,src:t.thumb,alt:''}); const ico = icoClean(t.ico); if (ico){ const el = h('div',{class:cls+' hasico',style:`background:${ico.b}`}); el.append(icoSvg(ico)); return el; } return h('div',{class:cls,text: tokInitials(t)}); }
function orderedTokens(r){ const all = r.tokens||[]; const toks = [...all.filter(t=>t.kind!=='asset'), ...all.filter(t=>t.kind==='asset')]; /* v1.18: Asset ไม่เข้าลำดับเทิร์น อยู่ท้ายรายการเสมอ */ if (!r.enc || !r.enc.active) return toks.slice(); const order = r.enc.order||[]; const out = []; for (const id of order){ const t = toks.find(x=>x.id===id); if (!t) continue; out.push(t); for (const s of toks) if (s.turnWith===id) out.push(s); /* ร่างแฝดที่ใช้เทิร์นร่วมกันอยู่ถัดกัน */ } return [...out, ...toks.filter(t=>!out.includes(t))]; }
function orderBody(r, gm){
  const box = h('div',{class:'twin-order'});
  const enc = r.enc||{active:false, round:0, turnIdx:0, order:[]};
  const head = h('div',{class:'row',style:'gap:6px;margin-bottom:6px'}, enc.active ? tag(`รอบ ${enc.round}`,'neg') : tag('ยังไม่เริ่มสู้'));
  if (gm){ if (enc.active) head.append(h('button',{class:'primary small',onclick:()=>{ enc.turnIdx++; if (enc.turnIdx>=enc.order.length){ enc.turnIdx=0; enc.round++; tickConditions(r); } Table.save(); const t=r.tokens.find(x=>x.id===enc.order[enc.turnIdx]); if (t && !t.hidden) Table.post({kind:'sys',who:'',text:`เทิร์นของ ${t.name} (รอบ ${enc.round})`}); },text:'เทิร์นถัดไป →'}), h('button',{class:'small',onclick:()=>rollInitiative(r),text:'ทอยใหม่'}), h('button',{class:'small ghost',onclick:()=>{ r.enc={active:false,round:0,turnIdx:0,order:[]}; for (const t of r.tokens){ delete t.initRoll; delete t.turnWith; } Table.save(); Table.post({kind:'sys',who:'',text:'จบฉากต่อสู้'}); },text:'จบการต่อสู้'}));
    else head.append(h('button',{class:'primary small',onclick:()=>rollInitiative(r),text:'เริ่มการต่อสู้ (ทอย 2d6 + Initiative)'})); }
  else if (enc.active){ const t=r.tokens.find(x=>x.id===enc.order[enc.turnIdx]); if (t && t.ownerId===Store.me) head.append(tag('ถึงเทิร์นของคุณ: 1 Swift 1 Basic 1 Cast','ok')); }
  box.append(head);
  const gmView = gm; const vis = gm ? null : computeVisibility(r, Store.me);
  const canSee = (t)=> (gmView || !t.hidden || ownsTok(t)) && (!vis || ownsTok(t) || vis.has(t.x+','+t.y));
  const cur = enc.active ? enc.order[enc.turnIdx] : null;
  const list = h('div',{class:'toklist compact'});
  const toks = orderedTokens(r).filter(canSee); let ordNo = 0;
  toks.forEach((t, i)=>{
    const inOrder = enc.active && (enc.order||[]).includes(t.id); const shared = enc.active && !!t.turnWith; if (inOrder) ordNo++;
    const row = h('div',{class:`tok ${t.kind}${t.hidden?' hid':''}${(cur===t.id || (cur && t.turnWith===cur))?' turn':''}${Table.sel===t.id?' sel':''}`,onclick:(e)=>{ if (e.target.closest('button,select,input,a')) return; Table.sel = Table.sel===t.id ? null : t.id; renderTable(); }},
      inOrder ? h('span',{class:'ord num',text:String(ordNo)}) : h('span',{class:'ord dim',title: shared ? 'ใช้เทิร์นร่วมกับอีกร่าง (แฝดแชร์ Action Point)' : '',text: shared ? '↳' : '·'}),
      tokAvatar(t, 'av'),
      h('div',{class:'nm'}, h('div',null, h('span',{text:t.name}), t.body ? h('span',{class:'dim',title:'ร่างของแฝด (Twinborn)',text:` [${t.body}]`}) : null, t.gmRun ? h('span',{class:'dim',title:'เดินแยกจากอีกร่าง GM คุมหลังฉาก',text:' 🚶GM'}) : null, t.hidden? h('span',{class:'dim',text:' (ซ่อน)'}):null, t.inside? h('span',{class:'dim',text:' 🦷'}):null, t.inWater? h('span',{title:'อยู่ในน้ำลึก',text:' 🌊'}):null),
        h('div',{class:'mini'}, t.kind==='asset' ? h('span',{class:'dim',text:'Asset'}) : null, (t.kind!=='asset' || t.hpMax>0) ? h('span',{class:'num',text:`HP ${t.hp}/${t.hpMax}`}) : null, t.sanMax? h('span',{class:'num',text:`SAN ${t.san}/${t.sanMax}`}):null, t.kind==='asset' ? null : (enc.active && t.initRoll!=null ? h('span',{class:'num',title:'ผลทอย Initiative',text:`⚡${t.initRoll}`}) : h('span',{class:'num dim',text:`Init ${signed(t.init||0)}`})), (t.conds||[]).length ? h('span',{text:(t.conds||[]).map(c=>condIcon(c.id)).join('')}) : null)));
    list.append(row);
  });
  if (!toks.length) list.append(h('div',{class:'dim',style:'font-size:13px',text:'ยังไม่มีหมากบนบอร์ด'}));
  box.append(list);
  box.append(h('p',{class:'dim',style:'font-size:11.5px;margin:8px 0 0',text:'ฉากหนึ่งยาว 1 นาที เทิร์นละ 6 วินาที ฝ่ายซุ่มโจมตีได้เริ่มก่อนเสมอ ทอยลำดับใหม่เมื่อเปลี่ยนฉาก · คลิกชื่อเพื่อเลือกหมาก'}));
  return box;
}
/* ---- หน้าต่างหมากที่เลือก: ค่าชีวิต สถานะ ปุ่มควบคุม คำอธิบาย และแผงต่อสู้ของตัวละคร (เจ้าของหรือ GM) ---- */
function tokBody(r, gm){
  const t = Table.sel ? (r.tokens||[]).find(x=>x.id===Table.sel) : null;
  if (!t) return h('p',{class:'dim',style:'font-size:13px;margin:0',text:'คลิกหมากบนบอร์ดหรือชื่อในลำดับเทิร์นเพื่อดูรายละเอียด · ลากหมากของคุณไปวางช่องอื่นเพื่อเคลื่อนที่'});
  const owner = t.ownerId===Store.me; const mine = gm || Table.localMode || (owner && !t.gmRun); // ร่างแฝดที่ GM คุมหลังฉาก เจ้าของดูได้แต่ไม่ได้บังคับ
  const box = h('div',{class:'twin-tok'});
  const eater = t.inside ? r.tokens.find(o=>o.id===t.inside) : null;
  const isAsset = t.kind==='asset';
  box.append(h('div',{class:'row',style:'gap:8px;align-items:center'}, tokAvatar(t, 'av big'+(isAsset?' asset':'')),
    h('div',{style:'flex:1;min-width:0'}, h('div',{style:'font-weight:600'}, t.name, t.hidden? h('span',{class:'dim',text:' (ซ่อน)'}):null), h('div',{class:'mini'}, tag(t.kind==='pc' ? 'ตัวละคร' : isAsset ? 'Asset' : 'NPC', t.kind==='pc' ? 'stat' : isAsset ? 'prop' : 'neg'), t.body ? tag('แฝด ร่าง '+t.body,'prop') : null, t.gmRun ? tag('🚶 GM คุมหลังฉาก','warn') : null, t.ownerName? h('span',{class:'dim',text:t.ownerName}):null, eater ? h('span',{class:'tag neg',text:'🦷 อยู่ในตัว '+eater.name}) : h('span',{class:'num dim',text:`(${t.x},${t.y})`}), t.inWater? tag('🌊 ในน้ำลึก','warn'):null, t.aquatic? tag('🐟 สัตว์น้ำ','stat'):null, t.climb? tag('🧗 ปีนป่าย','stat'):null, cellClimbable(r.map, t.x, t.y) && !t.inside ? tag((cellCling(r.map,t.x,t.y) ? 'เกาะ' : 'อยู่บน') + (TILE[mapCell(r.map,t.x,t.y)]||{}).th, 'warn') : null, t.nv? tag('👁 Dark Vision'):null, t.torch? tag('🔥 แหล่งแสง','prop'):null))));
  // ค่าชีวิต
  const vital = (label, key, maxKey, cls)=>{ const v = t[key]||0, mx = t[maxKey]||0; return h('div',{class:'vital'}, h('span',{class:'vl '+cls,text:label}), mine ? h('button',{class:'small',title:label+' −1',onclick:()=>{ tokenVitals(t, key, v-1); Table.save(); }},'−') : null, h('b',{class:'num',text:`${v} / ${mx}`}), mine ? h('button',{class:'small',title:label+' +1',onclick:()=>{ tokenVitals(t, key, Math.min(mx, v+1)); Table.save(); }},'+') : null, mine ? h('input',{type:'number',value:v,style:'width:56px',onchange:(e)=>{ tokenVitals(t, key, +e.target.value||0); Table.save(); }}) : null); };
  // NPC: Toughness ค่าเดียว GM ลดได้จากโต๊ะ (ตัวละครผู้เล่นใช้ตารางต่ออวัยวะในแผงต่อสู้ด้านล่าง)
  const npcTough = isAsset ? null : (!t.charId && gm) ? h('div',{class:'vital'}, h('span',{class:'vl',text:'Toughness'}), h('button',{class:'small',title:'Toughness −1',onclick:()=>{ t.tgh = Math.max(0, (t.tgh??t.tghMax??1) - 1); if (t.tghMax==null) t.tghMax = Math.max(1, t.tgh+1); Table.save(); }},'−'), h('b',{class:'num'+((t.tgh??1)<=0?' bad':''),text: t.tgh==null ? (t.tghMax!=null ? `${t.tghMax} / ${t.tghMax}` : '- / -') : `${t.tgh} / ${t.tghMax??'-'}`}), h('button',{class:'small',title:'Toughness +1',onclick:()=>{ const mx = t.tghMax??1; t.tgh = Math.min(mx, (t.tgh??mx) + 1); if (t.tghMax==null) t.tghMax = mx; Table.save(); }},'+'), h('input',{type:'number',min:0,value:t.tghMax??'',placeholder:'สูงสุด',title:'Toughness สูงสุดของ NPC นี้',style:'width:64px',onchange:(e)=>{ const mx = Math.max(0, +e.target.value||0); t.tghMax = mx; if (t.tgh==null || t.tgh>mx) t.tgh = mx; Table.save(); }})) : (!t.charId && t.tghMax!=null ? h('div',{class:'vital'}, h('span',{class:'vl',text:'Toughness'}), h('b',{class:'num'+((t.tgh??1)<=0?' bad':''),text:`${t.tgh??t.tghMax} / ${t.tghMax}`})) : null);
  // Asset: HP มีเมื่อ GM ตั้งความทนทานไว้ (ใส่ HP สูงสุดได้จากแผงนี้) ไม่มี Sanity Toughness หรือ Initiative
  const assetHp = isAsset && gm ? h('div',{class:'vital'}, h('span',{class:'vl',text:'HP สูงสุด'}), h('input',{type:'number',min:0,value:t.hpMax||0,title:'0 = ไม่ติดตามความทนทานของสิ่งของนี้',style:'width:64px',onchange:(e)=>{ const mx = Math.max(0, Math.round(+e.target.value||0)); t.hpMax = mx; t.hp = mx ? Math.min(mx, t.hp > 0 ? t.hp : mx) : 0; Table.save(); }}), h('span',{class:'dim',style:'font-size:11.5px',text:'0 = ไม่ติดตาม'})) : null;
  box.append(h('div',{class:'vitals'}, (!isAsset || t.hpMax>0) ? vital('HP','hp','hpMax','hp') : null, assetHp, t.sanMax ? vital('Sanity','san','sanMax','san') : null, npcTough, isAsset ? null : h('div',{class:'vital'}, h('span',{class:'vl',text:'Init'}), h('b',{class:'num',text:signed(t.init||0)}), r.enc&&r.enc.active&&t.initRoll!=null ? h('span',{class:'dim',text:`ทอยได้ ${t.initRoll}`}) : null)));
  if (t.charId && t.kind==='pc') box.append(h('p',{class:'dim',style:'font-size:11px;margin:2px 0 0',text: t.body ? `HP ของร่าง ${t.body} แยกจากอีกร่าง ส่วน Sanity ใช้ร่วมกันทั้งสองร่าง ซิงก์กับชีทของเจ้าของ` : 'HP และ Sanity ซิงก์กับชีทของเจ้าของ ฝั่งที่แก้ล่าสุดเป็นค่าที่ใช้'}));
  // แฝด (Twinborn): แยกทาง/กลับมารวม และช่องทางถามตอบลับระหว่างเจ้าของกับ GM
  if (t.body && (gm || owner || Table.localMode)){ const sibs = siblingTokens(t); const trow = h('div',{class:'row twinrow',style:'gap:4px;margin-top:6px'});
    if (t.gmRun) trow.append(h('button',{class:'small',title:'กลับมาอยู่กับอีกร่าง ผู้เล่นบังคับทั้งสองร่างตามเดิม',onclick:()=>setTokenGmRun(r, t, false),text:'🤝 กลับมารวมกับอีกร่าง'}));
    else trow.append(h('button',{class:'small ghost',title:'ร่างนี้เดินแยกจากอีกร่างโดยเจตนา GM คุมหลังฉากแทน ผู้เล่นบังคับอีกร่าง',onclick:()=>setTokenGmRun(r, t, true),text:'🚶 แยกทาง: ให้ GM คุมร่างนี้'}));
    if (owner && !t.gmRun && sibs.some(s=>s.gmRun)){ const c0 = Store.get(t.charId); if (c0) trow.append(h('button',{class:'small',title:'ส่งคำถามถึง GM แบบลับ (เห็นเฉพาะคุณกับ GM)',onclick:()=>askAboutTwin(c0),text:'💬 ถาม GM ถึงอีกร่าง'})); }
    if (gm && t.gmRun && !Table.localMode) trow.append(h('button',{class:'small',title:'ส่งข้อความลับถึงเจ้าของตัวละคร (เล่าเหตุการณ์ หรือถามให้เลือก)',onclick:()=>tellTwinOwner(t),text:'💬 เล่าให้เจ้าของฟัง (ลับ)'}));
    box.append(trow);
    if (t.gmRun) box.append(h('p',{class:'dim',style:'font-size:11.5px;margin:4px 0 0',text: gm ? 'ร่างนี้เดินแยกจากอีกร่าง คุณคุมแทนผู้เล่นอยู่หลังฉาก ผู้เล่นถามถึงเหตุการณ์ได้ตลอดเวลา และยังเป็นคนเลือกเมื่อร่างนี้เจอเหตุการณ์ที่ต้องเลือก' : 'ร่างนี้เดินแยกไป GM คุมอยู่หลังฉาก ถามถึงเหตุการณ์ได้ตลอดเวลา และคุณยังเป็นคนเลือกเมื่อร่างนี้เจอเหตุการณ์ที่ต้องเลือก'})); }
  if (mine && !t.inside && !isAsset) box.append(h('p',{class:'dim sightrow',style:'font-size:12px;margin:4px 0 0'}, '👁 ระยะมองเห็น (', h('span',{text:lightLabel(r.light||'low')}), '): ', h('span',{text:sightLabel(t, r.light||'low')})));
  if (mine && !t.inside && !isAsset){ const ms = tokenMoveSpeed(t); if (ms) box.append(h('p',{class:'dim moverow',style:'font-size:12px;margin:4px 0 0',title:'ระยะต่อ 1 Maneuver ตามความเร็วของตัวละคร (Non เคาะ 13 พ.ย. 2026) · ช่องเดินช้านับ 2 ช่อง'}, '🏃 เคลื่อนที่: ', h('span',{text: moveSpeedText(ms, true)}), ms.notes.length ? h('span',{class:'warn',text:' · ' + ms.notes.join(' · ')}) : null)); }
  // สถานะ
  const condRow = h('div',{class:'row',style:'gap:6px;margin-top:6px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'สถานะ'}), condChips(t, r, gm) || h('span',{class:'dim',style:'font-size:12px',text:'ไม่มี'}), gm ? h('button',{class:'small ghost',onclick:()=>condModal(t, r),text:'+ สถานะ'}) : null);
  box.append(condRow);
  // ปุ่มควบคุม
  if (mine){
    const ctl = h('div',{class:'row',style:'gap:4px;margin-top:8px'});
    if (t.charId && (gm || t.ownerId===Store.me || Store.isDevUid)) ctl.append(h('button',{class:'small',onclick:()=>{ location.hash='#sheet-'+t.charId; },text:'📜 ชีท'}));
    ctl.append(h('button',{class:'small ghost'+(t.torch?' on':''),title:'ถือแหล่งแสง (คบเพลิง ตะเกียง) ส่องรอบตัว 4 ช่องในที่มืด',onclick:()=>{ t.torch=!t.torch; Table.save(); if (!t.hidden) Table.post({kind:'sys',who:'',text:`${t.name} ${t.torch?'จุดแหล่งแสง':'ดับแหล่งแสง'}`}); },text:'🔥 แสง'}));
    if (gm && !isAsset) ctl.append(h('button',{class:'small ghost'+(t.nv?' on':''),title:'มองเห็นในความมืด (Dark Vision)',onclick:()=>{ t.nv=!t.nv; Table.save(); },text:'👁 Dark Vision'}));
    if (gm && !isAsset) ctl.append(h('button',{class:'small ghost'+(t.aquatic?' on':''),title:'สัตว์น้ำ/เงือก: อยู่ในน้ำลึกแล้วยังโจมตีได้และไม่เสียเทิร์น',onclick:()=>{ t.aquatic=!t.aquatic; Table.save(); },text:'🐟 สัตว์น้ำ'}));
    if (!isAsset) ctl.append(h('button',{class:'small ghost'+(t.climb?' on':''),title:'ปีนป่าย: เข้าช่องต้นไม้ เสา เหว และขอบหน้าผาได้ (เกาะขอบเหว/หน้าผา = Prone ตลอดเวลาที่เกาะ)',onclick:()=>{ t.climb=!t.climb; Table.save(); if (!t.hidden) Table.post({kind:'sys',who:'',text:`${t.name} ${t.climb?'เตรียมปีนป่าย 🧗':'เลิกปีนป่าย'}`}); },text:'🧗 ปีนป่าย'}));
    if (gm && t.charId) ctl.append(h('button',{class:'small ghost',title:'ใส่ไอเทมลงกระเป๋าของตัวละครนี้',onclick:()=>giveItemModal(t, r),text:'🎁 ไอเทม'}));
    if (gm && !t.charId) ctl.append(h('button',{class:'small ghost tokicobtn'+(t.ico?' on':''),title:'เลือกไอคอนของหมากนี้จากคลังไอคอน และปรับสีไอคอนกับสีพื้น',onclick:()=>tokenIconModal(t),text:'🎨 ไอคอน'}));
    if (gm && !t.charId) ctl.append(h('button',{class:'small ghost libsavetok',title:'เก็บหมากนี้ (ชื่อ ค่าพลัง คำอธิบาย บันทึก) เข้าคลัง NPC / Asset ของคุณ ไว้ใช้ในโต๊ะอื่น',onclick:async()=>{ await saveTokenToLibrary(t); Table.save(); },text:'💾 เก็บเข้าคลัง'}));
    if (gm) ctl.append(h('button',{class:'small ghost',title:t.hidden?'เปิดเผยให้ผู้เล่นเห็น':'ซ่อนจากผู้เล่น',onclick:()=>{t.hidden=!t.hidden; Table.save(); if(!t.hidden) Table.post({kind:'sys',who:'',text:`${t.name} ปรากฏตัวที่ (${t.x},${t.y})`});},text:t.hidden?'👁 เปิดเผย':'🙈 ซ่อน'}));
    ctl.append(h('button',{class:'small ghost',style:'margin-left:auto',title: gm ? 'เอาออกจากบอร์ด (ลบสำเนาชีทในห้องด้วย)' : 'ถอนตัวละครออกจากบอร์ด (GM จะไม่เห็นชีทอีก)',onclick:()=>{ if (!confirm(`เอา ${t.name} ออกจากบอร์ด?`)) return; detachToken(r, t); passSharedTurn(r, t); r.tokens=r.tokens.filter(x=>x!==t); r.enc.order=(r.enc.order||[]).filter(x=>x!==t.id); if (Table.sel===t.id) Table.sel=null; dropTokenCopy(r, t); Table.save(); },text:'✕ เอาออก'}));
    box.append(ctl);
  }
  // คำอธิบาย (ผู้เล่นเห็น) และบันทึก GM (ลับ)
  if (gm){
    const desc = h('textarea',{placeholder:'คำอธิบายหมากนี้ที่ผู้เล่นเห็น (รูปร่าง ท่าทาง สิ่งที่สังเกตได้)',style:'min-height:48px;font-size:12.5px'}); desc.value = t.desc||''; desc.onblur = ()=>{ if (desc.value !== (t.desc||'')){ t.desc = desc.value; Table.save(); } };
    const note = h('textarea',{placeholder:'บันทึกลับของ GM (สแตต แผนการ จุดอ่อน) ผู้เล่นไม่เห็น',style:'min-height:48px;font-size:12.5px'}); note.value = t.note||''; note.onblur = ()=>{ if (note.value !== (t.note||'')){ t.note = note.value; Table.save(); } };
    box.append(h('div',{style:'margin-top:8px'}, h('div',{class:'kicker',text:'คำอธิบาย (ผู้เล่นเห็น)'}), desc), h('div',{style:'margin-top:6px'}, h('div',{class:'kicker',text:'บันทึก GM (ลับ)'}), note));
  } else if (t.desc) box.append(h('p',{class:'desc',style:'margin:8px 0 0;font-size:13px',text:t.desc}));
  // แผงต่อสู้ของตัวละคร
  if (t.charId){ const c = Store.get(t.charId); if (c && (Store.isMine(c) || gm || Store.isDevUid)) box.append(combatPanel(c, t, gm)); }
  return box;
}
/* ค่าที่ผู้เล่นต้องใช้ตอนสู้: อาวุธ + Might เอฟเฟกต์ Toughness เกราะ สกิลและ Trait ที่เกี่ยวกับการต่อสู้ (ผู้ใช้เคาะ 9 พ.ย. 2026) */
const COMBAT_RX = /Attack|Parry|Evade|Damage|\bCV\b|Might|Sight|Defend|โจมตี|ป้องกัน|Reaction|Swift|Toughness|Armor|เกราะ|Cover|Perfect|Initiative|Reflex|Unbalanced|Guard Break|PDMG|หลบ|Melee|Range|ประชิด|ระยะไกล|Grab|Stance|กระบวนท่า/;
function combatPanel(c, t, gm){
  const box = h('div',{class:'combat-panel'});
  const min = c.shareMode==='min' && !Store.isMine(c);
  let d = null; try { d = compute(c); } catch(e){}
  if (Store.isMine(c) && d) { ensureSheetState(c, d); d = compute(c); }
  else { try { migrateNames(c); migrateItemText(c); migrateStackWeights(c); } catch(e){} } // v1.22.1: ชื่อของที่ถูกตัดออกจากคลัง (หนังยางเหวี่ยงหิน → สลิงหนัง) ย้ายก่อนเทียบข้อความ · v1.22: น้ำหนักต่อชิ้นของของหลายชิ้นด้วย · v1.20: สำเนาชีทของคนอื่นในห้อง ย้ายข้อความเก่าของไอเทมในหน่วยความจำให้ GM เห็นข้อความปัจจุบัน
  const cur = c.current || {};
  box.append(h('div',{class:'kicker',style:'margin-top:10px',text:'ค่าสำหรับการต่อสู้'}));
  if (hasFleshforge(c) && c.fleshforge && c.fleshforge.item) box.append(...[h('div',{class:'gives'}, tag('🧬 Fleshforge: '+c.fleshforge.item,'prop')), c.fleshforge.effect ? h('details',{class:'cp-d'}, h('summary',{text:'เอฟเฟกต์ของไอเทมมีชีวิต'}), h('div',{class:'desc',style:'font-size:12px'}, T(c.fleshforge.effect))) : null].filter(Boolean));
  if (d) box.append(h('div',{class:'gives'}, tag(`Might ${signed(d.might)}`,'stat sc sc-STR'), tag(`Sight ${signed(d.sight)}`,'stat sc sc-PER'), tag(`Reflex ${signed(d.reflex)}`,'stat sc sc-AGI'), tag(`Parry Dice ${d.parryDice}`,'stat sc sc-VIT'), tag(`Initiative ${signed(d.initiative)}`,'stat sc sc-PER'), tag(`Passive PER ${d.passivePer}`,'stat sc sc-PER')));
  // อาวุธ
  if (!min){ const eq = c.equip||{}; const ws = (typeof WEAPON_SLOTS!=='undefined' ? WEAPON_SLOTS : ['weapon1','weapon2','shield']).map(k=>[k, eq[k]]).filter(([k,e])=>e && (e.name||'').trim());
    const wbox = h('div',{class:'cp-sec'}, h('b',{text:'สายคาดอาวุธ'}));
    if (!ws.length) wbox.append(h('div',{class:'dim',style:'font-size:12px',text:'ยังไม่ได้สวมอาวุธ (สวมได้ในถุงย่ามที่ชีท)'}));
    for (const [k,e] of ws){ const eff = String(e.effect||''); const dmg = (eff.match(/(\d+)\s*PDMG/)||[])[1]; const pd = (eff.match(/\+(\d+)\s*Parry Dice/)||[])[1];
      wbox.append(h('div',{class:'cp-w'}, h('div',null, h('span',{class:'dim',style:'font-size:11px',text:(k==='shield'?'โล่/มือรอง':k==='weapon1'?'อาวุธหลัก':'อาวุธรอง')+' '}), h('b',{class:hueCls(e.name, eff).trim(),text:e.name.replace(/\s*\(.*?\)\s*/g,' ').trim()}), dmg && d ? h('span',{class:'num',style:'margin-left:6px',text:` ${dmg} PDMG + Might ${signed(d.might)} = ${+dmg + d.might}`}) : null, pd ? h('span',{class:'num dim',style:'margin-left:6px',text:` +${pd} Parry Dice`}) : null, weaponStrShort(eff, d) ? h('span',{class:'tag neg strshort',style:'margin-left:6px',title:'อาวุธนี้ระบุค่า STR ที่ต้องมี STR ไม่ถึงจึงโจมตีด้วย Disadvantage',text:`STR ${weaponStrNeed(eff)} ไม่ถึง: โจมตีติด Disadvantage`}) : null),
        eff ? h('details',null, h('summary',{text:'เอฟเฟกต์'}), h('div',{class:'desc',style:'font-size:12px'}, T(eff))) : null)); }
    box.append(wbox); }
  // Toughness + เกราะ
  const tb = h('table',{class:'t cp-t'}, h('thead',null, h('tr',null, h('th',{text:'อวัยวะ (เลขที่โดน)'}), h('th',{text:'Toughness'}), h('th',{text:'เกราะ A/B'}))));
  // Toughness ต่ออวัยวะ: เจ้าของหรือ GM กด ± ได้จากโต๊ะ (ผู้ใช้เคาะ 9 พ.ย. 2026) ค่าอยู่บนหมาก (t.tough) แล้วซิงก์เข้าชีทเหมือน HP/Sanity
  const mine = gm || Table.localMode || ownsTok(t); const tmax = d ? d.toughness : null; // ร่างแฝดที่ GM คุมหลังฉาก เจ้าของแก้ Toughness จากหมากนี้ไม่ได้
  // v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026): แฝดแต่ละร่างมี Toughness และเกราะของตัวเอง (ร่าง B ใช้ tough2 / armor2) · ค่าติดลบได้ถึงค่าเต็ม · เหลือ 0 ทอยตารางบาดแผลฉกรรจ์
  const tk = toughKeyOf(t); const curT = cur[tk] || {}; const armorMap = (bodyOf(t)==='B' ? c.armor2 : c.armor) || {};
  const tval = (k)=>{ const v = (t.tough||{})[k]; if (v!=null) return v; const cv = curT[k]; if (cv!=null) return cv; return tmax; };
  const setT = (k, v)=>{ if (!t.tough) t.tough = {}; for (const [kk] of DATA.meta.bodyParts) if (t.tough[kk]==null){ const cv = tval(kk); if (cv!=null) t.tough[kk] = cv; } const before = t.tough[k]; t.tough[k] = tmax!=null ? Math.max(toughFloor(tmax), Math.min(tmax, v)) : v; t.vitalsAt = Date.now(); Table.save();
    if (t.tough[k] === 0 && before > 0) Table.post({kind:'sys', who:'', text:`${t.name}: ${partLabel(k)}เหลือ Toughness 0 ทอยตารางบาดแผลฉกรรจ์ของส่วนนี้`});
    else if (tmax!=null && t.tough[k] <= -tmax && before > -tmax) Table.post({kind:'sys', who:'', text:`${t.name}: Toughness ของ${partLabel(k)}ติดลบถึงค่าเต็ม ${(k==='head' || k==='torso') ? 'ให้ผลเท่ากับ Mortal Wound (HP เหลือ 0 เข้าสู่ใกล้ตาย)' : 'ส่วนนี้ขาด'}`}); };
  const tokWounds = ()=> Array.isArray(t.wounds) ? t.wounds : woundsOf(cur, bodyOf(t)).map(woundLite);
  const tokWound = (k)=>{ const res = rollWound(k); const row = res.row || {name:'ไม่พบตาราง', text:''}; t.wounds = [...tokWounds(), {part:k, die:res.die, name:row.name, text:row.text, at:Date.now()}]; t.vitalsAt = Date.now(); Table.save(); Table.post({kind:'sys', who:'', text:`${t.name}: บาดแผลฉกรรจ์ที่${partLabel(k)} ทอย 1d6 ได้ ${res.die} ${row.name} · ${row.text}`}); toast(`${partLabel(k)}: ${row.name} (ทอยได้ ${res.die})`); };
  const tokWoundDrop = (w)=>{ t.wounds = tokWounds().filter(x=>x!==w && !((x.at||0)===(w.at||0) && x.part===w.part && x.die===w.die)); t.vitalsAt = Date.now(); Table.save(); };
  for (const [k,label] of DATA.meta.bodyParts){ const v = tval(k); const stt = toughState(k, v, tmax);
    tb.append(h('tr',null, h('td',null, label, h('span',{class:'dim',style:'font-size:10.5px',title:'ผลรวมเต๋าโจมตี 2 ลูกที่เข้าส่วนนี้',text:' '+(HIT_ATTACK[k]||[]).join(',')})), h('td',{class:'num'+((v??1) <= 0 ? ' bad' : '')}, mine && v!=null ? h('button',{class:'small tadj',title:label+' Toughness −1',onclick:()=>setT(k, v-1)},'−') : null, h('span',{text: v==null ? '-' : (tmax!=null ? `${v}/${tmax}` : String(v))}), mine && v!=null ? h('button',{class:'small tadj',title:label+' Toughness +1',onclick:()=>setT(k, v+1)},'+') : null,
        stt ? h('span',{class:'tstate ts-'+stt,text:toughStateText(stt)}) : null, (stt==='wound' && mine) ? h('button',{class:'small ghost tadj woundbtn',dataset:{part:k},title:'ทอย 1d6 ตามตารางบาดแผลฉกรรจ์ของส่วนนี้แล้วประกาศในแชต',onclick:()=>tokWound(k)},'🎲') : null), h('td',{class:'num',text:armorMap[k]||'-'}))); }
  const twl = tokWounds();
  box.append(h('div',{class:'cp-sec'}, h('b',{text:'Toughness และเกราะ'}), h('div',{class:'tablewrap'}, tb),
    twl.length ? h('div',{class:'woundlist'}, twl.map(w=>h('div',{class:'wound'}, h('b',{text:`${partLabel(w.part)}: ${w.name}`}), h('span',{class:'dim',text:` (ทอยได้ ${w.die})`}), mine ? h('button',{class:'small ghost',title:'ลบบาดแผลนี้ออกจากรายการ (รักษาหายแล้วหรือจดผิด)',onclick:()=>tokWoundDrop(w),text:'×'}) : null, w.text ? h('div',{class:'desc',style:'font-size:11.5px'}, T(w.text)) : null))) : null,
    mine ? h('p',{class:'dim',style:'font-size:11px;margin:4px 0 0',text:'Toughness และบาดแผลที่แก้ตรงนี้ซิงก์เข้าชีทของเจ้าของเหมือน HP และ Sanity · เหลือ 0 ทอยตารางบาดแผลฉกรรจ์ ติดลบได้ถึงค่าเต็ม'}) : null));
  if (min){ box.append(h('p',{class:'dim',style:'font-size:11.5px',text:'เจ้าของแชร์เฉพาะค่าหลัก อาวุธ สกิล และ Trait ไม่เปิดเผย'})); return box; }
  // สกิลและ Trait ที่เกี่ยวกับการต่อสู้
  const kin = c.kin ? KIN[c.kin] : null;
  const skills = (typeof allSkills==='function' ? allSkills(c) : (c.skills||[])).map(n=>SKILL_BY_NAME[n]).filter(sk=>sk && COMBAT_RX.test((sk.type||'')+' '+(sk.flavor||'')+' '+(sk.effect||'')));
  const traits = []; if (kin){ for (const x of [...(kin.traits||[]), ...(kin.benefits||[])]) if (COMBAT_RX.test(x.text||'')) traits.push({name:`${x.name} (${x.nameEn||''})`, text:x.text, cls:'ok'}); for (const x of kin.hindrances||[]) if (COMBAT_RX.test(x.text||'')) traits.push({name:`${x.name} (${x.nameEn||''})`, text:x.text, cls:'neg'}); for (const code of [c.childhood, c.adulthood]){ const b = findBg(kin, code); if (b && b.text && COMBAT_RX.test(b.text)) traits.push({name:b.name, text:b.text, cls:'prop'}); } }
  for (const x of [...(c.customTraits||[]), ...(c.customProfs||[])]) if (COMBAT_RX.test((x.name||'')+' '+(x.text||''))) traits.push({name:x.name+' (เพิ่มเอง)', text:x.text||'', cls:'ok'}); // Trait / Proficiency Trait ที่ผู้เล่นเพิ่มเองในชีท
  const sbox = h('div',{class:'cp-sec'}, h('b',{text:`สกิลที่ใช้ในการต่อสู้ (${skills.length})`}));
  for (const sk of skills) sbox.append(h('details',{class:'cp-d'}, h('summary',null, h('span',{class:hueCls(sk.nameEn, sk.type, sk.flavor, sk.effect).trim(),text:skLabel(sk)}), h('span',{class:'dim',style:'font-size:11px',text:` ${sk.type? sk.type.slice(0,30) : ''}${sk.cost? ' · '+sk.cost : ''}`})), sk.components? h('div',{style:'margin:3px 0'}, compTag(sk.components, sorceryLv(c))) : null, sk.flavor? h('div',{class:'flavor',style:'font-size:12px'}, T(sk.flavor)) : null, h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect||''))));
  if (!skills.length) sbox.append(h('div',{class:'dim',style:'font-size:12px',text:'ไม่มี'}));
  const tbox = h('div',{class:'cp-sec'}, h('b',{text:`Trait ที่เกี่ยวกับการต่อสู้ (${traits.length})`}));
  for (const tr of traits) tbox.append(h('details',{class:'cp-d'}, h('summary',null, h('span',{class:hueCls(tr.name, tr.text).trim(),text:tr.name})), h('div',{class:'desc',style:'font-size:12px'}, T(tr.text))));
  if (!traits.length) tbox.append(h('div',{class:'dim',style:'font-size:12px',text:'ไม่มี'}));
  box.append(sbox, tbox);
  return box;
}
/* ---- ซิงก์ HP/Sanity ระหว่างหมากกับชีท: ฝั่งที่แก้ล่าสุดชนะ (token.vitalsAt เทียบ c.current.at) ---- */
function bodyOf(t){ return t && t.body==='B' ? 'B' : 'A'; }
function hpKeyOf(t){ return bodyOf(t)==='B' ? 'hp2' : 'hp'; } // แฝด: ร่าง B ใช้ c.current.hp2
function toughKeyOf(t){ return bodyOf(t)==='B' ? 'tough2' : 'tough'; } // v1.15: แฝดแต่ละร่างมี Toughness ของตัวเอง ร่าง B ใช้ c.current.tough2
function siblingTokens(t){ const r = Table.room; return (t && t.charId && r) ? (r.tokens||[]).filter(x=>x!==t && x.charId===t.charId) : []; }
/* หมากนี้เป็นของฉันและฉันบังคับเอง (ร่างแฝดที่ GM คุมหลังฉากไม่นับ) */
function ownsTok(t){ return !!t && t.ownerId===Store.me && !t.gmRun; }
function tokenVitals(t, key, value){ t[key] = value; t.vitalsAt = Date.now(); if (key==='san') for (const s of siblingTokens(t)){ s.san = value; s.vitalsAt = t.vitalsAt; } /* แฝด: Sanity ใช้ร่วมกันทั้งสองร่าง */ }
/* v1.15 บาดแผลฉกรรจ์ของแต่ละร่าง: เก็บในชีท (c.current.wounds มี body กำกับ) และบนหมาก (t.wounds) ซิงก์สองทางเหมือน Toughness หมากที่ยังไม่เคยมีรายการ (undefined) ไม่ทับของในชีท */
function woundsOf(cur, body){ return ((cur && cur.wounds) || []).filter(w=>(w.body||'A')===body); }
function woundLite(w){ return {part:w.part, die:w.die, name:w.name||'', text:w.text||'', at:w.at||0}; }
function woundsEq(a, b){ a = a||[]; b = b||[]; if (a.length !== b.length) return false; for (let i = 0; i < a.length; i++) if ((a[i].at||0) !== (b[i].at||0) || a[i].part !== b[i].part || a[i].die !== b[i].die) return false; return true; }
function setWoundsOf(cur, body, list){ cur.wounds = [...((cur.wounds||[]).filter(w=>(w.body||'A')!==body)), ...(list||[]).map(w=>Object.assign(woundLite(w), {body}))]; }
function toughEq(a, b){ a = a||{}; b = b||{}; for (const [k] of DATA.meta.bodyParts) if ((a[k]??null) !== (b[k]??null)) return false; return true; }
function syncVitalsWithSheets(r){
  let roomChanged = false;
  // สองรอบ: แฝดมีสองหมากต่อหนึ่งชีท (HP และ Toughness แยกร่าง Sanity ร่วมกัน) หมากที่ใหม่กว่าเขียนชีทในรอบแรก อีกหมากตามชีทในรอบสอง
  const byAge = [...(r.tokens||[])].sort((x, y)=>(x.vitalsAt||0) - (y.vitalsAt||0)); // หมากที่แก้ก่อนเขียนชีทก่อน สองร่างของแฝดที่ถูกแก้ไล่เลี่ยกันจึงไม่ทับกัน
  for (let pass = 0; pass < 2; pass++) for (const t of byAge){ if (!t.charId || t.kind!=='pc') continue; const c = Store.chars.find(x=>x.id===t.charId && Store.isMine(x)); if (!c || !c.current) continue; const cur = c.current; const hk = hpKeyOf(t); const tk = toughKeyOf(t); if (hk==='hp2' && cur.hp2 == null) cur.hp2 = t.hp; if (tk==='tough2' && !cur.tough2) cur.tough2 = Object.assign({}, t.tough || cur.tough || {}); const ta = t.vitalsAt||0, ca = cur.at||0;
    const body = bodyOf(t); const tw = Array.isArray(t.wounds) ? t.wounds : null; const cw = woundsOf(cur, body);
    const same = t.hp === cur[hk] && t.san === cur.sanity && t.tough && toughEq(t.tough, cur[tk]) && (tw ? woundsEq(tw, cw) : !cw.length);
    if (same) continue;
    if (ta > ca){ cur[hk] = t.hp; cur.sanity = t.san; if (t.tough) cur[tk] = Object.assign({}, cur[tk]||{}, t.tough); else { t.tough = Object.assign({}, cur[tk]||{}); roomChanged = true; } if (tw) setWoundsOf(cur, body, tw); else if (cw.length){ t.wounds = cw.map(woundLite); roomChanged = true; } cur.at = ta; Store.upsert(c); if (location.hash==='#sheet-'+c.id) renderSheet(c.id); }
    else { t.hp = cur[hk]; t.san = cur.sanity; t.tough = Object.assign({}, cur[tk]||{}); t.wounds = cw.map(woundLite); t.vitalsAt = ca || Date.now(); roomChanged = true; } }
  return roomChanged;
}
function pushVitalsFromSheet(c){ const r = Table.room; if (!r) return; const cur = c.current||{}; let ch = false; for (const t of (r.tokens||[]).filter(x=>x.charId===c.id)){ const hp = cur[hpKeyOf(t)]; const ct = cur[toughKeyOf(t)] || cur.tough || {}; const cw = woundsOf(cur, bodyOf(t)); if (t.hp===hp && t.san===cur.sanity && t.tough && toughEq(t.tough, ct) && woundsEq(t.wounds||[], cw)) continue; if (hp != null) t.hp = hp; t.san = cur.sanity; t.tough = Object.assign({}, ct); t.wounds = cw.map(woundLite); t.vitalsAt = cur.at||Date.now(); ch = true; } if (ch) Table.save(); }
/* ===== Twinborn ในห้อง (ผู้ใช้เคาะ 10 พ.ย. 2026): เดินแยกกันโดยเจตนาได้ ร่างที่ผู้เล่นไม่ได้บังคับ GM คุมหลังฉาก (token.gmRun) =====
 * เจ้าของร่างนั้นลากหมากและแก้ค่าไม่ได้ มองผ่านตาร่างนั้นไม่ได้ และไม่เห็นหมากถ้า GM ซ่อนไว้ · ถามตอบกันแบบลับได้ในแชต (gmOnly + toId) */
function setTokenGmRun(r, t, on){
  t.gmRun = !!on; if (on) for (const s of siblingTokens(t)) s.gmRun = false; // GM คุมได้ทีละร่าง ผู้เล่นต้องเหลือร่างให้บังคับ
  if (Table.sel===t.id && on && ownsTokRaw(t) && !Table.isGM()) Table.sel = null;
  Table.save();
  if (!t.hidden) Table.post({kind:'sys', who:'', text: on ? `${t.name} เดินแยกจากอีกร่าง GM คุมหลังฉาก` : `${t.name} กลับมารวมกับอีกร่างแล้ว`});
}
function ownsTokRaw(t){ return !!t && t.ownerId===Store.me; }
/* เครื่องของเจ้าของ: จำสถานะแยกทางจากหมากลงชีท (GM อาจเป็นคนกดบนหมาก) · มีหมากร่างเดียวและไม่ได้ถูก GM คุม = ไม่แตะค่าในชีท */
function mirrorTwinbornFromTokens(r){
  for (const c of Store.chars){ if (!Store.isMine(c) || !isTwinborn(c)) continue; const ts = (r.tokens||[]).filter(t=>t.charId===c.id); if (!ts.length) continue;
    const run = ts.find(t=>t.gmRun); const st = twinbornState(c); let apart = st.apart, control = st.control;
    if (run){ apart = true; control = bodyOf(run)==='A' ? 'B' : 'A'; } else if (ts.length >= 2) apart = false; else continue;
    if (apart !== st.apart || control !== st.control){ c.twinborn = Object.assign({nameB:''}, c.twinborn||{}, {apart, control, at: Date.now()}); Store.upsert(c); } }
}
/* จากชีท: ตั้งสถานะแยกทางแล้วส่งต่อให้หมากในห้องที่เปิดอยู่ */
function setTwinbornState(c, apart, control){
  control = control==='B' ? 'B' : 'A';
  c.twinborn = Object.assign({nameB:''}, c.twinborn||{}, {apart: !!apart, control, at: Date.now()}); Store.upsert(c);
  const r = Table.room; if (!r) return; let ch = false;
  for (const t of (r.tokens||[]).filter(x=>x.charId===c.id)){ const run = !!apart && bodyOf(t) !== control; if (!!t.gmRun !== run){ t.gmRun = run; ch = true; } }
  if (ch){ Table.save(); Table.post({kind:'sys', who:'', text: apart ? `${c.name}: แฝดเดินแยกกัน ผู้เล่นบังคับ${bodyName(c, control)} ส่วน${bodyName(c, control==='A' ? 'B' : 'A')} GM คุมหลังฉาก` : `${c.name}: แฝดกลับมาอยู่ด้วยกัน ผู้เล่นบังคับทั้งสองร่าง`}); }
}
function renameTwinTokens(c){ const r = Table.room; if (!r) return; let ch = false; for (const t of (r.tokens||[]).filter(x=>x.charId===c.id && x.body)){ const nm = bodyName(c, bodyOf(t)); if (t.name !== nm){ t.name = nm; ch = true; } } if (ch) Table.save(); }
/* ผู้เล่นถาม GM ถึงร่างที่แยกไป (ข้อความลับ เห็นเฉพาะผู้ถามกับ GM) */
function askAboutTwin(c){ if (!Table.roomId){ toast('เปิดห้องก่อนจึงจะส่งคำถามถึง GM ได้'); return; } const st = twinbornState(c); const other = st.control==='A' ? 'B' : 'A'; const q = (prompt(`ถาม GM ถึง${bodyName(c, other)} (เห็นเฉพาะคุณกับ GM)`, 'ตอนนี้อีกร่างเป็นอย่างไรบ้าง') || '').trim(); if (!q) return; Table.post({kind:'say', who: bodyName(c, st.control), text:`[ถามถึง${bodyName(c, other)}] ${q}`, gmOnly:true}); toast('ส่งคำถามถึง GM แล้ว คำตอบจะขึ้นในแชตของโต๊ะ'); }
/* GM เล่าเหตุการณ์ของร่างที่คุมอยู่ หรือถามให้เจ้าของเลือก (ข้อความลับถึงเจ้าของคนเดียว) */
function tellTwinOwner(t){ const msg = (prompt(`ข้อความลับถึงเจ้าของ ${t.name} (เล่าเหตุการณ์ หรือถามให้เลือก)`, '') || '').trim(); if (!msg) return; Table.post({kind:'say', who:'GM', text:`[เรื่องของ ${t.name}] ${msg}`, gmOnly:true, toId:t.ownerId}); toast('ส่งถึงเจ้าของตัวละครแล้ว'); }
/* หมากที่ถือเทิร์นถูกเอาออก: ร่างแฝดที่ใช้เทิร์นร่วมกันรับเทิร์นต่อ */
function passSharedTurn(r, t){ const heirs = (r.tokens||[]).filter(x=>x!==t && x.turnWith===t.id); if (!heirs.length) return; const h0 = heirs[0]; delete h0.turnWith; const i = ((r.enc||{}).order||[]).indexOf(t.id); if (i >= 0) r.enc.order[i] = h0.id; for (const o of heirs.slice(1)) o.turnWith = h0.id; }
/* ---- น้ำลึก: ว่ายได้ ลงไปแล้วเสียเทิร์น และประกาศโจมตีไม่ได้ เว้นสัตว์น้ำ (ผู้ใช้เคาะ 9 พ.ย. 2026) ---- */
Table.attackBlocked = function(c){ const r = this.room; if (!r || !c) return null; const ts = (r.tokens||[]).filter(x=>x.charId===c.id); if (!ts.length) return null; const why = (t)=> (t.inWater && !t.aquatic) ? `${t.name} อยู่ในน้ำลึก ประกาศโจมตีไม่ได้จนกว่าจะขึ้นฝั่ง` : (t.inside ? `${t.name} ถูกกลืนอยู่ โจมตีได้เฉพาะจากข้างใน (GM ตัดสิน)` : null); const reasons = ts.map(why); return reasons.every(Boolean) ? reasons[0] : null; /* แฝด: ยังมีร่างที่โจมตีได้ก็ไม่บล็อก */ };
/* v1.22: ระหว่างต่อสู้ บอกในบันทึกว่าการย้ายครั้งนี้อยู่ในระยะ Dash หรือ Run ของตัวละคร (นับช่องตามพื้น ช่องเดินช้านับ 2) ไม่ห้ามการย้าย GM ตัดสินเอง */
function combatMoveNote(r, t, to){ if (!r || !r.enc || !r.enc.active) return ''; const ms = tokenMoveSpeed(t); if (!ms) return '';
  const cost = moveReach(r, t, 60, null).get(to.x+','+to.y); if (cost == null) return '';
  if (ms.dashCells != null && cost <= ms.dashCells) return ' · ระยะ Dash';
  if (ms.runCells != null && cost <= ms.runCells) return ' · ระยะ Run';
  return ` · ไกลกว่า 1 Maneuver (ใช้ ${cost * CELL_M} ม. ${ms.run != null ? 'Run ได้ ' + fmtM(ms.run) : 'Dash ได้ ' + fmtM(ms.dash)} ม.)`; }
/* ---- เคลื่อนหมาก (ลากวาง): ตรวจพื้น ข้อห้ามจากสถานะ หมากซ้อน น้ำลึก แล้วบันทึก ---- */
function tryMoveToken(r, t, x, y, gm, fogged){
  const tile = TILE[mapCell(r.map,x,y)]||TILE['.'];
  if (!tile.pass){
    if (!(tile.climb || tile.cling)){ toast('ผ่านช่องนี้ไม่ได้ ('+tile.th+')'); return false; }
    if (!t.climb){ toast(`ต้องติ๊ก 🧗 ปีนป่าย ให้ ${t.name} ก่อน ถึงจะเข้า${tile.th}ได้`); return false; } // ผู้ใช้เคาะ 9 พ.ย. 2026
  }
  const block = moveBlocked(r, t, {x,y}); if (block){ if (!gm || t.inside){ toast(block); return false; } toast('GM ย้ายข้ามข้อห้าม: '+block); }
  if (r.tokens.some(o=>o!==t && !o.inside && o.x===x && o.y===y)){ toast(fogged ? 'มีอะไรบางอย่างอยู่ตรงนั้นในความมืด เดินเข้าไปไม่ได้' : 'มีหมากอยู่ตรงนั้นแล้ว'); return false; }
  const dist = cellDist(t,{x,y}); const mvNote = combatMoveNote(r, t, {x,y}); const wasWater = !!t.inWater; const wasCling = cellCling(r.map, t.x, t.y); t.x=x; t.y=y; t.inWater = !!tile.swim; syncDevoured(r, t);
  const clingNow = !!tile.cling; enforceCling(r); Table.save();
  if (!t.hidden){ Table.post({kind:'sys',who:'',text:`${t.name} เคลื่อนที่ ${dist} ช่อง ไป (${x},${y})${mvNote}${tile.pass===2?' ('+tile.th+')':''}${tile.swim? ' ลงน้ำลึก' : (wasWater ? ' ขึ้นจากน้ำ' : '')}${tile.climb ? ' 🧗 ปีนขึ้น'+tile.th : ''}${clingNow ? ' 🧗 เกาะ'+tile.th : ''}`}); if (tile.swim && !wasWater && !t.aquatic) Table.post({kind:'sys',who:'',text:`${t.name} ว่ายอยู่ในน้ำลึก: เสียเทิร์นนี้ไปกับการว่าย และประกาศโจมตีไม่ได้จนกว่าจะขึ้นฝั่ง`}); if (clingNow && !wasCling) Table.post({kind:'sys',who:'',text:`${t.name} เกาะ${tile.th}อยู่: นับว่าติด 🛌 Prone ตลอดเวลาที่เกาะ`}); else if (wasCling && !clingNow) Table.post({kind:'sys',who:'',text:`${t.name} ปีนขึ้นมาจากขอบแล้ว พ้นจาก Prone`}); }
  return true;
}
/* เกาะขอบเหว/หน้าผา = Prone เสมอ: เติม Prone (auto) ให้หมากที่อยู่บนช่อง cling และถอด Prone ที่เป็น auto เมื่อออกมาแล้ว คืน true ถ้ามีการเปลี่ยน */
function enforceCling(r){
  let changed = false;
  for (const t of r.tokens||[]){ if (t.inside) continue; const on = cellCling(r.map, t.x, t.y); t.conds = t.conds||[]; const auto = t.conds.find(c=>c.id==='Prone' && c.auto==='cling'); const any = t.conds.find(c=>c.id==='Prone');
    if (on && !any){ t.conds.push({id:'Prone', turns:null, at:Date.now(), auto:'cling'}); changed = true; }
    else if (!on && auto){ t.conds = t.conds.filter(c=>c!==auto); changed = true; } }
  return changed;
}
function cellAtPoint(grid, cx, cy){ const el = document.elementFromPoint(cx, cy); const cell = el && el.closest ? el.closest('.cell') : null; return cell && grid.contains(cell) ? cell : null; }
/* ลากหมากด้วย pointer: ขยับเกิน 6px = ลาก (ปล่อยบนช่อง = ย้าย) · ปล่อยโดยไม่ขยับ = เลือกหมาก (โชว์โซนและระยะมองเห็น) */
function enableTokenDrag(tk, t, r, grid, gm, fogSet){
  tk.style.touchAction = 'none'; tk.classList.add('grab');
  tk.addEventListener('click', (e)=>e.stopPropagation());
  tk.addEventListener('pointerdown', (e)=>{
    if (e.button!==0) return; e.preventDefault(); e.stopPropagation();
    const pid = e.pointerId; const start = {x:e.clientX, y:e.clientY}; let ghost = null, moved = false, lastCell = null;
    try { tk.setPointerCapture(pid); } catch(x){}
    const onMove = (ev)=>{ if (ev.pointerId!==pid) return; const dx = ev.clientX-start.x, dy = ev.clientY-start.y; if (!moved && Math.hypot(dx,dy) < 6) return;
      if (!moved){ moved = true; const z = uiZoom(); const rct = tk.getBoundingClientRect(); ghost = tk.cloneNode(true); ghost.classList.add('ghost'); Object.assign(ghost.style, {position:'fixed', left:(rct.left/z)+'px', top:(rct.top/z)+'px', width:(rct.width/z)+'px', height:(rct.height/z)+'px', inset:'auto', zIndex:1000, pointerEvents:'none', opacity:.9, margin:0}); ghost.dataset.z = String(z); ghost.dataset.ox = String((rct.left - start.x)/z); ghost.dataset.oy = String((rct.top - start.y)/z); document.body.append(ghost); tk.classList.add('lifting'); }
      { const z = parseFloat(ghost.dataset.z)||1; ghost.style.left = (ev.clientX/z + parseFloat(ghost.dataset.ox))+'px'; ghost.style.top = (ev.clientY/z + parseFloat(ghost.dataset.oy))+'px'; }
      const cell = cellAtPoint(grid, ev.clientX, ev.clientY); if (cell !== lastCell){ if (lastCell) lastCell.classList.remove('drop'); if (cell) cell.classList.add('drop'); lastCell = cell; } };
    const onUp = (ev)=>{ if (ev.pointerId!==pid) return; tk.removeEventListener('pointermove', onMove); tk.removeEventListener('pointerup', onUp); tk.removeEventListener('pointercancel', onUp); try { tk.releasePointerCapture(pid); } catch(x){} if (ghost) ghost.remove(); tk.classList.remove('lifting'); if (lastCell) lastCell.classList.remove('drop');
      if (!moved || ev.type==='pointercancel'){ if (!moved) selectToken(t, r, gm); return; }
      const cell = cellAtPoint(grid, ev.clientX, ev.clientY); if (!cell) return; const x = +cell.dataset.x, y = +cell.dataset.y; if (x===t.x && y===t.y) return;
      tryMoveToken(r, t, x, y, gm, !!(fogSet && !fogSet.has(x+','+y))); };
    tk.addEventListener('pointermove', onMove); tk.addEventListener('pointerup', onUp); tk.addEventListener('pointercancel', onUp);
  });
}
function selectToken(t, r, gm){
  const selTok = Table.sel ? r.tokens.find(x=>x.id===Table.sel) : null;
  if (Table.sel===t.id) Table.sel = null;
  else if (selTok && selTok.id!==t.id){ const dist = cellDist(selTok,t); const band = rangeBand(dist); toast(`${selTok.name} → ${t.name}: ${dist} ช่อง (~${band.m} ม.) ${band.label}`); Table.sel = t.id; }
  else Table.sel = t.id;
  renderTable();
}
function mapPanel(r, gm){
  const wrap = h('div',{class:'mapwrap'});
  const map = r.map;
  // แถบควบคุมแผนที่ (GM)
  if (gm){
    const kindSel = h('select',null, MAP_KINDS.map(([k,l])=>h('option',{value:k,selected:k===map.kind,text:l})));
    const reseat = ()=>{ for (const t of r.tokens){ if (t.inside) continue; const pos = freeCell(r.map, r.tokens.filter(x=>x!==t), t.kind==='npc' ? [0,1,2,3] : t.kind==='asset' ? [8,9,10,11] : [16,17,18,19]); t.x=pos.x; t.y=pos.y; t.inWater=false; syncDevoured(r, t); } };
    const ctl = h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px',text:'สถานที่'}), kindSel,
      h('button',{class:'small primary',onclick:()=>{ r.map = generateMap(kindSel.value, uid()); Table.sel=null; reseat(); Table.save(); Table.post({kind:'sys',who:'GM',text:`เปลี่ยนฉากต่อสู้เป็น ${MAP_KINDS.find(x=>x[0]===kindSel.value)[1]}`}); },text:'สุ่มแผนที่ใหม่'}),
      h('button',{class:'small',onclick:()=>{ r.map = generateMap(map.kind, uid()); reseat(); Table.save(); },text:'สุ่มใหม่ (สถานที่เดิม)'}));
    const brushSel = h('select',{title:'พู่กัน: เลือกชนิดพื้นแล้วคลิกช่องเพื่อแก้แผนที่'}, h('option',{value:'',text:'พู่กัน: ปิด'}), Object.entries(TILE).map(([k,v])=>h('option',{value:k,selected:Table.brush===k,text:`${v.th}`})));
    brushSel.onchange = ()=>{ Table.brush = brushSel.value||null; Table.sel=null; renderTable(); };
    ctl.append(brushSel, h('button',{class:'small ghost',onclick:()=>{ if(!confirm('เอาหมากทุกตัวออกจากบอร์ด? (สำเนาชีทในห้องจะถูกลบด้วย)')) return; const old = r.tokens; r.tokens=[]; for (const t of old) dropTokenCopy(r, t); r.enc={active:false,round:0,turnIdx:0,order:[]}; Table.save(); },text:'ล้างหมาก'}));
    wrap.append(ctl);
    const lightSel = h('select',{title:'ระดับแสงของฉาก มีผลต่อระยะที่ผู้เล่นมองเห็นบนบอร์ด'}, LIGHTS.map(([k,l])=>h('option',{value:k,selected:k===(r.light||'low'),text:l})));
    lightSel.onchange = ()=>{ r.light = lightSel.value; Table.save(); Table.post({kind:'sys',who:'GM',text:`แสงในฉากเปลี่ยนเป็น ${lightLabel(r.light)}`}); };
    wrap.append(h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px',text:'💡 แสง'}), lightSel, h('span',{class:'dim',style:'font-size:11.5px;flex:1;min-width:160px',text:LIGHT_NOTE[r.light||'low']||''}),
      h('button',{class:'small ghost',title:'โหลดแผนที่ที่เตรียมไว้จากคลังแผนที่ของคุณ',onclick:()=>openMapLibraryPicker(r),text:'📚 คลังแผนที่'}),
      h('button',{class:'small ghost',title:'เก็บแผนที่ของห้องนี้ (พื้น แสง และ NPC) เข้าคลังแผนที่ส่วนตัว',onclick:()=>saveRoomMapToLibrary(r),text:'💾 เก็บเข้าคลัง'}),
      map.image ? h('button',{class:'small ghost'+(map.image.hidden?'':' on'),title:'ซ่อน/แสดงภาพประกอบแผนที่',onclick:()=>{ map.image.hidden = !map.image.hidden; Table.save(); },text:'🖼 ภาพ'}) : null));
  } else wrap.append(h('div',{class:'row mapctl'}, h('span',{class:'dim',style:'font-size:12px'}, 'สถานที่: ', h('b',{text:(MAP_KINDS.find(x=>x[0]===map.kind)||['','?'])[1]}), ' · 💡 ', h('b',{text:lightLabel(r.light||'low')})), h('span',{class:'dim',style:'font-size:11.5px',text:LIGHT_NOTE[r.light||'low']||''})));
  const light = r.light||'low';
  const vis = gm ? null : computeVisibility(r, Store.me); // null = เห็นทั้งบอร์ด
  const gridwrap = h('div',{class:'gridwrap'});
  const grid = h('div',{class:'gridmap'+(Table.brush?' painting':'')+(light==='dark'||light==='abyss'?' dark-scene':'')+(light==='dim'?' dim-scene':'')});
  if (!gm && light==='dark' && vis){ const mine = r.tokens.filter(t=>ownsTok(t) && !t.inside); if (mine.length && mine.every(t=>t.nv)) grid.classList.add('nightvision'); }
  const selTok = Table.sel ? r.tokens.find(t=>t.id===Table.sel) : null;
  const canSee = (t)=> (gm || !t.hidden || ownsTok(t)) && (!vis || ownsTok(t) || vis.has(t.x+','+t.y));
  const visible = (t)=> canSee(t) && !t.inside;
  const byPos = {}; for (const t of r.tokens) if (visible(t)) byPos[t.x+','+t.y] = t;
  const cur = r.enc.active ? r.enc.order[r.enc.turnIdx] : null;
  const sight = selTok && !selTok.inside && (gm || ownsTok(selTok)) ? tokenSight(r, selTok) : null; // ระยะมองเห็นของหมากที่เลือก
  const moveMs = selTok && !selTok.inside && (gm || ownsTok(selTok)) ? tokenMoveSpeed(selTok) : null; // v1.22: ช่องที่เดินถึงในหนึ่ง Maneuver
  const reach = moveMs ? moveReach(r, selTok, Math.max(moveMs.dashCells||0, moveMs.runCells||0), vis) : null;
  for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){
    const ch = mapCell(map,x,y); const tile = TILE[ch]||TILE['.'];
    const fog = !!(vis && !vis.has(x+','+y));
    const cell = h('div',{class:'cell t-'+(ch.replace(/[^A-Za-z]/g, m=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[m]||'ground')))+(fog?' fog':''),title: fog ? `(${x},${y}) มองไม่เห็น` : `(${x},${y}) ${tile.th}`,dataset:{x,y}});
    if (selTok && !(selTok.x===x && selTok.y===y)){ const dist = cellDist(selTok,{x,y}); const band = rangeBand(dist); cell.classList.add('rng-'+band.id); if (sight && !fog) cell.classList.add(sight.has(x+','+y) ? 'insight' : 'nosight'); }
    if (reach && !fog && !(selTok.x===x && selTok.y===y) && !byPos[x+','+y]){ const cst = reach.get(x+','+y); if (cst != null && cst > 0 && !moveBlocked(r, selTok, {x,y})){ if (moveMs.dashCells != null && cst <= moveMs.dashCells) cell.classList.add('mv-dash'); else if (moveMs.runCells != null && cst <= moveMs.runCells) cell.classList.add('mv-run'); } }
    cell.onclick = ()=>{
      if (Table.brush && gm){ setMapCell(r.map, x, y, Table.brush); Table.save(); return; }
      if (byPos[x+','+y]) return; // หมากจัดการคลิกเอง (เลือก/ลาก)
      if (Table.sel){ Table.sel = null; renderTable(); }
    };
    const t = byPos[x+','+y];
    if (t){ const conds = (t.conds||[]); const inside = r.tokens.filter(o=>o.inside===t.id && canSee(o));
      const tk = h('div',{class:`gtok ${t.kind}${t.hidden?' hid':''}${(cur===t.id || (cur && t.turnWith===cur))?' turn':''}${Table.sel===t.id?' sel':''}${(t.hp<=0 && (t.kind!=='asset' || t.hpMax>0))?' down':''}${t.torch?' torch':''}${t.inWater?' water':''}` + conds.map(c=>' c-'+condClass(c.id)).join(''),title:`${t.name}` + ((t.kind!=='asset' || t.hpMax>0) ? ` HP ${t.hp}/${t.hpMax}` : '') + (conds.length ? ' · ' + conds.map(c=>condLabel(c, r)).join(', ') : '') + (inside.length ? ' · ในท้อง: '+inside.map(o=>o.name).join(', ') : '') + (t.inWater ? ' · ในน้ำลึก' : '') + (t.gmRun ? ' · GM คุมหลังฉาก' : '') + ((gm || ownsTok(t)) ? ' · ลากเพื่อย้าย คลิกเพื่อดูโซนและระยะมองเห็น' : '')});
      // หน้าหมาก (รูป/อักษรย่อ + แถบ HP) ตัดเป็นวงกลมในกรอบ .face ส่วนป้าย (สถานะ ลำดับเทิร์น คบเพลิง ร่างแฝด) อยู่นอกกรอบตัด จะได้ไม่ถูกขอบวงกลมบัง (v1.14)
      const face = h('div',{class:'face'}); const ico = t.thumb ? null : icoClean(t.ico); if (t.thumb) face.append(h('img',{src:t.thumb,alt:t.name,draggable:'false'})); else if (ico){ face.classList.add('hasico'); face.style.background = ico.b; face.append(icoSvg(ico)); } else face.append(h('span',{class:'ini',text: tokInitials(t)}));
      const pct = t.hpMax? Math.max(0,Math.min(100,t.hp/t.hpMax*100)) : 0; if (t.kind!=='asset' || t.hpMax>0) face.append(h('i',{class:'hpbar',style:`--p:${pct}%`})); tk.append(face);
      if (conds.length) tk.append(h('div',{class:'cbadges'}, conds.slice(0,3).map(c=>h('span',{text:condIcon(c.id)+(COND_STACK.has(c.id)? (c.lv||1) : '')}))));
      if (inside.length) tk.append(h('span',{class:'devbadge',text:'🦷'+inside.length}));
      if (t.torch) tk.append(h('span',{class:'torchbadge',text:'🔥'}));
      if (t.body) tk.append(h('span',{class:'bodybadge'+(t.gmRun?' gmrun':''),title:`แฝด ร่าง ${t.body}${t.gmRun ? ' (GM คุมหลังฉาก)' : ''}`,text:t.body}));
      if (cellClimbable(map, x, y)) tk.append(h('span',{class:'climbbadge',title: cellCling(map,x,y) ? 'เกาะขอบ (Prone)' : 'ปีนอยู่',text:'🧗'}));
      if (r.enc.active && t.initRoll!=null) tk.append(h('span',{class:'initbadge num',title:'ลำดับ Initiative',text:String(t.initRoll)}));
      if (gm || ownsTok(t)) enableTokenDrag(tk, t, r, grid, gm, vis); else tk.addEventListener('click', (e)=>{ e.stopPropagation(); selectToken(t, r, gm); });
      cell.append(tk); }
    grid.append(cell);
  }
  gridwrap.append(grid);
  if (map.image && map.image.data && !map.image.hidden) gridwrap.append(mapImageOverlay(map.image, null));
  wrap.append(gridwrap);
  // ตำนานพื้นที่ปรากฏ
  const used = [...new Set(map.cells.split(''))].filter(k=>TILE[k]);
  wrap.append(h('div',{class:'legend'}, used.map(k=>h('span',{class:'lg'}, h('i',{class:'sw t-'+(k.replace(/[^A-Za-z]/g, m=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[m]||'ground')))}), TILE[k].th)), selTok ? h('span',{class:'lg dim',text:`· แดง = เขตปะทะ · ทอง = ใกล้เคียง (ไม่เกิน ${NEAR_MAX_M} ม.) · นอกนั้น = เขตไกล · ช่องมืดลง = พ้นระยะมองเห็นของหมากที่เลือก`}) : null));
  if (selTok && sight) wrap.append(h('p',{class:'dim sightnote',style:'font-size:12px;margin:6px 0 0'}, '👁 ระยะมองเห็นของ ', h('b',{text:selTok.name}), ` ใน${lightLabel(light)}: ${sightLabel(selTok, light)}`));
  if (vis && !gm) wrap.append(h('p',{class:'dim',style:'font-size:12px;margin:6px 0 0',text:`💡 ${lightLabel(light)}: ช่องมืดคือส่วนที่หมากของคุณมองไม่เห็น (กำแพง หิน บ้าน ต้นไม้ และเสา บังสายตา) ${light==='abyss' ? 'เห็นได้แค่ช่องติดตัว' : light==='dark' ? 'ถ้าไม่มี Dark Vision เห็นแค่ช่องติดตัว แหล่งแสง 🔥 ส่องรอบตัว 4 ช่อง' : light==='dim' ? 'เห็นได้ 12 ช่อง (24 ม.) ถ้าไม่มี Dark Vision' : ''}`}));
  return wrap;
}
/* ภาพประกอบบนแผนที่ (PNG ที่เจ้าของคลังใส่ไว้) วางทับกริดตามตำแหน่งหน่วยช่อง · onEdit = โหมดลาก/ย่อขยาย (ตัวแก้ไขแผนที่) */
function mapImageOverlay(img, onEdit){
  const el = h('div',{class:'mapimg'+(onEdit?' editable':'')});
  const place = ()=>{ el.style.left = (img.x/MAP_W*100)+'%'; el.style.top = (img.y/MAP_H*100)+'%'; el.style.width = (img.w/MAP_W*100)+'%'; el.style.height = (img.h/MAP_H*100)+'%'; el.style.opacity = img.opacity==null ? .9 : img.opacity; };
  el.style.backgroundImage = `url(${img.data})`; place();
  if (onEdit){
    const handle = h('div',{class:'mapimg-handle',title:'ลากเพื่อย่อขยาย'}); el.append(handle);
    const parentRect = ()=> el.parentElement.getBoundingClientRect();
    el.addEventListener('pointerdown', (e)=>{ if (e.button!==0 || e.target===handle) return; e.preventDefault(); e.stopPropagation(); const pr = parentRect(); const sx = e.clientX, sy = e.clientY, ox = img.x, oy = img.y; const pid = e.pointerId; el.setPointerCapture(pid);
      const mv = (ev)=>{ if (ev.pointerId!==pid) return; img.x = Math.round((ox + (ev.clientX-sx)/pr.width*MAP_W)*4)/4; img.y = Math.round((oy + (ev.clientY-sy)/pr.height*MAP_H)*4)/4; place(); };
      const up = (ev)=>{ if (ev.pointerId!==pid) return; el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); try{ el.releasePointerCapture(pid);}catch(x){} onEdit(); };
      el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up); });
    handle.addEventListener('pointerdown', (e)=>{ if (e.button!==0) return; e.preventDefault(); e.stopPropagation(); const pr = parentRect(); const sx = e.clientX, sy = e.clientY, ow = img.w, oh = img.h; const ratio = oh/ow; const pid = e.pointerId; handle.setPointerCapture(pid);
      const mv = (ev)=>{ if (ev.pointerId!==pid) return; const nw = Math.max(1, ow + (ev.clientX-sx)/pr.width*MAP_W); img.w = Math.round(nw*4)/4; img.h = ev.shiftKey ? Math.max(1, Math.round((oh + (ev.clientY-sy)/pr.height*MAP_H)*4)/4) : Math.round(img.w*ratio*4)/4; place(); };
      const up = (ev)=>{ if (ev.pointerId!==pid) return; handle.removeEventListener('pointermove', mv); handle.removeEventListener('pointerup', up); try{ handle.releasePointerCapture(pid);}catch(x){} onEdit(); };
      handle.addEventListener('pointermove', mv); handle.addEventListener('pointerup', up); });
  }
  return el;
}
function rollInitiative(r){
  const lines=[]; const first = new Map(); // charId → หมากแรกของตัวละคร: แฝดสองร่างแชร์ Action Point จึงทอยครั้งเดียวและใช้เทิร์นร่วมกัน
  for (const t of r.tokens){ delete t.turnWith;
    if (t.kind==='asset'){ delete t.initRoll; continue; } // v1.18: สิ่งของไม่ทอย Initiative และไม่เข้าลำดับเทิร์น
    if (t.charId && first.has(t.charId)){ const a = first.get(t.charId); t.initRoll = a.initRoll; t.turnWith = a.id; continue; }
    const rr = roll2d6(); t.initRoll = rr.sum + (t.init||0); if (t.charId) first.set(t.charId, t);
    const twinNote = t.charId && r.tokens.some(x=>x!==t && x.charId===t.charId) ? ' (แฝดใช้เทิร์นร่วมกัน)' : '';
    lines.push(`${t.hidden?'(ซ่อน) ':''}${t.name}${twinNote}: ${rr.kept[0]}+${rr.kept[1]} ${signed(t.init||0)} = ${t.initRoll}`); }
  r.enc.order = r.tokens.filter(t=>t.initRoll!=null && !t.turnWith).sort((a,b)=>b.initRoll-a.initRoll).map(t=>t.id);
  r.enc.active = true; r.enc.round = 1; r.enc.turnIdx = 0;
  Table.save();
  Table.post({kind:'sys',who:'GM',text:'เริ่มการต่อสู้ ทอย Initiative: '+lines.filter(l=>!l.startsWith('(ซ่อน)')).join(' · ')});
  if (lines.some(l=>l.startsWith('(ซ่อน)'))) Table.post({kind:'sys',who:'GM',text:'ฝั่งที่ซ่อน: '+lines.filter(l=>l.startsWith('(ซ่อน)')).join(' · '),gmOnly:true});
}
function clockEl(cl, r, gm){
  const size=72, cx=36, cy=36, R=30;
  const svg = document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('width',size); svg.setAttribute('height',size); svg.setAttribute('viewBox',`0 0 ${size} ${size}`);
  for (let i=0;i<cl.seg;i++){ const a0 = -Math.PI/2 + i*2*Math.PI/cl.seg, a1 = a0 + 2*Math.PI/cl.seg; const p = document.createElementNS('http://www.w3.org/2000/svg','path'); const x0=cx+R*Math.cos(a0), y0=cy+R*Math.sin(a0), x1=cx+R*Math.cos(a1), y1=cy+R*Math.sin(a1); p.setAttribute('d',`M${cx},${cy} L${x0},${y0} A${R},${R} 0 0 1 ${x1},${y1} Z`); p.setAttribute('fill', i<cl.fill? 'var(--blood)':'var(--ink)'); p.setAttribute('stroke','var(--line-2)'); p.setAttribute('stroke-width','1'); if (gm){ p.style.cursor='pointer'; p.addEventListener('click',()=>{ cl.fill = (i<cl.fill)? i : i+1; Table.save(); }); } svg.append(p); }
  return h('div',{class:'clock',style:'text-align:center;font-size:12px'}, svg, h('div',{text:`${cl.name} ${cl.fill}/${cl.seg}`}), gm? h('button',{class:'small ghost',onclick:()=>{ r.clocks=r.clocks.filter(x=>x.id!==cl.id); Table.save(); },text:'ลบ'}):null);
}
/* ทอยตามคำสั่ง (ใช้ทั้งจากแชต /r และช่องคำสั่งในหน้าต่างทอยเต๋า) */
function runRollCommand(expr, name, c, gmOnly, mode0){
  const p = parseRollCommand(expr); if (mode0 && mode0!=='normal' && p.mode==='normal'){ p.mode = mode0; p.expr = p.expr.replace(/ (Advantage|Disadvantage)$/,'') + (p.mode==='adv' ? ' Advantage' : ' Disadvantage'); }
  const text = p.label ? `${p.label} (${p.expr})` : p.expr;
  const post = (e)=>{ Table.post({kind:'roll',who:name,text:e.text,roll:e.roll,mod:e.mod,pm:0,total:e.total,judge:e.judge,dc:e.dc,atk:e.atk||null,def:e.def||null,gmOnly:!!gmOnly}); if (typeof diceBadge==='function') diceBadge(e.total); };
  const rollOf = (e)=>({dice:e.r.dice,kept:e.r.kept,keptIdx:e.r.keptIdx,sum:e.r.sum,crit:e.r.crit,double:e.r.double,mode:e.mode,chosen:!!e.r.chosen});
  if (p.kind==='attack'){ // v1.15: โจมตี · Advantage หรือ Combat Dice เกิน 2 = ผู้โจมตีเลือกเอง · Disadvantage = ฝ่ายรับเลือกจากข้อความในแชต · cv+n = ตัวปรับ CV · ชื่อตำแหน่ง = Focus (Precise)
    let d = null; try { d = c ? compute(c) : null; } catch(e){}
    if (c && Table.attackBlocked){ const blk = Table.attackBlocked(c); if (blk){ toast(blk); return; } }
    const base = p.diceGiven ? Math.max(2, Math.min(4, p.n)) : 2; const n = base + (p.mode==='normal' ? 0 : 1);
    const sight = p.loc && d ? (d.sight||0) : 0; const cvMod = (p.cvMod||0) + (p.mod||0) + sight;
    const label = (p.label ? p.label + ' · ' : '') + `Attack Roll (${n > 2 ? n+'d6 เลือก 2' : '2d6'}${p.mode==='adv' ? ' Advantage' : (p.mode==='dis' ? ' Disadvantage' : '')})` + (p.loc ? ` · Focus (Precise) ${partLabel(p.loc)}${sight ? ' Sight '+signed(sight) : ''}` : '');
    Table.guardedRoll(name, ()=>{
      const fin = (r, pick)=>{ const e = doRoll({label, mod:cvMod, c, mode:p.mode, kind:'attack', r, atk:{loc:p.loc, pick}}); post({text:e.label, roll:rollOf(e), mod:e.mod, total:e.total, judge:e.judge, dc:null, atk:e.atk}); };
      if (p.mode==='dis'){ Table.postPick({dice: Array.from({length:n}, rollD6), label, cvMod, loc:p.loc, who:name, gmOnly}); toast('ทอยแล้ว รอฝ่ายรับ (หรือ GM) เลือก 2 ลูกในแชต'); return; }
      if (n > 2) return rollChoose(n, p.mode, `โจมตี: ทอย ${n}d6 เลือก 2 ลูก`, {kind:'attack', cvMod, loc:p.loc}).then(r=>fin(r, 'atk'));
      fin(null, null);
    }, label);
    return;
  }
  if (p.kind){ // Parry / Evade (ผู้ใช้ขอ 9 พ.ย. 2026): ทอยหลายลูกแล้วเลือกเอง 2 ลูก ใช้ได้ทั้งผู้เล่น (ตามชีท) และ GM (ระบุจำนวนลูกเอง)
    let d = null; try { d = c ? compute(c) : null; } catch(e){}
    let n = 2, mod = p.mod, note = '';
    if (p.kind==='parry'){ if (p.diceGiven){ n = Math.min(PARRY_MAX_DICE, p.n); if (p.n > PARRY_MAX_DICE) note = `สูงสุด ${PARRY_MAX_DICE} ลูก`; } else if (p.mode==='dis') { n = 2; note = 'Disadvantage: 2d6 ไม่ใช้ Parry Dice'; } else n = parryDiceCount(d ? d.parryDice : 0, p.mode==='adv'); }
    else { if (d) mod += d.reflex; n = p.diceGiven ? p.n : (p.mode==='adv' ? 3 : 2); if (d) note = `Reflex ${signed(d.reflex)}`; }
    n = Math.max(2, Math.min(12, n));
    const kindName = p.kind==='parry' ? 'Parry' : 'Evade';
    const detail = [n > 2 ? `${n}d6 เลือก 2` : '2d6', note, p.mod ? signed(p.mod) : '', p.mode==='adv' ? 'Advantage' : (p.mode==='dis' ? 'Disadvantage' : '')].filter(Boolean).join(' ');
    const label = (p.label ? p.label + ' · ' : '') + `${kindName} (${detail})`;
    const mode = (p.kind==='parry' && p.mode==='dis') ? 'normal' : p.mode;
    Table.guardedRoll(name, ()=>{
      const pdis = p.kind==='parry' && p.mode==='dis';
      const dop = {cv: p.cv, loc: p.loc};
      const fin = (r)=>{ const e = doRoll({label, mod, c, dc:p.dc, mode, kind:p.kind, r, dis:pdis, def:dop}); post({text:e.label, roll:rollOf(e), mod:e.mod, total:e.total, judge:e.judge, dc:p.dc, def:e.def}); };
      if (n > 2) return rollChoose(n, mode, `${kindName}: ทอย ${n}d6 เลือก 2 ลูก${p.dc!=null ? ` (โจมตีมา ${p.dc})` : ''}`, {kind:p.kind, dc:p.dc, mod: p.kind==='evade' ? mod : 0, dis:pdis, cv:p.cv, loc:p.loc}).then(fin);
      fin(null);
    }, label);
    return;
  }
  if (p.kirana){
    Table.guardedRoll(name, ()=>{ const e = doRoll({label:text, mod:p.mod, c, mode:p.mode, dc:p.dc}); post({text:e.label, roll:{dice:e.r.dice,kept:e.r.kept,keptIdx:e.r.keptIdx,sum:e.r.sum,crit:e.r.crit,double:e.r.double,mode:e.mode}, mod:e.mod, total:e.total, judge:e.judge, dc:p.dc}); }, text);
  } else {
    Table.guardedRoll(name, ()=>{ const r = rollDiceExpr(p); const total = r.sum + p.mod; const judge = p.dc!=null ? (total >= p.dc ? {cls:'res-full', text:`สำเร็จ (ถึง DC ${p.dc})`} : {cls:'res-fail', text:`ล้มเหลว (DC ${p.dc})`}) : {cls:'', text:''}; post({text, roll:r, mod:p.mod, total, judge, dc:p.dc}); }, text);
  }
}
function rollHelpModal(){ modal(h('div',null, h('h3',{text:'คำสั่งทอยเต๋า'}), h('p',{class:'desc',style:'margin:4px 0 10px',text:'พิมพ์ในช่องแชต (นำหน้าด้วย /r) หรือในช่องคำสั่งของหน้าต่างทอยเต๋า (ไม่ต้องมี /r) ผลทอยเด้งให้ทุกคนในห้องเห็นเหมือนปุ่มทอย'}), h('table',{class:'t'}, h('tbody',null, ROLL_HELP.map(([k,v])=>h('tr',null, h('td',null, h('code',{text:k})), h('td',{text:v}))))))); }
function handleChatInput(txt, name, c, gm){
  let gmOnly=false, mode='normal', rest=txt;
  const toks = rest.split(/\s+/);
  while (toks.length && toks[0].startsWith('/')){
    const cmd = toks.shift().toLowerCase();
    if (cmd==='/gm' || cmd==='/gmr'){ gmOnly=true; if (cmd==='/gmr'){ runRollCommand(toks.join(' '), name, c, true, mode); return; } if (toks.length && /^r(oll)?$/i.test(toks[0])){ toks.shift(); runRollCommand(toks.join(' '), name, c, true, mode); return; } }
    else if (cmd==='/adv') mode='adv'; else if (cmd==='/dis') mode='dis';
    else if (cmd==='/r' || cmd==='/roll'){ runRollCommand(toks.join(' '), name, c, gmOnly, mode); return; }
    else if (cmd==='/parry' || cmd==='/evade' || cmd==='/attack' || cmd==='/atk'){ runRollCommand(cmd.slice(1) + ' ' + toks.join(' '), name, c, gmOnly, mode); return; }
    else if (cmd==='/help' || cmd==='/?'){ rollHelpModal(); return; }
    else { toks.unshift(cmd); break; }
  }
  // "/adv r 2d6" หรือ "/dis r ..." : คำถัดไปเป็น r
  if (mode!=='normal' && toks.length && /^r(oll)?$/i.test(toks[0])){ toks.shift(); runRollCommand(toks.join(' '), name, c, gmOnly, mode); return; }
  rest = toks.join(' ');
  if (!rest) return;
  Table.post({kind:'say', who:name, text:rest, gmOnly});
}
function renderChatOnly(){
  const log = document.getElementById('chatlog'); if (!log) return; clear(log);
  const gm = Table.isGM();
  const items = Table.chat.filter(m => !m.gmOnly || gm || m.authorId===Store.me || (m.toId && m.toId===Store.me));
  if (!items.length) log.append(h('div',{class:'dim',text:'ยังไม่มีข้อความ'}));
  for (const m of items){
    const time = new Date(m.ts||0).toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'});
    if (m.kind==='roll' && m.roll){
      const r = {dice:m.roll.dice||[], kept:m.roll.kept||[], keptIdx:m.roll.keptIdx||[], sum:m.roll.sum, crit:m.roll.crit, double:m.roll.double, mode:m.roll.mode||'normal'};
      log.append(h('div',{class:'e'}, h('div',{class:'row',style:'gap:6px'}, chatWho(m), h('b',{text:m.text||''}), r.mode!=='normal'? tag(r.mode==='adv'?'Advantage':'Disadvantage', r.mode==='adv'?'ok':'neg'):null, (m.atk && m.atk.pick==='def') ? tag('ฝ่ายรับเลือก','neg') : (m.roll.chosen? tag('เลือกลูกเอง','prop'):null), m.roll.sides && m.roll.sides!==6 ? tag('d'+m.roll.sides,'prop') : null, m.dc!=null? tag(isDefenseRollText(m.text) ? 'โจมตีมา '+m.dc : 'DC '+m.dc):null, (m.def && m.def.cv!=null && m.def.cv!==m.dc) ? tag('CV '+m.def.cv) : null, (m.def && m.def.loc) ? tag('เล็ง'+partLabel(m.def.loc)) : null, m.gmOnly? h('span',{class:'gm',text:'ลับ'}):null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
        h('div',{class:'row',style:'gap:8px;margin-top:2px'}, renderDice(r), h('span',{class:'dim num',text:r.kept.join('+') + (m.mod? ` ${signed(m.mod)}`:'') + (m.pm? ` ${m.persSide} ${signed(m.pm)}`:'')}), h('b',{class:'num',text:'= '+m.total}), m.judge? h('span',{class:m.judge.cls||'',text:m.judge.text||''}):null)));
    } else if (m.kind==='pick'){
      const done = Table.pickDone(m); const can = !done && Table.canPick(m); const dice = m.dice||[];
      log.append(h('div',{class:'e pickmsg'+(done?' done':'')}, h('div',{class:'row',style:'gap:6px'}, chatWho(m), h('b',{text:m.text||'Attack Roll'}), tag('Disadvantage','neg'), m.gmOnly? h('span',{class:'gm',text:'ลับ'}):null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
        h('div',{class:'row',style:'gap:8px;margin-top:2px;align-items:center'}, h('span',{class:'inline-roll'}, dice.map(v=>h('span',{class:'die',text:v}))), m.cvMod ? h('span',{class:'dim num',text:'ตัวปรับ CV '+signed(m.cvMod)}) : null, m.loc ? h('span',{class:'dim',text:'เล็ง'+partLabel(m.loc)}) : null,
          done ? h('span',{class:'dim',text:'เลือกแล้ว ดูผลในข้อความถัดไป'}) : (can ? h('button',{class:'small primary pickbtn',onclick:()=>Table.resolvePick(m),text:'เลือก 2 ลูกให้การโจมตีนี้'}) : h('span',{class:'dim',text:'รอฝ่ายรับหรือ GM เลือก 2 ลูก'})))));
    } else if (m.kind==='sys') log.append(h('div',{class:'e dim',style:'font-size:12px'}, m.gmOnly? h('span',{class:'gm',text:'ลับ '}):null, h('span',{text:m.text||''}), h('span',{class:'dim',style:'font-size:11px;float:right',text:time})));
    else log.append(h('div',{class:'e'}, chatWho(m, ': '), h('span',{text:m.text||''}), m.gmOnly? h('span',{class:'gm',text:' (ลับ)'}):null, h('span',{class:'dim',style:'font-size:11px;float:right',text:time})));
  }
}
function renderPeers(){ const p = document.getElementById('peers'); if (!p) return; const n = Table.peers.length; const names = Table.peers.map(x=>x.name||'').filter(Boolean); p.textContent = n ? `ออนไลน์ในห้อง ${n} คน${names.length? ': '+names.join(', ') : ''}` : ''; }
