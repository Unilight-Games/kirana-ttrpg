/* ===== Login gate (Firebase mode) + developer page ===== */
function loginGate(A, auth){
  return new Promise(resolve => {
    const m = $('#modal'); clear(m); m.classList.remove('hidden'); m.onclick = null;
    const box = h('div', {class:'box gate'});
    const status = h('div', {class:'dim', style:'font-size:13px;margin-top:8px'});
    const btn = h('button', {class:'primary', style:'width:100%;padding:12px;font-size:16px', onclick: async () => {
      btn.disabled = true; status.textContent = 'กำลังเปิดหน้าต่างล็อกอินของ Google…';
      try {
        const prov = new A.GoogleAuthProvider();
        prov.setCustomParameters({ prompt: 'select_account' });
        const res = await A.signInWithPopup(auth, prov);
        m.classList.add('hidden'); clear(m); resolve(res.user);
      } catch (e) {
        console.warn('google sign-in', e);
        const code = (e && e.code) || '';
        status.textContent = code.includes('popup-blocked') ? 'เบราว์เซอร์บล็อกหน้าต่างป๊อปอัป อนุญาตป๊อปอัปแล้วลองใหม่' : code.includes('unauthorized-domain') ? 'โดเมนนี้ยังไม่ได้รับอนุญาตใน Firebase (ผู้ดูแลต้องเพิ่มใน Authorized domains)' : code.includes('popup-closed') ? 'ปิดหน้าต่างก่อนล็อกอินเสร็จ ลองใหม่ได้' : 'ล็อกอินไม่สำเร็จ: ' + (e && e.message || e);
        btn.disabled = false;
      }
    }, text: 'เข้าสู่ระบบด้วย Google'});
    box.append(
      h('div', {class:'brand', style:'justify-content:center;margin-bottom:6px'}, h('span', {class:'moon'}), 'Kirana ', h('span',{class:'brand-sub',text:'TTRPG'})),
      h('h2', {style:'text-align:center', text:'โต๊ะนี้เปิดให้เฉพาะผู้เล่นที่ล็อกอิน'}),
      h('p', {class:'desc', style:'text-align:center;max-width:46ch;margin:8px auto 14px', text:'ล็อกอินด้วยบัญชี Google เพื่อให้ตัวละครของคุณตามไปทุกเครื่อง และให้ GM รู้ว่าใครเป็นใครในห้อง ไม่มีการเก็บรหัสผ่านไว้ที่เว็บนี้'}),
      btn, status,
      h('p', {class:'muted', style:'font-size:12px;text-align:center;margin-top:14px', text: Store.ip ? `IP ของคุณ: ${Store.ip}` : ''}));
    m.append(box);
  });
}

async function renderDev(){
  const root = clear($('#v-dev'));
  if (Store.backend !== 'firebase' || !FB){ root.append(h('div',{class:'card',text:'หน้านี้ใช้ได้เฉพาะเวอร์ชันที่ต่อ Firebase (GitHub Pages)'})); return; }
  const {A, F, auth, fdb} = FB;
  let site = null; try { const sn = await F.getDoc(F.doc(fdb,'config/site')); if (sn.exists()) site = sn.data(); } catch(e){}
  const user = auth.currentUser;
  const isAnon = !user || user.isAnonymous;
  const isDevUid = !!(site && (site.devUids||[]).includes(user && user.uid));
  const canClaim = !site || !(site.devUids||[]).length;
  const ip = Store.ip || await fetchPublicIp(); Store.ip = ip;
  const card = h('div',{class:'card'});
  card.append(h('h2',{text:'ตั้งค่าผู้พัฒนา (Developer)'}));
  const dl = h('dl'); const add=(k,v)=>dl.append(h('dt',{text:k}),h('dd',{text:v}));
  add('บัญชีตอนนี้', user ? (isAnon ? 'ผู้ใช้นิรนาม (anonymous)' : `${user.displayName||''} ${user.email||''}`.trim()) : 'ยังไม่ล็อกอิน');
  add('UID', user ? user.uid : '-');
  add('IP ปัจจุบัน', ip || 'หาไม่ได้');
  add('สถานะ', isDevUid ? 'คุณคือผู้พัฒนา' : (Store.isDevIp ? 'เครื่องนี้อยู่ใน IP ผู้พัฒนา' : 'ไม่ใช่ผู้พัฒนา'));
  add('บังคับล็อกอิน', site ? (site.requireLogin ? 'เปิด' : 'ปิด') : 'ยังไม่ตั้งค่า');
  add('IP ผู้พัฒนา', site && site.devIps && site.devIps.length ? site.devIps.join(', ') : '-');
  card.append(h('div',{class:'summary'}, dl));
  const save = async (patch) => { try { await F.setDoc(F.doc(fdb,'config/site'), {...(site||{requireLogin:false, devUids:[], devIps:[]}), ...patch}, {merge:true}); toast('บันทึกแล้ว'); renderDev(); } catch(e){ toast('บันทึกไม่ได้: ' + (e && e.code || e)); } };
  const row = h('div',{class:'row',style:'margin-top:12px'});
  if (isAnon) row.append(h('button',{class:'primary',onclick:async()=>{ try{ const prov=new A.GoogleAuthProvider(); await A.signInWithPopup(auth, prov); location.reload(); }catch(e){ toast('ล็อกอินไม่สำเร็จ: '+(e&&e.code||e)); } },text:'ล็อกอินด้วย Google (จำเป็นสำหรับการตั้งค่า)'}));
  if (!isAnon && canClaim) row.append(h('button',{class:'primary',onclick:()=>save({devUids:[user.uid]}),text:'ตั้งบัญชีนี้เป็นผู้พัฒนา'}));
  if (isDevUid){
    row.append(h('button',{onclick:()=>save({requireLogin: !(site&&site.requireLogin)}),text: site&&site.requireLogin ? 'ปิดการบังคับล็อกอิน' : 'เปิดการบังคับล็อกอิน'}));
    if (ip) row.append(h('button',{onclick:()=>{ const ips=new Set(site.devIps||[]); if (ips.has(ip)) ips.delete(ip); else ips.add(ip); save({devIps:[...ips]}); },text: (site.devIps||[]).includes(ip) ? 'เอา IP นี้ออก' : 'เพิ่ม IP นี้เป็นเครื่องผู้พัฒนา'}));
    const uidInp = h('input',{placeholder:'UID ผู้พัฒนาเพิ่ม',style:'width:260px'});
    row.append(uidInp, h('button',{onclick:()=>{ const u=uidInp.value.trim(); if(!u) return; save({devUids:[...new Set([...(site.devUids||[]), u])]}); },text:'เพิ่ม UID'}));
  }
  row.append(h('button',{class:'ghost',onclick:async()=>{ await A.signOut(auth); location.reload(); },text:'ออกจากระบบ'}));
  card.append(row);
  card.append(h('p',{class:'dim',style:'font-size:12px;margin-top:12px',text:'IP ของบ้านส่วนใหญ่เปลี่ยนได้เมื่อเราเตอร์รีสตาร์ต ถ้าเครื่องผู้พัฒนาเจอหน้าล็อกอิน ให้ล็อกอิน Google แล้วมากดเพิ่ม IP ใหม่ที่นี่'}));
  root.append(card);
}
