/* ===== UI helpers: stat colours, glossary popovers, archetype engine ===== */
const STAT_COLORS = { STR:'#e5484d', AGI:'#3fb950', VIT:'#f08c2e', PER:'#e8c547', INF:'#a371f7', INT:'#58b7ff' };
const STAT_TH = { STR:'พละกำลัง', AGI:'ความคล่องแคล่ว', VIT:'ความแข็งแรง', PER:'การรับรู้', INF:'อิทธิพล', INT:'ปัญญา' };
function statStyle(s){ return `--sc:${STAT_COLORS[s]||'var(--mana)'}`; }

/* ---- Glossary: wrap known terms in clickable spans ---- */
const GLOSSARY = DATA.glossary || {};
const GL_TERMS = Object.keys(GLOSSARY).sort((a,b)=>b.length-a.length);
const GL_RE = GL_TERMS.length ? new RegExp('(' + GL_TERMS.map(t=>t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|') + ')(?![A-Za-z])', 'g') : null;
/* ชื่อเฉพาะที่ห้ามขีดเส้นศัพท์ข้างใน (ชื่อสกิล Proficiency Trait พื้นหลัง ชุด ฯลฯ) เช่น "Yantra Master" ไม่ใช่ Master ระดับทักษะ */
const PROTECTED_NAMES = (()=>{
  const names = new Set();
  const add = (n)=>{ if (!n) return; n = String(n).replace(/^\(|\)$/g,'').trim(); if (n && /[A-Za-z]/.test(n)) names.add(n); };
  for (const sk of DATA.skills||[]) add(sk.nameEn);
  for (const k of DATA.knowledge||[]){ for (const L of Object.values(k.levels||{})) for (const p of L.proficiencies||[]) add(p.name.replace(/\s*-\s*[^)]*\)?$/,'')); }
  for (const kin of DATA.kins||[]){ for (const list of ['traits','benefits','hindrances']) for (const x of kin[list]||[]) add(x.nameEn); for (const list of ['childhood','specialChildhood','adulthood','specialAdulthood']) for (const b of kin[list]||[]) add(b.nameEn); for (const sk of kin.starterSkills||[]) add(sk.name.replace(/\(.*$/,'')); }
  for (const st of (DATA.sets && DATA.sets.sets)||[]) add(st.nameEn);
  // เก็บเฉพาะชื่อที่มีคำศัพท์อยู่ข้างใน (ชื่ออื่นไม่ต้องป้องกัน) และยาวก่อน
  const out = [...names].filter(n => { if (!GL_RE) return false; GL_RE.lastIndex = 0; return GL_RE.test(n) && !GLOSSARY[n]; }).sort((a,b)=>b.length-a.length);
  return out;
})();
const PROTECT_RE = PROTECTED_NAMES.length ? new RegExp('(' + PROTECTED_NAMES.map(t=>t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|') + ')(?![A-Za-z])', 'g') : null;
function protectedSpans(s){ const spans = []; if (!PROTECT_RE) return spans; PROTECT_RE.lastIndex = 0; let m; while ((m = PROTECT_RE.exec(s))){ const prev = s[m.index-1]; if (prev && /[A-Za-z0-9]/.test(prev)) continue; spans.push([m.index, m.index + m[0].length]); } return spans; }
/* คำศัพท์คำเดียวที่ชิดกับคำอังกฤษตัวใหญ่ที่ไม่ใช่ศัพท์ (เช่น "Yantra Master", "Martial Skill") ถือเป็นส่วนของชื่อ ไม่ขีด */
function partOfName(s, start, end, term){
  if (term.includes(' ')) return false;
  const before = s.slice(0, start).match(/([A-Z][A-Za-z'\-]*)\s$/); const after = s.slice(end).match(/^\s([A-Z][A-Za-z'\-]*)/);
  const isTerm = (w)=> !!GLOSSARY[w] || STATS.includes(w);
  if (before && !isTerm(before[1])) return true;
  if (after && !isTerm(after[1])) return true;
  return false;
}
function termify(text){
  const frag = document.createDocumentFragment();
  if (text == null) return frag;
  const s = String(text);
  if (!GL_RE){ frag.append(s); return frag; }
  const prot = protectedSpans(s);
  let last = 0; GL_RE.lastIndex = 0; let m; let count = 0;
  while ((m = GL_RE.exec(s)) && count < 60){
    const start = m.index; const term = m[1]; const end = start + term.length;
    // avoid matching inside a latin word (e.g. "Cast" inside "Forecast")
    const prev = s[start-1]; if (prev && /[A-Za-z0-9]/.test(prev)) { continue; }
    if (prot.some(([a,b]) => start < b && end > a)) continue;
    if (partOfName(s, start, end, term)) continue;
    if (start > last) frag.append(s.slice(last, start));
    frag.append(h('span', {class:'term', tabindex:0, role:'button', dataset:{term}, onclick:(e)=>{ showTerm(term, e.currentTarget); }, onkeydown:(e)=>{ if (e.key==='Enter'||e.key===' '){ e.preventDefault(); showTerm(term, e.currentTarget); } }}, term));
    last = end; count++;
  }
  if (last < s.length) frag.append(s.slice(last));
  return frag;
}
const T = termify;
let popEl = null;
function showTerm(term, anchor){
  hideTerm();
  const g = GLOSSARY[term]; if (!g) return;
  popEl = h('div', {class:'pop', role:'dialog'}, h('div', {class:'pop-h'}, h('b', {text: term}), g.th ? h('span', {class:'dim', text:' ' + g.th}) : null, h('button', {class:'small ghost', style:'margin-left:auto', onclick:hideTerm, text:'✕'})), h('div', {class:'pop-b'}, termifyShallow(g.text)), h('div', {class:'pop-c', text: g.cat||''}));
  document.body.append(popEl);
  const z = uiZoom(); const r = anchor.getBoundingClientRect(); const pw = Math.min(360, vw() - 24); // พิกัดจอ → พิกัดหลัง zoom
  popEl.style.width = pw + 'px';
  let left = Math.max(12, Math.min(r.left/z, vw() - pw - 12));
  let top = (r.bottom + 8 + window.scrollY)/z;
  popEl.style.left = left + 'px'; popEl.style.top = top + 'px';
  requestAnimationFrame(()=>{ const ph = popEl.offsetHeight; if (r.bottom/z + 8 + ph > vh()) popEl.style.top = Math.max(12, r.top/z - ph - 8) + window.scrollY/z + 'px'; });
  setTimeout(()=>document.addEventListener('click', hideTermOnce), 0);
}
function termifyShallow(text){ // one level only, no nested popups inside popup text
  const frag = document.createDocumentFragment(); frag.append(String(text||'')); return frag; }
function hideTermOnce(e){ if (popEl && !popEl.contains(e.target)) hideTerm(); }
function hideTerm(){ if (popEl){ popEl.remove(); popEl=null; document.removeEventListener('click', hideTermOnce); } }
document.addEventListener('keydown', e => { if (e.key==='Escape'){ hideTerm(); hideComp(); } });
/* ===== v1.17 (ผู้ใช้สั่ง 12 พ.ย. 2026): ป้าย Comp ของเวทมนตร์ ชี้เมาส์แล้วบอกว่าแต่ละตัวอักษรต้องทำอะไร =====
 * ข้อความมาจากหัวข้อ วิธีการร่าย (Method Components) ของ Skill & Sorceries.md ผ่าน DATA.meta.components
 * ชี้เมาส์หรือโฟกัสด้วยแป้นพิมพ์ = เปิดชั่วคราว · คลิกหรือแตะ = ปักไว้จนกดที่อื่น (จอสัมผัสไม่มีการชี้)
 * lv = ระดับ Sorceries ของตัวละคร (ถ้ารู้) ใช้บอกว่าตัวไหนไม่ต้องทำแล้วตาม DATA.meta.componentWaiver */
const COMP_INFO = (DATA.meta && DATA.meta.components) || {};
const COMP_WAIVER = (DATA.meta && DATA.meta.componentWaiver) || {};
function compLetters(s){ const out = []; for (const ch of String(s||'').toUpperCase()) if (COMP_INFO[ch] && !out.includes(ch)) out.push(ch); return out; }
function sorceryLv(c){ try { return c ? (knowledgeLevels(c).sorceries || 0) : null; } catch(e){ return null; } }
let compPop = null, compPinned = false, compAnchor = null, compWatch = null;
function hideComp(){ if (compWatch){ clearInterval(compWatch); compWatch = null; } if (compPop){ compPop.remove(); compPop = null; } compPinned = false; compAnchor = null; document.removeEventListener('click', hideCompOnce); }
function hideCompOnce(e){ if (compPop && !compPop.contains(e.target) && !(compAnchor && compAnchor.contains(e.target))) hideComp(); }
function placePop(el, anchor, maxW){ const z = uiZoom(); const r = anchor.getBoundingClientRect(); const pw = Math.min(maxW || 360, vw() - 24); el.style.width = pw + 'px';
  el.style.left = Math.max(12, Math.min(r.left/z, vw() - pw - 12)) + 'px'; el.style.top = (r.bottom + 8 + window.scrollY)/z + 'px';
  requestAnimationFrame(()=>{ if (!el.isConnected) return; const ph = el.offsetHeight; if (r.bottom/z + 8 + ph > vh()) el.style.top = Math.max(12, r.top/z - ph - 8) + window.scrollY/z + 'px'; }); }
function showComp(components, anchor, opts){
  const letters = compLetters(components); if (!letters.length || !anchor) return;
  const o = opts || {}; const lv = o.lv;
  hideComp(); hideTerm();
  const rows = letters.map(L=>{ const ci = COMP_INFO[L]; const need = COMP_WAIVER[L]; const waived = lv != null && need != null && lv >= need;
    return h('div',{class:'comp-row'+(waived?' waived':''), dataset:{comp:L}}, h('div',{class:'comp-k'}, h('b',{class:'comp-l',text:L}), h('span',{class:'comp-n',text:`${ci.th} (${ci.en})`}), waived ? h('span',{class:'tag ok',text:`ตัวละครนี้ไม่ต้องใช้แล้ว (Sorceries ระดับ ${lv})`}) : null),
      h('div',{class:'comp-d',text:ci.desc}), h('div',{class:'comp-lim'}, h('b',{text:'ข้อจำกัด '}), ci.limit)); });
  const foot = letters.filter(L=>COMP_WAIVER[L] != null).map(L=>`${knLabel('sorceries') || 'Sorceries'} ระดับ ${COMP_WAIVER[L]} ขึ้นไป ร่ายได้โดยไม่ต้องใช้ ${L}`).join(' · ');
  compPop = h('div',{class:'pop comppop'+(o.pin?' pinned':''), role:'tooltip'}, h('div',{class:'pop-h'}, h('b',{text:'Comp '+letters.join(' ')}), h('span',{class:'dim',text:' วิธีการร่าย (Method Components)'}), o.pin ? h('button',{class:'small ghost',style:'margin-left:auto',onclick:hideComp,text:'✕'}) : null), rows, foot ? h('div',{class:'pop-c',text:foot}) : null);
  document.body.append(compPop); compPinned = !!o.pin; compAnchor = anchor;
  placePop(compPop, anchor, 400);
  compWatch = setInterval(()=>{ if (!compAnchor || !compAnchor.isConnected) hideComp(); }, 250); // หน้าวาดใหม่แล้วป้ายหายไป ป๊อปอัปต้องหายตาม
  if (o.pin) setTimeout(()=>document.addEventListener('click', hideCompOnce), 0);
}
function compTag(components, lv){
  const el = h('span',{class:'tag comptag', text:'Comp '+components});
  if (!compLetters(components).length) return el;
  el.tabIndex = 0; el.setAttribute('role','button'); el.setAttribute('aria-label', `Comp ${components} ชี้หรือกดเพื่ออ่านวิธีการร่าย`);
  const open = ()=>{ if (!compPinned) showComp(components, el, {lv}); }; const close = ()=>{ if (!compPinned) hideComp(); };
  el.addEventListener('mouseenter', open); el.addEventListener('mouseleave', close); el.addEventListener('focus', open); el.addEventListener('blur', close);
  el.addEventListener('click', (e)=>{ e.stopPropagation(); e.preventDefault(); if (compPinned && compAnchor === el) hideComp(); else showComp(components, el, {lv, pin:true}); });
  el.addEventListener('keydown', (e)=>{ if (e.key==='Enter' || e.key===' '){ e.preventDefault(); e.stopPropagation(); el.click(); } });
  return el;
}

/* ---- Archetype engine ---- */
const ARCH = DATA.meta.archetypes;
function persVec(c){ // +value toward left pole
  const v = {}; for (const ax of DATA.meta.personality){ const p = c.personality[ax.id]; v[ax.id] = (p && p.value!=null) ? (p.side==='left' ? p.value : -p.value) : 0; } return v; }
// archetype affinity from personality (left = +): logic, confront, brave, others, compassion, order
const ARCH_PERS = {
  'Tank':          {confront: 2, others: 3, brave: 1, order: 1},
  'Fighter':       {confront: 3, brave: 2, order: 1},
  'Damage Dealer': {confront: 2, compassion: -2, logic: -1},
  'Striker':       {confront: 1, logic: -2, order: -2, compassion: -1},
  'Skirmisher':    {confront: -2, logic: -1, brave: 1, order: -1},
  'Rogue':         {confront: -2, brave: -2, others: -2, order: -2},
  'Support':       {others: 3, compassion: 3, confront: -1},
  'Controller':    {logic: 3, brave: -1, order: 2},
  'Specialist':    {logic: 3, order: 2, confront: -1},
  'Utility':       {brave: 1, logic: 1, confront: -1},
};
function archetypeScores(c, d){
  const pv = persVec(c); const out = [];
  for (const a of ARCH){
    let s = 0;
    for (const [ax, w] of Object.entries(ARCH_PERS[a.id]||{})) s += w * (pv[ax]||0);
    for (const [st, w] of Object.entries(a.weights)) s += w * (d.mod[st]||0) * 0.8;
    out.push({a, s});
  }
  return out.sort((x,y)=>y.s-x.s);
}
const PERS_LINES = { // id → [leftTexts by level, rightTexts by level]
  logic: [['คิดก่อนทำ ชอบวิเคราะห์และวางแผน', 'ใช้เหตุผลนำอารมณ์ เชื่อข้อมูลมากกว่าลางสังหรณ์', 'นักวางแผนตัวยง ทุกการตัดสินใจต้องมีเหตุผลรองรับ'], ['ทำตามความรู้สึกแรก', 'เชื่อสัญชาตญาณมากกว่าตำรา', 'สัญชาตญาณดิบนำทุกอย่าง ตอบสนองก่อนที่สมองจะทัน']],
  confront: [['ไม่ถอยเมื่อเจอปัญหา', 'ชอบเผชิญหน้าตรง ๆ', 'พุ่งชนทุกอุปสรรคแบบไม่คิดเลี่ยง'], ['เลี่ยงการปะทะเมื่อเลี่ยงได้', 'ถนัดหลบมากกว่าชน', 'ไม่สู้ถ้าไม่จำเป็น ถอยหรือหายตัวก่อนเสมอ']],
  brave: [['กล้าเสี่ยงพอประมาณ', 'กล้าสำรวจสิ่งที่คนอื่นกลัว', 'ไม่รู้จักกลัว เดินเข้าหาความมืดเป็นคนแรก'], ['ระวังตัวอยู่เสมอ', 'ไม่ไว้ใจอะไรง่าย ๆ ชอบจับผิด', 'ระแวงทุกเงา ทุกคำพูด เห็นกับดักก่อนใคร']],
  others: [['นึกถึงเพื่อนร่วมทีมก่อน', 'ยอมเจ็บแทนคนอื่น', 'ชีวิตของเพื่อนมาก่อนชีวิตตัวเองเสมอ'], ['ดูแลตัวเองเป็นหลัก', 'เอาตัวรอดก่อนค่อยคิดถึงคนอื่น', 'ทิ้งใครก็ได้ถ้าจำเป็นต้องรอด']],
  compassion: [['ใจอ่อนกับคนที่ลำบาก', 'เห็นใจแม้แต่ศัตรู', 'เมตตาจนบางครั้งเป็นจุดอ่อน'], ['ตัดสินใจเด็ดขาด', 'ไม่ลังเลที่จะทำร้ายถ้าต้องทำ', 'เลือดเย็นถึงกระดูก ลงมือโดยไม่ไหวติง']],
  order: [['เคารพกฎพอสมควร', 'ยึดระเบียบและสายบังคับบัญชา', 'กฎคือทุกอย่าง จัดระบบทุกสิ่งให้เข้าที่'], ['ไม่ชอบถูกบังคับ', 'แหกกฎเมื่อมันขวางทาง', 'คาดเดาไม่ได้ สร้างความวุ่นวายเป็นงานอดิเรก']],
};
function personalityProfile(c, d){
  const bs = budgetState(c); if (bs.left.length) return null;
  const lines = [];
  for (const ax of DATA.meta.personality){ const p = c.personality[ax.id]; if (!p || !p.value) continue; const side = p.side==='left'?0:1; lines.push(PERS_LINES[ax.id][side][Math.min(2, p.value-1)]); }
  const zero = DATA.meta.personality.filter(ax=>{ const p=c.personality[ax.id]; return p && p.value===0; }).map(ax=>`${ax.left}/${ax.right}`);
  const sc = archetypeScores(c, d);
  const top = sc.slice(0,2).map(x=>x.a);
  const talents = [...new Set(top.flatMap(a=>a.talent))].filter(t => t==='EDU' || d.highest.includes(t));
  return { lines, zero, top, sc, talentHint: talents, sets: [...new Set(top.flatMap(a=>a.sets))].slice(0,3) };
}
/* Auto fill Extra: greedy, prefers points that complete an even number (raise Mod) on weighted stats */
function autoFillExtra(c, archId){
  const a = ARCH.find(x=>x.id===archId); if (!a || !c.kin) return;
  c.extra = {};
  let d = compute(c);
  let guard = 0;
  while (d.extraLeft > 0 && guard++ < 60){
    let best = null, bestScore = -1;
    for (const s of STATS){
      const w = a.weights[s] || 0.15; if (d.raw[s] >= 20) continue;
      const completes = (d.raw[s] + 1) % 2 === 0; // next point raises Mod
      const score = w * (completes ? 2.2 : 1) + (d.raw[s] < 10 ? 0.4 : 0);
      if (score > bestScore){ bestScore = score; best = s; }
    }
    if (!best) break;
    c.extra[best] = (c.extra[best]||0) + 1;
    d = compute(c);
  }
}

/* ---- Proficiency ที่มีตัวเลือกย่อย (ความเชื่อ): รายการที่ชื่อขึ้นต้นด้วย "(" ต่อท้าย Proficiency ก่อนหน้า ---- */
function profGroups(L){ const out = []; for (const p of (L && L.proficiencies) || []){ if (p.name.startsWith('(') && out.length) out[out.length-1].subs.push(p); else out.push({prof:p, subs:[]}); } return out; }
function faithKey(name){ const m = String(name||'').match(/-\s*([^)]+)\)?\s*$/); return m ? m[1].trim().replace(/([ั-ฺ็-๎])\1+/g,'$1') : null; }
function faithShort(name){ return String(name||'').replace(/^\(|\)$/g,'').trim(); }
function charFaith(c, exceptKey){ for (const [k,sl] of Object.entries(c.kslots||{})) if (k!==exceptKey && sl && sl.faith) return faithKey(sl.faith); return null; }
/* v1.17: ชื่ออังกฤษของ Proficiency สี่ชื่อแก้ตัวสะกด (DATA.meta.profRenames) · profNow แปลงชื่อเก่าเป็นชื่อปัจจุบัน สำเนาชีทที่ยังไม่ได้ย้ายคีย์จึงยังหาข้อความเจอ */
const PROF_RENAME = (DATA.meta && DATA.meta.profRenames) || {};
function profNow(n){ return typeof n === 'string' && Object.prototype.hasOwnProperty.call(PROF_RENAME, n) ? PROF_RENAME[n] : n; }
function profGroupOf(kid, profName){ const k = KNOW[kid]; if (!k) return null; profName = profNow(profName); for (const L of Object.values(k.levels||{})){ const g = profGroups(L).find(x=>x.prof.name===profName); if (g) return g; } return null; }
function slotIncomplete(sl){ if (!sl || !sl.id || !sl.prof) return true; const g = profGroupOf(sl.id, sl.prof); return !!(g && g.subs.length && !sl.faith); }
function profLabel(sl){ return profNow(sl.prof) + (sl.faith ? ' · ' + faithShort(sl.faith) : ''); }
function profTexts(kid, sl){ const g = profGroupOf(kid, sl.prof); const sub = g && sl.faith ? g.subs.find(x=>x.name===sl.faith) : null; return { text: g ? g.prof.text : '', faithText: sub ? sub.text : '' }; }
/* ชีทรุ่นก่อน: เลือกความเชื่อในวงเล็บเป็น Proficiency ตรง ๆ → แปลงเป็น Proficiency แม่ + faith */
function migrateFaithSlots(c){ let changed=false; for (const sl of Object.values(c.kslots||{})){ if (!sl || !sl.id || !sl.prof || !sl.prof.startsWith('(')) continue; const k = KNOW[sl.id]; if (!k) continue; for (const L of Object.values(k.levels||{})){ const g = profGroups(L).find(x=>x.subs.some(f=>f.name===sl.prof)); if (g){ sl.faith = sl.prof; sl.prof = g.prof.name; changed=true; break; } } } return changed; }

/* ---- ทางเลือกในชุดเริ่มต้น: ไอเทมที่ชื่อขึ้นต้น "หรือ" เป็นทางเลือกของชิ้นก่อนหน้า ---- */
function setItemGroups(set){ const groups = []; for (const it of (set && set.items) || []){ if (/^หรือ\s/.test(it.name) && groups.length) groups[groups.length-1].items.push(it); else groups.push({items:[it]}); } return groups; }
/* v1.16: ย้ายชื่อเก่าในตัวละครที่บันทึกไว้ให้ตรงกับชื่อใหม่ (ไทยขึ้นก่อน)
 * เทียบชื่อตรงตัวกับตารางที่สร้างตอน build (DATA.meta.itemRenames) เท่านั้น ของที่ผู้เล่นตั้งชื่อเองจึงไม่ถูกแตะ · คืน true ถ้ามีการแก้ */
function migrateNames(c){ if (!c) return false; let ch = false; const IR = (DATA.meta && DATA.meta.itemRenames) || {};
  const fix = (o)=>{ if (o && typeof o.name === 'string' && Object.prototype.hasOwnProperty.call(IR, o.name)){ o.name = IR[o.name]; ch = true; } };
  for (const bag of [c.inventory, c.inventory2]) if (Array.isArray(bag)) bag.forEach(fix);
  if (c.equip && typeof c.equip === 'object') Object.values(c.equip).forEach(fix);
  if (c.fleshforge && typeof c.fleshforge.item === 'string' && Object.prototype.hasOwnProperty.call(IR, c.fleshforge.item)){ c.fleshforge.item = IR[c.fleshforge.item]; ch = true; }
  const sfix = (arr)=>{ if (!Array.isArray(arr)) return; arr.forEach((n,i)=>{ if (Object.prototype.hasOwnProperty.call(SKILL_ALIAS, n)){ arr[i] = SKILL_ALIAS[n]; ch = true; } }); };
  for (const arr of Object.values(c.skillSlots||{})) sfix(arr); sfix(c.grants);
  for (const sl of Object.values(c.kslots||{})) if (sl && typeof sl.prof === 'string' && Object.prototype.hasOwnProperty.call(PROF_RENAME, sl.prof)){ sl.prof = PROF_RENAME[sl.prof]; ch = true; } // v1.17: คีย์ Proficiency ที่แก้ตัวสะกด
  const ev = c.evolver; // Starter Skill ที่ Evolver ยืมมา เก็บเป็น 'S:'+ชื่อในไฟล์วงศา ซึ่งบางชื่อสลับลำดับภาษาใน v1.16
  if (ev && ev.kin && typeof ev.pick === 'string' && ev.pick.startsWith('S:') && KIN[ev.kin]){ const old = ev.pick.slice(2); const list = KIN[ev.kin].starterSkills||[];
    if (!list.some(s=>s.name===old)){ const hit = list.find(s=>cleanSkillName(s.name)===cleanSkillName(old)); if (hit){ ev.pick = 'S:'+hit.name; ch = true; } } }
  return ch; }
function cleanAltName(n){ return String(n||'').replace(/^หรือ\s+/, '').replace(/\s*ต้องการ\s+[A-Z]+\s*\d+\s*$/, '').trim(); }
function itemRequirement(n){ const m = String(n||'').match(/ต้องการ\s+([A-Z]+)\s*(\d+)/); return m ? {stat:m[1], value:+m[2], label:`${m[1]} ${m[2]}`} : null; }
/* ไอเทมที่ตัวละครได้จริงตามทางเลือกที่เลือก (c.starterPicks = {groupIndex: itemIndex}) */
function chosenSetItems(c, set){ const picks = c.starterPicks || {}; const out = []; setItemGroups(set).forEach((g, gi) => { const idx = g.items.length > 1 ? Math.min(g.items.length-1, +(picks[gi]||0)) : 0; const it = g.items[idx]; const req = itemRequirement(it.name); out.push(Object.assign({}, it, {name: cleanAltName(it.name), effect: (it.effect||'') + (req ? ` · ต้องการ ${req.label}` : '')})); }); return out; }
/* ===== Twinborn (พื้นหลังพิเศษวัยเด็กของ Lunaryn): สองร่าง วิญญาณดวงเดียว (ผู้ใช้เคาะ 10 พ.ย. 2026)
 * HP และกระเป๋าแยกกัน (c.current.hp / hp2 · c.inventory / inventory2) · MP, Sanity และ Action ใช้ร่วมกัน
 * เดินแยกกันโดยเจตนาได้: c.twinborn = {nameB, apart, control:'A'|'B', log} ร่างที่ผู้เล่นไม่ได้บังคับ GM คุมหลังฉาก ===== */
function isTwinborn(c){ try { const kin = c && c.kin ? KIN[c.kin] : null; const b = kin ? findBg(kin, c.childhood) : null; return !!(b && b.nameEn === 'Twinborn'); } catch(e){ return false; } }
function bodyName(c, body){ const nm = (c && c.name) || 'ตัวละคร'; if (body === 'B'){ const nb = ((c && c.twinborn) || {}).nameB; return (nb && nb.trim()) || `${nm} (ร่าง B)`; } return nm; }
function twinbornState(c){ const tb = (c && c.twinborn) || {}; return {apart: !!tb.apart, control: tb.control === 'B' ? 'B' : 'A'}; }
/* กระเป๋าของร่างที่เลือก (ตัวละครทั่วไปมีใบเดียว) */
function bagOf(c, body){ if (body === 'B' && isTwinborn(c)){ if (!Array.isArray(c.inventory2)) c.inventory2 = []; return c.inventory2; } c.inventory = c.inventory || []; return c.inventory; }
/* Trait/พื้นหลังที่มีทางเลือกย่อยในข้อความ ("เลือกประเภทเป้าหมาย 1 กลุ่ม", "เลือก…1 อย่าง") → ให้ผู้เล่นระบุ */
/* ===== Fleshforge (ศาสตราชีวะ) ของ Swalan: ต้องเลือกไอเทมที่ร่างจะผูกด้วยหนึ่งชิ้น ชนิดใดก็ได้ (อาวุธ โล่ หมวก หน้ากาก เกราะ ของสวมใส่ เครื่องมือ) และเป็นแบบนั้นตลอดทั้งเกม (ผู้ใช้เคาะ 9 พ.ย. 2026) ===== */
const FLESHFORGE = 'Fleshforge';
function hasFleshforge(c){ try { return (typeof allSkills==='function' ? allSkills(c) : []).includes(FLESHFORGE); } catch(e){ return false; } }
/* v1.16: ชื่อไอเทมในคลังสลับเป็นไทยขึ้นก่อน · itemNow แปลงชื่อเก่าเป็นชื่อปัจจุบันก่อนเทียบ ของที่ผูกหรือเก็บไว้ด้วยชื่อเก่าจึงยังจับคู่กับคลังได้ */
function itemNow(n){ const IR = (DATA.meta && DATA.meta.itemRenames) || {}; const k = String(n||'').replace(/\s*×\s*\d+/,'').trim(); return Object.prototype.hasOwnProperty.call(IR, k) ? IR[k] : String(n||''); }
function itemKey(n){ return itemNow(n).replace(/\s*\(.*?\)\s*/g,' ').replace(/\s*×\s*\d+/,'').replace(/\s+/g,' ').trim().toLowerCase(); }
function isFleshforgeItem(c, name){ const f = c && c.fleshforge; return !!(f && f.item && name && (itemKey(f.item) === itemKey(name) || itemKey(name).includes(itemKey(f.item)) || itemKey(f.item).includes(itemKey(name)))); }
/* v1.14 (ผู้ใช้เคาะ 10 พ.ย. 2026): เลือกจากคลังไอเทมของเกม (ค้นหาได้) หรือเขียนชื่อและเอฟเฟกต์เอง · ต้องไม่ใช่ไอเทมวัตถุดิบ อาหาร หรือวัสดุสร้างไอเทม
   c.fleshforge = {item, effect, custom, cat, at} */
/* v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026): เลือกกระสุน ลูกศร อุปกรณ์เวท และของที่ราคามากกว่า 30 เกรฟไม่ได้ (เพิ่มจากวัตถุดิบ อาหาร วัสดุสร้างไอเทมที่ห้ามอยู่เดิม)
 * อุปกรณ์เวท = หมวดไอเทมเวทมนตร์ หมวดอาวุธเวทมนตร์ และของที่ระบุชนิดเป็นอุปกรณ์เวท */
const FF_RAW_CATS = new Set(['วัตถุดิบอาหาร','วัตถุดิบเล่นแร่แปรธาตุ','เสบียงและเครื่องดื่ม']);
const FF_AMMO_CATS = new Set(['กระสุน']);
const FF_MAGIC_CATS = new Set(['ไอเทมเวทมนตร์','อาวุธเวทมนตร์']);
const FF_BLOCK_CATS = new Set([...FF_RAW_CATS, ...FF_AMMO_CATS, ...FF_MAGIC_CATS]);
const FF_MAX_PRICE = 30;
const FF_RULE_TEXT = 'ต้องไม่ใช่วัตถุดิบ อาหาร วัสดุสร้างไอเทม กระสุน ลูกศร อุปกรณ์เวท หรือของที่มีราคามากกว่า 30 เกรฟ';
function itemPrice(it){ const m = /(\d[\d,]*(?:\.\d+)?)/.exec(String((it && it.price) != null ? it.price : '')); return m ? parseFloat(m[1].replace(/,/g,'')) : null; }
/* ก่อน v1.16 ของในชุดเริ่มต้นเขียนชื่อสลับภาษากับคลังหลัก (เช่น "ไม้เท้าเวท (Sorcery Staff)" กับ "Sorcery Staff (ไม้เท้าเวท)") ตอนนี้คลังหลักขึ้นชื่อไทยก่อนเหมือนกันแล้ว แต่บางชิ้นยังมีคำต่อท้าย (เช่น "1 ซอง") และไม่มีหมวดของตัวเอง
   จึงหาคู่ในคลังหลักด้วยชื่อท่อนใดท่อนหนึ่ง แล้วใช้หมวดกับราคาของคลังหลักตัดสินด้วย ไม่งั้นไม้เท้าเวทกับซองกระสุนในชุดเริ่มต้นจะหลุดเกณฑ์ */
function itemNameParts(n){ const s = String(n||'').replace(/\s*×\s*\d+/,'').replace(/\s+\d+\s*(ซอง|ชิ้น|อัน|ดอก|นัด|ขวด|ชุด|ลูก)\s*$/,''); const m = /^(.*?)\s*\((.*?)\)\s*(.*)$/.exec(s); const parts = m ? [m[1], m[2]] : [s]; return parts.map(x=>x.replace(/\s+/g,' ').trim().toLowerCase()).filter(x=>x.length >= 3); }
function catalogTwin(it){ if (!it || it.cat !== 'ชุดเริ่มต้น' || typeof itemCatalog !== 'function') return null; const all = itemCatalog();
  if (!all.__parts){ const ix = new Map(); for (const x of all) if (x.cat !== 'ชุดเริ่มต้น') for (const p of itemNameParts(x.name)) if (!ix.has(p)) ix.set(p, x); Object.defineProperty(all, '__parts', {value: ix}); }
  for (const p of itemNameParts(it.name)){ const x = all.__parts.get(p); if (x) return x; } return null; }
/* เหตุผลที่ผูกกับ Fleshforge ไม่ได้ (สตริงว่าง = ผูกได้) */
function fleshforgeWhyNot(it){
  if (!it) return 'ไม่พบไอเทม';
  const tw = catalogTwin(it); if (tw){ const w = fleshforgeWhyNot(tw); if (w) return w; }
  const n = String(it.name||''), e = String(it.effect||'');
  if (FF_RAW_CATS.has(it.cat) || /เสบียง|Ration\b/i.test(n) || /^\s*(วัตถุดิบ(หลัก|รอง)?|เสบียง|อาหาร)/.test(e) || /ชนิด:\s*(แร่|วัตถุดิบ|วัสดุ|อาหาร)/.test(e)) return 'เป็นวัตถุดิบ อาหาร หรือวัสดุสร้างไอเทม';
  if (FF_AMMO_CATS.has(it.cat) || /ชนิด:\s*(ลูกศร|ลูกหน้าไม้|ลูกดอก|กระสุน)/.test(e) || /^\s*(กระสุน|ลูกศร|หัวศร|ลูกหน้าไม้|ลูกดอก)/.test(n)) return 'เป็นกระสุนหรือลูกศร';
  if (FF_MAGIC_CATS.has(it.cat) || /อุปกรณ์เวท/.test(e) || /อุปกรณ์เวท/.test(n)) return 'เป็นอุปกรณ์เวท';
  const p = itemPrice(it); if (p != null && p > FF_MAX_PRICE) return `ราคา ${p} เกรฟ เกิน ${FF_MAX_PRICE} เกรฟ`;
  return '';
}
function fleshforgeAllowed(it){ return !fleshforgeWhyNot(it); }
/* ไอเทมที่ผูกไว้ก่อน v1.15 ยังผ่านเกณฑ์ใหม่ไหม (ของเขียนเองตรวจไม่ได้ ให้ GM ตัดสิน) */
function fleshforgeIssue(c){ const f = c && c.fleshforge; if (!f || !f.item || f.custom) return ''; const hit = (typeof itemCatalog==='function' ? itemCatalog() : []).find(it=>itemKey(it.name)===itemKey(f.item)); return hit ? fleshforgeWhyNot(hit) : ''; }
function fleshforgeCatalog(){ return (typeof itemCatalog==='function' ? itemCatalog() : []).filter(fleshforgeAllowed); }
function setFleshforge(c, v, opts){ const at = (c.fleshforge && c.fleshforge.at) || Date.now(); c.fleshforge = Object.assign({item:'', effect:'', custom:false, cat:''}, v, {at}); modal(null); if (opts && opts.onChange) opts.onChange(); }
/* หน้าต่างค้นคลังไอเทม: แสดงเฉพาะของที่ผูกได้ */
function fleshforgeCatalogModal(c, opts={}){
  const all = fleshforgeCatalog(); const cats = [...new Set(all.map(i=>i.cat).filter(Boolean))];
  const q = h('input',{class:'ffsearch',placeholder:'ค้นหาไอเทม (ชื่อหรือเอฟเฟกต์)',style:'min-width:220px;flex:1'}); const list = h('div',{class:'giftlist fflist'});
  const catSel = h('select',{class:'ffcat'}, h('option',{value:'',text:`ทุกหมวดที่ผูกได้ (${all.length})`}), cats.map(k=>h('option',{value:k,text:`${k} (${all.filter(i=>i.cat===k).length})`})));
  const pick = (it)=>{ if (opts.confirmBind && !confirm(`ผูก ${it.name} เป็นไอเทมมีชีวิตของ ${c.name||'ตัวละครนี้'}? ผูกแล้วเปลี่ยนไม่ได้ตลอดทั้งเกม`)) return; setFleshforge(c, {item: it.name, effect: it.effect||'', custom:false, cat: it.cat||''}, opts); };
  const draw = ()=>{ clear(list); const k = q.value.trim().toLowerCase(); const ck = catSel.value;
    const hitsAll = all.filter(it => (!ck || it.cat===ck) && (!k || it.name.toLowerCase().includes(k) || (it.effect||'').toLowerCase().includes(k) || (it.desc||'').toLowerCase().includes(k))); const hits = hitsAll.slice(0, 60);
    if (!hits.length) list.append(h('div',{class:'dim',text:'ไม่พบไอเทมที่ผูกได้ตามคำค้นนี้ (วัตถุดิบ อาหาร วัสดุสร้างไอเทม กระสุน ลูกศร อุปกรณ์เวท และของที่ราคาเกิน 30 เกรฟไม่อยู่ในรายการ) จะเขียนชื่อและเอฟเฟกต์เองก็ได้'}));
    for (const it of hits) list.append(h('div',{class:'gift'}, h('div',null, h('b',{text:it.name}), h('span',{class:'dim',style:'font-size:11px',text:` · ${it.cat}${it.sub ? ' · '+it.sub : ''}${it.weight ? ' · '+it.weight+' กก.' : ''}${itemPrice(it)!=null ? ' · '+itemPrice(it)+' เกรฟ' : ''}`}), it.desc ? h('div',{class:'dim',style:'font-size:11.5px'}, it.desc.slice(0,140)) : null, h('div',{class:'desc',style:'font-size:12px'}, T(it.effect||''))), h('button',{class:'small primary',onclick:()=>pick(it),text:'ผูกชิ้นนี้'})));
    if (hitsAll.length > hits.length) list.append(h('div',{class:'dim',style:'font-size:12px',text:`แสดง ${hits.length} จาก ${hitsAll.length} พิมพ์ค้นหาเพิ่มเพื่อกรอง`})); };
  q.oninput = draw; catSel.onchange = draw; draw();
  modal(h('div',{class:'ffmodal'}, h('h3',{text:'🧬 เลือกไอเทมมีชีวิตจากคลังไอเทมของเกม'}), h('p',{class:'dim',style:'font-size:12.5px;margin:4px 0 8px',text:'รายการจาก Item All ทั้งไฟล์และชุดเริ่มต้น ตัดวัตถุดิบ อาหาร เครื่องดื่ม วัสดุสร้างไอเทม กระสุน ลูกศร อุปกรณ์เวท และของที่ราคาเกิน 30 เกรฟออกแล้ว เพราะผูกกับ Fleshforge ไม่ได้'}), h('div',{class:'row',style:'margin-bottom:6px'}, catSel, q), list,
    h('div',{class:'row',style:'margin-top:10px'}, h('button',{class:'small',onclick:()=>fleshforgeCustomModal(c, opts),text:'✎ ไม่เจอของที่ต้องการ เขียนชื่อและเอฟเฟกต์เอง'}))));
  setTimeout(()=>q.focus(), 50);
}
/* เขียนไอเทมเอง: ชื่อ + เอฟเฟกต์ (ชื่อที่ตรงกับวัตถุดิบ/อาหาร/วัสดุในคลังถูกปฏิเสธ) */
function fleshforgeCustomModal(c, opts={}){
  const f = c.fleshforge || {};
  const nameI = h('input',{class:'ffname',placeholder:'ชื่อไอเทม เช่น หน้ากากกระดูกวาฬ',style:'width:100%'}); nameI.value = f.custom ? (f.item||'') : '';
  const effI = h('textarea',{class:'ffeffect',placeholder:'เอฟเฟกต์ของไอเทม เช่น Armor 1/1 (Blunt) หรือ 2 PDMG (Slashing), Rip',style:'min-height:110px;width:100%'}); effI.value = f.custom ? (f.effect||'') : '';
  const ok = ()=>{ const nm = nameI.value.trim(); if (!nm){ toast('ใส่ชื่อไอเทมก่อน'); nameI.focus(); return; }
    const hit = (typeof itemCatalog==='function' ? itemCatalog() : []).find(it=>itemKey(it.name)===itemKey(nm));
    if (hit && !fleshforgeAllowed(hit)){ toast(`${hit.name} ${fleshforgeWhyNot(hit)} ผูกกับ Fleshforge ไม่ได้`); return; }
    if (opts.confirmBind && !confirm(`ผูก ${nm} เป็นไอเทมมีชีวิตของ ${c.name||'ตัวละครนี้'}? ผูกแล้วเปลี่ยนไม่ได้ตลอดทั้งเกม`)) return;
    setFleshforge(c, {item:nm, effect:effI.value.trim(), custom:true, cat:''}, opts); };
  modal(h('div',{class:'ffmodal'}, h('h3',{text:'🧬 เขียนไอเทมมีชีวิตเอง'}), h('p',{class:'dim',style:'font-size:12.5px;margin:4px 0 8px',text:'ใส่ชื่อและเอฟเฟกต์ของไอเทมที่ร่างของคุณจะกลายเป็น จะเป็นอาวุธ โล่ หมวก หน้ากาก เกราะ เครื่องมือ หรือของสวมใส่ชนิดใดก็ได้ แต่' + FF_RULE_TEXT + ' ของที่เขียนเองให้ GM เทียบมูลค่ากับไอเทมในคลัง'}),
    h('label',{style:'font-size:12.5px',text:'ชื่อไอเทม'}), nameI, h('label',{style:'font-size:12.5px;margin-top:8px;display:block',text:'เอฟเฟกต์'}), effI,
    h('div',{class:'row',style:'margin-top:10px;gap:8px'}, h('button',{class:'primary ffsave',onclick:ok,text:'ผูกไอเทมนี้'}), h('button',{class:'small ghost',onclick:()=>fleshforgeCatalogModal(c, opts),text:'← กลับไปค้นคลังไอเทม'}))));
  setTimeout(()=>nameI.focus(), 50);
}
/* กล่องไอเทมมีชีวิต: ล็อกเมื่ออยู่ในแคมเปญ (ผู้พัฒนายกเว้น) · onChange เรียกหลังเลือก · confirmBind = ถามยืนยันก่อนผูก (ใช้ในชีท ที่ผูกแล้วแก้ไม่ได้) */
function fleshforgePicker(c, opts={}){
  c.fleshforge = c.fleshforge || {item:'', effect:'', custom:false, cat:''};
  const f = c.fleshforge; const locked = !!opts.locked;
  const box = h('div',{class:'card ffbox',style:'margin-top:12px'});
  box.append(h('h3',null, '🧬 ศาสตราชีวะ (Fleshforge)', h('span',{class:'en',text:'ไอเทมมีชีวิตของคุณ'})));
  box.append(h('p',{class:'desc',style:'margin:4px 0 8px',text:'เลือกไอเทมหนึ่งชิ้นที่ร่างของคุณจะกลายเป็นเมื่อใช้ Fleshforge ค้นจากคลังไอเทมของเกม หรือเขียนชื่อและเอฟเฟกต์เองก็ได้ จะเป็นอาวุธ โล่ หมวก หน้ากาก เกราะ เครื่องมือ หรือของสวมใส่ชนิดใดก็ได้ แต่' + FF_RULE_TEXT + ' เลือกแล้วผูกกับตัวละครตลอดทั้งเกม เปลี่ยนไม่ได้'}));
  if (f.item) box.append(h('div',{class:'ffcur'}, h('div',{class:'gives'}, tag('🧬 '+f.item,'prop'), f.custom ? tag('เขียนเอง') : (f.cat ? tag(f.cat) : null), locked ? tag('🔒 ผูกถาวรตลอดเกม','warn') : null, fleshforgeIssue(c) ? h('span',{class:'tag neg ffissue',title:'ไอเทมนี้ผูกไว้ก่อนกติกาใหม่ (11 พ.ย. 2026) ให้ GM ตัดสินว่าจะให้เลือกใหม่หรือไม่',text:'⚠ ไม่ผ่านเกณฑ์ใหม่: '+fleshforgeIssue(c)}) : null), f.effect ? h('div',{class:'desc ffeff',style:'font-size:12.5px;margin-top:4px'}, T(f.effect)) : h('div',{class:'dim',style:'font-size:12px;margin-top:4px',text:'ยังไม่ได้จดเอฟเฟกต์ของไอเทมนี้'})));
  else box.append(h('div',{class:'gives'}, tag(locked ? '🧬 ยังไม่ได้เลือก' : 'ยังไม่ได้เลือกไอเทม','warn'), locked ? tag('🔒 ผูกถาวรตลอดเกม','warn') : null));
  if (locked) return box;
  box.append(h('div',{class:'row',style:'margin-top:8px;gap:8px'}, h('button',{class:'small primary ffpick',onclick:()=>fleshforgeCatalogModal(c, opts),text: f.item ? '🔎 เปลี่ยนเป็นชิ้นอื่นจากคลังไอเทม' : '🔎 ค้นจากคลังไอเทมของเกม'}), h('button',{class:'small ffcustom',onclick:()=>fleshforgeCustomModal(c, opts),text: f.item && f.custom ? '✎ แก้ชื่อและเอฟเฟกต์' : '✎ เขียนชื่อและเอฟเฟกต์เอง'})));
  box.append(h('p',{class:'dim',style:'font-size:12px;margin:6px 0 0',text:'เมื่อแปรร่าง ไอเทมมีชีวิตมี HP และ Toughness เท่ากับคุณ ใครแตะโดยไม่ได้รับอนุญาตโดน 1d3 Necrotic เมื่อถึงเทิร์นของคุณ (ดูสกิลเต็มในคัมภีร์)'}));
  return box;
}
function traitNeedsPick(text){ return /เลือก[^.\n]{0,60}?(1|หนึ่ง|๑)\s*(กลุ่ม|ประเภท|อย่าง|ชนิด|ภาษา|สาย|ค่า|แบบ|ทาง|ตัว|เผ่า|สำนัก|วงศา|เป้าหมาย|ธาตุ)/.test(String(text||'')) || /เลือก(ประเภท|กลุ่ม|เป้าหมาย|ธาตุ|ภาษา|สัตว์|อาวุธ)[^.\n]{0,40}(1|หนึ่ง)/.test(String(text||'')); }
function traitPickInput(c, key, placeholder, onChange){ c.traitPicks = c.traitPicks || {}; const inp = h('input',{value:c.traitPicks[key]||'', placeholder: placeholder||'ระบุทางเลือกที่เลือก', oninput:(e)=>{ c.traitPicks[key] = e.target.value; if (onChange) onChange(); }}); return h('div',{class:'traitpick'}, h('span',{class:'tag prop',text:'ทางเลือก'}), inp); }

/* ---- Knowledge Check (คำตัดสิน 9 พ.ย. 2026): 2d6 + ระดับความรู้ + Mod ค่าพลังกำกับ (ตัวที่สูงกว่าในคู่) + บุคลิกภาพถ้าเข้าบริบท ---- */
/* Knowledge Check = 2d6 + ระดับความรู้ (+ บุคลิกภาพที่เกี่ยวตอนทอย) ไม่รวม Mod ค่าพลัง (ผู้ใช้เคาะ 9 พ.ย. 2026 แก้จากคำตัดสินก่อนหน้า) */
function knowledgeBonus(c, d, k){ const lv = (knowledgeLevels(c)[k.id]||0); return { lv, stat: k.stats[0], mod: 0, total: lv }; }
/* สีหัวสกิล/Trait ตามค่าพลังที่การทอยนั้นเกี่ยว (ผู้ใช้เคาะ 9 พ.ย. 2026): หลบ/ปีน = AGI เขียว · ป้องกัน/Saving Throw = VIT ส้ม · ประชิด/Might = STR แดง · ระยะ/สังเกต = PER เหลือง · โน้มน้าว/Sanity = INF ม่วง · เวท/ความรู้ = INT ฟ้า */
const HUE_RULES = [
  ['AGI', /\bAGI\b/g, 3], ['AGI', /Evade|Reflex|หลบ|ปีน|Acrobat|Stealth|Burglary|ซ่อนตัว|คล่อง|กระโดด|\bDash\b|Speed|ความเร็ว|ลอบ|Unbalanced/g, 1],
  ['VIT', /\bVIT\b/g, 3], ['VIT', /Saving Throw|ป้องกัน|ต้านทาน|Resist|Toughness|Fortitude|Parry|Armor|เกราะ|\bHP\b|ฟื้นฟู|Heal|รักษา|Insulation|แข็งแรง|Temporary|ทนทาน|Immun|พิษ|Poison|Bleed/g, 1],
  ['STR', /\bSTR\b/g, 3], ['STR', /Might|Melee|Unarmed|Grab|พละกำลัง|ทุบ|แบก|Guard Break|Impact|ประชิด|Weapon|อาวุธ|Attack Roll|Perfect Strike/g, 1],
  ['PER', /\bPER\b/g, 3], ['PER', /Sight|Range|ระยะไกล|ธนู|ยิง|สังเกต|Initiative|Passive|สายตา|มองเห็น|Perception|\bAim\b|Focus|ค้นหา|สะกดรอย|Marked|Hidden/g, 1],
  ['INF', /\bINF\b/g, 3], ['INF', /Sanity|Persua|โน้มน้าว|ข่มขู่|Intimid|หลอก|ขวัญ|Frighten|Charm|บารมี|Perform|Decept|เจรจา|ต่อรอง|Morale|Fear/g, 1],
  ['INT', /\bINT\b/g, 3], ['INT', /Knowledge|Sorcer|เวท|\bCast\b|\bMP\b|Crafting|Alchemy|Medical|ปัญญา|Mana|มานา|Arcane|Ritual|ความรู้|วิเคราะห์|Spell/g, 1],
];
function rollHue(...texts){ const s = texts.filter(Boolean).join(' '); const score = {}; for (const [st, rx, w] of HUE_RULES){ rx.lastIndex = 0; const n = (s.match(rx)||[]).length; if (n) score[st] = (score[st]||0) + n*w; } let best = null; for (const st of STATS) if (score[st] && (!best || score[st] > score[best])) best = st; return best; }
function hueCls(...texts){ const hue = rollHue(...texts); return hue ? ' hue sc-'+hue : ''; }
