/* ===== UI helpers: stat colours, glossary popovers, archetype engine ===== */
const STAT_COLORS = { STR:'#e5484d', AGI:'#3fb950', VIT:'#f08c2e', PER:'#e8c547', INF:'#a371f7', INT:'#58b7ff' };
const STAT_TH = { STR:'พละกำลัง', AGI:'ความคล่องแคล่ว', VIT:'ความแข็งแรง', PER:'การรับรู้', INF:'อิทธิพล', INT:'ปัญญา' };
function statStyle(s){ return `--sc:${STAT_COLORS[s]||'var(--mana)'}`; }

/* ---- Glossary: wrap known terms in clickable spans ---- */
const GLOSSARY = DATA.glossary || {};
const GL_TERMS = Object.keys(GLOSSARY).sort((a,b)=>b.length-a.length);
const GL_RE = GL_TERMS.length ? new RegExp('(' + GL_TERMS.map(t=>t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|') + ')(?![A-Za-z])', 'g') : null;
/* ชื่อเฉพาะที่ห้ามขีดเส้นศัพท์ข้างใน (ชื่อสกิล Proficiency Trait พื้นหลัง ชุด ฯลฯ) เช่น "Yantra Master" ไม่ใช่ Master ระดับทักษะ */
const PROTECTED_NAMES = (()=>{
  const names = new Set();
  const add = (n)=>{ if (!n) return; n = String(n).replace(/^\(|\)$/g,'').trim(); if (n && /[A-Za-z]/.test(n)) names.add(n); };
  for (const sk of DATA.skills||[]) add(sk.nameEn);
  for (const k of DATA.knowledge||[]){ for (const L of Object.values(k.levels||{})) for (const p of L.proficiencies||[]) add(p.name.replace(/\s*-\s*[^)]*\)?$/,'')); }
  for (const kin of DATA.kins||[]){ for (const list of ['traits','benefits','hindrances']) for (const x of kin[list]||[]) add(x.nameEn); for (const list of ['childhood','specialChildhood','adulthood','specialAdulthood']) for (const b of kin[list]||[]) add(b.nameEn); for (const sk of kin.starterSkills||[]) add(sk.name.replace(/\(.*$/,'')); }
  for (const st of (DATA.sets && DATA.sets.sets)||[]) add(st.nameEn);
  // เก็บเฉพาะชื่อที่มีคำศัพท์อยู่ข้างใน (ชื่ออื่นไม่ต้องป้องกัน) และยาวก่อน
  const out = [...names].filter(n => { if (!GL_RE) return false; GL_RE.lastIndex = 0; return GL_RE.test(n) && !GLOSSARY[n]; }).sort((a,b)=>b.length-a.length);
  return out;
})();
const PROTECT_RE = PROTECTED_NAMES.length ? new RegExp('(' + PROTECTED_NAMES.map(t=>t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|') + ')(?![A-Za-z])', 'g') : null;
function protectedSpans(s){ const spans = []; if (!PROTECT_RE) return spans; PROTECT_RE.lastIndex = 0; let m; while ((m = PROTECT_RE.exec(s))){ const prev = s[m.index-1]; if (prev && /[A-Za-z0-9]/.test(prev)) continue; spans.push([m.index, m.index + m[0].length]); } return spans; }
/* คำศัพท์คำเดียวที่ชิดกับคำอังกฤษตัวใหญ่ที่ไม่ใช่ศัพท์ (เช่น "Yantra Master", "Martial Skill") ถือเป็นส่วนของชื่อ ไม่ขีด */
function partOfName(s, start, end, term){
  if (term.includes(' ')) return false;
  const before = s.slice(0, start).match(/([A-Z][A-Za-z'\-]*)\s$/); const after = s.slice(end).match(/^\s([A-Z][A-Za-z'\-]*)/);
  const isTerm = (w)=> !!GLOSSARY[w] || STATS.includes(w);
  if (before && !isTerm(before[1])) return true;
  if (after && !isTerm(after[1])) return true;
  return false;
}
function termify(text){
  const frag = document.createDocumentFragment();
  if (text == null) return frag;
  const s = String(text);
  if (!GL_RE){ frag.append(s); return frag; }
  const prot = protectedSpans(s);
  let last = 0; GL_RE.lastIndex = 0; let m; let count = 0;
  while ((m = GL_RE.exec(s)) && count < 60){
    const start = m.index; const term = m[1]; const end = start + term.length;
    // avoid matching inside a latin word (e.g. "Cast" inside "Forecast")
    const prev = s[start-1]; if (prev && /[A-Za-z0-9]/.test(prev)) { continue; }
    if (prot.some(([a,b]) => start < b && end > a)) continue;
    if (partOfName(s, start, end, term)) continue;
    if (start > last) frag.append(s.slice(last, start));
    frag.append(h('span', {class:'term', tabindex:0, role:'button', dataset:{term}, onclick:(e)=>{ showTerm(term, e.currentTarget); }, onkeydown:(e)=>{ if (e.key==='Enter'||e.key===' '){ e.preventDefault(); showTerm(term, e.currentTarget); } }}, term));
    last = end; count++;
  }
  if (last < s.length) frag.append(s.slice(last));
  return frag;
}
const T = termify;
let popEl = null;
function showTerm(term, anchor){
  hideTerm();
  const g = GLOSSARY[term]; if (!g) return;
  popEl = h('div', {class:'pop', role:'dialog'}, h('div', {class:'pop-h'}, h('b', {text: term}), g.th ? h('span', {class:'dim', text:' ' + g.th}) : null, h('button', {class:'small ghost', style:'margin-left:auto', onclick:hideTerm, text:'✕'})), h('div', {class:'pop-b'}, termifyShallow(g.text)), h('div', {class:'pop-c', text: g.cat||''}));
  document.body.append(popEl);
  const z = uiZoom(); const r = anchor.getBoundingClientRect(); const pw = Math.min(360, vw() - 24); // พิกัดจอ → พิกัดหลัง zoom
  popEl.style.width = pw + 'px';
  let left = Math.max(12, Math.min(r.left/z, vw() - pw - 12));
  let top = (r.bottom + 8 + window.scrollY)/z;
  popEl.style.left = left + 'px'; popEl.style.top = top + 'px';
  requestAnimationFrame(()=>{ const ph = popEl.offsetHeight; if (r.bottom/z + 8 + ph > vh()) popEl.style.top = Math.max(12, r.top/z - ph - 8) + window.scrollY/z + 'px'; });
  setTimeout(()=>document.addEventListener('click', hideTermOnce), 0);
}
function termifyShallow(text){ // one level only, no nested popups inside popup text
  const frag = document.createDocumentFragment(); frag.append(String(text||'')); return frag; }
function hideTermOnce(e){ if (popEl && !popEl.contains(e.target)) hideTerm(); }
function hideTerm(){ if (popEl){ popEl.remove(); popEl=null; document.removeEventListener('click', hideTermOnce); } }
document.addEventListener('keydown', e => { if (e.key==='Escape') hideTerm(); });

/* ---- Archetype engine ---- */
const ARCH = DATA.meta.archetypes;
function persVec(c){ // +value toward left pole
  const v = {}; for (const ax of DATA.meta.personality){ const p = c.personality[ax.id]; v[ax.id] = (p && p.value!=null) ? (p.side==='left' ? p.value : -p.value) : 0; } return v; }
// archetype affinity from personality (left = +): logic, confront, brave, others, compassion, order
const ARCH_PERS = {
  'Tank':          {confront: 2, others: 3, brave: 1, order: 1},
  'Fighter':       {confront: 3, brave: 2, order: 1},
  'Damage Dealer': {confront: 2, compassion: -2, logic: -1},
  'Striker':       {confront: 1, logic: -2, order: -2, compassion: -1},
  'Skirmisher':    {confront: -2, logic: -1, brave: 1, order: -1},
  'Rogue':         {confront: -2, brave: -2, others: -2, order: -2},
  'Support':       {others: 3, compassion: 3, confront: -1},
  'Controller':    {logic: 3, brave: -1, order: 2},
  'Specialist':    {logic: 3, order: 2, confront: -1},
  'Utility':       {brave: 1, logic: 1, confront: -1},
};
function archetypeScores(c, d){
  const pv = persVec(c); const out = [];
  for (const a of ARCH){
    let s = 0;
    for (const [ax, w] of Object.entries(ARCH_PERS[a.id]||{})) s += w * (pv[ax]||0);
    for (const [st, w] of Object.entries(a.weights)) s += w * (d.mod[st]||0) * 0.8;
    out.push({a, s});
  }
  return out.sort((x,y)=>y.s-x.s);
}
const PERS_LINES = { // id → [leftTexts by level, rightTexts by level]
  logic: [['คิดก่อนทำ ชอบวิเคราะห์และวางแผน', 'ใช้เหตุผลนำอารมณ์ เชื่อข้อมูลมากกว่าลางสังหรณ์', 'นักวางแผนตัวยง ทุกการตัดสินใจต้องมีเหตุผลรองรับ'], ['ทำตามความรู้สึกแรก', 'เชื่อสัญชาตญาณมากกว่าตำรา', 'สัญชาตญาณดิบนำทุกอย่าง ตอบสนองก่อนที่สมองจะทัน']],
  confront: [['ไม่ถอยเมื่อเจอปัญหา', 'ชอบเผชิญหน้าตรง ๆ', 'พุ่งชนทุกอุปสรรคแบบไม่คิดเลี่ยง'], ['เลี่ยงการปะทะเมื่อเลี่ยงได้', 'ถนัดหลบมากกว่าชน', 'ไม่สู้ถ้าไม่จำเป็น ถอยหรือหายตัวก่อนเสมอ']],
  brave: [['กล้าเสี่ยงพอประมาณ', 'กล้าสำรวจสิ่งที่คนอื่นกลัว', 'ไม่รู้จักกลัว เดินเข้าหาความมืดเป็นคนแรก'], ['ระวังตัวอยู่เสมอ', 'ไม่ไว้ใจอะไรง่าย ๆ ชอบจับผิด', 'ระแวงทุกเงา ทุกคำพูด เห็นกับดักก่อนใคร']],
  others: [['นึกถึงเพื่อนร่วมทีมก่อน', 'ยอมเจ็บแทนคนอื่น', 'ชีวิตของเพื่อนมาก่อนชีวิตตัวเองเสมอ'], ['ดูแลตัวเองเป็นหลัก', 'เอาตัวรอดก่อนค่อยคิดถึงคนอื่น', 'ทิ้งใครก็ได้ถ้าจำเป็นต้องรอด']],
  compassion: [['ใจอ่อนกับคนที่ลำบาก', 'เห็นใจแม้แต่ศัตรู', 'เมตตาจนบางครั้งเป็นจุดอ่อน'], ['ตัดสินใจเด็ดขาด', 'ไม่ลังเลที่จะทำร้ายถ้าต้องทำ', 'เลือดเย็นถึงกระดูก ลงมือโดยไม่ไหวติง']],
  order: [['เคารพกฎพอสมควร', 'ยึดระเบียบและสายบังคับบัญชา', 'กฎคือทุกอย่าง จัดระบบทุกสิ่งให้เข้าที่'], ['ไม่ชอบถูกบังคับ', 'แหกกฎเมื่อมันขวางทาง', 'คาดเดาไม่ได้ สร้างความวุ่นวายเป็นงานอดิเรก']],
};
function personalityProfile(c, d){
  const bs = budgetState(c); if (bs.left.length) return null;
  const lines = [];
  for (const ax of DATA.meta.personality){ const p = c.personality[ax.id]; if (!p || !p.value) continue; const side = p.side==='left'?0:1; lines.push(PERS_LINES[ax.id][side][Math.min(2, p.value-1)]); }
  const zero = DATA.meta.personality.filter(ax=>{ const p=c.personality[ax.id]; return p && p.value===0; }).map(ax=>`${ax.left}/${ax.right}`);
  const sc = archetypeScores(c, d);
  const top = sc.slice(0,2).map(x=>x.a);
  const talents = [...new Set(top.flatMap(a=>a.talent))].filter(t => t==='EDU' || d.highest.includes(t));
  return { lines, zero, top, sc, talentHint: talents, sets: [...new Set(top.flatMap(a=>a.sets))].slice(0,3) };
}
/* Auto fill Extra: greedy, prefers points that complete an even number (raise Mod) on weighted stats */
function autoFillExtra(c, archId){
  const a = ARCH.find(x=>x.id===archId); if (!a || !c.kin) return;
  c.extra = {};
  let d = compute(c);
  let guard = 0;
  while (d.extraLeft > 0 && guard++ < 60){
    let best = null, bestScore = -1;
    for (const s of STATS){
      const w = a.weights[s] || 0.15; if (d.raw[s] >= 20) continue;
      const completes = (d.raw[s] + 1) % 2 === 0; // next point raises Mod
      const score = w * (completes ? 2.2 : 1) + (d.raw[s] < 10 ? 0.4 : 0);
      if (score > bestScore){ bestScore = score; best = s; }
    }
    if (!best) break;
    c.extra[best] = (c.extra[best]||0) + 1;
    d = compute(c);
  }
}

/* ---- Proficiency ที่มีตัวเลือกย่อย (ความเชื่อ): รายการที่ชื่อขึ้นต้นด้วย "(" ต่อท้าย Proficiency ก่อนหน้า ---- */
function profGroups(L){ const out = []; for (const p of (L && L.proficiencies) || []){ if (p.name.startsWith('(') && out.length) out[out.length-1].subs.push(p); else out.push({prof:p, subs:[]}); } return out; }
function faithKey(name){ const m = String(name||'').match(/-\s*([^)]+)\)?\s*$/); return m ? m[1].trim().replace(/([ั-ฺ็-๎])\1+/g,'$1') : null; }
function faithShort(name){ return String(name||'').replace(/^\(|\)$/g,'').trim(); }
function charFaith(c, exceptKey){ for (const [k,sl] of Object.entries(c.kslots||{})) if (k!==exceptKey && sl && sl.faith) return faithKey(sl.faith); return null; }
function profGroupOf(kid, profName){ const k = KNOW[kid]; if (!k) return null; for (const L of Object.values(k.levels||{})){ const g = profGroups(L).find(x=>x.prof.name===profName); if (g) return g; } return null; }
function slotIncomplete(sl){ if (!sl || !sl.id || !sl.prof) return true; const g = profGroupOf(sl.id, sl.prof); return !!(g && g.subs.length && !sl.faith); }
function profLabel(sl){ return sl.prof + (sl.faith ? ' · ' + faithShort(sl.faith) : ''); }
function profTexts(kid, sl){ const g = profGroupOf(kid, sl.prof); const sub = g && sl.faith ? g.subs.find(x=>x.name===sl.faith) : null; return { text: g ? g.prof.text : '', faithText: sub ? sub.text : '' }; }
/* ชีทรุ่นก่อน: เลือกความเชื่อในวงเล็บเป็น Proficiency ตรง ๆ → แปลงเป็น Proficiency แม่ + faith */
function migrateFaithSlots(c){ let changed=false; for (const sl of Object.values(c.kslots||{})){ if (!sl || !sl.id || !sl.prof || !sl.prof.startsWith('(')) continue; const k = KNOW[sl.id]; if (!k) continue; for (const L of Object.values(k.levels||{})){ const g = profGroups(L).find(x=>x.subs.some(f=>f.name===sl.prof)); if (g){ sl.faith = sl.prof; sl.prof = g.prof.name; changed=true; break; } } } return changed; }

/* ---- ทางเลือกในชุดเริ่มต้น: ไอเทมที่ชื่อขึ้นต้น "หรือ" เป็นทางเลือกของชิ้นก่อนหน้า ---- */
function setItemGroups(set){ const groups = []; for (const it of (set && set.items) || []){ if (/^หรือ\s/.test(it.name) && groups.length) groups[groups.length-1].items.push(it); else groups.push({items:[it]}); } return groups; }
function cleanAltName(n){ return String(n||'').replace(/^หรือ\s+/, '').replace(/\s*ต้องการ\s+[A-Z]+\s*\d+\s*$/, '').trim(); }
function itemRequirement(n){ const m = String(n||'').match(/ต้องการ\s+([A-Z]+)\s*(\d+)/); return m ? {stat:m[1], value:+m[2], label:`${m[1]} ${m[2]}`} : null; }
/* ไอเทมที่ตัวละครได้จริงตามทางเลือกที่เลือก (c.starterPicks = {groupIndex: itemIndex}) */
function chosenSetItems(c, set){ const picks = c.starterPicks || {}; const out = []; setItemGroups(set).forEach((g, gi) => { const idx = g.items.length > 1 ? Math.min(g.items.length-1, +(picks[gi]||0)) : 0; const it = g.items[idx]; const req = itemRequirement(it.name); out.push(Object.assign({}, it, {name: cleanAltName(it.name), effect: (it.effect||'') + (req ? ` · ต้องการ ${req.label}` : '')})); }); return out; }
/* Trait/พื้นหลังที่มีทางเลือกย่อยในข้อความ ("เลือกประเภทเป้าหมาย 1 กลุ่ม", "เลือก…1 อย่าง") → ให้ผู้เล่นระบุ */
/* ===== Fleshforge (ศาสตราชีวะ) ของ Swalan: ต้องเลือกไอเทมที่ร่างจะผูกด้วยหนึ่งชิ้น ชนิดใดก็ได้ (อาวุธ โล่ หมวก หน้ากาก เกราะ ของสวมใส่ เครื่องมือ) และเป็นแบบนั้นตลอดทั้งเกม (ผู้ใช้เคาะ 9 พ.ย. 2026) ===== */
const FLESHFORGE = 'Fleshforge';
function hasFleshforge(c){ try { return (typeof allSkills==='function' ? allSkills(c) : []).includes(FLESHFORGE); } catch(e){ return false; } }
function itemKey(n){ return String(n||'').replace(/\s*\(.*?\)\s*/g,' ').replace(/\s*×\s*\d+/,'').replace(/\s+/g,' ').trim().toLowerCase(); }
function isFleshforgeItem(c, name){ const f = c && c.fleshforge; return !!(f && f.item && name && (itemKey(f.item) === itemKey(name) || itemKey(name).includes(itemKey(f.item)) || itemKey(f.item).includes(itemKey(name)))); }
/* รายชื่อไอเทมที่เลือกผูกได้: ของในชุดเริ่มต้นที่เลือก ชุดยังชีพ และของที่สวม/อยู่ในกระเป๋าตอนนี้ */
function fleshforgeCandidates(c){
  const names = []; const push = (n)=>{ n = String(n||'').replace(/\(เสนอ\)\s*/,'').replace(/\s*×\s*\d+/,'').trim(); if (n && !names.some(x=>itemKey(x)===itemKey(n))) names.push(n); };
  const set = c.starterSet ? DATA.sets.sets.find(x=>x.nameEn===c.starterSet) : null; if (set) for (const it of chosenSetItems(c, set)) push(it.name);
  for (const e of Object.values(c.equip||{})) if (e && e.name) push(e.name);
  for (const it of c.inventory||[]) push(it.name);
  for (const it of DATA.sets.common.items) push(it.name);
  return names;
}
/* ตัวเลือกไอเทมมีชีวิต: ล็อกเมื่ออยู่ในแคมเปญ (ผู้พัฒนายกเว้น) · onChange เรียกเมื่อเลือกจากรายการ (พิมพ์เองไม่วาดใหม่ กันโฟกัสหลุด) */
function fleshforgePicker(c, opts={}){
  c.fleshforge = c.fleshforge || {item:'', custom:false};
  const f = c.fleshforge; const locked = !!opts.locked;
  const box = h('div',{class:'card ffbox',style:'margin-top:12px'});
  box.append(h('h3',null, '🧬 ศาสตราชีวะ (Fleshforge)', h('span',{class:'en',text:'ไอเทมมีชีวิตของคุณ'})));
  box.append(h('p',{class:'desc',style:'margin:4px 0 8px',text:'เลือกไอเทมหนึ่งชิ้นที่ร่างของคุณจะกลายเป็นเมื่อใช้ Fleshforge จะเป็นอาวุธ โล่ หมวก หน้ากาก เกราะ เครื่องมือ หรือของสวมใส่ชนิดใดก็ได้ เลือกแล้วผูกกับตัวละครตลอดทั้งเกม เปลี่ยนไม่ได้'}));
  if (locked){ box.append(h('div',{class:'gives'}, tag('🧬 '+(f.item||'ยังไม่ได้เลือก'),'prop'), tag('🔒 ผูกถาวรตลอดเกม','warn'))); return box; }
  const cands = fleshforgeCandidates(c);
  const sel = h('select',null, h('option',{value:'',text:'เลือกไอเทม…'}), cands.map(n=>h('option',{value:n,text:n,selected: !f.custom && f.item===n})), h('option',{value:'__custom',text:'อื่น ๆ (ระบุเอง เช่น หน้ากาก มงกุฎ)',selected: !!f.custom}));
  const custom = h('input',{placeholder:'ชื่อไอเทมที่ร่างของคุณจะกลายเป็น',value: f.custom ? (f.item||'') : '',style:'min-width:240px' + (f.custom ? '' : ';display:none')});
  custom.oninput = ()=>{ f.item = custom.value.trim(); f.custom = true; f.at = f.at || Date.now(); if (opts.onInput) opts.onInput(); };
  sel.onchange = ()=>{ if (sel.value==='__custom'){ f.custom = true; f.item = custom.value.trim(); custom.style.display=''; custom.focus(); } else { f.custom = false; f.item = sel.value; f.at = f.at || Date.now(); custom.style.display='none'; } if (opts.onChange) opts.onChange(); };
  box.append(h('div',{class:'row'}, sel, custom));
  box.append(h('p',{class:'dim',style:'font-size:12px;margin:6px 0 0',text:'เมื่อแปรร่าง ไอเทมมีชีวิตมี HP และ Toughness เท่ากับคุณ ใครแตะโดยไม่ได้รับอนุญาตโดน 1d3 Necrotic เมื่อถึงเทิร์นของคุณ (ดูสกิลเต็มในคัมภีร์)'}));
  return box;
}
function traitNeedsPick(text){ return /เลือก[^.\n]{0,60}?(1|หนึ่ง|๑)\s*(กลุ่ม|ประเภท|อย่าง|ชนิด|ภาษา|สาย|ค่า|แบบ|ทาง|ตัว|เผ่า|สำนัก|วงศา|เป้าหมาย|ธาตุ)/.test(String(text||'')) || /เลือก(ประเภท|กลุ่ม|เป้าหมาย|ธาตุ|ภาษา|สัตว์|อาวุธ)[^.\n]{0,40}(1|หนึ่ง)/.test(String(text||'')); }
function traitPickInput(c, key, placeholder, onChange){ c.traitPicks = c.traitPicks || {}; const inp = h('input',{value:c.traitPicks[key]||'', placeholder: placeholder||'ระบุทางเลือกที่เลือก', oninput:(e)=>{ c.traitPicks[key] = e.target.value; if (onChange) onChange(); }}); return h('div',{class:'traitpick'}, h('span',{class:'tag prop',text:'ทางเลือก'}), inp); }

/* ---- Knowledge Check (คำตัดสิน 9 พ.ย. 2026): 2d6 + ระดับความรู้ + Mod ค่าพลังกำกับ (ตัวที่สูงกว่าในคู่) + บุคลิกภาพถ้าเข้าบริบท ---- */
/* Knowledge Check = 2d6 + ระดับความรู้ (+ บุคลิกภาพที่เกี่ยวตอนทอย) ไม่รวม Mod ค่าพลัง (ผู้ใช้เคาะ 9 พ.ย. 2026 แก้จากคำตัดสินก่อนหน้า) */
function knowledgeBonus(c, d, k){ const lv = (knowledgeLevels(c)[k.id]||0); return { lv, stat: k.stats[0], mod: 0, total: lv }; }
/* สีหัวสกิล/Trait ตามค่าพลังที่การทอยนั้นเกี่ยว (ผู้ใช้เคาะ 9 พ.ย. 2026): หลบ/ปีน = AGI เขียว · ป้องกัน/Saving Throw = VIT ส้ม · ประชิด/Might = STR แดง · ระยะ/สังเกต = PER เหลือง · โน้มน้าว/Sanity = INF ม่วง · เวท/ความรู้ = INT ฟ้า */
const HUE_RULES = [
  ['AGI', /\bAGI\b/g, 3], ['AGI', /Evade|Reflex|หลบ|ปีน|Acrobat|Stealth|Burglary|ซ่อนตัว|คล่อง|กระโดด|\bDash\b|Speed|ความเร็ว|ลอบ|Unbalanced/g, 1],
  ['VIT', /\bVIT\b/g, 3], ['VIT', /Saving Throw|ป้องกัน|ต้านทาน|Resist|Toughness|Fortitude|Parry|Armor|เกราะ|\bHP\b|ฟื้นฟู|Heal|รักษา|Insulation|แข็งแรง|Temporary|ทนทาน|Immun|พิษ|Poison|Bleed/g, 1],
  ['STR', /\bSTR\b/g, 3], ['STR', /Might|Melee|Unarmed|Grab|พละกำลัง|ทุบ|แบก|Guard Break|Impact|ประชิด|Weapon|อาวุธ|Attack Roll|Perfect Strike/g, 1],
  ['PER', /\bPER\b/g, 3], ['PER', /Sight|Range|ระยะไกล|ธนู|ยิง|สังเกต|Initiative|Passive|สายตา|มองเห็น|Perception|\bAim\b|Focus|ค้นหา|สะกดรอย|Marked|Hidden/g, 1],
  ['INF', /\bINF\b/g, 3], ['INF', /Sanity|Persua|โน้มน้าว|ข่มขู่|Intimid|หลอก|ขวัญ|Frighten|Charm|บารมี|Perform|Decept|เจรจา|ต่อรอง|Morale|Fear/g, 1],
  ['INT', /\bINT\b/g, 3], ['INT', /Knowledge|Sorcer|เวท|\bCast\b|\bMP\b|Crafting|Alchemy|Medical|ปัญญา|Mana|มานา|Arcane|Ritual|ความรู้|วิเคราะห์|Spell/g, 1],
];
function rollHue(...texts){ const s = texts.filter(Boolean).join(' '); const score = {}; for (const [st, rx, w] of HUE_RULES){ rx.lastIndex = 0; const n = (s.match(rx)||[]).length; if (n) score[st] = (score[st]||0) + n*w; } let best = null; for (const st of STATS) if (score[st] && (!best || score[st] > score[best])) best = st; return best; }
function hueCls(...texts){ const hue = rollHue(...texts); return hue ? ' hue sc-'+hue : ''; }
