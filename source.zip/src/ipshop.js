/* ===== ความก้าวหน้าด้วย Insight Point ตามบทที่ 13 (คำตัดสิน 29 ส.ค. 2026): IP เป็นสกุลเงินเดียว
 * ค่าพลัง: Mod ติดลบ→0 ขั้นละ 3 · 0→1 3 · 1→2 4 · 2→3 5 · 3→4 6 · 4→5 7 (บุคคลในตำนานลด 2 IP ต่อขั้น ไม่เกิน 3 ขั้น)
 * ความรู้: Lv1/2/3 = 4/6/9 IP ผ่านประตูระดับ (ใช้งานจริง ตำรา ครู) ระดับจากพรสวรรค์/เนื้อเรื่องไม่เสีย IP
 * ทักษะ: ราคาตามรายการ · Novice เรียนเองได้ · Expert ต้องมีครู ตำรา หรือเคยเห็นถูกใช้ · Master ต้องมีปรมาจารย์หรือเนื้อเรื่อง
 * ส่วนลด: ตำราทั่วไป/ผู้ชำนาญการ −1 · ตำราหายาก/ปรมาจารย์ −2 · สาขาละก้อนเดียว ไม่ทบ ใช้ได้ครั้งเดียวต่อช่วงระหว่าง Milestone
 * ใช้ IP ได้เฉพาะตอนจบเซสชั่นหรือช่วง Downtime ===== */
const IP_DISC = [['', 'ไม่มีส่วนลด', 0], ['common', 'ตำราทั่วไป / ผู้ชำนาญการ (−1)', 1], ['rare', 'ตำราหายาก / ปรมาจารย์ (−2)', 2]];
const IpUI = { tab: 'stat', q: '', cat: '', tier: '' };
function openIpShop(c, onChange){
  c.current = c.current || {}; c.ipLog = c.ipLog || []; c.ipDiscUsed = c.ipDiscUsed || {}; c.ipLegendSteps = c.ipLegendSteps || 0;
  const wrap = h('div',{class:'ipshop'});
  const ip = ()=> c.current.ip||0;
  const spend = (title, cost, kind, extra)=>{ c.current.ip = ip() - cost; c.ipLog.push({ts:Date.now(), title, cost, kind, ...(extra||{})}); if (onChange) onChange(); toast(`${title} · ใช้ ${cost} IP`); render(); };
  const discRow = (branch, onPick)=>{ // ส่วนลดครู/ตำรา สาขาละครั้งต่อช่วง Milestone
    const used = !!c.ipDiscUsed[branch];
    const sel = h('select',{class:'small',disabled:used}, IP_DISC.map(([v,l])=>h('option',{value:v,text:l})));
    sel.onchange = ()=>onPick(sel.value);
    return h('span',{class:'disc'}, sel, used ? h('span',{class:'dim',text:' ใช้ส่วนลดสาขานี้ไปแล้วในช่วงนี้'}) : null);
  };
  const costWith = (base, discId)=>{ const d = IP_DISC.find(x=>x[0]===discId); return Math.max(1, base - (d? d[2] : 0)); };
  const render = ()=>{
    clear(wrap);
    const d = compute(c); const kl = knowledgeLevels(c); const owned = new Set(allSkills(c));
    wrap.append(h('div',{class:'row',style:'justify-content:space-between;align-items:baseline'}, h('h3',null, 'ความก้าวหน้า ', h('span',{class:'ipbal',text:`${ip()} IP`})),
      h('button',{class:'small ghost',title:'ผ่าน Milestone แล้ว: รีเซ็ตสิทธิ์ส่วนลดครู/ตำราทุกสาขา',onclick:()=>{ if (!confirm('เริ่มช่วงใหม่หลัง Milestone? สิทธิ์ส่วนลดครู/ตำราทุกสาขาจะใช้ได้อีกครั้ง')) return; c.ipDiscUsed = {}; if (onChange) onChange(); render(); },text:'ผ่าน Milestone แล้ว'})));
    wrap.append(h('p',{class:'desc',style:'margin:4px 0 10px',text:'ใช้ IP ได้ตอนจบเซสชั่นหรือช่วง Downtime · ครูและตำราเปลี่ยนได้แค่สิทธิ์ (ประตู) และราคา (ส่วนลด) · GM เป็นผู้ยืนยันประตู'}));
    const tabs = h('div',{class:'iptabs'}, [['stat','ค่าพลัง'],['know','ความรู้'],['skill','ทักษะและเวทมนตร์'],['log','ประวัติ']].map(([k,l])=>h('button',{class:'small'+(IpUI.tab===k?' primary':''),onclick:()=>{ IpUI.tab=k; render(); },text:l})));
    wrap.append(tabs);
    const body = h('div',{class:'ipbody'}); wrap.append(body);
    if (IpUI.tab==='stat'){
      body.append(h('p',{class:'dim',style:'font-size:12px',text:`ซื้อ Mod ขึ้นหนึ่งขั้น = ค่าดิบ +2 · บุคคลในตำนานลด 2 IP ต่อขั้น (ใช้แล้ว ${c.ipLegendSteps}/3 ขั้น)`}));
      const tbl = h('table',{class:'t'}, h('thead',null, h('tr',null, h('th',{text:'ค่าพลัง'}), h('th',{text:'ดิบ'}), h('th',{text:'Mod'}), h('th',{text:'ถัดไป'}), h('th',{text:'ราคา'}), h('th'))));
      for (const s of STATS){ const cost = ipCostStat(d.mod[s]); const legend = h('input',{type:'checkbox',disabled: c.ipLegendSteps>=3}); const row = h('tr',{class:'sc-'+s});
        row.append(h('td',null, h('b',{class:'n',text:s}), ' ', h('span',{class:'dim',text:STAT_TH[s]})), h('td',{class:'num',text:d.raw[s]}), h('td',{class:'num ov',text:signed(d.mod[s])}), h('td',{class:'num',text: cost==null? 'สูงสุดแล้ว' : signed(d.mod[s]+1)}), h('td',{class:'num',text: cost==null? '-' : cost+' IP'}),
          h('td',null, cost==null? null : h('div',{class:'row',style:'gap:6px;align-items:center'}, h('label',{class:'dim',style:'font-size:11px'}, legend, ' บุคคลในตำนาน −2'), h('button',{class:'small primary',onclick:()=>{ const useL = legend.checked && c.ipLegendSteps<3; const fin = Math.max(1, cost - (useL?2:0)); if (ip() < fin){ toast(`IP ไม่พอ (ต้องการ ${fin})`); return; } c.ipStats = c.ipStats||{}; c.ipStats[s] = (c.ipStats[s]||0)+2; if (useL) c.ipLegendSteps++; spend(`${s} Mod ${signed(d.mod[s])} → ${signed(d.mod[s]+1)}`, fin, 'stat', useL? {disc:'legend'} : null); },text:'ซื้อ'}))));
        tbl.append(row); }
      body.append(h('div',{class:'tablewrap'}, tbl));
    } else if (IpUI.tab==='know'){
      body.append(h('p',{class:'dim',style:'font-size:12px',text:'ราคาระดับ 1 / 2 / 3 = 4 / 6 / 9 IP · ต้องผ่านประตูระดับ (เคยใช้งานจริง มีตำรา หรือมีครู) ให้ GM ยืนยัน · ซื้อแล้วเลือก Proficiency ของระดับใหม่'}));
      for (const k of DATA.knowledge){ const lv = kl[k.id]; const cost = ipCostKnowledge(lv); const L = k.levels[String(lv+1)]||{};
        const gate = h('input',{type:'checkbox'}); let disc = '';
        const row = h('div',{class:'iprow'}, h('div',{class:'ipmain'}, h('b',{text:k.nameEn}), h('span',{class:'dim',text:` ${k.nameTh} · ${k.stats.join('/')} · Lv${lv}`}), cost==null? h('div',{class:'dim',style:'font-size:12px',text:'ระดับสูงสุดแล้ว'}) : h('div',{class:'desc',style:'font-size:12px'}, `Lv${lv+1}: `, T(L.text||''))),
          cost==null? null : h('div',{class:'ipact'}, h('label',{class:'dim',style:'font-size:11px'}, gate, ' GM ยืนยันผ่านประตูระดับ'), discRow(k.id, v=>{ disc=v; }), h('button',{class:'small primary',onclick:()=>{ if (!gate.checked){ toast('ต้องให้ GM ยืนยันว่าผ่านประตูระดับก่อน'); return; } const fin = costWith(cost, disc); if (ip() < fin){ toast(`IP ไม่พอ (ต้องการ ${fin})`); return; }
            const groups = profGroups(L).filter(g=>!Object.values(c.kslots||{}).some(sl=>sl&&sl.prof===g.prof.name));
            const finish = (prof, faith)=>{ c.kslots = c.kslots||{}; c.kslots['ip'+uid()] = {id:k.id, prof: prof? prof.name : null, faith: faith ? faith.name : null}; if (disc) c.ipDiscUsed[k.id] = true; spend(`${k.nameEn} Lv${lv} → Lv${lv+1}${prof? ' ('+prof.name+(faith? ' · '+faithShort(faith.name):'')+')':''}`, fin, 'knowledge', disc? {disc} : null); };
            if (!groups.length){ finish(null); return; }
            const pickFaith = (g)=>{ const have = charFaith(c); clear(body); body.append(...[h('h4',{text:`${g.prof.name}: เลือกความเชื่อ 1 อย่าง`}), have ? h('div',{class:'dim',style:'font-size:12.5px',text:`ตัวละครนี้นับถือ "${have}" อยู่แล้ว เลือกได้เฉพาะความเชื่อเดียวกัน`}) : null, h('div',{class:'ipgrid'}, g.subs.map(f=>{ const blocked = !!(have && faithKey(f.name) && have!==faithKey(f.name)); return h('div',{class:'ipcard knowledge'+(blocked?' disabled':'')}, h('div',{class:'ribbon',text:'ความเชื่อ'}), h('h4',{text:faithShort(f.name)}), h('div',{class:'body cardtext'}, T(f.text||'')), h('button',{class:'primary small',disabled:blocked,onclick:()=>finish(g.prof, f),text:'เลือก'})); })), h('button',{class:'small ghost',style:'margin-top:8px',onclick:render,text:'← ยกเลิก'})].filter(Boolean)); };
            clear(body); body.append(h('h4',{text:`${k.nameEn} Lv${lv+1}: เลือก Proficiency 1 อย่าง`}), h('div',{class:'ipgrid'}, groups.map(g=>h('div',{class:'ipcard knowledge'}, h('div',{class:'ribbon',text:'Proficiency'}), h('h4',{text:g.prof.name}), g.subs.length ? h('div',{class:'dim',style:'font-size:12px',text:`เลือกความเชื่อ 1 จาก ${g.subs.length} ต่อ`}) : null, h('div',{class:'body cardtext'}, T(g.prof.text||'')), h('button',{class:'primary small',onclick:()=>{ if (g.subs.length) pickFaith(g); else finish(g.prof, null); },text:'เลือก'})))), h('button',{class:'small ghost',style:'margin-top:8px',onclick:render,text:'← ยกเลิก'}));
          },text:`ซื้อ ${cost} IP`})));
        body.append(row); }
    } else if (IpUI.tab==='skill'){
      const cats = [...new Set(DATA.skills.filter(s=>s.ipCost!=null).map(s=>s.category))];
      const subs = [...new Set(DATA.skills.filter(s=>s.ipCost!=null && (!IpUI.cat || s.category===IpUI.cat)).map(s=>s.subcategory))].sort();
      const f = h('div',{class:'row',style:'margin-bottom:8px'}, h('input',{placeholder:'ค้นชื่อ/ข้อความ',value:IpUI.q,style:'width:180px',oninput:(e)=>{ IpUI.q=e.target.value; renderList(); }}),
        h('select',{onchange:(e)=>{ IpUI.cat=e.target.value; IpUI.sub=''; render(); }}, h('option',{value:'',text:'ทุกหมวด'}), cats.map(x=>h('option',{value:x,selected:IpUI.cat===x,text:x}))),
        h('select',{onchange:(e)=>{ IpUI.sub=e.target.value; renderList(); }}, h('option',{value:'',text:'ทุกสำนัก/สาย'}), subs.map(x=>h('option',{value:x,selected:IpUI.sub===x,text:x}))),
        h('select',{onchange:(e)=>{ IpUI.tier=e.target.value; renderList(); }}, h('option',{value:'',text:'ทุกระดับ'}), ['Novice','Expert','Master'].map(x=>h('option',{value:x,selected:IpUI.tier===x,text:x}))),
        h('label',{class:'dim',style:'font-size:12px'}, h('input',{type:'checkbox',checked:!!IpUI.afford,onchange:(e)=>{ IpUI.afford=e.target.checked; renderList(); }}), ' เฉพาะที่ IP พอ'));
      body.append(f, h('p',{class:'dim',style:'font-size:12px',text:'ประตู: Novice เรียนเองได้ · Expert ต้องมีครู ตำรา หรือเคยเห็นถูกใช้ · Master ต้องมีปรมาจารย์หรือเนื้อเรื่อง (ให้ GM ยืนยัน) · ส่วนลดครู/ตำราใช้ได้สายละครั้งต่อช่วง Milestone'}));
      const listEl = h('div',{class:'iplist'}); body.append(listEl);
      const renderList = ()=>{ clear(listEl); const q = (IpUI.q||'').toLowerCase();
        const items = DATA.skills.filter(sk => sk.ipCost!=null && !owned.has(sk.nameEn) && (!IpUI.cat || sk.category===IpUI.cat) && (!IpUI.sub || sk.subcategory===IpUI.sub) && (!IpUI.tier || sk.tier===IpUI.tier) && (!q || (sk.nameEn+' '+(sk.nameTh||'')+' '+(sk.effect||'')).toLowerCase().includes(q)) && (!IpUI.afford || sk.ipCost <= ip()));
        if (!items.length) listEl.append(h('div',{class:'dim',text:'ไม่มีรายการตรงตัวกรอง'}));
        for (const sk of items.slice(0,80)){
          const gateNeeded = sk.tier && sk.tier!=='Novice'; const gate = h('input',{type:'checkbox'}); let disc = '';
          listEl.append(h('div',{class:'iprow'}, h('div',{class:'ipmain'}, h('div',{class:'row',style:'gap:6px;align-items:center'}, h('b',{text:sk.nameEn}), h('span',{class:'dim',text:sk.nameTh||''}), tag(sk.subcategory, sk.category==='Sorcery'?'prop':''), sk.tier? tag(sk.tier, sk.tier==='Master'?'neg':sk.tier==='Expert'?'warn':'ok'):null, sk.cost? tag('Cost '+sk.cost,'stat'):null, tag(sk.ipCost+' IP')),
              h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect||'')), sk.condition? h('div',{class:'lim',style:'font-size:12px'}, 'Limitation: ', T(sk.condition)) : null),
            h('div',{class:'ipact'}, gateNeeded? h('label',{class:'dim',style:'font-size:11px'}, gate, sk.tier==='Master'? ' GM ยืนยัน: มีปรมาจารย์/เนื้อเรื่อง' : ' GM ยืนยัน: มีครู/ตำรา/เคยเห็น') : h('span',{class:'dim',style:'font-size:11px',text:'เรียนเองได้'}), discRow(sk.subcategory, v=>{ disc=v; }),
              h('button',{class:'small primary',onclick:()=>{ if (gateNeeded && !gate.checked){ toast('ต้องให้ GM ยืนยันประตูของทักษะระดับนี้ก่อน'); return; } const fin = costWith(sk.ipCost, disc); if (ip() < fin){ toast(`IP ไม่พอ (ต้องการ ${fin})`); return; } c.grants = c.grants||[]; c.grants.push(sk.nameEn); if (disc) c.ipDiscUsed[sk.subcategory] = true; spend(`ทักษะ ${sk.nameEn}`, fin, 'skill', disc? {disc} : null); },text:'ซื้อ'}))));
        }
        if (items.length > 80) listEl.append(h('div',{class:'dim',text:`แสดง 80 จาก ${items.length} รายการ กรองให้แคบลง`}));
      };
      renderList();
    } else {
      const log = c.ipLog.slice().reverse();
      body.append(log.length ? h('table',{class:'t'}, log.map(l=>h('tr',null, h('td',{class:'dim',text:new Date(l.ts).toLocaleDateString('th-TH')}), h('td',{text:l.title}), h('td',{class:'num',text:l.cost+' IP'}), h('td',{class:'dim',text:l.disc? (l.disc==='legend'?'บุคคลในตำนาน':IP_DISC.find(x=>x[0]===l.disc)[1]) : ''})))) : h('div',{class:'dim',text:'ยังไม่เคยใช้ IP'}));
    }
  };
  render();
  modal(wrap);
}
