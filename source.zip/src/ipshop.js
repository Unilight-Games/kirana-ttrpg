/* ===== Insight Point shop: การ์ดตัวเลือกแบบ Roguelike (สุ่มมือ 5 ใบ สับใหม่ได้ หรือดูทั้งหมด) ===== */
function ipOptions(c){
  const d = compute(c); const kl = knowledgeLevels(c); const owned = new Set(allSkills(c));
  const out = [];
  for (const s of STATS){ const cost = ipCostStat(d.mod[s]); if (cost==null) continue;
    out.push({kind:'stat', id:'stat:'+s, stat:s, title:`${s} Mod ${signed(d.mod[s])} → ${signed(d.mod[s]+1)}`, sub:STAT_TH[s], cost, desc:`เพิ่มค่าดิบ ${s} +2 (${d.raw[s]} → ${d.raw[s]+2}) ทำให้ Mod ขึ้นหนึ่งขั้น กระทบทุกอย่างที่ใช้ ${s}`,
      apply:(c)=>{ c.ipStats = c.ipStats||{}; c.ipStats[s] = (c.ipStats[s]||0)+2; }}); }
  for (const k of DATA.knowledge){ const lv = kl[k.id]; const cost = ipCostKnowledge(lv); if (cost==null) continue; const L = k.levels[String(lv+1)] || {};
    out.push({kind:'knowledge', id:'kn:'+k.id, know:k, level:lv+1, title:`${k.nameEn} Lv${lv} → Lv${lv+1}`, sub:`${k.nameTh} · ${k.stats.join('/')}`, cost, desc:(L.text||'') + ((L.proficiencies||[]).length? ' · เลือก Proficiency 1 อย่าง' : ''),
      apply:(c)=>{ c.kslots = c.kslots||{}; c.kslots['ip'+uid()] = {id:k.id, prof:null}; }, needProf: (L.proficiencies||[]).filter(p=>!Object.values(c.kslots||{}).some(sl=>sl&&sl.prof===p.name)) }); }
  const mySubs = new Set([...owned].map(n=>SKILL_BY_NAME[n]).filter(Boolean).map(sk=>sk.subcategory));
  for (const sk of DATA.skills){ if (sk.ipCost==null || owned.has(sk.nameEn)) continue;
    const w = (mySubs.has(sk.subcategory)?4:1) * (sk.tier==='Novice'?3 : sk.tier==='Adept'?1.5 : 1);
    out.push({kind:'skill', id:'sk:'+sk.nameEn, skill:sk, title:sk.nameEn, sub:`${sk.nameTh||''} · ${sk.subcategory}${sk.tier?' · '+sk.tier:''}`, cost:sk.ipCost, desc:sk.effect||'', weight:w,
      apply:(c)=>{ c.grants = c.grants||[]; c.grants.push(sk.nameEn); }}); }
  return out;
}
function pickWeighted(arr, n){ const pool = arr.slice(); const out = []; while (pool.length && out.length < n){ const tot = pool.reduce((a,x)=>a+(x.weight||1),0); let r = Math.random()*tot; let i=0; for (; i<pool.length; i++){ r -= (pool[i].weight||1); if (r<=0) break; } out.push(pool.splice(Math.min(i,pool.length-1),1)[0]); } return out; }
function drawHand(opts, c){
  const kl = knowledgeLevels(c);
  const stats = opts.filter(o=>o.kind==='stat'); const kn = opts.filter(o=>o.kind==='knowledge').map(o=>({...o, weight: kl[o.know.id]>0 ? 3 : 1})); const sk = opts.filter(o=>o.kind==='skill');
  return [...pickWeighted(stats,1), ...pickWeighted(kn,1), ...pickWeighted(sk,3)];
}
function openIpShop(c, onChange){
  c.current = c.current || {}; // หมายเหตุ: renderSheet สร้าง c.current ใหม่ทุกครั้ง จึงอ้าง c.current สด ๆ เสมอ
  let showAll = false; let hand = null;
  const wrap = h('div',{class:'ipshop'});
  const render = ()=>{
    clear(wrap);
    const opts = ipOptions(c); if (!hand) hand = drawHand(opts, c);
    const ip = c.current.ip||0;
    wrap.append(h('div',{class:'row',style:'justify-content:space-between;align-items:baseline'}, h('h3',null, 'ใช้ Insight Point ', h('span',{class:'ipbal',text:`${ip} IP`})), h('div',{class:'row'}, h('button',{class:'small',onclick:()=>{ hand = drawHand(opts, c); showAll=false; render(); },text:'สับการ์ดใหม่'}), h('button',{class:'small ghost',onclick:()=>{ showAll=!showAll; render(); },text: showAll? 'กลับไปดูการ์ด' : 'ดูตัวเลือกทั้งหมด'}))));
    wrap.append(h('p',{class:'desc',style:'margin:4px 0 10px',text:'เลือกการ์ด 1 ใบต่อครั้ง (ทอยเสี่ยงโชคได้ด้วยการสับใหม่ ไม่เสีย IP) · ค่าใช้จ่ายตามตารางไฟล์แกน · GM ตัดสินได้ว่าเงื่อนไขของสกิลผ่านหรือไม่'}));
    const cardEl = (o)=>{
      const can = ip >= o.cost;
      const el = h('div',{class:`ipcard ${o.kind}${can?'':' locked'}`},
        h('div',{class:'ribbon',text: o.kind==='stat'?'ค่าพลัง' : o.kind==='knowledge'?'ความรู้' : (o.skill.category==='Sorcery'?'เวทมนตร์':'ทักษะ')}),
        h('div',{class:'cost',text:`${o.cost} IP`}),
        h('h4',{text:o.title}), h('div',{class:'sub',text:o.sub||''}),
        h('div',{class:'body cardtext'}, T(o.desc||'')),
        o.kind==='skill' && (o.skill.cost||o.skill.condition) ? h('div',{class:'sub'}, o.skill.cost? `Cost ${o.skill.cost}` : '', o.skill.condition? ` · ${o.skill.condition}` : '') : null,
        h('button',{class:'primary small',disabled:!can,onclick:()=>choose(o),text: can? 'เลือกการ์ดนี้' : `ขาดอีก ${o.cost-ip} IP`}));
      return el; };
    if (!showAll){ wrap.append(h('div',{class:'hand'}, hand.map(cardEl))); }
    else {
      for (const [kind,label] of [['stat','ค่าพลัง (Mod +1)'],['knowledge','ความรู้ (Level Up)'],['skill','ทักษะและเวทมนตร์']]){
        const list = opts.filter(o=>o.kind===kind); wrap.append(h('h4',{style:'margin:12px 0 6px',text:`${label} · ${list.length}`}));
        wrap.append(h('div',{class:'hand all'}, list.sort((a,b)=>a.cost-b.cost).map(cardEl)));
      }
    }
    const log = c.ipLog||[]; if (log.length) wrap.append(h('details',{style:'margin-top:10px'}, h('summary',{text:`ประวัติการใช้ IP (${log.length})`}), log.slice().reverse().map(l=>h('div',{class:'dim',style:'font-size:12px',text:`${new Date(l.ts).toLocaleDateString('th-TH')} · ${l.title} · ${l.cost} IP`}))));
  };
  const choose = (o)=>{
    const finish = (extraNote)=>{ o.apply(c); c.current.ip = (c.current.ip||0) - o.cost; c.ipLog = c.ipLog||[]; c.ipLog.push({ts:Date.now(), title:o.title + (extraNote? ' ('+extraNote+')':''), cost:o.cost, kind:o.kind}); if (onChange) onChange(); toast(`ได้ ${o.title}${extraNote? ' · '+extraNote:''}`); hand=null; render(); };
    if (o.kind==='knowledge' && o.needProf && o.needProf.length){
      // เลือก Proficiency ของระดับใหม่ก่อน
      clear(wrap); wrap.append(h('h3',{text:`${o.know.nameEn} Lv${o.level}: เลือก Proficiency 1 อย่าง`}));
      wrap.append(h('div',{class:'hand'}, o.needProf.map(p=>h('div',{class:'ipcard knowledge'}, h('div',{class:'ribbon',text:'Proficiency'}), h('h4',{text:p.name}), h('div',{class:'body cardtext'}, T(p.text||'')), h('button',{class:'primary small',onclick:()=>{ const key='ip'+uid(); c.kslots=c.kslots||{}; c.kslots[key]={id:o.know.id, prof:p.name}; o.apply=()=>{}; finish(p.name); },text:'เลือก'})))));
      wrap.append(h('button',{class:'small ghost',style:'margin-top:8px',onclick:render,text:'← กลับ'}));
      return;
    }
    finish();
  };
  render();
  modal(wrap);
}
