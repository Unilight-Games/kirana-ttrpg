/* ===== v1.27 (ร่าง · Non สั่ง 16 พ.ย. 2026): แก้ข้อมูลไอเทมและทักษะได้ตั้งแต่ในหน้าคลัง เฉพาะหลังบ้าน =====
 * "ทำให้ผมสามารถแก้ข้อมูลไอเทม และทักษะได้ตั้งแต่ในหน้าคลังเลย"
 * ปุ่ม ✎ บนการ์ดในหน้า #items และ #skills (และในหน้าต่างรายละเอียดไอเทม) · ปุ่มเพิ่มรายการใหม่บนแถบหลังบ้านของแต่ละหน้า · การ์ดสรุปในหน้า #dev
 * ผู้ที่แก้ได้ใช้เกณฑ์เดียวกับหลังบ้านตำนาน (LoreEdit.canEdit): บัญชีใน devUids บนเว็บที่ต่อ Firebase หรือเจ้าของเครื่องเมื่อเปิดไฟล์ในเครื่อง
 * ที่เก็บ: Firestore codex/items และ codex/skills = {v, at, by, byName, entries:[สตริง JSON {key, op:'edit'|'add', data}], log}
 *   เก็บเป็นอาร์เรย์ของสตริงเพราะชื่อไอเทมมีวงเล็บและทับ (/) ซึ่งไม่เหมาะเป็นชื่อฟิลด์ · ต้องเผยแพร่กฎ codex ฉบับที่รับ items กับ skills ก่อน (ร่างอยู่ใน firestore.rules)
 *   ระหว่างที่กฎยังไม่ขึ้น บันทึกแล้วเก็บเป็นร่างในเครื่องนั้น ส่งขึ้นเว็บภายหลังได้จากหน้า #dev
 * การใช้ผล: แก้ DATA.items กับ DATA.skills ในที่ วัตถุของรายการต้นฉบับคงตัวเดิม (ตัวอ้างอิงอื่นยังชี้ถูก) แล้วล้างแคชคลังไอเทมและสร้างดัชนีทักษะใหม่
 *   ชื่ออังกฤษของทักษะต้นฉบับแก้ไม่ได้ เพราะชีทตัวละครอ้างทักษะด้วยชื่อนี้ · ของที่อยู่ในกระเป๋าตัวละครแล้วเป็นสำเนา ไม่เปลี่ยนตามคลัง
 * ข้อมูลที่อ่านจากฐานข้อมูลผ่านตัวกรองชนิดและความยาวทุกช่อง แสดงผลเป็นข้อความล้วน */
function ceStr(x, max){ return typeof x === 'string' ? x.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max) : (typeof x === 'number' && Number.isFinite(x) ? String(x).slice(0, max) : ''); }
function ceSkillKey(s){ return `${s.category}|${s.subcategory}|${s.nameEn}`; }
const CE = {
  items: { label:'ไอเทม', doc:'codex/items', local:'kirana.codex.items.v1', objs: (DATA.items||[]).slice(), base: JSON.parse(JSON.stringify(DATA.items||[])), keys: [] },
  skills: { label:'ทักษะ', doc:'codex/skills', local:'kirana.codex.skills.v1', objs: (DATA.skills||[]).slice(), base: JSON.parse(JSON.stringify(DATA.skills||[])), keys: [] },
};
/* รหัสของรายการต้นฉบับ: ไอเทมใช้ชื่อ (ไม่ซ้ำ) · ทักษะใช้ หมวด|ประเภท|ชื่ออังกฤษ (ชื่ออังกฤษซ้ำได้ข้ามประเภท เช่น Wild Sense) */
for (const kind of ['items','skills']){ const K = CE[kind]; const seen = {};
  K.base.forEach((x, i)=>{ let k = kind === 'items' ? x.name : ceSkillKey(x); if (seen[k]){ seen[k]++; k += '#' + seen[k]; } else seen[k] = 1; K.keys.push(k); Object.defineProperty(K.objs[i], '__ceKey', {value: k, configurable: true}); }); }
const CE_ITEM_CATS = [...new Set(CE.items.base.map(i=>i.cat))];
const CE_SKILL_CATS = [...new Set(CE.skills.base.map(s=>s.category))];
const CE_TIERS_IT = [['', 'ไม่ระบุ'], [1, 'Tier 1'], [2, 'Tier 2'], [3, 'Tier 3'], [4, 'Tier 4'], ['S', 'Tier พิเศษ']];
function ceItemClean(d, base){
  if (!d || typeof d !== 'object') return null;
  const o = { name: ceStr(d.name, 160), cat: CE_ITEM_CATS.includes(d.cat) ? d.cat : (base ? base.cat : ''), sub: ceStr(d.sub, 160), desc: ceStr(d.desc, 4000), effect: ceStr(d.effect, 4000), price: ceStr(d.price, 80), slot: ceStr(d.slot, 80), src: base ? (base.src || 'Item All') : 'หลังบ้าน' };
  if (!o.name || !o.cat) return null;
  const w = +d.weight; o.weight = d.weight !== '' && d.weight != null && Number.isFinite(w) && w >= 0 ? Math.min(9999, Math.round(w * 100) / 100) : (base ? base.weight : 0);
  if ([1,2,3,4].includes(+d.tier) && d.tier !== '' && d.tier != null) o.tier = +d.tier; else if (d.tier === 'S') o.tier = 'S';
  return o; }
function ceSkillClean(d, base){
  if (!d || typeof d !== 'object') return null;
  const o = { category: CE_SKILL_CATS.includes(d.category) ? d.category : (base ? base.category : ''), subcategory: ceStr(d.subcategory, 120) || (base ? base.subcategory : ''),
    nameEn: base ? base.nameEn : ceStr(d.nameEn, 120), nameTh: ceStr(d.nameTh, 120) };
  if (!o.category || !o.subcategory || !o.nameEn) return null;
  for (const [k, max] of [['branch',200],['type',200],['cost',200],['components',40],['condition',1500],['dc',80],['onFail',1500],['flavor',3000],['effect',8000]]){ const v = ceStr(d[k], max); if (v) o[k] = v; }
  if (['Novice','Expert','Master'].includes(d.tier)) o.tier = d.tier;
  const ip = Math.round(+d.ipCost); if (d.ipCost !== '' && d.ipCost != null && Number.isFinite(ip) && ip >= 0 && ip <= 99){ o.ipCost = ip; o.ip = ip + ' IP'; }
  o.extra = (Array.isArray(d.extra) ? d.extra : []).map(x=>ceStr(x, 3000)).filter(Boolean).slice(0, 20);
  const tags = base && Array.isArray(base.tags) ? base.tags.slice() : []; if (/Cast/i.test(o.type||'') && !tags.includes('Cast')) tags.push('Cast'); if (o.subcategory === 'Stance' && !tags.includes('Stance')) tags.push('Stance'); o.tags = tags;
  return o; }
function ceClean(kind, d, base){ return kind === 'items' ? ceItemClean(d, base) : ceSkillClean(d, base); }
function ceSanitize(kind, d){
  if (!d || typeof d !== 'object') return null; const K = CE[kind];
  const out = { v:1, at: +d.at || 0, by: ceStr(d.by, 128), byName: ceStr(d.byName, 80), entries: [], log: [] }; const seen = new Set();
  for (const raw of (Array.isArray(d.entries) ? d.entries : []).slice(0, 2000)){
    let e = raw; if (typeof e === 'string'){ try { e = JSON.parse(e); } catch(err){ continue; } }
    if (!e || typeof e !== 'object' || typeof e.key !== 'string' || seen.has(e.key)) continue;
    if (e.op === 'edit'){ const i = K.keys.indexOf(e.key); const data = ceClean(kind, e.data, i >= 0 ? K.base[i] : null); if (!data) continue; out.entries.push({key: e.key, op:'edit', data, orphan: i < 0 || undefined}); seen.add(e.key); }
    else if (e.op === 'add' && /^new:[a-z0-9]{4,24}$/.test(e.key)){ const data = ceClean(kind, e.data, null); if (data){ out.entries.push({key: e.key, op:'add', data}); seen.add(e.key); } } }
  out.log = (Array.isArray(d.log) ? d.log : []).slice(0, 40).map(x=>x && typeof x==='object' ? {at: +x.at || 0, by: ceStr(x.by, 80), what: ceStr(x.what, 200)} : null).filter(Boolean);
  return out; }
function ceWire(d){ return { v:1, at: d.at, by: d.by, byName: d.byName, entries: d.entries.map(e=>JSON.stringify({key: e.key, op: e.op, data: e.data})), log: d.log }; }

const CatalogEdit = {
  remote: {items:null, skills:null}, localD: {items:null, skills:null}, status: {items:'idle', skills:'idle'}, error: {items:'', skills:''},
  canEdit(){ return LoreEdit.canEdit(); },
  ref(kind){ return Store.backend === 'firebase' && Store.db ? Store.db.doc(CE[kind].doc) : null; },
  readLocal(kind){ try { return ceSanitize(kind, JSON.parse(localStorage.getItem(CE[kind].local) || 'null')); } catch(e){ return null; } },
  writeLocal(kind, d){ try { if (d) localStorage.setItem(CE[kind].local, JSON.stringify(ceWire(d))); else localStorage.removeItem(CE[kind].local); return true; } catch(e){ return false; } },
  async boot(){ let changed = false;
    for (const kind of ['items','skills']){ const ref = this.ref(kind);
      if (ref){ try { const s = await ref.get(); this.remote[kind] = s.exists ? ceSanitize(kind, s.data()) : null; this.status[kind] = 'web'; }
        catch(e){ this.status[kind] = 'noread'; this.error[kind] = (e && e.code) || String(e); console.warn('codex ' + kind, e); } }
      else this.status[kind] = 'local';
      this.localD[kind] = this.canEdit() ? this.readLocal(kind) : null;
      if (this.effective(kind)){ this.apply(kind); changed = true; } }
    return changed; },
  effective(kind){ return (this.canEdit() && this.localD[kind]) || this.remote[kind] || null; },
  /* คืนค่าต้นฉบับให้ทุกรายการ (วัตถุตัวเดิม) แล้วทับด้วยฉบับแก้และต่อท้ายรายการที่เพิ่ม */
  apply(kind){ const K = CE[kind]; const arr = kind === 'items' ? DATA.items : DATA.skills; const d = this.effective(kind);
    const byKey = {}; for (const e of (d ? d.entries : [])) byKey[e.key] = e;
    K.objs.forEach((o, i)=>{ for (const k of Object.keys(o)) delete o[k]; const e = byKey[K.keys[i]]; Object.assign(o, JSON.parse(JSON.stringify(e && e.op === 'edit' ? e.data : K.base[i]))); });
    const added = (d ? d.entries : []).filter(e=>e.op === 'add').map(e=>{ const o = JSON.parse(JSON.stringify(e.data)); Object.defineProperty(o, '__ceKey', {value: e.key, configurable: true}); return o; });
    arr.length = 0; arr.push(...K.objs, ...added);
    if (kind === 'items') itemCatalogCache = null;
    else { for (const k of Object.keys(SKILL_BY_NAME)) delete SKILL_BY_NAME[k]; for (const s of DATA.skills) SKILL_BY_NAME[s.nameEn] = s;
      for (const [o, n] of Object.entries(SKILL_ALIAS)) if (SKILL_BY_NAME[n] && !SKILL_BY_NAME[o]) SKILL_BY_NAME[o] = SKILL_BY_NAME[n];
      for (const s of DATA.skills) SKILL_LC[s.nameEn.toLowerCase()] = s.nameEn; } },
  entry(kind, key){ const d = this.effective(kind); return d ? d.entries.find(e=>e.key === key) || null : null; },
  edited(kind, key){ return !!this.entry(kind, key); },
  added(kind, key){ return /^new:/.test(key || ''); },
  async save(kind, what, mutate){
    if (!this.canEdit()) return {where:'denied'};
    const ref = this.ref(kind);
    if (ref && !this.localD[kind]){ try { const s = await ref.get(); this.remote[kind] = s.exists ? ceSanitize(kind, s.data()) : null; } catch(e){} }
    const next = JSON.parse(JSON.stringify(this.localD[kind] || this.remote[kind] || {v:1, entries:[], log:[]}));
    mutate(next);
    next.at = Date.now(); next.by = Store.me || ''; next.byName = Store.displayName || (Store.backend ? '' : 'เครื่องนี้');
    next.log = [{at: next.at, by: next.byName || next.by || 'ผู้พัฒนา', what}, ...(next.log||[])].slice(0, 40);
    const clean = ceSanitize(kind, ceWire(next)); const wire = ceWire(clean); const bytes = new Blob([JSON.stringify(wire)]).size;
    if (bytes > 1000000) return {where:'toolarge', bytes};
    if (ref){ try { await ref.set(wire); this.remote[kind] = clean; this.localD[kind] = null; this.writeLocal(kind, null); this.status[kind] = 'web'; this.error[kind] = ''; this.apply(kind); return {where:'web'}; }
      catch(e){ this.error[kind] = (e && e.code) || String(e); this.localD[kind] = clean; this.writeLocal(kind, clean); this.status[kind] = 'draft'; this.apply(kind); return {where:'draft', code: this.error[kind]}; } }
    this.localD[kind] = clean; this.writeLocal(kind, clean); this.apply(kind); return {where:'local'}; },
  async pushDraft(kind){ const ref = this.ref(kind); if (!ref || !this.localD[kind]) return {where:'none'};
    try { await ref.set(ceWire(this.localD[kind])); this.remote[kind] = this.localD[kind]; this.localD[kind] = null; this.writeLocal(kind, null); this.status[kind] = 'web'; this.error[kind] = ''; this.apply(kind); return {where:'web'}; }
    catch(e){ this.error[kind] = (e && e.code) || String(e); return {where:'draft', code: this.error[kind]}; } },
  dropDraft(kind){ this.localD[kind] = null; this.writeLocal(kind, null); this.apply(kind); },
};
function ceSaveToast(kind, r){ const L = CE[kind].label;
  toast(r.where === 'web' ? `บันทึก${L}ขึ้นเว็บแล้ว ทุกคนเห็นข้อมูลใหม่` :
    r.where === 'draft' ? `เขียนขึ้นเว็บไม่ได้ (${r.code}) เก็บเป็นร่างในเครื่องนี้แล้ว ต้องเผยแพร่กฎ codex ฉบับที่รับ${L}ก่อน` :
    r.where === 'toolarge' ? `ข้อมูล${L}ที่แก้รวมกัน ${Math.round(r.bytes/1024)} KB เกินเพดานเอกสารละ 1 MB ยังไม่ได้บันทึก` :
    r.where === 'denied' ? `บัญชีนี้แก้${L}ไม่ได้` : `บันทึก${L}ในเครื่องนี้แล้ว (ไฟล์ในเครื่องไม่มีฐานข้อมูล)`); }
function ceKeyOf(x){ return x && x.__ceKey || ''; }
function ceRerender(){ const hsh = location.hash; if (/^#(items|skills|dev)/.test(hsh)) route(); }

/* ---- ปุ่มและป้ายบนหน้าคลัง (เห็นเฉพาะผู้พัฒนา) ---- */
function ceMark(kind, x){ if (!CatalogEdit.canEdit()) return null; const k = ceKeyOf(x); if (!k) return null;
  return CatalogEdit.added(kind, k) ? tag('เพิ่มจากหลังบ้าน','ok cedit-tag') : CatalogEdit.edited(kind, k) ? tag('แก้จากหลังบ้าน','warn cedit-tag') : null; }
function ceEditBtn(kind, x){ if (!CatalogEdit.canEdit() || !ceKeyOf(x)) return null;
  return h('button',{class:'small ghost cedit-btn',title:`แก้${CE[kind].label}นี้ (หลังบ้าน)`,'aria-label':`แก้${CE[kind].label}นี้`,onclick:(e)=>{ e.stopPropagation(); kind === 'items' ? ceItemEditor(x) : ceSkillEditor(x); },onkeydown:(e)=>e.stopPropagation(),text:'✎'}); }
function ceDevBar(kind, opts){ if (!CatalogEdit.canEdit()) return null; opts = opts || {}; const d = CatalogEdit.effective(kind); const n = d ? d.entries.length : 0; const L = CE[kind].label;
  const st = CatalogEdit.ref(kind) ? (CatalogEdit.localD[kind] ? `มีร่างในเครื่องนี้ที่ยังไม่ขึ้นเว็บ (${CatalogEdit.error[kind] || 'รอกฎ codex'})` : CatalogEdit.status[kind] === 'noread' ? `อ่านข้อมูลแก้จากเว็บไม่ได้ (${CatalogEdit.error[kind]})` : 'บันทึกแล้วขึ้นเว็บทันที') : 'เปิดจากไฟล์ในเครื่อง บันทึกในเบราว์เซอร์นี้';
  return h('div',{class:'lore-devbar cedit-bar',dataset:{kind}}, h('span',{class:'lore-devtag',text:'หลังบ้าน'}), h('span',{class:'dim',text:`กด ✎ บนการ์ดเพื่อแก้${L} · แก้แล้ว ${n} รายการ · ${st}`}),
    h('button',{class:'small cedit-add',onclick:()=>kind === 'items' ? ceItemEditor(null, {cat: opts.cat}) : ceSkillEditor(null, {category: opts.category}),text:`+ เพิ่ม${L}`}),
    h('a',{class:'small',href:'#dev',text:'ดูทั้งหมดในหน้าผู้พัฒนา'})); }

/* ---- หน้าต่างแก้ (โมดัลกว้าง แบบฟอร์มซ้าย ตัวอย่างขวา) ---- */
function ceField(label, el, hint){ return h('label',{class:'le-field'}, h('span',{class:'le-lab',text:label}), el, hint ? h('span',{class:'dim le-hint',text:hint}) : null); }
function ceModal(title, form, preview, onCloseCheck){
  modal(h('div',{class:'cedit'}, h('div',{class:'row',style:'gap:8px;align-items:center'}, h('span',{class:'lore-devtag',text:'หลังบ้าน · เห็นเฉพาะผู้พัฒนา'}), h('h3',{style:'margin:0',text:title})), h('div',{class:'cedit-wrap'}, form, preview)));
  const m = $('#modal'); const box = m.querySelector('.box'); if (box) box.classList.add('wide', 'cedit-box');
  m.onclick = (ev)=>{ if (ev.target === m && (!onCloseCheck() || confirm('ยังไม่ได้บันทึก ปิดเลยไหม?'))) modal(null); };
  const closeBtn = box && [...box.querySelectorAll(':scope > .row button')].pop(); if (closeBtn) closeBtn.onclick = ()=>{ if (!onCloseCheck() || confirm('ยังไม่ได้บันทึก ปิดเลยไหม?')) modal(null); }; }
function ceItemEditor(it, opts){ if (!CatalogEdit.canEdit()) return; opts = opts || {};
  const key = it ? ceKeyOf(it) : 'new:' + uid(); const isNew = !it; const bi = CE.items.keys.indexOf(key); const base = bi >= 0 ? CE.items.base[bi] : null;
  const cur = it ? JSON.parse(JSON.stringify(it)) : { name:'', cat: CE_ITEM_CATS.includes(opts.cat) ? opts.cat : CE_ITEM_CATS[0], sub:'', desc:'', effect:'', weight: 0, price:'', slot:'' };
  const f = {}; let dirty = false;
  f.name = h('input',{value: cur.name, maxlength:160, placeholder:'ชื่อไทย (English Name)', dataset:{ce:'name'}});
  f.cat = h('select',{dataset:{ce:'cat'}}, CE_ITEM_CATS.map(c=>h('option',{value:c, selected: cur.cat===c, text:c})));
  const subList = h('datalist',{id:'cedit-subs'}); const drawSubs = ()=>{ clear(subList); for (const s of [...new Set(CE.items.base.filter(i=>i.cat===f.cat.value).map(i=>i.sub).filter(Boolean))]) subList.append(h('option',{value:s})); };
  f.sub = h('input',{value: cur.sub||'', maxlength:160, list:'cedit-subs', dataset:{ce:'sub'}});
  const subTier = ()=>{ const tr = itemTier({sub: f.sub ? f.sub.value : cur.sub, name: cur.name}); return tr ? itemTierShort(tr) : ''; };
  f.tier = h('select',{dataset:{ce:'tier'}}, CE_TIERS_IT.map(([v, l])=>h('option',{value:String(v), selected: String(cur.tier ?? '')===String(v), text:l})));
  const tierLabel = ()=>{ const t = subTier(); f.tier.options[0].textContent = t ? `ตามไฟล์ (${t})` : 'ไม่ระบุ'; f.tier.title = t ? `ไม่เลือก = ใช้ ${t} ที่อ่านจากหัวข้อย่อยหรือไฟล์แกน` : ''; };
  f.slot = h('input',{value: cur.slot||'', maxlength:80, placeholder:'เช่น ชั้นใน (Inner)', dataset:{ce:'slot'}});
  f.weight = h('input',{type:'number', min:0, step:'0.1', value: cur.weight ?? '', dataset:{ce:'weight'}});
  f.price = h('input',{value: cur.price||'', maxlength:80, placeholder:'เช่น 12 เกรฟ', dataset:{ce:'price'}});
  f.desc = h('textarea',{rows:3, maxlength:4000, dataset:{ce:'desc'}}); f.desc.value = cur.desc||'';
  f.effect = h('textarea',{rows:6, maxlength:4000, class:'le-mono', dataset:{ce:'effect'}}); f.effect.value = cur.effect||'';
  const read = ()=>({ name: f.name.value, cat: f.cat.value, sub: f.sub.value, tier: f.tier.value === 'S' ? 'S' : f.tier.value, slot: f.slot.value, weight: f.weight.value, price: f.price.value, desc: f.desc.value, effect: f.effect.value });
  const prev = h('div',{class:'le-preview cedit-preview'});
  const draw = ()=>{ clear(prev); const x = ceItemClean(read(), base) || read(); const warn = [];
    if (!String(x.name||'').trim()) warn.push('ยังไม่มีชื่อ');
    const nm = String(x.name||'').trim(); if (nm && (DATA.items||[]).some(o=>o.name === nm && ceKeyOf(o) !== key)) warn.push('ชื่อนี้ซ้ำกับไอเทมอื่นในคลัง');
    if (base && nm && nm !== base.name){ const refs = []; if (DATA.sets.sets.some(s=>(s.items||[]).some(y=>cleanAltName(y.name).replace(/\s*×\s*\d+/, '').trim() === base.name))) refs.push('ชุดเริ่มต้น');
      if (Object.values(LORE).some(a=>((a.game||{}).items||[]).includes(base.name))) refs.push('กล่องในเกมของตำนาน');
      warn.push('เปลี่ยนชื่อจากต้นฉบับ' + (refs.length ? ` ที่อ้างชื่อเดิมอยู่ (${refs.join(' และ ')}) จะหาไอเทมนี้ไม่เจอ` : '')); }
    prev.append(...[h('div',{class:'kicker',text:'ตัวอย่างการ์ดในคลัง'}), warn.length ? h('div',{class:'le-warn'}, h('b',{text:'ตรวจพบ'}), h('ul',null, warn.map(w=>h('li',{text:w})))) : null,
      h('div',{class:'cx-grid',style:'grid-template-columns:minmax(0,1fr)'}, cxItemCard(Object.assign({}, x))),
      h('p',{class:'dim',style:'font-size:12px;margin:8px 0 0',text:'ป้ายความเสียหาย เกราะ Parry Dice และ STR ที่ต้องมี อ่านจากข้อความคุณสมบัติเหมือนบนชีท ของที่ตัวละครถืออยู่แล้วเป็นสำเนา ไม่เปลี่ยนตามการแก้นี้'})].filter(Boolean)); };
  for (const el of Object.values(f)) el.addEventListener('input', ()=>{ dirty = true; if (el === f.cat) drawSubs(); if (el === f.sub) tierLabel(); draw(); });
  drawSubs(); tierLabel();
  const same = (x)=>!!base && JSON.stringify(ceItemClean(x, base)) === JSON.stringify(ceItemClean(base, base));
  const saveBtn = h('button',{class:'primary cedit-save',text: isNew ? 'เพิ่มไอเทม' : 'บันทึก'});
  saveBtn.onclick = async ()=>{ const raw = read(); const x = ceItemClean(raw, base); if (!x){ toast('ใส่ชื่อและหมวดก่อน'); return; }
    if ((DATA.items||[]).some(o=>o.name === x.name && ceKeyOf(o) !== key)){ toast('ชื่อนี้ซ้ำกับไอเทมอื่นในคลัง'); return; }
    saveBtn.disabled = true;
    const r = await CatalogEdit.save('items', (isNew ? 'เพิ่มไอเทม ' : 'แก้ไอเทม ') + x.name, d=>{ d.entries = d.entries.filter(e=>e.key !== key); if (isNew || !same(raw)) d.entries.push({key, op: isNew || !base ? 'add' : 'edit', data: x}); });
    saveBtn.disabled = false; ceSaveToast('items', r); if (r.where === 'web' || r.where === 'draft' || r.where === 'local'){ dirty = false; modal(null); ceRerender(); } };
  const actions = h('div',{class:'row le-actions'}, saveBtn,
    base && CatalogEdit.edited('items', key) ? h('button',{class:'ghost cedit-revert',onclick:async()=>{ if (!confirm('คืนไอเทมนี้เป็นค่าต้นฉบับจาก Item All')) return; const r = await CatalogEdit.save('items', 'คืนต้นฉบับ ' + base.name, d=>{ d.entries = d.entries.filter(e=>e.key !== key); }); ceSaveToast('items', r); dirty = false; modal(null); ceRerender(); },text:'คืนต้นฉบับ'}) : null,
    !isNew && !base ? h('button',{class:'ghost danger cedit-del',onclick:async()=>{ if (!confirm('ลบไอเทมที่เพิ่มจากหลังบ้านชิ้นนี้')) return; const r = await CatalogEdit.save('items', 'ลบไอเทม ' + cur.name, d=>{ d.entries = d.entries.filter(e=>e.key !== key); }); ceSaveToast('items', r); dirty = false; modal(null); ceRerender(); },text:'ลบไอเทมนี้'}) : null);
  const form = h('div',{class:'le-form cedit-form'},
    ceField('ชื่อ', f.name, 'ชื่อไทยก่อน แล้วชื่ออังกฤษในวงเล็บ'),
    h('div',{class:'le-grid'}, ceField('หมวด', f.cat), ceField('หัวข้อย่อย', f.sub), ceField('Tier', f.tier)),
    h('div',{class:'le-grid'}, ceField('ช่องหรือชั้นที่สวม', f.slot), ceField('น้ำหนัก (กก.)', f.weight), ceField('ราคา', f.price)),
    ceField('คำอธิบาย', f.desc), ceField('คุณสมบัติ (Effect)', f.effect, 'เขียนแบบ Item All เช่น 2 PDMG (Slashing) · Armor 2 / 1 (Piercing) · +1 Parry Dice'), subList, actions);
  ceModal(isNew ? 'เพิ่มไอเทมใหม่' : 'แก้ไอเทม ' + itemNameSplit(cur.name)[0], form, prev, ()=>dirty);
  draw(); setTimeout(()=>f.name.focus(), 50); }
function ceSkillEditor(sk, opts){ if (!CatalogEdit.canEdit()) return; opts = opts || {};
  const key = sk ? ceKeyOf(sk) : 'new:' + uid(); const isNew = !sk; const bi = CE.skills.keys.indexOf(key); const base = bi >= 0 ? CE.skills.base[bi] : null;
  const cur = sk ? JSON.parse(JSON.stringify(sk)) : { category: CE_SKILL_CATS.includes(opts.category) ? opts.category : CE_SKILL_CATS[0], subcategory:'', nameEn:'', nameTh:'', extra:[] };
  const f = {}; let dirty = false;
  f.nameTh = h('input',{value: cur.nameTh||'', maxlength:120, dataset:{ce:'nameTh'}});
  f.nameEn = h('input',{value: cur.nameEn||'', maxlength:120, disabled: !!base, dataset:{ce:'nameEn'}});
  f.category = h('select',{dataset:{ce:'category'}}, CE_SKILL_CATS.map(c=>h('option',{value:c, selected: cur.category===c, text: (SK_CATS.find(x=>x[1]===c)||[])[2] ? `${(SK_CATS.find(x=>x[1]===c)||[])[2]} (${c})` : c})));
  const subList = h('datalist',{id:'cedit-sksubs'}); const drawSubs = ()=>{ clear(subList); for (const s of [...new Set(CE.skills.base.filter(x=>x.category===f.category.value).map(x=>x.subcategory))]) subList.append(h('option',{value:s, label: skSubInfo(s).th})); };
  f.subcategory = h('input',{value: cur.subcategory||'', maxlength:120, list:'cedit-sksubs', dataset:{ce:'subcategory'}});
  f.branch = h('input',{value: cur.branch||'', maxlength:200, dataset:{ce:'branch'}});
  f.tier = h('select',{dataset:{ce:'tier'}}, [['','ไม่แบ่งระดับ'], ['Novice','Novice'], ['Expert','Expert'], ['Master','Master']].map(([v, l])=>h('option',{value:v, selected:(cur.tier||'')===v, text:l})));
  f.ipCost = h('input',{type:'number', min:0, max:99, value: cur.ipCost ?? '', dataset:{ce:'ipCost'}});
  f.type = h('input',{value: cur.type||'', maxlength:200, placeholder:'เช่น Cast · Swift Action · Passive', dataset:{ce:'type'}});
  f.cost = h('input',{value: cur.cost||'', maxlength:200, placeholder:'เช่น 2 MP', dataset:{ce:'cost'}});
  f.components = h('input',{value: cur.components||'', maxlength:40, placeholder:'เช่น G F', dataset:{ce:'components'}});
  f.dc = h('input',{value: cur.dc||'', maxlength:80, dataset:{ce:'dc'}});
  f.condition = h('textarea',{rows:2, maxlength:1500, dataset:{ce:'condition'}}); f.condition.value = cur.condition||'';
  f.flavor = h('textarea',{rows:2, maxlength:3000, dataset:{ce:'flavor'}}); f.flavor.value = cur.flavor||'';
  f.effect = h('textarea',{rows:7, maxlength:8000, class:'le-mono', dataset:{ce:'effect'}}); f.effect.value = cur.effect||'';
  f.onFail = h('textarea',{rows:2, maxlength:1500, dataset:{ce:'onFail'}}); f.onFail.value = cur.onFail||'';
  f.extra = h('textarea',{rows:3, maxlength:20000, dataset:{ce:'extra'}}); f.extra.value = (cur.extra||[]).join('\n\n');
  const read = ()=>({ nameTh: f.nameTh.value, nameEn: f.nameEn.value, category: f.category.value, subcategory: f.subcategory.value, branch: f.branch.value, tier: f.tier.value, ipCost: f.ipCost.value, type: f.type.value, cost: f.cost.value, components: f.components.value, dc: f.dc.value, condition: f.condition.value, flavor: f.flavor.value, effect: f.effect.value, onFail: f.onFail.value, extra: f.extra.value.split(/\n[ \t]*\n/).map(x=>x.trim()).filter(Boolean) });
  const prev = h('div',{class:'le-preview cedit-preview'});
  const draw = ()=>{ clear(prev); const raw = read(); const x = ceSkillClean(raw, base); const warn = [];
    if (!raw.nameEn.trim()) warn.push('ยังไม่มีชื่ออังกฤษ ชีทตัวละครอ้างทักษะด้วยชื่อนี้');
    if (isNew && raw.nameEn.trim() && DATA.skills.some(s=>s.nameEn === raw.nameEn.trim())) warn.push('ชื่ออังกฤษซ้ำกับทักษะที่มีอยู่ ชีทจะชี้ไปที่ทักษะตัวหลังสุด');
    if (!raw.subcategory.trim()) warn.push('ยังไม่มีประเภท');
    if (!raw.effect.trim()) warn.push('ยังไม่มีเอฟเฟกต์');
    prev.append(...[h('div',{class:'kicker',text:'ตัวอย่างการ์ดในคลัง'}), warn.length ? h('div',{class:'le-warn'}, h('b',{text:'ตรวจพบ'}), h('ul',null, warn.map(w=>h('li',{text:w})))) : null,
      x ? h('div',{class:'cx-grid',style:'grid-template-columns:minmax(0,1fr)'}, cxSkillCard(x)) : h('div',{class:'card dim',text:'ใส่ชื่ออังกฤษ หมวด และประเภทให้ครบเพื่อดูตัวอย่าง'}),
      h('p',{class:'dim',style:'font-size:12px;margin:8px 0 0',text:'ชีทตัวละครที่มีทักษะนี้อ่านข้อความใหม่ทันทีที่บันทึก เพราะชีทอ้างทักษะด้วยชื่ออังกฤษ'})].filter(Boolean)); };
  for (const el of Object.values(f)) el.addEventListener('input', ()=>{ dirty = true; if (el === f.category) drawSubs(); draw(); });
  drawSubs();
  const same = (raw)=>!!base && JSON.stringify(ceSkillClean(raw, base)) === JSON.stringify(ceSkillClean(base, base));
  const saveBtn = h('button',{class:'primary cedit-save',text: isNew ? 'เพิ่มทักษะ' : 'บันทึก'});
  saveBtn.onclick = async ()=>{ const raw = read(); const x = ceSkillClean(raw, base); if (!x){ toast('ใส่ชื่ออังกฤษ หมวด และประเภทก่อน'); return; }
    if (isNew && DATA.skills.some(s=>s.nameEn === x.nameEn) && !confirm('ชื่ออังกฤษซ้ำกับทักษะที่มีอยู่ ชีทจะชี้ไปที่ทักษะตัวใหม่ เพิ่มต่อไหม?')) return;
    saveBtn.disabled = true;
    const r = await CatalogEdit.save('skills', (isNew ? 'เพิ่มทักษะ ' : 'แก้ทักษะ ') + (x.nameTh || x.nameEn), d=>{ d.entries = d.entries.filter(e=>e.key !== key); if (isNew || !same(raw)) d.entries.push({key, op: isNew || !base ? 'add' : 'edit', data: x}); });
    saveBtn.disabled = false; ceSaveToast('skills', r); if (r.where === 'web' || r.where === 'draft' || r.where === 'local'){ dirty = false; modal(null); ceRerender(); } };
  const actions = h('div',{class:'row le-actions'}, saveBtn,
    base && CatalogEdit.edited('skills', key) ? h('button',{class:'ghost cedit-revert',onclick:async()=>{ if (!confirm('คืนทักษะนี้เป็นค่าต้นฉบับจาก Skill & Sorceries')) return; const r = await CatalogEdit.save('skills', 'คืนต้นฉบับ ' + (base.nameTh || base.nameEn), d=>{ d.entries = d.entries.filter(e=>e.key !== key); }); ceSaveToast('skills', r); dirty = false; modal(null); ceRerender(); },text:'คืนต้นฉบับ'}) : null,
    !isNew && !base ? h('button',{class:'ghost danger cedit-del',onclick:async()=>{ if (!confirm('ลบทักษะที่เพิ่มจากหลังบ้านตัวนี้')) return; const r = await CatalogEdit.save('skills', 'ลบทักษะ ' + (cur.nameTh || cur.nameEn), d=>{ d.entries = d.entries.filter(e=>e.key !== key); }); ceSaveToast('skills', r); dirty = false; modal(null); ceRerender(); },text:'ลบทักษะนี้'}) : null);
  const form = h('div',{class:'le-form cedit-form'},
    h('div',{class:'le-grid'}, ceField('ชื่อไทย', f.nameTh), ceField('ชื่ออังกฤษ', f.nameEn, base ? 'ชีทตัวละครอ้างทักษะด้วยชื่อนี้ จึงแก้ไม่ได้' : 'ชีทตัวละครอ้างทักษะด้วยชื่อนี้ ตั้งแล้วอย่าเปลี่ยน')),
    h('div',{class:'le-grid'}, ceField('หมวด', f.category), ceField('ประเภท', f.subcategory), ceField('ระดับ', f.tier), ceField('ราคา (IP)', f.ipCost)),
    h('div',{class:'le-grid'}, ceField('สายหรือหมวดย่อย', f.branch), ceField('การใช้งาน', f.type), ceField('ค่าใช้', f.cost), ceField('Components', f.components)),
    ceField('เงื่อนไข', f.condition), ceField('Flavor (เรื่องเล่า)', f.flavor), ceField('เอฟเฟกต์', f.effect), h('div',{class:'le-grid'}, ceField('DC', f.dc), ceField('ถ้าล้มเหลว', f.onFail)),
    ceField('รายละเอียดเพิ่ม', f.extra, 'ย่อหน้าละหัวข้อ เว้นบรรทัดว่างระหว่างหัวข้อ'), subList, actions);
  ceModal(isNew ? 'เพิ่มทักษะใหม่' : 'แก้ทักษะ ' + (cur.nameTh || cur.nameEn), form, prev, ()=>dirty);
  draw(); setTimeout(()=>(base ? f.nameTh : f.nameEn).focus(), 50); }

/* ---- การ์ดในหลังบ้าน (#dev) ---- */
function catalogDevCard(){
  if (!CatalogEdit.canEdit()) return null;
  const card = h('div',{class:'card le-dev cedit-dev'});
  card.append(h('h2',{text:'แก้ข้อมูลไอเทมและทักษะ'}), h('p',{class:'dim',style:'font-size:13px;margin:2px 0 10px',text:'แก้ได้จากปุ่ม ✎ บนการ์ดในหน้าคลังไอเทมและคลังทักษะ ข้อมูลที่แก้ใช้ทั้งเว็บ (ชีท วิซาร์ด โต๊ะ คลัง NPC) แต่ไม่ทับไฟล์ Item All หรือ Skill & Sorceries ส่งออกเป็น JSON ได้ด้านล่าง'}));
  for (const kind of ['items','skills']){ const K = CE[kind]; const d = CatalogEdit.effective(kind);
    const st = CatalogEdit.ref(kind) ? (CatalogEdit.localD[kind] ? `มีร่างในเครื่องนี้ที่ยังไม่ขึ้นเว็บ${CatalogEdit.error[kind] ? ' (' + CatalogEdit.error[kind] + ')' : ''} ต้องเผยแพร่กฎ codex ฉบับที่รับ items และ skills ก่อน` : CatalogEdit.status[kind] === 'noread' ? `อ่านจากเว็บไม่ได้ (${CatalogEdit.error[kind]})` : `ข้อมูลที่แก้เก็บบนเว็บ (${K.doc})`) : 'เปิดจากไฟล์ในเครื่อง เก็บในเบราว์เซอร์นี้';
    const es = d ? d.entries : [];
    card.append(h('h3',{text:`${K.label}ที่แก้ ${es.filter(e=>e.op==='edit').length} · เพิ่ม ${es.filter(e=>e.op==='add').length}`}), h('p',{class:'dim',style:'font-size:12.5px;margin:0 0 4px',text:st}));
    if (es.length) card.append(h('ul',{class:'le-list cedit-list',dataset:{kind}}, es.map(e=>{ const obj = (kind === 'items' ? DATA.items : DATA.skills).find(o=>ceKeyOf(o) === e.key);
      const nm = kind === 'items' ? e.data.name : (e.data.nameTh ? `${e.data.nameTh} (${e.data.nameEn})` : e.data.nameEn);
      return h('li',null, h('button',{class:'linkish',onclick:()=>{ if (obj) (kind === 'items' ? ceItemEditor(obj) : ceSkillEditor(obj)); },text:nm}), ' ', e.op==='add' ? tag('เพิ่มใหม่','ok') : null, e.orphan ? tag('หาต้นฉบับไม่เจอ','neg') : null); })));
    else card.append(h('p',{class:'dim',style:'font-size:12.5px;margin:0',text:'ยังไม่มี ทุกรายการแสดงค่าจากไฟล์ต้นฉบับ'}));
    const row = h('div',{class:'row',style:'margin-top:6px'}, h('a',{class:'small',href: kind === 'items' ? '#items' : '#skills',text: kind === 'items' ? 'ไปคลังไอเทม' : 'ไปคลังทักษะ'}),
      h('button',{class:'small',onclick:()=>kind === 'items' ? ceItemEditor(null) : ceSkillEditor(null),text:`+ เพิ่ม${K.label}`}));
    if (CatalogEdit.localD[kind] && CatalogEdit.ref(kind)) row.append(h('button',{class:'small',onclick:async()=>{ ceSaveToast(kind, await CatalogEdit.pushDraft(kind)); renderDev(); },text:'ส่งร่างขึ้นเว็บอีกครั้ง'}),
      h('button',{class:'small ghost',onclick:()=>{ if (confirm(`ทิ้งร่าง${K.label}ในเครื่องนี้ แล้วใช้ข้อมูลบนเว็บ`)){ CatalogEdit.dropDraft(kind); renderDev(); } },text:'ทิ้งร่างในเครื่อง'}));
    card.append(row);
    if (d && d.log && d.log.length) card.append(h('details',{class:'le-help'}, h('summary',{text:'ประวัติการแก้ล่าสุด'}), h('ul',{class:'le-list dim'}, d.log.slice(0, 12).map(x=>h('li',{text:`${new Date(x.at).toLocaleString('th-TH')} · ${x.by} · ${x.what}`}))))); }
  const file = h('input',{type:'file',accept:'application/json',style:'display:none',onchange:async()=>{ const fl = file.files[0]; if (!fl) return;
    try { const j = JSON.parse(await fl.text()); const di = ceSanitize('items', j.items || {entries:[]}), ds = ceSanitize('skills', j.skills || {entries:[]});
      if (!confirm(`นำเข้าไอเทม ${di.entries.length} รายการ และทักษะ ${ds.entries.length} รายการ ข้อมูลที่แก้ไว้ตอนนี้จะถูกเขียนทับทั้งหมด`)) return;
      ceSaveToast('items', await CatalogEdit.save('items', 'นำเข้าจากไฟล์', d=>{ d.entries = di.entries; })); ceSaveToast('skills', await CatalogEdit.save('skills', 'นำเข้าจากไฟล์', d=>{ d.entries = ds.entries; })); renderDev(); }
    catch(e){ toast('นำเข้าไม่ได้: ' + e.message); } }});
  card.append(h('h3',{text:'สำรองข้อมูล'}), h('div',{class:'row'},
    h('button',{class:'cedit-export',onclick:()=>{ const out = { items: CatalogEdit.effective('items') || {v:1, entries:[]}, skills: CatalogEdit.effective('skills') || {v:1, entries:[]} };
      const blob = new Blob([JSON.stringify(out, null, 1)], {type:'application/json'}); const a = h('a',{href:URL.createObjectURL(blob), download:'kirana-items-skills-edits.json'}); document.body.append(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 500); },text:'ส่งออกไอเทมและทักษะที่แก้ (JSON)'}),
    h('button',{onclick:()=>file.click(),text:'นำเข้าจากไฟล์'}), file));
  return card; }
