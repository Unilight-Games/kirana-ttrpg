/* ===== คลัง NPC และ Asset (v1.18 ผู้ใช้สั่ง 12 พ.ย. 2026): GM เตรียมตัวละครรองกับสิ่งของประกอบฉากไว้ก่อนเปิดโต๊ะ แล้วโหลดลงบอร์ดจากในห้อง =====
 * หน้าตาและวิธีใช้ตามหน้า "สร้างและค้นหาแผนที่": คลังของฉัน + ค้นหาที่เผยแพร่ + ตัวแก้ไข + เก็บสำเนาเข้าคลัง
 * เอกสารอยู่ในคอลเลกชัน maps เดียวกับคลังแผนที่ แยกด้วยฟิลด์ type ('npc' | 'asset') เพราะ Rules ของ maps ครอบคลุมอยู่แล้ว
 *   (อ่านได้เฉพาะเจ้าของ ผู้พัฒนา หรือเมื่อ published) จึงใช้ได้ทันทีโดยไม่ต้องเผยแพร่ Rules ชุดใหม่ · คลังแผนที่กรองเอกสารที่มี type ออก
 *   {id, type, ownerId, ownerName, name, desc, note, hp, init, tgh, mods?, nv, aquatic, torch, icon, image:{has}, published, createdAt, updatedAt, fromId?, fromName?} · mods = ค่าพลังดัดแปลง {STR..INT} (v1.25)
 * ภาพหมากเก็บแยกใน mapimages/<id> (ของเจ้าของเท่านั้น ไม่ติดไปกับการเผยแพร่ หลักเดียวกับภาพประกอบแผนที่ที่ผู้ใช้เคาะ 9 พ.ย. 2026)
 * โหมดออฟไลน์เก็บใน localStorage kirana.npcs.v1 (ภาพอยู่ใน image.data ของรายการ) */
const LIB_TYPES = [['npc','NPC'], ['asset','Asset']];
const ASSET_ICONS = ['📦','🧰','🚪','🪤','🔥','🏮','🗿','🪑','🛢️','⚰️','🗝️','📜','💎','🪨','⛺','🛒','⚙️','🕯️'];
const LIB_PLACE_MAX = 12; // วางครั้งละไม่เกินนี้ เอกสารห้องมีเพดานขนาด และภาพหมากติดไปกับหมากทุกตัว
/* เอกสารที่อ่านจากฐานข้อมูลถือเป็นข้อมูลที่ไม่น่าไว้ใจ (Rules ของ maps ไม่ตรวจชนิดข้อมูล และรายการที่เผยแพร่เขียนโดยผู้ใช้คนอื่น): บังคับชนิดและความยาวของทุกฟิลด์ก่อนใช้ */
function libStr(v, max){ return (typeof v === 'string' ? v : (v == null ? '' : String(v))).slice(0, max); }
function libInt(v, min, max){ const n = Math.round(+v); return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : Math.max(min, 0); }
function libIcon(v){ return Array.from(libStr(v, 16)).slice(0, 3).join('') || '📦'; } // อีโมจิบางตัวมีหลายรหัสอักขระ เก็บได้ไม่เกิน 3 รหัส
function libImageOk(d){ return typeof d === 'string' && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+\/=]+$/.test(d) && d.length < 400000; } // รับเฉพาะภาพที่ฝังมากับข้อมูล ไม่โหลดจากที่อื่น
function libClean(x){
  if (!x || typeof x !== 'object' || (x.type !== 'npc' && x.type !== 'asset') || typeof x.id !== 'string') return null;
  const o = { id: x.id, type: x.type, ownerId: libStr(x.ownerId, 128), ownerName: libStr(x.ownerName, 80), name: libStr(x.name, 80), desc: libStr(x.desc, 2000), note: libStr(x.note, 4000), published: x.published === true, torch: x.torch === true, createdAt: +x.createdAt || 0, updatedAt: +x.updatedAt || 0 };
  if (x.fromId) o.fromId = libStr(x.fromId, 64); if (x.fromName) o.fromName = libStr(x.fromName, 80);
  if (x.type === 'asset'){ o.icon = libIcon(x.icon); o.hp = libInt(x.hp, 0, 999); }
  else { o.hp = libInt(x.hp, 1, 999) || 10; o.init = libInt(x.init, -10, 20); o.tgh = libInt(x.tgh, 0, 99); o.nv = x.nv === true; o.aquatic = x.aquatic === true; const mods = npcModsClean(x.mods); if (mods) o.mods = mods; const eq = npcEquipClean(x.equip); if (eq) o.equip = eq; } // v1.26: อาวุธและชุดเกราะ
  if (x.image && typeof x.image === 'object'){ o.image = { has: true }; if (libImageOk(x.image.data)) o.image.data = x.image.data; }
  const ico = icoClean(x.ico); if (ico) o.ico = ico;
  return o;
}
const NpcLib = {
  mine: [], pub: [], unsub: [], waiters: [], onChange: null, loaded: false, tab: 'mine', q: '', type: 'all', sort: 'new', pickHidden: true, localKey: 'kirana.npcs.v1', images: {},
  isItem(m){ return !!m && (m.type==='npc' || m.type==='asset'); },
  typeLabel(t){ return t==='asset' ? 'Asset' : 'NPC'; },
  loadLocal(){ try { return JSON.parse(localStorage.getItem(this.localKey)||'[]').map(libClean).filter(Boolean); } catch(e){ return []; } },
  saveLocal(list){ try { localStorage.setItem(this.localKey, JSON.stringify(list)); } catch(e){} },
  isMine(m){ return !!m && (!Store.db || m.ownerId===Store.me || !m.ownerId); },
  newItem(type){
    const base = { id: uid(), type: type==='asset' ? 'asset' : 'npc', name: type==='asset' ? 'สิ่งของใหม่' : 'NPC ใหม่', desc:'', note:'', published:false, ownerId: Store.me||'local', ownerName: Store.displayName||'', createdAt: Date.now(), updatedAt: Date.now() };
    return base.type==='asset' ? Object.assign(base, {icon:'📦', hp:0, torch:false}) : Object.assign(base, {hp:10, init:0, tgh:0, nv:false, aquatic:false, torch:false});
  },
  get(id){ return this.mine.find(x=>x.id===id) || this.pub.find(x=>x.id===id) || null; },
  async save(m){
    m.updatedAt = Date.now(); m.ownerId = m.ownerId || Store.me || 'local'; if (this.isMine(m)) m.ownerName = Store.displayName || m.ownerName || '';
    const i = this.mine.findIndex(x=>x.id===m.id); if (i>=0) this.mine[i] = m; else this.mine.push(m);
    if (!Store.db){ this.saveLocal(this.mine); return true; }
    const doc = JSON.parse(JSON.stringify(m)); if (doc.image){ if (doc.image.data) this.images[m.id] = doc.image.data; delete doc.image.data; doc.image.has = true; }
    try { await Store.db.doc('maps/'+m.id).set(doc); return true; }
    catch(e){ console.warn('save lib item', e); toast('บันทึกลงคลังไม่ได้ (สิทธิ์ไม่พอ หรือยังไม่ได้เชื่อมต่อ)'); return false; }
  },
  async remove(id){ this.mine = this.mine.filter(x=>x.id!==id); delete this.images[id]; if (!Store.db){ this.saveLocal(this.mine); return true; } try { await Store.db.doc('maps/'+id).delete(); Store.db.doc('mapimages/'+id).delete().catch(()=>{}); return true; } catch(e){ toast('ลบออกจากคลังไม่ได้'); return false; } },
  /* คลังของฉัน (อัปเดตสด) · ผู้พัฒนาเห็นของทุกคน · ผู้ฟังล่าสุดเป็นคนได้รับการอัปเดต (หน้าที่เปิดอยู่ตอนนี้) */
  subscribe(onChange){
    this.onChange = onChange; const fire = ()=>{ for (const w of this.waiters.splice(0)) w(); if (this.onChange) this.onChange(); };
    if (!Store.db){ this.mine = this.loadLocal(); this.loaded = true; fire(); return; }
    if (this.unsub.length){ onChange(); return; }
    try { const q = Store.isDevUid ? Store.db.collection('maps') : Store.db.collection('maps').where('ownerId','==',Store.me);
      this.unsub.push(q.onSnapshot(snap=>{ this.mine = snapDocs(snap).map(libClean).filter(Boolean); this.loaded = true; fire(); }, e=>{ console.warn('npc lib', e); this.loaded = true; fire(); })); }
    catch(e){ console.warn(e); this.loaded = true; fire(); }
  },
  /* รอให้คลังโหลดเสร็จหนึ่งครั้ง (ใช้ตอนเก็บหมากจากโต๊ะเข้าคลังโดยยังไม่เคยเปิดหน้าคลัง) */
  ready(){ if (this.loaded) return Promise.resolve(); return new Promise(res=>{ this.waiters.push(res); setTimeout(res, 2500); if (!this.unsub.length) this.subscribe(this.onChange || (()=>{})); }); },
  async loadPublished(){
    if (!Store.db){ this.pub = this.loadLocal().filter(m=>m.published); return this.pub; }
    const byNew = (a,b)=>(b.updatedAt||0)-(a.updatedAt||0);
    try { const out = []; for (const [t] of LIB_TYPES){ const snap = await Store.db.collection('maps').where('published','==',true).where('type','==',t).limit(300).get(); out.push(...snapDocs(snap).map(libClean).filter(Boolean)); } this.pub = out.sort(byNew); }
    catch(e){ // ฐานข้อมูลบางแบบไม่รับเงื่อนไขซ้อน: ถอยไปใช้คำค้นเดียวกับคลังแผนที่แล้วกรองเอง
      try { const snap = await Store.db.collection('maps').where('published','==',true).limit(500).get(); this.pub = snapDocs(snap).map(libClean).filter(Boolean).sort(byNew); }
      catch(e2){ console.warn('pub lib', e2); toast('โหลดรายการที่เผยแพร่ไม่ได้'); } }
    return this.pub;
  },
  /* เก็บสำเนาเข้าคลังของฉัน (ส่วนตัว จำชื่อผู้สร้างต้นฉบับไว้) · ภาพหมากติดไปเฉพาะสำเนาของเจ้าของเอง */
  async copyToMine(src, rename){
    const m = libClean(JSON.parse(JSON.stringify(src))); if (!m) return null; m.id = uid(); m.ownerId = Store.me||'local'; m.ownerName = Store.displayName||''; m.published = false;
    const foreign = !!(src.ownerId && src.ownerId !== (Store.me||'local'));
    if (foreign){ m.fromId = src.id; m.fromName = src.ownerName||''; delete m.image; } else { m.fromId = src.fromId||null; m.fromName = src.fromName||''; }
    m.name = rename || src.name; m.createdAt = Date.now();
    if (!foreign && src.image){ const data = await this.loadImage(src); delete m.image; if (data) await this.saveImage(m, data); }
    return (await this.save(m)) ? m : null;
  },
  /* ---- ภาพหมาก: เจ้าของเท่านั้น ---- */
  async loadImageById(id){ if (!id) return null; if (this.images[id]) return this.images[id]; const it = this.mine.find(x=>x.id===id); if (it && it.image && libImageOk(it.image.data)){ this.images[id] = it.image.data; return it.image.data; }
    if (!Store.db){ const l = this.loadLocal().find(x=>x.id===id); const d = l && l.image && libImageOk(l.image.data) ? l.image.data : null; if (d) this.images[id] = d; return d; }
    try { const d = docData(await Store.db.doc('mapimages/'+id).get()); if (d && libImageOk(d.data)){ this.images[id] = d.data; return d.data; } } catch(e){ /* ไม่ใช่เจ้าของ หรือไม่มีภาพ */ }
    return null; },
  async loadImage(m){ if (!m || !m.image || !this.isMine(m)) return null; if (libImageOk(m.image.data)) return m.image.data; return this.loadImageById(m.id); },
  async saveImage(m, data){ this.images[m.id] = data; if (!Store.db){ m.image = {has:true, data}; return true; }
    try { await Store.db.doc('mapimages/'+m.id).set({ id: m.id, ownerId: Store.me, data, at: Date.now() }); m.image = {has:true}; return true; }
    catch(e){ console.warn('save token image', e); delete this.images[m.id]; toast('บันทึกภาพหมากไม่ได้'); return false; } },
  async deleteImage(m){ delete this.images[m.id]; delete m.image; if (Store.db) try { await Store.db.doc('mapimages/'+m.id).delete(); } catch(e){} },
  /* ภาพย่อที่ติดไปกับหมากบนบอร์ด (64px) */
  async tokenThumb(m){ const data = await this.loadImage(m); return data ? shrinkDataUrl(data, 64, m.type==='asset') : null; },
};
/* ย่อภาพเป็นสี่เหลี่ยมจัตุรัส: NPC ครอบกึ่งกลาง (เห็นหน้า) · Asset ย่อทั้งชิ้นให้พอดีกรอบ พื้นหลังโปร่งใส · WebP ถ้าเบราว์เซอร์รองรับ ไม่อย่างนั้น PNG */
function squareCanvas(img, size, contain){
  const cv = document.createElement('canvas'); cv.width = cv.height = size; const ctx = cv.getContext('2d'); const w = img.naturalWidth || img.width, hgt = img.naturalHeight || img.height;
  if (contain){ const sc = Math.min(size/w, size/hgt); const dw = w*sc, dh = hgt*sc; ctx.drawImage(img, (size-dw)/2, (size-dh)/2, dw, dh); }
  else { const s = Math.min(w, hgt); ctx.drawImage(img, (w-s)/2, (hgt-s)/2, s, s, 0, 0, size, size); }
  let out = cv.toDataURL('image/webp', 0.86); if (!out.startsWith('data:image/webp')) out = cv.toDataURL('image/png');
  return out;
}
function shrinkDataUrl(dataUrl, size, contain){ return new Promise(res=>{ if (!dataUrl) return res(null); const img = new Image(); img.onload = ()=>{ try { res(squareCanvas(img, size, contain)); } catch(e){ res(null); } }; img.onerror = ()=>res(null); img.src = dataUrl; }); }
function shrinkTokenImage(file, contain){ return new Promise((resolve, reject)=>{ const img = new Image(); const url = URL.createObjectURL(file); img.onload = ()=>{ URL.revokeObjectURL(url); try { const data = squareCanvas(img, 160, contain); resolve({ data, bytes: Math.round(data.length*0.75) }); } catch(e){ reject(e); } }; img.onerror = ()=>{ URL.revokeObjectURL(url); reject(new Error('อ่านรูปไม่ได้')); }; img.src = url; }); }

/* รูปแทนตัวในคลัง: NPC วงกลม · Asset สี่เหลี่ยมมน · ไม่มีภาพใช้อักษรย่อหรือไอคอน */
function libAvatar(it, size){
  const el = h('div',{class:'libav '+(it.type==='asset'?'asset':'npc'), style:`width:${size}px;height:${size}px;font-size:${Math.round(size*(it.type==='asset' ? 0.5 : 0.36))}px`});
  const put = (d)=>{ clear(el); el.style.background = ''; if (d) el.append(h('img',{src:d,alt:it.name||'',draggable:'false'})); else if (ico){ el.style.background = ico.b; el.append(icoSvg(ico)); } else el.append(h('span',{text: it.type==='asset' ? libIcon(it.icon) : (String(it.name||'?').trim().slice(0,2) || '?')})); };
  const ico = icoClean(it.ico);
  const d0 = NpcLib.isMine(it) ? ((it.image && libImageOk(it.image.data) && it.image.data) || NpcLib.images[it.id] || null) : null; put(d0); // ภาพหมากเป็นของเจ้าของเท่านั้น ไม่แสดงภาพจากเอกสารของคนอื่น
  if (!d0 && it.image && NpcLib.isMine(it)) NpcLib.loadImage(it).then(d=>{ if (d && el.isConnected) put(d); });
  return el;
}
/* v1.25: ค่าพลังดัดแปลงของ NPC เก็บเฉพาะตัวที่ไม่เป็น 0 · คืน null ถ้าไม่มีเลย */
function npcModsClean(m){ const out = {}; for (const st of STATS){ const v = Math.max(-10, Math.min(10, Math.round(+((m||{})[st])||0))); if (v) out[st] = v; } return Object.keys(out).length ? out : null; }
/* v1.25 (Non สั่ง 15 พ.ย. 2026 ต่อจากคำตอบเรื่อง Modified): ค่าพลังรองของ NPC คิดจากค่าพลังดัดแปลงด้วยสูตรเดียวกับตัวละครผู้เล่น (compute ใน core.js)
 * Might = ปัดลง(STR Mod / 2) + 1 · Sight = ปัดลง(PER Mod / 2) + 1 · Passive PER = 7 + PER Mod · Reflex = ปัดลง(AGI Mod / 2) + 1 */
function npcDerived(m){ const g = (st)=>Math.round(+((m||{})[st])||0); return { might: Math.floor(g('STR')/2) + 1, sight: Math.floor(g('PER')/2) + 1, passivePer: 7 + g('PER'), reflex: Math.floor(g('AGI')/2) + 1 }; }
function npcDerivedTags(m){ const d = npcDerived(m); return [tag(`Might ${signed(d.might)}`,'stat sc sc-STR'), tag(`Sight ${signed(d.sight)}`,'stat sc sc-PER'), tag(`Passive PER ${d.passivePer}`,'stat sc sc-PER'), tag(`Reflex ${signed(d.reflex)}`,'stat sc sc-AGI')]; }
function npcModsText(m){ const x = npcModsClean(m); return x ? STATS.filter(st=>x[st]).map(st=>`${st} ${signed(x[st])}`).join(' · ') : ''; }
function libMeta(it){ const a = it.type==='asset';
  return h('div',{class:'gives'}, tag(a ? 'Asset' : 'NPC', a ? 'prop' : 'neg'),
    a ? (+it.hp > 0 ? tag(`HP ${+it.hp}`) : null) : tag(`HP ${+it.hp||0}`), a ? null : tag(`Init ${signed(+it.init||0)}`), !a && +it.tgh > 0 ? tag(`Toughness ${+it.tgh}`) : null, !a && npcModsText(it.mods) ? tag(npcModsText(it.mods),'stat') : null, ...(a ? [] : npcDerivedTags(it.mods)), !a && (it.equip||[]).length ? tag(npcEquipShort(it.equip),'prop') : null,
    !a && it.nv ? tag('👁 Dark Vision') : null, !a && it.aquatic ? tag('🐟 สัตว์น้ำ','stat') : null, it.torch ? tag('🔥 แหล่งแสง','prop') : null,
    it.published ? tag('เผยแพร่แล้ว','ok') : tag('ส่วนตัว'), it.fromName ? tag('จาก '+it.fromName,'prop') : null, it.image ? tag('🖼 มีภาพหมาก (เฉพาะเจ้าของ)') : null); }
function libConfirmPublish(it){ if (it.published) return true; const lines = [`เผยแพร่ "${it.name||'รายการนี้'}"?`, '', 'ทุกคนจะค้นหาเจอและเก็บสำเนาไปใช้ได้ สำเนานั้นได้คำอธิบายและบันทึกของ GM ไปด้วย', 'ผู้ใช้ที่เข้าสู่ระบบด้วย Google ให้ดาวและคอมเมนต์รายการนี้ได้']; if (it.image) lines.push('ภาพหมากจะไม่ติดไปกับการเผยแพร่ ยังอยู่ในคลังของคุณคนเดียว'); return confirm(lines.join('\n')); }
function libMatches(it, k){ return !k || (it.name||'').toLowerCase().includes(k) || (it.desc||'').toLowerCase().includes(k) || (it.ownerName||'').toLowerCase().includes(k) || NpcLib.typeLabel(it.type).toLowerCase().includes(k); }

/* ---- หน้า #npcs: คลังของฉัน + ค้นหาที่เผยแพร่ ---- */
function renderNpcs(){
  const root = clearKeep($('#v-npcs'));
  const create = async (type)=>{ const it = NpcLib.newItem(type); if (await NpcLib.save(it)) location.hash = '#npcedit-'+it.id; };
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'สร้างและค้นหา NPC กับ Asset'}), h('p',{text:'GM เตรียมตัวละครรอง ศัตรู และสิ่งของประกอบฉาก (Asset) เช่น หีบ ประตู กับดัก กองไฟ ไว้ก่อนเปิดโต๊ะ ตั้งค่าพลัง เขียนคำอธิบาย ใส่ภาพหมาก แล้วเก็บไว้ในคลังส่วนตัว ในห้องที่คุณเป็น GM กด "📚 คลัง NPC / Asset" เพื่อวางลงบอร์ด รายการจะยังเป็นส่วนตัวจนกว่าจะกดเผยแพร่ GM คนอื่นค้นหารายการที่เผยแพร่แล้วเก็บสำเนาไปใช้ในโต๊ะของตัวเองได้ และให้ดาวกับคอมเมนต์บอกผู้สร้างได้ว่าใช้แล้วเป็นอย่างไร'})),
    h('div',{class:'row'}, h('button',{class:'primary newnpc',onclick:()=>create('npc'),text:'+ สร้าง NPC'}), h('button',{class:'primary newasset',onclick:()=>create('asset'),text:'+ สร้าง Asset'}))));
  if (!Store.db) root.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'โหมดออฟไลน์: คลังเก็บในเบราว์เซอร์นี้เท่านั้น เผยแพร่ให้คนอื่นเห็นไม่ได้จนกว่าจะเชื่อมต่อ'));
  const tabs = h('div',{class:'row tabs',style:'margin-bottom:10px'},
    h('button',{class:'small'+(NpcLib.tab==='mine'?' primary':''),onclick:()=>{ NpcLib.tab='mine'; renderNpcs(); },text:'คลังของฉัน'}),
    h('button',{class:'small'+(NpcLib.tab==='pub'?' primary':''),onclick:async()=>{ NpcLib.tab='pub'; renderNpcs(); await NpcLib.loadPublished(); if (location.hash==='#npcs') renderNpcs(); },text:'ค้นหาที่เผยแพร่'}),
    h('span',{class:'dim',style:'font-size:12px;margin-left:6px',text:'ชนิด'}),
    [['all','ทั้งหมด'], ...LIB_TYPES].map(([k,l])=>h('button',{class:'small typef'+(NpcLib.type===k?' on':''),dataset:{type:k},onclick:()=>{ NpcLib.type = k; renderNpcs(); },text:l})));
  const q = h('input',{placeholder:'ค้นหาชื่อ คำอธิบาย หรือชื่อผู้สร้าง',style:'min-width:240px',value:NpcLib.q}); q.oninput = ()=>{ NpcLib.q = q.value; drawList(); };
  tabs.append(q);
  // v1.19: ดาวและคอมเมนต์ของ NPC และ Asset ที่เผยแพร่
  const rvSort = NpcLib.tab==='pub' ? rvSortSelect(NpcLib, ()=>drawList()) : null; if (rvSort) tabs.append(rvSort);
  const rvMine = rvMineButton(()=>{ if (location.hash==='#npcs') renderNpcs(); }); if (rvMine) tabs.append(rvMine);
  root.append(tabs);
  const host = h('div'); root.append(host);
  function drawList(){
    clear(host);
    const k = NpcLib.q.trim().toLowerCase();
    const filt = (arr)=> arr.filter(it => (NpcLib.type==='all' || it.type===NpcLib.type) && libMatches(it, k));
    const byNew = (a,b)=>(b.updatedAt||0)-(a.updatedAt||0);
    if (NpcLib.tab==='mine'){
      if (!NpcLib.loaded){ host.append(h('div',{class:'card dim',text:'กำลังโหลดคลังของคุณ…'})); return; }
      const mine = filt(NpcLib.mine.filter(m=>NpcLib.isMine(m))).sort(byNew);
      const others = Store.isDevUid ? filt(NpcLib.mine.filter(m=>!NpcLib.isMine(m))).sort(byNew) : [];
      if (!mine.length) host.append(h('div',{class:'card dim',text: (NpcLib.q || NpcLib.type!=='all') ? 'ไม่พบรายการที่ตรงกับตัวกรอง' : 'คลังยังว่าง กด "+ สร้าง NPC" หรือ "+ สร้าง Asset" หรือไปเก็บจากแท็บ "ค้นหาที่เผยแพร่"'}));
      else host.append(h('div',{class:'grid wide'}, mine.map(it=>libCard(it, true))));
      if (others.length){ host.append(h('h3',{style:'margin:18px 0 8px',text:'รายการของผู้ใช้คนอื่น (มุมมองผู้พัฒนา)'})); host.append(h('div',{class:'grid wide'}, others.map(it=>libCard(it, false)))); }
    } else {
      const pub = ReviewLib.sorted(filt(NpcLib.pub), NpcLib.sort);
      if (!pub.length) host.append(h('div',{class:'card dim',text: (NpcLib.q || NpcLib.type!=='all') ? 'ไม่พบรายการที่ตรงกับตัวกรอง' : 'ยังไม่มีใครเผยแพร่ NPC หรือ Asset (หรือกำลังโหลด)'}));
      else host.append(h('div',{class:'grid wide'}, pub.map(it=>libCard(it, NpcLib.isMine(it)))));
    }
  }
  NpcLib.subscribe(()=>{ if (location.hash==='#npcs') drawList(); });
  if (NpcLib.tab==='pub' && !NpcLib.pub.length) NpcLib.loadPublished().then(()=>{ if (location.hash==='#npcs') drawList(); });
  if (Store.db){ const before = ReviewLib.at, wasLoaded = ReviewLib.loaded; ReviewLib.load().then(()=>{ if ((ReviewLib.at === before && wasLoaded) || location.hash!=='#npcs') return; if (rvMine) rvMine.textContent = rvMineLabel(); drawList(); }); }
  drawList();
}
function libCard(it, mine){
  const card = h('div',{class:'card mapcard npccard',dataset:{id:it.id,type:it.type}});
  card.append(h('div',{class:'row',style:'gap:12px;align-items:flex-start'}, h('div',{class:'thumbwrap',onclick:()=>previewLibItem(it)}, libAvatar(it, 72)),
    h('div',{style:'flex:1;min-width:160px'}, h('h3',{style:'margin:0',text:it.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',style:'font-size:12px',text:(it.ownerName? 'โดย '+it.ownerName+' · ' : '') + new Date(it.updatedAt||0).toLocaleDateString('th-TH')}), libMeta(it), rvChip(it, ()=>{ if (location.hash==='#npcs') renderNpcs(); }), it.desc ? h('p',{class:'desc',style:'margin:6px 0 0;font-size:13px',text:it.desc.slice(0,160)}) : null)));
  const row = h('div',{class:'row',style:'margin-top:8px'});
  row.append(h('button',{class:'small ghost',onclick:()=>previewLibItem(it),text:'ดู'}));
  if (mine){
    row.append(h('button',{class:'small primary',onclick:()=>{ location.hash='#npcedit-'+it.id; },text:'แก้ไข'}),
      h('button',{class:'small'+(it.published?' on':''),title: it.published ? 'เอาออกจากหน้าค้นหา (สำเนาที่คนอื่นเก็บไปแล้วยังอยู่กับเขา)' : 'ให้ทุกคนค้นหาและเก็บสำเนาได้',onclick:async()=>{ if (!libConfirmPublish(it)) return; it.published = !it.published; if (await NpcLib.save(it)) toast(it.published ? 'เผยแพร่แล้ว ทุกคนค้นหาเจอ' : 'ยกเลิกเผยแพร่แล้ว'); renderNpcs(); },text: it.published ? 'ยกเลิกเผยแพร่' : 'เผยแพร่'}),
      h('button',{class:'small ghost',onclick:async()=>{ const c = await NpcLib.copyToMine(it, (it.name||NpcLib.typeLabel(it.type))+' (สำเนา)'); if (c){ toast('ทำสำเนาแล้ว'); renderNpcs(); } },text:'ทำสำเนา'}),
      h('button',{class:'small ghost',onclick:async()=>{ if (!confirm(`ลบ "${it.name}" ออกจากคลังถาวร?`)) return; await NpcLib.remove(it.id); renderNpcs(); },text:'ลบ'}));
  } else {
    row.append(h('button',{class:'small primary',title:'เก็บสำเนาไว้ในคลังของคุณ แก้ไขและใช้ในโต๊ะของตัวเองได้',onclick:async()=>{ const c = await NpcLib.copyToMine(it); if (c) toast(`เก็บ "${it.name}" เข้าคลังของคุณแล้ว`); },text:'เก็บเข้าคลัง'}));
  }
  card.append(row);
  return card;
}
function previewLibItem(it){
  const mine = NpcLib.isMine(it) || Store.isDevUid;
  modal(h('div',null, h('div',{class:'row',style:'gap:14px;align-items:flex-start'}, libAvatar(it, 120), h('div',{style:'flex:1;min-width:180px'}, h('h3',{text:it.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',style:'font-size:12px',text:(it.ownerName? 'โดย '+it.ownerName : '')}), libMeta(it), rvChip(it, ()=>{ if (location.hash==='#npcs') renderNpcs(); }))),
    it.desc ? h('div',{style:'margin-top:10px'}, h('div',{class:'kicker',text:'คำอธิบาย (ผู้เล่นเห็น)'}), h('p',{class:'desc',style:'white-space:pre-wrap;margin:4px 0 0',text:it.desc})) : null,
    mine && it.note ? h('div',{style:'margin-top:10px'}, h('div',{class:'kicker',text:'บันทึก GM (ลับ)'}), h('p',{class:'desc',style:'white-space:pre-wrap;margin:4px 0 0',text:it.note})) : null,
    !mine && it.note ? h('p',{class:'dim',style:'font-size:12px;margin:10px 0 0',text:'รายการนี้มีบันทึกของ GM แนบมาด้วย จะเห็นเมื่อเก็บสำเนาเข้าคลังของคุณ'}) : null));
}

/* ---- ตัวแก้ไข #npcedit-<id> ---- */
function renderNpcEditor(id){
  const root = clearKeep($('#v-npcs'));
  const back = ()=>h('button',{style:'margin-top:10px',onclick:()=>{ location.hash='#npcs'; },text:'← กลับคลัง NPC / Asset'});
  let drawn = false;
  const draw = ()=>{
    const it = NpcLib.get(id);
    if (!it){ clear(root); root.append(h('div',{class:'card'}, NpcLib.loaded ? 'ไม่พบรายการนี้ในคลังของคุณ' : 'กำลังโหลด…'), back()); return; }
    if (!NpcLib.isMine(it) && !Store.isDevUid){ clear(root); root.append(h('div',{class:'card',text:'รายการนี้ไม่ใช่ของคุณ เก็บสำเนาเข้าคลังก่อนแล้วค่อยแก้'}), back()); return; }
    clear(root); drawn = true;
    const asset = it.type==='asset';
    let dirty = false; const markDirty = ()=>{ dirty = true; saveBtn.textContent = 'บันทึก •'; refreshPreview(); };
    const saveBtn = h('button',{class:'primary small libsave',onclick:async()=>{ if (await NpcLib.save(it)){ dirty = false; saveBtn.textContent = 'บันทึกแล้ว'; toast('บันทึกลงคลังแล้ว'); } },text:'บันทึก'});
    root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text: asset ? 'แก้ไข Asset' : 'แก้ไข NPC'}), h('p',{text: asset ? 'Asset คือสิ่งของประกอบฉากที่วางบนบอร์ดได้ เช่น หีบ ประตู กับดัก กองไฟ รูปปั้น มันกินพื้นที่หนึ่งช่อง ไม่เข้าลำดับเทิร์น ซ่อนไว้ก่อนแล้วเปิดเผยทีหลังได้' : 'NPC คือตัวละครที่ GM คุม ค่าที่ตั้งตรงนี้คือค่าเริ่มต้นตอนวางลงบอร์ด แก้ต่อบนโต๊ะได้ทุกค่า'})),
      h('div',{class:'row'}, saveBtn, h('button',{class:'small'+(it.published?' on':''),onclick:async()=>{ if (!libConfirmPublish(it)) return; it.published = !it.published; if (await NpcLib.save(it)){ dirty = false; toast(it.published ? 'เผยแพร่แล้ว' : 'ยกเลิกเผยแพร่แล้ว'); draw(); } },text: it.published ? 'ยกเลิกเผยแพร่' : 'เผยแพร่'}), h('button',{class:'small ghost',onclick:()=>{ if (dirty && !confirm('ยังไม่ได้บันทึก ออกเลยไหม?')) return; location.hash='#npcs'; },text:'← คลัง NPC / Asset'}))));
    const left = h('div'), right = h('div');
    let eqRefresh = ()=>{};
    const num = (key, min, max, w)=>h('input',{type:'number',min,max,value:+it[key]||0,style:`width:${w||72}px`,dataset:{f:key},oninput:(e)=>{ it[key] = Math.max(min, Math.min(max, Math.round(+e.target.value||0))); markDirty(); }});
    const chk = (key, label, title)=>h('label',{class:'fld chk',title:title||''}, h('input',{type:'checkbox',checked:!!it[key],dataset:{f:key},onchange:(e)=>{ it[key] = e.target.checked; markDirty(); }}), h('span',{text:label}));
    const name = h('input',{value:it.name||'',placeholder: asset ? 'ชื่อสิ่งของ เช่น หีบเหล็กสนิมเกาะ' : 'ชื่อ NPC เช่น โจรดักปล้นริมทาง',style:'min-width:260px;flex:1',dataset:{f:'name'},maxlength:80,oninput:(e)=>{ it.name = e.target.value; markDirty(); }});
    const form = h('div',{class:'card npcform',style:'margin-bottom:10px'});
    form.append(h('div',{class:'row'}, h('label',{class:'fld'}, h('span',{text:'ชื่อ'})), name));
    if (asset){
      const custom = h('input',{value: ASSET_ICONS.includes(it.icon) ? '' : (it.icon||''),placeholder:'หรือพิมพ์อีโมจิเอง',style:'width:150px',maxlength:4,dataset:{f:'icon'},oninput:(e)=>{ const v = e.target.value.trim(); if (v){ it.icon = v; markDirty(); for (const b of icons.querySelectorAll('button')) b.classList.remove('on'); } }});
      const icons = h('div',{class:'iconpick'}, ASSET_ICONS.map(ic=>h('button',{class:'small'+(it.icon===ic?' on':''),title:'ใช้อีโมจินี้เมื่อไม่มีทั้งภาพหมากและไอคอน',onclick:(e)=>{ it.icon = ic; custom.value = ''; for (const b of icons.querySelectorAll('button')) b.classList.toggle('on', b===e.currentTarget); markDirty(); },text:ic})));
      form.append(h('div',null, h('div',{class:'kicker',text:'อีโมจิ (ใช้เมื่อไม่มีทั้งภาพหมากและไอคอน)'}), icons, h('div',{style:'margin-top:6px'}, custom)));
      form.append(h('div',{class:'row'}, h('label',{class:'fld',title:'ใส่ 0 ถ้าไม่ต้องติดตามความทนทาน ใส่ตัวเลขถ้าของชิ้นนี้ถูกทำลายได้ เช่น ประตูไม้'}, h('span',{text:'HP (0 = ไม่ติดตาม)'}), num('hp', 0, 999)), chk('torch', '🔥 เป็นแหล่งแสง', 'ส่องรอบตัว 4 ช่องในที่มืด เช่น กองไฟ ตะเกียงเสา')));
    } else {
      form.append(h('div',{class:'row'}, h('label',{class:'fld'}, h('span',{text:'HP สูงสุด'}), num('hp', 1, 999)), h('label',{class:'fld',title:'บวกกับ 2d6 ตอนจัดลำดับเทิร์น'}, h('span',{text:'Initiative'}), num('init', -10, 20, 60)), h('label',{class:'fld',title:'Toughness สูงสุดของ NPC ใส่ 0 ถ้ายังไม่ใช้ แก้บนโต๊ะได้'}, h('span',{text:'Toughness (0 = ไม่ใช้)'}), num('tgh', 0, 99, 60))));
      // v1.25 (Non สั่ง 15 พ.ย. 2026): ค่าพลังดัดแปลง (Modified) แบบเดียวกับบล็อกสัตว์ในไฟล์ Fauna, Enemy & Companion: STR Mod ถึง INT Mod
      it.mods = it.mods || {};
      const derivedRow = h('div',{class:'gives npcderived',style:'margin-top:6px'}); const drawDerived = ()=>{ clear(derivedRow); derivedRow.append(h('span',{class:'dim',style:'font-size:11.5px;margin-right:4px',text:'ค่าพลังรอง:'}), ...npcDerivedTags(it.mods)); }; drawDerived();
      form.append(h('div',null, h('div',{class:'kicker',text:'ค่าพลังดัดแปลง (Modified)'}), h('div',{class:'row npcmods'}, STATS.map(st=>h('label',{class:'fld modfld sc-'+st,title:`${st} Mod ของ NPC บวกกับ 2d6 ตอน GM กดทอย ${st} Check บนโต๊ะ`}, h('span',{text:st+' Mod'}), h('input',{type:'number',min:-10,max:10,value:+it.mods[st]||0,style:'width:58px',dataset:{f:'mod-'+st},oninput:(e)=>{ const v = Math.max(-10, Math.min(10, Math.round(+e.target.value||0))); if (v) it.mods[st] = v; else delete it.mods[st]; drawDerived(); markDirty(); eqRefresh(); }})))),
        derivedRow,
        h('div',{class:'dim',style:'font-size:11.5px;margin-top:4px',text:'บนโต๊ะ GM กดชื่อค่าพลังที่แผงหมากเพื่อทอย 2d6 + Mod ในนาม NPC ตัวนั้น (หมากที่ซ่อนอยู่ทอยแบบลับ) ค่าพลังรองคิดด้วยสูตรเดียวกับตัวละครผู้เล่น'})));
      form.append(h('div',{class:'row'}, chk('nv', '👁 Dark Vision', 'มองเห็นในความมืด ไม่ติดตาบอดในที่มืด'), chk('aquatic', '🐟 สัตว์น้ำ', 'สัตว์น้ำหรือเงือก: อยู่ในน้ำลึกแล้วโจมตีได้และไม่เสียเทิร์น'), chk('torch', '🔥 ถือแหล่งแสง', 'ถือคบเพลิงหรือตะเกียง ส่องรอบตัว 4 ช่องในที่มืด')));
    }
    const desc = h('textarea',{placeholder: asset ? 'คำอธิบายที่ผู้เล่นเห็นเมื่อเปิดเผย (รูปร่าง สภาพ สิ่งที่สังเกตได้)' : 'คำอธิบายที่ผู้เล่นเห็นเมื่อเปิดเผย (รูปร่าง ท่าทาง สิ่งที่สังเกตได้)',style:'min-height:70px',dataset:{f:'desc'},maxlength:2000}); desc.value = it.desc||''; desc.oninput = ()=>{ it.desc = desc.value; markDirty(); };
    const note = h('textarea',{placeholder: asset ? 'บันทึกลับของ GM (ของข้างใน กลไกกับดัก DC ที่ใช้ เงื่อนไขการเปิด) ผู้เล่นไม่เห็น' : 'บันทึกลับของ GM (สแตต อาวุธ แผนการ จุดอ่อน) ผู้เล่นไม่เห็น',style:'min-height:90px',dataset:{f:'note'},maxlength:4000}); note.value = it.note||''; note.oninput = ()=>{ it.note = note.value; markDirty(); };
    form.append(h('div',null, h('div',{class:'kicker',text:'คำอธิบาย (ผู้เล่นเห็น)'}), desc), h('div',null, h('div',{class:'kicker',text:'บันทึก GM (ลับ)'}), note, h('div',{class:'dim',style:'font-size:11.5px;margin-top:4px',text:'บนโต๊ะมีแต่ GM ที่เห็นบันทึกนี้ ถ้ากดเผยแพร่ บันทึกจะติดไปกับสำเนาที่ GM คนอื่นเก็บ'})));
    left.append(form);
    if (!asset){ const eqBox = npcEquipBox(()=>it.equip, (v)=>{ const c = npcEquipClean(v); if (c) it.equip = c; else delete it.equip; markDirty(); }, ()=>it.mods); eqRefresh = ()=>eqBox.refresh();
      left.append(h('div',{class:'card npceqcard',style:'margin-bottom:10px'}, h('h3',{text:'อาวุธและชุดเกราะ'}), h('p',{class:'dim',style:'font-size:12px;margin:2px 0 8px',text:'เลือกจากคลังไอเทมหรือพิมพ์เอง ติดไปกับหมากตอนวางลงบอร์ด บนโต๊ะ GM เห็นความเสียหายของอาวุธ (PDMG + Might) Parry Dice และเกราะแต่ละส่วนที่แผงหมาก'}), eqBox)); } // v1.26
    // ไอคอนหมากจากคลังไอคอน (ติดไปกับการเผยแพร่ได้ เพราะเป็นไอคอนสัญญาอนุญาตเปิด ไม่ใช่ภาพของผู้ใช้)
    left.append(h('div',{class:'card libicocard',style:'margin-bottom:10px'}, h('h3',{text:'ไอคอนหมาก'}), h('div',{style:'margin-top:8px'}, icoEditorBox(()=>it.ico, (v)=>{ if (v) it.ico = v; else delete it.ico; markDirty(); }, { asset })),
      h('p',{class:'dim',style:'font-size:11.5px;margin:8px 0 0',text:'บนบอร์ดใช้ภาพหมากก่อน ถ้าไม่มีภาพใช้ไอคอนนี้ ถ้าไม่มีทั้งสองอย่างใช้' + (asset ? 'อีโมจิด้านบน' : 'อักษรย่อของชื่อ') + ' ไอคอนกับสีติดไปกับการเผยแพร่'}), iconCredit()));
    // ภาพหมาก (ของเจ้าของคลังเท่านั้น)
    const imgFile = h('input',{type:'file',accept:'image/png,image/jpeg,image/webp',class:'sr libimgfile'});
    imgFile.onchange = async (e)=>{ const f = e.target.files[0]; if (!f) return; if (imgUploadBlocked(f, e.target)) return; try { const res = await shrinkTokenImage(f, asset); if (await NpcLib.saveImage(it, res.data) && await NpcLib.save(it)){ dirty = false; toast(`ใส่ภาพหมากแล้ว (${Math.max(1, Math.round(res.bytes/1024))} KB)`); draw(); } } catch(err){ toast('ใส่ภาพไม่ได้: '+(err && err.message || err)); } };
    left.append(h('div',{class:'card'}, h('h3',{text:'ภาพหมาก'}), h('div',{class:'row',style:'gap:8px;margin-top:6px'}, h('button',{class:'small libimgbtn',onclick:()=>imgFile.click(),text: it.image ? 'เปลี่ยนภาพ' : 'ใส่ภาพ PNG หรือ JPG'}), imgFile,
        it.image ? h('button',{class:'small ghost',onclick:async()=>{ if (!confirm('ลบภาพหมากของรายการนี้?')) return; await NpcLib.deleteImage(it); await NpcLib.save(it); dirty = false; draw(); },text:'ลบภาพ'}) : null),
      h('p',{class:'dim',style:'font-size:11.5px;margin:6px 0 0',text: (imgUploadNote() ? imgUploadNote() + ' · ' : '') + (asset ? 'ระบบย่อภาพทั้งชิ้นให้พอดีกรอบสี่เหลี่ยม 160px ส่วนที่โปร่งใสยังโปร่งใส' : 'ระบบตัดภาพตรงกึ่งกลางเป็นสี่เหลี่ยม 160px แล้วแสดงเป็นวงกลมบนบอร์ด') + ' ภาพอยู่ในคลังของคุณคนเดียว ไม่ติดไปกับการเผยแพร่ แต่แสดงในห้องที่คุณวางหมากนี้'})));
    // ตัวอย่างหมาก + วิธีใช้
    const pv = h('div',{class:'card',style:'margin-bottom:10px'});
    const refreshPreview = ()=>{ clear(pv); pv.append(h('h3',{text:'ตัวอย่างบนบอร์ด'}), h('div',{class:'row',style:'gap:12px;margin-top:8px;align-items:center'}, libAvatar(it, 64), h('div',{style:'flex:1;min-width:0'}, h('b',{text:it.name||'(ไม่มีชื่อ)'}), libMeta(it)))); };
    refreshPreview();
    right.append(pv, h('div',{class:'card'}, h('h3',{text:'ใช้ในโต๊ะ'}), h('p',{class:'dim',style:'font-size:12.5px',text:'เปิดห้องที่คุณเป็น GM แล้วกด "📚 คลัง NPC / Asset" เหนือบอร์ด เลือกรายการ ตั้งจำนวน แล้วกดวาง หมากเข้าบอร์ดแบบซ่อนไว้ก่อนถ้าติ๊กไว้ ลากไปวางตำแหน่งที่ต้องการแล้วค่อยเปิดเผย · หมากบนโต๊ะเป็นสำเนา แก้ HP หรือบันทึกบนโต๊ะไม่กระทบรายการในคลัง · กด "💾 เก็บเข้าคลัง" ที่แผงหมากเพื่อเก็บหมากที่ปรับบนโต๊ะกลับเข้าคลัง'})));
    root.append(h('div',{class:'table-wrap'}, left, right));
  };
  NpcLib.subscribe(()=>{ if (location.hash==='#npcedit-'+id && !drawn) draw(); });
  draw();
}

/* ---- ใช้ในห้อง: วางจากคลังลงบอร์ด / เก็บหมากบนโต๊ะเข้าคลัง ---- */
function libToken(r, it, pos, thumb, hidden, name){
  const base = { id: uid(), name: name || it.name || (it.type==='asset' ? 'สิ่งของ' : 'ศัตรู'), x: pos.x, y: pos.y, san:0, sanMax:0, hidden: !!hidden, note: it.note||'', desc: it.desc||'', torch: !!it.torch, inWater: !!(TILE[mapCell(r.map, pos.x, pos.y)]||{}).swim, climb:false, libId: it.id };
  if (thumb) base.thumb = thumb;
  const ico = icoClean(it.ico); if (ico) base.ico = ico;
  if (it.type==='asset') return Object.assign(base, { kind:'asset', icon: libIcon(it.icon), hp: Math.max(0, +it.hp||0), hpMax: Math.max(0, +it.hp||0), init:0, nv:false, aquatic:false });
  const tk = Object.assign(base, { kind:'npc', hp: +it.hp||10, hpMax: +it.hp||10, init: +it.init||0, nv: !!it.nv, aquatic: !!it.aquatic });
  if (+it.tgh > 0){ tk.tgh = +it.tgh; tk.tghMax = +it.tgh; }
  const mods = npcModsClean(it.mods); if (mods) tk.mods = mods; // v1.25
  const eq = npcEquipClean(it.equip); if (eq) tk.equip = eq; // v1.26
  return tk;
}
async function placeFromLibrary(r, it, qty, hidden){
  const n = Math.max(1, Math.min(LIB_PLACE_MAX, Math.round(+qty||1)));
  const thumb = await NpcLib.tokenThumb(it);
  const rows = it.type==='asset' ? [8,9,10,11] : [0,1,2,3];
  for (let i=0;i<n;i++){ const pos = freeCell(r.map, r.tokens, rows); r.tokens.push(libToken(r, it, pos, thumb, hidden, n > 1 ? `${it.name||NpcLib.typeLabel(it.type)} ${i+1}` : null)); }
  Table.save();
  Table.post({kind:'sys',who:'GM',text:`วาง ${it.name||NpcLib.typeLabel(it.type)}${n>1 ? ' ×'+n : ''} จากคลังลงบอร์ด${hidden ? ' (ซ่อนไว้ก่อน)' : ''}`,gmOnly: !!hidden});
  return n;
}
function openNpcLibraryPicker(r){
  const list = h('div',{class:'giftlist liblist'}); const q = h('input',{placeholder:'ค้นหาในคลังของฉัน',style:'min-width:200px'});
  const qty = h('input',{type:'number',min:1,max:LIB_PLACE_MAX,value:1,style:'width:60px',title:`วางครั้งละไม่เกิน ${LIB_PLACE_MAX} ตัว`});
  const hid = h('input',{type:'checkbox',checked:NpcLib.pickHidden}); hid.onchange = ()=>{ NpcLib.pickHidden = hid.checked; };
  let type = 'all';
  const typeRow = h('div',{class:'row',style:'gap:4px'});
  const drawTypes = ()=>{ clear(typeRow); for (const [k,l] of [['all','ทั้งหมด'], ...LIB_TYPES]) typeRow.append(h('button',{class:'small'+(type===k?' on':''),dataset:{type:k},onclick:()=>{ type = k; drawTypes(); drawList(); },text:l})); };
  const drawList = ()=>{ clear(list); const k = q.value.trim().toLowerCase();
    const mine = NpcLib.mine.filter(m=>NpcLib.isMine(m)).filter(it=>(type==='all' || it.type===type) && libMatches(it, k)).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
    if (!NpcLib.loaded) list.append(h('div',{class:'dim',text:'กำลังโหลดคลัง…'}));
    else if (!mine.length) list.append(h('div',{class:'dim'}, (k || type!=='all') ? 'ไม่พบรายการที่ตรงกับตัวกรอง ' : 'คลังยังว่าง ', h('a',{href:'#npcs',onclick:()=>modal(null),text:'ไปสร้างหรือค้นหา NPC กับ Asset'})));
    for (const it of mine) list.append(h('div',{class:'gift',dataset:{id:it.id}}, h('div',{class:'row',style:'gap:10px;align-items:flex-start;flex-wrap:nowrap'}, libAvatar(it, 44), h('div',{style:'min-width:0'}, h('b',{text:it.name||'(ไม่มีชื่อ)'}), libMeta(it), it.desc ? h('div',{class:'dim',style:'font-size:12px',text:it.desc.slice(0,120)}) : null)),
      h('button',{class:'small primary libplace',onclick:async(e)=>{ const b = e.currentTarget; b.disabled = true; try { const n = await placeFromLibrary(r, it, qty.value, hid.checked); toast(`วาง ${it.name||''}${n>1 ? ' ×'+n : ''} ลงบอร์ดแล้ว${hid.checked ? ' (ซ่อนอยู่ ลากไปวางแล้วค่อยเปิดเผย)' : ''}`); } finally { b.disabled = false; } },text:'วางลงบอร์ด'}))); };
  q.oninput = drawList; drawTypes();
  modal(h('div',{class:'libpicker'}, h('h3',{text:'วาง NPC หรือ Asset จากคลัง'}), h('div',{class:'row',style:'margin:6px 0;gap:8px'}, q, typeRow, h('label',{class:'fld'}, h('span',{text:'จำนวน'}), qty), h('label',{class:'fld chk',title:'หมากเข้าบอร์ดแบบซ่อน ผู้เล่นยังไม่เห็นจนกว่าคุณจะกดเปิดเผยที่แผงหมาก'}, hid, h('span',{text:'ซ่อนไว้ก่อน'}))), list,
    h('p',{class:'dim',style:'font-size:12px;margin:8px 0 0',text:'NPC ลงแถวบนของบอร์ด Asset ลงกลางบอร์ด ลากไปวางตำแหน่งจริงได้ทันที หน้าต่างนี้เปิดค้างไว้เพื่อวางต่อได้'})));
  NpcLib.subscribe(()=>{ if ($('#modal') && !$('#modal').classList.contains('hidden') && $('#modal .liblist')) drawList(); });
  drawList();
}
async function saveTokenToLibrary(t){
  if (!t || t.charId) return;
  await NpcLib.ready();
  let it = t.libId ? NpcLib.mine.find(x=>x.id===t.libId && NpcLib.isMine(x)) : null;
  if (it && !confirm(`"${it.name}" อยู่ในคลังแล้ว\n\nกด OK เพื่ออัปเดตรายการเดิมด้วยค่าของหมากตัวนี้\nกด Cancel เพื่อเก็บเป็นรายการใหม่`)) it = null;
  const fresh = !it; if (fresh) it = NpcLib.newItem(t.kind==='asset' ? 'asset' : 'npc');
  if (fresh || String(t.name||'').replace(/\s+\d+$/, '') !== it.name) it.name = t.name || it.name; // หมากที่วางหลายตัวถูกเติมเลขท้ายชื่อ ตอนอัปเดตรายการเดิมไม่เอาเลขนั้นกลับเข้าคลัง
  it.desc = t.desc||''; it.note = t.note||''; it.torch = !!t.torch;
  if (it.type==='asset'){ it.icon = t.icon || it.icon || '📦'; it.hp = Math.max(0, +t.hpMax||0); }
  else { it.hp = +t.hpMax || +t.hp || 10; it.init = +t.init||0; it.tgh = +t.tghMax||0; it.nv = !!t.nv; it.aquatic = !!t.aquatic; const mods = npcModsClean(t.mods); if (mods) it.mods = mods; else delete it.mods; const eq = npcEquipClean(t.equip); if (eq) it.equip = eq; else delete it.equip; }
  { const ico = icoClean(t.ico); if (ico) it.ico = ico; else delete it.ico; }
  if (fresh && t.thumb) await NpcLib.saveImage(it, t.thumb);
  if (await NpcLib.save(it)){ t.libId = it.id; toast(fresh ? `เก็บ "${it.name}" เข้าคลัง NPC / Asset แล้ว` : `อัปเดต "${it.name}" ในคลังแล้ว`); }
}

/* ===== ไอคอนหมาก (v1.18 ผู้ใช้สั่ง 12 พ.ย. 2026): ไอคอน 4,085 แบบในไฟล์ ttrpg-icons.js ที่ผู้ใช้วางไว้ข้าง index.html เลือกใช้กับ NPC และ Asset ปรับสีไอคอนกับสีพื้นได้ =====
 * ที่มา: game-icons.net โดย Lorc, Delapouite และผู้ร่วมสร้าง สัญญาอนุญาต CC BY 3.0 (เส้นแปลงจาก PNG เป็นเวกเตอร์) เครดิตแสดงในหน้าต่างเลือกไอคอนและหน้านโยบาย
 * ไฟล์ใหญ่ราว 4.5 MB (บีบแล้วราว 1.8 MB) จึงไม่ฝังใน index.html: โหลดเมื่อเปิดหน้าต่างเลือกไอคอนเท่านั้น
 * รายการในคลังและหมากเก็บเส้นของไอคอนที่เลือกไว้กับตัว ico = {n ชื่อ, d เส้น (ตาราง 512), c สีไอคอน, b สีพื้น} ผู้เล่นในห้องจึงเห็นไอคอนโดยไม่ต้องโหลดไฟล์นี้
 * ลำดับที่ใช้บนบอร์ด: ภาพหมากที่อัปโหลด → ไอคอน → อีโมจิ (Asset) หรืออักษรย่อ (NPC) */
const ICON_FILE = 'ttrpg-icons.js';
const ICON_PAGE = 240; // จำนวนไอคอนที่วาดต่อครั้งในหน้าต่างเลือก
const ICO_FG = ['#f2e9d8','#ffffff','#d4a84a','#e0705f','#58b7ff','#5bb97a','#a371f7','#101418'];
const ICO_BG = ['#5a1414','#14283c','#1f3a26','#3a1f4a','#4a3b16','#1c2026','#e8dcc0','#7a1f1f'];
const ICO_DEFAULT = { npc: {c:'#f2e9d8', b:'#5a1414'}, asset: {c:'#d4a84a', b:'#1c2026'} };
const ICO_PATH_RX = /^[MmLlHhVvCcSsQqTtAaZz0-9 ,.\-]{10,9000}$/;
const ICO_COLOR_RX = /^#[0-9a-fA-F]{6}$/;
/* ไอคอนที่อ่านจากเอกสารหรือหมากถือเป็นข้อมูลที่ไม่น่าไว้ใจ: เส้นต้องเป็นอักขระของ SVG path เท่านั้น สีต้องเป็น #rrggbb */
function icoClean(x){ if (!x || typeof x !== 'object' || typeof x.d !== 'string' || !ICO_PATH_RX.test(x.d)) return null;
  return { n: (typeof x.n === 'string' && /^[a-z0-9-]{1,40}$/.test(x.n)) ? x.n : 'icon', d: x.d, c: ICO_COLOR_RX.test(x.c||'') ? x.c.toLowerCase() : ICO_DEFAULT.npc.c, b: ICO_COLOR_RX.test(x.b||'') ? x.b.toLowerCase() : ICO_DEFAULT.asset.b }; }
function icoSvg(ico, cls){ return svg('svg',{viewBox:'0 0 512 512', class:'ico'+(cls ? ' '+cls : ''), 'aria-hidden':'true', focusable:'false'}, svg('path',{d: ico.d, fill: ico.c})); }
const IconLib = { data: null, p: null,
  /* โหลดไฟล์ไอคอนครั้งเดียว (แท็ก script ใช้ได้ทั้งบนเว็บและตอนเปิดไฟล์ในเครื่อง) · ตรวจรูปข้อมูลก่อนใช้ */
  load(){
    const take = ()=>{ const d = window.FED_ICONS; if (d && Array.isArray(d.list) && Array.isArray(d.cats)){ this.data = { cats: d.cats.map(c=>[String(c[0]), String(c[1])]), list: d.list.filter(x=>Array.isArray(x) && /^[a-z0-9-]{1,40}$/.test(String(x[0])) && typeof x[1] === 'string' && ICO_PATH_RX.test(x[1])).map(x=>({n:x[0], d:x[1], k:+x[2]||0})), credit: String(d.credit||'') }; return true; } return false; };
    if (this.data) return Promise.resolve(this.data);
    if (take()) return Promise.resolve(this.data);
    if (this.p) return this.p;
    this.p = new Promise((res, rej)=>{ const el = document.createElement('script'); el.src = ICON_FILE; el.async = true;
      el.onload = ()=>{ if (take()) res(this.data); else { this.p = null; el.remove(); rej(new Error('ไฟล์ไอคอนไม่มีข้อมูลที่อ่านได้')); } };
      el.onerror = ()=>{ this.p = null; el.remove(); rej(new Error('โหลดไฟล์ไอคอนไม่ได้')); };
      document.head.append(el); });
    return this.p;
  },
  find(name){ return this.data ? this.data.list.find(x=>x.n===name) || null : null; },
};
function iconCredit(){ return h('p',{class:'dim icocredit',style:'font-size:11.5px;margin:8px 0 0'}, 'ไอคอนจาก ', h('a',{href:'https://game-icons.net',target:'_blank',rel:'noopener noreferrer',text:'game-icons.net'}), ' โดย Lorc, Delapouite และผู้ร่วมสร้าง สัญญาอนุญาต ', h('a',{href:'https://creativecommons.org/licenses/by/3.0/',target:'_blank',rel:'noopener noreferrer',text:'CC BY 3.0'}), ' เส้นแปลงจากภาพ PNG เป็นเวกเตอร์ และปรับสีได้ในเว็บนี้'); }
/* หน้าต่างเลือกไอคอน: หมวด 25 หมวด + ค้นหาด้วยชื่ออังกฤษ (คำค้นหาค้นจากทุกหมวดเสมอ) · onPick({n, d}) · onBack() กลับไปหน้าต่างก่อนหน้า
   หมวดเริ่มต้นตามชนิด: NPC เปิดที่ "คนและร่างกาย" Asset เปิดที่ "สิ่งของเครื่องใช้" แล้วจำหมวดที่เลือกล่าสุดของชนิดนั้นไว้ตลอดการเปิดเว็บ */
const IconPick = { cats: { npc: null, asset: null }, q: '', kind: 'npc', get cat(){ return this.cats[this.kind]; }, set cat(v){ this.cats[this.kind] = v; } };
function openIconPicker(onPick, onBack, kind){
  IconPick.kind = kind==='asset' ? 'asset' : 'npc';
  const box = h('div',{class:'icopicker'}); let shown = ICON_PAGE;
  const head = h('div',null, h('h3',{text:'เลือกไอคอนหมาก'}));
  const grid = h('div',{class:'icogrid'}); const foot = h('div');
  box.append(head, grid, foot);
  const drawGrid = (L)=>{ clear(grid); clear(foot);
    const k = IconPick.q.trim().toLowerCase().replace(/\s+/g, '-');
    const hits = k ? L.list.filter(x=>x.n.includes(k)) : L.list.filter(x=>IconPick.cat < 0 || x.k === IconPick.cat);
    if (!hits.length) grid.append(h('div',{class:'dim',style:'grid-column:1/-1;padding:10px',text:'ไม่พบไอคอนที่ตรงกับคำค้น ชื่อไอคอนเป็นภาษาอังกฤษ ลองคำสั้น ๆ เช่น wolf, skull, chest, door'}));
    for (const x of hits.slice(0, shown)) grid.append(h('button',{class:'icocell',title:x.n,dataset:{n:x.n},onclick:()=>{ modal(null); onPick({n:x.n, d:x.d}); }}, icoSvg({d:x.d, c:'currentColor'}), h('span',{text:x.n})));
    foot.append(h('div',{class:'row',style:'margin-top:8px;justify-content:space-between'}, h('span',{class:'dim iconcount',style:'font-size:12px',text:`แสดง ${Math.min(shown, hits.length)} จาก ${hits.length} แบบ` + (k ? ' (ค้นจากทุกหมวด)' : '')}), hits.length > shown ? h('button',{class:'small icomore',onclick:()=>{ shown += ICON_PAGE; drawGrid(L); },text:`แสดงเพิ่มอีก ${Math.min(ICON_PAGE, hits.length - shown)}`}) : null), iconCredit());
  };
  const ready = (L)=>{ clear(head);
    if (IconPick.cat == null){ const i = L.cats.findIndex(c=>c[0]===(IconPick.kind==='asset' ? 'object' : 'people')); IconPick.cat = i; }
    const counts = L.cats.map((c, i)=>L.list.filter(x=>x.k===i).length);
    const sel = h('select',{class:'icocat'}, h('option',{value:-1,selected:IconPick.cat===-1,text:`ทุกหมวด (${L.list.length})`}), L.cats.map((c, i)=>h('option',{value:i,selected:IconPick.cat===i,text:`${c[1]} (${counts[i]})`}))); sel.onchange = ()=>{ IconPick.cat = +sel.value; shown = ICON_PAGE; drawGrid(L); };
    const q = h('input',{class:'icoq',placeholder:'ค้นหาชื่ออังกฤษ เช่น wolf, sword, chest',style:'min-width:220px;flex:1',value:IconPick.q}); q.oninput = ()=>{ IconPick.q = q.value; shown = ICON_PAGE; drawGrid(L); };
    head.append(h('h3',{text:'เลือกไอคอนหมาก'}), h('div',{class:'row',style:'margin:6px 0 8px;gap:8px'}, sel, q, onBack ? h('button',{class:'small ghost',onclick:()=>{ modal(null); onBack(); },text:'← กลับ'}) : null));
    drawGrid(L); };
  const start = ()=>{ clear(grid); clear(foot); grid.append(h('div',{class:'dim icoload',style:'grid-column:1/-1;padding:14px',text:'กำลังโหลดคลังไอคอน (ราว 1.8 MB โหลดครั้งเดียวต่อการเปิดเว็บ)…'}));
    IconLib.load().then(ready).catch(e=>{ clear(grid); grid.append(h('div',{class:'warnbox icoerr',style:'grid-column:1/-1'}, (e && e.message || 'โหลดไฟล์ไอคอนไม่ได้') + ' ตรวจว่าไฟล์ ' + ICON_FILE + ' อยู่ข้าง index.html แล้วลองใหม่ ', h('button',{class:'small',onclick:start,text:'ลองใหม่'}))); }); };
  modal(box); start();
}
/* กล่องตั้งค่าไอคอนของรายการหรือหมาก: ตัวอย่าง + เลือก/เปลี่ยน/เอาออก + สีไอคอน + สีพื้น · get() คืน ico ปัจจุบัน set(ico|null) เก็บค่า · opts.reopen ใช้เมื่อกล่องนี้อยู่ในหน้าต่างลอย */
function icoEditorBox(get, set, opts){
  opts = opts || {}; const def = ICO_DEFAULT[opts.asset ? 'asset' : 'npc'];
  const box = h('div',{class:'icoedit'});
  const draw = ()=>{ clear(box); const ico = icoClean(get());
    const pv = h('div',{class:'icopv'+(opts.asset ? ' asset' : ''),style: ico ? `background:${ico.b}` : ''}); if (ico) pv.append(icoSvg(ico)); else pv.append(h('span',{class:'dim',style:'font-size:11px',text:'ยังไม่เลือก'}));
    const pick = ()=>openIconPicker((ic)=>{ const cur = icoClean(get()); set({n:ic.n, d:ic.d, c: cur ? cur.c : def.c, b: cur ? cur.b : def.b}); if (opts.reopen) opts.reopen(); else draw(); }, opts.reopen || null, opts.asset ? 'asset' : 'npc');
    box.append(h('div',{class:'row',style:'gap:10px;align-items:center'}, pv, h('div',{style:'flex:1;min-width:0'}, h('div',{class:'row',style:'gap:6px'}, h('button',{class:'small primary icopick',onclick:pick,text: ico ? 'เปลี่ยนไอคอน' : 'เลือกไอคอน'}), ico ? h('button',{class:'small ghost icoclear',onclick:()=>{ set(null); draw(); },text:'เอาไอคอนออก'}) : null), ico ? h('div',{class:'dim iconame',style:'font-size:12px;margin-top:4px',text:ico.n}) : h('div',{class:'dim',style:'font-size:12px;margin-top:4px',text:'ไอคอน 4,085 แบบ แบ่ง 25 หมวด ปรับสีไอคอนและสีพื้นได้'}))));
    if (ico){
      const colorRow = (label, key, presets)=>{ const inp = h('input',{type:'color',value:ico[key],class:'icocolor',dataset:{k:key},title:label});
        const apply = (v, redraw)=>{ if (!ICO_COLOR_RX.test(v)) return; ico[key] = v.toLowerCase(); set({n:ico.n, d:ico.d, c:ico.c, b:ico.b}); if (redraw) draw(); else { if (key==='c') pv.querySelector('path').setAttribute('fill', ico.c); else pv.style.background = ico.b; } };
        inp.oninput = ()=>apply(inp.value, false); inp.onchange = ()=>apply(inp.value, true);
        return h('div',{class:'row icorow',style:'gap:6px;margin-top:8px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px;min-width:56px',text:label}), inp, presets.map(c=>h('button',{class:'icosw'+(ico[key]===c ? ' on' : ''),style:`background:${c}`,title:c,dataset:{c},onclick:()=>apply(c, true)}))); };
      box.append(colorRow('สีไอคอน', 'c', ICO_FG), colorRow('สีพื้น', 'b', ICO_BG));
    }
  };
  draw(); return box;
}
/* หน้าต่างไอคอนของหมากบนโต๊ะ (GM): เลือก เปลี่ยน ปรับสี หรือเอาออก */
function tokenIconModal(t){
  if (!t) return;
  const body = h('div',{class:'tokico'}, h('h3',{text:'ไอคอนของ ' + (t.name || 'หมาก')}),
    icoEditorBox(()=>t.ico, (v)=>{ if (v) t.ico = v; else delete t.ico; Table.save(); }, { asset: t.kind==='asset', reopen: ()=>tokenIconModal(t) }),
    t.thumb ? h('p',{class:'dim',style:'font-size:12px;margin:8px 0 0',text:'หมากนี้มีภาพอยู่ ภาพจะแสดงแทนไอคอน'}) : null, iconCredit());
  modal(body);
}

/* ===== v1.26 (ร่าง ยังไม่ขึ้นเว็บ · Non สั่ง 15 พ.ย. 2026): อาวุธและชุดเกราะของ NPC =====
 * it.equip (คลัง) และ t.equip (หมากบนโต๊ะ) = [{name, effect, slot, weight?}] ไม่เกิน NPC_EQ_MAX ชิ้น
 * เลือกจากคลังไอเทม (Item All และชุดเริ่มต้น) หรือพิมพ์เอง ระบบเดาช่องจากชนิดของไอเทม เปลี่ยนช่องเองได้
 * ติดไปกับหมากตอนวางจากคลัง และกลับเข้าคลังตอนกด "เก็บเข้าคลัง" ที่แผงหมาก (หลักเดียวกับค่าพลังดัดแปลง)
 * เกราะต่อส่วนคิดด้วยกฎเดียวกับชีทผู้เล่น (armorText: หลายชั้นรวม A · เกราะรองแยกตามชนิด · เข็มขัดไม่ทบกับเกราะลำตัว)
 * Parry Dice นับโบนัสที่ไม่มีเงื่อนไข และบัคเลอร์เมื่อถืออาวุธอยู่ด้วย · ความเสียหายอาวุธ = PDMG + Might จากค่าพลังดัดแปลง */
const NPC_EQ_MAX = 16;
const NPC_EQ_SLOTS = [['weapon','อาวุธ'],['shield','โล่ / มือรอง'],['head','ศีรษะ'],['chestIn','ลำตัว ชั้นใน'],['chestOut','ลำตัว ชั้นนอก'],['shirt','เสื้อ'],['hands','มือและข้อมือ'],['waist','เอว'],['legs','ขา'],['feet','เท้า'],['cape','ผ้าคลุม'],['neck','คอ'],['back','หลัง'],['other','พกติดตัว']];
const NPC_EQ_CATS = ['อาวุธประชิด','อาวุธระยะไกล','อาวุธเทคโนโลยี','อาวุธเวทมนตร์','โล่','หมวกเกราะ','เกราะลำตัว','เกราะส่วนย่อย','เสื้อผ้าและหมวก','แหวน','ไอเทมเวทมนตร์','อุปกรณ์พิเศษ','กระสุน'];
function npcEquipClean(list){ if (!Array.isArray(list)) return null; const keys = NPC_EQ_SLOTS.map(x=>x[0]); const out = [];
  for (const e of list){ if (out.length >= NPC_EQ_MAX) break; if (!e || typeof e !== 'object') continue; const name = libStr(e.name, 80).trim(); if (!name) continue;
    const o = {name, effect: libStr(e.effect, 1200), slot: keys.includes(e.slot) ? e.slot : 'other'}; const w = +e.weight; if (Number.isFinite(w) && w > 0) o.weight = Math.min(999, Math.round(w * 100) / 100); out.push(o); }
  return out.length ? out : null; }
function npcSlotName(k){ const x = NPC_EQ_SLOTS.find(s=>s[0]===k); return x ? x[1] : k; }
/* เดาช่องจากหมวดและหัวข้อย่อยของ Item All ก่อน แล้วค่อยใช้กฎเดียวกับปุ่มสวมอัตโนมัติในชีท (itemSlot) */
function npcSlotGuess(it){ const name = String(it && it.name || ''), cat = it && it.cat || '', sub = it && it.sub || '', eff = String(it && it.effect || ''), slot = String(it && it.slot || '');
  if (/โล่|Shield/i.test(name)) return 'shield';
  if (/^อาวุธ/.test(cat)) return 'weapon';
  if (cat==='กระสุน') return 'other';
  if (cat==='หมวกเกราะ') return 'head';
  if (cat==='เกราะลำตัว') return /ชั้นใน|Inner/i.test(slot + ' ' + eff) ? 'chestIn' : 'chestOut';
  if (cat==='เกราะส่วนย่อย'){ if (/Wrist|แขน|Hand|มือ/i.test(sub)) return 'hands'; if (/Waist|เอว/i.test(sub)) return 'waist'; if (/Feet|เท้า/i.test(sub)) return 'feet'; if (/Cape/i.test(sub)) return 'cape'; }
  const s2 = slot + ' ' + eff; if (/Feet Slot/i.test(s2)) return 'feet'; if (/(Hand|Wrist)s? Slot/i.test(s2)) return 'hands'; if (/Waist Slot/i.test(s2)) return 'waist'; if (/Cape Slot/i.test(s2)) return 'cape'; if (/Face Slot/i.test(s2)) return 'head';
  const g = itemSlot(name, eff); if (g && NPC_EQ_SLOTS.some(x=>x[0]===g)) return g;
  return 'other'; }
function npcArmor(list){ const parts = {}; for (const [k] of DATA.meta.bodyParts) parts[k] = {layers:[], belt:0};
  for (const e of list||[]){ if (!e || !e.effect) continue; const ar = parseArmor(e.effect); if (!ar) continue;
    for (const pk of ARMOR_SLOT_PARTS[e.slot]||[]){ if (e.slot==='waist') parts[pk].belt = Math.max(parts[pk].belt, ar.a); else parts[pk].layers.push(ar); } }
  const out = {}; for (const [k, v] of Object.entries(parts)) out[k] = armorText(v.layers, v.belt); return out; }
function npcParryDice(list){ const l = list||[]; let n = l.reduce((a, e)=>a + unconditionalParry(e && e.effect), 0);
  if (l.some(e=>e.slot==='shield' && /Buckler|บัคเลอร์/i.test(e.name) && !unconditionalParry(e.effect)) && l.some(e=>e.slot==='weapon')) n += 1; // บัคเลอร์: เมื่อใช้คู่กับอาวุธมือเดียว +1
  return n; }
function npcEquipShort(list){ const l = list||[]; const w = l.filter(e=>e.slot==='weapon').length; return w ? `⚔ อาวุธ ${w}` + (l.length > w ? ` · สวมใส่ ${l.length - w}` : '') : `🛡 สวมใส่ ${l.length}`; }
/* สรุปค่าที่ใช้บนโต๊ะ: ความเสียหายของอาวุธ Parry Dice และเกราะต่อส่วนพร้อมยอดที่หักจริง */
function npcEquipSummary(list, mods){ const l = list||[]; if (!l.length) return null; const d = npcDerived(mods); const armor = npcArmor(l); const pd = npcParryDice(l);
  const box = h('div',{class:'npceq-sum'}, h('div',{class:'kicker',text:'ค่าที่ใช้บนโต๊ะ'}));
  for (const e of l.filter(x=>x.slot==='weapon' || x.slot==='shield')){ const dmg = itemPdmg(e.effect); const od = dmg == null ? itemOtherDmg(e.effect) : ''; if (dmg == null && !od) continue; const need = weaponStrNeed(e.effect);
    box.append(h('div',{class:'npceq-w'}, h('b',{class:hueCls(e.name, e.effect).trim(),text:itemNameSplit(e.name)[0]}),
      dmg != null ? h('span',{class:'num',text:` ${dmg} PDMG + Might ${signed(d.might)} = ${dmg + d.might}`}) : h('span',{class:'num',text:' ' + od}), need ? h('span',{class:'dim',style:'font-size:11.5px',text:` · ต้องมี STR ${need}`}) : null)); }
  box.append(h('div',{class:'gives'}, tag(`Parry Dice ${pd}`,'stat sc sc-VIT'), tag(`Might ${signed(d.might)}`,'stat sc sc-STR')));
  const rows = DATA.meta.bodyParts.filter(([k])=>armor[k]);
  box.append(rows.length ? h('table',{class:'t npceq-armor'}, h('thead',null, h('tr',null, h('th',{text:'ส่วนที่โดน'}), h('th',{text:'เกราะ A/B'}))), rows.map(([k, label])=>h('tr',null, h('td',null, label, h('span',{class:'dim',style:'font-size:10.5px',text:' ' + (HIT_ATTACK[k]||[]).join(',')})), h('td',{class:'num'}, armor[k], armorHitEl(armor[k])))))
    : h('div',{class:'dim',style:'font-size:12px',text:'ยังไม่มีชิ้นไหนกันส่วนที่โดน'}));
  return box; }
function npcEquipRow(e, i, list, commit){
  const sel = h('select',{class:'npceq-slot',title:'ช่องที่สวมหรือถือ ใช้คิดเกราะของแต่ละส่วน',onchange:(ev)=>{ const nl = list.slice(); nl[i] = Object.assign({}, e, {slot: ev.target.value}); commit(nl); }}, NPC_EQ_SLOTS.map(([k, l])=>h('option',{value:k, selected: e.slot===k, text:l})));
  const dmg = itemPdmg(e.effect), ar = itemArmor(e.effect), pd = unconditionalParry(e.effect);
  return h('div',{class:'npceq-row',dataset:{slot:e.slot}}, sel,
    h('div',{class:'npceq-main'}, h('b',{class:hueCls(e.name, e.effect).trim(),text:itemNameSplit(e.name)[0]}), ' ', dmg != null ? tag(dmg+' PDMG','neg') : null, ' ', ar ? tag('Armor '+ar.txt,'stat') : null, ' ', pd ? tag('+'+pd+' Parry Dice','stat') : null,
      e.effect ? h('details',null, h('summary',{text:'คุณสมบัติ'}), h('div',{class:'desc',style:'font-size:12px'}, T(e.effect))) : null),
    h('button',{class:'small ghost npceq-del',title:'เอาออก',onclick:()=>{ const nl = list.slice(); nl.splice(i, 1); commit(nl); },text:'✕'})); }
/* กล่องจัดการอาวุธและชุดเกราะ: get() รายการปัจจุบัน · set(list) บันทึก · mods() ค่าพลังดัดแปลง · opts.back กลับมาที่หน้าต่างเดิมหลังเลือกจากคลัง (ใช้บนโต๊ะ) */
function npcEquipBox(get, set, mods, opts){ opts = opts || {};
  const box = h('div',{class:'npceq'}); let custom = false;
  const commit = (nl)=>{ set(nl); draw(); };
  const draw = ()=>{ clear(box); const list = get() || [];
    box.append(list.length ? h('div',{class:'npceq-list'}, list.map((e, i)=>npcEquipRow(e, i, list, commit))) : h('p',{class:'dim',style:'font-size:12.5px;margin:4px 0',text:'ยังไม่มีอาวุธหรือชุดเกราะ กด "+ เลือกจากคลังไอเทม" หรือพิมพ์เอง'}));
    box.append(h('div',{class:'row',style:'gap:6px;margin-top:8px'},
      h('button',{class:'small primary npceq-add',onclick:()=>npcEquipPicker((it)=>{ const cur = get() || []; if (cur.length >= NPC_EQ_MAX){ toast(`ใส่ได้ไม่เกิน ${NPC_EQ_MAX} ชิ้นต่อ NPC`); return false; } set([...cur, {name: it.name, effect: it.effect || '', slot: npcSlotGuess(it), weight: +it.weight || 0}]); if (!opts.back) draw(); return true; }, opts.back),text:'+ เลือกจากคลังไอเทม'}),
      h('button',{class:'small ghost npceq-custombtn'+(custom ? ' on' : ''),onclick:()=>{ custom = !custom; draw(); },text:'+ พิมพ์เอง'})));
    if (custom){ const nm = h('input',{placeholder:'ชื่อ เช่น ดาบสนิมเขรอะ',maxlength:80,style:'min-width:170px;flex:1'}); const ef = h('input',{placeholder:'คุณสมบัติ เช่น 2 PDMG (Slashing) หรือ Armor 1/1 (Blunt)',maxlength:300,style:'min-width:220px;flex:2'});
      const sl = h('select',null, NPC_EQ_SLOTS.map(([k, l])=>h('option',{value:k,text:l})));
      box.append(h('div',{class:'npceq-custom'}, sl, nm, ef, h('button',{class:'small primary',onclick:()=>{ const name = nm.value.trim(); if (!name){ toast('ใส่ชื่อก่อน'); return; } const cur = get() || []; if (cur.length >= NPC_EQ_MAX){ toast(`ใส่ได้ไม่เกิน ${NPC_EQ_MAX} ชิ้นต่อ NPC`); return; } custom = false; commit([...cur, {name, effect: ef.value.trim(), slot: sl.value}]); },text:'ใส่'}))); }
    const sum = npcEquipSummary(list, mods ? mods() : null); if (sum) box.append(sum);
  };
  box.refresh = draw; draw(); return box; }
/* หน้าต่างเลือกจากคลังไอเทม (เปิดค้างไว้ใส่ต่อได้) */
function npcEquipPicker(onPick, back){
  const cat = itemCatalog().filter(it=>NPC_EQ_CATS.includes(it.cat) || (it.cat==='ชุดเริ่มต้น' && npcSlotGuess(it) !== 'other'));
  const q = h('input',{type:'search',placeholder:'ค้นหาอาวุธหรือชุดเกราะ',style:'min-width:220px;flex:1'}); const list = h('div',{class:'giftlist npceq-picklist'});
  const cats = [...new Set(cat.map(i=>i.cat))];
  const catSel = h('select',null, h('option',{value:'',text:`ทุกหมวด (${cat.length})`}), cats.map(k=>h('option',{value:k,text:`${k} (${cat.filter(i=>i.cat===k).length})`})));
  const note = h('div',{class:'dim npceq-added',style:'font-size:12px;min-height:18px'});
  const draw = ()=>{ clear(list); const k = q.value.trim().toLowerCase(); const ck = catSel.value;
    const all = cat.filter(it=>(!ck || it.cat===ck) && (!k || (it.name + ' ' + it.effect + ' ' + it.desc).toLowerCase().includes(k))); const hits = all.slice(0, 60);
    if (!hits.length) list.append(h('div',{class:'dim',text:'ไม่พบ ลองคำค้นอื่น หรือปิดหน้าต่างนี้แล้วใช้ปุ่ม "+ พิมพ์เอง"'}));
    for (const it of hits){ const tr = itemTier(it);
      list.append(h('div',{class:'gift'}, h('div',null, h('b',{text:it.name}), h('span',{class:'dim',style:'font-size:11px',text:` · ${npcSlotName(npcSlotGuess(it))}${tr ? ' · ' + itemTierShort(tr) : ''} · ${it.sub || it.cat}`}), h('div',{class:'desc',style:'font-size:12px'}, T(it.effect))),
        h('button',{class:'small primary',onclick:()=>{ if (onPick(it) !== false){ note.textContent = `ใส่ ${itemNameSplit(it.name)[0]} แล้ว เลือกต่อได้เลย`; toast(`ใส่ ${itemNameSplit(it.name)[0]} แล้ว`); } },text:'ใส่'}))); }
    if (all.length > hits.length) list.append(h('div',{class:'dim',style:'font-size:12px',text:`แสดง ${hits.length} จาก ${all.length} พิมพ์ค้นหาเพิ่มเพื่อกรอง`})); };
  q.oninput = draw; catSel.onchange = draw; draw();
  modal(h('div',{class:'npceqpick'}, h('h3',{text:'ใส่อาวุธหรือชุดเกราะให้ NPC'}),
    h('p',{class:'dim',style:'font-size:12.5px;margin:2px 0 6px',text:'รายการจาก Item All และชุดเริ่มต้น ระบบเดาช่องให้จากชนิดของไอเทม เปลี่ยนช่องได้ในรายการหลังใส่ หน้าต่างนี้เปิดค้างไว้ให้ใส่ต่อได้'}),
    back ? h('button',{class:'small',style:'margin-bottom:6px',onclick:back,text:'← กลับไปที่รายการของ NPC'}) : null,
    h('div',{class:'row',style:'margin-top:4px'}, q, catSel), note, list));
  setTimeout(()=>q.focus(), 50); }
/* บนโต๊ะ: แผงหมาก NPC (GM เห็นคนเดียว) และหน้าต่างแก้ของหมากตัวนั้น */
function npcTokenEquipSection(t){ const list = t.equip || [];
  const sec = h('div',{class:'cp-sec npceq-tok'}, h('div',{class:'row',style:'gap:6px;align-items:center'}, h('b',{text:'⚔ อาวุธและชุดเกราะ'}), list.length ? h('span',{class:'dim',style:'font-size:12px',text:npcEquipShort(list)}) : null,
    h('button',{class:'small ghost npceq-edit',style:'margin-left:auto',title:'เพิ่ม เอาออก หรือเปลี่ยนช่องของอาวุธและชุดเกราะของหมากนี้ · กด 💾 เก็บเข้าคลัง ถ้าอยากให้รายการในคลังเปลี่ยนตาม',onclick:()=>npcTokenEquipModal(t),text:'✎ แก้'})));
  if (!list.length){ sec.append(h('div',{class:'dim',style:'font-size:12px',text:'ยังไม่ได้ใส่ กด ✎ แก้ แล้วเลือกจากคลังไอเทม'})); return sec; }
  const sum = npcEquipSummary(list, t.mods); if (sum) sec.append(sum);
  return sec; }
function npcTokenEquipModal(t){
  const reopen = ()=>npcTokenEquipModal(t);
  const box = npcEquipBox(()=>t.equip, (v)=>{ const c = npcEquipClean(v); if (c) t.equip = c; else delete t.equip; Table.save(); }, ()=>t.mods, {back: reopen});
  modal(h('div',{class:'npceqmodal'}, h('h3',{text:`อาวุธและชุดเกราะของ ${t.name}`}), h('p',{class:'dim',style:'font-size:12px;margin:2px 0 8px',text:'แก้เฉพาะหมากตัวนี้บนโต๊ะ ผู้เล่นไม่เห็นรายการนี้ · กด 💾 เก็บเข้าคลัง ที่แผงหมากถ้าอยากให้รายการในคลังเปลี่ยนตาม'}), box)); }
