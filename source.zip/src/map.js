/* ===== แผนที่ต่อสู้แบบตาราง 20×20 + ตัวสุ่มแผนที่ตามสถานที่ =====
 * ช่องหนึ่งตัวอักษร: . พื้น  , หญ้าสูง(กำบัง)  T ต้นไม้(ขวาง)  W น้ำลึก(ผ่านไม่ได้)  w น้ำตื้น(ช้า)  R หิน/ผนัง(ขวาง)  r เศษหิน(ช้า)
 *   = ถนน  F พื้นอาคาร  # กำแพง  D ประตู  S ทราย  s หิมะ(ช้า)  B สะพาน/ไม้กระดาน  H บ้าน(ขวาง)  M โคลน(ช้า)  C ขอบหน้าผา(ขวาง)  P เสา(ขวาง)  L ลาวา(อันตราย)  ~ เหว(ผ่านไม่ได้)  G หลุมศพ(กำบัง)  A แท่นบูชา  X กองไฟ/ค่าย
 */
const MAP_W = 20, MAP_H = 20, CELL_M = 2; // 1 ช่อง = 2 เมตร
const TILE = {
  '.': {th:'พื้น', pass:1},        ',': {th:'หญ้าสูง (กำบัง)', pass:1, cover:1},
  'T': {th:'ต้นไม้', pass:0, opaque:1, climb:1},      'W': {th:'น้ำลึก (ว่าย)', pass:3, swim:1},        'w': {th:'น้ำตื้น (ช้า)', pass:2},
  'R': {th:'หิน/ผนัง', pass:0, opaque:1},    'r': {th:'เศษหิน (ช้า)', pass:2},   '=': {th:'ถนน', pass:1},
  'F': {th:'พื้นอาคาร', pass:1},   '#': {th:'กำแพง', pass:0, opaque:1},         'D': {th:'ประตู', pass:1},
  'S': {th:'ทราย', pass:1},        's': {th:'หิมะ (ช้า)', pass:2},     'B': {th:'สะพาน', pass:1},
  'H': {th:'บ้าน', pass:0, opaque:1},        'M': {th:'โคลน (ช้า)', pass:2},     'C': {th:'ขอบหน้าผา', pass:0, cling:1},
  'P': {th:'เสา', pass:0, opaque:1, climb:1}, 'L': {th:'ลาวา (อันตราย)', pass:2, danger:1}, '~': {th:'เหว', pass:0, cling:1},
  'G': {th:'หลุมศพ (กำบัง)', pass:1, cover:1}, 'A': {th:'แท่นบูชา', pass:1}, 'X': {th:'กองไฟ', pass:0},
};
const MAP_KINDS = [
  ['forest','ป่า'],['river','ริมแม่น้ำ'],['city','เมือง'],['village','หมู่บ้าน'],['cave','ถ้ำ'],['dungeon','ดันเจี้ยน'],['mountain','ภูเขา'],
  ['sea','ทะเล/ชายฝั่ง'],['ship','บนเรือ'],['valley','หุบเขา'],['cliff','หน้าผา'],['swamp','บึง'],['desert','ทะเลทราย'],['ruins','ซากปรักหักพัง'],
  ['snow','ทุ่งหิมะ'],['camp','ค่ายพัก'],['temple','วิหาร'],['mine','เหมือง'],['farm','ไร่นา'],['bridge','สะพานข้ามเหว'],['graveyard','สุสาน'],['volcano','ภูเขาไฟ'],['island','เกาะ'],['field','ทุ่งโล่ง'],
];
function mulberry32(a){ return function(){ a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function seedFrom(s){ let h = 2166136261; for (const ch of String(s)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
/* value noise ขนาดกริด: คืนค่า 0..1 */
function noiseGrid(rnd, scale){
  const gw = Math.ceil(MAP_W/scale)+2, gh = Math.ceil(MAP_H/scale)+2;
  const g = Array.from({length:gh}, ()=>Array.from({length:gw}, ()=>rnd()));
  const out = [];
  for (let y=0;y<MAP_H;y++){ const row=[]; for (let x=0;x<MAP_W;x++){ const fx=x/scale, fy=y/scale; const x0=Math.floor(fx), y0=Math.floor(fy); const tx=fx-x0, ty=fy-y0; const sx=tx*tx*(3-2*tx), sy=ty*ty*(3-2*ty); const v = (g[y0][x0]*(1-sx)+g[y0][x0+1]*sx)*(1-sy) + (g[y0+1][x0]*(1-sx)+g[y0+1][x0+1]*sx)*sy; row.push(v); } out.push(row); }
  return out;
}
function blank(ch='.'){ return Array.from({length:MAP_H}, ()=>Array(MAP_W).fill(ch)); }
function inb(x,y){ return x>=0 && y>=0 && x<MAP_W && y<MAP_H; }
function walk(g, rnd, x, y, len, ch, width=1, drift=0.35, dir=null){ // เดินสุ่มวางเส้น (แม่น้ำ/ถนน/ทางเดิน)
  let dx = dir ? dir[0] : (rnd()<0.5?1:-1), dy = dir ? dir[1] : 0;
  for (let i=0;i<len;i++){
    for (let a=-Math.floor(width/2); a<=Math.floor(width/2); a++){ for (let b=-Math.floor(width/2); b<=Math.floor(width/2); b++){ if (inb(x+a,y+b)) g[y+b][x+a]=ch; } }
    if (rnd()<drift){ if (rnd()<0.5) dy = Math.max(-1, Math.min(1, dy + (rnd()<0.5?-1:1))); else dx = Math.max(-1, Math.min(1, dx + (rnd()<0.5?-1:1))); if (!dx && !dy) dx = 1; }
    x += dx; y += dy; if (!inb(x,y)) break;
  }
}
function rect(g, x0,y0,x1,y1, ch){ for (let y=y0;y<=y1;y++) for (let x=x0;x<=x1;x++) if (inb(x,y)) g[y][x]=ch; }
function sprinkle(g, rnd, ch, n, onlyOn='.'){ let k=0, guard=0; while (k<n && guard++<2000){ const x=Math.floor(rnd()*MAP_W), y=Math.floor(rnd()*MAP_H); if (onlyOn.includes(g[y][x])){ g[y][x]=ch; k++; } } }
function house(g, rnd, x, y, w, hh){ rect(g, x, y, x+w-1, y+hh-1, 'H'); }
function room(g, x0,y0,x1,y1){ rect(g,x0,y0,x1,y1,'#'); rect(g,x0+1,y0+1,x1-1,y1-1,'F'); }
const GEN = {
  field(g, rnd){ const n=noiseGrid(rnd,6); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.72? ',' : '.'; sprinkle(g,rnd,'T',6); sprinkle(g,rnd,'R',3); },
  forest(g, rnd){ const n=noiseGrid(rnd,4); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.62? 'T' : (n[y][x]>0.5? ',' : '.'); walk(g,rnd,0,Math.floor(rnd()*MAP_H),30,'.',1,0.3,[1,0]); sprinkle(g,rnd,'R',4); },
  river(g, rnd){ GEN.field(g,rnd); const y = 6+Math.floor(rnd()*8); walk(g,rnd,0,y,40,'W',3,0.25,[1,0]); for (let yy=0;yy<MAP_H;yy++) for (let x=0;x<MAP_W;x++) if (g[yy][x]==='.' && [[0,1],[0,-1],[1,0],[-1,0]].some(([a,b])=>inb(x+a,yy+b)&&g[yy+b][x+a]==='W') && rnd()<0.6) g[yy][x]='w'; const bx = 4+Math.floor(rnd()*12); for (let yy=0;yy<MAP_H;yy++) if ('Ww'.includes(g[yy][bx])) g[yy][bx]='B'; sprinkle(g,rnd,'T',8); },
  city(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x]='='; for (let i=0;i<3;i++){ const y=3+i*6; rect(g,0,y,MAP_W-1,y+1,'.'); } for (let x=0;x<MAP_W;x+=7){ for (let y=0;y<MAP_H;y++) g[y][x]='.'; } for (let by=0; by<MAP_H; by+=6) for (let bx=1; bx<MAP_W; bx+=7){ const w=2+Math.floor(rnd()*4), hh=2+Math.floor(rnd()*2); if (rnd()<0.85) house(g,rnd,bx+1,by+1,Math.min(w,5),hh); } sprinkle(g,rnd,'r',6,'='); sprinkle(g,rnd,'P',4,'='); },
  village(g, rnd){ GEN.field(g,rnd); walk(g,rnd,0,10,40,'=',1,0.2,[1,0]); for (let i=0;i<6;i++){ const x=1+Math.floor(rnd()*15), y=1+Math.floor(rnd()*15); if ('.,'.includes(g[y][x])) house(g,rnd,x,y,2+Math.floor(rnd()*2),2); } sprinkle(g,rnd,'T',5); sprinkle(g,rnd,'X',1); },
  cave(g, rnd){ const n=noiseGrid(rnd,3); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.55? 'R' : (n[y][x]>0.47? 'r':'.'); walk(g,rnd,0,Math.floor(rnd()*MAP_H),40,'.',2,0.3,[1,0]); walk(g,rnd,Math.floor(rnd()*MAP_W),0,40,'.',2,0.3,[0,1]); sprinkle(g,rnd,'w',8,'.'); sprinkle(g,rnd,'P',3,'.'); },
  dungeon(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x]='#'; const rooms=[]; for (let i=0;i<6;i++){ const w=3+Math.floor(rnd()*5), hh=3+Math.floor(rnd()*4); const x=Math.floor(rnd()*(MAP_W-w-1)), y=Math.floor(rnd()*(MAP_H-hh-1)); rooms.push([x,y,x+w,y+hh]); room(g,x,y,x+w,y+hh); } for (let i=1;i<rooms.length;i++){ const [ax,ay]=[Math.floor((rooms[i-1][0]+rooms[i-1][2])/2), Math.floor((rooms[i-1][1]+rooms[i-1][3])/2)]; const [bx,by]=[Math.floor((rooms[i][0]+rooms[i][2])/2), Math.floor((rooms[i][1]+rooms[i][3])/2)]; for (let x=Math.min(ax,bx); x<=Math.max(ax,bx); x++) if (g[ay][x]!=='F') g[ay][x]= g[ay][x]==='#' && (inb(x,ay-1)&&g[ay-1][x]==='F'||inb(x,ay+1)&&g[ay+1][x]==='F') ? 'D' : 'F'; for (let y=Math.min(ay,by); y<=Math.max(ay,by); y++) if (g[y][bx]!=='F') g[y][bx]='F'; } sprinkle(g,rnd,'P',3,'F'); sprinkle(g,rnd,'r',4,'F'); sprinkle(g,rnd,'A',1,'F'); },
  mountain(g, rnd){ const n=noiseGrid(rnd,5); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.7? 'R' : (n[y][x]>0.58? 'r' : (n[y][x]<0.25? 'C' : '.')); walk(g,rnd,0,Math.floor(rnd()*MAP_H),40,'.',1,0.35,[1,0]); sprinkle(g,rnd,'s',6,'.'); sprinkle(g,rnd,'T',3,'.'); },
  sea(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = x < 8+Math.floor(Math.sin(y/3)*2) ? 'W' : (x < 10+Math.floor(Math.sin(y/3)*2) ? 'w' : (x < 13 ? 'S' : '.')); sprinkle(g,rnd,'R',4,'S.'); sprinkle(g,rnd,'T',3,'.'); rect(g, 6, 8, 9, 9, 'B'); },
  ship(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x]='W'; for (let y=1;y<MAP_H-1;y++){ const half = Math.round(5 + 4*Math.sin(Math.PI*y/(MAP_H-1))); rect(g, 10-half, y, 9+half, y, 'B'); } for (let y=2;y<MAP_H-2;y++){ if (g[y][9]==='B') g[y][9]='F'; if (g[y][10]==='B') g[y][10]='F'; } g[5][9]='P'; g[13][10]='P'; rect(g,7,8,12,10,'#'); rect(g,8,9,11,9,'F'); g[9][7]='D'; sprinkle(g,rnd,'r',5,'B'); },
  valley(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = (x<3||x>16) ? 'R' : ((x<5||x>14) ? 'r' : '.'); walk(g,rnd,8,0,40,'w',1,0.3,[0,1]); sprinkle(g,rnd,'T',6,'.'); sprinkle(g,rnd,',',10,'.'); },
  cliff(g, rnd){ const edge = 8+Math.floor(rnd()*4); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){ const e = edge + Math.round(Math.sin(y/2.5)*1.5); g[y][x] = x>e+1 ? '~' : (x===e||x===e+1 ? 'C' : '.'); } sprinkle(g,rnd,'R',5,'.'); sprinkle(g,rnd,',',8,'.'); const by=4+Math.floor(rnd()*10); for (let x=0;x<MAP_W;x++) if ('C~'.includes(g[by][x])) g[by][x]='B'; },
  swamp(g, rnd){ const n=noiseGrid(rnd,4); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.66? 'W' : (n[y][x]>0.52? 'M' : (n[y][x]>0.42? ',' : '.')); sprinkle(g,rnd,'T',8,'.,M'); sprinkle(g,rnd,'B',4,'WM'); },
  desert(g, rnd){ const n=noiseGrid(rnd,6); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.7? 'R' : 'S'; sprinkle(g,rnd,'r',6,'S'); sprinkle(g,rnd,'w',3,'S'); sprinkle(g,rnd,'P',2,'S'); },
  ruins(g, rnd){ GEN.field(g,rnd); for (let i=0;i<5;i++){ const w=3+Math.floor(rnd()*4), hh=3+Math.floor(rnd()*3); const x=Math.floor(rnd()*(MAP_W-w-1)), y=Math.floor(rnd()*(MAP_H-hh-1)); room(g,x,y,x+w,y+hh); for (let yy=y;yy<=y+hh;yy++) for (let xx=x;xx<=x+w;xx++) if (g[yy][xx]==='#' && rnd()<0.45) g[yy][xx]= rnd()<0.5?'r':'F'; } sprinkle(g,rnd,'P',5,'.F'); sprinkle(g,rnd,'A',1,'F'); },
  snow(g, rnd){ const n=noiseGrid(rnd,5); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.6? 's' : '.'; sprinkle(g,rnd,'T',7,'.s'); sprinkle(g,rnd,'R',4,'.s'); sprinkle(g,rnd,'W',3,'s'); },
  camp(g, rnd){ GEN.field(g,rnd); g[10][10]='X'; for (let i=0;i<4;i++){ const a=i*Math.PI/2+rnd(); const x=10+Math.round(Math.cos(a)*4), y=10+Math.round(Math.sin(a)*4); rect(g,x,y,x+1,y,'H'); } sprinkle(g,rnd,'T',8,'.,'); walk(g,rnd,0,16,40,'=',1,0.15,[1,0]); },
  temple(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x]='.'; room(g,4,2,15,17); for (let y=4;y<16;y+=3){ g[y][6]='P'; g[y][13]='P'; } g[17][9]='D'; g[17][10]='D'; rect(g,8,4,11,5,'A'); sprinkle(g,rnd,'T',6,'.'); walk(g,rnd,9,18,2,'=',2,0,[0,1]); },
  mine(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x]='R'; walk(g,rnd,0,10,40,'.',2,0.25,[1,0]); walk(g,rnd,10,0,40,'.',1,0.3,[0,1]); for (let i=0;i<4;i++){ const x=2+Math.floor(rnd()*15), y=2+Math.floor(rnd()*15); rect(g,x,y,x+2,y+2,'.'); } sprinkle(g,rnd,'r',10,'.'); sprinkle(g,rnd,'P',4,'.'); sprinkle(g,rnd,'B',3,'.'); },
  farm(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = (y%4===0) ? '.' : ','; walk(g,rnd,0,9,40,'=',1,0.1,[1,0]); house(g,rnd,2,2,3,2); house(g,rnd,15,14,3,3); sprinkle(g,rnd,'T',4,'.'); sprinkle(g,rnd,'w',3,','); },
  bridge(g, rnd){ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = (x>=7 && x<=12) ? '~' : '.'; rect(g,7,8,12,10,'B'); g[6][8]='C'; g[6][11]='C'; g[13][8]='C'; g[13][11]='C'; sprinkle(g,rnd,'R',5,'.'); sprinkle(g,rnd,'T',4,'.'); },
  graveyard(g, rnd){ GEN.field(g,rnd); for (let y=3;y<17;y+=3) for (let x=3;x<17;x+=3) if (rnd()<0.8) g[y][x]='G'; room(g,8,1,11,4); g[4][9]='D'; sprinkle(g,rnd,'T',5,'.,'); sprinkle(g,rnd,'M',4,'.'); },
  volcano(g, rnd){ const n=noiseGrid(rnd,4); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) g[y][x] = n[y][x]>0.68? 'L' : (n[y][x]>0.55? 'r' : (n[y][x]<0.2? 'R' : '.')); sprinkle(g,rnd,'B',3,'L'); },
  island(g, rnd){ const n=noiseGrid(rnd,5); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){ const dx=(x-9.5)/9.5, dy=(y-9.5)/9.5; const r=Math.sqrt(dx*dx+dy*dy); const v = n[y][x]*0.5 + (1-r); g[y][x] = v>0.95? '.' : (v>0.8? 'S' : (v>0.68? 'w' : 'W')); } sprinkle(g,rnd,'T',6,'.'); sprinkle(g,rnd,'R',3,'.S'); },
};
function generateMap(kind, seed){
  if (!GEN[kind]) kind = 'field';
  const rnd = mulberry32(seedFrom(kind + ':' + seed));
  const g = blank('.');
  GEN[kind](g, rnd);
  return { kind, seed: String(seed), w: MAP_W, h: MAP_H, cells: g.map(r=>r.join('')).join('') };
}
function mapCell(map, x, y){ if (!map || !inb(x,y)) return 'R'; return map.cells[y*MAP_W + x] || '.'; }
function setMapCell(map, x, y, ch){ if (!inb(x,y)) return; const a = map.cells.split(''); a[y*MAP_W+x] = ch; map.cells = a.join(''); }
/* ปีนป่าย (ผู้ใช้เคาะ 9 พ.ย. 2026): ช่อง climb (ต้นไม้ เสา) และ cling (เหว ขอบหน้าผา) เข้าได้เฉพาะหมากที่ติ๊ก 🧗 ปีนป่าย · เกาะขอบเหว/หน้าผา = ติด Prone ตลอดเวลาที่อยู่ตรงนั้น */
function cellClimbable(map, x, y){ const t = TILE[mapCell(map,x,y)]; return !!(t && (t.climb || t.cling)); }
function cellCling(map, x, y){ const t = TILE[mapCell(map,x,y)]; return !!(t && t.cling); }
function cellPassable(map, x, y){ const t = TILE[mapCell(map,x,y)]; return !!(t && t.pass); }
/* ยืนได้ (ไม่ใช่น้ำลึก): ใช้ตอนวางหมากอัตโนมัติ */
function cellStandable(map, x, y){ const t = TILE[mapCell(map,x,y)]; return !!(t && t.pass && !t.swim); }
/* เส้นสายตา (Bresenham): หิน กำแพง บ้าน ต้นไม้ (กำบังสูง) เสา บังการมองเห็น · ช่องปลายทางมองเห็นได้แม้เป็นช่องทึบ (ผู้ใช้เคาะ 9 พ.ย. 2026) */
function losClear(map, a, b){ let x0=a.x, y0=a.y; const x1=b.x, y1=b.y; const dx=Math.abs(x1-x0), dy=-Math.abs(y1-y0), sx = x0<x1?1:-1, sy = y0<y1?1:-1; let err = dx+dy; let guard = 0; while (!(x0===x1 && y0===y1) && guard++ < 64){ const e2 = 2*err; if (e2 >= dy){ err += dy; x0 += sx; } if (e2 <= dx){ err += dx; y0 += sy; } if (x0===x1 && y0===y1) break; const t = TILE[mapCell(map,x0,y0)]; if (t && t.opaque) return false; } return true; }
/* ช่องที่หมากตัวหนึ่งมองเห็น: ในรัศมีตามแสง + เส้นสายตาโล่ง หรือช่องที่มีแหล่งแสงส่องและมองเห็นได้ */
function tokenSight(r, t){ const light = r.light||'low'; const rad = visionCells(t, light); const lit = lightSourceCells(light); const sources = lightSources(r); const vis = new Set(); for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){ const p={x,y}; const d = cellDist(t,p); if (d===0){ vis.add(x+','+y); continue; } if (!losClear(r.map, t, p)) continue; if (d <= rad || sources.some(sv=>cellDist(sv,p) <= lit)) vis.add(x+','+y); } return vis; }
function lightSources(r){ const out = []; for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) if (mapCell(r.map,x,y)==='X') out.push({x,y}); for (const t of r.tokens||[]) if (t.torch && !t.inside) out.push({x:t.x, y:t.y}); return out; }
function cellDist(a, b){ return Math.max(Math.abs(a.x-b.x), Math.abs(a.y-b.y)); } // Chebyshev: ทแยง = 1 ช่อง
/* เขต (ผู้ใช้เคาะ 10 พ.ย. 2026): ปะทะ 1-3 ม. (ช่องติดกัน) · ใกล้เคียง 4-10 ม. (2-5 ช่อง) · ไกล 11-20+ ม. (6 ช่องขึ้นไป) */
const NEAR_MAX_M = 10;
function rangeBand(cells){ const m = cells*CELL_M; if (cells <= 1) return {id:'eng', label:'เขตปะทะ', m}; if (m <= NEAR_MAX_M) return {id:'near', label:'เขตใกล้เคียง', m}; return {id:'far', label:'เขตไกล', m}; }
/* ===== v1.24 (Non สั่ง 15 พ.ย. 2026): ระยะยิงให้เห็นชัดตอนคลิกเช็คระยะ =====
 * ระยะแม่นของการโจมตีระยะไกลมาจากทักษะความรู้ ต่อสู้ระยะไกล (Range) ของตัวละคร อ่านตัวเลขจากข้อความระดับในไฟล์ Talent & Knowledge
 * (ระดับ 0 = 10 ม., 1 = 20 ม. ...) เกินระยะแม่น -1 CV ต่อทุก 10 ม. ที่เริ่มนับ · หมาก NPC ไม่มีชีท GM ตั้งระดับเองที่แผงหมาก (t.rangeLv ค่าเริ่ม 0)
 * ระยะบนกระดานนับแบบ Chebyshev (ทแยง = 1 ช่อง) วงระยะจึงเป็นกรอบสี่เหลี่ยม */
const RANGE_ACC_FALLBACK = [10, 20, 50, 100];
function rangeAccM(lv){ lv = Math.max(0, Math.min(3, +lv || 0)); const K = (typeof KNOW !== 'undefined' && KNOW) ? KNOW.range : null; const txt = K && K.levels && K.levels[String(lv)] ? String(K.levels[String(lv)].text || '') : ''; const m = /ความแม่นยำในระยะ\s*(\d+)\s*เมตร/.exec(txt); return m ? +m[1] : RANGE_ACC_FALLBACK[lv]; }
function tokenRangeLv(t){ if (!t) return 0; if (t.charId && typeof Store !== 'undefined'){ const c = Store.get(t.charId); if (c && c.kin && KIN[c.kin] && typeof knowledgeLevels === 'function'){ try { return Math.max(0, Math.min(3, knowledgeLevels(c).range || 0)); } catch(e){} } } return Math.max(0, Math.min(3, +t.rangeLv || 0)); }
function rangePenalty(m, acc){ return m > acc ? Math.ceil((m - acc) / 10) : 0; }
function rangeShotText(m, acc){ const p = rangePenalty(m, acc); return p ? `ยิง −${p} CV (เกินระยะแม่น ${acc} ม.)` : `ยิงในระยะแม่น (${acc} ม.)`; }
function svgNode(tag, attrs, text){ const el = document.createElementNS('http://www.w3.org/2000/svg', tag); for (const [k,v] of Object.entries(attrs||{})) el.setAttribute(k, v); if (text != null) el.textContent = text; return el; }
/* ชั้น SVG ทับกระดาน: กรอบเขตปะทะ เขตใกล้เคียง ระยะยิงแม่น และขั้นโทษทุก 10 ม. พร้อมป้ายเมตร · ถ้ามีเป้า (tgt) ลากเส้นวัดพร้อมป้ายระยะ */
function rangeOverlaySvg(o, tgt, acc, W, H){
  W = W || MAP_W; H = H || MAP_H;
  const svg = svgNode('svg', {class:'rngsvg', viewBox:`0 0 ${W} ${H}`, preserveAspectRatio:'none', 'aria-hidden':'true'});
  const clampX = (v)=>Math.max(0.12, Math.min(W - 0.2, v)), clampY = (v)=>Math.max(0.62, Math.min(H - 0.18, v));
  const ring = (cells, cls, label)=>{ const x0 = o.x - cells, y0 = o.y - cells, sz = cells*2 + 1;
    if (x0 <= 0 && y0 <= 0 && x0 + sz >= W && y0 + sz >= H) return; // กรอบใหญ่เกินกระดานทุกด้าน ไม่ต้องวาด
    svg.append(svgNode('rect', {class:'rr '+cls, x:x0, y:y0, width:sz, height:sz, rx:0.18}));
    if (!label) return;
    // ป้ายวางชิดขอบกรอบด้านที่ยังอยู่ในกระดาน (บนก่อน แล้วล่าง) ชิดซ้ายถ้าขอบซ้ายอยู่ในกระดาน ไม่งั้นชิดขวา กรอบที่ล้นหลายด้านจึงไม่เอาป้ายไปกองที่มุมเดียวกัน
    const topIn = y0 >= 0, botIn = y0 + sz <= H, leftIn = x0 >= 0, rightIn = x0 + sz <= W;
    let ly, lx, anchor = 'start';
    if (topIn) ly = y0 + 0.6; else if (botIn) ly = y0 + sz - 0.2; else ly = Math.min(H - 0.2, Math.max(0.62, o.y + 0.7));
    if (leftIn) lx = x0 + 0.14; else if (rightIn){ lx = x0 + sz - 0.14; anchor = 'end'; } else { lx = Math.min(W - 0.2, Math.max(0.12, o.x + 1.2)); }
    if (!topIn && !botIn && !leftIn && !rightIn) return;
    svg.append(svgNode('text', {class:'rl '+cls, x:clampX(lx), y:clampY(ly), 'text-anchor':anchor}, label)); };
  const nearCells = Math.floor(NEAR_MAX_M / CELL_M), accCells = Math.floor(acc / CELL_M), maxCells = Math.max(W, H);
  ring(1, 'eng', null);
  ring(nearCells, 'near', accCells === nearCells ? `${NEAR_MAX_M} ม. · ยิงแม่น` : `${NEAR_MAX_M} ม.`);
  if (accCells !== nearCells && accCells < maxCells) ring(accCells, 'acc', `ยิงแม่น ${acc} ม.`);
  for (let k = 1; k <= 6; k++){ const cells = Math.floor((acc + 10*k) / CELL_M); if (cells >= maxCells) break; ring(cells, 'pen', `−${k} CV ถึง ${acc + 10*k} ม.`); }
  if (tgt){ const d = cellDist(o, tgt), m = d * CELL_M, band = rangeBand(d), pen = rangePenalty(m, acc);
    svg.append(svgNode('line', {class:'ruler', x1:o.x+0.5, y1:o.y+0.5, x2:tgt.x+0.5, y2:tgt.y+0.5}));
    svg.append(svgNode('circle', {class:'rulerdot', cx:tgt.x+0.5, cy:tgt.y+0.5, r:0.5}));
    const lbl = `${m} ม. · ${band.label}` + (band.id === 'eng' ? '' : (pen ? ` · ยิง −${pen} CV` : ' · ยิงแม่น'));
    const lx = Math.max(0.1, Math.min(W - 0.1, tgt.x + 0.5)), ly = tgt.y > 1 ? tgt.y - 0.22 : tgt.y + 1.75;
    svg.append(svgNode('text', {class:'rulerlbl '+band.id+(pen?' pen':''), x:lx, y:ly, 'text-anchor': tgt.x < 3 ? 'start' : (tgt.x > W - 4 ? 'end' : 'middle')}, lbl)); }
  return svg;
}
/* ===== v1.22 (Non เคาะ 13 พ.ย. 2026): ช่องที่หมากเดินถึงในหนึ่ง Maneuver ตามความเร็วของตัวละคร =====
 * budget = จำนวนช่องที่ไปได้ (moveSpeed ใน core.js แปลงเมตรเป็นช่อง ช่องละ CELL_M เมตร ปัดลง) · เดิน 8 ทิศ ทแยงนับ 1 ช่องเหมือนระยะเขต
 * ช่องเดินช้านับ 2 · ช่องผ่านไม่ได้ข้ามไม่ได้ เว้นหมากที่ติ๊กปีนป่ายเข้าช่องปีนได้ (นับ 2 ช่อง ตัวเลขนี้เว็บตั้งเอง ไฟล์แกนไม่ได้กำหนดความเร็วปีน)
 * น้ำลึกลงได้แต่เดินต่อจากช่องนั้นไม่ได้ (ลงไปแล้วเสียเทิร์น) เว้นสัตว์น้ำ · ช่องที่ผู้เล่นมองไม่เห็น (vis) คิดเป็นพื้นปกติ ไม่บอกใบ้สิ่งที่อยู่ในความมืด
 * หมากอื่นเดินผ่านได้ แต่ไปหยุดทับไม่ได้ (คนเรียกตรวจเอง) · คืน Map ของ "x,y" → จำนวนช่องที่ใช้ */
function moveReach(r, t, budget, vis){ const K = (x,y)=>x+','+y; const dist = new Map(); if (!t || budget == null || budget < 0) return dist;
  dist.set(K(t.x,t.y), 0); const q = [[0, t.x, t.y]];
  const tileAt = (x,y)=> (vis && !vis.has(K(x,y))) ? TILE['.'] : (TILE[mapCell(r.map,x,y)]||TILE['.']);
  while (q.length){ q.sort((a,b)=>a[0]-b[0]); const [d0, x0, y0] = q.shift(); if (d0 > dist.get(K(x0,y0))) continue;
    if (d0 > 0 && tileAt(x0,y0).swim && !t.aquatic) continue;
    for (let dy=-1; dy<=1; dy++) for (let dx=-1; dx<=1; dx++){ if (!dx && !dy) continue; const x = x0+dx, y = y0+dy; if (x<0 || y<0 || x>=MAP_W || y>=MAP_H) continue;
      const tile = tileAt(x,y); let step = 1;
      if (!tile.pass){ if (!(t.climb && (tile.climb || tile.cling))) continue; step = 2; } else if (tile.pass === 2) step = 2;
      const nd = d0 + step; if (nd > budget) continue; const k = K(x,y); if (!dist.has(k) || nd < dist.get(k)){ dist.set(k, nd); q.push([nd, x, y]); } } }
  return dist; }
/* ===== ระดับแสง (ไฟล์แกน: ระบบแสง 5 ระดับ) และระยะที่หมากมองเห็นบนบอร์ด =====
 * Bright/Low เห็นทั้งบอร์ด · Dim: ไม่มี Dark Vision เห็น 12 ช่อง (24 ม.) มี Dark Vision เห็นหมด (ระยะนี้เว็บตั้งเอง ไฟล์แกนไม่กำหนดเป็นเมตร คงไว้เท่าเดิมหลังเขตใกล้เคียงหดเหลือ 10 ม.)
 * Darkness: ไม่มี Dark Vision ตาบอด เห็นแค่ช่องติดตัว · มี Dark Vision เห็น 30 ม. (15 ช่อง) เป็นเฉดเทา · Abyssal Fog: ทุกคนเห็นแค่เขตปะทะ
 * แหล่งแสง (กองไฟบนแผนที่ หรือหมากที่ถือคบเพลิง) ส่องรอบตัว 4 ช่อง (8 ม.) ในที่มืด และแค่ 1 ช่องในหมอกทมิฬ */
const LIGHTS = [ ['bright','สว่างจ้า'], ['low','แสงหม่น (ปกติของคีรันนา)'], ['dim','แสงสลัว'], ['dark','มืดสนิท'], ['abyss','ม่านหมอกห้วงทมิฬ'] ];
const LIGHT_NOTE = { bright:'ทุกคนเห็นชัด · Stealth ติด Disadvantage · อสูรทั่วไปไม่โผล่', low:'เห็นทั้งบอร์ด · มองเขตไกลอาจติด Disadvantage ตามที่ GM ประกาศ', dim:'ไม่มี Dark Vision เห็นได้ 12 ช่อง (24 ม.) และติด Disadvantage ในการทอย PER ที่ใช้สายตา · Stealth ได้ Advantage', dark:'ไม่มี Dark Vision ตาบอด เห็นแค่ช่องติดตัว · Dark Vision เห็น 30 ม. เป็นเฉดเทา · กองไฟส่อง 8 ม. · ทุกคนซ่อนตัวได้', abyss:'ทุกคนเห็นแค่เขตปะทะ Dark Vision ไม่มีผล · แหล่งแสงส่องได้ 1 ช่อง · อยู่นานต้องทอย Sanity Check' };
function lightLabel(id){ const l = LIGHTS.find(x=>x[0]===id); return l ? l[1] : LIGHTS[1][1]; }
function visionCells(tok, light){ const nv = !!tok.nv; if (light==='dim') return nv ? Infinity : 12; if (light==='dark') return nv ? 15 : 1; if (light==='abyss') return 1; return Infinity; }
/* คำบอกระยะมองเห็นของหมากตัวหนึ่งในแสงปัจจุบัน (ใช้ในตำนานใต้แผนที่และหน้าปัดหมาก) */
function sightLabel(t, light){
  const rad = visionCells(t, light); const lit = lightSourceCells(light); let s;
  if (rad === Infinity) s = light==='dim' ? 'ทั้งบอร์ดตามเส้นสายตา (Dark Vision)' : 'ทั้งบอร์ดตามเส้นสายตา';
  else if (rad <= 1) s = light==='abyss' ? '1 ช่อง = เขตปะทะเท่านั้น (หมอกทมิฬบังทุกคน Dark Vision ไม่ช่วย)' : '1 ช่อง = ช่องติดตัว (ตาบอดในความมืด ไม่มี Dark Vision)';
  else s = `${rad} ช่อง (~${rad*CELL_M} ม.)${t.nv ? ' ด้วย Dark Vision' + (light==='dark' ? ' เห็นเป็นเฉดเทา' : '') : ''}`;
  if (lit) s += ` · กองไฟหรือหมากที่ถือ 🔥 ส่องให้เห็นรอบจุดนั้น ${lit} ช่อง`;
  return s;
}
function lightSourceCells(light){ return light==='abyss' ? 1 : (light==='dark' || light==='dim') ? 4 : 0; }
/* คืน Set ของ 'x,y' ที่ผู้เล่นคนนี้มองเห็นจากหมากทุกตัวของตน (รัศมีตามแสง + เส้นสายตา) หรือ null = เห็นทั้งบอร์ด (GM หรือยังไม่มีหมากของตัวเอง) */
function computeVisibility(r, me){
  const mine = (r.tokens||[]).filter(t=>t.ownerId===me && !t.inside && !t.gmRun); if (!mine.length) return null; // ร่างแฝดที่ GM คุมหลังฉาก เจ้าของไม่ได้มองผ่านตาร่างนั้น
  const vis = new Set(); for (const t of mine) for (const k of tokenSight(r, t)) vis.add(k);
  return vis;
}
/* ตัวละครมองเห็นในความมืดไหม: Trait Dark Vision / Mana Sight ของวงศา หรือที่หยิบมาผ่าน Descendants of Evolver */
function charHasNightVision(c){ const kin = c && c.kin ? KIN[c.kin] : null; const rx = /Dark Vision|Night Vision|Mana Sight|มองเห็นในความมืด/; if (kin && (kin.traits||[]).some(t=>rx.test((t.nameEn||'')+' '+(t.name||'')))) return true; const ev = c && c.evolver || {}; return rx.test(String(ev.pick||'')); }
function freeCell(map, tokens, preferRows, rnd=Math.random){
  const taken = (x,y)=>tokens.some(t=>!t.inside && t.x===x && t.y===y);
  for (let guard=0; guard<400; guard++){ const y = preferRows[Math.floor(rnd()*preferRows.length)]; const x = Math.floor(rnd()*MAP_W); if (cellStandable(map,x,y) && !taken(x,y)) return {x,y}; }
  for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) if (cellStandable(map,x,y) && !taken(x,y)) return {x,y};
  for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) if (cellPassable(map,x,y) && !taken(x,y)) return {x,y};
  return {x:0,y:0};
}
/* ย่อภาพตัวละครเป็นรูปหมาก 56px (เก็บในเอกสารห้องได้โดยไม่หนัก) */
function makeThumb(dataUrl){
  return new Promise(res => { if (!dataUrl) return res(null); const img = new Image(); img.onload = ()=>{ const cv = document.createElement('canvas'); cv.width = cv.height = 56; const ctx = cv.getContext('2d'); const s = Math.min(img.width, img.height); ctx.drawImage(img, (img.width-s)/2, (img.height-s)/2, s, s, 0, 0, 56, 56); res(cv.toDataURL('image/jpeg', 0.7)); }; img.onerror = ()=>res(null); img.src = dataUrl; });
}
