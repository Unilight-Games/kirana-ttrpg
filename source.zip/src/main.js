/* ===== Home, rules reference, routing ===== */
W.skFilter = {};
function renderHome(){
  const root = clear($('#v-home'));
  const nChars = Store.chars.filter(c=>c.done).length;
  const go = (hash, isNew)=>{ if (isNew) startWizard(null); location.hash = hash; };
  root.append(h('section',{class:'home'},
    h('div',{class:'home-hero'},
      h('div',{class:'home-text'},
        h('div',{class:'kicker',text:'โลกใต้ม่านมานา'}),
        h('h1',{class:'gothic'}, 'Kirana ', h('span',{class:'thin',text:'TTRPG'})),
        h('p',{class:'lede',text:'โต๊ะเล่นออนไลน์ของคีรันนา โลกที่วงศาทั้งสิบสองต้องอยู่ร่วมกันทั้งที่ยังระแวงกันอยู่ เวทมนตร์มีราคา และแผลไม่หายเพราะพักแค่คืนเดียว สร้างตัวละครที่นี่ เก็บชีทที่กดทอยได้จริง แล้วยกไปนั่งโต๊ะเดียวกับเพื่อนที่อยู่คนละเมือง'}),
        h('div',{class:'row home-actions'},
          h('button',{class:'primary',onclick:()=>{ location.hash='#create'; },text:'ให้เนเมสไซอาร์สอนเล่น'}),
          h('button',{onclick:()=>{ location.hash='#chars'; },text: nChars ? `ตัวละครของฉัน (${nChars})` : 'สร้างตัวละครตัวแรก'}),
          h('button',{class:'ghost',onclick:()=>{ location.hash='#table'; },text:'เข้าโต๊ะเล่น'}))),
      h('div',{class:'home-nem'}, h('div',{class:'home-arch'}), nemImg('smile'))),
    h('div',{class:'nem-box mood-smile home-say'},
      h('div',{class:'nem-side'},
        h('div',{class:'nem-name'}, h('b',{text:NEM.name}), h('span',{class:'dim',text:' · '+NEM.title})),
        h('p',null, T('ยินดีต้อนรับ ลูกรัก เราชื่อเนเมสไซอาร์ คนที่จะนั่งข้างเจ้าบนโต๊ะนี้ คอยบอกว่าลูกเต๋าจะส่งผลอะไร แล้วทำไม ที่นี่เจ้าจะได้สร้างตัวละครทีละขั้น โดยทุกตัวเลือกนั้นบอกชัดอยู่แล้วว่าได้อะไร และเราจะคอยยืนชี้แนะอยู่ข้าง ๆ ตลอดทาง ไม่ต้องกลัวว่าจะพลาด')),
        h('p',null, T('เกมนี้มีแนวคิดง่าย ๆ ว่าเจ้ายอมเสียอะไร เพื่อให้ได้สิ่งที่ต้องการ ถ้ายังไม่เคยเล่น กด "สอนเล่น" แล้วเราจะเล่าให้ฟังทีละบท แต่ถ้าเคยเล่นแล้วหรืออยากลองระบบเอง ก็ออกไปรังสรรค์ตัวละครของเจ้าได้เลย')))),
    h('h3',{class:'home-h',text:'จุดเด่นของระบบ'}),
    h('div',{class:'grid feat'},
      feat('⚄', 'ลูกเต๋าสองลูกตัดสินทุกอย่าง', 'ทอย 2d6 + Mod + บุคลิกภาพ เทียบ DC 5 / 7 / 10 / 12 / 14 ออก [6,6] ผ่านทันที [1,1] พังทันที Advantage และ Disadvantage ทอยสามลูกเลือกสอง'),
      feat('✦', 'ค่าพลังหกค่า และ Mod ที่ซ่อนอยู่', 'STR AGI VIT PER INF INT ค่าดิบหารสองลบห้า เลขคู่เท่านั้นที่ขยับ Mod ตัวเลขเล็ก ๆ จึงมีความหมายทุกแต้ม'),
      feat('☗', 'Toughness แยกตามอวัยวะ', 'หัว ลำตัว แขนสอง ขาสอง เกราะ A/B ต่อส่วน ตำแหน่งที่โดนมาจากลูกเต๋า แขนที่หายไปไม่งอกกลับมาเพราะพักผ่อน'),
      feat('☾', 'เวทมนตร์ที่มีราคา', 'เวทจ่ายด้วย MP หรือ Sanity สติเป็นทรัพยากรเท่ากับเลือด และ GM เรียกเก็บได้เมื่อเจ้าฝืนนิสัยที่เลือกไว้'),
      feat('◈', 'บุคลิกภาพคือค่าพลังที่เลือกเอง', 'หกคู่ตรงข้าม แจก 3 2 2 1 1 0 ฝั่งที่เลือกเป็นบวก ฝั่งตรงข้ามติดลบเท่ากัน ระบบอ่านนิสัยแล้วบอกสายการเล่นที่เข้ากัน'),
      feat('⚑', 'โต๊ะออนไลน์ แผนที่ 20×20', `สุ่มแผนที่ต่อสู้ตามสถานที่ หมากมีรูปจากชีท ทอยเต๋าเด้งหน้าทุกคนและทอยได้ทีละคน แชต ลำดับเทิร์น และ Insight Point ตามกฎจริง`)),
    h('p',{class:'dim home-foot',text:`${DATA.kins.length} วงศา · ${DATA.kins.reduce((a,k)=>a+k.childhood.length+k.specialChildhood.length+k.adulthood.length,0)} พื้นหลัง · ${DATA.skills.filter(s=>s.category!=='Granted').length} ทักษะและเวทมนตร์ · ${DATA.knowledge.length} สาขาความรู้ · ${DATA.sets.sets.length} ชุดเริ่มต้น · ${(DATA.items||[]).length} ไอเทม · ข้อมูลจาก ${Object.values(DATA.source).join(' · ')} · Beastman ยังไม่เปิดให้เลือก`}),
    h('p',{class:'dim home-foot'}, h('a',{href:'#policy',text:'นโยบายความเป็นส่วนตัว มารยาท และมาตรฐานการใช้งาน'}), ' · ', h('a',{href:'#maps',text:'สร้างและค้นหาแผนที่'}), ' · ', h('a',{href:'#npcs',text:'สร้างและค้นหา NPC กับ Asset'}), ' · Unilight Games')));
  function feat(glyph, title, text){ return h('div',{class:'card featcard'}, h('div',{class:'glyph',text:glyph}), h('h4',{text:title}), h('div',{class:'desc'}, T(text))); }
}
function renderRules(){
  const root = clear($('#v-rules'));
  root.append(h('h2',{text:'กฎย่อสำหรับโต๊ะ'}));
  const g = h('div',{class:'grid two',style:'margin-top:12px'});
  g.append(h('div',{class:'card'}, h('h3',{text:'การทอยหลัก'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Check: 2d6 + Stat Mod + Personality (ถ้าเข้าบริบท)')),
    h('li',null, T('ไม่มี DC: 10+ Full Success · 7-9 Partial Success (สำเร็จแต่มีราคา) · 6- Failure')),
    h('li',null, T('Clash / Challenge: ทั้งสองฝ่ายทอย ฝ่ายสูงกว่าชนะ เท่ากันฝ่ายตั้งรับ (ผู้ถูกท้า) ชนะ')),
    h('li',null, T('Knowledge Check: 2d6 + ระดับความรู้ + บุคลิกภาพที่เกี่ยวข้อง (ไม่รวม Mod ค่าพลัง)')),
    h('li',null, T('Saving Throw: ต้านทานผล เลือกไม่ทอยและรับผลได้ · Luck ST ทอยเปล่า ผ่านที่ 8')),
    h('li',null, T('Advantage: 3d6 เก็บ 2 ดีสุด · Disadvantage: 3d6 เก็บ 2 แย่สุด · ได้ทั้งคู่ = ทอยปกติ')),
    h('li',null, T('Attack Roll แบบ Advantage ผู้โจมตีเลือก 2 ลูกเอง · แบบ Disadvantage ฝ่ายรับเลือก 2 ลูกให้ (เป้าไม่ป้องกันหรือมีหลายเป้า GM เลือก) · Parry และ Evade แบบ Advantage ผู้ป้องกันเลือกเอง')),
    h('li',null, T('Critical: [6,6] ผ่านทันทีแม้ต่ำกว่า DC · [1,1] ล้มเหลวทันที ใช้กับ Check และ Saving Throw (Attack/Parry/Evade ไม่นับ Critical)')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'ระดับความยาก (DC)'}), h('table',{class:'t'}, DATA.meta.dc.map(([k,v])=>h('tr',null,h('td',{text:k}),h('td',{class:'num',text:v+(v===14?'+':'')})))), h('p',{class:'dim',style:'font-size:13px',text:'ตัวเลขทุกช่องตรวจกับไฟล์แกนแล้ว'})));
  g.append(h('div',{class:'card'}, h('h3',{text:'การต่อสู้'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Initiative: 2d6 + Initiative Mod ลำดับคงอยู่ทั้งฉาก ซุ่มโจมตีได้เริ่มก่อน')),
    h('li',null, T('เทิร์น: 1 Swift + 1 Basic + 1 Cast (= AP) ไม่ต้องเรียงลำดับ')),
    h('li',null, T('Attack Roll: Combat Dice (2d6) เลือก 2 ลูกเป็น CV เทียบค่าป้องกัน · คู่เลขเดียวกัน = Perfect Strike (Might/Sight ×2) · ตัวปรับ CV บวกทีหลังและไม่ขยับตำแหน่งที่โดน CV ใช้ตัดสินเฉพาะ Evade')),
    h('li',null, T('ไม่ประกาศ Parry/Evade = โดนเต็ม · ฝ่ายรับประกาศวิธีป้องกันหลังเห็นผลทอยโจมตี · Perfect Parry/Evade (ผลรวมเต๋าเท่าผู้โจมตี) ได้ 1 Swift Action ทันที และ Perfect Evade นับว่าหลบสำเร็จเสมอ')),
    h('li',{text:'Hit Location เมื่อโจมตี (ผลรวมเต๋า 2 ลูก): '+hitListText(HIT_ATTACK)+' · แขนเลขคู่ ขาเลขคี่ · เล็งด้วย Focus (Precise) ใช้ตำแหน่งที่ประกาศ'}),
    h('li',null, T('Parry เมื่อป้องกัน: สำเร็จเมื่อผลรวม 2 ลูกที่เลือกอยู่กลุ่มเดียวกับตำแหน่งที่ถูกโจมตี · ' + hitListText(HIT_DEFEND) + ' · ทอยได้สูงสุด 4 ลูก · ติด Disadvantage ทอย 2d6 เปล่าและต้องได้ Perfect Parry เท่านั้น')),
    h('li',null, T('Evade เมื่อป้องกัน: 2d6 + Reflex สูงกว่าหรือเท่ากับ CV ของผู้โจมตี = หลบได้ · ใช้กับการโจมตีระยะประชิดติด Disadvantage')),
    h('li',null, T('เมื่อป้องกันไม่สำเร็จ: หักเกราะของส่วนที่โดนก่อน แล้วส่วนนั้นเสีย Toughness 1 หน่วย เว้นแต่เกราะหักความเสียหายกายภาพจนเหลือ 0')),
    h('li',null, T('Toughness แยกตามอวัยวะ เหลือ 0 = ทอยตารางบาดแผลของส่วนนั้น โดนซ้ำติดลบต่อได้ ติดลบถึงค่าเต็ม = แขนขาขาด ส่วนศีรษะหรือลำตัวให้ผลเท่า Mortal Wound')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'เขต (Zones) แบบไม่มีแผนที่'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('เขตปะทะ 1-3 ม.: โจมตีประชิดกันได้ทุกคนในเขต')),
    h('li',null, T('เขตใกล้เคียง 4-10 ม.: วิ่งเข้าร่วมวงได้ทันที ยิงใส่เขตปะทะได้')),
    h('li',null, T('เขตไกล 11-20+ ม.: ยิงยากขึ้น (ลด CV ตามระยะ) เคลื่อนที่ไปต้องใช้ Swift + 1 AP')),
    h('li',null, T('ระยะยิง: เกินความแม่นยำของระดับ Range เสีย 1 CV ต่อ 10 เมตร นับทุก 10 เมตรที่เริ่มนับ · ยิงเข้าเขตไกลไม่ติด Disadvantage เพราะระยะ ที่กำบังเท่านั้นที่ทำให้ติด')),
    h('li',null, T('AoE: Burst = เป้าหมายหลัก + ตัวที่ "อยู่ติดกันเป็นกลุ่ม" · Cone = ตัวแรกในทิศและตัวที่อยู่ด้านหลัง · Aura = ทุกคนในเขตเดียวกับผู้ร่าย')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'ความก้าวหน้า (IP)'}), h('table',{class:'t'}, DATA.meta.ipTable.map(([k,v])=>h('tr',null,h('td',{text:k}),h('td',{text:v})))), h('p',{class:'dim',style:'font-size:13px',text:'ได้ IP เมื่อจบเซสชั่น +1 · Minor +2 · Major +3 · Epic +4 · บทเรียนจากความล้มเหลว +1 · หนึ่งเหตุการณ์นับชั้นสูงสุดชั้นเดียว รวมไม่เกิน 5 IP ต่อเซสชั่น Epic ครั้งเดียวต่ออาร์ค · ใช้ได้ตอนจบเซสชั่นหรือ Downtime'})));
  g.append(h('div',{class:'card'}, h('h3',{text:'ทรัพยากร'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Max HP = 10 + VIT Mod + STR Mod · Max MP = 10 + INF Mod + INT Mod')),
    h('li',null, T('Toughness = ((Raw VIT + Raw STR)/10) + 1 · Max Sanity = 5 + INF Mod')),
    h('li',null, T('การพัก: ค่า Recovery ของ HP เท่ากับ Max HP ของ MP เท่ากับ Max MP · พักสั้นฟื้นครึ่งหนึ่ง (ปัดลง) · พักยาวฟื้นเต็มและฟื้น Toughness 1 หน่วยในส่วนที่เลือก · ต้องกินเสบียง 1 อัตรา')),
    h('li',null, T('การรักษาแผล (Treat Wound): ระหว่างพักยาว ผู้มี Medical ระดับ 1 ขึ้นไปทอย Medical Check DC 8 ให้คนไข้ ผ่านแล้วฟื้น Toughness เพิ่มอีก 1 หน่วย คนไข้หนึ่งคนรับได้หนึ่งครั้งต่อการพักยาว')),
    h('li',null, T('Passive PER = 7 + PER Mod · Capacity = STR × 3 (Medium) / ×4 (Large) / ×5 (Huge)')),
    h('li',null, T('Mod = (ค่าพลัง / 2) - 5 ปัดลง ช่วง -5 ถึง +5')),
    h('li',null, T('Initiative = PER Mod · Reflex = (AGI Mod/2)+1 · Might = (STR Mod/2)+1 · Sight = (PER Mod/2)+1 · Parry Dice เริ่ม 0 (+1 ต่อโล่) · Toughness: Large +1, Huge +2 คงที่ตลอดชีวิต ยกด้วยอุปกรณ์เท่านั้น')))));
  root.append(g);
}

/* ---- routing: #home #create(สอนเล่น) #wizard #chars #sheet-<id> #table #room-<id> #rules #dev ---- */
const ROUTE_VIEW = { home:'home', create:'tutor', tutor:'tutor', wizard:'create', chars:'chars', sheet:'sheet', table:'table', room:'table', rules:'rules', dev:'dev', maps:'maps', mapedit:'maps', npcs:'npcs', npcedit:'npcs', policy:'policy' };
function devAllowed(){ return !!(Store.isDevUid || (Store.backend==='firebase' && Store.site && !(Store.site.devUids||[]).length) || Store.backend!=='firebase'); }
function route(){
  let hash = location.hash.replace('#','') || 'home';
  let view = hash, arg = null;
  const m = hash.match(/^(sheet|room|mapedit|npcedit)-([a-z0-9]+)$/);
  if (m){ view = m[1]; arg = m[2]; }
  if (!ROUTE_VIEW[view]) { view='home'; }
  if (view==='dev' && Store.ready && !devAllowed()){ location.hash = '#home'; return; }
  for (const v of document.querySelectorAll('.view')) v.classList.remove('active');
  const target = ROUTE_VIEW[view];
  $('#v-'+target).classList.add('active');
  const navKey = view==='room' ? 'table' : (view==='sheet' || view==='wizard') ? 'chars' : (view==='mapedit' ? 'maps' : view==='npcedit' ? 'npcs' : target);
  for (const a of document.querySelectorAll('#nav a')) a.classList.toggle('active', a.dataset.v===navKey);
  document.body.className = document.body.className.replace(/\bbg-\S+/g,'').trim();
  document.body.classList.add(view==='home' || view==='tutor' || view==='create' ? 'bg-study' : 'bg-map');
  document.body.classList.toggle('on-tutor', target==='tutor');
  if (view!=='room' && view!=='sheet' && Table.roomId) Table.close(); // เปิดชีทจากห้องแล้วยังค้างห้องไว้ให้กลับได้
  if (view!=='sheet') HUD.hide();
  if (typeof clearTwins==='function' && view!=='room') clearTwins();
  const changedView = route._last !== hash; route._last = hash;
  switch(view){
    case 'home': renderHome(); break;
    case 'create': case 'tutor': renderTutorial(); break;
    case 'wizard': renderWizard(); break;
    case 'chars': renderChars(); break;
    case 'sheet': renderSheet(arg); break;
    case 'table': renderTableHome(); break;
    case 'room': if (Table.roomId!==arg) Table.open(arg); else renderTable(); break;
    case 'rules': renderRules(); break;
    case 'maps': renderMaps(); break;
    case 'mapedit': renderMapEditor(arg); break;
    case 'npcs': renderNpcs(); break;
    case 'npcedit': renderNpcEditor(arg); break;
    case 'policy': renderPolicy(); break;
    case 'dev': renderDev(); break;
  }
  if (changedView) window.scrollTo(0, 0); // เปลี่ยนหน้า = เริ่มที่หัวหน้า ส่วนการวาดใหม่ในหน้าเดิมคงตำแหน่งเดิม (clearKeep)
}
/* ---- การแสดงผล: ขนาด UI และโหมดสีของชีท (ปุ่ม ⚙ มุมขวาบน) ---- */
function uiSettingsModal(){
  const box = h('div',{class:'uiset'});
  const build = ()=>{ clear(box);
    box.append(h('h3',{text:'การแสดงผล'}), h('p',{class:'desc',style:'margin:4px 0 10px',text:'ค่าพวกนี้จำไว้ในเบราว์เซอร์เครื่องนี้ ไม่ติดไปกับบัญชี'}));
    box.append(h('div',{class:'kicker',text:'ขนาดตัวอักษรและปุ่ม'}), h('div',{class:'row',style:'margin:6px 0 12px'}, [[1,'ปกติ 100%'],[1.15,'ใหญ่ 115%'],[1.3,'ใหญ่มาก 130%'],[1.45,'ใหญ่ที่สุด 145%']].map(([zz,l])=>h('button',{class:'small'+(Math.abs(UI.zoom-zz)<.01?' on':''),onclick:()=>{ UI.zoom = zz; UI.persist(); UI.apply(); build(); },text:l}))));
    box.append(h('div',{class:'kicker',text:'โหมดสีของชีทตัวละคร'}), h('div',{class:'row',style:'margin:6px 0 4px'}, [['paper','☀ กระดาษ (สว่าง)'],['dark','☾ มืด (แบบเดิม)']].map(([t,l])=>h('button',{class:'small'+(UI.theme===t?' on':''),onclick:()=>{ UI.theme = t; UI.persist(); UI.apply(); build(); },text:l}))),
      h('p',{class:'dim',style:'font-size:12px;margin:4px 0 0',text:'มีผลกับชีทตัวละครและหน้าต่างกระเป๋า ถุงย่าม คัมภีร์ ทอยเต๋าในชีท ส่วนอื่นของเว็บเป็นโทนมืดเสมอ'}));
  };
  build(); modal(box);
}
window.addEventListener('hashchange', route);
{ const b = $('#ui-settings'); if (b) b.addEventListener('click', uiSettingsModal); }
Store.listeners.add(()=>{ const hsh=location.hash; if (hsh==='#chars') renderChars(); else if (hsh==='' || hsh==='#home') renderHome(); });
route();
initCapabilities().then(()=>{ Store.ready = true; if (location.hash==='#table') renderTableHome(); if (location.hash==='#chars') renderChars(); if (location.hash==='#maps') renderMaps(); { const me = location.hash.match(/^#mapedit-([a-z0-9]+)$/); if (me) renderMapEditor(me[1]); } if (location.hash==='#npcs') renderNpcs(); { const ne = location.hash.match(/^#npcedit-([a-z0-9]+)$/); if (ne) renderNpcEditor(ne[1]); } if (location.hash==='#dev'){ if (devAllowed()) renderDev(); else location.hash='#home'; } const m = location.hash.match(/^#room-([a-z0-9]+)$/); if (m){ Table.close(); Table.open(m[1]); } if (Store.isDevUid) $('#nav-dev').classList.remove('hidden'); });
// test hook (read-only)
window.__kirana = { compute, roll2d6, judge, DATA, Store, knowledgeLevels, allSkills };
