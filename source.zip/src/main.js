/* ===== Home, rules reference, routing ===== */
W.skFilter = {};
function renderHome(){
  const root = clear($('#v-home'));
  const nChars = Store.chars.filter(c=>c.done).length;
  root.append(h('div',{class:'hero'},
    h('div',null, h('div',{class:'kicker',text:'โลกใต้ม่านมานา'}), h('h1',{text:'เล่น Kirana TTRPG ออนไลน์'}), h('p',{text:'สร้างตัวละครทีละขั้นตามไฟล์แกน V.2 ทุกตัวเลือกบอกว่าได้อะไร คำนวณค่าให้เอง เก็บเป็นชีทที่กดทอยได้ แล้วยกลงโต๊ะเล่นร่วมกับเพื่อนในห้องเดียวกัน'}),
      h('div',{class:'row',style:'margin-top:12px'}, h('button',{class:'primary',onclick:()=>{ startWizard(null); location.hash='#create'; },text:'สร้างตัวละครใหม่'}), h('button',{onclick:()=>{location.hash='#chars';},text:`ตัวละครของฉัน (${nChars})`}), h('button',{onclick:()=>{location.hash='#table';},text:'เข้าโต๊ะเล่น'}))),
    h('div',{class:'card'}, h('h3',{text:'ระบบในฉบับนี้'}), h('ul',{style:'margin:8px 0 0;padding-left:18px;font-size:14px;color:var(--bone-dim)'},
      h('li',{text:`${DATA.kins.length} วงศา · ${DATA.kins.reduce((a,k)=>a+k.childhood.length+k.specialChildhood.length+k.adulthood.length,0)} พื้นหลัง · ${DATA.skills.filter(s=>s.category!=='Granted').length} ทักษะและเวทมนตร์ · ${DATA.knowledge.length} สาขาความรู้ · ${DATA.sets.sets.length} ชุดเริ่มต้น`}),
      h('li',null, T('ทอย 2d6 + Stat + Personality · Advantage/Disadvantage 3d6 · Critical [6,6]/[1,1] · Degrees of Success 10 / 7-9 / 6')),
      h('li',null, T('โต๊ะเล่นแบบ Theater of the Mind: บอร์ดเขตปะทะ/ใกล้เคียง/ไกล ลำดับเทิร์น นาฬิกาชะตากรรม แชตและทอยเต๋าร่วมกัน')),
      h('li',null, 'คำเฉพาะทุกคำที่ขีดเส้นประ ', h('span',{class:'term',onclick:(e)=>showTerm('Mod', e.currentTarget),text:'กดดูความหมายได้'}), ' เช่น Mod, Toughness, Perfect Strike'),
      h('li',null, T('Beastman ยังไม่เปิดให้เลือก (รอข้อมูลอัปเดต)'))))));
  root.append(h('h3',{style:'margin-bottom:8px',text:'8 ขั้นของการสร้างตัวละคร'}));
  root.append(h('div',{class:'quick'}, STEP_DEFS.map((s,i)=>h('div',{class:'card'}, h('h4',{text:s.title}), h('div',{class:'desc',style:'margin-top:4px'}, T(s.blurb))))));
  root.append(h('p',{class:'dim',style:'font-size:12px;margin-top:16px',text:`ข้อมูลจาก ${Object.values(DATA.source).join(' · ')} · ค่าที่ติดป้าย (เสนอ) คือสูตรที่ไฟล์แกนยังไม่ล็อก`}));
}
function renderRules(){
  const root = clear($('#v-rules'));
  root.append(h('h2',{text:'กฎย่อสำหรับโต๊ะ'}));
  const g = h('div',{class:'grid two',style:'margin-top:12px'});
  g.append(h('div',{class:'card'}, h('h3',{text:'การทอยหลัก'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Check: 2d6 + Stat Mod + Personality (ถ้าเข้าบริบท)')),
    h('li',null, T('ไม่มี DC: 10+ Full Success · 7-9 Partial Success (สำเร็จแต่มีราคา) · 6- Failure')),
    h('li',null, T('Clash Throw: ทั้งสองฝ่ายทอย ฝ่ายสูงกว่าชนะ เท่ากันผู้ท้าชนะ (Challenge: ผู้ท้า ≥ ผู้ถูกท้า = สำเร็จ)')),
    h('li',null, T('Saving Throw: ต้านทานผล เลือกไม่ทอยและรับผลได้ · Luck ST ทอยเปล่า ผ่านที่ 8')),
    h('li',null, T('Advantage: 3d6 เก็บ 2 ดีสุด · Disadvantage: 3d6 เก็บ 2 แย่สุด · ได้ทั้งคู่ = ทอยปกติ')),
    h('li',null, T('Critical: [6,6] ผ่านทันทีแม้ต่ำกว่า DC · [1,1] ล้มเหลวทันที')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'ระดับความยาก (DC)'}), h('table',{class:'t'}, DATA.meta.dc.map(([k,v])=>h('tr',null,h('td',{text:k}),h('td',{class:'num',text:v+(v===14?'+':'')})))), h('p',{class:'dim',style:'font-size:13px',text:'ตัวเลขทุกช่องตรวจกับไฟล์แกนแล้ว'})));
  g.append(h('div',{class:'card'}, h('h3',{text:'การต่อสู้'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Initiative: 2d6 + Initiative Mod ลำดับคงอยู่ทั้งฉาก ซุ่มโจมตีได้เริ่มก่อน')),
    h('li',null, T('เทิร์น: 1 Swift + 1 Basic + 1 Cast (= AP) ไม่ต้องเรียงลำดับ')),
    h('li',null, T('Attack Roll: Combat Dice (2d6) เลือก 2 ลูกเป็น CV เทียบค่าป้องกัน · คู่เลขเดียวกัน = Perfect Strike (Might/Sight ×2)')),
    h('li',null, T('ไม่ประกาศ Parry/Evade = โดนเต็ม (ruling P-02) · Perfect Parry/Evade (เลขเหมือนผู้โจมตี) ได้ 1 AP คืน')),
    h('li',{text:'Hit Location: '+DATA.meta.hitLocation}),
    h('li',null, T('Toughness แยกตามอวัยวะ หมด = ทอยตารางบาดแผลของส่วนนั้น (ruling P-01)')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'เขต (Zones) แบบไม่มีแผนที่'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('เขตปะทะ 1-3 ม.: โจมตีประชิดกันได้ทุกคนในเขต')),
    h('li',null, T('เขตใกล้เคียง 4-25 ม.: วิ่งเข้าร่วมวงได้ทันที ยิงใส่เขตปะทะได้')),
    h('li',null, T('เขตไกล 26-100+ ม.: ยิงยากขึ้น (ลด CV ตามระยะ) เคลื่อนที่ไปต้องใช้ Swift + 1 AP')),
    h('li',null, T('AoE: Burst = เป้าหมายหลัก + ตัวที่ "อยู่ติดกันเป็นกลุ่ม" · Cone = ตัวแรกในทิศและตัวที่อยู่ด้านหลัง · Aura = ทุกคนในเขตเดียวกับผู้ร่าย')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'ความก้าวหน้า (IP)'}), h('table',{class:'t'}, DATA.meta.ipTable.map(([k,v])=>h('tr',null,h('td',{text:k}),h('td',{text:v})))), h('p',{class:'dim',style:'font-size:13px',text:'ได้ IP เมื่อจบเซสชั่น +1 · Minor +2 · Major +3 · Epic +4 · บทเรียนจากความล้มเหลว +1 · ใช้ได้ตอนจบเซสชั่นหรือ Downtime'})));
  g.append(h('div',{class:'card'}, h('h3',{text:'ทรัพยากร'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Max HP = 10 + VIT Mod + STR Mod · Max MP = 10 + INF Mod + INT Mod')),
    h('li',null, T('Toughness = ((Raw VIT + Raw STR)/10) + 1 · Max Sanity = 5 + INF Mod')),
    h('li',null, T('Passive PER = 7 + PER Mod · Capacity = STR × 3 (Medium) / ×4 (Large) / ×5 (Huge)')),
    h('li',null, T('Mod = (ค่าพลัง / 2) - 5 ปัดลง ช่วง -5 ถึง +5')))));
  root.append(g);
}

/* ---- routing: #home #create #chars #sheet-<id> #table #room-<id> #rules ---- */
function route(){
  let hash = location.hash.replace('#','') || 'home';
  let view = hash, arg = null;
  const m = hash.match(/^(sheet|room)-([a-z0-9]+)$/);
  if (m){ view = m[1]; arg = m[2]; }
  if (!['home','create','chars','sheet','table','room','rules','dev'].includes(view)) { view='home'; }
  for (const v of document.querySelectorAll('.view')) v.classList.remove('active');
  const target = view==='room' ? 'table' : view;
  $('#v-'+target).classList.add('active');
  for (const a of document.querySelectorAll('#nav a')) a.classList.toggle('active', a.dataset.v===target || (view==='sheet' && a.dataset.v==='chars'));
  if (view!=='room' && Table.roomId) Table.close();
  if (view!=='sheet') HUD.hide();
  switch(view){
    case 'home': renderHome(); break;
    case 'create': renderWizard(); break;
    case 'chars': renderChars(); break;
    case 'sheet': renderSheet(arg); break;
    case 'table': renderTableHome(); break;
    case 'room': if (Table.roomId!==arg) Table.open(arg); else renderTable(); break;
    case 'rules': renderRules(); break;
    case 'dev': renderDev(); break;
  }
}
window.addEventListener('hashchange', route);
Store.listeners.add(()=>{ const hsh=location.hash; if (hsh==='#chars') renderChars(); else if (hsh==='' || hsh==='#home') renderHome(); });
route();
initCapabilities().then(()=>{ if (location.hash==='#table') renderTableHome(); if (location.hash==='#chars') renderChars(); if (location.hash==='#dev') renderDev(); const m = location.hash.match(/^#room-([a-z0-9]+)$/); if (m){ Table.close(); Table.open(m[1]); } if (Store.isDev) $('#nav-dev').classList.remove('hidden'); });
// test hook (read-only)
window.__kirana = { compute, roll2d6, judge, DATA, Store, knowledgeLevels, allSkills };
