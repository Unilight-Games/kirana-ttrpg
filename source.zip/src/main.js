/* ===== Home, rules reference, routing ===== */
W.skFilter = {};
function renderHome(){
  const root = clear($('#v-home'));
  const nChars = Store.chars.filter(c=>c.done).length;
  const go = (hash, isNew)=>{ if (isNew) startWizard(null); location.hash = hash; };
  root.append(h('section',{class:'home'},
    h('div',{class:'home-hero'},
      h('div',{class:'home-text'},
        h('div',{class:'kicker',text:'โลกใต้ม่านมานา'}),
        h('h1',{class:'gothic'}, 'Kirana ', h('span',{class:'thin',text:'TTRPG'})),
        h('p',{class:'lede',text:'โต๊ะเล่นออนไลน์สำหรับคีรันนา โลกที่วงศาทั้งสิบสองอยู่ร่วมกันอย่างกระอักกระอ่วน เวทมนตร์มีราคา และบาดแผลไม่หายเพราะพักหนึ่งคืน สร้างตัวละคร เก็บชีทที่กดทอยได้ แล้วยกลงโต๊ะเดียวกับเพื่อนจากคนละเมือง'}),
        h('div',{class:'row home-actions'},
          h('button',{class:'primary',onclick:()=>{ location.hash='#create'; },text:'ให้เนเมสไซอาร์สอนเล่น'}),
          h('button',{onclick:()=>{ location.hash='#chars'; },text: nChars ? `ตัวละครของฉัน (${nChars})` : 'สร้างตัวละครตัวแรก'}),
          h('button',{class:'ghost',onclick:()=>{ location.hash='#table'; },text:'เข้าโต๊ะเล่น'}))),
      h('div',{class:'home-nem'}, h('div',{class:'home-arch'}), nemImg('smile'))),
    h('div',{class:'nem-box mood-smile home-say'},
      h('div',{class:'nem-side'},
        h('div',{class:'nem-name'}, h('b',{text:NEM.name}), h('span',{class:'dim',text:' · '+NEM.title})),
        h('p',null, T('ยินดีต้อนรับ ลูกรัก เราคือเนเมสไซอาร์ คนที่จะนั่งข้างเจ้าบนโต๊ะนี้ อธิบายว่าลูกเต๋ากลิ้งไปทางไหนและทำไม ที่นี่เจ้าสร้างตัวละครได้ทีละขั้น ทุกตัวเลือกบอกว่าได้อะไร และเราจะยืนคอมเมนต์อยู่ข้าง ๆ ตลอดทาง')),
        h('p',null, T('เกมนี้ไม่ถามว่าเจ้าแข็งแกร่งแค่ไหน มันถามว่าเจ้ายอมเสียอะไรเพื่อให้ได้สิ่งที่ต้องการ ถ้ายังไม่เคยเล่น กด "สอนเล่น" แล้วเราจะเล่าให้ฟังทีละบท ถ้าเคยแล้ว ไปที่ตัวละครของเจ้าได้เลย')))),
    h('h3',{class:'home-h',text:'จุดเด่นของระบบ'}),
    h('div',{class:'grid feat'},
      feat('⚄', 'ลูกเต๋าสองลูกตัดสินทุกอย่าง', 'ทอย 2d6 + Mod + บุคลิกภาพ เทียบ DC 5 / 7 / 10 / 12 / 14 ออก [6,6] ผ่านทันที [1,1] พังทันที Advantage และ Disadvantage ทอยสามลูกเลือกสอง'),
      feat('✦', 'ค่าพลังหกค่า และ Mod ที่ซ่อนอยู่', 'STR AGI VIT PER INF INT ค่าดิบหารสองลบห้า เลขคู่เท่านั้นที่ขยับ Mod ตัวเลขเล็ก ๆ จึงมีความหมายทุกแต้ม'),
      feat('☗', 'Toughness แยกตามอวัยวะ', 'หัว ลำตัว แขนสอง ขาสอง เกราะ A/B ต่อส่วน ตำแหน่งที่โดนมาจากลูกเต๋า แขนที่หายไปไม่งอกกลับมาเพราะพักผ่อน'),
      feat('☾', 'เวทมนตร์ที่มีราคา', 'เวทจ่ายด้วย MP หรือ Sanity สติเป็นทรัพยากรเท่ากับเลือด และ GM เรียกเก็บได้เมื่อเจ้าฝืนนิสัยที่เลือกไว้'),
      feat('◈', 'บุคลิกภาพคือค่าพลังที่เลือกเอง', 'หกคู่ตรงข้าม แจก 3 2 2 1 1 0 ฝั่งที่เลือกเป็นบวก ฝั่งตรงข้ามติดลบเท่ากัน ระบบอ่านนิสัยแล้วบอกสายการเล่นที่เข้ากัน'),
      feat('⚑', 'โต๊ะออนไลน์ แผนที่ 20×20', `สุ่มแผนที่ต่อสู้ตามสถานที่ หมากมีรูปจากชีท ทอยเต๋าเด้งหน้าทุกคนและทอยได้ทีละคน แชต ลำดับเทิร์น และ Insight Point ตามกฎจริง`)),
    h('p',{class:'dim home-foot',text:`${DATA.kins.length} วงศา · ${DATA.kins.reduce((a,k)=>a+k.childhood.length+k.specialChildhood.length+k.adulthood.length,0)} พื้นหลัง · ${DATA.skills.filter(s=>s.category!=='Granted').length} ทักษะและเวทมนตร์ · ${DATA.knowledge.length} สาขาความรู้ · ${DATA.sets.sets.length} ชุดเริ่มต้น · ข้อมูลจาก ${Object.values(DATA.source).join(' · ')} · ค่าที่ติดป้าย (เสนอ) คือสูตรที่ไฟล์แกนยังไม่ล็อก · Beastman ยังไม่เปิดให้เลือก`})));
  function feat(glyph, title, text){ return h('div',{class:'card featcard'}, h('div',{class:'glyph',text:glyph}), h('h4',{text:title}), h('div',{class:'desc'}, T(text))); }
}
function renderRules(){
  const root = clear($('#v-rules'));
  root.append(h('h2',{text:'กฎย่อสำหรับโต๊ะ'}));
  const g = h('div',{class:'grid two',style:'margin-top:12px'});
  g.append(h('div',{class:'card'}, h('h3',{text:'การทอยหลัก'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Check: 2d6 + Stat Mod + Personality (ถ้าเข้าบริบท)')),
    h('li',null, T('ไม่มี DC: 10+ Full Success · 7-9 Partial Success (สำเร็จแต่มีราคา) · 6- Failure')),
    h('li',null, T('Clash Throw: ทั้งสองฝ่ายทอย ฝ่ายสูงกว่าชนะ เท่ากันผู้ท้าชนะ (Challenge: ผู้ท้า ≥ ผู้ถูกท้า = สำเร็จ)')),
    h('li',null, T('Saving Throw: ต้านทานผล เลือกไม่ทอยและรับผลได้ · Luck ST ทอยเปล่า ผ่านที่ 8')),
    h('li',null, T('Advantage: 3d6 เก็บ 2 ดีสุด · Disadvantage: 3d6 เก็บ 2 แย่สุด · ได้ทั้งคู่ = ทอยปกติ')),
    h('li',null, T('Critical: [6,6] ผ่านทันทีแม้ต่ำกว่า DC · [1,1] ล้มเหลวทันที')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'ระดับความยาก (DC)'}), h('table',{class:'t'}, DATA.meta.dc.map(([k,v])=>h('tr',null,h('td',{text:k}),h('td',{class:'num',text:v+(v===14?'+':'')})))), h('p',{class:'dim',style:'font-size:13px',text:'ตัวเลขทุกช่องตรวจกับไฟล์แกนแล้ว'})));
  g.append(h('div',{class:'card'}, h('h3',{text:'การต่อสู้'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Initiative: 2d6 + Initiative Mod ลำดับคงอยู่ทั้งฉาก ซุ่มโจมตีได้เริ่มก่อน')),
    h('li',null, T('เทิร์น: 1 Swift + 1 Basic + 1 Cast (= AP) ไม่ต้องเรียงลำดับ')),
    h('li',null, T('Attack Roll: Combat Dice (2d6) เลือก 2 ลูกเป็น CV เทียบค่าป้องกัน · คู่เลขเดียวกัน = Perfect Strike (Might/Sight ×2)')),
    h('li',null, T('ไม่ประกาศ Parry/Evade = โดนเต็ม (ruling P-02) · Perfect Parry/Evade (เลขเหมือนผู้โจมตี) ได้ 1 AP คืน')),
    h('li',{text:'Hit Location: '+DATA.meta.hitLocation}),
    h('li',null, T('Toughness แยกตามอวัยวะ หมด = ทอยตารางบาดแผลของส่วนนั้น (ruling P-01)')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'เขต (Zones) แบบไม่มีแผนที่'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('เขตปะทะ 1-3 ม.: โจมตีประชิดกันได้ทุกคนในเขต')),
    h('li',null, T('เขตใกล้เคียง 4-25 ม.: วิ่งเข้าร่วมวงได้ทันที ยิงใส่เขตปะทะได้')),
    h('li',null, T('เขตไกล 26-100+ ม.: ยิงยากขึ้น (ลด CV ตามระยะ) เคลื่อนที่ไปต้องใช้ Swift + 1 AP')),
    h('li',null, T('AoE: Burst = เป้าหมายหลัก + ตัวที่ "อยู่ติดกันเป็นกลุ่ม" · Cone = ตัวแรกในทิศและตัวที่อยู่ด้านหลัง · Aura = ทุกคนในเขตเดียวกับผู้ร่าย')))));
  g.append(h('div',{class:'card'}, h('h3',{text:'ความก้าวหน้า (IP)'}), h('table',{class:'t'}, DATA.meta.ipTable.map(([k,v])=>h('tr',null,h('td',{text:k}),h('td',{text:v})))), h('p',{class:'dim',style:'font-size:13px',text:'ได้ IP เมื่อจบเซสชั่น +1 · Minor +2 · Major +3 · Epic +4 · บทเรียนจากความล้มเหลว +1 · ใช้ได้ตอนจบเซสชั่นหรือ Downtime'})));
  g.append(h('div',{class:'card'}, h('h3',{text:'ทรัพยากร'}), h('ul',{style:'padding-left:18px;font-size:14px;color:var(--bone-dim)'},
    h('li',null, T('Max HP = 10 + VIT Mod + STR Mod · Max MP = 10 + INF Mod + INT Mod')),
    h('li',null, T('Toughness = ((Raw VIT + Raw STR)/10) + 1 · Max Sanity = 5 + INF Mod')),
    h('li',null, T('Passive PER = 7 + PER Mod · Capacity = STR × 3 (Medium) / ×4 (Large) / ×5 (Huge)')),
    h('li',null, T('Mod = (ค่าพลัง / 2) - 5 ปัดลง ช่วง -5 ถึง +5')))));
  root.append(g);
}

/* ---- routing: #home #create(สอนเล่น) #wizard #chars #sheet-<id> #table #room-<id> #rules #dev ---- */
const ROUTE_VIEW = { home:'home', create:'tutor', tutor:'tutor', wizard:'create', chars:'chars', sheet:'sheet', table:'table', room:'table', rules:'rules', dev:'dev' };
function devAllowed(){ return !!(Store.isDevUid || (Store.backend==='firebase' && Store.site && !(Store.site.devUids||[]).length) || Store.backend!=='firebase'); }
function route(){
  let hash = location.hash.replace('#','') || 'home';
  let view = hash, arg = null;
  const m = hash.match(/^(sheet|room)-([a-z0-9]+)$/);
  if (m){ view = m[1]; arg = m[2]; }
  if (!ROUTE_VIEW[view]) { view='home'; }
  if (view==='dev' && Store.ready && !devAllowed()){ location.hash = '#home'; return; }
  for (const v of document.querySelectorAll('.view')) v.classList.remove('active');
  const target = ROUTE_VIEW[view];
  $('#v-'+target).classList.add('active');
  const navKey = view==='room' ? 'table' : (view==='sheet' || view==='wizard') ? 'chars' : target;
  for (const a of document.querySelectorAll('#nav a')) a.classList.toggle('active', a.dataset.v===navKey);
  document.body.className = document.body.className.replace(/\bbg-\S+/g,'').trim();
  document.body.classList.add(view==='home' || view==='tutor' || view==='create' ? 'bg-study' : 'bg-map');
  document.body.classList.toggle('on-tutor', target==='tutor');
  if (view!=='room' && view!=='sheet' && Table.roomId) Table.close(); // เปิดชีทจากห้องแล้วยังค้างห้องไว้ให้กลับได้
  if (view!=='sheet') HUD.hide();
  switch(view){
    case 'home': renderHome(); break;
    case 'create': case 'tutor': renderTutorial(); break;
    case 'wizard': renderWizard(); break;
    case 'chars': renderChars(); break;
    case 'sheet': renderSheet(arg); break;
    case 'table': renderTableHome(); break;
    case 'room': if (Table.roomId!==arg) Table.open(arg); else renderTable(); break;
    case 'rules': renderRules(); break;
    case 'dev': renderDev(); break;
  }
}
window.addEventListener('hashchange', route);
Store.listeners.add(()=>{ const hsh=location.hash; if (hsh==='#chars') renderChars(); else if (hsh==='' || hsh==='#home') renderHome(); });
route();
initCapabilities().then(()=>{ Store.ready = true; if (location.hash==='#table') renderTableHome(); if (location.hash==='#chars') renderChars(); if (location.hash==='#dev'){ if (devAllowed()) renderDev(); else location.hash='#home'; } const m = location.hash.match(/^#room-([a-z0-9]+)$/); if (m){ Table.close(); Table.open(m[1]); } if (Store.isDevUid) $('#nav-dev').classList.remove('hidden'); });
// test hook (read-only)
window.__kirana = { compute, roll2d6, judge, DATA, Store, knowledgeLevels, allSkills };
