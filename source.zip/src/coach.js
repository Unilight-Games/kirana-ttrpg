/* ===== เนเมสไซอาร์ยืนคอมเมนต์ข้างวิซาร์ดสร้างตัวละคร =====
 * อ่านสถานะตัวละคร (c, d) แล้วพูด 1-3 บรรทัด: แซว แนะนำ บอกผลต่อเกม คอมโบที่ต่อได้ และเกี่ยวเรื่องราว
 * ข้อความเลือกแบบคงที่ต่อสถานะ (seed) จะได้ไม่เปลี่ยนไปมาทุกครั้งที่หน้าวาดใหม่ */
const Coach = { off: (()=>{ try { return localStorage.getItem('kirana.coach')==='off'; } catch(e){ return false; } })(), lastKey:'' };
function coachHash(s){ let x = 2166136261; for (let i=0;i<s.length;i++){ x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return x >>> 0; }
function coachPick(arr, seed){ return arr[coachHash(seed) % arr.length]; }
const STAT_WORD = { STR:'กำลัง', AGI:'ความคล่อง', VIT:'ความทน', PER:'การรับรู้', INF:'อิทธิพล', INT:'ปัญญา' };

/* ความเห็นต่อวงศา: แซว · สายการเล่น · คอมโบ · เรื่องราว (ค่าตัวเลขดึงจากข้อมูลจริงตอนพูด) */
const COACH_KIN = {
  'lunaryn': { mood:'smile', joke:'ลูนารินหรือ เราเองก็โตมากับคนพวกนี้ อ่านหนังสือเก่ง เถียงเก่ง และตายง่ายพอ ๆ กัน', play:'INF กับ INT เริ่มที่ 10 ส่วนกายหยาบต่ำกว่าค่าเฉลี่ย Extra 14 แต้มคือของขวัญที่ใหญ่ที่สุดของวงศานี้ ใช้มันถมค่าที่เจ้าอยากให้เป็นตัวตน', combo:'Healing Factor ทำให้เจ้าทนการเล่นสายเสี่ยงได้มากกว่าที่ค่าดิบบอก ถ้าเลือก Descendants of Evolver จะยืม Trait ของวงศาอื่นมาได้ แต่ต้องแบก Hindrance ของเขามาด้วย อย่าหยิบแต่ของหวาน', story:'คนเลือดจันทร์ทุกคนมีตระกูลที่ต้องอธิบาย หรือตระกูลที่หนีมา เลือกอย่างใดอย่างหนึ่งแล้วเขียนไว้ GM จะขอบคุณเจ้า' },
  'solrin': { mood:'explain', joke:'ภาคีเปลวสุริยะ คนพวกนี้ยิ้มน้อย สวดมาก และยืนบังหน้าเพื่อนจนเราต้องสั่งให้ถอย', play:'VIT 10 STR 9 เกิดมาเพื่อยืนแถวหน้า Resilient กับ Ring of Fire ทำให้เจ้าเป็นกำแพงที่ร้อน ศัตรูที่ชอบรุมจะเสียใจ', combo:'ดัน VIT ให้ถึง 12 ก่อน แล้ว Talent สาย VIT จะเปิด Robust ให้ ต่อด้วยชุด The Vanguard หรือ The Priest จะได้โล่มา Parry Dice ของเจ้าเริ่มทำงานตั้งแต่เซสชั่นแรก', story:'Path of Honor คือข้อเสียที่ดีที่สุดในการเล่าเรื่อง ถามตัวเองว่าเกียรติของตัวละครนี้เคยทำให้ใครตายไหม' },
  'nightkin': { mood:'smirk', joke:'ไนท์คิน พวกเจ้าเดินเงียบจนเราเคยเหยียบคนหนึ่งในความมืด เขาไม่โกรธ แค่กัดเราเฉย ๆ', play:'AGI 10 PER 10 Dark Vision และ Iron Stomach กินอะไรก็ได้ เห็นอะไรก็ได้ นี่คือวงศาของคนที่ไปก่อนแล้วกลับมาเล่าว่าข้างหน้ามีอะไร', combo:'ถ้าดัน PER ให้นำ Talent สาย PER มี Observation Mastery กับ Interceptor ให้เลือก คู่กับชุด The Hunter หรือ The Convict แล้วเจ้าจะยิงก่อนที่ใครจะรู้ว่ามีคนอยู่', story:'Savage Heart เป็นข้อเสียที่ GM ชอบ เขียนไว้เลยว่าอะไรทำให้ตัวละครนี้หลุด และใครเคยเห็นมัน' },
  'rimmen': { mood:'ask', joke:'คนชายขอบ ไม่มีบ้าน ไม่มีเทพ มีแต่ปาก และปากนั่นแหละที่พาพวกเจ้ารอดมาได้ทุกครั้ง', play:'INT 11 INF 10 ร่างกายเปราะ Mortal Frailty ทำให้ตายง่ายกว่าคนอื่น ชดเชยด้วย Cross-Cultural Adaptation ที่เลือกได้ว่าจะทนอะไร', combo:'ค่า INT 11 เป็นเลขคี่ แต้ม Extra แรกที่ใส่ลง INT จะดัน Mod เป็น +1 ทันที คุ้มที่สุดในบรรดาทุกวงศา ต่อด้วย Talent สาย INT หรือ Educated แล้วไปชุด The Scholar The Merchant หรือ The Minstrel', story:'ถามว่าตัวละครนี้เรียกที่ไหนว่าบ้าน ถ้าตอบไม่ได้ นั่นแหละคือเรื่องราว' },
  'norlan': { mood:'surprise', joke:'ชาวนอร์ลัน ตัวใหญ่ เสียงดัง กินเก่ง เราเคยเลี้ยงอาหารกองทัพนอร์ลันหนึ่งคืน เสบียงหมดไปสามเดือน', play:'STR 12 ตั้งแต่เกิด ขนาด Large แบกได้ ×4 Toughness บวกหนึ่งจากขนาด แต่ AGI 6 กับ INF 6 คือราคา Mod −2 สองตัว อย่าฝืนเล่นนักพูด', combo:'STR 12 คือ Mod +1 แล้ว ดันเป็น 14 จะ +2 เปิด Talent สาย STR ที่ให้ Stance กับ Qi ชุด The Vanguard หรือ The Reaver รับต่อพอดี Giant Slayer ทำให้เจ้าเป็นคนที่โต๊ะส่งไปสู้กับของตัวใหญ่', story:'Caloric Furnace แปลว่าเจ้าหิวตลอดเวลา GM ที่ดีจะใช้เรื่องนี้ และเราคือคนที่สอน GM เรื่องนี้' },
  'day-alves': { mood:'think', joke:'เดย์อัลฟ์ สวย เร็ว อายุยืน และกลัวสัตว์ร้ายจนเราต้องอุ้มข้ามแม่น้ำครั้งหนึ่ง เขาไม่เคยให้อภัยเรา', play:'AGI 14 เริ่มที่ Mod +2 PER INF INT 12 อีกสามค่า แต่ STR 5 VIT 5 คือ Mod −3 สองตัว HP เริ่มที่ 4 ลูกรัก สี่ อย่าให้ใครตีถึงตัว', combo:'Precision as Truth กับอาวุธระยะคือทางที่เกิดมาเพื่อสิ่งนี้ ดัน AGI เป็น 16 รับ Talent สาย AGI แล้วไปชุด The Hunter หรือ The Gunslinger Extra มีแค่ 10 แบ่งไปถม VIT สักสองสามแต้มเถอะ เราขอ', story:'Long-Lived Perspective หมายความว่าตัวละครนี้เคยเห็นเมืองที่คนอื่นเรียกว่าโบราณตอนที่มันยังใหม่ ใช้มันเวลาคุยกับ NPC' },
  'night-alves': { mood:'shush', joke:'ไนท์อัลฟ์ พวกเจ้าจำความแค้นได้แม่นกว่าจำชื่อลูก เราพูดจากประสบการณ์', play:'VIT 13 AGI 12 PER 12 แข็ง เร็ว ตาดี แต่ INT 5 คือ Mod −3 อย่าให้ตัวละครนี้เป็นคนอ่านแผนที่', combo:'Nimble Grace ติดตัวมาแล้ว ถ้าเลือก Talent สาย AGI เว็บจะให้เจ้าเลือก Tactical & General Skill แทนที่จะได้ซ้ำ VIT 13 ใส่ Extra หนึ่งแต้มเป็น 14 ได้ Mod +2 ทันที ชุด The Convict หรือ The Hunter เข้าทาง', story:'Vengeful Spirit ต้องมีชื่อคนที่ตัวละครแค้น เขียนชื่อนั้นไว้ในเรื่องราว แล้วรอดูว่า GM จะเอาเขาโผล่มาเมื่อไร' },
  'handerlaw-dwarves': { mood:'explain', joke:'ดวอร์ฟแฮนเดอร์ลอว์ ตัวเตี้ยที่สุดและแบกของได้มากที่สุด เราเคยถามว่าทำไมไม่พักบ้าง เขาตอบว่าพักคืออะไร', play:'STR 14 VIT 15 ตั้งแต่เกิด Steel Bone กับ Powerful Build ทำให้เจ้าเป็นคนตัวเล็กที่ไม่มีใครผลักได้ แต่ AGI 6 INF 5 ช้าและพูดไม่เก่ง', combo:'VIT 15 เป็นเลขคี่ หนึ่งแต้มเป็น 16 Mod +3 คุ้มมาก Mountain Craftsman จับคู่กับชุด The Craftsman หรือ The Alchemist แล้วตัวละครนี้จะซ่อมของให้ทั้งปาร์ตี้ ขายได้ด้วย', story:'Fear of Open Spaces ในโลกที่แผนที่ส่วนใหญ่เป็นที่โล่ง นี่คือเรื่องราวที่เขียนตัวเองได้ทุกฉาก' },
  'swalan': { mood:'think', joke:'สวาลัน หน้านิ่งจนเราเล่นมุขไปสามเรื่องแล้วไม่รู้ว่าเขาขำหรือเปล่า เขาบอกทีหลังว่าขำทั้งสาม', play:'PER 12 INF 12 STR 10 Mana Sight เห็นมานา Soul Chamber ทนทางใจ ตัวละครนี้คือคนที่รู้ว่าอะไรกำลังผิดปกติก่อนใคร', combo:'Mana Hunger ต้องมีมานาป้อนอยู่เสมอ สายเวทจึงเข้าตัวกว่าสายกาย Talent สาย PER หรือ INF ต่อด้วยชุด The Grave Keeper หรือ The Priest แล้วใช้ Unfeeling Body ยืนรับแทนคนที่เจ็บเป็น', story:'Still Face ทำให้คนไม่เชื่อว่าเจ้าหวังดี เขียนไว้ว่าใครคือคนเดียวที่อ่านหน้าตัวละครนี้ออก' },
  'floran': { mood:'smile', joke:'ฟลอรัน พวกเจ้าสังเคราะห์แสงได้ เราอิจฉาที่สุด เราต้องทำอาหารกินทุกวัน', play:'PER 14 INF 14 เริ่มที่ Mod +2 สองตัว สายควบคุมและสนับสนุนที่แข็งที่สุดในสิบสองวงศา แต่ STR 6 แบกได้แค่ 18 กิโลกรัม ชุดหนักเกือบทุกชุดจะเกินแบก ดูน้ำหนักก่อนเลือก', combo:'Fairy Ring กับ Floran Nectar ทำให้เจ้าเป็นฐานของปาร์ตี้ Talent สาย INF ให้ Tactical Expert มาด้วย ต่อด้วยชุด The Minstrel หรือ The Plague Doctor แล้วเพื่อนจะรักเจ้า ศัตรูจะเกลียดเจ้าก่อนคนอื่น', story:'Possessive Territory ตัวละครนี้มีที่ที่หวง ถามว่าใครกำลังคุกคามมัน แล้วเจ้าจะได้แรงจูงใจมาฟรี ๆ' },
  'orcarim': { mood:'mad', joke:'ออร์คาริม ซื่อสัตย์จนโกหกไม่ได้แม้แต่ตอนเล่นไพ่ เราชนะเงินพวกเจ้ามาเยอะ และรู้สึกผิดทุกครั้ง', play:'STR 14 VIT 15 Muscle Memory กับ Spring Biceps ตีหนัก ตีแม่น แต่ INF 6 INT 6 Mod −2 สองตัว และ Honest Heart ทำให้เจ้าหลอกใครไม่ได้เลย', combo:'VIT 15 หนึ่งแต้มเป็น 16 Mod +3 หรือ STR 14 สองแต้มเป็น 16 เลือกเอาว่าจะทนหรือจะตี Talent สาย STR ให้ Stance กับ Qi ชุด The Reaver The Samurai หรือ The Vanguard ขนาด Large แบก ×4 ไม่ต้องห่วงน้ำหนัก', story:'Instinct-Driven แปลว่าตัวละครนี้ลงมือก่อนคิด เขียนไว้ว่าครั้งล่าสุดที่มันพาเดือดร้อนคือเมื่อไร GM จะต่อให้เอง' },
  'necrobug': { mood:'surprise', joke:'เนโครบัค พูดไม่ได้ แต่สื่อสารด้วยกลิ่นและขน เราเรียนภาษานี้อยู่สามเดือน ตอนนี้ยังพูดได้แค่ "หิว" กับ "อันตราย"', play:'STR 12 VIT 12 PER 11 Layered Chitin คือเกราะติดตัว Walking Ecosystem ทำให้เจ้าไม่ต้องห่วงเรื่องกิน แต่ Voiceless ทำให้ทุกบทสนทนาเป็นงานของเพื่อนร่วมทีม', combo:'PER 11 เลขคี่ หนึ่งแต้มเป็น 12 Mod +1 ทันที Non-Humanoid Limbs มีผลกับของสวมใส่ ดูช่องถุงย่ามในชีทให้ดี Talent สาย VIT หรือ STR ชุด The Vanguard หรือ The Wanderer', story:'ตัวละครที่พูดไม่ได้คือตัวละครที่โต๊ะจะจดจำ ถ้าเจ้าเล่นให้ถึง เขียนไว้ว่ามันสื่อสารกับใครในปาร์ตี้ได้ดีที่สุด และทำไม' },
};
/* ความเห็นต่อ Talent ที่เลือก */
const COACH_TALENT = {
  INT: { mood:'explain', text:'สาย INT ได้ Sorcery ระดับ Novice สองอย่างและยกความรู้สองสาขา เวทในคีรันนาจ่ายด้วย MP หรือ Sanity อ่านช่อง Cost ให้ครบ MP ของเจ้าตอนนี้คือ {mp} Sanity {sanity} ถ้า Sanity ต่ำ เลือกเวทที่กิน MP เป็นหลัก' },
  PER: { mood:'think', text:'สาย PER เลือกได้ระหว่าง Observation Mastery กับ Interceptor อย่างแรกทำให้เจ้าเห็นก่อน อย่างหลังทำให้เจ้าขยับก่อน ถ้าถืออาวุธระยะ Interceptor ให้เทิร์นแรกที่โหดกว่า ถ้าเป็นคนสืบ Observation คุ้มกว่า' },
  INF: { mood:'smirk', text:'สาย INF แถม Tactical Expert มาให้เลย นั่นคือสกิลสั่งการที่ทำให้เพื่อนทั้งโต๊ะเก่งขึ้น ตัวละครนี้จะเป็นคนที่ทุกคนหันมาถามว่าเอายังไงต่อ เตรียมคำตอบไว้ให้ดี ลูกรัก' },
  AGI: { mood:'smile', text:'สาย AGI ได้ Nimble Grace แล้วเลือก Qi Trick หรือ Unarmed สองอย่าง สายนี้ชนะด้วยการไม่โดน Reflex ของเจ้าตอนนี้ {reflex} Evade จะเป็นเพื่อนสนิท อย่าใส่เกราะหนักจนขยับไม่ได้' },
  STR: { mood:'mad', text:'สาย STR หยิบ Stance หรือ Qi หนึ่ง Martial อีกหนึ่ง แล้วยกความรู้ Melee ตัวละครนี้ตีแล้วต้องเจ็บ Might ของเจ้าตอนนี้ {might} คูณสองตอน Perfect Strike ยืนให้ถูกช่องแล้วทุกอย่างจะตามมา' },
  VIT: { mood:'explain', text:'สาย VIT ได้ Robust ทนร้อนทนหนาว แล้วเลือก Stance หรือ Qi สองอย่าง สายนี้ไม่ได้เก่งที่สุดในเทิร์นแรก แต่เป็นคนสุดท้ายที่ยังยืนอยู่ HP {hp} Toughness {tough} ต่ออวัยวะ ดูแลโล่ให้ดี' },
  EDU: { mood:'ask', text:'Educated หรือ คนที่เลือกทางนี้คือคนที่ไม่ยอมให้ค่าดิบตัดสินว่าตัวเองเป็นใคร ยกความรู้สาขาที่อยากได้ แล้วเลือกสองทักษะจาก Sorcery Martial หรือ Survival กว้างที่สุดในเจ็ดสาย เหมาะกับตัวละครที่มีเรื่องราวมากกว่ามีกล้าม' },
};
/* ความเห็นต่อคู่บุคลิกภาพที่ได้ 3 (ฝั่งซ้าย/ขวา) */
const COACH_PERS3 = {
  logic: ['ตรรกะ +3 ตัวละครนี้จะคิดก่อนทุกครั้ง และทุกครั้งที่ต้องทำตามสัญชาตญาณจะติด −3 เวลาหนีไฟ อย่าหยุดคำนวณ', 'สัญชาตญาณ +3 ลงมือก่อนคิดเสมอ เวลาต้องวางแผนจะได้ −3 ให้เพื่อนวางแผน เจ้ามีหน้าที่ทำให้แผนพัง หรือทำให้มันสำเร็จ'],
  confront: ['เผชิญหน้า +3 ประตูทุกบานถูกถีบเปิด ดีสำหรับแทงค์และไฟท์เตอร์ แต่ตอนต้องแอบจะได้ −3 เราแนะนำให้มีเพื่อนที่เงียบกว่าเจ้าสักคน', 'หลบเลี่ยง +3 ตัวละครนี้ไม่สู้ถ้าไม่จำเป็น เหมาะกับโร้กและคนยิงไกล แต่เวลาต้องยืนบังเพื่อน −3 จะทำให้เจ้าเจ็บ'],
  brave: ['กล้าหาญ +3 เดินเข้าความมืดคนแรก GM จะรักเจ้า และจะฆ่าเจ้าด้วยความรัก ทุกการทอยที่ต้องระแวดระวังติด −3 เห็นกับดักไม่ออกคืองานประจำ', 'ระแวดระวัง +3 เห็นกับดักก่อนใคร ไม่ไว้ใจใคร เหมาะกับคนสืบและคนเฝ้ายาม แต่เวลาต้องกล้า −3 จะทำให้ตัวละครนี้ลังเลตอนที่ไม่ควร'],
  others: ['ส่วนรวม +3 ยอมเจ็บแทนเพื่อน เหมาะกับแทงค์และซัพพอร์ต แต่เวลาที่ต้องเอาตัวรอดคนเดียว −3 นั่นคือฉากที่ตัวละครแบบนี้ตาย เขียนไว้ก่อนว่ายอมไหม', 'รักตัวเอง +3 เอาตัวรอดก่อน ไม่มีใครว่า เหมาะกับโร้กและพ่อค้า แต่เพื่อนร่วมโต๊ะจะจำได้ว่าเจ้าทิ้งใคร และ GM ก็จำได้'],
  compassion: ['เห็นอกเห็นใจ +3 แม้แต่ศัตรูก็สงสาร นี่คือตัวละครที่เรื่องราวดีที่สุดเกิดขึ้นรอบตัว และเป็นตัวละครที่ถูกหลอกบ่อยที่สุด −3 ตอนต้องเด็ดขาด', 'เลือดเย็น +3 ลงมือโดยไม่ไหวติง ดาเมจดีลเลอร์ชอบค่านี้ แต่ระวัง GM เรียก Sanity ตอนเจ้าโหดเกินไป และ −3 เวลาต้องปลอบใคร'],
  order: ['ระเบียบ +3 กฎคือทุกอย่าง เหมาะกับทหารและนักบวช คอนโทรลเลอร์ก็ชอบ แต่เวลาต้องด้นสด −3 แผนที่พังคือฝันร้ายของตัวละครนี้', 'ไร้ระเบียบ +3 คาดเดาไม่ได้ เหมาะกับสไตรเกอร์และโร้ก แต่ทุกอย่างที่ต้องทำตามขั้นตอน −3 อย่าให้ตัวละครนี้เป็นคนถือกุญแจ'],
};

function coachCompute(c, d, step){
  const kin = c.kin ? KIN[c.kin] : null;
  const seed = (c.id||'') + '|' + step + '|' + (c.kin||'') + '|' + (c.childhood||'') + '|' + (c.adulthood||'') + '|' + (c.talent||'') + '|' + (c.starterSet||'');
  const out = { mood:'smile', lines:[] };
  const say = (m, ...t)=>{ if (m) out.mood = m; for (const x of t) if (x) out.lines.push(x); };
  const bs = budgetState(c);
  const prof = (c.kin && !bs.left.length) ? personalityProfile(c, d) : null;
  const oddStats = STATS.filter(s => d.raw[s] % 2 === 1);
  const nearMod = STATS.filter(s => (d.raw[s]+1) % 2 === 0 && d.raw[s] < 20);
  switch (step){
    case 0: { // วงศา
      if (!kin){ say('ask', coachPick(['เริ่มจากคำถามแรกของทุกชีวิต เจ้าเกิดมาเป็นอะไร การ์ดบอกจุดเด่นจุดด้อย แต่ค่าดิบข้างล่างต่างหากที่บอกว่าเจ้าจะทอยอะไรได้ดี', 'สิบสองวงศา สิบสองวิธีที่จะเจ็บ เลือกจากเรื่องราวที่อยากเล่าก่อน ตัวเลขค่อยตามมา เราช่วยเรื่องตัวเลขได้ แต่เรื่องราวต้องเป็นของเจ้า', 'อย่าเพิ่งมองแต่ค่าสูงสุด มองข้อเสียด้วย Hindrance ที่เจ้ารับได้คือ Hindrance ที่จะทำให้ตัวละครนี้น่าจดจำ'], seed)); break; }
      const K = COACH_KIN[kin.id] || {};
      const hi = STATS.slice().sort((a,b)=>kin.raw[b]-kin.raw[a]); const lo = hi[hi.length-1];
      say(K.mood||'smile', K.joke, K.play || `ค่าดิบสูงสุดคือ ${hi[0]} ${kin.raw[hi[0]]} ต่ำสุดคือ ${lo} ${kin.raw[lo]} ตรงนั้นคือจุดที่ศัตรูจะหาเจอ`, K.combo);
      if (kin.sizes.length > 1) say(null, `วงศานี้เลือกขนาดได้ ${kin.sizes.join(' หรือ ')} ขนาดมีผลกับการแบกและ Toughness ดูตัวเลือกใต้การ์ด`);
      if (kin.id==='lunaryn' && c.evolver && c.evolver.kin) say('smirk', `ยืมของ ${KIN[c.evolver.kin] ? KIN[c.evolver.kin].name : c.evolver.kin} มาหรือ จำไว้ว่า Hindrance ของเขาก็มาด้วย เลือกให้ครบทั้งสองช่อง ไม่งั้นเราไม่ปล่อยไปขั้นต่อไป`);
      break; }
    case 1: { // พื้นหลัง
      if (!kin){ say('guilty', 'เลือกวงศาก่อนสิ ลูกรัก พื้นหลังของแต่ละวงศาไม่เหมือนกัน'); break; }
      const ch = findBg(kin, c.childhood), ad = findBg(kin, c.adulthood);
      if (!ch && !ad){ say('explain', 'สองใบ วัยเด็กกับวัยผู้ใหญ่ แต่ละใบให้แต้มกับ Trait มองหาใบที่ดันค่าที่เจ้าอยากให้นำไปถึงเลขคู่ และใบที่ Trait เข้ากับวิธีเล่นที่คิดไว้ ส่วนเรื่องราว เลือกคู่ที่มีช่องว่างระหว่างกัน เด็กที่เป็นอย่างหนึ่งแล้วโตมาเป็นอีกอย่าง มีคำถามว่าเกิดอะไรขึ้นตรงกลาง นั่นแหละตัวละคร'); if (K_story(kin)) say(null, K_story(kin)); break; }
      const bgLine = (label, b)=>{ const st = Object.entries(b.stats||{}); const hits = st.filter(([k])=>d.raw[k] % 2 === 0).map(([k])=>k); const txt = st.map(([k,v])=>`${signed(v)} ${k}`).join(' '); return `${label} "${b.name}" ให้ ${txt}` + (hits.length ? ` ค่า ${hits.join(' ')} ลงที่เลขคู่พอดี Mod ขยับจริง` : ` แต้มยังค้างที่เลขคี่ เก็บไว้เติม Extra ขั้นที่สี่`); };
      if (ch) say('explain', bgLine('วัยเด็ก', ch));
      if (ad) say(null, bgLine('วัยผู้ใหญ่', ad));
      if (ch && ad){
        const both = Object.keys(ch.stats||{}).filter(k => (ad.stats||{})[k]);
        if (both.length) say('smirk', `ทั้งสองใบดัน ${both.join(' ')} ซ้อนกัน ชัดเจนว่าตัวละครนี้เป็นใคร คนที่ชัดเจนเล่นสนุกกว่าคนที่เก่งทุกอย่างนิดหน่อย`);
        else say('think', 'สองใบไม่ซ้อนค่ากัน กระจายดี แต่ตอนแจก Extra ต้องเลือกแล้วว่าจะให้ใครนำ อย่าถมทุกค่าทีละนิด เลขคี่ไม่ให้อะไร');
        say('ask', coachPick([`เด็กที่เป็น${ch.name} แล้วโตมาเป็น${ad.name} ระหว่างนั้นเกิดอะไรขึ้น เขียนคำตอบไว้ตอนขั้นที่เจ็ด แค่สองบรรทัดก็พอ`, `${ch.name}ที่กลายเป็น${ad.name} ใครเป็นคนพาไป หรือใครเป็นคนพรากไป คำตอบนั้นคือ NPC ตัวแรกของเจ้า`, `จาก${ch.name}ถึง${ad.name} ใช้เวลากี่ปี และช่วงนั้นตัวละครเสียอะไรไป เราถามเพราะเรื่องที่ดีมักเริ่มจากสิ่งที่หายไป`], seed));
        if (ch.statsChoice && (c.choiceStats||[]).length !== ch.statsChoice.count) say('panic', `ใบวัยเด็กนี้ให้เลือกค่าพลังเอง ${ch.statsChoice.count} ค่า ยังเลือกไม่ครบนะ`);
      } else say('ask', ch ? 'แล้วโตมาเป็นอะไรล่ะ เลือกวัยผู้ใหญ่ด้วย' : 'เลือกวัยเด็กด้วย ทุกคนเคยเป็นเด็ก แม้แต่เรา เชื่อเถอะ');
      break; }
    case 2: { // บุคลิกภาพ
      const three = DATA.meta.personality.find(ax => c.personality[ax.id] && c.personality[ax.id].value === 3);
      if (!bs.used.length){ say('ask', coachPick(['คำถามที่เราชอบที่สุด ตัวละครนี้เป็นคนแบบไหน ให้ 3 กับสิ่งที่นิยามเขาหรือนางมากที่สุด เพราะค่านั้นจะโผล่มาในทุกการทอยที่เข้าบริบท และจะเป็น −3 ในทุกครั้งที่ต้องทำตรงข้าม', 'เริ่มจากคู่ที่ให้ 0 ก่อนก็ได้ คู่ที่ตัวละครนี้ไม่แคร์เลย ที่เหลือจะเรียงตัวง่ายขึ้น', 'อย่าเลือกตามวงศา เลือกตามคน นอร์ลันที่ระแวดระวังหรือฟลอรันที่เลือดเย็นเล่นสนุกกว่าแบบที่ทุกคนคาดไว้'], seed)); break; }
      if (three){ const p = c.personality[three.id]; say('explain', COACH_PERS3[three.id][p.side==='left'?0:1]); }
      if (bs.left.length){ say(null, `เหลือค่า ${bs.left.join(', ')} ให้แจกอีก ${bs.left.length} คู่`); }
      else if (prof){
        const t = prof.top[0], t2 = prof.top[1];
        say('smile', `อ่านออกแล้ว ตัวละครนี้คือ${t.th}${t2 ? ` ที่มีกลิ่นของ${t2.th}` : ''} ตามนิสัยที่เลือก Talent ที่เข้าทางคือสาย ${t.talent.map(x=>x==='EDU'?'Educated':x).join(' หรือ ')}${prof.sets.length ? ` ชุดเริ่มต้นที่เข้ากัน ${prof.sets.join(', ')}` : ''}`);
        const ruth = persMod(c,'Ruthless'), self = persMod(c,'Self'), brave = persMod(c,'Brave'), caut = persMod(c,'Cautious');
        if (ruth >= 2 && self >= 2) say('shush', 'เลือดเย็นและรักตัวเอง เราเคยนำทัพกับคนแบบนี้ เก่งมาก และเราไม่เคยหันหลังให้เขา บอก GM ไว้ว่าตัวละครนี้มีเส้นที่ไม่ข้ามสักเส้น ไม่งั้นโต๊ะจะเหนื่อย');
        if (brave >= 2 && persMod(c,'Others') >= 2) say('guilty', 'กล้าหาญและเห็นแก่ส่วนรวม ตัวละครแบบนี้ตายสวยที่สุดในเกมนี้ เราแค่บอกไว้ก่อน');
        if (caut >= 2 && persMod(c,'Logic') >= 2) say('smirk', 'ระแวดระวังและมีตรรกะ ตัวละครนี้จะเป็นคนที่เห็นกับดักก่อนทุกคน และเป็นคนที่เพื่อนไม่ฟังจนกว่ากับดักจะทำงาน');
        if (persMod(c,'Chaos') >= 2 && persMod(c,'Instinct') >= 2) say('surprise', 'ไร้ระเบียบและใช้สัญชาตญาณ GM จะไม่มีวันเตรียมฉากทัน เราชอบ เพื่อนร่วมโต๊ะอาจไม่ชอบ');
      }
      break; }
    case 3: { // Extra
      if (!kin){ say('guilty', 'เลือกวงศาก่อน แต้ม Extra มากับวงศา'); break; }
      if (d.extraLeft > 0){
        say('explain', `เหลือ ${d.extraLeft} แต้ม กฎข้อเดียวที่ต้องจำ เลขคู่เท่านั้นที่ขยับ Mod` + (nearMod.length ? ` ตอนนี้ ${nearMod.map(s=>`${s} ${d.raw[s]}`).join(' · ')} อยู่ห่าง Mod ถัดไปแค่หนึ่งแต้ม` : ' ตอนนี้ทุกค่าอยู่ที่เลขคู่ สองแต้มต่อหนึ่ง Mod'));
        if (prof) say(null, `ตามนิสัยที่เลือก ปุ่ม Auto Fill สาย ${prof.top[0].id} ถูกไฮไลต์ไว้ กดแล้วปรับทีหลังได้ แต่ถ้าเจ้ารู้แล้วว่าอยากเป็นอะไร ไม่ต้องฟังปุ่ม`);
        const weakest = STATS.slice().sort((a,b)=>d.raw[a]-d.raw[b])[0];
        if (d.mod[weakest] <= -2) say('think', `${weakest} ${d.raw[weakest]} Mod ${signed(d.mod[weakest])} จะเป็นจุดที่ศัตรูเล็ง ถมมันหรือยอมรับมัน ทั้งสองทางถูก แต่ต้องเลือกโดยรู้ตัว`);
      } else if (d.extraLeft < 0) say('panic', `ใช้เกินไป ${-d.extraLeft} แต้ม เอาคืนมาก่อน เราไม่ปล่อยให้โกงต่อหน้าเรา`);
      else {
        const hiList = d.highest.join(' และ ');
        say('smile', `ครบพอดี ค่าที่นำคือ ${hiList} Mod ${signed(d.mod[d.highest[0]])} ขั้นต่อไป Talent สาย ${hiList} จะเปิดให้เลือก หรือเลือก Educated ก็ได้เสมอ`);
        if (oddStats.length) say('smirk', `${oddStats.map(s=>`${s} ${d.raw[s]}`).join(' · ')} ค้างที่เลขคี่ แต้มพวกนี้ยังไม่ให้อะไรตอนนี้ ถ้าอยากให้คุ้มทุกแต้ม ย้ายหนึ่งแต้มไปให้ค่าอื่นที่ใกล้เลขคู่ หรือเก็บไว้เป็นเรื่องราวว่าตัวละครนี้เกือบเก่งเรื่องนั้น`);
        else say(null, 'ทุกค่าลงเลขคู่หมด ไม่มีแต้มเสียเปล่า เราภูมิใจ');
        if (d.hp <= 7) say('panic', `HP ${d.hp} ลูกรัก ดาบหนึ่งเล่มก็จบ ถ้ายังไม่ได้ตั้งใจเล่นสายหลบ ย้ายแต้มไป VIT หรือ STR สักหน่อย`);
        if (d.sanity <= 4) say('shush', `Sanity ${d.sanity} ต่ำ ตัวละครนี้จะเสียสติง่าย เหมาะกับเรื่องสยองขวัญ ไม่เหมาะกับเวทที่กิน Sanity`);
      }
      break; }
    case 4: { // Talent
      if (!c.talent){
        say('explain', `Talent เปิดตามค่าที่ Mod สูงสุด ตอนนี้คือ ${d.highest.join(' และ ')} ${prof && prof.talentHint.length ? `ตามนิสัยที่เลือก เราแนะนำสาย ${prof.talentHint.map(t=>t==='EDU'?'Educated':t).join(' หรือ ')}` : ''} Educated เลือกได้เสมอถ้าอยากกว้างกว่าลึก`);
        say('ask', 'ขั้นนี้ยาวที่สุด ทักษะทุกใบบอกว่าทำอะไร ราคาเท่าไร และต้องการอะไร อ่านช่อง Cost ก่อนช่องดาเมจเสมอ');
      } else {
        const K = COACH_TALENT[c.talent]; if (K) say(K.mood, K.text.replace('{mp}', d.mp).replace('{sanity}', d.sanity).replace('{reflex}', signed(d.reflex)).replace('{might}', signed(d.might)).replace('{hp}', d.hp).replace('{tough}', d.toughness));
        const blocker = stepBlocker(4);
        if (blocker) say('ask', `ยังขาดอยู่ ${blocker}`);
        else { const sk = allSkills(c); say('smile', `ครบแล้ว ทักษะติดตัว ${sk.length} อย่าง${sk.length ? ` ${sk.slice(0,4).join(', ')}${sk.length>4?' และอื่น ๆ':''}` : ''} เปิดคัมภีร์ในชีทแล้วอ่านทุกใบก่อนลงโต๊ะ`); }
      }
      break; }
    case 5: { // คำนวณ
      say('explain', `HP ${d.hp} MP ${d.mp} Sanity ${d.sanity} Toughness ${d.toughness} ต่ออวัยวะ แบกได้ ${d.capacity} กิโลกรัม`);
      if (d.hp <= 8) say('guilty', 'HP น้อย ตัวละครนี้ต้องประกาศ Parry หรือ Evade ทุกครั้งที่โดนโจมตี ไม่มีข้อยกเว้น และควรมีเพื่อนตัวใหญ่ยืนข้างหน้า');
      else if (d.hp >= 14) say('smirk', 'HP หนา ยืนรับได้ แต่อย่าลืมว่า Toughness ต่ออวัยวะต่างหากที่ตัดสินว่าแขนยังอยู่ไหม HP เยอะแต่แขนหักก็ถือดาบไม่ได้');
      if (d.mod.INF < 0) say('think', 'INF ติดลบ Sanity ต่ำกว่าคนทั่วไป เวลา GM เรียก Saving Throw ทางใจ ให้เพื่อนที่พูดเก่งเป็นคนเจรจา ตัวละครนี้มีหน้าที่อื่น');
      if (d.toughness >= 4) say(null, 'Toughness สูง บาดแผลฉกรรจ์จะมาถึงช้า นี่คือคนที่โต๊ะจะส่งไปยืนรับอะไรก็ตามที่น่ากลัว');
      if (d.capacity < 24) say('panic', `แบกได้แค่ ${d.capacity} กิโลกรัม ชุดเริ่มต้นหลายชุดหนักเกิน 9 กิโลกรัมและชุดยังชีพอีกเกือบ 3 ขั้นสุดท้ายดูป้ายน้ำหนักให้ดี`);
      break; }
    case 6: { // รายละเอียด
      const dt = c.details || {};
      if (!c.name.trim()) say('ask', coachPick(['ยังไม่มีชื่อหรือ เราเรียกเจ้าว่า "ลูกรัก" ได้ แต่ GM เรียกไม่ได้ ตั้งชื่อตามธรรมเนียมวงศาก็ดี หรือชื่อที่คนอื่นตั้งให้แล้วตัวละครไม่ชอบก็ยิ่งดี', 'ชื่อก่อน ชื่อคือสิ่งแรกที่ NPC จะพูดถึงลับหลังเจ้า', 'ตั้งชื่อให้ออกเสียงง่าย โต๊ะจะเรียกชื่อนี้เป็นร้อยครั้ง ชื่อที่ไม่มีใครออกเสียงถูกจะกลายเป็นชื่อเล่นที่เจ้าไม่ได้เลือก'], seed));
      else say('smile', coachPick([`${c.name.trim()} ชื่อดี เราจะจำไว้ ตอนนี้บอกเราหน่อยว่า${c.name.trim()}ต้องการอะไร และจำเป็นต้องได้อะไร สองอย่างนี้ไม่เหมือนกัน และช่องว่างระหว่างมันคือเรื่องทั้งหมด`, `${c.name.trim()} เราเคยรู้จักคนชื่อคล้ายกัน เขาไม่รอด แต่เจ้าอาจต่างออกไป`, `${c.name.trim()} ดี ทีนี้ Want คือสิ่งที่ตัวละครคิดว่าอยากได้ Need คือสิ่งที่ตัวละครต้องเรียนรู้ ถ้าสองอย่างนี้ขัดกัน เจ้าได้เรื่องราวมาฟรี`], seed));
      const kinT = kin ? KIN[kin.id] : null; const ch = findBg(kin, c.childhood), ad = findBg(kin, c.adulthood);
      if (!(dt.backstory||'').trim() && ch && ad) say('think', `เรื่องราว เขียนแค่สามบรรทัดก็พอ ${ch.name}ที่กลายเป็น${ad.name} ใครอยู่ในเรื่องนั้นบ้าง และใครที่ยังตามหาเจ้าอยู่${kinT && kinT.hindrances.length ? ` อย่าลืมผูก ${kinT.hindrances[0].name} เข้าไปด้วย ข้อเสียที่มีที่มาเล่นสนุกกว่าข้อเสียที่ติดมาเฉย ๆ` : ''}`);
      if (!(dt.fears||'').trim()) say(null, 'ช่องหวาดกลัว อย่าเว้นว่าง GM ใช้ช่องนี้บ่อยที่สุดในชีท และเราก็ใช้');
      if ((dt.signature||'').trim()) say('smirk', 'เอกลักษณ์ที่ตกลงกับ GM ไม่กินช่องเก็บของ ไม่นับน้ำหนัก และบอกทุกคนว่าตัวละครนี้คือใครก่อนที่เจ้าจะพูด เลือกให้ดี');
      break; }
    case 7: { // ชุดเริ่มต้น
      const S = DATA.sets; const set = c.starterSet ? S.sets.find(x=>x.nameEn===c.starterSet) : null;
      if (!set){
        say('explain', `สิบเจ็ดชุด ทุกชุดได้ชุดยังชีพกับ 15 เกรฟเท่ากัน ต่างกันที่ของหลัก${prof && prof.sets.length ? ` ตามนิสัยและค่าพลัง เราแนะนำ ${prof.sets.join(', ')}` : ''} ดูป้ายน้ำหนักให้ดี แบกได้ ${d.capacity} กิโลกรัม`);
        if (d.capacity < 30) say('think', 'ชุดที่หนักเกินไม่ได้ห้ามเลือก แต่ตัวละครจะช้าตั้งแต่ก้าวแรก ยอมทิ้งของบางชิ้นไว้กับเพื่อนก็ได้ นั่นก็เป็นเรื่องราว');
      } else {
        const wt = parseFloat(set.totalWeight) || 0; const over = wt + 2.8 > d.capacity;
        const archs = set.archetype.split('/').map(s=>s.trim());
        const match = prof && prof.top.some(a => archs.includes(a.id));
        say(match ? 'smile' : 'think', match ? `${set.nameEn} ตรงกับสาย${prof.top[0].th}ที่อ่านได้จากนิสัย ของในชุดจะถูกสวมให้ทันทีที่กดเสร็จสิ้น และค่าเกราะแต่ละอวัยวะจะถูกเติมตามของที่สวม` : `${set.nameEn} เป็นชุดสาย ${set.archetype}${prof ? ` ส่วนนิสัยที่เลือกชี้ไปทาง${prof.top[0].th}` : ''} ไม่ตรงกันไม่ได้แปลว่าผิด ตัวละครที่ถือของผิดมือมีเรื่องให้เล่าเสมอ แค่รู้ตัวว่าทอยจะไม่ได้โบนัสจากนิสัยบ่อยนัก`);
        if (over) say('panic', `หนัก ${set.totalWeight} กิโลกรัม บวกชุดยังชีพแล้วเกินที่แบกได้ ${d.capacity} กิโลกรัม ตัวละครนี้จะเดินช้าตั้งแต่ออกจากเมือง ทิ้งของบางชิ้น หรือเลือกชุดที่เบากว่า`);
        else say(null, `น้ำหนัก ${set.totalWeight} กิโลกรัม แบกไหว เหลือที่ว่างสำหรับของที่เก็บได้ระหว่างทาง`);
        if (set.backgrounds) say('ask', `ชุดนี้เข้ากับพื้นหลังอย่าง ${set.backgrounds.split(',')[0].trim()} ถ้าพื้นหลังของเจ้าไม่ใช่ ลองคิดว่าของพวกนี้มาอยู่ในมือได้อย่างไร ซื้อมา ขโมยมา หรือได้มาจากคนตาย`);
        say('smile', 'กดเสร็จสิ้นเมื่อพร้อม แล้วไปเจอกันที่ชีท เราจะอยู่ตรงปุ่มลอยข้างจอ ไม่ได้ไปไหน');
      }
      break; }
  }
  if (!out.lines.length) say('smile', 'เราดูอยู่ ทำต่อไปเถอะ');
  return out;
}
function K_story(kin){ const K = COACH_KIN[kin.id]; return K ? K.story : ''; }

/* แผงที่วางไว้เหนือแผงสรุปด้านขวาของวิซาร์ด */
function coachPanel(c, d){
  if (Coach.off) return h('div',{class:'coach off'}, h('button',{class:'small ghost',onclick:()=>{ Coach.off=false; try{ localStorage.setItem('kirana.coach','on'); }catch(e){} renderWizard(); }}, nemImg('smile','coach-mini'), ' เรียกเนเมสไซอาร์กลับมา'));
  const r = coachCompute(c, d, W.step);
  const key = r.mood + '|' + r.lines.join('|');
  const changed = key !== Coach.lastKey; Coach.lastKey = key;
  const box = h('div',{class:'coach mood-'+r.mood+(changed?' fresh':'')},
    h('div',{class:'coach-portrait'}, h('div',{class:'coach-arch'}), nemImg(r.mood)),
    h('div',{class:'coach-bubble'},
      h('div',{class:'coach-name'}, h('b',{text:NEM.name}), h('span',{class:'dim',text:' · '+NEM.title}), h('button',{class:'small ghost coach-x',title:'ซ่อนเนเมสไซอาร์',onclick:()=>{ Coach.off=true; try{ localStorage.setItem('kirana.coach','off'); }catch(e){} renderWizard(); },text:'✕'})),
      ...r.lines.map(t => h('p',null, T(t)))));
  return box;
}
let coachT = null;
function coachLater(){ clearTimeout(coachT); coachT = setTimeout(()=>{ if (!W.char) return; const old = $('#v-create .coach'); if (!old) return; old.replaceWith(coachPanel(W.char, compute(W.char))); }, 500); }
