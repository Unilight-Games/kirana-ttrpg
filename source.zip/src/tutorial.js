/* ===== หน้าสอนเล่นแบบ visual novel: เนเมสไซอาร์ ศาสดาสีชาด เป็นผู้สอน =====
 * นางเรียกตัวเองว่า "เรา" เรียกผู้เล่นว่า "เจ้า" หรือ "ลูกรัก" อ่อนโยน ขี้เล่น ชอบตั้งคำถาม ไม่ชอบคนเชื่อโดยไม่คิด
 * ภาพจาก assets/nem-<mood>.webp (ask explain guilty mad panic shush smile smirk surprise think) 360×432 พื้นหลัง assets/scene-study.webp
 * แต่ละบทเป็นลำดับ "บรรทัด" [mood, ข้อความ] คลิก/Space/→ เพื่อไปต่อ ตัวอักษรค่อย ๆ ปรากฏ คลิกซ้ำเพื่อโชว์ทั้งบรรทัด */
const NEM = { name: 'เนเมสไซอาร์', title: 'ศาสดาสีชาด', moods: ['smile','explain','ask','think','smirk','guilty','shush','surprise','panic','mad'] };
function nemSrc(mood){ return 'assets/nem-' + (NEM.moods.includes(mood) ? mood : 'smile') + '.webp'; }
function nemImg(mood, cls){ const img = h('img',{class:'nem-img '+(cls||''), src:nemSrc(mood), alt:NEM.name, draggable:'false'}); img.onerror = ()=>{ img.style.visibility='hidden'; }; return img; }

/* บทเรียน: ข้อเท็จจริงทุกข้อตรงกับกติกาที่เว็บใช้ (ไฟล์แกน V.2 + ค่าที่ติดป้ายเสนอ) */
const LESSONS = [
  { id:'welcome', nav:'ต้อนรับ', title:'ยินดีต้อนรับสู่โต๊ะของเรา', scene:'study', lines:[
    ['smile', 'อ้าว มาแล้วหรือ นั่งก่อนสิ ลูกรัก ฝนข้างนอกยังไม่ซาหรอก'],
    ['smile', 'เราคือเนเมสไซอาร์ ผู้คนเรียกเราว่าศาสดาสีชาด แต่บนโต๊ะนี้เราเป็นเพียงคนที่นั่งข้างเจ้า คอยอธิบายว่าลูกเต๋ากลิ้งไปทางไหน และทำไม'],
    ['explain', 'คีรันนาเป็นโลกใต้ม่านมานา วงศาทั้งสิบสองใช้ชีวิตอยู่ร่วมกันอย่างกระอักกระอ่วน เวทมนตร์มีราคาที่ต้องจ่ายเสมอ และบาดแผลไม่หายไปเพราะพักหนึ่งคืน', 'kins'],
    ['think', 'เกมนี้จึงไม่ถามว่าเจ้าแข็งแกร่งแค่ไหน มันถามว่าเจ้ายอมเสียอะไร เพื่อให้ได้สิ่งที่ต้องการ', null],
    ['smirk', 'บทเรียนต่อจากนี้สั้นทั้งนั้น อ่านแล้วอย่าเพิ่งเชื่อเรา ท้ายบทมีปุ่ม "ลองทำ" ไปจับของจริงดู เราชอบคนที่ตั้งคำถามมากกว่าคนที่พยักหน้า'],
    ['ask', 'พร้อมหรือยัง คลิกที่ไหนก็ได้บนฉากนี้ หรือกด Space เพื่อให้เราพูดต่อ'],
  ]},
  { id:'dice', nav:'ลูกเต๋าสองลูก', title:'ทุกอย่างเริ่มที่ลูกเต๋าสองลูก', scene:'study', lines:[
    ['explain', 'เวลาผลลัพธ์ไม่แน่นอน เจ้าทอย 2d6 แล้วบวก Mod ของค่าพลังที่ใช้ ถ้าการกระทำนั้นเข้ากับนิสัยของตัวละคร ก็บวกคะแนนบุคลิกภาพเข้าไปด้วย', {t:'roll'}],
    ['explain', 'ผลรวมเทียบกับ DC ที่ GM ตั้ง ง่าย 5 ปานกลาง 7 ยาก 10 ยากมาก 12 และเกือบเป็นไปไม่ได้ 14', 'dc'],
    ['think', 'ลูกเต๋าสองลูกให้ผลรวมเฉลี่ย 7 ดังนั้น DC 7 คือครึ่งต่อครึ่ง และ Mod +1 เพียงแต้มเดียวก็เปลี่ยนโอกาสไปหลายเปอร์เซ็นต์ อย่าดูถูกแต้มเล็ก ๆ', 'avg'],
    ['surprise', 'ออก [6,6] คือ Critical Success ผ่านทันที ออก [1,1] คือ Critical Failure ล้มเหลวทันที ไม่ว่า Mod จะสูงเพียงใด ลูกเต๋าไม่สนว่าเจ้าเป็นใคร', 'crit'],
    ['explain', 'Advantage ให้เจ้าทอยสามลูกแล้วเก็บสองลูกที่ดีที่สุด Disadvantage เก็บสองลูกที่แย่ที่สุด ได้ทั้งสองอย่างพร้อมกันก็หักล้างกัน ทอยปกติ', 'advdis'],
    ['shush', 'ถ้าไม่มีใครตั้ง DC เว็บจะไม่ตัดสินให้ว่าสำเร็จหรือล้มเหลว เพราะการทอยนั้นอาจเป็น Parry ที่ต้องเทียบกับผู้โจมตี หรือเป็นเรื่องที่ GM อยากตัดสินเอง เว็บบอกแค่ตัวเลข ที่เหลือเป็นเรื่องของคนบนโต๊ะ', 'nodc'],
  ], tryLabel:'ลองทอยที่ชีท (ต้องมีตัวละครก่อน)', tryHash:'#chars' },
  { id:'stats', nav:'ค่าพลังหกค่า', title:'ค่าพลังหกค่า และ Mod ที่ซ่อนอยู่ข้างใต้', scene:'study', lines:[
    ['explain', 'ตัวละครมีค่าพลังหกค่า STR พละกำลัง AGI ความคล่องแคล่ว VIT ความแข็งแรง PER การรับรู้ INF อิทธิพล และ INT ปัญญา', 'stats'],
    ['think', 'ค่าดิบอยู่ราว 5 ถึง 20 แต่สิ่งที่ใช้ทอยจริงคือ Mod = ค่าดิบหารสอง ลบห้า ปัดลง ค่า 10 จึงเป็น Mod 0 ค่า 12 เป็น +1 ค่า 8 เป็น −1', 'modtable'],
    ['smirk', 'สังเกตให้ดี ค่าดิบเลขคี่ไม่ได้ให้ Mod เพิ่ม 9 กับ 10 ให้ Mod ต่างกัน แต่ 10 กับ 11 ให้เท่ากัน ตอนแจกแต้ม Extra ให้มองที่เลขคู่ถัดไปเสมอ ปุ่ม Auto Fill ในวิซาร์ดรู้เรื่องนี้ดี'],
    ['explain', 'ค่าพลังรองคำนวณจาก Mod ทั้งหมด HP = 10 + VIT Mod + STR Mod · MP = 10 + INF Mod + INT Mod · Sanity = 5 + INF Mod · Passive PER = 7 + PER Mod', 'derived'],
    ['explain', 'Toughness ต่ออวัยวะ = (VIT ดิบ + STR ดิบ) ÷ 10 + 1 และแบกของได้ STR × 3 กิโลกรัม ตัวใหญ่แบกได้มากกว่านั้น'],
    ['guilty', 'ค่าที่ติดป้าย (เสนอ) เช่น Reflex Might Sight คือสิ่งที่ไฟล์แกนยังไม่ได้เขียนเป็นตารางให้ผู้เล่น เว็บใช้สูตรฝั่ง Bestiary ไปก่อน ถ้าเจ้าเห็นว่าไม่สมเหตุผล บอกคนทำกฎ อย่าบอกเรา เราแค่อ่านให้ฟัง', 'proposed'],
  ]},
  { id:'pers', nav:'บุคลิกภาพ', title:'บุคลิกภาพคือค่าพลังที่เจ้าเลือกเอง', scene:'study', lines:[
    ['ask', 'ทีนี้คำถามที่เราชอบที่สุด ตัวละครของเจ้าเป็นคนแบบไหน', null],
    ['explain', 'มีหกคู่ตรงข้าม ตรรกะกับสัญชาตญาณ เผชิญหน้ากับหลบเลี่ยง กล้าหาญกับระแวดระวัง เห็นแก่ส่วนรวมกับรักตัวเอง เห็นอกเห็นใจกับเลือดเย็น และเจ้าระเบียบกับไร้ระเบียบ', 'persaxes'],
    ['explain', 'เจ้าแจกแต้ม 3, 2, 2, 1, 1 และ 0 ให้คู่ละหนึ่งค่า แล้วเลือกว่าจะเอียงไปฝั่งไหน ฝั่งที่เลือกเป็นบวก ฝั่งตรงข้ามติดลบเท่ากัน'],
    ['shush', 'คนที่กล้าหาญ +3 เวลาทอยอะไรที่ต้องใช้ความระแวดระวังจะได้ −3 นี่คือราคาของการเป็นใครสักคน ไม่มีใครเก่งทุกด้าน แม้แต่เรา', 'persbar'],
    ['smile', 'ในวิซาร์ด แถบแต่ละคู่แบ่งเป็นสีโทนอุ่นกับโทนเย็น ฝั่งที่เจ้าเลือกจะกลืนแถบตามระดับ เลือกครบแล้วเราจะอ่านนิสัยของตัวละครให้ฟัง พร้อมบอกว่าสายการเล่นไหนเข้ากับนางหรือเขา', 'profile'],
    ['smirk', 'ฟังไว้ แต่ตัดสินใจเองนะลูกรัก คนที่เชื่อเราทุกคำมักจบไม่สวย', null],
  ], tryLabel:'ดูขั้นบุคลิกภาพในวิซาร์ด', tryHash:'#wizard' },
  { id:'create', nav:'สร้างตัวละคร 8 ขั้น', title:'สร้างตัวละครทีละขั้น ทั้งหมดแปดขั้น', scene:'study', lines:[
    ['explain', 'ขั้นที่หนึ่ง เลือกวงศา จากสิบสองวงศา การ์ดบอกแค่จุดเด่น จุดด้อย และค่าดิบ กด "ดูรายละเอียด" ถ้าอยากอ่านทั้งหมด Beastman ยังไม่เปิด รอข้อมูลอยู่', {t:'steps',cur:0}],
    ['explain', 'ขั้นที่สอง พื้นหลังวัยเด็กและวัยผู้ใหญ่อย่างละใบ แต่ละใบให้แต้มค่าพลังและ Trait ติดตัวมา แผงขวามือจะสรุปให้ว่าเลือกอะไรไปแล้ว และเราจะยืนคอมเมนต์อยู่ข้าง ๆ ตลอดทาง', 'bgcard'],
    ['explain', 'ขั้นที่สาม บุคลิกภาพ ขั้นที่สี่ แต้ม Extra ของวงศา ใส่ลงค่าพลังที่อยากยก จำเรื่องเลขคู่ได้ใช่ไหม', {t:'steps',cur:3}],
    ['think', 'ขั้นที่ห้า เลือก Talent ตามค่าพลังที่สูงที่สุดของเจ้า หรือเลือก Educated แทน แล้วอัปเกรดความรู้หนึ่งระดับ พร้อมรับทักษะเริ่มต้นจากวงศา ขั้นนี้ยาวที่สุด ใจเย็น ๆ ทุกช่องมีป้ายบอกว่าได้อะไร', {t:'steps',cur:4}],
    ['explain', 'ขั้นที่หก เว็บคำนวณค่าพลังรองให้ทั้งหมด ขั้นที่เจ็ด ชื่อ อายุ รูปลักษณ์ แรงจูงใจ สิ่งที่อยาก สิ่งที่ต้องการ และสิ่งที่แสดงออก', {t:'steps',cur:6}],
    ['smile', 'ขั้นที่แปด ชุดเริ่มต้นหนึ่งชุดจากสิบเจ็ดชุด พร้อมเงินติดตัว 15 เกรฟ กดเสร็จสิ้นแล้วชีทของเจ้าจะพร้อม ของในชุดถูกสวมให้ และค่าเกราะถูกเติมตามของที่สวม', {t:'steps',cur:7}],
    ['ask', 'คำเฉพาะทุกคำที่ขีดเส้นประในวิซาร์ด กดแล้วมีความหมายขึ้นมา อย่าเดา ถ้าสงสัยก็กด เจ้าจะเดาไปทำไมในเมื่อถามได้', 'glossary'],
  ], tryLabel:'เริ่มสร้างตัวละครจริง', tryHash:'#wizard', tryNew:true },
  { id:'sheet', nav:'ชีทและปุ่มลอย', title:'ชีทไม่ใช่เอกสาร มันคือหน้าปัดของเจ้า', scene:'study', lines:[
    ['smirk', 'เปิดชีทแล้วมองหาปุ่มลอยข้างจอสี่ปุ่ม กระเป๋า คัมภีร์ ถุงย่าม และทอยเต๋า ลากไปวางตรงไหนก็ได้ กดแล้วเปิดเป็นหน้าต่างลอยที่ลากและย่อขยายได้', 'hud'],
    ['explain', 'ของในกระเป๋ามีชื่อ คุณสมบัติ จำนวน และน้ำหนัก สวมแล้วย้ายไปอยู่ในถุงย่าม น้ำหนักรวมเทียบกับที่แบกได้อยู่บนป้ายของปุ่มกระเป๋าเสมอ'],
    ['explain', 'ถุงย่ามเป็นหุ่นสวมใส่สิบสี่ช่อง ของที่สวมบอกค่าเกราะ A/B ของอวัยวะนั้นให้เอง A กันกายภาพทั่วไป B กันการกระแทก หรือชนิดที่วงเล็บไว้ เข็มขัดโซ่ไม่ทบกับเกราะลำตัว ใช้ค่าที่สูงกว่า', 'doll'],
    ['smile', 'ถ้าผังชีทไม่ถูกใจ กด "จัดวางกรอบเอง" แล้วลากทุกกรอบไปวางใหม่ ย่อขยายได้ เว็บจำผังของเจ้าไว้ในเบราว์เซอร์นี้', 'layout'],
    ['think', 'และปุ่ม "ใช้ IP" ข้างแต้ม Insight Point คือทางเดียวที่ตัวละครจะเติบโต เราจะพูดถึงมันอีกทีข้างหน้า', 'ip'],
  ], tryLabel:'ไปที่ตัวละครของฉัน', tryHash:'#chars' },
  { id:'combat', nav:'เทิร์นและระยะ', title:'เมื่อเลือดจะต้องตก: เทิร์น ระยะ และแผนที่', scene:'map', lines:[
    ['explain', 'ฉากต่อสู้ยาวหนึ่งนาที แบ่งเป็นเทิร์นละหกวินาที ทุกคนทอย 2d6 + Initiative ตั้งลำดับ ในเทิร์นของเจ้าได้ 1 Swift Action 1 Basic Action และ 1 Cast ใช้ไม่ครบก็เสียเปล่า เลือกให้ดี', 'turn'],
    ['explain', 'แผนที่ต่อสู้เป็นตาราง 20 คูณ 20 ช่อง ช่องละ 2 เมตร GM สุ่มสถานที่ได้ ป่า แม่น้ำ เมือง ถ้ำ ดันเจี้ยน ภูเขา ทะเล บนเรือ และอื่น ๆ', {t:'grid',kind:'forest',seed:'tutor-forest',bands:false,title:'สุ่มแผนที่: ป่า'}],
    ['think', 'ช่องน้ำลึก หิน หรือกำแพงผ่านไม่ได้ ช่องน้ำตื้น หิมะ โคลน เศษหินเดินช้า นับเป็นสองช่อง ดูพื้นก่อนวิ่ง เราเคยเห็นทหารทั้งกองจมโคลนมาแล้ว', 'terrain'],
    ['explain', 'คลิกหมากของเจ้า ช่องรอบตัวจะระบายสี สีแดงคือเขตปะทะ ติดกันรวมทแยง สีทองคือเขตใกล้เคียงไม่เกิน 25 เมตร ไกลกว่านั้นคือเขตไกล', {t:'grid',kind:'ruins',seed:'tutor-ruins',tok:{x:9,y:10},npc:{x:14,y:7},title:'แดง = ปะทะ · ทอง = ใกล้เคียง (≤ 25 ม.)'}],
    ['explain', 'จากใกล้เคียงเข้าปะทะใช้ 1 Swift ถอยจากปะทะออกมาก็ 1 Swift แต่โดนโจมตีฉวยโอกาส จากใกล้เคียงไปไกลใช้ Swift บวก 1 AP', 'move'],
    ['shush', 'อาวุธประชิดตีได้เฉพาะในเขตปะทะเดียวกัน อาวุธระยะยิงได้ทุกเขต แต่ยิงไกลหรือมีที่กำบังจะติด Disadvantage', 'weapon'],
  ], tryLabel:'ดูโต๊ะเล่น', tryHash:'#table' },
  { id:'attack', nav:'โจมตีและป้องกัน', title:'โจมตี ป้องกัน และตำแหน่งที่โดน', scene:'map', lines:[
    ['explain', 'ผู้โจมตีทอย Attack Roll 2d6 ผลรวมคือ CV ออกเลขคู่คือ Perfect Strike ฝ่ายรับต้องประกาศว่าจะ Parry หรือ Evade', 'attack'],
    ['mad', 'ถ้าไม่ประกาศ โดนเต็ม ไม่มีการต่อรอง เราพูดเรื่องนี้กับทหารใหม่ทุกคน และทุกคนที่ไม่ฟังก็ไม่ได้กลับมาฟังซ้ำ'],
    ['explain', 'Parry ทอย 2d6 บวกจำนวน Parry Dice จากโล่ แล้วเลือกเองว่าจะใช้สองลูกไหน จะเอาสูงสุด หรือจะเอาให้เท่ากับผลของผู้โจมตีเพื่อ Perfect Parry ก็ได้', 'parry'],
    ['explain', 'Evade ทอย 2d6 + Reflex ถ้าได้ Advantage ก็เลือกลูกเองเช่นกัน แต่ Parry แบบ Disadvantage ทอยสองลูกเปล่า ๆ โล่ช่วยไม่ได้ ผลเท่ากับผู้โจมตีพอดีคือ Perfect ได้ 1 AP คืนทันที'],
    ['think', 'เมื่อโดน ให้ดูว่าโดนตรงไหน ผลรวม 2 3 11 12 คือหัว 6 7 8 คือลำตัว 4 กับ 9 ทอย 1d6 ต่อ 1-3 ขาขวา 4-6 แขนขวา ส่วน 5 กับ 10 เป็นข้างซ้ายแบบเดียวกัน', 'hitloc'],
    ['explain', 'เกราะของอวัยวะนั้นหักความเสียหายกายภาพออกก่อน ที่เหลือหัก HP และ Toughness ของอวัยวะนั้น', 'damage'],
    ['guilty', 'Toughness ของอวัยวะไหนหมด อวัยวะนั้นใช้ไม่ได้และต้องทอยตารางบาดแผลฉกรรจ์ ติดลบจนถึงค่าเต็มคือเสียอวัยวะ เราเคยนำทัพในสงครามร้อยปี ลูกรัก เรารู้ว่าแขนที่หายไปไม่งอกกลับมาเพราะพักผ่อน คิดก่อนยืนรับดาบ', 'wound'],
  ], tryLabel:'ทอย Parry ดูในหน้าต่างทอยเต๋า', tryHash:'#chars' },
  { id:'mind', nav:'จิตใจและราคาของเวท', title:'สิ่งที่หักไม่ใช่แค่กระดูก', scene:'study', lines:[
    ['shush', 'Sanity คือสติของเจ้า ถูกดึงเมื่อเผชิญสิ่งบิดเบี้ยว เมื่อฝืนใจตัวเอง หรือเมื่อเวทบางบทเรียกเก็บแทน MP', 'sanity'],
    ['think', 'เวทมนตร์ในคีรันนาไม่มีอะไรฟรี บางบทจ่ายด้วยเลือด บางบทจ่ายด้วยสติ อ่านช่อง Cost ของทุกสกิลก่อนร่าย เราเห็นคนร่ายโดยไม่อ่านมาเยอะ ส่วนใหญ่น่าสงสาร', 'cost'],
    ['explain', 'Temporary Health เป็นเกราะชั่วคราวที่บางสกิลหรือสถานะมอบให้ หายไปก่อน HP จริง และพักผ่อนก็ไม่คืน', 'sanity'],
    ['ask', 'ตัวละครของเจ้ามีนิสัยที่เลือกไว้ตั้งแต่สร้าง เมื่อเจ้าให้นางหรือเขาทำสิ่งที่ขัดกับนิสัยนั้น GM มีสิทธิ์เรียกเก็บ Sanity เป็นค่าฝืน เรื่องนี้อยู่ในดุลยพินิจของโต๊ะ ไม่ใช่ของเว็บ', null],
  ]},
  { id:'ip', nav:'Insight Point', title:'การเติบโตมีราคา และราคาเขียนไว้ชัด', scene:'study', lines:[
    ['explain', 'ตัวละครได้ Insight Point จากเหตุการณ์สำคัญ จบเซสชั่น +1 เป้าหมายย่อย +2 ภารกิจสำคัญ +3 เป้าหมายหลักของเรื่อง +4 ใช้ได้เฉพาะตอนจบเซสชั่นหรือช่วง Downtime สะสมข้ามเซสชั่นได้ไม่จำกัด', 'ipgain'],
    ['explain', 'IP ซื้อได้สามอย่าง หนึ่ง ยก Mod ของค่าพลังขึ้นหนึ่งขั้น ราคาขึ้นตามขั้น ติดลบขึ้นมา 0 ขั้นละ 3 จากนั้น 3 4 5 6 7', 'ipmod'],
    ['explain', 'สอง ยกระดับความรู้ ระดับหนึ่ง 4 ระดับสอง 6 ระดับสาม 9 ต้องผ่านประตูของระดับนั้นก่อน เคยใช้งานจริง มีตำรา หรือมีครู สาม ซื้อทักษะและเวทตามราคาที่เขียนไว้ในรายการ', 'ipknow'],
    ['think', 'ทักษะระดับ Novice เรียนเองได้ Expert ต้องมีครู ตำรา หรือเคยเห็นใครใช้ Master ต้องมีปรมาจารย์หรือเหตุการณ์ในเรื่อง', 'gates'],
    ['smirk', 'ครูและตำราเปลี่ยนได้แค่สิทธิ์และราคา ตำราทั่วไปหรือผู้ชำนาญการลด 1 IP ของหายากหรือปรมาจารย์ลด 2 ใช้ได้สาขาละครั้งต่อช่วงระหว่าง Milestone GM เป็นคนติ๊กยืนยันประตูให้เจ้าในหน้าต่าง "ใช้ IP"'],
  ], tryLabel:'เปิดหน้าต่างใช้ IP ที่ชีท', tryHash:'#chars' },
  { id:'online', nav:'โต๊ะออนไลน์', title:'โต๊ะนี้นั่งได้ทั้งที่อยู่คนละเมือง', scene:'map', lines:[
    ['surprise', 'รู้ไหม โต๊ะนี้นั่งได้ทั้งที่อยู่คนละเมือง ล็อกอินด้วยบัญชี Google ที่มุมขวาบน ตัวละครของเจ้าจะตามไปทุกเครื่อง', 'login'],
    ['explain', 'ชีทของเจ้าเป็นของเจ้าคนเดียว GM กับเพื่อนร่วมโต๊ะจะเห็นก็ต่อเมื่อเจ้าหยิบตัวละครลงบอร์ดในห้องนั้น ปุ่ม "ออนไลน์" บอกว่าใครอยู่ที่ไหน'],
    ['explain', 'GM สร้างห้องแล้วส่งลิงก์ให้ ผู้เล่นกด "วางตัวละครลงบอร์ด" รูปจากชีทจะไปอยู่บนหมาก GM เลือกสถานที่ สุ่มแผนที่ เพิ่ม NPC ที่ซ่อนไว้ก่อน เริ่มการต่อสู้ แล้วทุกคนเดินหมากของตัวเอง', 'roomflow'],
    ['smile', 'ทุกการทอยในห้องเด้งเป็นลูกเต๋าใหญ่กลางจอของทุกคน และทอยได้ทีละคน ระหว่างที่เต๋าของใครยังหมุนอยู่ คนอื่นต้องรอ แชตมีคำสั่ง /r 2d6+2 สำหรับทอยเอง /adv /dis และ /gm สำหรับข้อความลับถึง GM', 'dicepop'],
    ['shush', 'ถ้า GM ย้ายเครื่อง ให้ใช้รหัส GM หกตัวของห้องเพื่อกลับมาเป็น GM อย่าให้ผู้เล่นเห็นรหัสนั้น เราเห็นบาปที่คนเคยทำมามากพอจะรู้ว่าอะไรเกิดขึ้นเมื่อผู้เล่นได้รหัส GM', 'gmkey'],
  ], tryLabel:'ไปโต๊ะเล่น', tryHash:'#table' },
  { id:'end', nav:'ส่งท้าย', title:'เท่านี้ก็พอให้เจ้านั่งลงที่โต๊ะได้แล้ว', scene:'study', lines:[
    ['smile', 'เท่านี้ก็พอให้เจ้านั่งลงที่โต๊ะได้แล้ว ที่เหลือเรียนจากการเล่น ไม่ใช่จากเรา'],
    ['explain', 'กฎย่อทั้งหมดอยู่ในหน้า "กฎย่อ" และศัพท์ทุกคำที่ขีดเส้นประกดดูได้ทุกที่ในเว็บ ตอนสร้างตัวละคร เราจะยืนอยู่ข้างเจ้าด้วย คอยบ่น คอยแซว และคอยบอกว่าอะไรเข้ากับอะไร', 'rulespage'],
    ['smile', 'จงเฉลิมฉลองเมื่อเริ่มสิ่งใหม่ และจดจำเรื่องราวที่เกิดบนโต๊ะไว้เล่าต่อ นั่นคือสิ่งที่เราขอ', null],
    ['smile', 'ขอให้สายเลือดของเจ้าสืบสานไปนานชั่วกัลป์ ลูกรัก'],
  ], tryLabel:'สร้างตัวละครตัวแรก', tryHash:'#wizard', tryNew:true },
];

/* สถานะ: บทที่ (ch) บรรทัด (ln) เก็บใน localStorage kirana.tutor (รุ่นเก่าเก็บเป็นเลขบท) */
const Tutor = (()=>{ let s = { ch:0, ln:0, auto:false, timer:null, typing:null, done:false }; try { const raw = localStorage.getItem('kirana.tutor'); if (raw){ const v = JSON.parse(raw); if (typeof v === 'number') s.ch = v; else if (v && typeof v === 'object'){ s.ch = v.ch|0; s.ln = v.ln|0; } } } catch(e){} return s; })();
function tutorSave(){ try { localStorage.setItem('kirana.tutor', JSON.stringify({ch:Tutor.ch, ln:Tutor.ln})); } catch(e){} }
function tutorStopTimers(){ if (Tutor.typing){ clearInterval(Tutor.typing); Tutor.typing = null; } if (Tutor.timer){ clearTimeout(Tutor.timer); Tutor.timer = null; } }

function renderTutorial(){
  const root = clear($('#v-tutor'));
  tutorStopTimers();
  if (Tutor.ch < 0 || Tutor.ch >= LESSONS.length) Tutor.ch = 0;
  const L = LESSONS[Tutor.ch];
  if (Tutor.ln < 0 || Tutor.ln >= L.lines.length) Tutor.ln = 0;
  const go = (hash, isNew)=>{ if (isNew) startWizard(null); location.hash = hash; };
  const setLesson = (i, ln)=>{ Tutor.ch = i; Tutor.ln = ln||0; tutorSave(); renderTutorial(); };

  const stage = h('div',{class:'vn scene-'+(L.scene||'study'), tabindex:0, role:'region', 'aria-label':'บทเรียน '+L.title});
  const sprite = nemImg(L.lines[Tutor.ln][0], 'vn-sprite-img');
  const nameEl = h('div',{class:'vn-name'}, h('b',{text:NEM.name}), h('span',{text:NEM.title}));
  const textEl = h('div',{class:'vn-text'});
  const nextEl = h('div',{class:'vn-next',text:'▼'});
  const counter = h('span',{class:'vn-count num'});
  const choices = h('div',{class:'vn-choices hidden'});
  const autoBtn = h('button',{class:'small ghost'+(Tutor.auto?' on':''), title:'เล่นต่อเองเมื่อพูดจบ', onclick:(e)=>{ e.stopPropagation(); Tutor.auto = !Tutor.auto; autoBtn.classList.toggle('on', Tutor.auto); autoBtn.textContent = Tutor.auto ? 'อัตโนมัติ: เปิด' : 'อัตโนมัติ'; if (Tutor.auto && !Tutor.typing) armAuto(); }, text: Tutor.auto ? 'อัตโนมัติ: เปิด' : 'อัตโนมัติ'});
  const top = h('div',{class:'vn-top'},
    h('div',{class:'vn-title'}, h('div',{class:'kicker',text:`บทที่ ${Tutor.ch+1} / ${LESSONS.length}`}), h('h2',{text:L.title})),
    h('div',{class:'row vn-tools'},
      h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); openLessonMenu(); },text:'สารบัญ'}),
      h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); toggleLog(); },text:'อ่านทั้งบท'}),
      autoBtn,
      h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); finishChapter(); },text:'ข้ามบท'})));
  const box = h('div',{class:'vn-box'}, nameEl, textEl, h('div',{class:'vn-foot'}, counter, nextEl), choices);
  const log = h('div',{class:'vn-log hidden'});
  const figHost = h('div',{class:'vn-fighost'});
  stage.append(h('div',{class:'vn-bg'}), h('div',{class:'vn-fog'}), top, h('div',{class:'vn-sprite'}, sprite), figHost, box, log);
  root.append(stage);
  root.append(h('p',{class:'dim vn-hint',text:'คลิกที่ฉาก หรือกด Space / Enter / → เพื่อพูดต่อ · คลิกระหว่างที่ตัวอักษรกำลังขึ้นเพื่อแสดงทั้งบรรทัด · ความคืบหน้าถูกจำไว้ในเครื่องนี้'}));

  function openLessonMenu(){
    const list = h('div',{class:'vn-menu'});
    LESSONS.forEach((x,i)=> list.append(h('button',{class:'toc-i'+(i===Tutor.ch?' on':'')+(i<Tutor.ch?' done':''),onclick:()=>{ modal(null); setLesson(i,0); }}, h('span',{class:'num dim',text:String(i+1).padStart(2,'0')}), h('span',{text:x.nav}), i<Tutor.ch ? h('span',{class:'tag ok',text:'จบแล้ว'}) : null)));
    modal(h('div',null, h('h2',{text:'สารบัญบทเรียน'}), h('p',{class:'dim',style:'font-size:13px',text:'เลือกบทที่อยากฟัง เนเมสไซอาร์จะเริ่มเล่าตั้งแต่ต้นบท'}), list, h('div',{class:'row',style:'margin-top:12px'}, h('button',{class:'small ghost',onclick:()=>{ modal(null); setLesson(0,0); },text:'เริ่มใหม่ตั้งแต่บทแรก'}))));
  }
  function toggleLog(){
    if (!log.classList.contains('hidden')){ log.classList.add('hidden'); return; }
    clear(log);
    log.append(h('div',{class:'row',style:'justify-content:space-between'}, h('b',{text:'บทนี้ทั้งบท'}), h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); log.classList.add('hidden'); },text:'ปิด'})));
    L.lines.forEach(([m,t,f],i)=> log.append(h('div',{class:'vn-logline'+(i===Tutor.ln?' cur':''), onclick:(e)=>{ e.stopPropagation(); Tutor.ln = i; tutorSave(); showLine(); log.classList.add('hidden'); }}, h('img',{src:nemSrc(m),alt:''}), h('div',null, T(t)))));
    log.classList.remove('hidden');
  }
  function armAuto(){ if (!Tutor.auto) return; if (Tutor.timer) clearTimeout(Tutor.timer); const len = L.lines[Tutor.ln][1].length; Tutor.timer = setTimeout(()=>{ Tutor.timer=null; if (Tutor.auto) advance(); }, 1400 + Math.min(4000, len*22)); }
  function typeOut(text, onDone){
    tutorStopTimers();
    clear(textEl); textEl.classList.add('typing');
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let i = 0; const span = h('span'); textEl.append(span);
    const finish = ()=>{ if (Tutor.typing){ clearInterval(Tutor.typing); Tutor.typing=null; } clear(textEl); textEl.classList.remove('typing'); textEl.append(T(text)); nextEl.classList.add('show'); if (onDone) onDone(); };
    if (reduce){ finish(); return; }
    nextEl.classList.remove('show');
    Tutor.typing = setInterval(()=>{ i += 2; span.textContent = text.slice(0, i); if (i >= text.length) finish(); }, 18);
    textEl._finish = finish;
  }
  function figFor(ln){ for (let i=ln;i>=0;i--){ const f = L.lines[i][2]; if (f !== undefined) return f; } return null; }
  function showFig(ln){ const spec = figFor(ln); const key = JSON.stringify(spec||null); if (figHost.dataset.key === key) return; figHost.dataset.key = key; clear(figHost); const node = vnFigure(spec); if (node) figHost.append(node); stage.classList.toggle('has-fig', !!node); }
  function showLine(){
    const [mood, text] = L.lines[Tutor.ln];
    showFig(Tutor.ln);
    Tutor.done = false;
    choices.classList.add('hidden');
    sprite.src = nemSrc(mood); stage.className = 'vn scene-'+(L.scene||'study')+' mood-'+mood;
    sprite.classList.remove('nem-pop'); void sprite.offsetWidth; sprite.classList.add('nem-pop');
    counter.textContent = `${Tutor.ln+1} / ${L.lines.length}`;
    typeOut(text, ()=>{ if (Tutor.ln === L.lines.length-1) showChoices(); else armAuto(); });
  }
  function showChoices(){
    Tutor.done = true; nextEl.classList.remove('show');
    clear(choices);
    if (L.tryHash) choices.append(h('button',{class:'ghost',onclick:(e)=>{ e.stopPropagation(); go(L.tryHash, L.tryNew); },text:'ลองทำ: '+L.tryLabel}));
    if (Tutor.ch < LESSONS.length-1) choices.append(h('button',{class:'primary',onclick:(e)=>{ e.stopPropagation(); setLesson(Tutor.ch+1, 0); },text:'บทถัดไป →'}));
    else choices.append(h('button',{class:'primary',onclick:(e)=>{ e.stopPropagation(); go('#wizard', true); },text:'สร้างตัวละครตัวแรก'}));
    if (Tutor.ln > 0) choices.append(h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); Tutor.ln=0; tutorSave(); showLine(); },text:'ฟังบทนี้อีกครั้ง'}));
    choices.classList.remove('hidden');
  }
  function finishChapter(){ Tutor.ln = L.lines.length-1; tutorSave(); const [mood, text] = L.lines[Tutor.ln]; sprite.src = nemSrc(mood); showFig(Tutor.ln); counter.textContent = `${Tutor.ln+1} / ${L.lines.length}`; tutorStopTimers(); clear(textEl); textEl.append(T(text)); showChoices(); }
  function advance(){
    if (Tutor.typing){ textEl._finish && textEl._finish(); return; }
    if (Tutor.done){ if (Tutor.ch < LESSONS.length-1) setLesson(Tutor.ch+1, 0); return; } // จบบท: คลิก/Space ไปบทถัดไป (บทสุดท้ายใช้ปุ่ม)
    if (Tutor.ln < L.lines.length-1){ Tutor.ln++; tutorSave(); showLine(); }
  }
  function back(){ tutorStopTimers(); if (Tutor.ln > 0){ Tutor.ln--; tutorSave(); showLine(); } else if (Tutor.ch > 0){ setLesson(Tutor.ch-1, LESSONS[Tutor.ch-1].lines.length-1); } }
  stage.addEventListener('click', (e)=>{ if (e.target.closest('button, .term, .vn-log, a')) return; advance(); });
  stage.addEventListener('keydown', (e)=>{ if (e.target.closest('input,textarea')) return; if (e.key===' ' || e.key==='Enter' || e.key==='ArrowRight'){ e.preventDefault(); advance(); } else if (e.key==='ArrowLeft'){ e.preventDefault(); back(); } });
  Tutor._advance = advance; Tutor._back = back; Tutor._stage = stage;
  showLine();
  setTimeout(()=>{ try { stage.focus({preventScroll:true}); } catch(e){} }, 50);
}
/* กด Space/→ ที่ไหนก็ได้ในหน้าสอนเล่น (นอกช่องกรอกข้อความ) */
document.addEventListener('keydown', (e)=>{
  const v = $('#v-tutor'); if (!v || !v.classList.contains('active')) return;
  if (e.target.closest('input,textarea,select,button,.modal')) return;
  if (document.activeElement === Tutor._stage) return; // stage จัดการเอง
  if (e.key===' ' || e.key==='Enter' || e.key==='ArrowRight'){ e.preventDefault(); Tutor._advance && Tutor._advance(); }
  else if (e.key==='ArrowLeft'){ e.preventDefault(); Tutor._back && Tutor._back(); }
});
