/* ===== หน้าสอนเล่นแบบ visual novel: เนเมสไซอาร์ ศาสดาสีชาด เป็นผู้สอน =====
 * นางเรียกตัวเองว่า "เรา" เรียกผู้เล่นว่า "เจ้า" หรือ "ลูกรัก" อ่อนโยน ขี้เล่น ชอบตั้งคำถาม ไม่ชอบคนเชื่อโดยไม่คิด
 * ภาพจาก assets/nem-<mood>.webp (ask explain guilty mad panic shush smile smirk surprise think) 360×432 พื้นหลัง assets/scene-study.webp
 * แต่ละบทเป็นลำดับ "บรรทัด" [mood, ข้อความ] คลิก/Space/→ เพื่อไปต่อ ตัวอักษรค่อย ๆ ปรากฏ คลิกซ้ำเพื่อโชว์ทั้งบรรทัด */
const NEM = { name: 'เนเมสไซอาร์', title: 'ศาสดาสีชาด', moods: ['smile','explain','ask','think','smirk','guilty','shush','surprise','panic','mad'] };
function nemSrc(mood){ return 'assets/nem-' + (NEM.moods.includes(mood) ? mood : 'smile') + '.webp'; }
function nemImg(mood, cls){ const img = h('img',{class:'nem-img '+(cls||''), src:nemSrc(mood), alt:NEM.name, draggable:'false'}); img.onerror = ()=>{ img.style.visibility='hidden'; }; return img; }

/* บทเรียน: ข้อเท็จจริงทุกข้อตรงกับกติกาที่เว็บใช้ (ไฟล์แกน V.2 + ค่าที่ติดป้ายเสนอ) */
const LESSONS = [
  { id:'welcome', nav:'ต้อนรับ', title:'ยินดีต้อนรับสู่โต๊ะของเรา', scene:'study', lines:[
    ['smile', 'อ้าว มาแล้วหรือ นั่งก่อนสิ ลูกรัก ข้างนอกฝนยังไม่ซาหรอก'],
    ['smile', 'เราชื่อเนเมสไซอาร์ คนทั่วไปเรียกเราว่าศาสดาสีชาด ฟังดูใหญ่โตใช่ไหม แต่บนโต๊ะนี้เราแค่นั่งข้างเจ้า คอยบอกว่าลูกเต๋ากลิ้งไปทางไหน แล้วทำไมมันถึงกลิ้งไปทางนั้น'],
    ['explain', 'คีรันนาเป็นโลกใต้ม่านมานา มีวงศาอยู่สิบสองวงศา อยู่ร่วมกันแบบที่ต่างฝ่ายต่างระแวง เวทมนตร์ที่นี่ต้องจ่ายราคาเสมอ และแผลก็ไม่หายเพราะนอนหนึ่งคืน', 'kins'],
    ['think', 'เพราะอย่างนั้น เกมนี้เลยถามคำถามเดียวซ้ำ ๆ ว่าเจ้ายอมเสียอะไร เพื่อให้ได้สิ่งที่อยากได้ ความเก่งเป็นเรื่องรองลงมา', null],
    ['smirk', 'บทต่อจากนี้สั้น ๆ ทั้งนั้น ฟังแล้วอย่าเพิ่งเชื่อเราทั้งหมดนะ ท้ายบทมีปุ่ม "ลองทำ" ให้ไปจับของจริง เราชอบคนที่ถามกลับ มากกว่าคนที่พยักหน้าตาม'],
    ['ask', 'พร้อมหรือยัง คลิกตรงไหนก็ได้บนฉากนี้ หรือกด Space แล้วเราจะเล่าต่อ'],
  ]},
  { id:'dice', nav:'ลูกเต๋าสองลูก', title:'ทุกอย่างเริ่มที่ลูกเต๋าสองลูก', scene:'study', lines:[
    ['explain', 'เวลาผลยังไม่แน่ เจ้าทอยลูกเต๋าหกหน้าสองลูก แล้วบวก Mod ของค่าพลังที่ใช้เข้าไป ถ้าเรื่องที่ทำเข้ากับนิสัยตัวละครด้วย ก็บวกคะแนนบุคลิกภาพเพิ่มอีก', {t:'roll'}],
    ['explain', 'ผลรวมเอาไปเทียบกับ DC ที่ GM ตั้งไว้ ง่ายก็ห้า กลาง ๆ ก็เจ็ด ยากสิบ ยากมากสิบสอง ส่วนสิบสี่น่ะ เกือบเป็นไปไม่ได้แล้ว', 'dc'],
    ['think', 'ลูกเต๋าสองลูกรวมกันได้เฉลี่ยเจ็ด DC เจ็ดก็เลยครึ่งต่อครึ่ง และ Mod แค่บวกหนึ่งก็ขยับโอกาสไปหลายเปอร์เซ็นต์แล้ว อย่าดูถูกแต้มเล็ก ๆ เชียว', 'avg'],
    ['surprise', 'ถ้าออกหกกับหก นั่นคือ Critical Success ผ่านทันที ออกหนึ่งกับหนึ่งคือ Critical Failure พังทันที ต่อให้ Mod จะสูงแค่ไหนก็ช่วยไม่ได้ ลูกเต๋าไม่สนหรอกว่าเจ้าเป็นใคร', 'crit'],
    ['explain', 'Advantage ให้เจ้าทอยสามลูก แล้วเก็บสองลูกที่ดีที่สุด Disadvantage ก็เก็บสองลูกที่แย่ที่สุด ถ้าได้ทั้งสองอย่างพร้อมกัน มันหักล้างกัน ทอยปกติไป', 'advdis'],
    ['shush', 'ถ้าไม่มีใครตั้ง DC เว็บจะไม่ตัดสินให้ว่าผ่านหรือพลาดนะ เพราะทอยนั้นอาจเป็น Parry ที่ต้องเอาไปเทียบกับคนตี หรือเป็นเรื่องที่ GM อยากชี้ขาดเอง เว็บบอกแค่ตัวเลข ที่เหลือเป็นเรื่องของคนบนโต๊ะ', 'nodc'],
  ], tryLabel:'ลองทอยที่ชีท (ต้องมีตัวละครก่อน)', tryHash:'#chars' },
  { id:'stats', nav:'ค่าพลังหกค่า', title:'ค่าพลังหกค่า และ Mod ที่ซ่อนอยู่ข้างใต้', scene:'study', lines:[
    ['explain', 'ตัวละครมีค่าพลังหกอย่าง STR คือพละกำลัง AGI ความคล่องแคล่ว VIT ความแข็งแรง PER การรับรู้ INF อิทธิพล และ INT ปัญญา ดูตารางข้าง ๆ ไปด้วยก็ได้', 'stats'],
    ['think', 'ค่าดิบอยู่ราว ๆ ห้าถึงยี่สิบ แต่ตัวที่ใช้ทอยจริงคือ Mod เอาค่าดิบหารสองแล้วลบห้า ปัดลง สิบก็เลยเป็นศูนย์ สิบสองเป็นบวกหนึ่ง แปดเป็นลบหนึ่ง', 'modtable'],
    ['smirk', 'สังเกตดี ๆ นะ เลขคี่ไม่ได้ให้ Mod เพิ่ม เก้ากับสิบให้ Mod ต่างกัน แต่สิบกับสิบเอ็ดให้เท่ากัน เวลาแจกแต้ม Extra ให้เล็งเลขคู่ถัดไปเสมอ ปุ่ม Auto Fill ในวิซาร์ดรู้เรื่องนี้ดี'],
    ['explain', 'ค่าพลังรองคิดจาก Mod ทั้งนั้น HP คือสิบบวก VIT Mod บวก STR Mod MP คือสิบบวก INF Mod บวก INT Mod Sanity คือห้าบวก INF Mod ส่วน Passive PER คือเจ็ดบวก PER Mod สูตรอยู่ในตารางข้าง ๆ ไม่ต้องท่อง', 'derived'],
    ['explain', 'Toughness ของแต่ละอวัยวะ เอา VIT ดิบบวก STR ดิบ หารสิบ แล้วบวกหนึ่ง ตัวใหญ่ได้เพิ่มอีกหน่อย ค่านี้อยู่กับเจ้าไปทั้งชีวิต อยากได้เพิ่มต้องหาเกราะหรือของสวมใส่เอา ส่วนของที่แบกไหวคือ STR คูณสามกิโลกรัม ตัวใหญ่แบกได้มากกว่านั้น'],
    ['explain', 'ยังมีค่าสถานะศักยภาพอีกชุด Initiative เท่ากับ PER Mod ส่วน Reflex Might และ Sight เอา Mod ของ AGI STR PER หารสองแล้วบวกหนึ่ง ปัดลงทั้งหมด ตัวเลขพวกนี้จะโผล่ตอนต่อสู้ จำแค่ว่ามันมาจากไหนก็พอ', 'proposed'],
  ]},
  { id:'pers', nav:'บุคลิกภาพ', title:'บุคลิกภาพคือค่าพลังที่เจ้าเลือกเอง', scene:'study', lines:[
    ['ask', 'ทีนี้ถึงคำถามที่เราชอบที่สุด ตัวละครของเจ้าเป็นคนแบบไหนล่ะ', null],
    ['explain', 'มีหกคู่ตรงข้าม เหตุผลกับสัญชาตญาณ เผชิญหน้ากับหลีกเลี่ยง กล้าหาญกับระแวดระวัง เพื่อผู้อื่นกับเพื่อตนเอง เมตตากับอำมหิต และระเบียบกับโกลาหล', 'persaxes'],
    ['explain', 'เจ้าแจกแต้ม สาม สอง สอง หนึ่ง หนึ่ง และศูนย์ ให้คู่ละหนึ่งค่า แล้วเลือกว่าจะเอียงไปข้างไหน ข้างที่เลือกเป็นบวก ข้างตรงข้ามติดลบเท่ากันเป๊ะ'],
    ['shush', 'คนที่กล้าหาญบวกสาม พอต้องทอยอะไรที่ใช้ความระแวดระวัง จะติดลบสาม นี่แหละราคาของการเป็นใครสักคน ไม่มีใครเก่งทุกด้านหรอก แม้แต่เรา', 'persbar'],
    ['smile', 'ในวิซาร์ด แถบแต่ละคู่แบ่งเป็นสีอุ่นกับสีเย็น ข้างที่เจ้าเลือกจะกลืนแถบไปตามระดับ พอเลือกครบ เราจะอ่านนิสัยตัวละครให้ฟัง แล้วบอกด้วยว่าสายการเล่นไหนเข้ากับนางหรือเขา', 'profile'],
    ['smirk', 'ฟังเราได้ แต่ตัดสินใจเองนะลูกรัก คนที่เชื่อเราทุกคำมักจบไม่ค่อยสวย', null],
  ], tryLabel:'ดูขั้นบุคลิกภาพในวิซาร์ด', tryHash:'#wizard' },
  { id:'create', nav:'สร้างตัวละคร 8 ขั้น', title:'สร้างตัวละครทีละขั้น ทั้งหมดแปดขั้น', scene:'study', lines:[
    ['explain', 'ขั้นแรก เลือกวงศา มีให้สิบสองวงศา การ์ดบอกแค่จุดเด่น จุดด้อย กับค่าดิบ อยากอ่านทั้งหมดก็กด "ดูรายละเอียด" ส่วน Beastman ยังไม่เปิดนะ ข้อมูลยังมาไม่ถึง', {t:'steps',cur:0}],
    ['explain', 'ขั้นสอง เลือกพื้นหลังวัยเด็กกับวัยผู้ใหญ่อย่างละใบ แต่ละใบให้แต้มค่าพลังและ Trait ติดตัวมา แผงขวามือจะสรุปให้ว่าเลือกอะไรไปแล้ว และเราก็จะยืนบ่นอยู่ข้าง ๆ นั่นแหละ', 'bgcard'],
    ['explain', 'ขั้นสาม บุคลิกภาพ ขั้นสี่ แต้ม Extra ของวงศา เอาไปใส่ค่าพลังที่อยากยก จำเรื่องเลขคู่ได้ใช่ไหม', {t:'steps',cur:3}],
    ['think', 'ขั้นห้า เลือก Talent ตามค่าพลังที่สูงที่สุดของเจ้า หรือจะเลือก Educated แทนก็ได้ แล้วอัปเกรดความรู้หนึ่งระดับ พร้อมรับทักษะเริ่มต้นจากวงศา ขั้นนี้ยาวที่สุด ค่อย ๆ ดู ทุกช่องมีป้ายบอกว่าได้อะไร', {t:'steps',cur:4}],
    ['explain', 'ขั้นหก เว็บคำนวณค่าพลังรองให้หมด ขั้นเจ็ด ตั้งชื่อ อายุ รูปลักษณ์ แรงจูงใจ สิ่งที่อยากได้ สิ่งที่ต้องการจริง ๆ และสิ่งที่แสดงออกให้คนอื่นเห็น', {t:'steps',cur:6}],
    ['smile', 'ขั้นแปด เลือกชุดเริ่มต้นหนึ่งชุดจากสิบเจ็ดชุด ได้เงินติดตัวสิบห้าเกรฟ กด "เสร็จสิ้น" แล้วชีทก็พร้อม ของในชุดถูกสวมให้เรียบร้อย เกราะก็เติมตามของที่สวม', {t:'steps',cur:7}],
    ['ask', 'คำไหนขีดเส้นประไว้ในวิซาร์ด กดแล้วมีความหมายโผล่มา อย่าเดานะ สงสัยก็กด ในเมื่อถามได้ จะเดาไปทำไม', 'glossary'],
  ], tryLabel:'เริ่มสร้างตัวละครจริง', tryHash:'#wizard', tryNew:true },
  { id:'sheet', nav:'ชีทและปุ่มลอย', title:'ชีทคือหน้าปัดของเจ้า', scene:'study', lines:[
    ['smirk', 'เปิดชีทแล้วมองหาปุ่มลอยข้างจอสี่ปุ่ม กระเป๋า คัมภีร์ ถุงย่าม แล้วก็ทอยเต๋า ลากไปวางตรงไหนก็ได้ กดแล้วจะเปิดเป็นหน้าต่างลอย ลากได้ ย่อขยายได้', 'hud'],
    ['explain', 'ของในกระเป๋ามีชื่อ คุณสมบัติ จำนวน กับน้ำหนัก สวมเมื่อไหร่ก็ย้ายไปอยู่ในถุงย่าม น้ำหนักรวมเทียบกับที่แบกไหวอยู่บนป้ายปุ่มกระเป๋าตลอด แตะของชิ้นไหน รายละเอียดจะขึ้นมาบนสุดของหน้าต่างทันที'],
    ['explain', 'ถุงย่ามมีสายคาดอาวุธอยู่ด้านบน อาวุธหลัก อาวุธรอง และโล่ ข้างล่างเป็นหุ่นสวมใส่ ของที่สวมจะบอกค่าเกราะ A กับ B ของอวัยวะนั้นให้เอง A กันกายภาพทั่วไป B กันการกระแทกหรือชนิดที่วงเล็บไว้ เข็มขัดโซ่ไม่ทบกับเกราะลำตัวนะ ใช้ค่าที่สูงกว่า', 'doll'],
    ['smile', 'ถ้าผังชีทไม่ถูกใจ กด "จัดวางกรอบเอง" แล้วลากทุกกรอบไปวางใหม่ ย่อขยายได้ เว็บจะจำผังของเจ้าไว้ในเบราว์เซอร์นี้', 'layout'],
    ['think', 'แล้วก็ปุ่ม "ใช้ IP" ข้างแต้ม Insight Point นั่นคือทางเดียวที่ตัวละครจะโตขึ้น เดี๋ยวเราค่อยคุยเรื่องนี้กันอีกที', 'ip'],
  ], tryLabel:'ไปที่ตัวละครของฉัน', tryHash:'#chars' },
  { id:'combat', nav:'เทิร์นและระยะ', title:'เมื่อเลือดจะต้องตก: เทิร์น ระยะ และแผนที่', scene:'map', lines:[
    ['explain', 'ฉากต่อสู้ยาวหนึ่งนาที แบ่งเป็นเทิร์นละหกวินาที ทุกคนทอยสองลูกบวก Initiative เพื่อจัดลำดับ พอถึงเทิร์นเจ้า ได้หนึ่ง Swift หนึ่ง Basic และหนึ่ง Cast ใช้ไม่ครบก็หายไปเฉย ๆ เลือกดี ๆ ล่ะ', 'turn'],
    ['explain', 'แผนที่ต่อสู้เป็นตารางยี่สิบคูณยี่สิบ ช่องละสองเมตร GM สุ่มสถานที่ได้ ป่า แม่น้ำ เมือง ถ้ำ ดันเจี้ยน ภูเขา ทะเล บนเรือ แล้วก็อีกเยอะ หรือจะเตรียมแผนที่ไว้ก่อนในคลังแผนที่ก็ได้ หมากของเจ้าลากไปวางช่องไหนก็ได้ที่เดินถึง', {t:'grid',kind:'forest',seed:'tutor-forest',bands:false,title:'สุ่มแผนที่: ป่า'}],
    ['think', 'หิน กำแพง บ้าน ผ่านไม่ได้ น้ำตื้น หิมะ โคลน เศษหิน เดินช้า นับเป็นสองช่อง ส่วนน้ำลึกว่ายได้ แต่ลงไปแล้วเสียเทิร์นนั้น และประกาศโจมตีไม่ได้จนกว่าจะขึ้นฝั่ง เว้นแต่เจ้าเป็นสัตว์น้ำ มองพื้นก่อนวิ่งนะ เราเคยเห็นทหารทั้งกองจมโคลนมาแล้ว', 'terrain'],
    ['explain', 'คลิกหมากของเจ้า ช่องรอบตัวจะมีสี แดงคือเขตปะทะ ติดกันรวมทแยง ทองคือเขตใกล้เคียง ไม่เกินยี่สิบห้าเมตร ไกลกว่านั้นคือเขตไกล ส่วนช่องที่มืดลงคือที่หมากมองไม่เห็น กำแพงกับต้นไม้บังสายตานะ', {t:'grid',kind:'ruins',seed:'tutor-ruins',tok:{x:9,y:10},npc:{x:14,y:7},title:'แดง = ปะทะ · ทอง = ใกล้เคียง (≤ 25 ม.)'}],
    ['explain', 'จากใกล้เคียงเข้าปะทะใช้หนึ่ง Swift ถอยออกจากปะทะก็หนึ่ง Swift เหมือนกัน แต่จะโดนตีฉวยโอกาส ส่วนจากใกล้เคียงไปไกล ใช้ Swift บวกอีกหนึ่ง AP', 'move'],
    ['shush', 'อาวุธประชิดตีได้เฉพาะคนที่อยู่ในเขตปะทะเดียวกัน อาวุธยิงไปได้ทุกเขต แต่ยิงไกลหรือเป้ามีที่กำบังจะติด Disadvantage อ้อ แสงในฉากก็มีผลนะ ถ้ามืด หมากของเจ้าจะเห็นแค่รอบตัว เว้นแต่วงศาของเจ้าจะมองในที่มืดได้', 'weapon'],
  ], tryLabel:'ดูโต๊ะเล่น', tryHash:'#table' },
  { id:'attack', nav:'โจมตีและป้องกัน', title:'โจมตี ป้องกัน และตำแหน่งที่โดน', scene:'map', lines:[
    ['explain', 'คนโจมตีทอย Attack Roll สองลูก ผลรวมเรียกว่า CV ถ้าออกเลขคู่เหมือนกัน นั่นคือ Perfect Strike ฝ่ายรับต้องประกาศว่าจะ Parry หรือ Evade', 'attack'],
    ['mad', 'ถ้าไม่ประกาศ ก็โดนเต็ม ไม่มีต่อรอง เราพูดเรื่องนี้กับทหารใหม่ทุกคน คนที่ไม่ฟังก็ไม่ได้กลับมาฟังซ้ำ'],
    ['explain', 'Parry ทอยสองลูก บวกลูกเพิ่มตามจำนวน Parry Dice จากโล่ แล้วเจ้าเลือกเองว่าจะใช้สองลูกไหน จะเอาสูงสุด หรือจะเอาให้เท่ากับผลของคนตีพอดีเพื่อ Perfect Parry ก็ได้', 'parry'],
    ['explain', 'Evade ทอยสองลูกบวก Reflex ถ้าได้ Advantage ก็เลือกลูกเองเหมือนกัน ส่วน Parry ที่ติด Disadvantage ได้ทอยสองลูกเปล่า ๆ โล่ช่วยไม่ได้ ผลเท่ากับคนตีพอดีคือ Perfect ได้ Swift Action เพิ่มอีกหนึ่งครั้งทันที'],
    ['think', 'พอโดนแล้วดูว่าโดนตรงไหน ผลรวมสอง สาม สิบเอ็ด สิบสอง คือหัว หก เจ็ด แปด คือลำตัว สี่กับเก้าให้ทอยลูกเดียวต่อ หนึ่งถึงสามขาขวา สี่ถึงหกแขนขวา ส่วนห้ากับสิบเป็นข้างซ้ายแบบเดียวกัน', 'hitloc'],
    ['explain', 'โดนหนึ่งครั้ง Toughness ของอวัยวะนั้นลดหนึ่ง แล้ว HP หักเท่าความเสียหายที่เหลือหลังเกราะของอวัยวะนั้นรับไป ถ้าแพ้ทางธาตุ ความเสียหายคูณสอง', 'damage'],
    ['guilty', 'Toughness ของอวัยวะไหนหมด อวัยวะนั้นใช้ไม่ได้ ต้องทอยตารางบาดแผลฉกรรจ์ ถ้าติดลบจนเท่าค่าเต็มก็เสียอวัยวะนั้นไปเลย เราเคยนำทัพในสงครามร้อยปีนะลูกรัก แขนที่หายไปไม่งอกกลับมาเพราะได้พัก คิดก่อนยืนรับดาบ', 'wound'],
  ], tryLabel:'ทอย Parry ดูในหน้าต่างทอยเต๋า', tryHash:'#chars' },
  { id:'mind', nav:'จิตใจและราคาของเวท', title:'สิ่งที่หักได้มีมากกว่ากระดูก', scene:'study', lines:[
    ['shush', 'Sanity คือสติของเจ้า มันถูกดึงออกไปเมื่อเจอสิ่งบิดเบี้ยว เมื่อฝืนใจตัวเอง หรือเมื่อเวทบางบทเรียกเก็บแทน MP', 'sanity'],
    ['think', 'เวทมนตร์ในคีรันนาไม่มีของฟรี บางบทจ่ายด้วยเลือด บางบทจ่ายด้วยสติ อ่านช่อง Cost ของทุกสกิลก่อนร่ายนะ เราเห็นคนร่ายโดยไม่อ่านมาเยอะ ส่วนใหญ่น่าสงสาร', 'cost'],
    ['explain', 'Temporary Health เป็นเกราะชั่วคราวที่บางสกิลหรือสถานะให้มา มันหายไปก่อน HP จริง และพักผ่อนก็ไม่คืน', 'sanity'],
    ['ask', 'ตัวละครของเจ้ามีนิสัยที่เลือกไว้ตั้งแต่สร้าง ถ้าเจ้าให้นางหรือเขาทำอะไรที่ขัดกับนิสัยนั้น GM เรียกเก็บ Sanity เป็นค่าฝืนได้ เรื่องนี้อยู่ที่ดุลยพินิจของโต๊ะ เว็บจะไม่ยุ่ง', null],
  ]},
  { id:'ip', nav:'Insight Point', title:'การเติบโตมีราคา และราคาเขียนไว้ชัด', scene:'study', lines:[
    ['explain', 'ตัวละครได้ Insight Point จากเหตุการณ์สำคัญ จบเซสชันหนึ่งแต้ม เป้าหมายย่อยสอง ภารกิจสำคัญสาม เป้าหมายหลักของเรื่องสี่ ใช้ได้ตอนจบเซสชันหรือช่วง Downtime เท่านั้น สะสมข้ามเซสชันได้ไม่จำกัด', 'ipgain'],
    ['explain', 'IP ซื้อได้สามอย่าง อย่างแรก ยก Mod ของค่าพลังขึ้นหนึ่งขั้น ราคาขึ้นตามขั้น จากติดลบขึ้นมาศูนย์ขั้นละสาม จากนั้นสาม สี่ ห้า หก เจ็ด', 'ipmod'],
    ['explain', 'อย่างที่สอง ยกระดับความรู้ ระดับหนึ่งสี่แต้ม ระดับสองหก ระดับสามเก้า แต่ต้องผ่านประตูของระดับนั้นก่อน เคยใช้จริง มีตำรา หรือมีครู อย่างที่สาม ซื้อทักษะกับเวทตามราคาที่เขียนไว้ในรายการ', 'ipknow'],
    ['think', 'ทักษะระดับ Novice เรียนเองได้ Expert ต้องมีครู ตำรา หรือเคยเห็นใครใช้ ส่วน Master ต้องมีปรมาจารย์ หรือมีเหตุการณ์ในเรื่องรองรับ', 'gates'],
    ['smirk', 'ครูกับตำราเปลี่ยนได้แค่สิทธิ์และราคา ตำราทั่วไปหรือผู้ชำนาญลดให้หนึ่งแต้ม ของหายากหรือปรมาจารย์ลดสอง ใช้ได้สาขาละครั้งต่อช่วงระหว่าง Milestone ส่วนประตูพวกนี้ GM เป็นคนติ๊กยืนยันให้ในหน้าต่าง "ใช้ IP"'],
  ], tryLabel:'เปิดหน้าต่างใช้ IP ที่ชีท', tryHash:'#chars' },
  { id:'online', nav:'โต๊ะออนไลน์', title:'โต๊ะนี้นั่งได้ทั้งที่อยู่คนละเมือง', scene:'map', lines:[
    ['surprise', 'รู้ไหม โต๊ะนี้นั่งได้ทั้งที่อยู่คนละเมือง เข้าสู่ระบบด้วยบัญชี Google ที่มุมขวาบน ตัวละครของเจ้าจะตามไปทุกเครื่อง', 'login'],
    ['explain', 'ชีทของเจ้าเป็นของเจ้าคนเดียว GM กับเพื่อนร่วมโต๊ะจะเห็นก็ต่อเมื่อเจ้าหยิบตัวละครลงบอร์ดในห้องนั้น และเจ้าเลือกได้ว่าจะให้เขาเห็นทั้งชีท หรือเห็นแค่ค่าหลัก ส่วนปุ่ม "ออนไลน์" บอกว่าใครอยู่ตรงไหน'],
    ['explain', 'GM สร้างห้องแล้วส่งลิงก์มา ผู้เล่นกด "วางตัวละครลงบอร์ด" รูปจากชีทจะไปอยู่บนหมาก GM เลือกสถานที่ สุ่มแผนที่หรือโหลดจากคลัง เพิ่ม NPC ซ่อนไว้ ตั้งแสงของฉาก แปะสถานะให้ใครก็ได้ แล้วเริ่มการต่อสู้ ทุกคนเดินหมากของตัวเอง', 'roomflow'],
    ['smile', 'ทุกการทอยในห้องเด้งเป็นลูกเต๋าใหญ่กลางจอของทุกคน และทอยได้ทีละคน ระหว่างที่เต๋าของใครยังหมุนอยู่ คนอื่นก็รอหน่อย ปุ่มทอยอยู่ที่แท็บลูกเต๋ามุมขวาล่าง ลากไปวางตรงไหนก็ได้ ส่วนแชตกับบันทึกการทอยอยู่ใต้แผนที่ พิมพ์ /r 2d6+2 เพื่อทอยเอง /adv กับ /dis ก็มี และ /gm ไว้กระซิบถึง GM', 'dicepop'],
    ['shush', 'ถ้า GM ย้ายเครื่อง ใช้รหัส GM หกตัวของห้องกลับมาเป็น GM ได้ อย่าให้ผู้เล่นเห็นรหัสนั้นเชียว เราเห็นบาปของคนมามากพอจะรู้ว่าเกิดอะไรขึ้น เมื่อผู้เล่นได้รหัส GM', 'gmkey'],
  ], tryLabel:'ไปโต๊ะเล่น', tryHash:'#table' },
  { id:'end', nav:'ส่งท้าย', title:'เท่านี้ก็พอให้เจ้านั่งลงที่โต๊ะได้แล้ว', scene:'study', lines:[
    ['smile', 'เท่านี้ก็พอให้เจ้านั่งลงที่โต๊ะได้แล้ว ที่เหลือเรียนเอาจากการเล่นและเพื่อนร่วมโต๊ะเถอะ'],
    ['explain', 'กฎย่อทั้งหมดอยู่ที่หน้า "กฎย่อ" ศัพท์ที่ขีดเส้นประกดดูได้ทุกที่ในเว็บ และถ้าอยากรู้ว่าเว็บเก็บอะไรของเจ้าไว้บ้าง มีหน้านโยบายอยู่ท้ายหน้าแรก ตอนสร้างตัวละคร เราจะยืนอยู่ข้างเจ้าด้วย คอยบ่น คอยแซว คอยบอกว่าอะไรเข้ากับอะไร', 'rulespage'],
    ['smile', 'จงเฉลิมฉลองเมื่อเริ่มสิ่งใหม่ และจำเรื่องราวบนโต๊ะไว้เล่าต่อ แค่นั้นแหละที่เราขอ', null],
    ['smile', 'ขอให้สายเลือดของเจ้าสืบสานไปนานชั่วกัลป์ ลูกรัก'],
  ], tryLabel:'สร้างตัวละครตัวแรก', tryHash:'#wizard', tryNew:true },
];

/* สถานะ: บทที่ (ch) บรรทัด (ln) เก็บใน localStorage kirana.tutor (รุ่นเก่าเก็บเป็นเลขบท) */
const Tutor = (()=>{ let s = { ch:0, ln:0, auto:false, timer:null, typing:null, done:false }; try { const raw = localStorage.getItem('kirana.tutor'); if (raw){ const v = JSON.parse(raw); if (typeof v === 'number') s.ch = v; else if (v && typeof v === 'object'){ s.ch = v.ch|0; s.ln = v.ln|0; } } } catch(e){} return s; })();
function tutorSave(){ try { localStorage.setItem('kirana.tutor', JSON.stringify({ch:Tutor.ch, ln:Tutor.ln})); } catch(e){} }
function tutorStopTimers(){ if (Tutor.typing){ clearInterval(Tutor.typing); Tutor.typing = null; } if (Tutor.timer){ clearTimeout(Tutor.timer); Tutor.timer = null; } }

function renderTutorial(){
  const root = clear($('#v-tutor'));
  tutorStopTimers();
  if (Tutor.ch < 0 || Tutor.ch >= LESSONS.length) Tutor.ch = 0;
  const L = LESSONS[Tutor.ch];
  if (Tutor.ln < 0 || Tutor.ln >= L.lines.length) Tutor.ln = 0;
  const go = (hash, isNew)=>{ if (isNew) startWizard(null); location.hash = hash; };
  const setLesson = (i, ln)=>{ Tutor.ch = i; Tutor.ln = ln||0; tutorSave(); renderTutorial(); };

  const stage = h('div',{class:'vn scene-'+(L.scene||'study'), tabindex:0, role:'region', 'aria-label':'บทเรียน '+L.title});
  const sprite = nemImg(L.lines[Tutor.ln][0], 'vn-sprite-img');
  const nameEl = h('div',{class:'vn-name'}, h('b',{text:NEM.name}), h('span',{text:NEM.title}));
  const textEl = h('div',{class:'vn-text'});
  const nextEl = h('div',{class:'vn-next',text:'▼'});
  const counter = h('span',{class:'vn-count num'});
  const choices = h('div',{class:'vn-choices hidden'});
  const autoBtn = h('button',{class:'small ghost'+(Tutor.auto?' on':''), title:'เล่นต่อเองเมื่อพูดจบ', onclick:(e)=>{ e.stopPropagation(); Tutor.auto = !Tutor.auto; autoBtn.classList.toggle('on', Tutor.auto); autoBtn.textContent = Tutor.auto ? 'อัตโนมัติ: เปิด' : 'อัตโนมัติ'; if (Tutor.auto && !Tutor.typing) armAuto(); }, text: Tutor.auto ? 'อัตโนมัติ: เปิด' : 'อัตโนมัติ'});
  const top = h('div',{class:'vn-top'},
    h('div',{class:'vn-title'}, h('div',{class:'kicker',text:`บทที่ ${Tutor.ch+1} / ${LESSONS.length}`}), h('h2',{text:L.title})),
    h('div',{class:'row vn-tools'},
      h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); openLessonMenu(); },text:'สารบัญ'}),
      h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); toggleLog(); },text:'อ่านทั้งบท'}),
      autoBtn,
      h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); finishChapter(); },text:'ข้ามบท'})));
  const box = h('div',{class:'vn-box'}, nameEl, textEl, h('div',{class:'vn-foot'}, counter, nextEl), choices);
  const log = h('div',{class:'vn-log hidden'});
  const figHost = h('div',{class:'vn-fighost'});
  stage.append(h('div',{class:'vn-bg'}), h('div',{class:'vn-fog'}), top, h('div',{class:'vn-sprite'}, sprite), figHost, box, log);
  root.append(stage);
  root.append(h('p',{class:'dim vn-hint',text:'คลิกที่ฉาก หรือกด Space / Enter / → เพื่อพูดต่อ · คลิกระหว่างที่ตัวอักษรกำลังขึ้นเพื่อแสดงทั้งบรรทัด · ความคืบหน้าถูกจำไว้ในเครื่องนี้'}));

  function openLessonMenu(){
    const list = h('div',{class:'vn-menu'});
    LESSONS.forEach((x,i)=> list.append(h('button',{class:'toc-i'+(i===Tutor.ch?' on':'')+(i<Tutor.ch?' done':''),onclick:()=>{ modal(null); setLesson(i,0); }}, h('span',{class:'num dim',text:String(i+1).padStart(2,'0')}), h('span',{text:x.nav}), i<Tutor.ch ? h('span',{class:'tag ok',text:'จบแล้ว'}) : null)));
    modal(h('div',null, h('h2',{text:'สารบัญบทเรียน'}), h('p',{class:'dim',style:'font-size:13px',text:'เลือกบทที่อยากฟัง เนเมสไซอาร์จะเริ่มเล่าตั้งแต่ต้นบท'}), list, h('div',{class:'row',style:'margin-top:12px'}, h('button',{class:'small ghost',onclick:()=>{ modal(null); setLesson(0,0); },text:'เริ่มใหม่ตั้งแต่บทแรก'}))));
  }
  function toggleLog(){
    if (!log.classList.contains('hidden')){ log.classList.add('hidden'); return; }
    clear(log);
    log.append(h('div',{class:'row',style:'justify-content:space-between'}, h('b',{text:'บทนี้ทั้งบท'}), h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); log.classList.add('hidden'); },text:'ปิด'})));
    L.lines.forEach(([m,t,f],i)=> log.append(h('div',{class:'vn-logline'+(i===Tutor.ln?' cur':''), onclick:(e)=>{ e.stopPropagation(); Tutor.ln = i; tutorSave(); showLine(); log.classList.add('hidden'); }}, h('img',{src:nemSrc(m),alt:''}), h('div',null, T(t)))));
    log.classList.remove('hidden');
  }
  function armAuto(){ if (!Tutor.auto) return; if (Tutor.timer) clearTimeout(Tutor.timer); const len = L.lines[Tutor.ln][1].length; Tutor.timer = setTimeout(()=>{ Tutor.timer=null; if (Tutor.auto) advance(); }, 1400 + Math.min(4000, len*22)); }
  function typeOut(text, onDone){
    tutorStopTimers();
    clear(textEl); textEl.classList.add('typing');
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let i = 0; const span = h('span'); textEl.append(span);
    const finish = ()=>{ if (Tutor.typing){ clearInterval(Tutor.typing); Tutor.typing=null; } clear(textEl); textEl.classList.remove('typing'); textEl.append(T(text)); nextEl.classList.add('show'); if (onDone) onDone(); };
    if (reduce){ finish(); return; }
    nextEl.classList.remove('show');
    Tutor.typing = setInterval(()=>{ i += 2; span.textContent = text.slice(0, i); if (i >= text.length) finish(); }, 18);
    textEl._finish = finish;
  }
  function figFor(ln){ for (let i=ln;i>=0;i--){ const f = L.lines[i][2]; if (f !== undefined) return f; } return null; }
  function showFig(ln){ const spec = figFor(ln); const key = JSON.stringify(spec||null); if (figHost.dataset.key === key) return; figHost.dataset.key = key; clear(figHost); const node = vnFigure(spec); if (node) figHost.append(node); stage.classList.toggle('has-fig', !!node); }
  function showLine(){
    const [mood, text] = L.lines[Tutor.ln];
    showFig(Tutor.ln);
    Tutor.done = false;
    choices.classList.add('hidden');
    sprite.src = nemSrc(mood); stage.className = 'vn scene-'+(L.scene||'study')+' mood-'+mood;
    sprite.classList.remove('nem-pop'); void sprite.offsetWidth; sprite.classList.add('nem-pop');
    counter.textContent = `${Tutor.ln+1} / ${L.lines.length}`;
    typeOut(text, ()=>{ if (Tutor.ln === L.lines.length-1) showChoices(); else armAuto(); });
  }
  function showChoices(){
    Tutor.done = true; nextEl.classList.remove('show');
    clear(choices);
    if (L.tryHash) choices.append(h('button',{class:'ghost',onclick:(e)=>{ e.stopPropagation(); go(L.tryHash, L.tryNew); },text:'ลองทำ: '+L.tryLabel}));
    if (Tutor.ch < LESSONS.length-1) choices.append(h('button',{class:'primary',onclick:(e)=>{ e.stopPropagation(); setLesson(Tutor.ch+1, 0); },text:'บทถัดไป →'}));
    else choices.append(h('button',{class:'primary',onclick:(e)=>{ e.stopPropagation(); go('#wizard', true); },text:'สร้างตัวละครตัวแรก'}));
    if (Tutor.ln > 0) choices.append(h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); Tutor.ln=0; tutorSave(); showLine(); },text:'ฟังบทนี้อีกครั้ง'}));
    choices.classList.remove('hidden');
  }
  function finishChapter(){ Tutor.ln = L.lines.length-1; tutorSave(); const [mood, text] = L.lines[Tutor.ln]; sprite.src = nemSrc(mood); showFig(Tutor.ln); counter.textContent = `${Tutor.ln+1} / ${L.lines.length}`; tutorStopTimers(); clear(textEl); textEl.append(T(text)); showChoices(); }
  function advance(){
    if (Tutor.typing){ textEl._finish && textEl._finish(); return; }
    if (Tutor.done){ if (Tutor.ch < LESSONS.length-1) setLesson(Tutor.ch+1, 0); return; } // จบบท: คลิก/Space ไปบทถัดไป (บทสุดท้ายใช้ปุ่ม)
    if (Tutor.ln < L.lines.length-1){ Tutor.ln++; tutorSave(); showLine(); }
  }
  function back(){ tutorStopTimers(); if (Tutor.ln > 0){ Tutor.ln--; tutorSave(); showLine(); } else if (Tutor.ch > 0){ setLesson(Tutor.ch-1, LESSONS[Tutor.ch-1].lines.length-1); } }
  stage.addEventListener('click', (e)=>{ if (e.target.closest('button, .term, .vn-log, a')) return; advance(); });
  stage.addEventListener('keydown', (e)=>{ if (e.target.closest('input,textarea')) return; if (e.key===' ' || e.key==='Enter' || e.key==='ArrowRight'){ e.preventDefault(); advance(); } else if (e.key==='ArrowLeft'){ e.preventDefault(); back(); } });
  Tutor._advance = advance; Tutor._back = back; Tutor._stage = stage;
  showLine();
  setTimeout(()=>{ try { stage.focus({preventScroll:true}); } catch(e){} }, 50);
}
/* กด Space/→ ที่ไหนก็ได้ในหน้าสอนเล่น (นอกช่องกรอกข้อความ) */
document.addEventListener('keydown', (e)=>{
  const v = $('#v-tutor'); if (!v || !v.classList.contains('active')) return;
  if (e.target.closest('input,textarea,select,button,.modal')) return;
  if (document.activeElement === Tutor._stage) return; // stage จัดการเอง
  if (e.key===' ' || e.key==='Enter' || e.key==='ArrowRight'){ e.preventDefault(); Tutor._advance && Tutor._advance(); }
  else if (e.key==='ArrowLeft'){ e.preventDefault(); Tutor._back && Tutor._back(); }
});
