/* ===== คลังแผนที่: GM เตรียมด่านและสถานที่ไว้ก่อนเปิดโต๊ะ =====
 * เอกสาร maps/<id> = {id, ownerId, ownerName, name, desc, kind, seed, w, h, cells, light, npcs:[{id,name,hp,init,x,y,nv,hidden,note}], published, createdAt, updatedAt, fromId?, fromName?}
 * ส่วนตัวจนกว่าจะกด "เผยแพร่" (Rules: อ่านได้เฉพาะเจ้าของ ผู้พัฒนา หรือเมื่อ published) · ผู้เล่นค้นหาแผนที่ที่เผยแพร่แล้ว "เก็บเข้าคลัง" เป็นสำเนาของตัวเอง
 * โหมดออฟไลน์เก็บใน localStorage kirana.maps.v1 */
/* v1.18: คอลเลกชัน maps เก็บรายการของคลัง NPC / Asset ด้วย (แยกด้วยฟิลด์ type ดู npcs.js) คลังแผนที่จึงรับเฉพาะเอกสารที่ไม่มี type หรือ type เป็น map */
function isMapDoc(m){ return !!m && (!m.type || m.type==='map'); }
const MapLib = {
  mine: [], pub: [], unsub: [], loaded: false, tab: 'mine', q: '', sort: 'new', localKey: 'kirana.maps.v1',
  loadLocal(){ try { return JSON.parse(localStorage.getItem(this.localKey)||'[]'); } catch(e){ return []; } },
  saveLocal(list){ try { localStorage.setItem(this.localKey, JSON.stringify(list)); } catch(e){} },
  isMine(m){ return !!m && (!Store.db || m.ownerId===Store.me || !m.ownerId); },
  newMap(name){ const id = uid(); const g = generateMap('field', id); return { id, name: name||'แผนที่ใหม่', desc:'', kind:g.kind, seed:g.seed, w:g.w, h:g.h, cells:g.cells, light:'low', npcs:[], published:false, ownerId: Store.me||'local', ownerName: Store.displayName||'', createdAt:Date.now(), updatedAt:Date.now() }; },
  get(id){ return this.mine.find(x=>x.id===id) || this.pub.find(x=>x.id===id) || null; },
  async save(m){
    m.updatedAt = Date.now(); m.ownerId = m.ownerId || Store.me || 'local'; if (this.isMine(m)) m.ownerName = Store.displayName || m.ownerName || '';
    const i = this.mine.findIndex(x=>x.id===m.id); if (i>=0) this.mine[i] = m; else this.mine.push(m);
    if (!Store.db){ this.saveLocal(this.mine); return true; }
    const doc = JSON.parse(JSON.stringify(m)); if (doc.image){ if (doc.image.data) this.images[m.id] = doc.image.data; delete doc.image.data; doc.image.has = true; }
    try { await Store.db.doc('maps/'+m.id).set(doc); return true; }
    catch(e){ console.warn('save map', e); toast('บันทึกแผนที่ไม่ได้ (สิทธิ์ไม่พอ หรือ Rules ยังไม่ใช่รุ่น v1.5)'); return false; }
  },
  async remove(id){ this.mine = this.mine.filter(x=>x.id!==id); delete this.images[id]; if (!Store.db){ this.saveLocal(this.mine); return true; } try { await Store.db.doc('maps/'+id).delete(); Store.db.doc('mapimages/'+id).delete().catch(()=>{}); return true; } catch(e){ toast('ลบแผนที่ไม่ได้'); return false; } },
  /* คลังของฉัน (อัปเดตสด) · ผู้พัฒนาเห็นทุกแผนที่ */
  subscribe(onChange){
    if (!Store.db){ this.mine = this.loadLocal(); this.loaded = true; onChange(); return; }
    if (this.unsub.length){ onChange(); return; }
    try { const q = Store.isDevUid ? Store.db.collection('maps') : Store.db.collection('maps').where('ownerId','==',Store.me);
      this.unsub.push(q.onSnapshot(snap=>{ this.mine = snapDocs(snap).filter(Boolean).filter(isMapDoc); this.loaded = true; onChange(); }, e=>{ console.warn('maps', e); this.loaded = true; onChange(); })); }
    catch(e){ console.warn(e); this.loaded = true; onChange(); }
  },
  async loadPublished(){
    if (!Store.db){ this.pub = this.loadLocal().filter(m=>m.published); return this.pub; }
    try { const snap = await Store.db.collection('maps').where('published','==',true).limit(500).get(); this.pub = snapDocs(snap).filter(Boolean).filter(isMapDoc).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)); }
    catch(e){ console.warn('pub maps', e); toast('โหลดแผนที่ที่เผยแพร่ไม่ได้'); }
    return this.pub;
  },
  /* เก็บสำเนาเข้าคลังของฉัน (ส่วนตัว จำชื่อผู้สร้างต้นฉบับไว้) · ภาพประกอบติดไปเฉพาะสำเนาของเจ้าของเอง */
  async copyToMine(src, rename){
    const m = JSON.parse(JSON.stringify(src)); m.id = uid(); m.ownerId = Store.me||'local'; m.ownerName = Store.displayName||''; m.published = false;
    const foreign = !!(src.ownerId && src.ownerId !== (Store.me||'local'));
    if (foreign){ m.fromId = src.id; m.fromName = src.ownerName||''; delete m.image; } else { m.fromId = src.fromId||null; m.fromName = src.fromName||''; }
    m.name = rename || src.name; m.createdAt = Date.now();
    if (!foreign && src.image){ const data = await this.loadImage(src); if (data){ if (Store.db){ m.image = {...src.image, has:true}; delete m.image.data; await this.saveImage(m, data); } else m.image = {...src.image, data}; } else delete m.image; }
    return (await this.save(m)) ? m : null;
  },
  /* ---- ภาพประกอบ PNG ของแผนที่: เจ้าของเท่านั้น (ไม่ติดไปกับการเผยแพร่) ---- */
  images: {},
  async loadImage(m){ if (!m || !m.image) return null; if (m.image.data) return m.image.data; if (this.images[m.id]) return this.images[m.id]; if (!Store.db) return null; try { const d = docData(await Store.db.doc('mapimages/'+m.id).get()); if (d && d.data){ this.images[m.id] = d.data; return d.data; } } catch(e){ console.warn('map image', e); } return null; },
  async saveImage(m, data){ this.images[m.id] = data; if (!Store.db){ m.image = Object.assign(m.image||{}, {data}); if (this.mine.some(x=>x.id===m.id)) this.saveLocal(this.mine); return true; } try { await Store.db.doc('mapimages/'+m.id).set({ id: m.id, ownerId: Store.me, data, at: Date.now() }); m.image = Object.assign(m.image||{}, {has:true}); delete m.image.data; return true; } catch(e){ console.warn('save image', e); toast('บันทึกภาพไม่ได้ (ภาพใหญ่เกิน หรือ Rules ยังไม่ใช่รุ่น v1.6)'); return false; } },
  async deleteImage(m){ delete this.images[m.id]; delete m.image; if (Store.db) try { await Store.db.doc('mapimages/'+m.id).delete(); } catch(e){} },
};
/* ย่อรูปให้พอเหมาะกับแผนที่ 20×20 และไม่หนักเกินฐานข้อมูล: ด้านยาวสุด 800px เข้ารหัส WebP (มีความโปร่งใส) ไม่เกินราว 350KB ถ้ายังเกิน ย่อลงอีก */
function shrinkMapImage(file){
  return new Promise((resolve, reject)=>{ const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = ()=>{ URL.revokeObjectURL(url); let maxSide = 800, out = '';
      for (let i=0; i<6; i++){ const sc = Math.min(1, maxSide/Math.max(img.width, img.height)); const cv = document.createElement('canvas'); cv.width = Math.max(1, Math.round(img.width*sc)); cv.height = Math.max(1, Math.round(img.height*sc)); cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); out = cv.toDataURL('image/webp', 0.82); if (!out.startsWith('data:image/webp')) out = cv.toDataURL('image/jpeg', 0.82); if (out.length <= 350000 || maxSide <= 300) break; maxSide = Math.round(maxSide*0.8); }
      resolve({ data: out, ratio: img.height/img.width, bytes: Math.round(out.length*0.75) }); };
    img.onerror = ()=>{ URL.revokeObjectURL(url); reject(new Error('อ่านรูปไม่ได้')); }; img.src = url; });
}
/* ภาพย่อของแผนที่ (canvas สีตามชนิดพื้น) */
const TILE_COLOR = { '.':'#2e3b2a', ',':'#36522f', 'T':'#2f6b3a', 'W':'#1b3f6b', 'w':'#2b5e8a', 'R':'#5a5f66', 'r':'#3f4348', '=':'#6b5a3e', 'F':'#5b4a35', '#':'#23262c', 'D':'#8a5a2b', 'S':'#c2a35f', 's':'#dfe8f0', 'B':'#8b6a3e', 'H':'#5a3f2b', 'M':'#4a3f2a', 'C':'#7a6a55', 'P':'#8d8273', 'L':'#c84a1a', '~':'#07090c', 'G':'#5a6a58', 'A':'#b08a3a', 'X':'#ffb24a' };
function mapCanvas(m, px){
  const cv = document.createElement('canvas'); cv.width = cv.height = MAP_W*px; cv.className = 'mapthumb';
  const ctx = cv.getContext('2d'); const cells = m.cells||'';
  for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){ ctx.fillStyle = TILE_COLOR[cells[y*MAP_W+x]] || TILE_COLOR['.']; ctx.fillRect(x*px, y*px, px, px); }
  for (const n of m.npcs||[]){ if (n.kind==='asset'){ ctx.fillStyle = '#d4a84a'; ctx.fillRect(n.x*px+px*0.15, n.y*px+px*0.15, px*0.7, px*0.7); continue; } ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(n.x*px+px/2, n.y*px+px/2, px*0.4, 0, Math.PI*2); ctx.fill(); }
  return cv;
}
function mapAssetCount(m){ return (m.npcs||[]).filter(n=>n.kind==='asset').length; }
function mapNpcCount(m){ return (m.npcs||[]).length - mapAssetCount(m); }
function mapMeta(m){ return h('div',{class:'gives'}, tag((MAP_KINDS.find(x=>x[0]===m.kind)||['','?'])[1]), tag('💡 '+lightLabel(m.light||'low')), mapNpcCount(m) ? tag(`${mapNpcCount(m)} NPC`,'neg') : null, mapAssetCount(m) ? tag(`${mapAssetCount(m)} Asset`,'prop') : null, m.published ? tag('เผยแพร่แล้ว','ok') : tag('ส่วนตัว'), m.fromName ? tag('จาก '+m.fromName,'prop') : null, m.image ? tag('🖼 มีภาพประกอบ (เฉพาะเจ้าของ)') : null); }

/* ก่อนเผยแพร่: เตือนว่าภาพ PNG ไม่ติดไปด้วย (ผู้ใช้เคาะ 9 พ.ย. 2026) */
function confirmPublish(m){ if (m.published) return true; if (!m.image) return true; return confirm(`เผยแพร่ "${m.name||'แผนที่'}"?\n\nภาพประกอบ PNG จะไม่ติดไปกับการเผยแพร่ คนที่เก็บสำเนาจะได้เฉพาะพื้น ระดับแสง และ NPC ส่วนภาพยังอยู่ในคลังของคุณคนเดียว`); }
/* ---- หน้า #maps: คลังของฉัน + ค้นหาแผนที่ที่เผยแพร่ ---- */
function renderMaps(){
  const root = clearKeep($('#v-maps'));
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'สร้างและค้นหาแผนที่'}), h('p',{text:'GM เตรียมด่านและสถานที่ไว้ก่อนเปิดโต๊ะ วาดพื้น ตั้งระดับแสง วาง NPC แล้วเก็บไว้ในคลังส่วนตัว แผนที่จะยังเป็นส่วนตัวจนกว่าจะกดเผยแพร่ ผู้เล่นคนอื่นค้นหาแผนที่ที่เผยแพร่แล้วเก็บสำเนาไปใช้ในโต๊ะของตัวเองได้ และให้ดาวกับคอมเมนต์บอกผู้สร้างได้ว่าใช้แล้วเป็นอย่างไร'})),
    h('div',{class:'row'}, h('button',{class:'primary',onclick:async()=>{ const m = MapLib.newMap(); if (await MapLib.save(m)) location.hash = '#mapedit-'+m.id; },text:'+ สร้างแผนที่ใหม่'}))));
  if (!Store.db) root.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'โหมดออฟไลน์: แผนที่เก็บในเบราว์เซอร์นี้เท่านั้น เผยแพร่ให้คนอื่นเห็นไม่ได้จนกว่าจะเชื่อมต่อ'));
  const tabs = h('div',{class:'row tabs',style:'margin-bottom:10px'},
    h('button',{class:'small'+(MapLib.tab==='mine'?' primary':''),onclick:()=>{ MapLib.tab='mine'; renderMaps(); },text:'คลังของฉัน'}),
    h('button',{class:'small'+(MapLib.tab==='pub'?' primary':''),onclick:async()=>{ MapLib.tab='pub'; renderMaps(); await MapLib.loadPublished(); if (location.hash==='#maps') renderMaps(); },text:'ค้นหาแผนที่ที่เผยแพร่'}));
  const q = h('input',{placeholder:'ค้นหาชื่อ สถานที่ หรือคำอธิบาย',style:'min-width:240px',value:MapLib.q}); q.oninput = ()=>{ MapLib.q = q.value; drawList(); };
  tabs.append(q);
  // v1.19: ดาวและคอมเมนต์ของแผนที่ที่เผยแพร่ (ตัวเลือกการเรียงอยู่ในแท็บค้นหา ปุ่มรีวิวของฉันอยู่ทั้งสองแท็บ)
  const rvSort = MapLib.tab==='pub' ? rvSortSelect(MapLib, ()=>drawList()) : null; if (rvSort) tabs.append(rvSort);
  const rvMine = rvMineButton(()=>{ if (location.hash==='#maps') renderMaps(); }); if (rvMine) tabs.append(rvMine);
  root.append(tabs);
  const host = h('div'); root.append(host);
  function drawList(){
    clear(host);
    const k = MapLib.q.trim().toLowerCase();
    const filt = (arr)=> arr.filter(m => !k || (m.name||'').toLowerCase().includes(k) || (m.desc||'').toLowerCase().includes(k) || ((MAP_KINDS.find(x=>x[0]===m.kind)||['',''])[1]).includes(k) || (m.ownerName||'').toLowerCase().includes(k));
    if (MapLib.tab==='mine'){
      if (!MapLib.loaded){ host.append(h('div',{class:'card dim',text:'กำลังโหลดคลังของคุณ…'})); return; }
      const mine = filt(MapLib.mine.filter(m=>MapLib.isMine(m))).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
      const others = Store.isDevUid ? filt(MapLib.mine.filter(m=>!MapLib.isMine(m))) : [];
      if (!mine.length) host.append(h('div',{class:'card dim',text: MapLib.q ? 'ไม่พบแผนที่ที่ตรงกับคำค้น' : 'คลังยังว่าง กด "+ สร้างแผนที่ใหม่" หรือไปเก็บจากแท็บ "ค้นหาแผนที่ที่เผยแพร่"'}));
      else host.append(h('div',{class:'grid wide'}, mine.map(m=>mapCard(m, true))));
      if (others.length){ host.append(h('h3',{style:'margin:18px 0 8px',text:'แผนที่ของผู้ใช้คนอื่น (มุมมองผู้พัฒนา)'})); host.append(h('div',{class:'grid wide'}, others.map(m=>mapCard(m, false)))); }
    } else {
      const pub = ReviewLib.sorted(filt(MapLib.pub), MapLib.sort);
      if (!pub.length) host.append(h('div',{class:'card dim',text: MapLib.q ? 'ไม่พบแผนที่ที่ตรงกับคำค้น' : 'ยังไม่มีใครเผยแพร่แผนที่ (หรือกำลังโหลด)'}));
      else host.append(h('div',{class:'grid wide'}, pub.map(m=>mapCard(m, MapLib.isMine(m)))));
    }
  }
  MapLib.subscribe(()=>{ if (location.hash==='#maps') drawList(); });
  if (MapLib.tab==='pub' && !MapLib.pub.length) MapLib.loadPublished().then(()=>{ if (location.hash==='#maps') drawList(); });
  if (Store.db){ const before = ReviewLib.at, wasLoaded = ReviewLib.loaded; ReviewLib.load().then(()=>{ if ((ReviewLib.at === before && wasLoaded) || location.hash!=='#maps') return; if (rvMine) rvMine.textContent = rvMineLabel(); drawList(); }); }
  drawList();
}
function mapCard(m, mine){
  const card = h('div',{class:'card mapcard'});
  card.append(h('div',{class:'row',style:'gap:12px;align-items:flex-start'}, h('div',{class:'thumbwrap',onclick:()=>previewMap(m)}, mapCanvas(m, 6)),
    h('div',{style:'flex:1;min-width:160px'}, h('h3',{style:'margin:0',text:m.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',style:'font-size:12px',text:(m.ownerName? 'โดย '+m.ownerName+' · ' : '') + new Date(m.updatedAt||0).toLocaleDateString('th-TH')}), mapMeta(m), rvChip(m, ()=>{ if (location.hash==='#maps') renderMaps(); }), m.desc ? h('p',{class:'desc',style:'margin:6px 0 0;font-size:13px',text:m.desc.slice(0,160)}) : null)));
  const row = h('div',{class:'row',style:'margin-top:8px'});
  row.append(h('button',{class:'small ghost',onclick:()=>previewMap(m),text:'ดู'}));
  if (mine){
    row.append(h('button',{class:'small primary',onclick:()=>{ location.hash='#mapedit-'+m.id; },text:'แก้ไข'}),
      h('button',{class:'small'+(m.published?' on':''),title: m.published ? 'เอาออกจากหน้าค้นหา (สำเนาที่คนอื่นเก็บไปแล้วยังอยู่กับเขา)' : 'ให้ทุกคนค้นหาและเก็บสำเนาได้',onclick:async()=>{ if (!confirmPublish(m)) return; m.published = !m.published; if (await MapLib.save(m)) toast(m.published ? 'เผยแพร่แล้ว ทุกคนค้นหาเจอ' : 'ยกเลิกเผยแพร่แล้ว'); renderMaps(); },text: m.published ? 'ยกเลิกเผยแพร่' : 'เผยแพร่'}),
      h('button',{class:'small ghost',onclick:async()=>{ const c = await MapLib.copyToMine(m, (m.name||'แผนที่')+' (สำเนา)'); if (c) { toast('ทำสำเนาแล้ว'); renderMaps(); } },text:'ทำสำเนา'}),
      h('button',{class:'small ghost',onclick:async()=>{ if (!confirm(`ลบแผนที่ "${m.name}" ถาวร?`)) return; await MapLib.remove(m.id); renderMaps(); },text:'ลบ'}));
  } else {
    row.append(h('button',{class:'small primary',title:'เก็บสำเนาไว้ในคลังของคุณ แก้ไขและใช้ในโต๊ะของตัวเองได้',onclick:async()=>{ const c = await MapLib.copyToMine(m); if (c){ toast(`เก็บ "${m.name}" เข้าคลังของคุณแล้ว`); } },text:'เก็บเข้าคลัง'}));
  }
  card.append(row);
  return card;
}
function previewMap(m){
  modal(h('div',null, h('h3',{text:m.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',style:'font-size:12px',text:(m.ownerName? 'โดย '+m.ownerName : '')}), mapMeta(m), rvChip(m, ()=>{ if (location.hash==='#maps') renderMaps(); }), m.desc ? h('p',{class:'desc',text:m.desc}) : null,
    h('div',{style:'margin-top:8px'}, mapCanvas(m, 16)),
    (m.npcs||[]).length ? h('div',{style:'margin-top:8px'}, h('b',{text:'NPC และ Asset ที่เตรียมไว้: '}), (m.npcs||[]).map(n=>n.kind==='asset' ? `${n.icon||'📦'} ${n.name}${n.hidden?' (ซ่อน)':''}` : `${n.name} (HP ${n.hp}${n.hidden?' ซ่อน':''})`).join(' · ')) : null));
}

/* ---- ตัวแก้ไขแผนที่ #mapedit-<id> ---- */
const MapEd = { brush: '.', tool: 'paint', npc: null, imgMode: false };
function renderMapEditor(id){
  const root = clearKeep($('#v-maps'));
  const draw = ()=>{
    const m = MapLib.get(id);
    if (!m){ clear(root); root.append(h('div',{class:'card'}, MapLib.loaded ? 'ไม่พบแผนที่นี้ในคลังของคุณ' : 'กำลังโหลด…'), h('button',{style:'margin-top:10px',onclick:()=>{ location.hash='#maps'; },text:'← กลับคลังแผนที่'})); return; }
    if (!MapLib.isMine(m) && !Store.isDevUid){ clear(root); root.append(h('div',{class:'card',text:'แผนที่นี้ไม่ใช่ของคุณ เก็บสำเนาเข้าคลังก่อนแล้วค่อยแก้'}), h('button',{style:'margin-top:10px',onclick:()=>{ location.hash='#maps'; },text:'← กลับคลังแผนที่'})); return; }
    clear(root);
    let dirty = false; const markDirty = ()=>{ dirty = true; saveBtn.textContent = 'บันทึก •'; };
    const saveBtn = h('button',{class:'primary small',onclick:async()=>{ if (await MapLib.save(m)){ dirty = false; saveBtn.textContent = 'บันทึกแล้ว'; toast('บันทึกแผนที่แล้ว'); } },text:'บันทึก'});
    const name = h('input',{value:m.name||'',placeholder:'ชื่อแผนที่ เช่น สะพานข้ามเหวนอร์ลัน',style:'min-width:260px',oninput:(e)=>{ m.name = e.target.value; markDirty(); }});
    const desc = h('textarea',{placeholder:'คำอธิบาย บรรยากาศ จุดสำคัญ กับดัก แนวทางการใช้ (ผู้เล่นที่ค้นหาเจอจะเห็นข้อความนี้)',style:'min-height:70px'}); desc.value = m.desc||''; desc.oninput = ()=>{ m.desc = desc.value; markDirty(); };
    const kindSel = h('select',null, MAP_KINDS.map(([k,l])=>h('option',{value:k,selected:k===m.kind,text:l})));
    const lightSel = h('select',null, LIGHTS.map(([k,l])=>h('option',{value:k,selected:k===(m.light||'low'),text:l}))); lightSel.onchange = ()=>{ m.light = lightSel.value; markDirty(); draw(); };
    const head = h('div',{class:'stephead'}, h('div',null, h('h2',{text:'แก้ไขแผนที่'}), h('p',{text:'เลือกพู่กันแล้วคลิกหรือลากบนตารางเพื่อวาดพื้น เครื่องมือ NPC วางศัตรูที่เตรียมไว้ (ซ่อนจนกว่า GM จะเปิดเผย) · 1 ช่อง = 2 เมตร'})),
      h('div',{class:'row'}, saveBtn, h('button',{class:'small'+(m.published?' on':''),onclick:async()=>{ if (!confirmPublish(m)) return; m.published = !m.published; if (await MapLib.save(m)){ dirty=false; toast(m.published ? 'เผยแพร่แล้ว' : 'ยกเลิกเผยแพร่แล้ว'); draw(); } },text: m.published ? 'ยกเลิกเผยแพร่' : 'เผยแพร่'}), h('button',{class:'small ghost',onclick:()=>{ if (dirty && !confirm('ยังไม่ได้บันทึก ออกเลยไหม?')) return; location.hash='#maps'; },text:'← คลังแผนที่'})));
    root.append(head);
    const left = h('div'), right = h('div');
    left.append(h('div',{class:'card',style:'margin-bottom:10px'}, h('div',{class:'row'}, name, h('span',{class:'dim',style:'font-size:12px',text:'สถานที่'}), kindSel, h('button',{class:'small',onclick:()=>{ const g = generateMap(kindSel.value, uid()); m.kind = g.kind; m.seed = g.seed; m.cells = g.cells; markDirty(); draw(); },text:'สุ่มพื้นจากสถานที่นี้'}), h('span',{class:'dim',style:'font-size:12px',text:'💡 แสง'}), lightSel), desc, h('div',{class:'dim',style:'font-size:11.5px;margin-top:4px',text:LIGHT_NOTE[m.light||'low']||''})));
    // พู่กัน
    const pal = h('div',{class:'row palette'});
    for (const [k,v] of Object.entries(TILE)) pal.append(h('button',{class:'small pal'+(MapEd.tool==='paint'&&MapEd.brush===k?' on':''),title:v.th,onclick:()=>{ MapEd.tool='paint'; MapEd.brush=k; draw(); }}, h('i',{class:'sw',style:'background:'+(TILE_COLOR[k]||'#333')}), ' '+v.th));
    pal.append(h('button',{class:'small pal'+(MapEd.tool==='npc'?' on':''),onclick:()=>{ MapEd.tool='npc'; draw(); },text:'👹 วาง NPC'}), h('button',{class:'small pal'+(MapEd.tool==='erase'?' on':''),onclick:()=>{ MapEd.tool='erase'; draw(); },text:'✕ เอา NPC ออก'}));
    left.append(pal);
    if (MapEd.tool==='npc'){ MapEd.npc = MapEd.npc || {name:'ศัตรู', hp:10, init:0, nv:false, aquatic:false, hidden:true}; const n = MapEd.npc; left.append(h('div',{class:'row',style:'margin:6px 0'}, h('input',{value:n.name,placeholder:'ชื่อ NPC',style:'width:150px',oninput:(e)=>{ n.name=e.target.value; }}), h('label',{class:'fld'}, h('span',{text:'HP สูงสุด'}), h('input',{type:'number',value:n.hp,style:'width:64px',oninput:(e)=>{ n.hp=+e.target.value||1; }})), h('label',{class:'fld'}, h('span',{text:'Initiative'}), h('input',{type:'number',value:n.init,style:'width:56px',oninput:(e)=>{ n.init=+e.target.value||0; }})), h('label',{class:'fld chk',title:'มองเห็นในความมืด (Dark Vision) ไม่ติดตาบอดในที่มืด'}, h('input',{type:'checkbox',checked:n.nv,onchange:(e)=>{ n.nv=e.target.checked; }}), h('span',{text:'Dark Vision'})), h('label',{class:'fld chk',title:'สัตว์น้ำหรือเงือก: อยู่ในน้ำลึกแล้วโจมตีได้'}, h('input',{type:'checkbox',checked:n.aquatic,onchange:(e)=>{ n.aquatic=e.target.checked; }}), h('span',{text:'🐟 สัตว์น้ำ'})), h('label',{class:'fld chk'}, h('input',{type:'checkbox',checked:n.hidden,onchange:(e)=>{ n.hidden=e.target.checked; }}), h('span',{text:'ซ่อนตอนเริ่ม'})), h('span',{class:'dim',style:'font-size:12px',text:'แล้วคลิกช่องบนแผนที่'}))); }
    // ภาพประกอบ PNG (ส่วนตัวของเจ้าของคลัง)
    const imgFile = h('input',{type:'file',accept:'image/png,image/jpeg,image/webp',class:'sr'});
    imgFile.onchange = async (e)=>{ const f = e.target.files[0]; if (!f) return; try { const res = await shrinkMapImage(f); const w = MAP_W; const hgt = Math.min(MAP_H*3, Math.round(w*res.ratio*4)/4); m.image = Object.assign({}, m.image||{}, {x:0, y:0, w, h:hgt, opacity:.9, has:true}); if (await MapLib.saveImage(m, res.data)){ MapEd.imgMode = true; markDirty(); toast(`ใส่ภาพแล้ว (${Math.round(res.bytes/1024)} KB) ลากภาพเพื่อย้าย ลากมุมขวาล่างเพื่อย่อขยาย กด Shift ค้างเพื่อปรับสัดส่วนอิสระ`); draw(); } } catch(err){ toast('ใส่ภาพไม่ได้: '+(err && err.message || err)); } };
    const imgBar = h('div',{class:'row imgbar',style:'margin:4px 0 6px'}, h('span',{class:'dim',style:'font-size:12px',text:'🖼 ภาพประกอบ'}),
      h('button',{class:'small',onclick:()=>imgFile.click(),text: m.image ? 'เปลี่ยนภาพ' : 'ใส่ภาพ PNG'}), imgFile,
      m.image ? h('button',{class:'small'+(MapEd.imgMode?' on':''),title:'เปิดเพื่อลากย้ายและย่อขยายภาพ ปิดเพื่อกลับไปวาดพื้น',onclick:()=>{ MapEd.imgMode = !MapEd.imgMode; draw(); },text: MapEd.imgMode ? 'กำลังจัดภาพ (คลิกเพื่อกลับไปวาดพื้น)' : 'จัดตำแหน่งภาพ'}) : null,
      m.image ? h('label',{class:'fld'}, h('span',{text:'ความทึบ'}), h('input',{type:'range',min:0.2,max:1,step:0.05,value:m.image.opacity==null?0.9:m.image.opacity,style:'width:90px',oninput:(e)=>{ m.image.opacity = +e.target.value; const ov = left.querySelector('.mapimg'); if (ov) ov.style.opacity = m.image.opacity; markDirty(); }})) : null,
      m.image ? h('button',{class:'small ghost',onclick:async()=>{ if (!confirm('ลบภาพประกอบออกจากแผนที่นี้?')) return; await MapLib.deleteImage(m); MapEd.imgMode = false; markDirty(); draw(); },text:'ลบภาพ'}) : null,
      h('span',{class:'dim',style:'font-size:11.5px',text:'ภาพย่อให้ไม่เกิน 800px และราว 350KB อยู่ในคลังของคุณคนเดียว ไม่ติดไปกับการเผยแพร่ แต่จะแสดงในห้องที่คุณโหลดแผนที่นี้'}));
    left.append(imgBar);
    // ตาราง
    const gridwrap = h('div',{class:'gridwrap'+(MapEd.imgMode?' imgmode':'')});
    const grid = h('div',{class:'gridmap painting'});
    let painting = false;
    const paintAt = (x,y)=>{ if (MapEd.tool==='paint'){ const a = m.cells.split(''); if (a[y*MAP_W+x]===MapEd.brush) return; a[y*MAP_W+x] = MapEd.brush; m.cells = a.join(''); markDirty(); redraw(); } };
    const npcAt = (x,y)=> (m.npcs||[]).find(n=>n.x===x && n.y===y);
    const cellEls = [];
    for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){
      const cell = h('div',{class:'cell',dataset:{x,y}});
      cell.onpointerdown = (e)=>{ e.preventDefault(); if (MapEd.tool==='paint'){ painting = true; paintAt(x,y); } else if (MapEd.tool==='npc'){ if (npcAt(x,y)){ toast('มี NPC อยู่แล้ว'); return; } if (!cellPassable(m, x, y)){ toast('ช่องนี้ผ่านไม่ได้'); return; } if (!MapEd.npc.aquatic && !cellStandable(m, x, y)){ toast('น้ำลึก วางได้เฉพาะ NPC ที่เป็นสัตว์น้ำ'); return; } m.npcs = m.npcs||[]; m.npcs.push({id:uid(), ...JSON.parse(JSON.stringify(MapEd.npc)), x, y}); markDirty(); redraw(); } else if (MapEd.tool==='erase'){ const n = npcAt(x,y); if (n){ m.npcs = m.npcs.filter(o=>o!==n); markDirty(); redraw(); } } };
      cell.onpointerenter = ()=>{ if (painting && MapEd.tool==='paint') paintAt(x,y); };
      cellEls.push(cell); grid.append(cell);
    }
    grid.onpointerup = grid.onpointerleave = ()=>{ painting = false; };
    const redraw = ()=>{ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){ const cell = cellEls[y*MAP_W+x]; const ch = mapCell(m,x,y); const tile = TILE[ch]||TILE['.']; cell.className = 'cell t-'+(ch.replace(/[^A-Za-z]/g, c=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[c]||'ground'))); cell.title = `(${x},${y}) ${tile.th}`; clear(cell); const n = npcAt(x,y); if (n){ const ico = icoClean(n.ico); const tk = h('div',{class:'gtok '+(n.kind==='asset'?'asset':'npc')+(n.hidden?' hid':''),title: n.kind==='asset' ? `${n.name} (Asset)` : `${n.name} HP ${n.hp}`}); if (ico){ const face = h('div',{class:'face hasico',style:`background:${ico.b}`}); face.append(icoSvg(ico)); tk.append(face); } else tk.append(h('span',{class:'ini',text: n.kind==='asset' ? (n.icon||'📦') : (n.name||'?').slice(0,2)})); cell.append(tk); } } npcList(); };
    gridwrap.append(grid);
    if (m.image){ const dataNow = m.image.data || MapLib.images[m.id]; if (dataNow) gridwrap.append(mapImageOverlay(Object.assign(m.image, {data: dataNow}), ()=>{ markDirty(); })); else MapLib.loadImage(m).then(d=>{ if (d && location.hash==='#mapedit-'+id) draw(); }); }
    left.append(gridwrap);
    const used = ()=>[...new Set(m.cells.split(''))].filter(k=>TILE[k]);
    left.append(h('div',{class:'legend'}, used().map(k=>h('span',{class:'lg'}, h('i',{class:'sw',style:'background:'+(TILE_COLOR[k]||'#333')}), TILE[k].th))));
    // NPC list
    const npcBox = h('div',{class:'card',style:'margin-bottom:10px'});
    const npcList = ()=>{ clear(npcBox); npcBox.append(h('h3',{text:`NPC และ Asset ที่เตรียมไว้ (${(m.npcs||[]).length})`})); if (!(m.npcs||[]).length) npcBox.append(h('p',{class:'dim',style:'font-size:12.5px',text:'เลือกเครื่องมือ "วาง NPC" แล้วคลิกบนแผนที่ NPC ทุกตัวจะถูกเพิ่มเข้าห้องแบบซ่อนไว้เมื่อโหลดแผนที่นี้'})); for (const n of m.npcs||[]) npcBox.append(h('div',{class:'row',style:'gap:6px;font-size:13px;margin-top:4px'}, h('b',{text:n.name}), n.kind==='asset' ? tag('Asset','prop') : null, h('span',{class:'num dim',text: n.kind==='asset' ? `(${n.x},${n.y})` : `HP ${n.hp} · Init ${signed(n.init||0)} · (${n.x},${n.y})`}), n.torch ? tag('🔥','prop') : null, n.nv? tag('👁 Dark Vision'):null, n.aquatic? tag('🐟 สัตว์น้ำ','stat'):null, n.hidden? tag('ซ่อน'):tag('เปิดเผย','warn'), h('button',{class:'small ghost',style:'margin-left:auto',onclick:()=>{ m.npcs = m.npcs.filter(o=>o!==n); markDirty(); redraw(); },text:'✕'}))); };
    right.append(npcBox);
    right.append(h('div',{class:'card'}, h('h3',{text:'ใช้แผนที่นี้'}), h('p',{class:'dim',style:'font-size:12.5px',text:'เปิดห้องที่คุณเป็น GM แล้วกด "📚 คลังแผนที่" ใต้บอร์ด เพื่อโหลดพื้น ระดับแสง และ NPC ชุดนี้ลงโต๊ะ · กด "เผยแพร่" ถ้าอยากให้ GM คนอื่นค้นหาเจอและเก็บสำเนาไปใช้ได้ (เขาแก้สำเนาของเขาเอง ต้นฉบับของคุณไม่เปลี่ยน)'}), h('div',{class:'row',style:'margin-top:6px'}, h('button',{class:'small ghost',onclick:()=>previewMap(m),text:'ดูภาพย่อ'}))));
    root.append(h('div',{class:'table-wrap'}, left, right));
    redraw();
  };
  MapLib.subscribe(()=>{ if (location.hash==='#mapedit-'+id && !$('#v-maps .gridmap')) draw(); });
  draw();
}

/* ---- ใช้ในห้อง: โหลดจากคลัง / เก็บแผนที่ห้องเข้าคลัง ---- */
async function applyLibraryMap(r, m, withNpcs){
  r.map = { kind: m.kind||'field', seed: 'lib:'+m.id, w: MAP_W, h: MAP_H, cells: m.cells };
  if (m.image){ const data = await MapLib.loadImage(m); if (data){ r.map.image = {x:m.image.x, y:m.image.y, w:m.image.w, h:m.image.h, opacity:m.image.opacity==null?.9:m.image.opacity, data}; } }
  r.light = m.light||'low';
  for (const t of r.tokens){ if (t.inside) continue; if (!cellStandable(r.map, t.x, t.y) || r.tokens.some(o=>o!==t && !o.inside && o.x===t.x && o.y===t.y)){ const pos = freeCell(r.map, r.tokens.filter(x=>x!==t), t.kind==='npc' ? [0,1,2,3] : t.kind==='asset' ? [8,9,10,11] : [16,17,18,19]); t.x=pos.x; t.y=pos.y; } syncDevoured(r, t); }
  let added = 0;
  let addedAssets = 0; const thumbs = {}; // ภาพหมากจากคลังของเจ้าของ (คนอื่นที่เก็บสำเนาแผนที่ไปจะไม่ได้ภาพ)
  if (withNpcs) for (const id of new Set((m.npcs||[]).map(n=>n.libId).filter(Boolean))){ const data = await NpcLib.loadImageById(id); if (data) thumbs[id] = data; }
  if (withNpcs) for (const n of m.npcs||[]){ const a = n.kind==='asset'; let x=n.x, y=n.y; if (!cellPassable(r.map,x,y) || (!n.aquatic && !cellStandable(r.map,x,y)) || r.tokens.some(o=>!o.inside && o.x===x && o.y===y)){ const pos = freeCell(r.map, r.tokens, a ? [8,9,10,11] : [0,1,2,3]); x=pos.x; y=pos.y; }
    const tk = a ? {id:uid(), name:n.name||'สิ่งของ', kind:'asset', icon:n.icon||'📦', x, y, hp:Math.max(0,+n.hp||0), hpMax:Math.max(0,+n.hp||0), san:0, sanMax:0, init:0, hidden: n.hidden!==false, note:n.note||'', desc:n.desc||'', nv:false, aquatic:false, torch:!!n.torch, inWater:false}
      : {id:uid(), name:n.name||'ศัตรู', kind:'npc', x, y, hp:+n.hp||10, hpMax:+n.hp||10, san:0, sanMax:0, init:+n.init||0, hidden: n.hidden!==false, note:n.note||'', desc:n.desc||'', nv:!!n.nv, aquatic:!!n.aquatic, torch:!!n.torch, inWater: !!(TILE[mapCell(r.map,x,y)]||{}).swim};
    if (!a && +n.tgh > 0){ tk.tgh = +n.tgh; tk.tghMax = +n.tgh; }
    { const ico = icoClean(n.ico); if (ico) tk.ico = ico; } // ไอคอนจากคลังไอคอนติดมากับแผนที่ (รวมถึงแผนที่ที่เผยแพร่)
    if (n.libId){ tk.libId = n.libId; if (thumbs[n.libId]) tk.thumb = await shrinkDataUrl(thumbs[n.libId], 64, a); }
    r.tokens.push(tk); if (a) addedAssets++; else added++; }
  Table.sel = null; Table.save();
  Table.post({kind:'sys',who:'GM',text:`GM โหลดแผนที่ "${m.name}" (${(MAP_KINDS.find(x=>x[0]===m.kind)||['','?'])[1]} · ${lightLabel(r.light)})${added && addedAssets ? ' พร้อม NPC และ Asset ที่เตรียมไว้' : added ? ' พร้อม NPC ที่เตรียมไว้' : addedAssets ? ' พร้อม Asset ที่เตรียมไว้' : ''}`});
  if (added || addedAssets) Table.post({kind:'sys',who:'GM',text:`เพิ่ม${added ? ` NPC ${added} ตัว (ซ่อนไว้ก่อน)` : ''}${addedAssets ? ` Asset ${addedAssets} ชิ้น` : ''}`,gmOnly:true});
}
function openMapLibraryPicker(r){
  const list = h('div',{class:'giftlist'}); const q = h('input',{placeholder:'ค้นหาในคลังของฉัน',style:'min-width:240px'}); const withNpc = h('input',{type:'checkbox',checked:true});
  const drawList = ()=>{ clear(list); const k = q.value.trim().toLowerCase(); const mine = MapLib.mine.filter(m=>MapLib.isMine(m)).filter(m=>!k || (m.name||'').toLowerCase().includes(k) || (m.desc||'').toLowerCase().includes(k)).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
    if (!MapLib.loaded) list.append(h('div',{class:'dim',text:'กำลังโหลดคลัง…'}));
    else if (!mine.length) list.append(h('div',{class:'dim'}, 'คลังยังว่าง ', h('a',{href:'#maps',onclick:()=>modal(null),text:'ไปสร้างหรือค้นหาแผนที่'})));
    for (const m of mine) list.append(h('div',{class:'gift'}, h('div',{class:'row',style:'gap:10px;align-items:flex-start'}, mapCanvas(m, 4), h('div',null, h('b',{text:m.name}), mapMeta(m), m.desc? h('div',{class:'dim',style:'font-size:12px',text:m.desc.slice(0,120)}):null)), h('button',{class:'small primary',onclick:async()=>{ if (!confirm(`เปลี่ยนแผนที่ห้องเป็น "${m.name}"? หมากทุกตัวจะถูกจัดวางใหม่ถ้าตำแหน่งเดิมเดินไม่ได้`)) return; modal(null); toast('กำลังโหลดแผนที่…'); await applyLibraryMap(r, m, withNpc.checked); },text:'โหลด'}))); };
  q.oninput = drawList;
  modal(h('div',null, h('h3',{text:'โหลดแผนที่จากคลัง'}), h('div',{class:'row',style:'margin:6px 0'}, q, h('label',{class:'dim',style:'font-size:12.5px;display:flex;gap:4px;align-items:center'}, withNpc, 'เพิ่ม NPC ที่เตรียมไว้ด้วย (ซ่อนก่อน)')), list));
  MapLib.subscribe(()=>{ if ($('#modal') && !$('#modal').classList.contains('hidden')) drawList(); });
  drawList();
}
async function saveRoomMapToLibrary(r){
  const name = (prompt('ตั้งชื่อแผนที่ที่จะเก็บเข้าคลัง', r.name||'แผนที่จากห้อง')||'').trim(); if (!name) return;
  const m = MapLib.newMap(name); m.kind = r.map.kind||'field'; m.seed = r.map.seed||m.seed; m.cells = r.map.cells; m.light = r.light||'low';
  // v1.18: เก็บ Asset ไปด้วย (kind:'asset') พร้อม Toughness และ libId · ภาพหมากไม่เก็บลงแผนที่ ตอนโหลดจะดึงจากคลัง NPC / Asset ของเจ้าของผ่าน libId
  m.npcs = (r.tokens||[]).filter(t=>(t.kind==='npc' || t.kind==='asset') && !t.inside).map(t=>{ const a = t.kind==='asset'; const n = {id:uid(), name:t.name, hp: a ? (t.hpMax||0) : (t.hpMax||t.hp||10), init:t.init||0, x:t.x, y:t.y, nv:!!t.nv, aquatic:!!t.aquatic, hidden: a ? !!t.hidden : true, note:t.note||'', desc:t.desc||''}; /* NPC ซ่อนไว้ก่อนเสมอตามเดิม ส่วน Asset คงสภาพตอนเก็บ (กองไฟที่เปิดเผยอยู่ก็โหลดกลับมาแบบเปิดเผย) */ if (a){ n.kind = 'asset'; n.icon = t.icon||'📦'; } if (t.torch) n.torch = true; if (t.tghMax) n.tgh = t.tghMax; if (t.libId) n.libId = t.libId; { const ico = icoClean(t.ico); if (ico) n.ico = ico; } return n; });
  m.desc = r.scene ? r.scene.slice(0,300) : '';
  if (r.map.image && r.map.image.data){ m.image = {x:r.map.image.x, y:r.map.image.y, w:r.map.image.w, h:r.map.image.h, opacity:r.map.image.opacity, has:true}; await MapLib.saveImage(m, r.map.image.data); }
  const na = m.npcs.filter(n=>n.kind==='asset').length;
  if (await MapLib.save(m)) toast(`เก็บ "${name}" เข้าคลังแผนที่แล้ว (${m.npcs.length - na} NPC${na ? ` ${na} Asset` : ''})`);
}
