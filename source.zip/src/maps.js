/* ===== คลังแผนที่: GM เตรียมด่านและสถานที่ไว้ก่อนเปิดโต๊ะ =====
 * เอกสาร maps/<id> = {id, ownerId, ownerName, name, desc, kind, seed, w, h, cells, light, npcs:[{id,name,hp,init,x,y,nv,hidden,note}], published, createdAt, updatedAt, fromId?, fromName?}
 * ส่วนตัวจนกว่าจะกด "เผยแพร่" (Rules: อ่านได้เฉพาะเจ้าของ ผู้พัฒนา หรือเมื่อ published) · ผู้เล่นค้นหาแผนที่ที่เผยแพร่แล้ว "เก็บเข้าคลัง" เป็นสำเนาของตัวเอง
 * โหมดออฟไลน์เก็บใน localStorage kirana.maps.v1 */
const MapLib = {
  mine: [], pub: [], unsub: [], loaded: false, tab: 'mine', q: '', localKey: 'kirana.maps.v1',
  loadLocal(){ try { return JSON.parse(localStorage.getItem(this.localKey)||'[]'); } catch(e){ return []; } },
  saveLocal(list){ try { localStorage.setItem(this.localKey, JSON.stringify(list)); } catch(e){} },
  isMine(m){ return !!m && (!Store.db || m.ownerId===Store.me || !m.ownerId); },
  newMap(name){ const id = uid(); const g = generateMap('field', id); return { id, name: name||'แผนที่ใหม่', desc:'', kind:g.kind, seed:g.seed, w:g.w, h:g.h, cells:g.cells, light:'low', npcs:[], published:false, ownerId: Store.me||'local', ownerName: Store.displayName||'', createdAt:Date.now(), updatedAt:Date.now() }; },
  get(id){ return this.mine.find(x=>x.id===id) || this.pub.find(x=>x.id===id) || null; },
  async save(m){
    m.updatedAt = Date.now(); m.ownerId = m.ownerId || Store.me || 'local'; if (this.isMine(m)) m.ownerName = Store.displayName || m.ownerName || '';
    const i = this.mine.findIndex(x=>x.id===m.id); if (i>=0) this.mine[i] = m; else this.mine.push(m);
    if (!Store.db){ this.saveLocal(this.mine); return true; }
    try { await Store.db.doc('maps/'+m.id).set(JSON.parse(JSON.stringify(m))); return true; }
    catch(e){ console.warn('save map', e); toast('บันทึกแผนที่ไม่ได้ (สิทธิ์ไม่พอ หรือ Rules ยังไม่ใช่รุ่น v1.5)'); return false; }
  },
  async remove(id){ this.mine = this.mine.filter(x=>x.id!==id); if (!Store.db){ this.saveLocal(this.mine); return true; } try { await Store.db.doc('maps/'+id).delete(); return true; } catch(e){ toast('ลบแผนที่ไม่ได้'); return false; } },
  /* คลังของฉัน (อัปเดตสด) · ผู้พัฒนาเห็นทุกแผนที่ */
  subscribe(onChange){
    if (!Store.db){ this.mine = this.loadLocal(); this.loaded = true; onChange(); return; }
    if (this.unsub.length){ onChange(); return; }
    try { const q = Store.isDevUid ? Store.db.collection('maps') : Store.db.collection('maps').where('ownerId','==',Store.me);
      this.unsub.push(q.onSnapshot(snap=>{ this.mine = snapDocs(snap).filter(Boolean); this.loaded = true; onChange(); }, e=>{ console.warn('maps', e); this.loaded = true; onChange(); })); }
    catch(e){ console.warn(e); this.loaded = true; onChange(); }
  },
  async loadPublished(){
    if (!Store.db){ this.pub = this.loadLocal().filter(m=>m.published); return this.pub; }
    try { const snap = await Store.db.collection('maps').where('published','==',true).limit(200).get(); this.pub = snapDocs(snap).filter(Boolean).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)); }
    catch(e){ console.warn('pub maps', e); toast('โหลดแผนที่ที่เผยแพร่ไม่ได้'); }
    return this.pub;
  },
  /* เก็บสำเนาเข้าคลังของฉัน (ส่วนตัว จำชื่อผู้สร้างต้นฉบับไว้) */
  async copyToMine(src, rename){
    const m = JSON.parse(JSON.stringify(src)); m.id = uid(); m.ownerId = Store.me||'local'; m.ownerName = Store.displayName||''; m.published = false;
    if (src.ownerId && src.ownerId !== (Store.me||'local')){ m.fromId = src.id; m.fromName = src.ownerName||''; } else { m.fromId = src.fromId||null; m.fromName = src.fromName||''; }
    m.name = rename || src.name; m.createdAt = Date.now();
    return (await this.save(m)) ? m : null;
  },
};
/* ภาพย่อของแผนที่ (canvas สีตามชนิดพื้น) */
const TILE_COLOR = { '.':'#2e3b2a', ',':'#36522f', 'T':'#2f6b3a', 'W':'#1b3f6b', 'w':'#2b5e8a', 'R':'#5a5f66', 'r':'#3f4348', '=':'#6b5a3e', 'F':'#5b4a35', '#':'#23262c', 'D':'#8a5a2b', 'S':'#c2a35f', 's':'#dfe8f0', 'B':'#8b6a3e', 'H':'#5a3f2b', 'M':'#4a3f2a', 'C':'#7a6a55', 'P':'#8d8273', 'L':'#c84a1a', '~':'#07090c', 'G':'#5a6a58', 'A':'#b08a3a', 'X':'#ffb24a' };
function mapCanvas(m, px){
  const cv = document.createElement('canvas'); cv.width = cv.height = MAP_W*px; cv.className = 'mapthumb';
  const ctx = cv.getContext('2d'); const cells = m.cells||'';
  for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){ ctx.fillStyle = TILE_COLOR[cells[y*MAP_W+x]] || TILE_COLOR['.']; ctx.fillRect(x*px, y*px, px, px); }
  for (const n of m.npcs||[]){ ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(n.x*px+px/2, n.y*px+px/2, px*0.4, 0, Math.PI*2); ctx.fill(); }
  return cv;
}
function mapMeta(m){ return h('div',{class:'gives'}, tag((MAP_KINDS.find(x=>x[0]===m.kind)||['','?'])[1]), tag('💡 '+lightLabel(m.light||'low')), (m.npcs||[]).length ? tag(`${m.npcs.length} NPC`,'neg') : null, m.published ? tag('เผยแพร่แล้ว','ok') : tag('ส่วนตัว'), m.fromName ? tag('จาก '+m.fromName,'prop') : null); }

/* ---- หน้า #maps: คลังของฉัน + ค้นหาแผนที่ที่เผยแพร่ ---- */
function renderMaps(){
  const root = clear($('#v-maps'));
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'สร้างและค้นหาแผนที่'}), h('p',{text:'GM เตรียมด่านและสถานที่ไว้ก่อนเปิดโต๊ะ วาดพื้น ตั้งระดับแสง วาง NPC แล้วเก็บไว้ในคลังส่วนตัว แผนที่จะยังเป็นส่วนตัวจนกว่าจะกดเผยแพร่ ผู้เล่นคนอื่นค้นหาแผนที่ที่เผยแพร่แล้วเก็บสำเนาไปใช้ในโต๊ะของตัวเองได้'})),
    h('div',{class:'row'}, h('button',{class:'primary',onclick:async()=>{ const m = MapLib.newMap(); if (await MapLib.save(m)) location.hash = '#mapedit-'+m.id; },text:'+ สร้างแผนที่ใหม่'}))));
  if (!Store.db) root.append(h('div',{class:'warnbox',style:'margin-bottom:12px'}, 'โหมดออฟไลน์: แผนที่เก็บในเบราว์เซอร์นี้เท่านั้น เผยแพร่ให้คนอื่นเห็นไม่ได้จนกว่าจะเชื่อมต่อ'));
  const tabs = h('div',{class:'row tabs',style:'margin-bottom:10px'},
    h('button',{class:'small'+(MapLib.tab==='mine'?' primary':''),onclick:()=>{ MapLib.tab='mine'; renderMaps(); },text:'คลังของฉัน'}),
    h('button',{class:'small'+(MapLib.tab==='pub'?' primary':''),onclick:async()=>{ MapLib.tab='pub'; renderMaps(); await MapLib.loadPublished(); if (location.hash==='#maps') renderMaps(); },text:'ค้นหาแผนที่ที่เผยแพร่'}));
  const q = h('input',{placeholder:'ค้นหาชื่อ สถานที่ หรือคำอธิบาย',style:'min-width:240px',value:MapLib.q}); q.oninput = ()=>{ MapLib.q = q.value; drawList(); };
  tabs.append(q);
  root.append(tabs);
  const host = h('div'); root.append(host);
  function drawList(){
    clear(host);
    const k = MapLib.q.trim().toLowerCase();
    const filt = (arr)=> arr.filter(m => !k || (m.name||'').toLowerCase().includes(k) || (m.desc||'').toLowerCase().includes(k) || ((MAP_KINDS.find(x=>x[0]===m.kind)||['',''])[1]).includes(k) || (m.ownerName||'').toLowerCase().includes(k));
    if (MapLib.tab==='mine'){
      if (!MapLib.loaded){ host.append(h('div',{class:'card dim',text:'กำลังโหลดคลังของคุณ…'})); return; }
      const mine = filt(MapLib.mine.filter(m=>MapLib.isMine(m))).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
      const others = Store.isDevUid ? filt(MapLib.mine.filter(m=>!MapLib.isMine(m))) : [];
      if (!mine.length) host.append(h('div',{class:'card dim',text: MapLib.q ? 'ไม่พบแผนที่ที่ตรงกับคำค้น' : 'คลังยังว่าง กด "+ สร้างแผนที่ใหม่" หรือไปเก็บจากแท็บ "ค้นหาแผนที่ที่เผยแพร่"'}));
      else host.append(h('div',{class:'grid wide'}, mine.map(m=>mapCard(m, true))));
      if (others.length){ host.append(h('h3',{style:'margin:18px 0 8px',text:'แผนที่ของผู้ใช้คนอื่น (มุมมองผู้พัฒนา)'})); host.append(h('div',{class:'grid wide'}, others.map(m=>mapCard(m, false)))); }
    } else {
      const pub = filt(MapLib.pub);
      if (!pub.length) host.append(h('div',{class:'card dim',text: MapLib.q ? 'ไม่พบแผนที่ที่ตรงกับคำค้น' : 'ยังไม่มีใครเผยแพร่แผนที่ (หรือกำลังโหลด)'}));
      else host.append(h('div',{class:'grid wide'}, pub.map(m=>mapCard(m, MapLib.isMine(m)))));
    }
  }
  MapLib.subscribe(()=>{ if (location.hash==='#maps') drawList(); });
  if (MapLib.tab==='pub' && !MapLib.pub.length) MapLib.loadPublished().then(()=>{ if (location.hash==='#maps') drawList(); });
  drawList();
}
function mapCard(m, mine){
  const card = h('div',{class:'card mapcard'});
  card.append(h('div',{class:'row',style:'gap:12px;align-items:flex-start'}, h('div',{class:'thumbwrap',onclick:()=>previewMap(m)}, mapCanvas(m, 6)),
    h('div',{style:'flex:1;min-width:160px'}, h('h3',{style:'margin:0',text:m.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',style:'font-size:12px',text:(m.ownerName? 'โดย '+m.ownerName+' · ' : '') + new Date(m.updatedAt||0).toLocaleDateString('th-TH')}), mapMeta(m), m.desc ? h('p',{class:'desc',style:'margin:6px 0 0;font-size:13px',text:m.desc.slice(0,160)}) : null)));
  const row = h('div',{class:'row',style:'margin-top:8px'});
  row.append(h('button',{class:'small ghost',onclick:()=>previewMap(m),text:'ดู'}));
  if (mine){
    row.append(h('button',{class:'small primary',onclick:()=>{ location.hash='#mapedit-'+m.id; },text:'แก้ไข'}),
      h('button',{class:'small'+(m.published?' on':''),title: m.published ? 'เอาออกจากหน้าค้นหา (สำเนาที่คนอื่นเก็บไปแล้วยังอยู่กับเขา)' : 'ให้ทุกคนค้นหาและเก็บสำเนาได้',onclick:async()=>{ m.published = !m.published; if (await MapLib.save(m)) toast(m.published ? 'เผยแพร่แล้ว ทุกคนค้นหาเจอ' : 'ยกเลิกเผยแพร่แล้ว'); renderMaps(); },text: m.published ? 'ยกเลิกเผยแพร่' : 'เผยแพร่'}),
      h('button',{class:'small ghost',onclick:async()=>{ const c = await MapLib.copyToMine(m, (m.name||'แผนที่')+' (สำเนา)'); if (c) { toast('ทำสำเนาแล้ว'); renderMaps(); } },text:'ทำสำเนา'}),
      h('button',{class:'small ghost',onclick:async()=>{ if (!confirm(`ลบแผนที่ "${m.name}" ถาวร?`)) return; await MapLib.remove(m.id); renderMaps(); },text:'ลบ'}));
  } else {
    row.append(h('button',{class:'small primary',title:'เก็บสำเนาไว้ในคลังของคุณ แก้ไขและใช้ในโต๊ะของตัวเองได้',onclick:async()=>{ const c = await MapLib.copyToMine(m); if (c){ toast(`เก็บ "${m.name}" เข้าคลังของคุณแล้ว`); } },text:'เก็บเข้าคลัง'}));
  }
  card.append(row);
  return card;
}
function previewMap(m){
  modal(h('div',null, h('h3',{text:m.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',style:'font-size:12px',text:(m.ownerName? 'โดย '+m.ownerName : '')}), mapMeta(m), m.desc ? h('p',{class:'desc',text:m.desc}) : null,
    h('div',{style:'margin-top:8px'}, mapCanvas(m, 16)),
    (m.npcs||[]).length ? h('div',{style:'margin-top:8px'}, h('b',{text:'NPC ที่เตรียมไว้: '}), (m.npcs||[]).map(n=>`${n.name} (HP ${n.hp}${n.hidden?' ซ่อน':''})`).join(' · ')) : null));
}

/* ---- ตัวแก้ไขแผนที่ #mapedit-<id> ---- */
const MapEd = { brush: '.', tool: 'paint', npc: null };
function renderMapEditor(id){
  const root = clear($('#v-maps'));
  const draw = ()=>{
    const m = MapLib.get(id);
    if (!m){ clear(root); root.append(h('div',{class:'card'}, MapLib.loaded ? 'ไม่พบแผนที่นี้ในคลังของคุณ' : 'กำลังโหลด…'), h('button',{style:'margin-top:10px',onclick:()=>{ location.hash='#maps'; },text:'← กลับคลังแผนที่'})); return; }
    if (!MapLib.isMine(m) && !Store.isDevUid){ clear(root); root.append(h('div',{class:'card',text:'แผนที่นี้ไม่ใช่ของคุณ เก็บสำเนาเข้าคลังก่อนแล้วค่อยแก้'}), h('button',{style:'margin-top:10px',onclick:()=>{ location.hash='#maps'; },text:'← กลับคลังแผนที่'})); return; }
    clear(root);
    let dirty = false; const markDirty = ()=>{ dirty = true; saveBtn.textContent = 'บันทึก •'; };
    const saveBtn = h('button',{class:'primary small',onclick:async()=>{ if (await MapLib.save(m)){ dirty = false; saveBtn.textContent = 'บันทึกแล้ว'; toast('บันทึกแผนที่แล้ว'); } },text:'บันทึก'});
    const name = h('input',{value:m.name||'',placeholder:'ชื่อแผนที่ เช่น สะพานข้ามเหวนอร์ลัน',style:'min-width:260px',oninput:(e)=>{ m.name = e.target.value; markDirty(); }});
    const desc = h('textarea',{placeholder:'คำอธิบาย บรรยากาศ จุดสำคัญ กับดัก แนวทางการใช้ (ผู้เล่นที่ค้นหาเจอจะเห็นข้อความนี้)',style:'min-height:70px'}); desc.value = m.desc||''; desc.oninput = ()=>{ m.desc = desc.value; markDirty(); };
    const kindSel = h('select',null, MAP_KINDS.map(([k,l])=>h('option',{value:k,selected:k===m.kind,text:l})));
    const lightSel = h('select',null, LIGHTS.map(([k,l])=>h('option',{value:k,selected:k===(m.light||'low'),text:l}))); lightSel.onchange = ()=>{ m.light = lightSel.value; markDirty(); draw(); };
    const head = h('div',{class:'stephead'}, h('div',null, h('h2',{text:'แก้ไขแผนที่'}), h('p',{text:'เลือกพู่กันแล้วคลิกหรือลากบนตารางเพื่อวาดพื้น เครื่องมือ NPC วางศัตรูที่เตรียมไว้ (ซ่อนจนกว่า GM จะเปิดเผย) · 1 ช่อง = 2 เมตร'})),
      h('div',{class:'row'}, saveBtn, h('button',{class:'small'+(m.published?' on':''),onclick:async()=>{ m.published = !m.published; if (await MapLib.save(m)){ dirty=false; toast(m.published ? 'เผยแพร่แล้ว' : 'ยกเลิกเผยแพร่แล้ว'); draw(); } },text: m.published ? 'ยกเลิกเผยแพร่' : 'เผยแพร่'}), h('button',{class:'small ghost',onclick:()=>{ if (dirty && !confirm('ยังไม่ได้บันทึก ออกเลยไหม?')) return; location.hash='#maps'; },text:'← คลังแผนที่'})));
    root.append(head);
    const left = h('div'), right = h('div');
    left.append(h('div',{class:'card',style:'margin-bottom:10px'}, h('div',{class:'row'}, name, h('span',{class:'dim',style:'font-size:12px',text:'สถานที่'}), kindSel, h('button',{class:'small',onclick:()=>{ const g = generateMap(kindSel.value, uid()); m.kind = g.kind; m.seed = g.seed; m.cells = g.cells; markDirty(); draw(); },text:'สุ่มพื้นจากสถานที่นี้'}), h('span',{class:'dim',style:'font-size:12px',text:'💡 แสง'}), lightSel), desc, h('div',{class:'dim',style:'font-size:11.5px;margin-top:4px',text:LIGHT_NOTE[m.light||'low']||''})));
    // พู่กัน
    const pal = h('div',{class:'row palette'});
    for (const [k,v] of Object.entries(TILE)) pal.append(h('button',{class:'small pal'+(MapEd.tool==='paint'&&MapEd.brush===k?' on':''),title:v.th,onclick:()=>{ MapEd.tool='paint'; MapEd.brush=k; draw(); }}, h('i',{class:'sw',style:'background:'+(TILE_COLOR[k]||'#333')}), ' '+v.th));
    pal.append(h('button',{class:'small pal'+(MapEd.tool==='npc'?' on':''),onclick:()=>{ MapEd.tool='npc'; draw(); },text:'👹 วาง NPC'}), h('button',{class:'small pal'+(MapEd.tool==='erase'?' on':''),onclick:()=>{ MapEd.tool='erase'; draw(); },text:'✕ เอา NPC ออก'}));
    left.append(pal);
    if (MapEd.tool==='npc'){ MapEd.npc = MapEd.npc || {name:'ศัตรู', hp:10, init:0, nv:false, hidden:true}; const n = MapEd.npc; left.append(h('div',{class:'row',style:'margin:6px 0'}, h('input',{value:n.name,placeholder:'ชื่อ NPC',style:'width:150px',oninput:(e)=>{ n.name=e.target.value; }}), h('input',{type:'number',value:n.hp,style:'width:70px',title:'HP',oninput:(e)=>{ n.hp=+e.target.value||1; }}), h('input',{type:'number',value:n.init,style:'width:70px',title:'Initiative',oninput:(e)=>{ n.init=+e.target.value||0; }}), h('label',{class:'dim',style:'font-size:12px;display:flex;gap:3px;align-items:center'}, h('input',{type:'checkbox',checked:n.nv,onchange:(e)=>{ n.nv=e.target.checked; }}), '👁 มืด'), h('label',{class:'dim',style:'font-size:12px;display:flex;gap:3px;align-items:center'}, h('input',{type:'checkbox',checked:n.hidden,onchange:(e)=>{ n.hidden=e.target.checked; }}), 'ซ่อนตอนเริ่ม'), h('span',{class:'dim',style:'font-size:12px',text:'แล้วคลิกช่องบนแผนที่'}))); }
    // ตาราง
    const grid = h('div',{class:'gridmap painting'});
    let painting = false;
    const paintAt = (x,y)=>{ if (MapEd.tool==='paint'){ const a = m.cells.split(''); if (a[y*MAP_W+x]===MapEd.brush) return; a[y*MAP_W+x] = MapEd.brush; m.cells = a.join(''); markDirty(); redraw(); } };
    const npcAt = (x,y)=> (m.npcs||[]).find(n=>n.x===x && n.y===y);
    const cellEls = [];
    for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){
      const cell = h('div',{class:'cell',dataset:{x,y}});
      cell.onpointerdown = (e)=>{ e.preventDefault(); if (MapEd.tool==='paint'){ painting = true; paintAt(x,y); } else if (MapEd.tool==='npc'){ if (npcAt(x,y)){ toast('มี NPC อยู่แล้ว'); return; } if (!cellPassable(m, x, y)){ toast('ช่องนี้ผ่านไม่ได้'); return; } m.npcs = m.npcs||[]; m.npcs.push({id:uid(), ...JSON.parse(JSON.stringify(MapEd.npc)), x, y}); markDirty(); redraw(); } else if (MapEd.tool==='erase'){ const n = npcAt(x,y); if (n){ m.npcs = m.npcs.filter(o=>o!==n); markDirty(); redraw(); } } };
      cell.onpointerenter = ()=>{ if (painting && MapEd.tool==='paint') paintAt(x,y); };
      cellEls.push(cell); grid.append(cell);
    }
    grid.onpointerup = grid.onpointerleave = ()=>{ painting = false; };
    const redraw = ()=>{ for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){ const cell = cellEls[y*MAP_W+x]; const ch = mapCell(m,x,y); const tile = TILE[ch]||TILE['.']; cell.className = 'cell t-'+(ch.replace(/[^A-Za-z]/g, c=>({'.':'ground',',':'grass','=':'road','#':'wall','~':'chasm'}[c]||'ground'))); cell.title = `(${x},${y}) ${tile.th}`; clear(cell); const n = npcAt(x,y); if (n) cell.append(h('div',{class:'gtok npc'+(n.hidden?' hid':''),title:`${n.name} HP ${n.hp}`}, h('span',{class:'ini',text:(n.name||'?').slice(0,2)}))); } npcList(); };
    left.append(grid);
    const used = ()=>[...new Set(m.cells.split(''))].filter(k=>TILE[k]);
    left.append(h('div',{class:'legend'}, used().map(k=>h('span',{class:'lg'}, h('i',{class:'sw',style:'background:'+(TILE_COLOR[k]||'#333')}), TILE[k].th))));
    // NPC list
    const npcBox = h('div',{class:'card',style:'margin-bottom:10px'});
    const npcList = ()=>{ clear(npcBox); npcBox.append(h('h3',{text:`NPC ที่เตรียมไว้ (${(m.npcs||[]).length})`})); if (!(m.npcs||[]).length) npcBox.append(h('p',{class:'dim',style:'font-size:12.5px',text:'เลือกเครื่องมือ "วาง NPC" แล้วคลิกบนแผนที่ NPC ทุกตัวจะถูกเพิ่มเข้าห้องแบบซ่อนไว้เมื่อโหลดแผนที่นี้'})); for (const n of m.npcs||[]) npcBox.append(h('div',{class:'row',style:'gap:6px;font-size:13px;margin-top:4px'}, h('b',{text:n.name}), h('span',{class:'num dim',text:`HP ${n.hp} · Init ${signed(n.init||0)} · (${n.x},${n.y})`}), n.nv? tag('👁 มืด'):null, n.hidden? tag('ซ่อน'):tag('เปิดเผย','warn'), h('button',{class:'small ghost',style:'margin-left:auto',onclick:()=>{ m.npcs = m.npcs.filter(o=>o!==n); markDirty(); redraw(); },text:'✕'}))); };
    right.append(npcBox);
    right.append(h('div',{class:'card'}, h('h3',{text:'ใช้แผนที่นี้'}), h('p',{class:'dim',style:'font-size:12.5px',text:'เปิดห้องที่คุณเป็น GM แล้วกด "📚 คลังแผนที่" ใต้บอร์ด เพื่อโหลดพื้น ระดับแสง และ NPC ชุดนี้ลงโต๊ะ · กด "เผยแพร่" ถ้าอยากให้ GM คนอื่นค้นหาเจอและเก็บสำเนาไปใช้ได้ (เขาแก้สำเนาของเขาเอง ต้นฉบับของคุณไม่เปลี่ยน)'}), h('div',{class:'row',style:'margin-top:6px'}, h('button',{class:'small ghost',onclick:()=>previewMap(m),text:'ดูภาพย่อ'}))));
    root.append(h('div',{class:'table-wrap'}, left, right));
    redraw();
  };
  MapLib.subscribe(()=>{ if (location.hash==='#mapedit-'+id && !$('#v-maps .gridmap')) draw(); });
  draw();
}

/* ---- ใช้ในห้อง: โหลดจากคลัง / เก็บแผนที่ห้องเข้าคลัง ---- */
function applyLibraryMap(r, m, withNpcs){
  r.map = { kind: m.kind||'field', seed: 'lib:'+m.id, w: MAP_W, h: MAP_H, cells: m.cells };
  r.light = m.light||'low';
  for (const t of r.tokens){ if (t.inside) continue; if (!cellPassable(r.map, t.x, t.y) || r.tokens.some(o=>o!==t && !o.inside && o.x===t.x && o.y===t.y)){ const pos = freeCell(r.map, r.tokens.filter(x=>x!==t), t.kind==='npc'?[0,1,2,3]:[16,17,18,19]); t.x=pos.x; t.y=pos.y; } syncDevoured(r, t); }
  let added = 0;
  if (withNpcs) for (const n of m.npcs||[]){ let x=n.x, y=n.y; if (!cellPassable(r.map,x,y) || r.tokens.some(o=>!o.inside && o.x===x && o.y===y)){ const pos = freeCell(r.map, r.tokens, [0,1,2,3]); x=pos.x; y=pos.y; } r.tokens.push({id:uid(), name:n.name||'ศัตรู', kind:'npc', x, y, hp:+n.hp||10, hpMax:+n.hp||10, san:0, sanMax:0, init:+n.init||0, hidden: n.hidden!==false, note:n.note||'', nv:!!n.nv, torch:false}); added++; }
  Table.sel = null; Table.save();
  Table.post({kind:'sys',who:'GM',text:`GM โหลดแผนที่ "${m.name}" (${(MAP_KINDS.find(x=>x[0]===m.kind)||['','?'])[1]} · ${lightLabel(r.light)})${added? ' พร้อม NPC ที่เตรียมไว้':''}`});
  if (added) Table.post({kind:'sys',who:'GM',text:`เพิ่ม NPC ${added} ตัว (ซ่อนไว้ก่อน)`,gmOnly:true});
}
function openMapLibraryPicker(r){
  const list = h('div',{class:'giftlist'}); const q = h('input',{placeholder:'ค้นหาในคลังของฉัน',style:'min-width:240px'}); const withNpc = h('input',{type:'checkbox',checked:true});
  const drawList = ()=>{ clear(list); const k = q.value.trim().toLowerCase(); const mine = MapLib.mine.filter(m=>MapLib.isMine(m)).filter(m=>!k || (m.name||'').toLowerCase().includes(k) || (m.desc||'').toLowerCase().includes(k)).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
    if (!MapLib.loaded) list.append(h('div',{class:'dim',text:'กำลังโหลดคลัง…'}));
    else if (!mine.length) list.append(h('div',{class:'dim'}, 'คลังยังว่าง ', h('a',{href:'#maps',onclick:()=>modal(null),text:'ไปสร้างหรือค้นหาแผนที่'})));
    for (const m of mine) list.append(h('div',{class:'gift'}, h('div',{class:'row',style:'gap:10px;align-items:flex-start'}, mapCanvas(m, 4), h('div',null, h('b',{text:m.name}), mapMeta(m), m.desc? h('div',{class:'dim',style:'font-size:12px',text:m.desc.slice(0,120)}):null)), h('button',{class:'small primary',onclick:()=>{ if (!confirm(`เปลี่ยนแผนที่ห้องเป็น "${m.name}"? หมากทุกตัวจะถูกจัดวางใหม่ถ้าตำแหน่งเดิมเดินไม่ได้`)) return; applyLibraryMap(r, m, withNpc.checked); modal(null); },text:'โหลด'}))); };
  q.oninput = drawList;
  modal(h('div',null, h('h3',{text:'โหลดแผนที่จากคลัง'}), h('div',{class:'row',style:'margin:6px 0'}, q, h('label',{class:'dim',style:'font-size:12.5px;display:flex;gap:4px;align-items:center'}, withNpc, 'เพิ่ม NPC ที่เตรียมไว้ด้วย (ซ่อนก่อน)')), list));
  MapLib.subscribe(()=>{ if ($('#modal') && !$('#modal').classList.contains('hidden')) drawList(); });
  drawList();
}
async function saveRoomMapToLibrary(r){
  const name = (prompt('ตั้งชื่อแผนที่ที่จะเก็บเข้าคลัง', r.name||'แผนที่จากห้อง')||'').trim(); if (!name) return;
  const m = MapLib.newMap(name); m.kind = r.map.kind||'field'; m.seed = r.map.seed||m.seed; m.cells = r.map.cells; m.light = r.light||'low';
  m.npcs = (r.tokens||[]).filter(t=>t.kind==='npc' && !t.inside).map(t=>({id:uid(), name:t.name, hp:t.hpMax||t.hp||10, init:t.init||0, x:t.x, y:t.y, nv:!!t.nv, hidden:true, note:t.note||''}));
  m.desc = r.scene ? r.scene.slice(0,300) : '';
  if (await MapLib.save(m)) toast(`เก็บ "${name}" เข้าคลังแผนที่แล้ว (${m.npcs.length} NPC)`);
}
