/* ===== v1.26 (ร่าง ยังไม่ขึ้นเว็บ · Non สั่ง 15 พ.ย. 2026): คลังความรู้ของคีรันนา =====
 * #lore ตำนานแบบวิกิ (เนื้อหาใน lore.js) · #lore-<id> บทความ
 * #skills คลังทักษะและเวทมนตร์ แบ่งตามหมวดและประเภทแบบไฟล์ Skill & Sorceries และระดับ Novice Expert Master
 * #items คลังไอเทม แบ่งตามรูปแบบการใช้ อาวุธ โล่ หมวกเกราะแยกตาม Tier ที่ไฟล์กำหนด
 * ทั้งสามหน้าอ่านอย่างเดียวสำหรับผู้เล่น สถานะตัวกรองจำไว้ใน Codex ระหว่างเปิดหน้า
 * ข้อความตำนานแก้ได้จากหลังบ้านโดยผู้พัฒนา (loreedit.js ทับ LORE ด้วยฉบับแก้ใน codex/lore) */
const Codex = { loreQ: '', sk: { cat: 'sorcery', tier: '', act: '', q: '', focus: '' }, it: { fam: 'weapon', tier: '', q: '' } };
function cxScrollTo(el){ if (el) el.scrollIntoView({behavior:'smooth', block:'start'}); }

/* ============================== ตำนาน (#lore) ============================== */
const LORE_KIND = { event:['เหตุการณ์','✦'], topic:['หัวข้อ','◈'], person:['บุคคล','☉'], faction:['ฝ่ายและองค์กร','⚑'], place:['สถานที่','⌂'] };
const LORE_KIND_ORDER = ['topic','faction','person','place'];
const LORE_ORDER = LORE_ERAS.flatMap(e=>e.events);
const LORE_LINK_RX = /\[\[([a-z0-9]+)(?:\|([^\]]+))?\]\]/g;
let LORE_INTRO = 'ประวัติศาสตร์ของโลกใต้ม่านมานา ตั้งแต่วันที่วัฏจักรมานาเริ่มหมุน จนถึงรุ่งอรุณของยุคสหพันธรัฐ เดินตามเส้นเวลาทีละเหตุการณ์ หรือแวะตามกิ่งที่แตกออกไปหาผู้คน ศรัทธา และภัยที่อยู่เบื้องหลังแต่ละยุค';
function loreTitle(id){ const a = LORE[id]; return a ? a.title : id; }
/* ข้อความที่มีลิงก์ [[id|ข้อความ]] เป็นรายการโหนด (ข้อความธรรมดา + ลิงก์ไปบทความ) */
function loreNodes(str){
  const s = String(str||''); const out = []; let last = 0; let m; const rx = new RegExp(LORE_LINK_RX.source, 'g');
  while ((m = rx.exec(s))){ if (m.index > last) out.push(s.slice(last, m.index)); const a = LORE[m[1]];
    out.push(a ? h('a',{class:'lorelink k-'+a.kind, href:'#lore-'+m[1], title: a.sub || a.title, text: m[2] || a.title}) : (m[2] || m[1])); last = rx.lastIndex; }
  if (last < s.length) out.push(s.slice(last)); return out; }
function lorePlain(str){ return String(str||'').replace(new RegExp(LORE_LINK_RX.source, 'g'), (m, id, lb)=> lb || loreTitle(id)); }
function loreEra(a){ return a && a.era ? LORE_ERAS.find(e=>e.id===a.era) : null; }
/* บทความที่ลิงก์มาหาแต่ละบทความ (คำนวณครั้งเดียว) */
let LORE_BACK = null;
function loreBack(){ if (LORE_BACK) return LORE_BACK; LORE_BACK = {}; for (const id of Object.keys(LORE)) LORE_BACK[id] = [];
  for (const [src, a] of Object.entries(LORE)){ const seen = new Set(a.branches||[]); for (const m of JSON.stringify([a.lead, a.box, a.body]).matchAll(/\[\[([a-z0-9]+)/g)) seen.add(m[1]);
    for (const t of seen) if (t !== src && LORE_BACK[t]) LORE_BACK[t].push(src); }
  return LORE_BACK; }
/* กิ่งที่แตกจากเหตุการณ์: หัวข้อที่กำหนดไว้ + ผู้คน ฝ่าย สถานที่ที่กล่องข้อมูลอ้างถึง (ไม่รวมเหตุการณ์อื่น) */
function loreKids(id){ const a = LORE[id]; const out = (a.branches||[]).filter(x=>LORE[x] && x !== id);
  for (const [k, b] of Object.entries(LORE)) if (b.parent === id && b.kind !== 'event' && !out.includes(k)) out.push(k);
  return out; }
function loreBranchIds(id){ const a = LORE[id]; const out = []; const add = (x)=>{ if (x && x !== id && LORE[x] && LORE[x].kind !== 'event' && !out.includes(x)) out.push(x); };
  for (const b of loreKids(id)) add(b);
  for (const [, v] of a.box||[]) for (const m of String(v).matchAll(new RegExp(LORE_LINK_RX.source, 'g'))) add(m[1]);
  return out.sort((x, y)=>LORE_KIND_ORDER.indexOf(LORE[x].kind) - LORE_KIND_ORDER.indexOf(LORE[y].kind)); }
function loreChip(id, cls){ const a = LORE[id]; const k = LORE_KIND[a.kind]; return h('a',{class:'lchip k-'+a.kind+(cls ? ' '+cls : ''), href:'#lore-'+id, title: k[0] + (a.sub ? ' · ' + a.sub : '')}, h('span',{class:'lchip-i','aria-hidden':'true',text:k[1]}), a.title); }
function renderLore(arg){
  const root = clear($('#v-lore'));
  if (arg && LORE[arg]) loreArticle(root, arg); else loreHome(root);
}
function loreHome(root){
  const main = h('div',{class:'lore-main'});
  const q = h('input',{type:'search',class:'lore-q',placeholder:'ค้นในตำนาน เช่น เนเมสไซอาร์ แร่รัตติกาล ห้วงเมฆาพิโรธ','aria-label':'ค้นในตำนาน',value:Codex.loreQ});
  const draw = ()=>{ clear(main); const k = Codex.loreQ.trim(); main.append(k ? loreSearch(k) : loreTimeline()); };
  q.oninput = ()=>{ Codex.loreQ = q.value; draw(); };
  root.append(h('div',{class:'lore-hero'},
    h('div',{class:'kicker',text:'บันทึกแห่งคีรันนา'}),
    h('h1',{class:'gothic',text:'ตำนานแห่งคีรันนา'}),
    h('p',{class:'lede',text:LORE_INTRO}),
    h('div',{class:'row lore-actions'}, h('button',{class:'primary',onclick:()=>{ location.hash = '#lore-' + LORE_ORDER[0]; },text:'อ่านตั้งแต่ต้น'}), q)));
  root.append(h('div',{class:'lore-layout'}, main, loreIndexAside(()=>{ if (Codex.loreQ){ Codex.loreQ = ''; q.value = ''; draw(); } })));
  root.append(h('p',{class:'dim lore-foot',text:'เรียบเรียงจากบันทึก Astral Sea Lore · กดชื่อที่ขีดเส้นใต้ในบทความเพื่ออ่านเรื่องที่เกี่ยวข้อง'}));
  draw();
}
/* เส้นเวลา: มหายุค → เหตุการณ์ → กิ่งที่แตกออกไป */
function loreTimeline(){
  const box = h('div',{class:'tl'});
  for (const era of LORE_ERAS){
    const sec = h('section',{class:'tl-era',id:'era-'+era.id});
    sec.append(h('div',{class:'tl-erahead'}, h('span',{class:'tl-eramark','aria-hidden':'true'}),
      h('div',null, h('h2',{text:era.title}), h('div',{class:'tl-en',text:[era.en, era.note].filter(Boolean).join(' · ')}), h('p',{class:'desc',text:era.blurb}))));
    const ol = h('ol',{class:'tl-events'});
    for (const id of era.events){ const a = LORE[id]; const n = LORE_ORDER.indexOf(id) + 1; const br = loreBranchIds(id);
      ol.append(h('li',{class:'tl-ev',dataset:{id}}, h('span',{class:'tl-dot',text:String(n)}),
        h('div',{class:'tl-body'},
          h('a',{class:'tl-card',href:'#lore-'+id}, h('div',{class:'tl-title'}, h('b',{text:a.title}), h('span',{class:'tl-en',text:a.en})), a.sub ? h('div',{class:'tl-sub',text:a.sub}) : null, h('p',{class:'tl-lead',text:lorePlain(a.lead)})),
          br.length ? h('div',{class:'tl-branches'}, h('span',{class:'tl-branch-l',text:'แตกแขนง'}), br.map(x=>loreChip(x))) : null))); }
    sec.append(ol); box.append(sec);
  }
  return box;
}
function loreIndexAside(beforeJump){
  const aside = h('aside',{class:'lore-aside'});
  const toc = h('div',{class:'card lore-toc'}, h('h3',{text:'สารบัญเส้นเวลา'}));
  for (const era of LORE_ERAS) toc.append(h('div',{class:'toc-era'},
    h('button',{class:'linkish',onclick:()=>{ if (beforeJump) beforeJump(); requestAnimationFrame(()=>cxScrollTo(document.getElementById('era-'+era.id))); },text:era.title}),
    h('ol',{class:'toc-evs'}, era.events.map(id=>h('li',null, h('a',{href:'#lore-'+id,text:LORE[id].title}))))));
  aside.append(toc);
  for (const kind of ['person','faction','place','topic']){ const ids = Object.keys(LORE).filter(id=>LORE[id].kind===kind);
    aside.append(h('div',{class:'card lore-kind'}, h('h3',null, h('span',{class:'lchip-i','aria-hidden':'true',text:LORE_KIND[kind][1]}), ' ', LORE_KIND[kind][0], h('span',{class:'dim',style:'font-size:12px;font-weight:400',text:' '+ids.length})), h('div',{class:'lore-chips'}, ids.map(id=>loreChip(id))))); }
  return aside;
}
function loreHay(id){ const a = LORE[id];
  return [a.title, a.en, a.sub, lorePlain(a.lead), ...(a.box||[]).map(([k, v])=>k + ' ' + lorePlain(v)),
    ...a.body.map(b=>b[0]==='ul' ? b[1].map(lorePlain).join(' ') : b[0]==='q' ? lorePlain(b[1]) + ' ' + lorePlain(b[2]||'') : b[0]==='fig' ? (LORE_FIGS[b[1]] ? LORE_FIGS[b[1]].title + ' ' + LORE_FIGS[b[1]].cap : '') : lorePlain(b[1]))].filter(Boolean).join('   '); }
function loreSearch(k){
  const kl = k.toLowerCase(); const hits = [];
  for (const id of Object.keys(LORE)){ const hay = loreHay(id); const i = hay.toLowerCase().indexOf(kl); if (i < 0) continue; const a = LORE[id];
    const titleHit = (a.title + ' ' + a.en).toLowerCase().includes(kl); const ord = LORE_ORDER.indexOf(id);
    hits.push({id, i, hay, rank: (titleHit ? 0 : 1000) + (ord >= 0 ? ord : 100)}); }
  hits.sort((x, y)=>x.rank - y.rank);
  const box = h('div',{class:'lore-results'}, h('div',{class:'dim',style:'font-size:13px;margin-bottom:6px',text: hits.length ? `พบ ${hits.length} บทความที่กล่าวถึง "${k}"` : `ไม่พบบทความที่กล่าวถึง "${k}"`}));
  for (const x of hits){ const a = LORE[x.id]; const s = Math.max(0, x.i - 50); const e = Math.min(x.hay.length, x.i + kl.length + 90);
    const snip = x.hay.slice(s, e); const at = x.i - s;
    box.append(h('a',{class:'card pick lore-hit',href:'#lore-'+x.id},
      h('div',{class:'row',style:'gap:6px'}, tag(LORE_KIND[a.kind][0], a.kind==='event' ? 'neg' : a.kind==='person' ? 'prop' : 'stat'), h('b',{text:a.title}), h('span',{class:'dim',style:'font-size:12.5px',text:a.en})),
      h('p',{class:'desc',style:'margin:6px 0 0'}, s > 0 ? '…' : '', snip.slice(0, at), h('mark',{text:snip.slice(at, at + kl.length)}), snip.slice(at + kl.length), e < x.hay.length ? '…' : ''))); }
  return box;
}
function loreArticle(root, id, draft){
  const pv = !!draft; const a = draft || LORE[id]; const era = loreEra(a) || (a.parent && LORE[a.parent] ? loreEra(LORE[a.parent]) : null);
  const goEra = (e)=>{ ev(e); Codex.loreQ = ''; location.hash = '#lore'; setTimeout(()=>cxScrollTo(document.getElementById('era-'+era.id)), 80); };
  const ev = (e)=>{ if (e) e.preventDefault(); };
  root.append(h('div',{class:'lore-crumbs',role:'navigation','aria-label':'ตำแหน่งของบทความ'}, h('a',{href:'#lore',text:'ตำนาน'}),
    era ? [h('span',{class:'sep',text:' › '}), h('a',{href:'#lore',onclick:goEra,text:era.title})] : null,
    a.parent && LORE[a.parent] ? [h('span',{class:'sep',text:' › '}), h('a',{href:'#lore-'+a.parent,text:LORE[a.parent].title})] : null,
    h('span',{class:'sep',text:' › '}), h('span',{class:'cur',text:a.title})));
  if (!pv){ const bar = loreDevBar(id); if (bar) root.append(bar); }
  const art = h('article',{class:'lore-art'});
  art.append(h('div',{class:'kicker',text: LORE_KIND[a.kind][0] + (era ? ' · ' + era.title : '')}),
    h('h1',{class:'gothic lore-title',text:a.title}), h('div',{class:'lore-en',text:a.en}), a.sub ? h('div',{class:'lore-sub',text:a.sub}) : null,
    h('p',{class:'lore-lead'}, loreNodes(a.lead)));
  const heads = a.body.filter(b=>b[0]==='h');
  if (heads.length >= 3) art.append(h('div',{class:'lore-intoc'}, h('div',{class:'kicker',text:'ในบทความนี้'}), h('ol',null, heads.map((b, i)=>h('li',null, h('button',{class:'linkish',onclick:()=>cxScrollTo(art.querySelector('#lh-'+i)),text:b[1]}))))));
  let hi = 0;
  for (const b of a.body){
    if (b[0]==='h') art.append(h('h2',{class:'lore-h',id:'lh-'+(hi++),text:b[1]}));
    else if (b[0]==='p') art.append(h('p',{class:'lore-p'}, loreNodes(b[1])));
    else if (b[0]==='ul') art.append(h('ul',{class:'lore-ul'}, b[1].map(x=>h('li',null, loreNodes(x)))));
    else if (b[0]==='q') art.append(h('blockquote',{class:'lore-quote'}, h('p',null, loreNodes(b[1])), b[2] ? h('cite',null, loreNodes(b[2])) : null));
    else if (b[0]==='fig'){ const f = loreFig(b[1]); if (f) art.append(f); }
  }
  // กิ่งที่แตกออกจากบทความนี้
  const br = pv ? (a.branches||[]).filter(x=>LORE[x]) : loreKids(id);
  if (br.length) art.append(h('section',{class:'lore-branches'}, h('h2',{class:'lore-h',text: a.kind==='event' ? 'แตกแขนงจากเหตุการณ์นี้' : 'อ่านต่อในหัวข้อย่อย'}),
    h('div',{class:'lore-bgrid'}, br.map(x=>{ const b = LORE[x]; return h('a',{class:'card pick lore-bcard',href:'#lore-'+x}, h('div',{class:'row',style:'gap:6px'}, h('span',{class:'lchip-i',text:LORE_KIND[b.kind][1]}), h('b',{text:b.title})), h('div',{class:'dim',style:'font-size:12px',text:b.en}), h('p',{class:'desc',text:lorePlain(b.lead)})); }))));
  if (!pv) art.append(loreNav(id));
  root.append(h('div',{class:'lore-artgrid'}, art, h('aside',{class:'lore-side'}, loreInfobox(a), loreGameBox(a), pv ? null : loreMiniTimeline(id), pv ? null : loreBacklinks(id))));
}
/* เหตุการณ์ก่อนหน้า / ถัดไป · หัวข้อย่อยกลับไปที่เหตุการณ์แม่ */
function loreNav(id){ const a = LORE[id]; const nav = h('div',{class:'lore-nav',role:'navigation','aria-label':'อ่านต่อ'});
  const i = LORE_ORDER.indexOf(id);
  if (i >= 0){ const p = LORE_ORDER[i - 1], n = LORE_ORDER[i + 1];
    nav.append(p ? h('a',{class:'lore-navbtn prev',href:'#lore-'+p}, h('span',{class:'dim',text:'← เหตุการณ์ก่อนหน้า'}), h('b',{text:LORE[p].title})) : h('span'),
      n ? h('a',{class:'lore-navbtn next',href:'#lore-'+n}, h('span',{class:'dim',text:'เหตุการณ์ถัดไป →'}), h('b',{text:LORE[n].title})) : h('a',{class:'lore-navbtn next',href:'#lore'}, h('span',{class:'dim',text:'จบเส้นเวลา'}), h('b',{text:'กลับสารบัญ'}))); }
  else if (a.parent) nav.append(h('a',{class:'lore-navbtn prev',href:'#lore-'+a.parent}, h('span',{class:'dim',text:'← กลับไปที่เหตุการณ์'}), h('b',{text:LORE[a.parent].title})), h('a',{class:'lore-navbtn next',href:'#lore'}, h('span',{class:'dim',text:'สารบัญ'}), h('b',{text:'ตำนานแห่งคีรันนา'})));
  else nav.append(h('a',{class:'lore-navbtn prev',href:'#lore'}, h('span',{class:'dim',text:'← สารบัญ'}), h('b',{text:'ตำนานแห่งคีรันนา'})));
  return nav; }
function loreInfobox(a){ if (!(a.box||[]).length) return null;
  return h('div',{class:'card lore-infobox'}, h('h3',{text:a.title}), h('div',{class:'dim',style:'font-size:12px;margin:-2px 0 8px',text:a.en}),
    h('table',{class:'lore-ibt'}, a.box.map(([k, v])=>h('tr',null, h('th',{text:k}), h('td',null, loreNodes(v)))))); }
/* ในเกม: วงศาที่เลือกเล่นได้ ไอเทม และทักษะที่เรื่องนี้เกี่ยวข้อง */
function loreGameBox(a){ const g = a.game; if (!g) return null; const box = h('div',{class:'card lore-game'}, h('h3',{text:'ในเกม'}));
  const kins = (g.kins||[]).filter(k=>KIN[k]); const items = (g.items||[]).map(n=>(DATA.items||[]).find(it=>it.name===n)).filter(Boolean); const skills = (g.skills||[]).filter(Boolean);
  if (kins.length) box.append(h('div',{class:'kicker',text:'วงศาที่เลือกเล่นได้'}), h('div',{class:'lore-chips'}, kins.map(k=>h('button',{class:'small gchip',onclick:()=>kinInfoModal(k),text:KIN[k].name}))));
  if (items.length) box.append(h('div',{class:'kicker',text:'ไอเทม'}), h('div',{class:'lore-chips'}, items.map(it=>h('button',{class:'small gchip',onclick:()=>itemInfoModal(it),text:itemNameSplit(it.name)[0]}))));
  if (skills.length) box.append(h('div',{class:'kicker',text:'ทักษะและเวทมนตร์'}), h('div',{class:'lore-chips'}, skills.map(sub=>h('button',{class:'small gchip',onclick:()=>skillLibFocus(sub),text:skSubInfo(sub).th}))));
  return box; }
function loreMiniTimeline(id){ const a = LORE[id]; const back = loreBack()[id] || [];
  const mark = new Set(a.kind==='event' ? [id] : a.parent ? [a.parent] : back.filter(x=>LORE[x].kind==='event'));
  const box = h('div',{class:'card lore-mini'}, h('h3',{text:'เส้นเวลา'}));
  for (const era of LORE_ERAS){ box.append(h('div',{class:'mini-era',text:era.title}), h('ol',{class:'mini-evs'}, era.events.map(x=>h('li',{class:(x===id ? 'cur' : mark.has(x) ? 'hit' : '')}, x===id ? h('b',{text:LORE[x].title}) : h('a',{href:'#lore-'+x,text:LORE[x].title}))))); }
  if (a.kind!=='event' && !a.parent && mark.size) box.append(h('p',{class:'dim',style:'font-size:11.5px;margin:6px 0 0',text:'จุดที่ไฮไลต์คือเหตุการณ์ที่กล่าวถึง'+a.title}));
  return box; }
function loreBacklinks(id){ const back = (loreBack()[id]||[]).filter(x=>x!==id); if (!back.length) return null;
  const ord = (x)=>{ const i = LORE_ORDER.indexOf(x); return i >= 0 ? i : 100 + LORE_KIND_ORDER.indexOf(LORE[x].kind); };
  return h('div',{class:'card lore-back'}, h('h3',{text:'ถูกกล่าวถึงใน'}), h('div',{class:'lore-chips'}, back.sort((x, y)=>ord(x) - ord(y)).map(x=>loreChip(x)))); }

/* ---- แผนผังระบบพลัง (Non เคาะ 16 พ.ย. 2026: "พวกเรื่องระบบพลังทำเป็นแผนผังให้ก็ดีนะ") ----
 * บล็อก ['fig', id] ในเนื้อบทความ วาดเป็น SVG ด้วยสีของธีม (มืดและกระดาษ) ข้อความทั้งหมดมาจากต้นฉบับ Astral Sea Lore */
const SVGNS = 'http://www.w3.org/2000/svg';
function sv(tag, attrs, ...kids){ const e = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs||{})) if (v != null && v !== false) e.setAttribute(k, v);
  for (const kid of kids.flat(Infinity)) if (kid != null && kid !== false) e.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  return e; }
/* ข้อความหลายบรรทัด: lines = [[ข้อความ, คลาส], ...] เว้นบรรทัดละ lh */
function svLines(x, y, lines, anchor, lh){ lh = lh || 17;
  return sv('text',{x, y, 'text-anchor':anchor||'middle'}, lines.map((ln, i)=>{ const [t, c] = Array.isArray(ln) ? ln : [ln, '']; return sv('tspan',{x, dy: i ? lh : 0, class:c||null}, t); })); }
/* กล่องข้อความ: บรรทัดแรกเป็นหัว ที่เหลือเป็นคำอธิบาย */
function svBox(x, y, w, hgt, lines, cls){ const n = lines.length; const lh = 16.5; const y0 = y + hgt/2 - (n - 1) * lh / 2 + 5;
  return sv('g',{class:'lf-node' + (cls ? ' ' + cls : '')}, sv('rect',{x, y, width:w, height:hgt, rx:9}),
    svLines(x + w/2, y0, lines.map((t, i)=>[t, i ? 'lf-sub' : 'lf-head']), 'middle', lh)); }
function svDefs(id){ return sv('defs',null,
  sv('marker',{id:'lfa-'+id, viewBox:'0 0 10 10', refX:8.5, refY:5, markerWidth:7, markerHeight:7, orient:'auto-start-reverse'}, sv('path',{d:'M0,0 L10,5 L0,10 z', class:'lf-tip'})),
  sv('marker',{id:'lfb-'+id, viewBox:'0 0 10 10', refX:5, refY:5, markerWidth:8, markerHeight:8, orient:'auto'}, sv('path',{d:'M5,0 L5,10', class:'lf-bar'}))); }
function svArrow(id, d, cls, both){ return sv('path',{d, class:'lf-arrow' + (cls ? ' ' + cls : ''), 'marker-end':'url(#lfa-'+id+')', 'marker-start': both ? 'url(#lfa-'+id+')' : null}); }
function svLabel(x, y, t, cls, anchor){ return sv('text',{x, y, class:'lf-lab' + (cls ? ' ' + cls : ''), 'text-anchor':anchor||'middle'}, t); }
const LORE_FIGS = {
  resetcycle: { title:'วัฏจักรมานาและการรีเซ็ตของโลก', cap:'อารยธรรมที่ดึงลมมานามาใช้จนฟ้าอิ่มตัวจะปลุกระบบสิบสามห้วงที่วัลล็อปวางไว้ เมื่อเข้าสู่ห้วงที่ 13 โลกรีเซ็ตตัวเอง แล้ววัฏจักรก็เริ่มนับใหม่ สิ่งที่ตายในการรีเซ็ตไม่ถูกปิดจนสนิท และสะสมเป็นสิ่งตกค้างทุกรอบ',
    draw(id){ return [svDefs(id),
      sv('ellipse',{cx:380, cy:225, rx:122, ry:56, class:'lf-core'}),
      svLines(380, 205, [['ภูมิคุ้มกันของดวงดาว','lf-head'],['สิบสามห้วงที่วัลล็อปวางไว้','lf-sub'],['จำกัดประชากร','lf-sub'],['กันอารยธรรมใดก้าวพ้นดวงดาว','lf-sub']], 'middle', 16.5),
      svBox(273, 34, 214, 54, ['อารยธรรมเติบโต','ประชากรเพิ่ม เวทมนตร์รุ่งเรือง']),
      svBox(494, 116, 214, 54, ['ดึงลมมานามาใช้','ราคาเป็นศูนย์ จึงดูดกันไม่หยุด']),
      svBox(494, 281, 214, 54, ['มานาในฟ้าอิ่มตัว','เมฆผิดปกติเหนือฟรอเซนเบิร์ก']),
      svBox(273, 364, 214, 54, ['ห้วงที่ 13: รีเซ็ต','ครั้งล่าสุดคือการล่มสลาย'], 'hot'),
      svBox(52, 281, 214, 54, ['ภัยพิบัติและสงคราม','ไข้มานา ความอดอยาก ประชากรล่ม']),
      svBox(52, 116, 214, 54, ['มานาจาง ม่านบางลง','แสงแรก ฤดูกาลกลับคืน']),
      svArrow(id, 'M489,62 Q566,64 596,112'), svArrow(id, 'M650,172 Q680,226 650,277'), svArrow(id, 'M598,337 Q568,388 489,391'),
      svArrow(id, 'M271,391 Q192,388 162,337'), svArrow(id, 'M110,279 Q80,226 110,172'), svArrow(id, 'M164,112 Q194,62 271,62'),
      sv('g',{class:'lf-pin'}, sv('rect',{x:512, y:212, width:128, height:26, rx:13}), svLabel(576, 230, '◉ ยุคสหพันธรัฐ', 'pin')),
      svArrow(id, 'M489,406 L516,426', 'dash'),
      svBox(518, 404, 238, 68, ['สิ่งที่ตายแล้วไม่ถูกปิด','เขตแดนผี · ซากที่ไม่ผุ · อสูรนอกห่วงโซ่','งานปิดยุคเดิมเป็นของดาดัสเธน'], 'ghost')]; }, w:760, h:480 },
  twostate: { title:'หลักสองสถานะแห่งมานา', cap:'ลมมานาไร้เจ้าของและราคาเป็นศูนย์ มานาข้นเป็นทรัพย์สินที่ซื้อขายได้ เครื่องรบกวนมานาเปลี่ยนอากาศให้เป็นเขตมีเจ้าของ ส่วนอิสรภาพในการดูดลมฟรีคือแรงที่หมุนวัฏจักรมานาให้เร็วขึ้น',
    draw(id){ return [svDefs(id),
      svBox(20, 20, 300, 150, ['สถานะที่หนึ่ง ลมมานา','Ambient Mana','ไร้เจ้าของ เหมือนอากาศที่หายใจ','ใครก็ดึงใช้ระดับยังชีพได้เสรี','ราคาตลาดเป็นศูนย์เสมอ'], 'free'),
      svBox(440, 20, 300, 150, ['สถานะที่สอง มานาข้น','Concentrated Mana','ผลึก · เซฟไฟน์ · เขาผลึก · เซลล์ประจุ','กระแสพลังในโครงข่ายมานา','ขุด ถือครอง ซื้อขาย เก็บภาษี จำนอง คว่ำบาตร'], 'owned'),
      svArrow(id, 'M322,70 L436,70'), svLabel(380, 60, 'ควบแน่น ขุด กลั่น'), svLabel(380, 92, 'มีต้นทุน', 'dim'),
      svBox(230, 222, 300, 76, ['เครื่องรบกวนมานา ล้อมเขต','ลมมานาในเขตถูกดึงมาใช้ไม่ได้','ทุกคนต้องซื้อมานาข้นจากผู้คุมแจมเมอร์'], 'hot'),
      svArrow(id, 'M170,172 Q176,258 226,260', 'cut'), svLabel(132, 238, 'ถูกตัดขาด', 'neg'),
      svArrow(id, 'M532,260 Q584,258 590,174'), svLabel(628, 238, 'บังคับซื้อ'),
      svLabel(380, 320, 'เครื่องยนต์เก็บค่าเช่ามานาของสิบสามตระกูลรีฟ', 'dim'),
      sv('g',{class:'lf-strip'}, sv('rect',{x:20, y:340, width:720, height:44, rx:10}),
        svLabel(380, 367, 'ลมฟรีถูกกว่าเสมอ  ›  ทุกอารยธรรมดูดลมมานา  ›  มานาในฟ้าหนาขึ้น  ›  วัฏจักรมานาหมุนเร็วขึ้น', 'strip'))]; }, w:760, h:396 },
  veil: { title:'ระบบแสงของคีรันนา', cap:'ม่านมานาปิดฟ้าของพื้นราบด้วยแสงกระจายที่ไม่ทอดเงาคม มีเพียงยอดเขาที่ศิลาลอยค้ำไว้ซึ่งทะลุพ้นเพดานม่าน ไปถึงดวงอาทิตย์และดวงดาวที่คนบนพื้นราบหลายคนไม่เคยเห็น',
    draw(id){ const stars = [[40,24],[96,52],[150,18],[214,40],[268,22],[322,58],[372,28],[610,22],[700,44],[736,18],[560,48],[470,20]];
      return [svDefs(id),
      sv('rect',{x:0, y:0, width:760, height:156, class:'lf-sky'}),
      stars.map(([x, y])=>sv('circle',{cx:x, cy:y, r:1.6, class:'lf-star'})),
      sv('circle',{cx:666, cy:64, r:24, class:'lf-sun'}),
      sv('g',{class:'ondark'}, svLines(24, 84, [['เหนือม่าน','lf-head'],['ดวงอาทิตย์เต็มดวง ดาวเต็มฟ้า','lf-sub']], 'start', 17)),
      sv('path',{d:'M0,150 C120,128 220,170 340,148 C460,126 560,168 760,140 L760,186 C600,206 470,170 340,192 C210,214 110,176 0,196 Z', class:'lf-veil'}),
      sv('path',{d:'M28,146 L76,142 L86,200 L22,202 Z', class:'lf-gap'}),
      sv('path',{d:'M38,202 L30,300 M52,202 L54,300 M66,202 L78,300', class:'lf-ray'}),
      sv('path',{d:'M360,330 L440,60 L486,150 L520,92 L600,330 Z', class:'lf-peak'}),
      sv('path',{d:'M440,60 L422,122 L458,122 Z M520,92 L506,140 L534,140 Z', class:'lf-snow'}),
      svLabel(480, 266, 'ศิลาลอยค้ำยอดเขา', 'onpeak'),
      svLabel(258, 172, 'เพดานม่านมานา หนาบางตามห้วงและภูมิภาค', 'veil'),
      svLines(96, 226, [['ช่องฟ้าโปร่ง','lf-head'],['ห้วงฟ้าคลาย เหนือทะเลทรายและชายฝั่ง','lf-sub']], 'start', 17),
      sv('rect',{x:0, y:330, width:760, height:4, class:'lf-ground'}),
      svLines(96, 272, [['พื้นราบใต้ม่าน','lf-head'],['แสงกระจาย ไม่ทอดเงาคม ไม่เห็นดวงตะวัน','lf-sub'],['นับเวลาด้วยชีพจรมานาและห้วงเทียน','lf-sub']], 'start', 17),
      svLines(744, 210, [['ผู้ครองยอดเขา','lf-head'],['ครองแสงแดด พืชแดด','lf-sub'],['เส้นทางแสวงบุญ','lf-sub'],['และความจริงเรื่องเวลา','lf-sub']], 'end', 17)]; }, w:760, h:350 },
  gods: { title:'สี่มหาเทพผู้ปกปักษ์คีรันนา', cap:'เทพวัยเยาว์สี่องค์ถ่วงสมดุลของโลกด้วยวิธีที่ขัดกันเอง เนเมสไซอาร์ทรงพลังที่สุดและขวางไม่ให้องค์อื่นทำลายอารยธรรมโดยตรง ดาดัสเธนกับมอร์ริกอร์คือขั้วตรงข้ามที่ขาดกันไม่ได้ ส่วนซินเทียร์คือตัวตนระดับเทพที่เกิดภายหลัง',
    draw(id){ return [svDefs(id),
      svBox(250, 14, 260, 92, ['เนเมสไซอาร์ ศาสดาสีเลือด','แรงปรารถนา ความรัก การก่อกำเนิด','พิทักษ์มนุษย์และผู้อ่อนแอ','ดวงจันทร์สีเลือด ฝ่ามือ ดวงตา'], 'blood'),
      svBox(16, 168, 226, 92, ['ซิลวา หรือไกอานา','พฤกษา ความอุดมสมบูรณ์','มารดาของเผ่าพฤกษา','เกลียดอารยธรรมที่โตเกิน'], 'green'),
      svBox(518, 168, 226, 92, ['ซินเทียร์ (เทียร์ลาเมน)','จิตสำนึกจักรกลที่เกิดภายหลัง','จากข้อมูลในกระแสมานา','ผู้นำของซินเฟรย์'], 'ghost'),
      svBox(96, 332, 250, 92, ['ดาดัสเธน หรือเธน','เทพแห่งกาลเวลา คนแคระเชิดชู','ปิดยุคที่จบแล้วให้สนิท','ค้อนและลิ่ม'], 'stone'),
      svBox(414, 332, 250, 92, ['มอร์ริกอร์','ความเท่าเทียม เสรีภาพ ภูตพราย','ชาวสวาลานนับถือ','ตราชั่งและเชิงเทียน'], 'violet'),
      svArrow(id, 'M250,84 Q160,92 140,164', 'cut'), svLabel(236, 40, 'ขวางไม่ให้ทำลาย', 'neg', 'end'), svLabel(236, 57, 'อารยธรรมโดยตรง', 'neg', 'end'),
      svArrow(id, 'M510,84 Q604,92 624,164'), svLabel(524, 40, 'มอบชีวิต', '', 'start'), svLabel(524, 57, 'และความรู้สึก', '', 'start'),
      svArrow(id, 'M350,378 L410,378', 'pair', true), svLabel(380, 318, 'ขั้วตรงข้ามที่ขาดกันไม่ได้'),
      svLabel(221, 448, 'ปิดสิ่งที่หมดวาระ', 'dim'), svLabel(539, 448, 'กันสิ่งที่ยังไม่ถูกตัดสินไม่ให้ถูกปิด', 'dim')]; }, w:760, h:462 },
};
function loreFig(fid){ const f = LORE_FIGS[fid]; if (!f) return null;
  const svg = sv('svg',{viewBox:`0 0 ${f.w} ${f.h}`, class:'lfig-svg', role:'img', 'aria-label':f.title}, sv('title',null, f.title), f.draw('f' + fid));
  return h('figure',{class:'lfig'}, h('div',{class:'lfig-scroll'}, svg), h('figcaption',null, h('b',{text:f.title}), ' ', f.cap)); }

/* ---- หน้าต่างข้อมูลวงศาและไอเทม (เปิดจากตำนาน คลังทักษะ และคลังไอเทม) ---- */
const KIN_SKILL_SUB = { lunaryn:'Lunaryn', solrin:'Solrin', nightkin:'Nightkin', rimmen:'Human (ทุกสายมนุษย์)', norlan:'Human (ทุกสายมนุษย์)', 'day-alves':'Day Alves', 'night-alves':'Night Alves', 'handerlaw-dwarves':'Handerlaw Dwarves', swalan:'Swalan', floran:'Floran', orcarim:'Orcarim', necrobug:'Necrobug' };
const KIN_LORE = { lunaryn:'bloodmoon', solrin:'solrin', nightkin:'childofnight', swalan:'swalan' };
function kinInfoModal(k){ const kin = KIN[k]; if (!kin) return;
  const names = (arr, cls)=>(arr||[]).filter(x=>x && x.name).map(x=>tag(x.name + (x.nameEn ? ' (' + x.nameEn + ')' : ''), cls));
  const sub = KIN_SKILL_SUB[k]; const nSk = sub ? DATA.skills.filter(s=>s.category==='Kins Unique' && s.subcategory===sub).length : 0;
  modal(h('div',{class:'kinmodal'}, h('div',{class:'kicker',text:'วงศาที่เลือกเล่นได้'}), h('h3',{text:kin.name}),
    (kin.intro||[]).slice(0, 2).map(p=>h('p',{class:'desc',style:'margin:8px 0 0',text:p})),
    (kin.benefits||[]).length || (kin.traits||[]).length ? h('div',{style:'margin-top:10px'}, h('div',{class:'kicker',text:'Trait ติดตัว'}), h('div',{class:'gives'}, names(kin.benefits, 'ok'), names(kin.traits, 'stat'))) : null,
    (kin.hindrances||[]).length ? h('div',{style:'margin-top:6px'}, h('div',{class:'kicker',text:'ข้อจำกัด'}), h('div',{class:'gives'}, names(kin.hindrances, 'neg'))) : null,
    h('div',{class:'row',style:'margin-top:12px'},
      nSk ? h('button',{class:'primary small',onclick:()=>{ modal(null); skillLibFocus(sub); },text:`ดูทักษะเฉพาะวงศา (${nSk})`}) : null,
      KIN_LORE[k] && location.hash !== '#lore-'+KIN_LORE[k] ? h('button',{class:'small',onclick:()=>{ modal(null); location.hash = '#lore-'+KIN_LORE[k]; },text:'อ่านตำนาน'}) : null)));
}
/* ชื่อไอเทม "ชื่อไทย (English)" แยกเป็นสองส่วน */
function itemNameSplit(name){ const s = String(name||'').trim(); const m = /^(.*?)\s*\(([^()]*)\)\s*$/.exec(s); return m && m[1] ? [m[1], m[2]] : [s, '']; }
function itemPdmg(eff){ const m = /(\d+)\s*PDMG/.exec(eff||''); return m ? +m[1] : null; }
function itemOtherDmg(eff){ const m = /(\d+)\s*(Plasma|Fire|Electric|Lightning)\s*Damage/i.exec(eff||''); return m ? `${m[1]} ${m[2]} Damage` : ''; }
function itemArmor(eff){ const ar = parseArmor(eff||''); if (!ar || (!ar.a && !ar.b)) return null; const txt = armorText([ar], 0); return txt ? {txt, hit: armorHitText(txt)} : null; }
function itemStatTags(it){ const eff = String(it.effect||''); const tr = itemTier(it); const dmg = itemPdmg(eff); const od = dmg == null ? itemOtherDmg(eff) : ''; const ar = itemArmor(eff); const pd = unconditionalParry(eff); const need = weaponStrNeed(eff);
  const layer = it.cat==='เกราะลำตัว' ? (/ชั้นใน|Inner/i.test(it.slot||'') ? 'ชั้นใน' : /ชั้นนอก|Outer/i.test(it.slot||'') ? 'ชั้นนอก' : '') : '';
  return [tr ? tag(itemTierShort(tr), 'prop'+(tr.src==='core' ? ' tier-core' : '')) : null, layer ? tag(layer, 'stat') : null, dmg != null ? tag(dmg+' PDMG','neg') : null, od ? tag(od,'neg') : null, ar ? tag('Armor '+ar.txt,'stat') : null, pd ? tag('+'+pd+' Parry Dice','stat') : null, need ? tag('STR '+need) : null,
    it.weight != null && it.weight !== '' ? tag((+it.weight||0)+' กก.') : null, it.price ? tag(String(it.price).replace(/\s*\(.*\)\s*$/, '')) : null]; }
function itemInfoModal(it, opts){ if (!it) return; opts = opts||{}; const [th, en] = itemNameSplit(it.name); const ar = itemArmor(it.effect); const tr = itemTier(it);
  const inCat = (DATA.items||[]).some(x=>x.name===it.name);
  modal(h('div',{class:'itemmodal'}, h('div',{class:'kicker',text:[it.cat, it.sub].filter(Boolean).join(' · ') || 'ไอเทม'}), h('h3',{text:th}), en ? h('div',{class:'dim',text:en}) : null,
    h('div',{class:'gives',style:'margin-top:8px'}, itemStatTags(it)),
    tr && tr.src==='core' ? h('p',{class:'dim',style:'font-size:12px;margin:2px 0 0',text:`${itemTierShort(tr)} ตามตัวอย่างในหัวข้อระดับชั้นของยุทโธปกรณ์ ไฟล์แกน (Item All ยังไม่ระบุ Tier ของชิ้นนี้)`}) : null,
    it.slot ? h('p',{class:'dim',style:'font-size:12.5px;margin:6px 0 0',text:'ช่องสวมใส่: '+it.slot}) : null,
    it.desc ? h('p',{class:'desc',style:'margin:8px 0 0'}, it.desc) : null,
    it.effect ? h('div',{style:'margin-top:8px'}, h('div',{class:'kicker',text:'คุณสมบัติ'}), h('div',{class:'desc'}, T(it.effect))) : null,
    ar && ar.hit ? h('p',{class:'dim',style:'font-size:12px;margin:6px 0 0',title:ARMOR_RULE_TIP,text:'เกราะชิ้นนี้ชิ้นเดียว: '+ar.hit}) : null,
    it.price ? h('p',{class:'dim',style:'font-size:12.5px;margin:6px 0 0',text:'ราคา: '+it.price}) : null,
    !opts.inLib && inCat ? h('div',{class:'row',style:'margin-top:10px'}, h('button',{class:'small',onclick:()=>{ modal(null); Codex.it.q = th; location.hash = '#items'; if (location.hash === '#items') renderItemLib(); },text:'เปิดในคลังไอเทม'})) : null,
    CatalogEdit.canEdit() && ceKeyOf(it) ? h('div',{class:'row',style:'margin-top:10px'}, h('span',{class:'lore-devtag',text:'หลังบ้าน'}), h('button',{class:'small cedit-open',onclick:()=>ceItemEditor(it),text:'✎ แก้ไอเทมนี้'})) : null)); } // v1.27

/* ============================== คลังทักษะ (#skills) ============================== */
const SK_CATS = [['sorcery','Sorcery','ศาสตร์เวทมนตร์'],['martial','Martial','ทักษะสายนักสู้'],['survival','Survival','ทักษะการเอาตัวรอด'],['trick','Trick','ทักษะหลอกล่อ'],['kins','Kins Unique','ทักษะเฉพาะเผ่าพันธุ์'],['granted','Granted','ได้จากพรสวรรค์'],['all',null,'ทั้งหมด']];
const SK_CAT_DESC = {
  Sorcery:'แบ่งเป็นสามระดับ Novice Expert และ Master จ่ายด้วย MP หรือ Sanity และต้องใช้วิธีการร่าย (Components) U G F',
  Martial:'ทักษะสายนักสู้ ทั้งมือเปล่าและระยะประชิด ระยะไกล กลยุทธ์ ปราณ และกระบวนท่า',
  Survival:'ทักษะที่ช่วยเอาตัวรอดในสถานการณ์ต่าง ๆ ทั้งในสังคม ในป่า และเสริมความทรหดอดทน',
  Trick:'ทักษะที่ใช้เล่ห์เหลี่ยมสร้างความได้เปรียบ เช่น การสาดทราย หรือแสร้งทำเป็นอ่อนแอ',
  'Kins Unique':'ทักษะและความสามารถพิเศษเฉพาะตัวของแต่ละเผ่าพันธุ์',
  Granted:'ทักษะที่ได้จากพรสวรรค์ของค่าพลัง (Talent)' };
/* ชื่อไทยและคำอธิบายของแต่ละประเภท ยกจากสารบัญทักษะและเวทมนตร์ในไฟล์ Skill & Sorceries */
const SK_SUB = {
  'Chaos Sorcery':['ศาสตร์เวทแห่งความโกลาหล','เน้นการควบคุมจิตใจ บิดเบือนความเป็นจริง และใช้พลังจากมิติอื่น'],
  'Plasma & Light Sorcery':['ศาสตร์แห่งพลาสม่าและแสง','เน้นการควบคุมแสงและพลังงานพลาสม่าเพื่อการทำลายล้างและสร้างภาพลวงตา'],
  'Electric & Energy Sorcery':['ศาสตร์แห่งสายฟ้าและพลังงาน','เชี่ยวชาญการควบคุมสายฟ้าและสนามแม่เหล็กเพื่อโจมตีและขัดขวางศัตรู'],
  'Fire & Combustion Sorcery':['ศาสตร์แห่งไฟและการเผาไหม้','เน้นการควบคุมเปลวไฟเพื่อสร้างความเสียหายรุนแรงและต่อเนื่อง'],
  'Wind & Air Sorcery':['ศาสตร์แห่งลมและอากาศ','ควบคุมกระแสลมเพื่อเพิ่มความคล่องตัว ป้องกัน และควบคุมพื้นที่ในสนามรบ'],
  'Solid (Earth & Metal) Sorcery':['ศาสตร์แห่งปฐพีและโลหะ','เชี่ยวชาญการควบคุมดินและโลหะเพื่อการป้องกันและโจมตีอย่างหนักหน่วง'],
  'Liquid (Water & Decay) Sorcery':['ศาสตร์แห่งของเหลวและการสลาย','ควบคุมของเหลวในรูปแบบต่าง ๆ ตั้งแต่น้ำแข็ง พิษ ไปจนถึงพลังชีวิต'],
  'Sylvian Sorcery':['ศาสตร์แห่งพงไพร','โดดเด่นด้านการสนับสนุน ฟื้นฟู และควบคุมศัตรูด้วยพลังแห่งธรรมชาติ'],
  'Ritual Sorcery':['เวทพิธีกรรม หรือ คุณไสย','เปลี่ยนแปลงความเป็นจริงผ่านพิธีกรรม ต้องใช้สมาธิและเวลายาวนานในการเรียกใช้ และมักเกิดผลร้ายแรง'],
  'Blood Sorcery':['เวทโลหิต','ควบคุมโลหิตและพลังชีวิต ปั้นเลือดเป็นหอก เกราะ โซ่ กรงขัง และอาวุธ ถ่ายเทพลังชีวิตเพื่อเยียวยาหรือชุบชีวิต บางเวทจ่ายด้วย HP ของผู้ร่ายเอง ผู้คิดค้นคือแคสเซท จันทราร้อยเรียง หนึ่งในเจ็ดจันทรา','sevenlunars'],
  'Unarmed & Melee Skills':['ทักษะการต่อสู้มือเปล่าและระยะประชิด','เน้นการสร้างความเสียหายและสถานะผิดปกติในระยะใกล้'],
  'Ranged Skills':['ทักษะการต่อสู้ระยะไกล','เน้นความแม่นยำ การควบคุมตำแหน่ง และสร้างความได้เปรียบจากระยะไกล'],
  'Qi':['ปราณ','ศาสตร์การใช้พลังงานชีวิตภายในเพื่อเสริมความสามารถทางกายภาพ ผู้ที่มีทักษะสาย Sorcery ตั้งแต่ 3 สกิลขึ้นไปใช้ปราณไม่ได้'],
  'Stance':['กระบวนท่า','รูปแบบการตั้งท่าที่มอบความสามารถติดตัวชั่วขณะเมื่อเปิดใช้งาน'],
  'Tactical & General Skills':['ทักษะกลยุทธ์และทั่วไป','ทักษะเชิงกลยุทธ์ที่ใช้ได้ทั้งในและนอกการต่อสู้ เพื่อควบคุมสถานการณ์'],
  'Special Skills':['ทักษะพิเศษ','ทักษะที่มีเงื่อนไขเฉพาะตัวแต่ให้ผลลัพธ์ที่ทรงพลัง เช่น การท้าดวล หรือการคลุ้มคลั่ง'],
  'Trick Skills':['ทักษะหลอกล่อ',''],
  'Social & Interaction Survival':['ทักษะการเอาตัวรอดในสังคม',''],
  'Wilderness & Environmental Survival':['ทักษะการเอาตัวรอดในป่า',''],
  'Resilience & Personal Survival':['ทักษะความทรหดและการปรับตัว',''],
  'Human':['ทักษะพื้นฐานของเผ่าพันธุ์มนุษย์','ใช้ได้กับมนุษย์ทุกสาย'],
  'Solrin':['ทักษะเฉพาะของโซลริน','Solrin · Eclipse Order','solrin'],
  'Lunaryn':['ทักษะเฉพาะของลูนาร์ริน','Lunaryn · Blood Moon','bloodmoon'],
  'Nightkin':['ทักษะเฉพาะของไนท์คิน','Nightkin · Child of Night','childofnight'],
  'Swalan':['ทักษะเฉพาะของสวาลาน','Swalan','swalan'],
  'Handerlaw Dwarves':['ทักษะเฉพาะของคนแคระ','Handerlaw Dwarves'],
  'Day Alves':['ทักษะเฉพาะของเอลฟ์','Alves · Day Alves'],
  'Night Alves':['ทักษะเฉพาะของไนท์เอลฟ์','Night Alves'],
  'Floran':['ทักษะเฉพาะของเผ่าพฤกษา','Floran','gods'],
  'Orcarim':['ทักษะเฉพาะของออร์คาริม','Orcarim'],
  'Necrobug':['ทักษะเฉพาะของเนโครบัค','Necrobug · Mok\'Nars'],
  'Faceless':['ทักษะเฉพาะของเฟสเลส','Faceless'],
  'Talent AGI':['พรสวรรค์ AGI',''], 'Talent VIT':['พรสวรรค์ VIT',''], 'Talent PER':['พรสวรรค์ PER',''] };
/* ชื่อประเภทในข้อมูลบางตัวมีหมายเหตุของตัวแปลงไฟล์ในวงเล็บ เช่น Blood Sorcery (ไม่มีหัวข้อในไฟล์ต้นฉบับ) */
function skSubBase(sub){ return String(sub||'').replace(/\s*\((?:[^()]*[฀-๿][^()]*)\)\s*$/, '').trim(); }
function skSubNote(sub){ const m = /\(([^()]*[฀-๿][^()]*)\)\s*$/.exec(String(sub||'')); return m ? m[1] : ''; }
function skSubInfo(sub){ const base = skSubBase(sub); const x = SK_SUB[base] || SK_SUB[sub]; return { base, th: x ? x[0] : base, desc: x ? x[1] : '', lore: x ? x[2] : '', note: skSubNote(sub) }; }
const SK_TIERS = [['Novice','เรียนเองได้','ok'],['Expert','ต้องมีครู ตำรา หรือเคยเห็นทักษะนั้นถูกใช้ต่อหน้า','warn'],['Master','ต้องมีปรมาจารย์ หรือเหตุการณ์ในเรื่อง','neg']];
const SK_ACTS = [['cast','ร่ายเวท (Cast)'],['swift','Swift Action'],['basic','Basic Action'],['reaction','Reaction'],['passive','ติดตัว (Passive)'],['stance','กระบวนท่า (Stance)'],['other','อื่น ๆ']];
function skActs(sk){ const t = String(sk.type||''); const out = [];
  if (/Cast/i.test(t)) out.push('cast'); if (/Swift/i.test(t)) out.push('swift'); if (/Basic|(^|[^A-Za-z])AP([^A-Za-z]|$)/.test(t)) out.push('basic'); if (/Reaction/i.test(t)) out.push('reaction'); if (/Passive/i.test(t)) out.push('passive');
  if (/กระบวนท่า/.test(t) || (sk.tags||[]).includes('Stance') || sk.subcategory==='Stance') out.push('stance');
  if (!out.length) out.push('other'); return out; }
const SK_TIER_ORDER = {Novice:0, Expert:1, Master:2};
function skSort(a, b){ return (SK_TIER_ORDER[a.tier] ?? 3) - (SK_TIER_ORDER[b.tier] ?? 3) || (a.ipCost ?? 99) - (b.ipCost ?? 99) || skTh(a).localeCompare(skTh(b), 'th'); }
function skillLibFocus(sub){ const sk = DATA.skills.find(s=>skSubBase(s.subcategory)===skSubBase(sub) || s.subcategory===sub); const cat = sk ? (SK_CATS.find(c=>c[1]===sk.category)||['all'])[0] : 'all';
  Object.assign(Codex.sk, {cat, tier:'', act:'', q:'', focus: sk ? sk.subcategory : ''}); const hash = '#skills-'+cat; if (location.hash === hash) renderSkillLib(cat); else location.hash = hash; }
function renderSkillLib(arg){
  const st = Codex.sk; if (arg && SK_CATS.some(c=>c[0]===arg) && arg !== st.cat){ st.cat = arg; st.tier = ''; st.act = ''; } // เปลี่ยนหมวดแล้วตัวกรองเริ่มใหม่ กลับมาหน้าเดิมตัวกรองยังอยู่
  const root = clear($('#v-skills'));
  const total = DATA.skills.length;
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'คลังทักษะและเวทมนตร์'}),
    h('p',{text:`ทักษะทั้งหมด ${total} รายการ จัดหมวดและประเภทตามไฟล์ Skill & Sorceries เวทมนตร์แบ่งเป็นสามระดับตามประตูของทักษะ ส่วนหมวดอื่นในไฟล์ไม่ได้แบ่งระดับ จึงเรียงตามราคา IP`}))));
  { const bar = ceDevBar('skills', {category: (SK_CATS.find(c=>c[0]===st.cat)||[])[1] || ''}); if (bar) root.append(bar); } // v1.27: หลังบ้านแก้ทักษะ
  root.append(h('div',{class:'cx-tabs',role:'tablist'}, SK_CATS.map(([key, name, th])=>{ const n = name ? DATA.skills.filter(s=>s.category===name).length : total;
    return h('button',{class:'cx-tab'+(st.cat===key?' on':''),role:'tab','aria-selected':st.cat===key?'true':'false',dataset:{cat:key},onclick:()=>{ Object.assign(st, {tier:'', act:'', focus:''}); const hs = '#skills-'+key; if (location.hash === hs) renderSkillLib(key); else location.hash = hs; }}, th, h('span',{class:'n',text:String(n)})); })));
  const q = h('input',{type:'search',placeholder:'ค้นชื่อ ประเภท หรือข้อความในเอฟเฟกต์',value:st.q,'aria-label':'ค้นทักษะ',style:'min-width:240px;flex:1'});
  const chips = h('div',{class:'cx-filters'});
  const count = h('span',{class:'dim cx-count'});
  const toc = h('aside',{class:'cx-toc card'}); const list = h('div',{class:'cx-list'});
  const drawChips = ()=>{ clear(chips);
    const catName = (SK_CATS.find(c=>c[0]===st.cat)||[])[1];
    if (!catName || catName==='Sorcery') chips.append(h('div',{class:'cx-chiprow'}, h('span',{class:'cx-fl',text:'ระดับ'}), [['','ทุกระดับ'], ...SK_TIERS.map(t=>[t[0], t[0]]), ...(catName ? [] : [['none','ไม่แบ่งระดับ']])].map(([v, l])=>h('button',{class:'small cx-chip'+(st.tier===v?' on':''),dataset:{tier:v},onclick:()=>{ st.tier = v; drawChips(); draw(); },text:l}))));
    chips.append(h('div',{class:'cx-chiprow'}, h('span',{class:'cx-fl',text:'การใช้งาน'}), [['','ทุกแบบ'], ...SK_ACTS].map(([v, l])=>h('button',{class:'small cx-chip'+(st.act===v?' on':''),dataset:{act:v},onclick:()=>{ st.act = v; drawChips(); draw(); },text:l})))); };
  const draw = ()=>{ clear(toc); clear(list);
    const catName = (SK_CATS.find(c=>c[0]===st.cat)||[])[1];
    let pool = DATA.skills.filter(s=>!catName || s.category===catName);
    if (st.tier) pool = pool.filter(s=>(s.tier||'none')===st.tier);
    if (st.act) pool = pool.filter(s=>skActs(s).includes(st.act));
    const k = st.q.trim().toLowerCase(); if (k) pool = pool.filter(s=>[s.nameEn, s.nameTh, s.flavor, s.effect, s.type, s.subcategory, skSubInfo(s.subcategory).th, s.branch, s.condition, s.cost].join(' ').toLowerCase().includes(k));
    count.textContent = `${pool.length} รายการ`;
    if (!pool.length){ list.append(h('div',{class:'card dim',text:'ไม่พบทักษะที่ตรงกับตัวกรอง ลองล้างคำค้นหรือเลือก "ทุกระดับ"'})); toc.append(h('div',{class:'dim',text:'ไม่มีหมวดที่ตรง'})); return; }
    // หมวด → ประเภท (ตามลำดับในไฟล์)
    const cats = SK_CATS.filter(c=>c[1] && (!catName || c[1]===catName));
    toc.append(h('h3',{text:'สารบัญ'}));
    let gi = 0; let focusEl = null;
    for (const [, cname, cth] of cats){ const inCat = pool.filter(s=>s.category===cname); if (!inCat.length) continue;
      const subs = [...new Set(inCat.map(s=>s.subcategory))];
      if (!catName){ list.append(h('h3',{class:'cx-cathead'}, cth, h('span',{class:'dim',text:' '+cname}))); toc.append(h('div',{class:'cx-toccat',text:cth})); }
      else list.append(h('p',{class:'desc cx-catdesc',text:SK_CAT_DESC[cname]||''}));
      const tl = h('ol',{class:'cx-tocl'}); toc.append(tl);
      for (const sub of subs){ const arr = inCat.filter(s=>s.subcategory===sub).sort(skSort); const info = skSubInfo(sub); const gid = 'skg-'+(gi++);
        const sec = h('section',{class:'cx-group',id:gid,dataset:{sub}});
        const tierCount = SK_TIERS.map(([t,, cls])=>{ const n = arr.filter(s=>s.tier===t).length; return n ? tag(`${t} ${n}`, cls) : null; });
        sec.append(h('div',{class:'cx-ghead'}, h('div',null, h('h3',null, info.th, info.base && info.base !== info.th ? h('span',{class:'en',text:info.base}) : null), info.desc ? h('p',{class:'desc',text:info.desc}) : null, info.note ? h('p',{class:'dim',style:'font-size:12px;margin:2px 0 0',text:'หมายเหตุ: '+info.note}) : null),
          h('div',{class:'gives'}, tag(`${arr.length} ทักษะ`), tierCount, info.lore && LORE[info.lore] ? h('a',{class:'lchip k-'+LORE[info.lore].kind,href:'#lore-'+info.lore,title:'อ่านตำนานที่เกี่ยวข้อง'}, h('span',{class:'lchip-i',text:'☾'}), 'ตำนาน: ' + LORE[info.lore].title) : null)));
        if (cname==='Sorcery'){ for (const [t, gate, cls] of SK_TIERS){ const ts = arr.filter(s=>s.tier===t); if (!ts.length) continue; sec.append(h('div',{class:'cx-tierhead'}, tag(t, cls), h('span',{class:'dim',text:gate})), h('div',{class:'cx-grid'}, ts.map(cxSkillCard))); }
          const rest = arr.filter(s=>!SK_TIER_ORDER.hasOwnProperty(s.tier)); if (rest.length) sec.append(h('div',{class:'cx-grid'}, rest.map(cxSkillCard))); }
        else sec.append(h('div',{class:'cx-grid'}, arr.map(cxSkillCard)));
        list.append(sec); if (st.focus && sub===st.focus) focusEl = sec;
        tl.append(h('li',null, h('button',{class:'linkish',onclick:()=>cxScrollTo(sec)}, info.th, h('span',{class:'dim',text:' '+arr.length})))); } }
    if (focusEl){ st.focus = ''; const jump = ()=>{ if (focusEl.isConnected) focusEl.scrollIntoView({block:'start'}); }; requestAnimationFrame(jump); setTimeout(jump, 250); } // กระโดดตรงทันที แล้วซ้ำอีกครั้งหลังฟอนต์และภาพจัดหน้าเสร็จ
  };
  q.oninput = ()=>{ st.q = q.value; draw(); };
  root.append(h('div',{class:'cx-bar'}, h('div',{class:'row'}, q, count), chips));
  root.append(h('div',{class:'cx-layout'}, toc, list));
  drawChips(); draw();
}
function cxSkillCard(sk){ const tierCls = sk.tier==='Master' ? 'neg' : sk.tier==='Expert' ? 'warn' : 'ok';
  return h('div',{class:'cx-sk',dataset:{name:sk.nameEn}},
    h('div',{class:'cx-sk-h'}, h('b',{class:hueCls(sk.nameEn, sk.type, sk.flavor, sk.effect).trim(),text:skTh(sk)}), skEn(sk) ? h('span',{class:'dim',text:skEn(sk)}) : null, ceEditBtn('skills', sk)), // v1.27: ✎ หลังบ้าน
    h('div',{class:'gives'}, ceMark('skills', sk), sk.tier ? tag(sk.tier, tierCls) : null, sk.ipCost != null ? tag(`${sk.ipCost} IP`) : null, sk.type ? tag(sk.type.length > 46 ? sk.type.slice(0, 46) + '…' : sk.type, 'stat') : null, sk.cost ? tag(sk.cost, 'prop') : null, sk.components ? compTag(sk.components) : null, sk.branch && !/ไม่มีหัวข้อ/.test(sk.subcategory||'') ? tag(sk.branch.replace(/^(สายที่\s*\d+|หมวดหมู่)\s*:\s*/, ''), 'cx-branch') : null),
    sk.condition ? h('div',{class:'eff',style:'color:var(--warn)'}, 'เงื่อนไข: ', T(sk.condition)) : null,
    sk.flavor ? h('div',{class:'eff flavor'}, T(sk.flavor)) : null,
    h('div',{class:'eff'}, T(sk.effect||'')),
    ...skillRollLines(sk, 'eff skroll'),
    sk.extra && sk.extra.length ? h('details',null, h('summary',{text:'รายละเอียดเพิ่ม'}), sk.extra.map(x=>h('div',{class:'eff'}, T(x)))) : null); }

/* ============================== คลังไอเทม (#items) ============================== */
const IT_FAMS = [
  ['weapon','อาวุธ',['อาวุธประชิด','อาวุธระยะไกล','อาวุธเทคโนโลยี','อาวุธเวทมนตร์','กระสุน']],
  ['armor','ชุดเกราะและโล่',['เกราะลำตัว','หมวกเกราะ','โล่','เกราะส่วนย่อย']],
  ['wear','เครื่องแต่งกาย',['เสื้อผ้าและหมวก','แหวน']],
  ['gear','เครื่องมือและอุปกรณ์',['เครื่องมือและอุปกรณ์','อุปกรณ์พิเศษ','ไอเทมเวทมนตร์']],
  ['supply','เสบียงและวัตถุดิบ',['เสบียงและเครื่องดื่ม','วัตถุดิบอาหาร','วัตถุดิบเล่นแร่แปรธาตุ']],
  ['sets','ชุดเริ่มต้น',null]];
/* ระดับชั้นของยุทโธปกรณ์ ไฟล์แกน บทเศรษฐศาสตร์ ข้อ 1 */
const IT_TIER_INFO = {1:['ของสามัญ','Common Tier','ยุทโธปกรณ์พื้นฐานที่หาได้ทั่วไป ของชาวบ้าน ทหารเกณฑ์ และนักผจญภัยมือใหม่'], 2:['ของทหาร','Military Tier','คุณภาพดีสำหรับทหารอาชีพหรือนักผจญภัยที่มีประสบการณ์ เริ่มมีคุณสมบัติเฉพาะทาง'], 3:['ของชั้นยอด','Masterwork Tier','สร้างโดยช่างฝีมือชั้นครู ของคู่กายนักรบชั้นยอดหรือผู้บัญชาการ'], 4:['ของในตำนาน','Legendary Tier','มาสเตอร์พีซหายากและทรงอานุภาพ สร้างด้วยศาสตร์ที่สาบสูญหรือเทคโนโลยีทหารขั้นสูงสุด'], S:['ของเวทมนตร์และของพิเศษ','Sorcerous & Special','หลอมรวมพลังเวทมนตร์หรือเทคโนโลยีขั้นสูง มักไม่มีขายทั่วไป']};
/* ไอเทมที่ Item All ไม่ได้ใส่ Tier แต่ไฟล์แกนยกเป็นตัวอย่างของระดับนั้นตรงตัว (ตัวอย่างที่เป็นอาวุธมี Tier ใน Item All ตรงกันทุกชิ้นแล้ว) */
const IT_CORE_TIER = {'เกราะหนังฟอก (Hide Armor)':1, 'รองเท้าหนังสัตว์ (Leather Boots)':1, 'เกราะโซ่ถัก (Chain Hauberk / Chain Mail)':2, 'เกราะแผ่นช่วงอก (Cuirass)':3, 'เกราะแผ่นเต็มยศ (Harness Plate Armor)':4, 'คทาเพลิง (Fire Mace)':'S', 'ดาบความถี่สูง (High Frequency Cutter)':'S', 'ปืนไรเฟิลเซฟไฟน์ (Sephine Rifle)':'S'};
function itemTier(it){ if (it && it.tier != null && it.tier !== '') return {t: it.tier, src:'file'}; const s = String(it && it.sub || ''); const m = /ระดับ(?:อาวุธ)?\s*(\d)/.exec(s); if (m) return {t:+m[1], src:'file'}; if (/ระดับพิเศษ/.test(s)) return {t:'S', src:'file'};
  if (it && IT_CORE_TIER[it.name] != null) return {t:IT_CORE_TIER[it.name], src:'core'}; return null; }
function itemTierShort(tr){ return tr.t==='S' ? 'Tier พิเศษ' : 'Tier '+tr.t; }
const IT_TIER_FILTER = [['','ทุก Tier'],['1','Tier 1'],['2','Tier 2'],['3','Tier 3'],['4','Tier 4'],['S','พิเศษ'],['none','ไม่ระบุ']];
function itemTierKey(it){ const tr = itemTier(it); return tr ? String(tr.t) : 'none'; }
const WEAR_GROUPS = [['head','หมวกและผ้าคลุมศีรษะ'],['shirt','เสื้อ'],['chestOut','เสื้อนอกและเสื้อคลุม'],['legs','กางเกง กระโปรง และของสวมขา'],['other','อื่น ๆ']];
/* กลุ่มย่อยภายในหมวด: Tier (อาวุธ โล่ หมวกเกราะ) · ชั้นที่สวม (เกราะลำตัว) · หัวข้อย่อยในไฟล์ · ช่องสวมใส่ (เสื้อผ้า) */
function itemSubgroups(cat, arr){
  if (['อาวุธประชิด','อาวุธระยะไกล','อาวุธเทคโนโลยี','อาวุธเวทมนตร์','โล่','หมวกเกราะ','เกราะลำตัว'].includes(cat)){ const keys = [1,2,3,4,'S'];
    return keys.map(t=>{ const xs = arr.filter(it=>{ const tr = itemTier(it); return tr && tr.t===t; }); if (!xs.length) return null; const info = IT_TIER_INFO[t]; const fileLabel = (xs[0].sub||'').replace(/^ระดับ(?:อาวุธ)?\s*\d\s*:?\s*/, '').replace(/^ระดับพิเศษ\s*:?\s*/, '').trim();
      return {key:'t'+t, title: (t==='S' ? 'Tier พิเศษ' : 'Tier '+t) + ' · ' + info[0], en: fileLabel && !/^\(Weapon Tier/.test(fileLabel) ? fileLabel : info[1], note: info[2], items: xs}; }).filter(Boolean).concat((()=>{ const xs = arr.filter(it=>!itemTier(it)); return xs.length ? [{key:'tn', title:'ไม่ระบุ Tier', items:xs}] : []; })()); }
  if (cat==='เสื้อผ้าและหมวก'){ const slotOf = (it)=>{ const s = itemSlot(it.name, it.effect); return WEAR_GROUPS.some(g=>g[0]===s) ? s : 'other'; };
    return WEAR_GROUPS.map(([k, l])=>({key:k, title:l, items: arr.filter(it=>slotOf(it)===k)})).filter(g=>g.items.length); }
  const subs = [...new Set(arr.map(it=>it.sub||''))];
  const byTier = (xs)=> cat==='เกราะส่วนย่อย' ? xs.slice().sort((a, b)=>(itemTierKey(a)).localeCompare(itemTierKey(b)) || (parseInt(a.price)||0) - (parseInt(b.price)||0)) : xs;
  if (subs.length > 1 || (subs[0]||'')) return subs.map((s, i)=>({key:'s'+i, title: s.replace(/^\d+\.\s*/, '') || 'ทั่วไป', note: cat==='เกราะส่วนย่อย' ? 'เรียงจาก Tier ต่ำไปสูง' : '', items: byTier(arr.filter(it=>(it.sub||'')===s))}));
  return [{key:'all', title:'', items:arr}];
}
function renderItemLib(arg){
  const st = Codex.it; if (arg && IT_FAMS.some(f=>f[0]===arg) && arg !== st.fam){ st.fam = arg; st.tier = ''; }
  const root = clear($('#v-items'));
  const all = DATA.items||[];
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'คลังไอเทม'}),
    h('p',{text:`ไอเทม ${all.length} ชิ้นจากไฟล์ Item All และชุดเริ่มต้น ${DATA.sets.sets.length} ชุด แบ่งตามรูปแบบการใช้ อาวุธ โล่ และหมวกเกราะแยกตาม Tier ที่ไฟล์กำหนด กดการ์ดเพื่อดูรายละเอียดเต็ม`}))));
  { const fam = IT_FAMS.find(f=>f[0]===st.fam); const bar = ceDevBar('items', {cat: fam && fam[2] ? fam[2][0] : ''}); if (bar) root.append(bar); } // v1.27: หลังบ้านแก้ไอเทม
  root.append(h('div',{class:'cx-tabs',role:'tablist'}, IT_FAMS.map(([key, th, cats])=>{ const n = cats ? all.filter(it=>cats.includes(it.cat)).length : DATA.sets.sets.length;
    return h('button',{class:'cx-tab'+(st.fam===key && !st.q.trim()?' on':''),role:'tab',dataset:{fam:key},onclick:()=>{ st.tier = ''; st.q = ''; const hs = '#items-'+key; if (location.hash === hs) renderItemLib(key); else location.hash = hs; }}, th, h('span',{class:'n',text:String(n)})); })));
  const q = h('input',{type:'search',placeholder:'ค้นไอเทมทั้งคลัง (ชื่อ คำอธิบาย หรือคุณสมบัติ)',value:st.q,'aria-label':'ค้นไอเทม',style:'min-width:240px;flex:1'});
  const count = h('span',{class:'dim cx-count'});
  const chips = h('div',{class:'cx-filters'});
  const toc = h('aside',{class:'cx-toc card'}); const list = h('div',{class:'cx-list'});
  const tiered = ()=>!st.q.trim() && (st.fam==='weapon' || st.fam==='armor');
  const drawChips = ()=>{ clear(chips); if (!tiered()) return;
    chips.append(h('div',{class:'cx-chiprow'}, h('span',{class:'cx-fl',text:'Tier'}), IT_TIER_FILTER.map(([v, l])=>h('button',{class:'small cx-chip'+(st.tier===v?' on':''),dataset:{tier:v},onclick:()=>{ st.tier = v; drawChips(); draw(); },text:l}))),
      h('p',{class:'dim',style:'font-size:12px;margin:2px 0 0',text: st.fam==='armor' ? 'Tier ของโล่และหมวกเกราะมาจาก Item All · เกราะลำตัวจัดตามตัวอย่างในไฟล์แกน · เกราะส่วนย่อยจัดตามช่วงราคา 1–10, 11–20, 21–30 เกรฟ ป้ายชั้นในหรือชั้นนอกอยู่บนการ์ดเกราะลำตัว สวมทั้งสองชั้นพร้อมกันติด Disadvantage กับ Reflex, AGI (Stealth) และ Acrobatic' : 'Tier ของอาวุธประชิดและระยะไกลมาจาก Item All · อาวุธเทคโนโลยีและอาวุธเวทมนตร์ทุกชิ้นเป็นระดับพิเศษ'})); };
  const draw = ()=>{ clear(toc); clear(list); const k = st.q.trim().toLowerCase();
    if (!k && st.fam==='sets'){ drawSets(toc, list); count.textContent = `${DATA.sets.sets.length} ชุด`; return; }
    const fams = k ? IT_FAMS.filter(f=>f[2]) : IT_FAMS.filter(f=>f[0]===st.fam);
    let total = 0; toc.append(h('h3',{text: k ? 'ผลการค้นหา' : 'สารบัญ'}));
    for (const [, fth, cats] of fams){
      if (k) toc.append(h('div',{class:'cx-toccat',text:fth}));
      const tl = h('ol',{class:'cx-tocl'}); toc.append(tl); let famHits = 0;
      for (const cat of cats){ let arr = all.filter(it=>it.cat===cat);
        if (k) arr = arr.filter(it=>[it.name, it.desc, it.effect, it.sub, it.slot].join(' ').toLowerCase().includes(k));
        else if (tiered() && st.tier) arr = arr.filter(it=>itemTierKey(it)===st.tier);
        if (!arr.length) continue; total += arr.length; famHits += arr.length;
        const sec = h('section',{class:'cx-group',dataset:{cat}});
        sec.append(h('div',{class:'cx-ghead'}, h('h3',null, cat), h('div',{class:'gives'}, tag(`${arr.length} ชิ้น`))));
        for (const g of itemSubgroups(cat, arr)){ if (g.title) sec.append(h('div',{class:'cx-tierhead'}, h('b',{text:g.title}), g.en ? h('span',{class:'dim',text:g.en}) : null, g.note ? h('span',{class:'dim cx-note',text:g.note}) : null));
          sec.append(h('div',{class:'cx-grid'}, g.items.map(cxItemCard))); }
        list.append(sec);
        tl.append(h('li',null, h('button',{class:'linkish',onclick:()=>cxScrollTo(sec)}, cat, h('span',{class:'dim',text:' '+arr.length})))); }
      if (k && !famHits) tl.append(h('li',{class:'dim',style:'font-size:12px',text:'ไม่พบ'})); }
    count.textContent = `${total} ชิ้น`;
    if (!total) list.append(h('div',{class:'card dim',text: k ? `ไม่พบไอเทมที่ตรงกับ "${st.q.trim()}"` : 'ไม่มีไอเทมใน Tier นี้'}));
  };
  q.oninput = ()=>{ st.q = q.value; for (const b of root.querySelectorAll('.cx-tab')) b.classList.toggle('on', !st.q.trim() && b.dataset.fam===st.fam); drawChips(); draw(); };
  root.append(h('div',{class:'cx-bar'}, h('div',{class:'row'}, q, count), chips));
  root.append(h('div',{class:'cx-layout'}, toc, list));
  drawChips(); draw();
}
function cxItemCard(it){ const [th, en] = itemNameSplit(it.name);
  return h('div',{class:'cx-it',tabindex:0,role:'button','aria-label':'ดูรายละเอียด '+th,onclick:()=>itemInfoModal(it, {inLib:true}),onkeydown:(e)=>{ if (e.key==='Enter' || e.key===' '){ e.preventDefault(); itemInfoModal(it, {inLib:true}); } }},
    h('div',{class:'cx-it-h'}, h('b',{class:hueCls(it.name, it.effect).trim(),text:th}), en ? h('span',{class:'dim',text:en}) : null, ceEditBtn('items', it)), // v1.27: ✎ หลังบ้าน
    h('div',{class:'gives'}, itemStatTags(it), ceMark('items', it)),
    it.desc ? h('div',{class:'eff dim cx-clamp',text:it.desc}) : null,
    it.effect ? h('div',{class:'eff cx-clamp'}, T(it.effect)) : null); }
function drawSets(toc, list){
  toc.append(h('h3',{text:'สารบัญ'}));
  const tl = h('ol',{class:'cx-tocl'}); toc.append(tl);
  const common = DATA.sets.common;
  const itemBtn = (x)=>{ const full = (DATA.items||[]).find(it=>it.name===cleanAltName(x.name).replace(/\s*×\s*\d+/, '').trim());
    return h('button',{class:'cx-setit',onclick:()=>itemInfoModal(full || {name: cleanAltName(x.name), effect: x.effect||'', weight: x.weight, price: x.price ? x.price + ' เกรฟ' : ''})}, h('span',{text:x.name}), x.effect ? h('span',{class:'dim',text:' · '+(x.effect.length > 70 ? x.effect.slice(0, 70) + '…' : x.effect)}) : null); };
  const secCommon = h('section',{class:'cx-group'}, h('div',{class:'cx-ghead'}, h('h3',null, 'ชุดยังชีพ', h('span',{class:'en',text:'ทุกตัวละครได้รับ'})), h('div',{class:'gives'}, tag(`${common.items.length} ชิ้น`), common.money ? tag(`เงินติดตัว ${common.money} เกรฟ`,'prop') : null)),
    h('div',{class:'cx-setlist'}, common.items.map(itemBtn)));
  list.append(secCommon); tl.append(h('li',null, h('button',{class:'linkish',onclick:()=>cxScrollTo(secCommon),text:'ชุดยังชีพ'})));
  const grid = h('div',{class:'cx-sets'});
  for (const s of DATA.sets.sets){ const card = h('div',{class:'card cx-set',dataset:{set:s.nameEn}},
      h('h3',null, s.nameTh || s.nameEn, s.nameTh ? h('span',{class:'en',text:s.nameEn}) : null),
      h('div',{class:'gives'}, s.archetype ? tag(s.archetype,'stat') : null, s.total ? tag(`มูลค่า ${s.total} เกรฟ`,'prop') : null, s.totalWeight ? tag(`${s.totalWeight} กก.`) : null),
      s.desc ? h('p',{class:'desc',style:'margin:4px 0 6px'}, s.desc) : null,
      h('div',{class:'cx-setlist'}, (s.items||[]).map(itemBtn)),
      s.outfit ? h('p',{class:'dim',style:'font-size:12px;margin:6px 0 0'}, 'ชุดที่สวม: ', s.outfit) : null);
    grid.append(card); tl.append(h('li',null, h('button',{class:'linkish',onclick:()=>cxScrollTo(card),text:s.nameTh || s.nameEn}))); }
  list.append(h('section',{class:'cx-group'}, h('div',{class:'cx-ghead'}, h('h3',null, 'ชุดเริ่มต้น', h('span',{class:'en',text:'Starter Set'})), h('div',{class:'gives'}, tag(`${DATA.sets.sets.length} ชุด`))), grid));
}
