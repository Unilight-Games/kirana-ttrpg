'use strict';
/* ===== Kirana TTRPG Online — core ===== */
const DATA = JSON.parse(document.getElementById('kirana-data').textContent);
const STATS = ['STR','AGI','VIT','PER','INF','INT'];
const KIN = Object.fromEntries(DATA.kins.map(k => [k.id, k]));
const KNOW = Object.fromEntries(DATA.knowledge.map(k => [k.id, k]));
const SKILL_BY_NAME = Object.fromEntries(DATA.skills.map(s => [s.nameEn, s]));

/* ---- DOM helpers (textContent only: ข้อมูลจาก db ถือว่าไม่น่าไว้ใจเสมอ) ---- */
function h(tag, attrs, ...kids){
  const e = document.createElement(tag);
  if (attrs) for (const [k,v] of Object.entries(attrs)){
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(e.dataset, v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)){
    if (kid == null || kid === false) continue;
    e.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return e;
}
const $ = (sel, root=document) => root.querySelector(sel);
function clear(e){ while (e.firstChild) e.removeChild(e.firstChild); return e; }
/* ล้างแล้ววาดใหม่โดยไม่ให้จอกระชากขึ้นหัวหน้า: คงความสูงเดิมไว้ระหว่างวาด แล้วคืนตำแหน่งเลื่อน (ผู้ใช้เคาะ 9 พ.ย. 2026) */
function clearKeep(e){ if (!e) return e; const y = window.scrollY; const hgt = e.offsetHeight; if (hgt) e.style.minHeight = hgt + 'px'; clear(e); requestAnimationFrame(()=>{ e.style.minHeight = ''; if (Math.abs(window.scrollY - y) > 2) window.scrollTo(0, y); }); return e; }
/* ===== การแสดงผล (v1.8): ขนาด UI ด้วย CSS zoom ที่ body และโหมดสีของชีทตัวละคร (กระดาษ / มืดแบบเดิม) จำไว้ในเบราว์เซอร์ (ผู้ใช้เคาะ 9 พ.ย. 2026) ===== */
const UI = {
  zoom: null, theme: 'paper',
  load(){ try { Object.assign(this, JSON.parse(localStorage.getItem('kirana.ui')||'{}')); } catch(e){} if (!(this.zoom > 0)) this.zoom = window.innerWidth >= 900 ? 1.15 : 1; if (this.theme !== 'dark') this.theme = 'paper'; },
  persist(){ try { localStorage.setItem('kirana.ui', JSON.stringify({zoom:this.zoom, theme:this.theme})); } catch(e){} },
  apply(){ document.body.style.zoom = this.zoom === 1 ? '' : String(this.zoom); document.body.classList.toggle('paper', this.theme==='paper'); document.body.classList.toggle('sheet-dark', this.theme!=='paper'); },
};
UI.load(); UI.apply();
/* ตัวคูณ zoom ปัจจุบัน: พิกัดจากเมาส์/getBoundingClientRect/innerWidth เป็นพิกัดจอ ส่วน style.left/top ของธาตุใน body เป็นพิกัดที่ถูกย่อขยาย ต้องหารด้วยค่านี้ */
function uiZoom(){ const b = document.body; if (!b) return 1; const z = b.currentCSSZoom; if (z > 0) return z; const s = parseFloat(getComputedStyle(b).zoom); return s > 0 ? s : 1; }
function vw(){ return window.innerWidth / uiZoom(); }
function vh(){ return window.innerHeight / uiZoom(); }
function tag(text, cls){ return h('span', {class:'tag' + (cls ? ' ' + cls : ''), text}); }
function signed(n){ return (n > 0 ? '+' : '') + n; }
function uid(){ const a='abcdefghijkmnpqrstuvwxyz23456789'; let s=''; const r=crypto.getRandomValues(new Uint8Array(12)); for (const b of r) s+=a[b%a.length]; return s; }
let toastT=null;
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.remove('hidden'); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.add('hidden'), 3200); }
function modal(content){ const m=$('#modal'); clear(m); if(!content){ m.classList.add('hidden'); return; }
  const box=h('div',{class:'box'}, content, h('div',{class:'row',style:'justify-content:flex-end;margin-top:12px'}, h('button',{onclick:()=>modal(null),text:'ปิด'})));
  m.append(box); m.classList.remove('hidden'); m.onclick=(ev)=>{ if(ev.target===m) modal(null); }; }

/* ---- Dice: 2d6 ตามไฟล์แกน, Advantage/Disadvantage = 3d6 เก็บ 2 ดี/แย่ ---- */
function rollD6(){ return 1 + (crypto.getRandomValues(new Uint8Array(1))[0] % 6); }
function roll2d6(mode='normal'){
  const n = mode === 'normal' ? 2 : 3;
  const dice = Array.from({length:n}, rollD6);
  let kept;
  if (mode === 'adv') kept = [...dice].sort((a,b)=>b-a).slice(0,2);
  else if (mode === 'dis') kept = [...dice].sort((a,b)=>a-b).slice(0,2);
  else kept = dice.slice();
  // mark which indexes were dropped (one die only)
  const keptIdx = [];
  const pool = kept.slice();
  dice.forEach((d,i)=>{ const j = pool.indexOf(d); if (j>=0){ pool.splice(j,1); keptIdx.push(i);} });
  const sum = kept[0]+kept[1];
  const crit = kept[0]===6 && kept[1]===6 ? 'success' : (kept[0]===1 && kept[1]===1 ? 'failure' : null);
  const dbl = kept[0]===kept[1];
  return {dice, kept, keptIdx, sum, crit, double: dbl, mode};
}
/* ===== คำสั่งทอยอิสระ (ผู้ใช้ขอ 9 พ.ย. 2026): "2d6+3" · "3d6 dis" · "1d20" · "4d6kh3 -1" · "dc10" · คำที่เหลือเป็นชื่อการทอย
 * 2d6 และ 3d6 (adv/dis) ใช้กฎของระบบ (คริติคอล [6,6]/[1,1] ออกคู่ Perfect) เต๋าอื่นทอยตรง ๆ แล้วรวม · adv/dis กับเต๋าอื่น = ตัดลูกต่ำสุด/สูงสุดออกหนึ่งลูก */
function parseRollCommand(text){
  let s = String(text||'').trim(); if (!s) s = '2d6';
  s = s.replace(/\s*([+-])\s*(?=\d)/g, '$1'); // "2d6 + 3" → "2d6+3"
  const out = {n:2, sides:6, keep:null, mod:0, mode:'normal', dc:null, label:'', raw:s, kirana:true};
  const rest = []; let diceSeen = false, dcNext = false;
  for (const tk of s.split(/\s+/)){
    const low = tk.toLowerCase();
    const m = low.match(/^(\d*)d(\d+)(?:(kh|kl|h|l)(\d+))?((?:[+-]\d+)*)$/);
    if (m && !diceSeen){ diceSeen = true; out.n = m[1] ? parseInt(m[1],10) : 1; out.sides = parseInt(m[2],10); if (m[3]) out.keep = {type: (m[3]==='kl'||m[3]==='l') ? 'l' : 'h', count: parseInt(m[4],10)}; if (m[5]) for (const mm of m[5].match(/[+-]\d+/g)||[]) out.mod += parseInt(mm,10); continue; }
    if (/^[+-]\d+$/.test(low)){ out.mod += parseInt(low,10); continue; }
    if (/^\d+$/.test(low) && dcNext){ out.dc = parseInt(low,10); dcNext = false; continue; }
    if (/^\d+$/.test(low) && !diceSeen && !rest.length){ out.mod += parseInt(low,10); continue; } // "/r 3" = 2d6+3 แบบเดิม
    if (low==='adv' || low==='advantage' || low==='ได้เปรียบ'){ out.mode = 'adv'; continue; }
    if (low==='dis' || low==='disadvantage' || low==='เสียเปรียบ'){ out.mode = 'dis'; continue; }
    const dm = low.match(/^dc(\d+)$/); if (dm){ out.dc = parseInt(dm[1],10); continue; }
    if (low==='dc'){ dcNext = true; continue; }
    rest.push(tk);
  }
  out.label = rest.join(' ');
  out.n = Math.max(1, Math.min(40, out.n||1)); out.sides = Math.max(2, Math.min(1000, out.sides||6));
  if (out.keep) out.keep.count = Math.max(1, Math.min(out.n, out.keep.count));
  out.kirana = out.sides===6 && !out.keep && (out.n===2 || out.n===3);
  if (out.kirana && out.n===3 && out.mode==='normal') out.mode = 'adv'; // 3d6 เฉย ๆ = Advantage เหมือนเดิม
  out.expr = `${out.n}d${out.sides}${out.keep ? 'k'+out.keep.type+out.keep.count : ''}${out.mod ? signed(out.mod) : ''}${out.mode!=='normal' ? (out.mode==='adv' ? ' Advantage' : ' Disadvantage') : ''}`;
  return out;
}
function rollDiceExpr(p){
  const dice = Array.from({length:p.n}, ()=> 1 + Math.floor(Math.random()*p.sides));
  let keepCount = p.n, type = 'h';
  if (p.keep){ keepCount = p.keep.count; type = p.keep.type; }
  else if (p.mode==='adv' && p.n>1){ keepCount = p.n-1; type = 'h'; }
  else if (p.mode==='dis' && p.n>1){ keepCount = p.n-1; type = 'l'; }
  const kept = [...dice].sort((a,b)=> type==='h' ? b-a : a-b).slice(0, keepCount);
  const keptIdx = []; const pool = kept.slice(); dice.forEach((d,i)=>{ const j = pool.indexOf(d); if (j>=0){ pool.splice(j,1); keptIdx.push(i); } });
  return {dice, kept, keptIdx, sum: kept.reduce((a,b)=>a+b,0), crit:null, double:false, mode: p.keep ? 'normal' : p.mode, sides: p.sides};
}
const ROLL_HELP = [
  ['/r 2d6+3', 'ทอย 2d6 ของระบบ บวก 3 (คริติคอล [6,6] [1,1] และออกคู่ตัดสินตามกฎ)'],
  ['/r 3d6 dis', 'Disadvantage: ทอย 3 ลูกเก็บ 2 ลูกต่ำสุด · "3d6 adv" หรือ "3d6" เฉย ๆ = Advantage'],
  ['/r 2d6 dc 10 ชื่อการทอย', 'ใส่ DC ให้ตัดสินสำเร็จ/ล้มเหลว คำที่เหลือเป็นชื่อการทอย'],
  ['/r 1d20 · /r 4d8+2 · /r 1d100', 'เต๋าอื่นทอยตรง ๆ แล้วรวม (ไม่ใช้กฎคริติคอลของระบบ)'],
  ['/r 4d6kh3 · /r 2d20kl1', 'เก็บลูกสูงสุด (kh) หรือต่ำสุด (kl) ตามจำนวนที่ระบุ'],
  ['/gm r 3d6 dis', 'ทอยลับ: ผลเห็นเฉพาะ GM (ใช้ /gm นำหน้าได้ทุกคำสั่ง รวมข้อความ)'],
  ['/adv · /dis', 'นำหน้าคำสั่งทอยเพื่อบอกโหมด เช่น /dis r 2d6+1'],
];
/* ตัดสินผลเฉพาะเมื่อระบุ DC: ถึง DC = สำเร็จ, [6,6]/[1,1] ตัดสินทันที · ไม่ระบุ DC = ไม่บอกสำเร็จ/ล้มเหลว (อาจเป็นทอย Parry หรือทอยที่ GM ตัดสินเอง) บอกแค่ว่าออกคู่ */
function judge(total, r, dc){
  if (dc != null){
    if (r.crit === 'success') return {cls:'res-crit', text:'Critical Success [6,6] ผ่านทันที'};
    if (r.crit === 'failure') return {cls:'res-crit', text:'Critical Failure [1,1] ล้มเหลวทันที'};
    return total >= dc ? {cls:'res-full', text:`สำเร็จ (ถึง DC ${dc})`} : {cls:'res-fail', text:`ล้มเหลว (DC ${dc})`};
  }
  if (r.double) return {cls:'res-crit', text:`ออกคู่ [${r.kept[0]},${r.kept[1]}]`};
  return {cls:'', text:''};
}
/* ทอยป้องกัน (Parry/Evade): DC = ผลทอยโจมตีของอีกฝ่าย · เท่ากัน = Perfect (ได้ 1 Swift Action ทันที) · ไม่ใส่ DC = ไม่ตัดสิน */
function judgeDefense(total, dc, kind){
  const nm = kind==='parry' ? 'Parry' : 'Evade';
  if (dc == null) return {cls:'', text:''};
  if (total === dc) return {cls:'res-crit', text:`Perfect ${nm} (เท่ากับ ${dc} ได้ 1 Swift Action)`};
  return total > dc ? {cls:'res-full', text:`ป้องกันได้ (${total} > ${dc})`} : {cls:'res-fail', text:`ป้องกันไม่ได้ (${total} < ${dc})`};
}
/* ค่าซื้อด้วย Insight Point (ตารางในไฟล์แกน): Mod ติดลบ→0 ขั้นละ 3 · 0→1 3 · 1→2 4 · 2→3 5 · 3→4 6 · 4→5 7 · Knowledge Level Up 4 / 6 / 9 */
function ipCostStat(mod){ if (mod >= 5) return null; if (mod < 0) return 3; return [3,4,5,6,7][mod]; }
function ipCostKnowledge(level){ if (level >= 3) return null; return [4,6,9][level]; } // ผู้ใช้เคาะ 29 ส.ค. 2026 (บทที่ 13 V.3): Lv1 4 · Lv2 6 · Lv3 9 IP
function renderDice(r){
  return h('span', {class:'inline-roll'}, r.dice.map((d,i)=>h('span',{class:'die' + (r.keptIdx.includes(i)?'':' drop'), text:d})));
}

/* ---- Character model & computation ---- */
/* สำเนาที่ส่งเข้าห้อง: โหมด "full" = ทั้งชีท · โหมด "min" = เฉพาะค่าที่หมากและ GM ต้องใช้ (ชื่อ รูป วงศา HP Sanity สถานะ) */
function roomCopyOf(copy){
  if ((copy.shareMode||'full') !== 'min') return copy;
  const cur = copy.current || {};
  return { id: copy.id, name: copy.name, kin: copy.kin, size: copy.size, portrait: copy.portrait||null, ownerId: copy.ownerId, ownerName: copy.ownerName, shareMode: 'min', done: true, updatedAt: copy.updatedAt,
    current: { hp: cur.hp, mp: cur.mp, sanity: cur.sanity, temp: cur.temp, tough: cur.tough || {} }, armor: copy.armor || {}, details: { appearance: (copy.details||{}).appearance || '', signature: (copy.details||{}).signature || '' } };
}
/* ลบลิงก์ห้องที่ค้าง: ห้องถูกลบ หรือหมากของตัวละครถูกเอาออกไปแล้วขณะเราไม่อยู่ */
/* ถังขยะในเครื่อง: เก็บตัวละครที่ถูกลบ/ถูกตัดออกตามเซิร์ฟเวอร์ไว้ 10 ตัวล่าสุด เผื่อกู้คืน (ผู้พัฒนากู้ได้จากคอนโซล: JSON.parse(localStorage['kirana.chars.trash'])) */
function stashTrash(list){ try { const t = JSON.parse(localStorage.getItem('kirana.chars.trash')||'[]'); for (const c of list) t.unshift({at: Date.now(), char: c}); localStorage.setItem('kirana.chars.trash', JSON.stringify(t.slice(0,10))); } catch(e){} }
/* ถอนหมากของตัวละครออกจากบอร์ดห้อง (เมื่อเจ้าของลบตัวละคร) อ่านห้องแล้วเขียนเฉพาะ tokens/enc */
async function removeTokensOf(rid, charId){
  if (!Store.db) return; const ref = Store.db.doc('rooms/'+rid); const r = docData(await ref.get()); if (!r || !(r.tokens||[]).some(t=>t.charId===charId)) return;
  const ids = r.tokens.filter(t=>t.charId===charId).map(t=>t.id);
  const tokens = r.tokens.filter(t=>t.charId!==charId).map(t=> ids.includes(t.inside) ? Object.assign({}, t, {inside:null}) : t);
  const enc = r.enc ? Object.assign({}, r.enc, {order: (r.enc.order||[]).filter(x=>!ids.includes(x))}) : null;
  const patch = {tokens, updatedAt: Date.now()}; if (enc){ if (enc.turnIdx >= enc.order.length) enc.turnIdx = 0; patch.enc = enc; }
  await ref.update(patch);
}
/* รวมรายการตัวละครจากเซิร์ฟเวอร์เข้ากับของในเครื่อง (เรียกทุกครั้งที่ snapshot มา; แยกเป็นฟังก์ชันให้ทดสอบได้) */
function applyCharsSnapshot(snap){
  const docs = snapDocs(snap);
  let changed=false; const ids = new Set();
  for (const d of docs){ if(!d || !d.id) continue; ids.add(d.id); d.synced = true; const i=Store.chars.findIndex(x=>x.id===d.id); if(i<0){ Store.chars.push(d); changed=true; } else { Store.chars[i].synced = true; if ((d.updatedAt||0) > (Store.chars[i].updatedAt||0)){ Store.chars[i]=d; changed=true; } } }
  // เซิร์ฟเวอร์ยืนยันรายการแล้ว: ตัวละครที่เคยบันทึกขึ้นเว็บ (มี ownerId) แต่ไม่อยู่ในรายการ = ถูกลบจากเครื่องอื่นหรือโดยผู้พัฒนา ต้องหายจากเครื่องนี้ด้วย
  // (เดิมเครื่องที่ยังถือสำเนาจะเซฟกลับขึ้นไปใหม่ ทำให้ดูเหมือนลบไม่ได้) สำเนาเก็บไว้ใน kirana.chars.trash เผื่อกู้
  if (snap && snap.fromCache === false){
    const gone = Store.chars.filter(c => c.ownerId && !ids.has(c.id) && (Store.isDevUid || c.ownerId === Store.me));
    if (gone.length){ stashTrash(gone); Store.chars = Store.chars.filter(c => !gone.includes(c)); changed = true;
      toast(`ซิงก์: ${gone.map(c=>c.name||'ตัวละคร').join(', ')} ถูกลบไปแล้วจากเครื่องอื่น`);
      const m = location.hash.match(/^#sheet-([a-z0-9]+)$/); if (m && gone.some(c=>c.id===m[1])) location.hash = '#chars'; }
  }
  if (changed){ saveLocal(Store.chars); Store.notify(); }
  if (!Store._pruned){ Store._pruned = true; setTimeout(()=>pruneRoomLinks().catch(()=>{}), 1500); }
  return {changed, count: Store.chars.length};
}
async function pruneRoomLinks(){
  if (!Store.db || Store.backend!=='firebase') return;
  const seen = {};
  for (const c of Store.chars){ if (!Store.isMine(c) || !(c.roomIds||[]).length) continue;
    for (const rid of [...c.roomIds]){
      try { if (!(rid in seen)) seen[rid] = docData(await Store.db.doc('rooms/'+rid).get()); } catch(e){ seen[rid] = undefined; }
      const room = seen[rid]; if (room === undefined) continue; // อ่านไม่ได้ (ห้องล็อกและเราไม่ใช่สมาชิก) ปล่อยไว้
      if (!room || !(room.tokens||[]).some(t=>t.charId===c.id)) Store.unshareFromRoom(c, rid);
    }
  }
}
function newChar(){
  return { id: uid(), name:'', kin:null, size:null, childhood:null, adulthood:null, evolver:{kin:null, pick:null, hindrance:null},
    personality:{}, extra:{}, choiceStats:[], talent:null, talentPicks:{}, knowledge:{}, prof:{}, skills:[], grants:[],
    adaptation:null, starterSet:null, details:{likes:'',dislikes:'',fears:'',backstory:'',appearance:'',signature:''},
    current:null, notes:'', createdAt:Date.now(), updatedAt:Date.now(), ownerId:null, step:0 };
}
const modOf = v => Math.max(-5, Math.min(5, Math.floor(v/2) - 5));

function findBg(kin, code){
  if (!kin || !code) return null;
  for (const list of ['childhood','specialChildhood','adulthood','specialAdulthood'])
    for (const b of kin[list]) if (b.code === code) return b;
  return null;
}
function compute(c){
  const kin = c.kin ? KIN[c.kin] : null;
  const raw = Object.fromEntries(STATS.map(s=>[s, kin ? (kin.raw[s]||0) : 0]));
  const from = Object.fromEntries(STATS.map(s=>[s, []]));
  const addStats = (obj, label) => { for (const [k,v] of Object.entries(obj||{})) if (STATS.includes(k)) { raw[k]+=v; from[k].push(`${label} ${signed(v)}`); } };
  const ch = findBg(kin, c.childhood), ad = findBg(kin, c.adulthood);
  if (ch) addStats(ch.stats, 'วัยเด็ก');
  if (ad) addStats(ad.stats, 'วัยผู้ใหญ่');
  for (const s of c.choiceStats||[]) { raw[s]+=1; from[s].push('พื้นหลัง (เลือก) +1'); }
  for (const [k,v] of Object.entries(c.extra||{})) if (v) { raw[k]+=v; from[k].push(`Extra ${signed(v)}`); }
  for (const [k,v] of Object.entries(c.ipStats||{})) if (v) { raw[k]+=v; from[k].push(`IP ${signed(v)}`); }
  const mod = Object.fromEntries(STATS.map(s=>[s, modOf(raw[s])]));
  const extraTotal = kin ? kin.extra : 0;
  const extraUsed = Object.values(c.extra||{}).reduce((a,b)=>a+(b||0),0);
  const size = c.size || (kin ? kin.sizes[0] : 'Medium');
  let capMult = {Small:3, Medium:3, Large:4, Huge:5}[size] || 3;
  let capNote = size==='Small' ? 'Small ใช้ตัวคูณเดียวกับ Medium' : '';
  if (kin && kin.id==='handerlaw-dwarves') { capMult = 4; capNote = 'Powerful Build: นับขนาดใหญ่ขึ้นหนึ่งขั้นเรื่องการแบก จึงใช้ ×4'; }
  const toughSizeBonus = {Large:1, Huge:2}[size] || 0; // ชีท Duck Family (AX2) และกฎ Bestiary: Large +1, Huge +2
  const tough = Math.floor((raw.VIT + raw.STR)/10) + 1 + toughSizeBonus;
  const d = {
    raw, mod, from, extraTotal, extraUsed, extraLeft: extraTotal - extraUsed, size,
    hp: 10 + mod.VIT + mod.STR,
    mp: 10 + mod.INF + mod.INT,
    sanity: 5 + mod.INF,
    toughness: tough, toughSizeBonus,
    passivePer: 7 + mod.PER,
    capacity: raw.STR * capMult, capMult, capNote,
    // ค่าพลังรอง (Ability Stats) ตามตารางค่าสถานะศักยภาพที่ล็อก 9 พ.ย. 2026
    fortitude: mod.VIT, will: mod.PER, reflex: Math.floor(mod.AGI/2)+1, sight: Math.floor(mod.PER/2)+1,
    might: Math.floor(mod.STR/2)+1, initiative: mod.PER, parryDice: Math.max(0, (c.current && c.current.parryBonus) || 0), combatDice: '2d6',
    speed: kin ? kin.speed : '',
    highest: [], knowledgeMods: {},
  };
  const best = Math.max(...STATS.map(s=>mod[s]));
  d.highest = STATS.filter(s=>mod[s]===best);
  for (const k of DATA.knowledge){ const lvl = c.knowledge[k.id]||0; const profs = (c.prof[k.id]||[]).length; d.knowledgeMods[k.id] = {level: lvl, prof: Math.max(lvl, profs)}; }
  return d;
}
function personalityValue(c, axisId){ const p = c.personality[axisId]; if (!p || p.value==null) return null; return p; }
/* คู่บุคลิกภาพ: ฝั่งที่เลือกเป็นบวก ฝั่งตรงข้ามติดลบเท่ากัน */
function persMod(c, side){ // side = 'Logic' etc.
  for (const ax of DATA.meta.personality){
    const p = c.personality[ax.id]; if (!p || p.value==null) continue;
    if (ax.left === side) return p.side==='left' ? p.value : -p.value;
    if (ax.right === side) return p.side==='right' ? p.value : -p.value;
  }
  return 0;
}
function budgetState(c){
  const used = []; for (const ax of DATA.meta.personality){ const p=c.personality[ax.id]; if (p && p.value!=null) used.push(p.value); }
  const pool = DATA.meta.personalityBudget.slice();
  const left = pool.slice(); for (const v of used){ const i=left.indexOf(v); if(i>=0) left.splice(i,1); }
  return {used, left};
}

/* ---- Storage: localStorage เสมอ + db เมื่อมี ---- */
const LS_KEY = 'kirana.chars.v1';
function loadLocal(){ try { return JSON.parse(localStorage.getItem(LS_KEY)||'[]'); } catch(e){ return []; } }
function saveLocal(list){ try { localStorage.setItem(LS_KEY, JSON.stringify(list)); } catch(e){} }
const Store = {
  chars: loadLocal(), db:null, user:null, room:null, me:null, isOwner:false, canWrite:null, online:false, backend:null,
  displayName:'', isDevUid:false, onlineUsers:[],
  listeners: new Set(),
  notify(){ for (const f of this.listeners) try{ f(); }catch(e){ console.error(e);} },
  upsert(c){ c.updatedAt = Date.now(); const i=this.chars.findIndex(x=>x.id===c.id); if(i>=0) this.chars[i]=c; else this.chars.push(c); saveLocal(this.chars); this.notify();
    if (this.db && this.me && this.canWrite!==false){ const copy = JSON.parse(JSON.stringify(c)); copy.ownerId = copy.ownerId || this.me; if (!c.ownerId) c.ownerId = copy.ownerId; copy.ownerName = this.displayName||copy.ownerName||''; this.db.doc('chars/'+c.id).set(copy).then(()=>{ c.synced = true; }).catch(e=>{ console.warn('db set', e); toast('บันทึกตัวละครขึ้นเว็บไม่สำเร็จ ('+(e && e.code || e)+')'); });
      const roomCopy = roomCopyOf(copy); for (const rid of c.roomIds||[]) this.db.doc(`rooms/${rid}/chars/${c.id}`).set(roomCopy).catch(()=>{}); } },
  /* ตัวละครอยู่ในแคมเปญ (ถูกวางลงบอร์ดห้องใดห้องหนึ่ง) → ล็อกไม่ให้กลับไปแก้ในวิซาร์ด */
  inCampaign(c){ return !!(c && (c.roomIds||[]).length); },
  /* แชร์สำเนาชีทเข้าห้อง: GM และผู้เล่นในห้องเห็นได้เฉพาะตัวละครที่ถูกหยิบมาเล่นในแคมเปญนี้ */
  shareToRoom(c, rid){ c.roomIds = [...new Set([...(c.roomIds||[]), rid])]; this.upsert(c); },
  /* ถอนตัวละครออกจากห้อง: เลิกซิงก์และลบสำเนาในห้อง */
  unshareFromRoom(c, rid){ if (!c) return; c.roomIds = (c.roomIds||[]).filter(x=>x!==rid); if (this.isMine(c)) this.upsert(c); if (this.db) this.db.doc(`rooms/${rid}/chars/${c.id}`).delete().catch(()=>{}); },
  /* ลบตัวละคร: ลบในเครื่อง ลบบนเว็บ ลบสำเนาในห้อง และถอนหมากออกจากบอร์ดของห้องที่อยู่ (ล้มเหลวบนเว็บจะบอก ไม่เงียบ) */
  remove(id){ const c = this.get(id); this.chars = this.chars.filter(x=>x.id!==id); saveLocal(this.chars); this.notify(); if (c) stashTrash([c]);
    if (!this.db && typeof loadLocalRooms==='function'){ const rooms = loadLocalRooms(); let touched=false; for (const r of rooms){ if ((r.tokens||[]).some(t=>t.charId===id)){ const ids = r.tokens.filter(t=>t.charId===id).map(t=>t.id); r.tokens = r.tokens.filter(t=>t.charId!==id).map(t=> ids.includes(t.inside) ? Object.assign({}, t, {inside:null}) : t); if (r.enc) r.enc.order = (r.enc.order||[]).filter(x=>!ids.includes(x)); touched=true; } } if (touched){ saveLocalRooms(rooms); if (typeof Table!=='undefined' && Table.room && rooms.some(r=>r.id===Table.room.id)) Table.room = rooms.find(r=>r.id===Table.room.id); } }
    if (this.db){ this.db.doc('chars/'+id).delete().catch(e=>{ console.warn('delete char', e); toast('ลบบนเว็บไม่สำเร็จ ('+(e && e.code || e)+') ตัวละครอาจกลับมาเมื่อซิงก์'); });
      for (const rid of (c&&c.roomIds)||[]){ this.db.doc(`rooms/${rid}/chars/${id}`).delete().catch(()=>{}); removeTokensOf(rid, id).catch(()=>{}); } } },
  get(id){ return this.chars.find(x=>x.id===id) || (typeof Table!=='undefined' && Table.roomChars.find(x=>x.id===id)) || null; },
  isMine(c){ return !c.ownerId || !this.me || c.ownerId===this.me; },
  canEdit(c){ return this.isMine(c) || this.isDevUid; },
};
async function initCapabilities(){
  if (window.claude && window.claude.use){
    try {
      const [db, user, room] = await Promise.all([claude.use('db'), claude.use('user'), claude.use('room')]);
      Store.db = db; Store.user = user; Store.room = room; Store.backend = 'claude';
      if (user){ try { Store.me = await user.id(); } catch(e){} try { Store.isOwner = !!user.isOwner(); } catch(e){} try { Store.canWrite = user.can('data.write'); } catch(e){} }
    } catch(e){ console.warn('capabilities', e); }
  } else if (window.KIRANA_FIREBASE && window.KIRANA_FIREBASE.projectId){
    try { await initFirebase(window.KIRANA_FIREBASE); } catch(e){ console.warn('firebase', e); toast('เชื่อมต่อ Firebase ไม่ได้: ' + (e && e.message ? e.message : e)); }
  }
  if (Store.db){
    Store.online = true;
    // ตัวละครที่แชร์ในโต๊ะเดียวกัน: ทุกคนอ่านได้ (GM ต้องเห็นชีทผู้เล่น)
    try {
      // ตัวละครของฉันเท่านั้น (ผู้พัฒนาเห็นทั้งหมด) — ชีทของคนอื่นเห็นได้ผ่านสำเนาในห้องที่เขาหยิบตัวละครมาเล่น
      const q = (Store.backend==='firebase' && !Store.isDevUid) ? Store.db.collection('chars').where('ownerId','==',Store.me) : Store.db.collection('chars');
      q.onSnapshot(snap => applyCharsSnapshot(snap), err => console.warn('chars snapshot', err));
    } catch(e){ console.warn(e); }
  }
  updateOnline();
}
/* ---- Firebase backend (GitHub Pages): Firestore + Anonymous auth ห่อให้หน้าตาเหมือน db/user/room ของ claude.ai ---- */
async function initFirebase(cfg){
  const V = cfg.sdkVersion || '11.0.1';
  const base = `https://www.gstatic.com/firebasejs/${V}/`;
  const [{initializeApp}, A, F] = await Promise.all([import(base+'firebase-app.js'), import(base+'firebase-auth.js'), import(base+'firebase-firestore.js')]);
  const app = initializeApp(cfg);
  const auth = A.getAuth(app);
  const fdb = F.getFirestore(app);
  FB = {A, F, auth, fdb};
  const plain = o => JSON.parse(JSON.stringify(o)); // Firestore ไม่รับ undefined
  const wrapDoc = snap => ({ exists: snap.exists(), id: snap.id, data: () => snap.data() });
  const docRef = path => { const ref = F.doc(fdb, path); return {
    set: d => F.setDoc(ref, plain(d)), update: d => F.updateDoc(ref, plain(d)), delete: () => F.deleteDoc(ref), get: async () => wrapDoc(await F.getDoc(ref)),
    onSnapshot: (ok, err) => F.onSnapshot(ref, s => ok(wrapDoc(s)), err) }; };
  const coll = (path, cons=[]) => ({
    orderBy: (f, d) => coll(path, [...cons, F.orderBy(f, d||'asc')]), limit: n => coll(path, [...cons, F.limit(n)]), where: (a, op, v) => coll(path, [...cons, F.where(a, op, v)]),
    doc: id => docRef(path + '/' + id),
    get: async () => ({ docs: (await F.getDocs(cons.length ? F.query(F.collection(fdb, path), ...cons) : F.collection(fdb, path))).docs.map(wrapDoc) }),
    onSnapshot: (ok, err) => F.onSnapshot(cons.length ? F.query(F.collection(fdb, path), ...cons) : F.collection(fdb, path), s => ok({ docs: s.docs.map(wrapDoc), fromCache: !!(s.metadata && s.metadata.fromCache), pending: !!(s.metadata && s.metadata.hasPendingWrites) }), err) });
  const db = { doc: docRef, collection: coll };
  // ---- login gate: config/site = {requireLogin, devUids, devIps} ----
  let site = null;
  try { const sn = await F.getDoc(F.doc(fdb, 'config/site')); if (sn.exists()) site = sn.data(); } catch(e){ console.warn('config read', e); }
  Store.site = site;
  const current = await new Promise(res => { const stop = A.onAuthStateChanged(auth, u => { stop(); res(u); }); setTimeout(()=>res(auth.currentUser), 6000); });
  let user = current;
  const needLogin = !!(site && site.requireLogin);
  if (needLogin){
    if (user && !user.isAnonymous) { /* ล็อกอิน Google อยู่แล้ว */ }
    else {
      const ip = await fetchPublicIp();
      Store.ip = ip;
      if (ip && (site.devIps||[]).includes(ip)){
        Store.isDevIp = true;
        if (!user) user = (await A.signInAnonymously(auth)).user;
      } else {
        user = await loginGate(A, auth); // รอจนกว่าจะล็อกอินสำเร็จ
      }
    }
  } else {
    if (!user) user = (await A.signInAnonymously(auth)).user;
  }
  Store.authUser = user;
  Store.db = db;
  Store.user = { id: async () => user.uid, isOwner: () => false, canEdit: () => false, can: () => true };
  Store.me = user.uid; Store.canWrite = true; Store.backend = 'firebase';
  Store.isDevUid = !!(site && (site.devUids||[]).includes(user.uid));
  Store.isDev = Store.isDevUid || Store.isDevIp;
  Store.displayName = user.isAnonymous ? (localStorage.getItem('kirana.nick') || 'ผู้เล่น-' + user.uid.slice(0,4)) : (user.displayName || (user.email||'').split('@')[0] || 'ผู้เล่น');
  // แคชในเครื่องอาจมีตัวละครของคนอื่นจากรุ่นก่อน (ตอนนั้นทุกคนเห็นทุกตัว) เก็บเฉพาะของฉัน
  if (!Store.isDevUid) { Store.chars = Store.chars.filter(c => !c.ownerId || c.ownerId === user.uid); saveLocal(Store.chars); }
  startSitePresence(F, fdb, user);
  Store.login = async () => { try { const prov = new A.GoogleAuthProvider(); prov.setCustomParameters({prompt:'select_account'}); if (auth.currentUser && auth.currentUser.isAnonymous){ try { await A.linkWithPopup(auth.currentUser, prov); } catch(e){ if (e && /credential-already-in-use|email-already-in-use/.test(e.code||'')) await A.signInWithPopup(auth, prov); else throw e; } } else await A.signInWithPopup(auth, prov); location.reload(); } catch(e){ toast('ล็อกอินไม่สำเร็จ: ' + (e && e.code || e)); } };
  Store.logout = async () => { try { await F.deleteDoc(F.doc(fdb, 'presence/' + user.uid)); } catch(e){} try { await A.signOut(auth); } catch(e){} try { localStorage.removeItem(LS_KEY); } catch(e){} location.reload(); };
  // presence ผ่าน Firestore: rooms/<id>/presence/<uid> อัปเดตทุก 40 วิ ถือว่าออนไลน์ถ้าไม่เกิน 100 วิ
  Store.room = { join: async (name) => {
    const path = 'rooms/' + name.replace(/^kirana-/, '') + '/presence';
    let state = {}; let timer = null; let unsub = null;
    const push = () => F.setDoc(F.doc(fdb, path + '/' + user.uid), plain({ ...state, at: Date.now() })).catch(()=>{});
    return {
      presence: (patch) => { state = { ...state, ...patch }; push(); if (!timer) timer = setInterval(push, 40000); },
      onPeers: (fn) => { unsub = F.onSnapshot(F.collection(fdb, path), s => { const now = Date.now(); fn(s.docs.map(d => d.data()).filter(p => p && (now - (p.at||0)) < 100000)); }, ()=>{}); },
      leave: () => { if (timer) clearInterval(timer); if (unsub) unsub(); F.deleteDoc(F.doc(fdb, path + '/' + user.uid)).catch(()=>{}); },
      emit: () => {}, on: () => {} };
  } };
}
let FB = null;
/* ---- ผู้เล่นที่ออนไลน์ทั้งเว็บ: presence/<uid> อัปเดตทุก 40 วิ (ถือว่าออนไลน์ถ้าไม่เกิน 100 วิ) ---- */
function startSitePresence(F, fdb, user){
  const plain = o => JSON.parse(JSON.stringify(o));
  const push = () => F.setDoc(F.doc(fdb, 'presence/' + user.uid), plain({ uid: user.uid, name: Store.displayName, anon: !!user.isAnonymous, dev: !!Store.isDevUid, room: (typeof Table!=='undefined' && Table.roomId) || null, roomName: (typeof Table!=='undefined' && Table.room && Table.room.name) || '', at: Date.now() })).catch(()=>{});
  push(); setInterval(push, 40000); window.addEventListener('hashchange', ()=>setTimeout(push, 800));
  window.addEventListener('beforeunload', ()=>{ try { F.deleteDoc(F.doc(fdb, 'presence/' + user.uid)); } catch(e){} });
  try { F.onSnapshot(F.collection(fdb, 'presence'), s => { const now = Date.now(); Store.onlineUsers = s.docs.map(d=>d.data()).filter(p => p && (now - (p.at||0)) < 100000).sort((a,b)=>(a.name||'').localeCompare(b.name||'')); updateOnline(); }, ()=>{}); } catch(e){}
  setInterval(updateOnline, 30000);
}
async function fetchPublicIp(){
  try { const r = await fetch('https://api.ipify.org?format=json', {cache:'no-store'}); const j = await r.json(); return j.ip || null; } catch(e){ return null; }
}
function snapDocs(snap){
  if (!snap) return [];
  if (Array.isArray(snap)) return snap.map(x => x && x.data ? (typeof x.data==='function' ? x.data() : x.data) : x);
  if (snap.docs) return snap.docs.map(x => x && typeof x.data==='function' ? x.data() : (x.data||x));
  if (typeof snap.forEach==='function'){ const out=[]; snap.forEach(x=>out.push(typeof x.data==='function'?x.data():(x.data||x))); return out; }
  return [];
}
function docData(d){ if(!d) return null; if (typeof d.data==='function') return d.exists===false ? null : d.data(); return d.data||d; }
function updateOnline(){
  const o = $('#online'); if (!o) return; clear(o);
  const dot = h('span', {class:'dot' + (Store.online ? ' on' : '')});
  if (!Store.online){ o.append(dot, 'โหมดออฟไลน์ (บันทึกในเครื่องนี้)'); return; }
  if (Store.backend !== 'firebase'){ o.append(dot, Store.canWrite===false ? 'ออนไลน์แบบอ่านอย่างเดียว' : 'ออนไลน์: ซิงก์ผ่านเว็บ'); return; }
  const u = Store.authUser; const anon = !u || u.isAnonymous;
  const n = Store.onlineUsers.length;
  const who = h('button',{class:'small ghost onl',title:'ผู้เล่นที่ออนไลน์อยู่ตอนนี้',onclick:(e)=>{ e.stopPropagation(); showOnlineList(who); }}, dot, ` ออนไลน์ ${n} คน`);
  o.append(who);
  o.append(h('span',{class:'acct',text: anon ? (Store.isDevIp ? 'เครื่องผู้พัฒนา (นิรนาม)' : 'ผู้เล่นนิรนาม') : (Store.displayName + (Store.isDevUid ? ' · ผู้พัฒนา' : ''))}));
  if (anon) o.append(h('button',{class:'small primary',onclick:()=>Store.login(),text:'เข้าสู่ระบบ Google'}));
  else o.append(h('button',{class:'small ghost',onclick:()=>{ if (confirm('ออกจากระบบ? ตัวละครในแคชเครื่องนี้จะถูกล้าง (ยังอยู่บนเว็บ ล็อกอินใหม่ก็กลับมา)')) Store.logout(); },text:'ออกจากระบบ'}));
}
let onlPop = null;
function showOnlineList(anchor){
  if (onlPop){ onlPop.remove(); onlPop=null; return; }
  const list = Store.onlineUsers;
  onlPop = h('div',{class:'pop onl-pop',role:'dialog'}, h('div',{class:'pop-h'}, h('b',{text:`ออนไลน์ ${list.length} คน`}), h('button',{class:'small ghost',style:'margin-left:auto',onclick:()=>{ onlPop.remove(); onlPop=null; },text:'✕'})),
    h('div',{class:'pop-b'}, list.length ? list.map(p=>h('div',{class:'onl-row'}, h('span',{class:'dot on'}), h('b',{text:p.name||'?'}), p.dev? tag('ผู้พัฒนา','prop'):null, p.anon? tag('นิรนาม'):null, p.room? h('a',{href:'#room-'+p.room,class:'dim',style:'font-size:12px',text:' อยู่ในห้อง '+(p.roomName||p.room)}):null)) : h('div',{class:'dim',text:'ไม่มีใครออนไลน์'})));
  document.body.append(onlPop);
  const r = anchor.getBoundingClientRect(); const z = uiZoom(); onlPop.style.width='300px'; onlPop.style.right='12px'; onlPop.style.top=((r.bottom+8+window.scrollY)/z)+'px';
  setTimeout(()=>document.addEventListener('click', function once(e){ if (onlPop && !onlPop.contains(e.target)){ onlPop.remove(); onlPop=null; } document.removeEventListener('click', once); }), 0);
}
