'use strict';
/* ===== Kirana TTRPG Online — core ===== */
const DATA = JSON.parse(document.getElementById('kirana-data').textContent);
const STATS = ['STR','AGI','VIT','PER','INF','INT'];
const KIN = Object.fromEntries(DATA.kins.map(k => [k.id, k]));
const KNOW = Object.fromEntries(DATA.knowledge.map(k => [k.id, k]));
const SKILL_BY_NAME = Object.fromEntries(DATA.skills.map(s => [s.nameEn, s]));
/* ===== v1.16 (ผู้ใช้สั่ง 12 พ.ย. 2026): ชื่อไทยขึ้นก่อน ตามด้วยชื่ออังกฤษ =====
 * ตัวละครยังเก็บทักษะด้วยชื่ออังกฤษ (คีย์เดิม) จึงเปลี่ยนเฉพาะการแสดงผล · ชื่อไอเทมเปลี่ยนที่ไฟล์กฎ แล้วย้ายชื่อเก่าในตัวละครด้วย migrateNames
 * SKILL_ALIAS = คีย์เก่าของทักษะที่เคยอัดสองภาษาไว้ในชื่ออังกฤษ ชี้ไปคีย์ใหม่ */
const SKILL_ALIAS = (DATA.meta && DATA.meta.skillAliases) || {};
for (const [o, n] of Object.entries(SKILL_ALIAS)) if (SKILL_BY_NAME[n] && !SKILL_BY_NAME[o]) SKILL_BY_NAME[o] = SKILL_BY_NAME[n];
function skOf(x){ return x && typeof x === 'object' ? x : (typeof x === 'string' && Object.prototype.hasOwnProperty.call(SKILL_BY_NAME, x) ? SKILL_BY_NAME[x] : null); }
function skTh(x){ const sk = skOf(x); return sk ? (sk.nameTh || sk.nameEn) : String(x == null ? '' : x); }   // ชื่อหลัก (ไทย)
function skEn(x){ const sk = skOf(x); return sk && sk.nameTh ? sk.nameEn : ''; }                               // ชื่อรอง (อังกฤษ) ว่างเมื่อไม่มีชื่อไทย
function skLabel(x){ const sk = skOf(x); if (!sk) return String(x == null ? '' : x); return sk.nameTh ? `${sk.nameTh} (${sk.nameEn})` : sk.nameEn; }
function knLabel(k){ k = typeof k === 'string' ? KNOW[k] : k; return k ? (k.nameTh ? `${k.nameTh} (${k.nameEn})` : k.nameEn) : ''; }

/* ---- DOM helpers (textContent only: ข้อมูลจาก db ถือว่าไม่น่าไว้ใจเสมอ) ---- */
function h(tag, attrs, ...kids){
  const e = document.createElement(tag);
  if (attrs) for (const [k,v] of Object.entries(attrs)){
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(e.dataset, v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)){
    if (kid == null || kid === false) continue;
    e.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return e;
}
const $ = (sel, root=document) => root.querySelector(sel);
function clear(e){ while (e.firstChild) e.removeChild(e.firstChild); return e; }
/* ล้างแล้ววาดใหม่โดยไม่ให้จอกระชากขึ้นหัวหน้า: คงความสูงเดิมไว้ระหว่างวาด แล้วคืนตำแหน่งเลื่อน (ผู้ใช้เคาะ 9 พ.ย. 2026) */
function clearKeep(e){ if (!e) return e; const y = window.scrollY; const hgt = e.offsetHeight; if (hgt) e.style.minHeight = hgt + 'px'; clear(e); requestAnimationFrame(()=>{ e.style.minHeight = ''; if (Math.abs(window.scrollY - y) > 2) window.scrollTo(0, y); }); return e; }
/* ===== การแสดงผล (v1.8): ขนาด UI ด้วย CSS zoom ที่ body และโหมดสีของชีทตัวละคร (กระดาษ / มืดแบบเดิม) จำไว้ในเบราว์เซอร์ (ผู้ใช้เคาะ 9 พ.ย. 2026) ===== */
const UI = {
  zoom: null, theme: 'paper',
  load(){ try { Object.assign(this, JSON.parse(localStorage.getItem('kirana.ui')||'{}')); } catch(e){} if (!(this.zoom > 0)) this.zoom = window.innerWidth >= 900 ? 1.15 : 1; if (this.theme !== 'dark') this.theme = 'paper'; },
  persist(){ try { localStorage.setItem('kirana.ui', JSON.stringify({zoom:this.zoom, theme:this.theme})); } catch(e){} },
  apply(){ document.body.style.zoom = this.zoom === 1 ? '' : String(this.zoom); document.body.classList.toggle('paper', this.theme==='paper'); document.body.classList.toggle('sheet-dark', this.theme!=='paper'); },
};
UI.load(); UI.apply();
/* ตัวคูณ zoom ปัจจุบัน: พิกัดจากเมาส์/getBoundingClientRect/innerWidth เป็นพิกัดจอ ส่วน style.left/top ของธาตุใน body เป็นพิกัดที่ถูกย่อขยาย ต้องหารด้วยค่านี้ */
function uiZoom(){ const b = document.body; if (!b) return 1; const z = b.currentCSSZoom; if (z > 0) return z; const s = parseFloat(getComputedStyle(b).zoom); return s > 0 ? s : 1; }
function vw(){ return window.innerWidth / uiZoom(); }
function vh(){ return window.innerHeight / uiZoom(); }
function tag(text, cls){ return h('span', {class:'tag' + (cls ? ' ' + cls : ''), text}); }
function signed(n){ return (n > 0 ? '+' : '') + n; }
function uid(){ const a='abcdefghijkmnpqrstuvwxyz23456789'; let s=''; const r=crypto.getRandomValues(new Uint8Array(12)); for (const b of r) s+=a[b%a.length]; return s; }
let toastT=null;
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.remove('hidden'); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.add('hidden'), 3200); }
function modal(content){ const m=$('#modal'); clear(m); if(!content){ m.classList.add('hidden'); return; }
  const box=h('div',{class:'box'}, content, h('div',{class:'row',style:'justify-content:flex-end;margin-top:12px'}, h('button',{onclick:()=>modal(null),text:'ปิด'})));
  m.append(box); m.classList.remove('hidden'); m.onclick=(ev)=>{ if(ev.target===m) modal(null); }; }

/* ---- Dice: 2d6 ตามไฟล์แกน, Advantage/Disadvantage = 3d6 เก็บ 2 ดี/แย่ ---- */
function rollD6(){ return 1 + (crypto.getRandomValues(new Uint8Array(1))[0] % 6); }
function roll2d6(mode='normal'){
  const n = mode === 'normal' ? 2 : 3;
  const dice = Array.from({length:n}, rollD6);
  let kept;
  if (mode === 'adv') kept = [...dice].sort((a,b)=>b-a).slice(0,2);
  else if (mode === 'dis') kept = [...dice].sort((a,b)=>a-b).slice(0,2);
  else kept = dice.slice();
  // mark which indexes were dropped (one die only)
  const keptIdx = [];
  const pool = kept.slice();
  dice.forEach((d,i)=>{ const j = pool.indexOf(d); if (j>=0){ pool.splice(j,1); keptIdx.push(i);} });
  const sum = kept[0]+kept[1];
  const crit = kept[0]===6 && kept[1]===6 ? 'success' : (kept[0]===1 && kept[1]===1 ? 'failure' : null);
  const dbl = kept[0]===kept[1];
  return {dice, kept, keptIdx, sum, crit, double: dbl, mode};
}
/* ===== คำสั่งทอยอิสระ (ผู้ใช้ขอ 9 พ.ย. 2026): "2d6+3" · "3d6 dis" · "1d20" · "4d6kh3 -1" · "dc10" · คำที่เหลือเป็นชื่อการทอย
 * 2d6 และ 3d6 (adv/dis) ใช้กฎของระบบ (คริติคอล [6,6]/[1,1] ออกคู่ Perfect) เต๋าอื่นทอยตรง ๆ แล้วรวม · adv/dis กับเต๋าอื่น = ตัดลูกต่ำสุด/สูงสุดออกหนึ่งลูก */
const ROLL_KIND_WORDS = {attack:'attack', atk:'attack', 'โจมตี':'attack', parry:'parry', 'ปัด':'parry', 'พาร์รี่':'parry', evade:'evade', 'หลบ':'evade'};
const ROLL_LOC_WORDS = {head:'head', 'หัว':'head', 'ศีรษะ':'head', torso:'torso', 'ลำตัว':'torso', armr:'armR', 'แขนขวา':'armR', arml:'armL', 'แขนซ้าย':'armL', legr:'legR', 'ขาขวา':'legR', legl:'legL', 'ขาซ้าย':'legL'};
function parseRollCommand(text){
  let s = String(text||'').trim(); if (!s) s = '2d6';
  s = s.replace(/([+-])\s+(?=\d)/g, '$1'); // "2d6 + 3" → "2d6 +3" (ติดเครื่องหมายเข้ากับตัวเลข แต่ไม่ดึงไปติดคำข้างหน้า ไม่งั้น "attack +1" หรือ "evade +2" จะกลายเป็นคำเดียวและอ่านชนิดการทอยไม่ออก)
  const out = {n:2, sides:6, keep:null, mod:0, mode:'normal', dc:null, label:'', raw:s, kirana:true, kind:null, diceGiven:false, cv:null, cvMod:0, loc:null};
  const rest = []; let diceSeen = false, dcNext = false, cvNext = false;
  const toks = s.split(/\s+/); const combat = toks.some(t=>ROLL_KIND_WORDS[t.toLowerCase()]); // คำสั่งโจมตี/ป้องกันเท่านั้นที่อ่าน cv และชื่อตำแหน่ง
  for (const tk of toks){
    const low = tk.toLowerCase();
    const m = low.match(/^(\d*)d(\d+)(?:(kh|kl|h|l)(\d+))?((?:[+-]\d+)*)$/);
    if (m && !diceSeen){ diceSeen = true; out.diceGiven = true; out.n = m[1] ? parseInt(m[1],10) : 1; out.sides = parseInt(m[2],10); if (m[3]) out.keep = {type: (m[3]==='kl'||m[3]==='l') ? 'l' : 'h', count: parseInt(m[4],10)}; if (m[5]) for (const mm of m[5].match(/[+-]\d+/g)||[]) out.mod += parseInt(mm,10); continue; }
    if (combat && cvNext && /^[+-]\d+$/.test(low)){ out.cvMod += parseInt(low,10); cvNext = false; continue; }
    if (combat && cvNext && /^\d+$/.test(low)){ out.cv = parseInt(low,10); cvNext = false; continue; }
    if (combat){ const cm = low.match(/^cv([+-]\d+)$/); if (cm){ out.cvMod += parseInt(cm[1],10); continue; } const cm2 = low.match(/^cv(\d+)$/); if (cm2){ out.cv = parseInt(cm2[1],10); continue; } if (low==='cv'){ cvNext = true; continue; } if (ROLL_LOC_WORDS[low]){ out.loc = ROLL_LOC_WORDS[low]; continue; } }
    if (/^[+-]\d+$/.test(low)){ out.mod += parseInt(low,10); continue; }
    if (/^\d+$/.test(low) && dcNext){ out.dc = parseInt(low,10); dcNext = false; continue; }
    if (/^\d+$/.test(low) && out.kind && !diceSeen){ out.n = parseInt(low,10); out.diceGiven = true; diceSeen = true; continue; } // "parry 4" = ทอย 4 ลูกเลือก 2
    if (/^\d+$/.test(low) && !diceSeen && !rest.length){ out.mod += parseInt(low,10); continue; } // "/r 3" = 2d6+3 แบบเดิม
    if (ROLL_KIND_WORDS[low]){ out.kind = ROLL_KIND_WORDS[low]; continue; }
    if (low==='adv' || low==='advantage' || low==='ได้เปรียบ'){ out.mode = 'adv'; continue; }
    if (low==='dis' || low==='disadvantage' || low==='เสียเปรียบ'){ out.mode = 'dis'; continue; }
    const dm = low.match(/^dc(\d+)$/); if (dm){ out.dc = parseInt(dm[1],10); continue; }
    if (low==='dc'){ dcNext = true; continue; }
    rest.push(tk);
  }
  out.label = rest.join(' ');
  out.n = Math.max(1, Math.min(40, out.n||1)); out.sides = Math.max(2, Math.min(1000, out.sides||6));
  if (out.keep) out.keep.count = Math.max(1, Math.min(out.n, out.keep.count));
  if (out.kind){ out.sides = 6; out.keep = null; out.kirana = true; } // Attack/Parry/Evade ใช้ d6 ของระบบเสมอ (ทอยหลายลูกแล้วเลือก 2)
  else out.kirana = out.sides===6 && !out.keep && (out.n===2 || out.n===3);
  if (out.kirana && !out.kind && out.n===3 && out.mode==='normal') out.mode = 'adv'; // 3d6 เฉย ๆ = Advantage เหมือนเดิม
  out.expr = `${out.n}d${out.sides}${out.keep ? 'k'+out.keep.type+out.keep.count : ''}${out.mod ? signed(out.mod) : ''}${out.mode!=='normal' ? (out.mode==='adv' ? ' Advantage' : ' Disadvantage') : ''}`;
  return out;
}
function rollDiceExpr(p){
  const dice = Array.from({length:p.n}, ()=> 1 + Math.floor(Math.random()*p.sides));
  let keepCount = p.n, type = 'h';
  if (p.keep){ keepCount = p.keep.count; type = p.keep.type; }
  else if (p.mode==='adv' && p.n>1){ keepCount = p.n-1; type = 'h'; }
  else if (p.mode==='dis' && p.n>1){ keepCount = p.n-1; type = 'l'; }
  const kept = [...dice].sort((a,b)=> type==='h' ? b-a : a-b).slice(0, keepCount);
  const keptIdx = []; const pool = kept.slice(); dice.forEach((d,i)=>{ const j = pool.indexOf(d); if (j>=0){ pool.splice(j,1); keptIdx.push(i); } });
  return {dice, kept, keptIdx, sum: kept.reduce((a,b)=>a+b,0), crit:null, double:false, mode: p.keep ? 'normal' : p.mode, sides: p.sides};
}
const ROLL_HELP = [
  ['/r 2d6+3', 'ทอย 2d6 ของระบบ บวก 3 (คริติคอล [6,6] [1,1] และออกคู่ตัดสินตามกฎ)'],
  ['/r 3d6 dis', 'Disadvantage: ทอย 3 ลูกเก็บ 2 ลูกต่ำสุด · "3d6 adv" หรือ "3d6" เฉย ๆ = Advantage'],
  ['/r 2d6 dc 10 ชื่อการทอย', 'ใส่ DC ให้ตัดสินสำเร็จ/ล้มเหลว คำที่เหลือเป็นชื่อการทอย'],
  ['/r 1d20 · /r 4d8+2 · /r 1d100', 'เต๋าอื่นทอยตรง ๆ แล้วรวม (ไม่ใช้กฎคริติคอลของระบบ)'],
  ['/r 4d6kh3 · /r 2d20kl1', 'เก็บลูกสูงสุด (kh) หรือต่ำสุด (kl) ตามจำนวนที่ระบุ'],
  ['/r attack · /adv r attack · /r attack cv+2 หัว', 'โจมตี: ผลรวมเต๋า 2 ลูกคือ CV และบอกตำแหน่ง · Advantage ทอยเพิ่ม 1 ลูกแล้วผู้โจมตีเลือกเอง 2 ลูก · "attack 3" = Combat Dice 3 ลูก · "cv+2" = ตัวปรับ CV (ไม่ขยับตำแหน่ง) · ใส่ชื่อตำแหน่ง = เล็งด้วย Focus (Precise)'],
  ['/dis r attack', 'โจมตีแบบ Disadvantage: ทอยเพิ่ม 1 ลูกแล้วฝ่ายรับ (หรือ GM) กดเลือก 2 ลูกให้จากข้อความในแชต'],
  ['/r parry · /r parry dc 9', 'Parry: ทอย 2 + Parry Dice ของตัวละครที่เลือก (Advantage +1 ลูก สูงสุด 4 ลูก) เลือกเอง 2 ลูก · dc = ผลโจมตีของอีกฝ่าย กันได้เมื่อผลรวมอยู่กลุ่มเดียวกับตำแหน่งที่โดน เช่น โดน 9 (ขาขวา) กันด้วย 9 หรือ 4 · เท่ากันพอดี = Perfect Parry'],
  ['/dis r parry dc 9', 'Parry ที่ติด Disadvantage: ทอย 2d6 เปล่า ไม่ได้ Parry Dice และต้องได้เท่าผลโจมตีพอดีเท่านั้น'],
  ['/r parry 4 dc 9 · /parry 4', 'ระบุจำนวนลูกเอง (เช่น NPC ถือโล่) ทอย 4 ลูกเลือก 2 แล้วเทียบกับผลโจมตี 9'],
  ['/r evade · /r evade adv dc 9', 'Evade: 2d6 + Reflex ของตัวละครที่เลือก ถึงผลโจมตี = หลบได้ เต๋าสองลูกเท่าผลรวมเต๋าโจมตี = Perfect Evade (หลบได้เสมอ) · Advantage = 3d6 เลือกเอง 2 ลูก'],
  ['/r evade dc 7 cv 9 · /r parry dc 7 หัว', 'ผู้โจมตีมีตัวปรับ CV: dc = ผลรวมเต๋าของผู้โจมตี (ดูตำแหน่งกับ Perfect) ส่วน cv = CV หลังบวก (ใช้ตัดสิน Evade) · ใส่ชื่อตำแหน่งเมื่อผู้โจมตีเล็งด้วย Focus (Precise)'],
  ['/gm r 3d6 dis', 'ทอยลับ: ผลเห็นเฉพาะ GM (ใช้ /gm นำหน้าได้ทุกคำสั่ง รวมข้อความ)'],
  ['/adv · /dis', 'นำหน้าคำสั่งทอยเพื่อบอกโหมด เช่น /dis r 2d6+1'],
];
/* ตัดสินผลเฉพาะเมื่อระบุ DC: ถึง DC = สำเร็จ, [6,6]/[1,1] ตัดสินทันที · ไม่ระบุ DC = ไม่บอกสำเร็จ/ล้มเหลว (อาจเป็นทอย Parry หรือทอยที่ GM ตัดสินเอง) บอกแค่ว่าออกคู่ */
function judge(total, r, dc){
  if (dc != null){
    if (r.crit === 'success') return {cls:'res-crit', text:'Critical Success [6,6] ผ่านทันที'};
    if (r.crit === 'failure') return {cls:'res-crit', text:'Critical Failure [1,1] ล้มเหลวทันที'};
    return total >= dc ? {cls:'res-full', text:`สำเร็จ (ถึง DC ${dc})`} : {cls:'res-fail', text:`ล้มเหลว (DC ${dc})`};
  }
  if (r.double) return {cls:'res-crit', text:`ออกคู่ [${r.kept[0]},${r.kept[1]}]`};
  return {cls:'', text:''};
}
/* ===== Hit Location (ผู้ใช้เคาะ 10 พ.ย. 2026): ผลรวมเต๋าโจมตี 2 ลูกชี้ตำแหน่งตรง ๆ ไม่ทอย 1d6 ซ้ำ
 * โจมตี (ผู้ใช้เคาะ 11 พ.ย. 2026 สลับซีกซ้าย): หัว 2,3,11,12 · แขนขวา 4 · ขาขวา 9 · แขนซ้าย 10 · ขาซ้าย 5 · ลำตัว 6,7,8 (แขนเลขคู่ รับ Perfect Strike ได้ ขาเลขคี่)
 * ป้องกัน (Parry): แขนกับขาข้างเดียวกันใช้เลขร่วมกัน ขวา 4,9 · ซ้าย 5,10 (ไฟล์แกน: เลขที่ทอยอยู่กลุ่มเดียวกับตำแหน่งที่ถูกโจมตี = Parry สำเร็จ) */
const HIT_ATTACK = DATA.meta.hitAttack || {head:[2,3,11,12], armR:[4], legR:[9], armL:[10], legL:[5], torso:[6,7,8]};
const HIT_DEFEND = DATA.meta.hitDefend || {head:[2,3,11,12], armR:[4,9], legR:[9,4], armL:[10,5], legL:[5,10], torso:[6,7,8]};
const HIT_BY_SUM = {}; for (const [k, nums] of Object.entries(HIT_ATTACK)) for (const n of nums) HIT_BY_SUM[n] = k;
function hitPart(sum){ return HIT_BY_SUM[sum] || null; }
function partLabel(k){ const p = DATA.meta.bodyParts.find(x=>x[0]===k); return p ? p[1] : (k||''); }
function hitText(sum){ const k = hitPart(sum); return k ? partLabel(k) : ''; }
const HIT_ORDER = ['head','armR','legR','armL','legL','torso'];
/* ข้อความสรุปตารางตำแหน่ง เช่น "ศีรษะ 2,3,11,12 · แขนขวา 4 · …" (tbl = HIT_ATTACK หรือ HIT_DEFEND) */
function hitListText(tbl){ return HIT_ORDER.filter(k=>tbl[k]).map(k=>`${partLabel(k)} ${tbl[k].join(',')}`).join(' · '); }
/* เลขที่ใช้ Parry การโจมตีที่ออกผลรวมนี้ได้ (กลุ่มเดียวกับตำแหน่งที่โดน) */
function parryNumbers(attackSum){ const k = hitPart(attackSum); return k ? HIT_DEFEND[k].slice() : []; }
/* ทอยป้องกัน (Parry/Evade): DC = ผลทอยโจมตีของอีกฝ่าย (ผลรวมเต๋า 2 ลูก) · ไม่ใส่ DC = ไม่ตัดสิน
 * Parry: ผลรวมเต๋า 2 ลูกที่เลือกอยู่กลุ่มเดียวกับตำแหน่งที่ถูกโจมตี = สำเร็จ · เท่ากับผลโจมตีพอดี = Perfect Parry · ติด Disadvantage ต้อง Perfect เท่านั้น
 * Evade: 2d6 + Reflex สูงกว่าหรือเท่ากับผลโจมตี = สำเร็จ · ผลรวมเต๋า 2 ลูก (ก่อนบวก) เท่ากับผลโจมตี = Perfect Evade
 * Perfect ได้ 1 Swift Action ทันที · o.sum = ผลรวมเต๋า 2 ลูกที่ใช้ (ไม่รวมตัวบวก) · o.dis = Parry ที่ติด Disadvantage */
function judgeDefense(total, dc, kind, o){
  o = o || {};
  if (dc == null) return {cls:'', text:''};
  const sum = o.sum != null ? o.sum : total;
  const cv = o.cv != null ? o.cv : dc;                                  // CV หลังบวกตัวปรับ (ไม่ใส่ = เท่าผลรวมเต๋า)
  const part = (o.loc && HIT_DEFEND[o.loc]) ? o.loc : hitPart(dc);       // เล็งด้วย Focus (Precise) = ใช้ตำแหน่งที่ประกาศ
  if (kind === 'parry'){
    if (!part) return sum === dc ? {cls:'res-crit', text:`Perfect Parry (เท่ากับ ${dc} ได้ 1 Swift Action)`} : {cls:'', text:''}; // ผลโจมตีนอกช่วง 2-12 ไม่มีตำแหน่งให้เทียบ
    const nums = HIT_DEFEND[part], where = partLabel(part);
    if (sum === dc) return {cls:'res-crit', text:`Perfect Parry (${sum} เท่ากับผลโจมตี ได้ 1 Swift Action)`};
    if (o.dis) return {cls:'res-fail', text:`Parry ไม่สำเร็จ (Disadvantage ต้องได้ ${dc} พอดี) โดน${where}`};
    return nums.includes(sum) ? {cls:'res-full', text:`Parry สำเร็จ (${sum} อยู่กลุ่มเดียวกับ${where}: ${nums.join(', ')})`} : {cls:'res-fail', text:`Parry ไม่สำเร็จ (${where}ต้องได้ ${nums.join(' หรือ ')}) โดน${where}`};
  }
  // Perfect Evade เทียบหน้าเต๋า 2 ลูกของทั้งสองฝ่าย และนับว่าหลบสำเร็จเสมอ แม้ผลรวมหลังบวก Reflex ยังไม่ถึง CV (ผู้ใช้เคาะ 11 พ.ย. 2026)
  if (sum === dc) return {cls:'res-crit', text:`Perfect Evade (เต๋า ${sum} เท่ากับผลโจมตี ได้ 1 Swift Action)`};
  const where = part ? partLabel(part) : '';
  const tgt = cv !== dc ? `CV ${cv}` : String(dc);
  return total >= cv ? {cls:'res-full', text:`Evade สำเร็จ (${total} ถึง ${tgt})`} : {cls:'res-fail', text:`Evade ไม่สำเร็จ (${total} ต่ำกว่า ${tgt})${where ? ' โดน'+where : ''}`};
}
/* ===== v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026) =====
 * ทอยโจมตี: ตำแหน่งและ Perfect Strike ดูจากหน้าเต๋า 2 ลูกที่เลือก ตัวปรับ CV บวกทีหลังและไม่ขยับตำแหน่ง · o.loc = ตำแหน่งที่ประกาศด้วย Focus (Precise)
 * Advantage: ผู้โจมตีเลือก 2 ลูกเอง · Disadvantage: ฝ่ายรับเลือกให้ · Parry ทอยได้สูงสุด 4 ลูก */
const PARRY_MAX_DICE = 4;
function parryDiceCount(pd, adv){ return Math.min(PARRY_MAX_DICE, 2 + Math.max(0, pd||0) + (adv ? 1 : 0)); }
function attackVerdict(r, o){
  o = o || {}; const cvMod = o.cvMod||0; const cv = r.sum + cvMod; const part = (o.loc && HIT_ATTACK[o.loc]) ? o.loc : hitPart(r.sum);
  const bits = []; if (r.double) bits.push(`Perfect Strike (คู่ ${r.kept[0]})`);
  bits.push(cvMod ? `CV ${cv} (เต๋า ${r.sum} ${signed(cvMod)})` : `CV ${r.sum}`);
  if (part) bits.push(partLabel(part) + (o.loc ? ' (เล็ง)' : ''));
  return {cls: r.double ? 'res-crit' : 'res-part', text: bits.join(' · '), sum: r.sum, cv, part, precise: !!o.loc};
}
/* อาวุธที่เขียนว่า "(STR n: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage)" (ผู้ใช้เคาะ 11 พ.ย. 2026 ข้อ 1ค)
 * weaponStrNeed = ค่า STR ที่อาวุธต้องการ (0 = ไม่มีเงื่อนไขแบบนี้) · weaponStrShort = ตัวละครนี้ STR ไม่ถึงไหม · weaponPropsText = เอฟเฟกต์ที่ตัดวงเล็บนี้ออกสำหรับป้ายย่อ */
const WEAPON_STR_RX = /\(STR\s*(\d+)\s*:\s*หาก STR ไม่ถึง[^)]*\)\s*/;
function weaponStrNeed(effect){ const m = WEAPON_STR_RX.exec(String(effect||'')); return m ? +m[1] : 0; }
function weaponStrShort(effect, d){ const need = weaponStrNeed(effect); return !!(need && d && d.raw && (d.raw.STR||0) < need); }
function weaponPropsText(effect){ return String(effect||'').replace(WEAPON_STR_RX, ''); }
/* คู่เต๋าที่เลือกได้จากเต๋าที่ทอย (ไม่ซ้ำผลรวม+คู่) ใช้กับปุ่มเลือกของฝ่ายรับ */
function dicePairs(dice){ const out = []; for (let i = 0; i < dice.length; i++) for (let j = i+1; j < dice.length; j++) out.push({i, j, a: dice[i], b: dice[j], sum: dice[i]+dice[j], double: dice[i]===dice[j]}); return out; }
function rollFromPick(dice, i, j, mode){ const kept = [dice[i], dice[j]]; return {dice: dice.slice(), kept, keptIdx: [i, j], sum: kept[0]+kept[1], crit: null, double: kept[0]===kept[1], mode: mode||'normal', chosen: true}; }
/* ===== บาดแผลฉกรรจ์และค่า Toughness ติดลบ (v1.15) =====
 * เหลือ 0 = ทอย 1d6 ตามตารางของส่วนนั้น · ติดลบถึงค่าเต็ม = แขนขาขาด ส่วนศีรษะหรือลำตัวให้ผลเท่า Mortal Wound */
const WOUND_KIND = {head:'head', torso:'torso', armL:'arm', armR:'arm', legL:'leg', legR:'leg'};
function woundRows(part){ return ((DATA.meta.wounds||{})[WOUND_KIND[part]]) || []; }
function rollWound(part){ const die = rollD6(); return {die, row: woundRows(part).find(x=>x.faces.includes(die)) || null}; }
function toughFloor(max){ return max != null ? -Math.abs(max) : 0; }
function toughState(part, v, max){ if (v == null || max == null) return ''; if (v <= -max) return (part==='head' || part==='torso') ? 'mortal' : 'lost'; if (v <= 0) return 'wound'; return ''; }
function toughStateText(st){ return st==='lost' ? 'ขาด' : st==='mortal' ? 'Mortal Wound' : st==='wound' ? 'บาดแผลฉกรรจ์' : ''; }
/* ===== การพัก (v1.15): ค่า Recovery ของ HP = Max HP ของ MP = Max MP · พักสั้นฟื้นครึ่งหนึ่ง (ปัดลง) พักยาวฟื้นเต็ม · ยาม 1 คนฟื้นครึ่งเดียว ผู้เฝ้ายามไม่ฟื้น Toughness */
function restGain(max, kind, watch){ if (!max || max < 0) return 0; if (kind==='short') return Math.floor(max/2); return watch===1 ? Math.floor(max/2) : max; }
/* ค่าซื้อด้วย Insight Point (ตารางในไฟล์แกน): Mod ติดลบ→0 ขั้นละ 3 · 0→1 3 · 1→2 4 · 2→3 5 · 3→4 6 · 4→5 7 · Knowledge Level Up 4 / 6 / 9 */
function ipCostStat(mod){ if (mod >= 5) return null; if (mod < 0) return 3; return [3,4,5,6,7][mod]; }
function ipCostKnowledge(level){ if (level >= 3) return null; return [4,6,9][level]; } // ผู้ใช้เคาะ 29 ส.ค. 2026 (บทที่ 13 V.3): Lv1 4 · Lv2 6 · Lv3 9 IP
function renderDice(r){
  return h('span', {class:'inline-roll'}, r.dice.map((d,i)=>h('span',{class:'die' + (r.keptIdx.includes(i)?'':' drop'), text:d})));
}

/* ---- Character model & computation ---- */
/* สำเนาที่ส่งเข้าห้อง: โหมด "full" = ทั้งชีท · โหมด "min" = เฉพาะค่าที่หมากและ GM ต้องใช้ (ชื่อ รูป วงศา HP Sanity สถานะ) */
function roomCopyOf(copy){
  if ((copy.shareMode||'full') !== 'min') return copy;
  const cur = copy.current || {};
  return { id: copy.id, name: copy.name, kin: copy.kin, size: copy.size, portrait: copy.portrait||null, ownerId: copy.ownerId, ownerName: copy.ownerName, shareMode: 'min', done: true, updatedAt: copy.updatedAt,
    current: Object.assign({ hp: cur.hp, mp: cur.mp, sanity: cur.sanity, temp: cur.temp, tough: cur.tough || {}, wounds: (cur.wounds || []).map(w=>({part:w.part, body:w.body||'A', die:w.die, name:w.name||''})) }, cur.hp2 != null ? { hp2: cur.hp2, tough2: cur.tough2 || {} } : {}), armor: copy.armor || {}, armor2: copy.armor2 || {}, /* hp2 / tough2 / armor2 = HP Toughness และเกราะของร่าง B (Twinborn) */ details: { appearance: (copy.details||{}).appearance || '', signature: (copy.details||{}).signature || '' } };
}
/* ลบลิงก์ห้องที่ค้าง: ห้องถูกลบ หรือหมากของตัวละครถูกเอาออกไปแล้วขณะเราไม่อยู่ */
/* ถังขยะในเครื่อง: เก็บตัวละครที่ถูกลบ/ถูกตัดออกตามเซิร์ฟเวอร์ไว้ 10 ตัวล่าสุด เผื่อกู้คืน (ผู้พัฒนากู้ได้จากคอนโซล: JSON.parse(localStorage['kirana.chars.trash'])) */
function stashTrash(list){ try { const t = JSON.parse(localStorage.getItem('kirana.chars.trash')||'[]'); for (const c of list) t.unshift({at: Date.now(), char: c}); localStorage.setItem('kirana.chars.trash', JSON.stringify(t.slice(0,10))); } catch(e){} }
/* ถอนหมากของตัวละครออกจากบอร์ดห้อง (เมื่อเจ้าของลบตัวละคร) อ่านห้องแล้วเขียนเฉพาะ tokens/enc */
async function removeTokensOf(rid, charId){
  if (!Store.db) return; const ref = Store.db.doc('rooms/'+rid); const r = docData(await ref.get()); if (!r || !(r.tokens||[]).some(t=>t.charId===charId)) return;
  const ids = r.tokens.filter(t=>t.charId===charId).map(t=>t.id);
  const tokens = r.tokens.filter(t=>t.charId!==charId).map(t=> ids.includes(t.inside) ? Object.assign({}, t, {inside:null}) : t);
  const enc = r.enc ? Object.assign({}, r.enc, {order: (r.enc.order||[]).filter(x=>!ids.includes(x))}) : null;
  const patch = {tokens, updatedAt: Date.now()}; if (enc){ if (enc.turnIdx >= enc.order.length) enc.turnIdx = 0; patch.enc = enc; }
  await ref.update(patch);
}
/* รวมรายการตัวละครจากเซิร์ฟเวอร์เข้ากับของในเครื่อง (เรียกทุกครั้งที่ snapshot มา; แยกเป็นฟังก์ชันให้ทดสอบได้) */
function applyCharsSnapshot(snap){
  const docs = snapDocs(snap);
  let changed=false; const ids = new Set();
  for (const d of docs){ if(!d || !d.id) continue; ids.add(d.id); d.synced = true; const i=Store.chars.findIndex(x=>x.id===d.id); if(i<0){ Store.chars.push(d); changed=true; } else { Store.chars[i].synced = true; if ((d.updatedAt||0) > (Store.chars[i].updatedAt||0)){ Store.chars[i]=d; changed=true; } } }
  // เซิร์ฟเวอร์ยืนยันรายการแล้ว: ตัวละครที่เคยบันทึกขึ้นเว็บ (มี ownerId) แต่ไม่อยู่ในรายการ = ถูกลบจากเครื่องอื่นหรือโดยผู้พัฒนา ต้องหายจากเครื่องนี้ด้วย
  // (เดิมเครื่องที่ยังถือสำเนาจะเซฟกลับขึ้นไปใหม่ ทำให้ดูเหมือนลบไม่ได้) สำเนาเก็บไว้ใน kirana.chars.trash เผื่อกู้
  if (snap && snap.fromCache === false){
    const gone = Store.chars.filter(c => c.ownerId && !ids.has(c.id) && (Store.isDevUid || c.ownerId === Store.me));
    if (gone.length){ stashTrash(gone); Store.chars = Store.chars.filter(c => !gone.includes(c)); changed = true;
      toast(`ซิงก์: ${gone.map(c=>c.name||'ตัวละคร').join(', ')} ถูกลบไปแล้วจากเครื่องอื่น`);
      const m = location.hash.match(/^#sheet-([a-z0-9]+)$/); if (m && gone.some(c=>c.id===m[1])) location.hash = '#chars'; }
  }
  if (changed){ saveLocal(Store.chars); Store.notify(); }
  if (!Store._pruned){ Store._pruned = true; setTimeout(()=>pruneRoomLinks().catch(()=>{}), 1500); }
  return {changed, count: Store.chars.length};
}
async function pruneRoomLinks(){
  if (!Store.db || Store.backend!=='firebase') return;
  const seen = {};
  for (const c of Store.chars){ if (!Store.isMine(c) || !(c.roomIds||[]).length) continue;
    for (const rid of [...c.roomIds]){
      try { if (!(rid in seen)) seen[rid] = docData(await Store.db.doc('rooms/'+rid).get()); } catch(e){ seen[rid] = undefined; }
      const room = seen[rid]; if (room === undefined) continue; // อ่านไม่ได้ (ห้องล็อกและเราไม่ใช่สมาชิก) ปล่อยไว้
      if (!room || !(room.tokens||[]).some(t=>t.charId===c.id)) Store.unshareFromRoom(c, rid);
    }
  }
}
function newChar(){
  return { id: uid(), name:'', kin:null, size:null, childhood:null, adulthood:null, evolver:{kin:null, pick:null, hindrance:null},
    personality:{}, extra:{}, choiceStats:[], talent:null, talentPicks:{}, knowledge:{}, prof:{}, skills:[], grants:[],
    adaptation:null, starterSet:null, details:{likes:'',dislikes:'',fears:'',backstory:'',appearance:'',signature:''},
    current:null, notes:'', createdAt:Date.now(), updatedAt:Date.now(), ownerId:null, step:0 };
}
const modOf = v => Math.max(-5, Math.min(5, Math.floor(v/2) - 5));

function findBg(kin, code){
  if (!kin || !code) return null;
  for (const list of ['childhood','specialChildhood','adulthood','specialAdulthood'])
    for (const b of kin[list]) if (b.code === code) return b;
  return null;
}
/* ---------- ภาษาของตัวละคร (v1.18 ผู้ใช้แจ้ง 12 พ.ย. 2026 ว่าวิซาร์ดยังไม่มีตัวเลือกภาษา) ----------
   รายการภาษามาจากไฟล์แกนผ่าน DATA.meta.languages · ภาษาของวงศามาจาก kin.lang (fixed ได้เลย · choose ต้องเลือกตอนสร้าง)
   "open" = บรรทัด "อีกหนึ่งภาษาตามที่คุณเลือก" ของลูนารินกับโซริน เลือกได้ทุกภาษายกเว้นหมวดเฉพาะกลุ่มที่ไฟล์แกนให้มีได้เฉพาะเผ่าที่ระบุ
   c.langPick = ภาษาที่เลือกตามสิทธิ์ของวงศา · c.langExtra = ภาษาที่ได้เพิ่มระหว่างเล่น (รหัสภาษาหรือข้อความที่พิมพ์เอง) */
const LANGS = (DATA.meta && DATA.meta.languages) || [];
const LANG = Object.fromEntries(LANGS.map(l => [l.id, l]));
const LANG_GROUPS = [['common','ภาษากลาง'], ['culture','ภาษาตามเผ่าพันธุ์และวัฒนธรรม'], ['restricted','ภาษาเฉพาะกลุ่ม']];
function langLabel(id){ const l = LANG[id]; return l ? `${l.th} (${l.en})` : String(id == null ? '' : id); }
function langOptions(kin){ const sp = kin && kin.lang; if (!sp || !sp.choose) return []; if (Array.isArray(sp.choose)) return sp.choose.filter(id => LANG[id]); return LANGS.filter(l => l.group !== 'restricted' && !sp.fixed.includes(l.id)).map(l => l.id); }
function langNeedsPick(c){ const opts = langOptions(c && c.kin ? KIN[c.kin] : null); return opts.length > 0 && !(c.langPick && opts.includes(c.langPick)); }
function charLanguages(c){
  const kin = c && c.kin ? KIN[c.kin] : null; if (!kin || !kin.lang) return [];
  const sp = kin.lang; const out = []; const seen = new Set();
  const push = (o)=>{ if (o.id){ if (seen.has(o.id)) return; seen.add(o.id); } out.push(o); };
  for (const id of sp.fixed) push({id, label: langLabel(id), note: (sp.notes||{})[id] || '', src:'kin'});
  const opts = langOptions(kin);
  if (opts.length){ if (c.langPick && opts.includes(c.langPick)) push({id:c.langPick, label: langLabel(c.langPick), note:'', src:'pick'}); else push({id:null, label:'ยังไม่ได้เลือกภาษา', note:'', src:'pick', missing:true}); }
  for (const b of [findBg(kin, c.childhood), findBg(kin, c.adulthood)]) if (b && b.langFromPick){ const p = String((c.traitPicks||{})['bg:'+b.code]||'').trim(); push({id:null, label: p ? `ภาษาของ${p}` : 'ภาษาของเผ่าพันธมิตร 1 เผ่า', note: 'พูดและอ่านได้ จากพื้นหลัง ' + b.name + (p ? '' : ' (ยังไม่ได้ระบุเผ่า)'), src:'trait', missing: !p}); }
  for (const x of (c.langExtra||[])){ const v = String(x||'').trim(); if (!v) continue; if (LANG[v]) push({id:v, label: langLabel(v), note:'', src:'extra'}); else push({id:null, label:v, note:'', src:'extra', custom:true}); }
  return out;
}
/* ช่องภาษาเดิมของชีทเป็นข้อความอิสระที่เติมประโยคของวงศาไว้ให้ · ถ้ายังเป็นประโยคตั้งต้นของวงศาใดวงศาหนึ่ง (ผู้เล่นไม่ได้แก้) ให้ล้าง เพราะป้ายภาษามาแทนแล้ว ส่วนที่ผู้เล่นพิมพ์เองเก็บไว้เป็นหมายเหตุ */
function migrateLanguages(c){ if (!c || !c.extraText) return false; const t = String(c.extraText.languages||'').trim(); if (!t) return false; if (DATA.kins.some(k => String(k.languages||'').trim() === t)){ c.extraText.languages = ''; return true; } return false; }
function compute(c){
  const kin = c.kin ? KIN[c.kin] : null;
  const raw = Object.fromEntries(STATS.map(s=>[s, kin ? (kin.raw[s]||0) : 0]));
  const from = Object.fromEntries(STATS.map(s=>[s, []]));
  const addStats = (obj, label) => { for (const [k,v] of Object.entries(obj||{})) if (STATS.includes(k)) { raw[k]+=v; from[k].push(`${label} ${signed(v)}`); } };
  const ch = findBg(kin, c.childhood), ad = findBg(kin, c.adulthood);
  if (ch) addStats(ch.stats, 'วัยเด็ก');
  if (ad) addStats(ad.stats, 'วัยผู้ใหญ่');
  for (const s of c.choiceStats||[]) { raw[s]+=1; from[s].push('พื้นหลัง (เลือก) +1'); }
  for (const [k,v] of Object.entries(c.extra||{})) if (v) { raw[k]+=v; from[k].push(`Extra ${signed(v)}`); }
  for (const [k,v] of Object.entries(c.ipStats||{})) if (v) { raw[k]+=v; from[k].push(`IP ${signed(v)}`); }
  const mod = Object.fromEntries(STATS.map(s=>[s, modOf(raw[s])]));
  const extraTotal = kin ? kin.extra : 0;
  const extraUsed = Object.values(c.extra||{}).reduce((a,b)=>a+(b||0),0);
  const size = c.size || (kin ? kin.sizes[0] : 'Medium');
  let capMult = {Small:3, Medium:3, Large:4, Huge:5}[size] || 3;
  let capNote = size==='Small' ? 'Small ใช้ตัวคูณเดียวกับ Medium' : '';
  if (kin && kin.id==='handerlaw-dwarves') { capMult = 4; capNote = 'Powerful Build: นับขนาดใหญ่ขึ้นหนึ่งขั้นเรื่องการแบก จึงใช้ ×4'; }
  const toughSizeBonus = {Large:1, Huge:2}[size] || 0; // ชีท Duck Family (AX2) และกฎ Bestiary: Large +1, Huge +2
  const tough = Math.floor((raw.VIT + raw.STR)/10) + 1 + toughSizeBonus;
  const d = {
    raw, mod, from, extraTotal, extraUsed, extraLeft: extraTotal - extraUsed, size,
    hp: 10 + mod.VIT + mod.STR,
    mp: 10 + mod.INF + mod.INT,
    sanity: 5 + mod.INF,
    toughness: tough, toughSizeBonus,
    passivePer: 7 + mod.PER,
    capacity: raw.STR * capMult, capMult, capNote,
    // ค่าพลังรอง (Ability Stats) ตามตารางค่าสถานะศักยภาพที่ล็อก 9 พ.ย. 2026
    fortitude: mod.VIT, will: mod.PER, reflex: Math.floor(mod.AGI/2)+1, sight: Math.floor(mod.PER/2)+1,
    might: Math.floor(mod.STR/2)+1, initiative: mod.PER, parryDice: Math.max(0, (c.current && c.current.parryBonus) || 0), combatDice: '2d6',
    speed: kin ? kin.speed : '',
    highest: [], knowledgeMods: {},
  };
  const best = Math.max(...STATS.map(s=>mod[s]));
  d.highest = STATS.filter(s=>mod[s]===best);
  for (const k of DATA.knowledge){ const lvl = c.knowledge[k.id]||0; const profs = (c.prof[k.id]||[]).length; d.knowledgeMods[k.id] = {level: lvl, prof: Math.max(lvl, profs)}; }
  return d;
}
function personalityValue(c, axisId){ const p = c.personality[axisId]; if (!p || p.value==null) return null; return p; }
/* คู่บุคลิกภาพ: ฝั่งที่เลือกเป็นบวก ฝั่งตรงข้ามติดลบเท่ากัน */
function persMod(c, side){ // side = 'Logic' etc.
  for (const ax of DATA.meta.personality){
    const p = c.personality[ax.id]; if (!p || p.value==null) continue;
    if (ax.left === side) return p.side==='left' ? p.value : -p.value;
    if (ax.right === side) return p.side==='right' ? p.value : -p.value;
  }
  return 0;
}
function budgetState(c){
  const used = []; for (const ax of DATA.meta.personality){ const p=c.personality[ax.id]; if (p && p.value!=null) used.push(p.value); }
  const pool = DATA.meta.personalityBudget.slice();
  const left = pool.slice(); for (const v of used){ const i=left.indexOf(v); if(i>=0) left.splice(i,1); }
  return {used, left};
}

/* ---- Storage: localStorage เสมอ + db เมื่อมี ---- */
const LS_KEY = 'kirana.chars.v1';
function loadLocal(){ try { return JSON.parse(localStorage.getItem(LS_KEY)||'[]'); } catch(e){ return []; } }
function saveLocal(list){ try { localStorage.setItem(LS_KEY, JSON.stringify(list)); } catch(e){} }
const Store = {
  chars: loadLocal(), db:null, user:null, room:null, me:null, isOwner:false, canWrite:null, online:false, backend:null,
  displayName:'', isDevUid:false, onlineUsers:[],
  listeners: new Set(),
  notify(){ for (const f of this.listeners) try{ f(); }catch(e){ console.error(e);} },
  upsert(c){ c.updatedAt = Date.now(); const i=this.chars.findIndex(x=>x.id===c.id); if(i>=0) this.chars[i]=c; else this.chars.push(c); saveLocal(this.chars); this.notify();
    if (this.db && this.me && this.canWrite!==false){ const copy = JSON.parse(JSON.stringify(c)); copy.ownerId = copy.ownerId || this.me; if (!c.ownerId) c.ownerId = copy.ownerId; copy.ownerName = this.displayName||copy.ownerName||''; this.db.doc('chars/'+c.id).set(copy).then(()=>{ c.synced = true; }).catch(e=>{ console.warn('db set', e); toast('บันทึกตัวละครขึ้นเว็บไม่สำเร็จ ('+(e && e.code || e)+')'); });
      const roomCopy = JSON.parse(JSON.stringify(roomCopyOf(copy))); for (const rid of c.roomIds||[]) this.db.doc(`rooms/${rid}/chars/${c.id}`).set(roomCopy).catch(()=>{}); } },
  /* ตัวละครอยู่ในแคมเปญ (ถูกวางลงบอร์ดห้องใดห้องหนึ่ง) → ล็อกไม่ให้กลับไปแก้ในวิซาร์ด */
  inCampaign(c){ return !!(c && (c.roomIds||[]).length); },
  /* แชร์สำเนาชีทเข้าห้อง: GM และผู้เล่นในห้องเห็นได้เฉพาะตัวละครที่ถูกหยิบมาเล่นในแคมเปญนี้ */
  shareToRoom(c, rid){ c.roomIds = [...new Set([...(c.roomIds||[]), rid])]; this.upsert(c); },
  /* ถอนตัวละครออกจากห้อง: เลิกซิงก์และลบสำเนาในห้อง */
  unshareFromRoom(c, rid){ if (!c) return; c.roomIds = (c.roomIds||[]).filter(x=>x!==rid); if (this.isMine(c)) this.upsert(c); if (this.db) this.db.doc(`rooms/${rid}/chars/${c.id}`).delete().catch(()=>{}); },
  /* ลบตัวละคร: ลบในเครื่อง ลบบนเว็บ ลบสำเนาในห้อง และถอนหมากออกจากบอร์ดของห้องที่อยู่ (ล้มเหลวบนเว็บจะบอก ไม่เงียบ) */
  remove(id){ const c = this.get(id); this.chars = this.chars.filter(x=>x.id!==id); saveLocal(this.chars); this.notify(); if (c) stashTrash([c]);
    if (!this.db && typeof loadLocalRooms==='function'){ const rooms = loadLocalRooms(); let touched=false; for (const r of rooms){ if ((r.tokens||[]).some(t=>t.charId===id)){ const ids = r.tokens.filter(t=>t.charId===id).map(t=>t.id); r.tokens = r.tokens.filter(t=>t.charId!==id).map(t=> ids.includes(t.inside) ? Object.assign({}, t, {inside:null}) : t); if (r.enc) r.enc.order = (r.enc.order||[]).filter(x=>!ids.includes(x)); touched=true; } } if (touched){ saveLocalRooms(rooms); if (typeof Table!=='undefined' && Table.room && rooms.some(r=>r.id===Table.room.id)) Table.room = rooms.find(r=>r.id===Table.room.id); } }
    if (this.db){ this.db.doc('chars/'+id).delete().catch(e=>{ console.warn('delete char', e); toast('ลบบนเว็บไม่สำเร็จ ('+(e && e.code || e)+') ตัวละครอาจกลับมาเมื่อซิงก์'); });
      for (const rid of (c&&c.roomIds)||[]){ this.db.doc(`rooms/${rid}/chars/${id}`).delete().catch(()=>{}); removeTokensOf(rid, id).catch(()=>{}); } } },
  get(id){ return this.chars.find(x=>x.id===id) || (typeof Table!=='undefined' && Table.roomChars.find(x=>x.id===id)) || null; },
  isMine(c){ return !c.ownerId || !this.me || c.ownerId===this.me; },
  canEdit(c){ return this.isMine(c) || this.isDevUid; },
};
async function initCapabilities(){
  if (window.claude && window.claude.use){
    try {
      const [db, user, room] = await Promise.all([claude.use('db'), claude.use('user'), claude.use('room')]);
      Store.db = db; Store.user = user; Store.room = room; Store.backend = 'claude';
      if (user){ try { Store.me = await user.id(); } catch(e){} try { Store.isOwner = !!user.isOwner(); } catch(e){} try { Store.canWrite = user.can('data.write'); } catch(e){} }
    } catch(e){ console.warn('capabilities', e); }
  } else if (window.KIRANA_FIREBASE && window.KIRANA_FIREBASE.projectId){
    try { await initFirebase(window.KIRANA_FIREBASE); } catch(e){ console.warn('firebase', e); toast('เชื่อมต่อ Firebase ไม่ได้: ' + (e && e.message ? e.message : e)); }
  }
  if (Store.db){
    Store.online = true;
    // ตัวละครที่แชร์ในโต๊ะเดียวกัน: ทุกคนอ่านได้ (GM ต้องเห็นชีทผู้เล่น)
    try {
      // ตัวละครของฉันเท่านั้น (ผู้พัฒนาเห็นทั้งหมด) — ชีทของคนอื่นเห็นได้ผ่านสำเนาในห้องที่เขาหยิบตัวละครมาเล่น
      const q = (Store.backend==='firebase' && !Store.isDevUid) ? Store.db.collection('chars').where('ownerId','==',Store.me) : Store.db.collection('chars');
      q.onSnapshot(snap => applyCharsSnapshot(snap), err => console.warn('chars snapshot', err));
    } catch(e){ console.warn(e); }
  }
  updateOnline();
}
/* ---- Firebase backend (GitHub Pages): Firestore + Anonymous auth ห่อให้หน้าตาเหมือน db/user/room ของ claude.ai ---- */
async function initFirebase(cfg){
  const V = cfg.sdkVersion || '11.0.1';
  const base = `https://www.gstatic.com/firebasejs/${V}/`;
  const [{initializeApp}, A, F] = await Promise.all([import(base+'firebase-app.js'), import(base+'firebase-auth.js'), import(base+'firebase-firestore.js')]);
  const app = initializeApp(cfg);
  const auth = A.getAuth(app);
  const fdb = F.getFirestore(app);
  FB = {A, F, auth, fdb};
  const plain = o => JSON.parse(JSON.stringify(o)); // Firestore ไม่รับ undefined
  const wrapDoc = snap => ({ exists: snap.exists(), id: snap.id, data: () => snap.data() });
  const docRef = path => { const ref = F.doc(fdb, path); return {
    set: d => F.setDoc(ref, plain(d)), update: d => F.updateDoc(ref, plain(d)), delete: () => F.deleteDoc(ref), get: async () => wrapDoc(await F.getDoc(ref)),
    onSnapshot: (ok, err) => F.onSnapshot(ref, s => ok(wrapDoc(s)), err) }; };
  const coll = (path, cons=[]) => ({
    orderBy: (f, d) => coll(path, [...cons, F.orderBy(f, d||'asc')]), limit: n => coll(path, [...cons, F.limit(n)]), where: (a, op, v) => coll(path, [...cons, F.where(a, op, v)]),
    doc: id => docRef(path + '/' + id),
    get: async () => ({ docs: (await F.getDocs(cons.length ? F.query(F.collection(fdb, path), ...cons) : F.collection(fdb, path))).docs.map(wrapDoc) }),
    onSnapshot: (ok, err) => F.onSnapshot(cons.length ? F.query(F.collection(fdb, path), ...cons) : F.collection(fdb, path), s => ok({ docs: s.docs.map(wrapDoc), fromCache: !!(s.metadata && s.metadata.fromCache), pending: !!(s.metadata && s.metadata.hasPendingWrites) }), err) });
  const db = { doc: docRef, collection: coll };
  // ---- login gate: config/site = {requireLogin, devUids, devIps} ----
  let site = null;
  try { const sn = await F.getDoc(F.doc(fdb, 'config/site')); if (sn.exists()) site = sn.data(); } catch(e){ console.warn('config read', e); }
  Store.site = site;
  const current = await new Promise(res => { const stop = A.onAuthStateChanged(auth, u => { stop(); res(u); }); setTimeout(()=>res(auth.currentUser), 6000); });
  let user = current;
  const needLogin = !!(site && site.requireLogin);
  if (needLogin){
    if (user && !user.isAnonymous) { /* ล็อกอิน Google อยู่แล้ว */ }
    else {
      const ip = await fetchPublicIp();
      Store.ip = ip;
      if (ip && (site.devIps||[]).includes(ip)){
        Store.isDevIp = true;
        if (!user) user = (await A.signInAnonymously(auth)).user;
      } else {
        user = await loginGate(A, auth); // รอจนกว่าจะล็อกอินสำเร็จ
      }
    }
  } else {
    if (!user) user = (await A.signInAnonymously(auth)).user;
  }
  Store.authUser = user;
  Store.db = db;
  Store.user = { id: async () => user.uid, isOwner: () => false, canEdit: () => false, can: () => true };
  Store.me = user.uid; Store.canWrite = true; Store.backend = 'firebase';
  Store.isDevUid = !!(site && (site.devUids||[]).includes(user.uid));
  Store.isDev = Store.isDevUid || Store.isDevIp;
  Store.displayName = user.isAnonymous ? (localStorage.getItem('kirana.nick') || 'ผู้เล่น-' + user.uid.slice(0,4)) : (user.displayName || (user.email||'').split('@')[0] || 'ผู้เล่น');
  // แคชในเครื่องอาจมีตัวละครของคนอื่นจากรุ่นก่อน (ตอนนั้นทุกคนเห็นทุกตัว) เก็บเฉพาะของฉัน
  if (!Store.isDevUid) { Store.chars = Store.chars.filter(c => !c.ownerId || c.ownerId === user.uid); saveLocal(Store.chars); }
  startSitePresence(F, fdb, user);
  Store.login = async () => { try { const prov = new A.GoogleAuthProvider(); prov.setCustomParameters({prompt:'select_account'}); if (auth.currentUser && auth.currentUser.isAnonymous){ try { await A.linkWithPopup(auth.currentUser, prov); } catch(e){ if (e && /credential-already-in-use|email-already-in-use/.test(e.code||'')) await A.signInWithPopup(auth, prov); else throw e; } } else await A.signInWithPopup(auth, prov); location.reload(); } catch(e){ toast('ล็อกอินไม่สำเร็จ: ' + (e && e.code || e)); } };
  Store.logout = async () => { try { await F.deleteDoc(F.doc(fdb, 'presence/' + user.uid)); } catch(e){} try { await A.signOut(auth); } catch(e){} try { localStorage.removeItem(LS_KEY); } catch(e){} location.reload(); };
  // presence ผ่าน Firestore: rooms/<id>/presence/<uid> อัปเดตทุก 40 วิ ถือว่าออนไลน์ถ้าไม่เกิน 100 วิ
  Store.room = { join: async (name) => {
    const path = 'rooms/' + name.replace(/^kirana-/, '') + '/presence';
    let state = {}; let timer = null; let unsub = null;
    const push = () => F.setDoc(F.doc(fdb, path + '/' + user.uid), plain({ ...state, at: Date.now() })).catch(()=>{});
    return {
      presence: (patch) => { state = { ...state, ...patch }; push(); if (!timer) timer = setInterval(push, 40000); },
      onPeers: (fn) => { unsub = F.onSnapshot(F.collection(fdb, path), s => { const now = Date.now(); fn(s.docs.map(d => d.data()).filter(p => p && (now - (p.at||0)) < 100000)); }, ()=>{}); },
      leave: () => { if (timer) clearInterval(timer); if (unsub) unsub(); F.deleteDoc(F.doc(fdb, path + '/' + user.uid)).catch(()=>{}); },
      emit: () => {}, on: () => {} };
  } };
}
let FB = null;
/* ---- ผู้เล่นที่ออนไลน์ทั้งเว็บ: presence/<uid> อัปเดตทุก 40 วิ (ถือว่าออนไลน์ถ้าไม่เกิน 100 วิ) ---- */
function startSitePresence(F, fdb, user){
  const plain = o => JSON.parse(JSON.stringify(o));
  const push = () => F.setDoc(F.doc(fdb, 'presence/' + user.uid), plain({ uid: user.uid, name: Store.displayName, anon: !!user.isAnonymous, dev: !!Store.isDevUid, room: (typeof Table!=='undefined' && Table.roomId) || null, roomName: (typeof Table!=='undefined' && Table.room && Table.room.name) || '', at: Date.now() })).catch(()=>{});
  push(); setInterval(push, 40000); window.addEventListener('hashchange', ()=>setTimeout(push, 800));
  window.addEventListener('beforeunload', ()=>{ try { F.deleteDoc(F.doc(fdb, 'presence/' + user.uid)); } catch(e){} });
  try { F.onSnapshot(F.collection(fdb, 'presence'), s => { const now = Date.now(); Store.onlineUsers = s.docs.map(d=>d.data()).filter(p => p && (now - (p.at||0)) < 100000).sort((a,b)=>(a.name||'').localeCompare(b.name||'')); updateOnline(); }, ()=>{}); } catch(e){}
  setInterval(updateOnline, 30000);
}
async function fetchPublicIp(){
  try { const r = await fetch('https://api.ipify.org?format=json', {cache:'no-store'}); const j = await r.json(); return j.ip || null; } catch(e){ return null; }
}
function snapDocs(snap){
  if (!snap) return [];
  if (Array.isArray(snap)) return snap.map(x => x && x.data ? (typeof x.data==='function' ? x.data() : x.data) : x);
  if (snap.docs) return snap.docs.map(x => x && typeof x.data==='function' ? x.data() : (x.data||x));
  if (typeof snap.forEach==='function'){ const out=[]; snap.forEach(x=>out.push(typeof x.data==='function'?x.data():(x.data||x))); return out; }
  return [];
}
function docData(d){ if(!d) return null; if (typeof d.data==='function') return d.exists===false ? null : d.data(); return d.data||d; }
function updateOnline(){
  const o = $('#online'); if (!o) return; clear(o);
  const dot = h('span', {class:'dot' + (Store.online ? ' on' : '')});
  if (!Store.online){ o.append(dot, 'โหมดออฟไลน์ (บันทึกในเครื่องนี้)'); return; }
  if (Store.backend !== 'firebase'){ o.append(dot, Store.canWrite===false ? 'ออนไลน์แบบอ่านอย่างเดียว' : 'ออนไลน์: ซิงก์ผ่านเว็บ'); return; }
  const u = Store.authUser; const anon = !u || u.isAnonymous;
  const n = Store.onlineUsers.length;
  const who = h('button',{class:'small ghost onl',title:'ผู้เล่นที่ออนไลน์อยู่ตอนนี้',onclick:(e)=>{ e.stopPropagation(); showOnlineList(who); }}, dot, ` ออนไลน์ ${n} คน`);
  o.append(who);
  o.append(h('span',{class:'acct',text: anon ? (Store.isDevIp ? 'เครื่องผู้พัฒนา (นิรนาม)' : 'ผู้เล่นนิรนาม') : (Store.displayName + (Store.isDevUid ? ' · ผู้พัฒนา' : ''))}));
  if (anon) o.append(h('button',{class:'small primary',onclick:()=>Store.login(),text:'เข้าสู่ระบบ Google'}));
  else o.append(h('button',{class:'small ghost',onclick:()=>{ if (confirm('ออกจากระบบ? ตัวละครในแคชเครื่องนี้จะถูกล้าง (ยังอยู่บนเว็บ ล็อกอินใหม่ก็กลับมา)')) Store.logout(); },text:'ออกจากระบบ'}));
}
let onlPop = null;
function showOnlineList(anchor){
  if (onlPop){ onlPop.remove(); onlPop=null; return; }
  const list = Store.onlineUsers;
  onlPop = h('div',{class:'pop onl-pop',role:'dialog'}, h('div',{class:'pop-h'}, h('b',{text:`ออนไลน์ ${list.length} คน`}), h('button',{class:'small ghost',style:'margin-left:auto',onclick:()=>{ onlPop.remove(); onlPop=null; },text:'✕'})),
    h('div',{class:'pop-b'}, list.length ? list.map(p=>h('div',{class:'onl-row'}, h('span',{class:'dot on'}), h('b',{text:p.name||'?'}), p.dev? tag('ผู้พัฒนา','prop'):null, p.anon? tag('นิรนาม'):null, p.room? h('a',{href:'#room-'+p.room,class:'dim',style:'font-size:12px',text:' อยู่ในห้อง '+(p.roomName||p.room)}):null)) : h('div',{class:'dim',text:'ไม่มีใครออนไลน์'})));
  document.body.append(onlPop);
  const r = anchor.getBoundingClientRect(); const z = uiZoom(); onlPop.style.width='300px'; onlPop.style.right='12px'; onlPop.style.top=((r.bottom+8+window.scrollY)/z)+'px';
  setTimeout(()=>document.addEventListener('click', function once(e){ if (onlPop && !onlPop.contains(e.target)){ onlPop.remove(); onlPop=null; } document.removeEventListener('click', once); }), 0);
}
