/* ===== HUD แบบเกม: ปุ่มลอยข้างจอ (กระเป๋า / คัมภีร์สกิล / ถุงย่ามของสวมใส่) ลากย้ายได้ เปิดเป็นหน้าต่างลอย ===== */
const HUD = {
  pos: null, open: null, winPos: {}, sel: {},  // sel = สิ่งที่เลือกอยู่ในแต่ละหน้าต่าง
  load(){ try{ Object.assign(this, JSON.parse(localStorage.getItem('kirana.hud')||'{}')); }catch(e){} for (const k of Object.keys(this.winPos||{})){ const p = this.winPos[k]; if (!p || !(p.x>=0) || !(p.y>=0) || (p.w!=null && !(p.w>0))) delete this.winPos[k]; } },
  persist(){ try{ localStorage.setItem('kirana.hud', JSON.stringify({pos:this.pos, winPos:this.winPos, open:this.open})); }catch(e){} },
  hide(){ const el = $('#hud'); if (el) clear(el); },
};
HUD.load();
/* ไอคอน SVG วาดเอง */
const HUD_ICONS = {
  bag: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><path d="M14 18h20l3 22H11z" fill="rgba(0,0,0,.25)"/><path d="M17 18v-3a7 7 0 0 1 14 0v3"/><path d="M11 24h26"/><path d="M19 30h10"/><circle cx="24" cy="34" r="1.6" fill="currentColor"/></svg>',
  book: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><path d="M10 10h13a4 4 0 0 1 4 4v24a4 4 0 0 0-4-4H10z" fill="rgba(0,0,0,.25)"/><path d="M38 10H25a4 4 0 0 0-4 4v24a4 4 0 0 1 4-4h13z" fill="rgba(0,0,0,.25)"/><path d="M15 17h6M15 22h6M27 17h6M27 22h6"/><path d="M24 14v24"/></svg>',
  pouch: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><path d="M16 20c-6 6-6 20 8 20s14-14 8-20z" fill="rgba(0,0,0,.25)"/><path d="M16 20c2-4 6-6 8-6s6 2 8 6"/><path d="M18 14l-2-5M30 14l2-5M24 13V8"/><path d="M15 20h18"/></svg>',
  dice: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><rect x="9" y="9" width="30" height="30" rx="6" fill="rgba(0,0,0,.25)"/><circle cx="17" cy="17" r="2.4" fill="currentColor"/><circle cx="31" cy="17" r="2.4" fill="currentColor"/><circle cx="24" cy="24" r="2.4" fill="currentColor"/><circle cx="17" cy="31" r="2.4" fill="currentColor"/><circle cx="31" cy="31" r="2.4" fill="currentColor"/></svg>',
  close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  grip: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.6"/><circle cx="15" cy="6" r="1.6"/><circle cx="9" cy="12" r="1.6"/><circle cx="15" cy="12" r="1.6"/><circle cx="9" cy="18" r="1.6"/><circle cx="15" cy="18" r="1.6"/></svg>',
};
function svgEl(name, cls){ const w = document.createElement('span'); w.className = 'ico' + (cls? ' '+cls : ''); w.innerHTML = HUD_ICONS[name]; return w; }
/* ลากด้วย pointer events: handle = ส่วนที่จับ, el = สิ่งที่ขยับ (position:fixed) */
function makeDraggable(el, handle, onEnd){
  let sx=0, sy=0, ox=0, oy=0, moved=false, id=null;
  handle.style.touchAction = 'none';
  let z = 1; // พิกัดเมาส์เป็นพิกัดจอ style.left/top เป็นพิกัดที่ถูก zoom (ดู uiZoom)
  handle.addEventListener('pointerdown', (e)=>{ if (e.button!==0 || e.target.closest('button,input,textarea,select')) return; id = e.pointerId; handle.setPointerCapture(id); z = uiZoom(); const r = el.getBoundingClientRect(); sx=e.clientX; sy=e.clientY; ox=r.left/z; oy=r.top/z; moved=false; el.classList.add('dragging'); e.preventDefault(); });
  handle.addEventListener('pointermove', (e)=>{ if (id==null || e.pointerId!==id) return; const dx=(e.clientX-sx)/z, dy=(e.clientY-sy)/z; if (Math.abs(dx)+Math.abs(dy) > 3) moved=true; const w = el.offsetWidth, hh = el.offsetHeight; const x = Math.max(4, Math.min(window.innerWidth/z - w - 4, ox+dx)), y = Math.max(4, Math.min(window.innerHeight/z - hh - 4, oy+dy)); el.style.left = x+'px'; el.style.top = y+'px'; el.style.right='auto'; el.style.bottom='auto'; });
  const up = (e)=>{ if (id==null) return; try{ handle.releasePointerCapture(id); }catch(x){} id=null; el.classList.remove('dragging'); if (moved && onEnd) onEnd({x: parseFloat(el.style.left), y: parseFloat(el.style.top)}); if (moved) el.dataset.justDragged = '1'; setTimeout(()=>{ delete el.dataset.justDragged; }, 50); };
  handle.addEventListener('pointerup', up); handle.addEventListener('pointercancel', up);
}
function renderHUD(c, d, ctx){
  let root = $('#hud'); if (!root){ root = h('div',{id:'hud'}); document.body.append(root); }
  clear(root);
  const eqW = equipWeight(c), bagW = bagWeight(c), totalW = eqW + bagW, over = totalW > d.capacity;
  const twin = isTwinborn(c); const bagW2 = twin ? listWeight(c.inventory2) : 0; const over2 = bagW2 > d.capacity; // แฝด: กระเป๋าร่าง B แยกจากร่าง A
  const sks = allSkills(c);
  const eqCount = Object.values(c.equip).filter(e=>e && (e.name||'').trim()).length;
  // ---- dock ----
  const dock = h('div',{class:'hud-dock'});
  const grip = h('div',{class:'hud-grip',title:'ลากเพื่อย้าย'}, svgEl('grip'));
  dock.append(grip);
  const mk = (key, icon, label, badge, badgeCls)=>{ const b = h('button',{class:'hud-btn'+(HUD.open===key?' on':''),title:label,onclick:()=>{ if (dock.dataset.justDragged) return; HUD.open = HUD.open===key ? null : key; HUD.persist(); renderHUD(c, d, ctx); }}, svgEl(icon), h('span',{class:'lbl',text:label}), badge!=null? h('span',{class:'badge'+(badgeCls?' '+badgeCls:''),text:String(badge)}):null); dock.append(b); };
  mk('bag', 'bag', 'กระเป๋า', `${totalW.toFixed(1)}/${d.capacity}`, (over || over2)?'neg':'');
  mk('book', 'book', 'คัมภีร์', sks.length);
  mk('pouch', 'pouch', 'ถุงย่าม', eqCount);
  if (ctx.dice) mk('dice', 'dice', 'ทอยเต๋า', RollLog.entries.length ? RollLog.entries[0].total : null, 'gold');
  if (HUD.pos){ dock.style.left = HUD.pos.x+'px'; dock.style.top = HUD.pos.y+'px'; dock.style.right='auto'; }
  root.append(dock);
  makeDraggable(dock, dock, (p)=>{ HUD.pos = p; HUD.persist(); });
  requestAnimationFrame(()=>{ // กันหลุดจอเมื่อขนาดหน้าต่างเปลี่ยน
    const r = dock.getBoundingClientRect(); if (r.right > window.innerWidth || r.bottom > window.innerHeight || r.left < 0 || r.top < 0){ HUD.pos = null; dock.style.left=''; dock.style.top=''; dock.style.right=''; } });
  if (!HUD.open) return;
  // ---- window ----
  const win = h('div',{class:'hud-win '+HUD.open});
  if (HUD.open==='dice' && !ctx.dice){ HUD.open=null; HUD.persist(); return; }
  const title = {bag:'กระเป๋าสัมภาระ', book:'คัมภีร์ทักษะ', pouch:'ถุงย่าม · ของสวมใส่', dice:'ทอยเต๋า'}[HUD.open];
  const head = h('div',{class:'hud-head'}, svgEl({bag:'bag',book:'book',pouch:'pouch',dice:'dice'}[HUD.open]), h('b',{text:title}), h('span',{class:'dim hud-sub'}), h('button',{class:'hud-x',title:'ปิด',onclick:()=>{ HUD.open=null; HUD.persist(); renderHUD(c, d, ctx); }}, svgEl('close')));
  const body = h('div',{class:'hud-body'});
  win.append(head, body);
  const wp = HUD.winPos[HUD.open]; if (wp){ win.style.left = wp.x+'px'; win.style.top = wp.y+'px'; win.style.right='auto'; if (wp.w) win.style.width = wp.w+'px'; if (wp.h) win.style.height = wp.h+'px'; }
  { const key = HUD.open; let first = true; new ResizeObserver(()=>{ if (first){ first=false; return; } if (!win.isConnected || !win.offsetWidth || !win.offsetHeight) return; /* หน้าต่างที่ถูกถอดจาก DOM มีขนาด 0 ห้ามจำ ไม่งั้นเด้งไปมุมซ้ายบน */ const rct = win.getBoundingClientRect(); const z = uiZoom(); const cur = HUD.winPos[key] || {x: Math.max(0, Math.round(rct.left/z)), y: Math.max(0, Math.round(rct.top/z))}; HUD.winPos[key] = {...cur, w: win.offsetWidth, h: win.offsetHeight}; HUD.persist(); }).observe(win); }
  root.append(win);
  makeDraggable(win, head, (p)=>{ HUD.winPos[HUD.open] = {...(HUD.winPos[HUD.open]||{}), ...p}; HUD.persist(); });
  hudCtx = ctx;
  const {save, rerender, txt, grow} = ctx;
  const refresh = ()=>{ save(); rerender(); };
  if (HUD.open==='bag') renderBagWin(c, d, body, head, {save, rerender, txt, grow, refresh, bagW, eqW, totalW, over, twin, bagW2, over2});
  else if (HUD.open==='book') renderBookWin(c, d, body, head, sks);
  else if (HUD.open==='dice'){ head.querySelector('.hud-sub').textContent = Table.roomId ? 'ผลทอยเด้งเข้าห้องที่เปิดอยู่' : 'ทอยส่วนตัว (ไม่ได้อยู่ในห้อง)'; const panel = dicePanel(c, (e)=>{ ctx.dice.onRoll(e); const btn = root.querySelector('.hud-btn[title="ทอยเต๋า"]'); if (btn){ let bd = btn.querySelector('.badge'); if (!bd){ bd = h('span',{class:'badge gold'}); btn.append(bd); } bd.textContent = String(e.total); } }, {guard: ctx.dice.guard}); panel.classList.remove('card'); panel.classList.add('hud-dice'); body.append(panel); }
  else renderPouchWin(c, d, body, head, {save, rerender, txt, grow, refresh, eqW});
  if (SheetUI.readOnly){ for (const el of win.querySelectorAll('input,textarea,select')) el.disabled = true; for (const b of win.querySelectorAll('.hud-body button')) b.disabled = true; }
  requestAnimationFrame(()=>{ const r = win.getBoundingClientRect(); if (r.right > window.innerWidth+2 || r.bottom > window.innerHeight+2 || r.left < 0){ delete HUD.winPos[HUD.open]; win.style.left=''; win.style.top=''; win.style.right=''; } });
}
/* ---- กระเป๋า: ตารางช่องของ + แถบน้ำหนัก + รายละเอียดของชิ้นที่เลือก ---- */
function renderBagWin(c, d, body, head, o){
  // แฝด (Twinborn): กระเป๋าแยกร่าง สลับด้วยแท็บ · ของสวมใส่ (ถุงย่าม) ยังเป็นชุดเดียว นับน้ำหนักที่ร่าง A
  const bodyKey = o.twin && HUD.bagBody==='B' ? 'B' : 'A'; const inv = bagOf(c, bodyKey); const isB = bodyKey==='B';
  head.querySelector('.hud-sub').textContent = `${inv.length} ชิ้น` + (o.twin ? ` · ร่าง ${bodyKey}` : '');
  if (o.twin) body.append(h('div',{class:'bagtabs'}, ['A','B'].map(k=>h('button',{class:'small bagtab'+(bodyKey===k?' primary':''),dataset:{body:k},title:`กระเป๋าของ${bodyName(c, k)}`,onclick:()=>{ HUD.bagBody = k; HUD.sel.bag = null; renderHUD(c, d, hudCtx); },text:`ร่าง ${k}${k==='A' ? ' · '+(c.name||'') : (((c.twinborn||{}).nameB||'').trim() ? ' · '+c.twinborn.nameB.trim() : '')} (${bagOf(c, k).length})`}))));
  const meter = isB
    ? h('div',{class:'hud-meter'+(o.over2?' over':'')}, h('div',{class:'bar'}, h('i',{style:`width:${Math.min(100, d.capacity? o.bagW2/d.capacity*100 : 0)}%`})), h('span',{class:'num',text:`แบก ${o.bagW2.toFixed(1)} / ${d.capacity} กก.`}), h('span',{class:'dim',text:'(กระเป๋าของร่าง B · ของสวมใส่นับที่ร่าง A)'}))
    : h('div',{class:'hud-meter'+(o.over?' over':'')}, h('div',{class:'bar'}, h('i',{style:`width:${Math.min(100, d.capacity? o.totalW/d.capacity*100 : 0)}%`})), h('span',{class:'num',text:`แบก ${o.totalW.toFixed(1)} / ${d.capacity} กก.`}), h('span',{class:'dim',text:`(ย่าม ${o.eqW.toFixed(1)} · กระเป๋า ${o.bagW.toFixed(1)})`}));
  body.append(meter);
  const detailHost = h('div',{class:'hud-detail-host'}); body.append(detailHost); // รายละเอียดขึ้นหัวป๊อปอัป ไม่ต้องเลื่อนลงไปหาท้ายตาราง
  const grid = h('div',{class:'hud-grid'});
  const selIdx = HUD.sel.bag;
  inv.forEach((row,i)=>{
    const guess = isB ? null : itemSlot(row.name, row.effect);
    const t = h('div',{class:'tile'+(selIdx===i?' sel':'')+(guess?' wearable':''),tabindex:0,onclick:()=>{ HUD.sel.bag = selIdx===i ? null : i; renderHUD(c, d, hudCtx); }}, h('div',{class:'nm',text:row.name||'(ไม่มีชื่อ)'}), (row.qty||1)>1? h('span',{class:'qty',text:'×'+row.qty}):null, isFleshforgeItem(c, row.name) ? h('span',{class:'ffbadge',title:'ไอเทมมีชีวิตของ Fleshforge',text:'🧬'}) : null, h('span',{class:'wt',text:(row.weight||0)+' กก.'}));
    grid.append(t);
  });
  grid.append(h('div',{class:'tile add',tabindex:0,onclick:()=>{ inv.push({name:'',effect:'',qty:1,weight:0}); HUD.sel.bag = inv.length-1; o.refresh(); }}, h('div',{class:'plus',text:'+'}), h('div',{class:'nm dim',text:'เพิ่มของ'})));
  body.append(grid);
  const row = inv[selIdx];
  if (row){
    const guess = isB ? null : itemSlot(row.name, row.effect); const gslot = guess==='weapon' ? (c.equip.weapon1 && c.equip.weapon1.name ? 'weapon2' : 'weapon1') : guess;
    const slotSel = isB ? h('span',{class:'dim',style:'font-size:11.5px',text:'จะสวมต้องย้ายไปกระเป๋าร่าง A ก่อน (ของสวมใส่ใช้ชุดเดียว)'}) : h('select',null, h('option',{value:'',text:'สวมที่ช่อง…'}), EQUIP_SLOTS.map(([k,l])=>h('option',{value:k,text:l})));
    if (!isB) slotSel.onchange = ()=>{ if (!slotSel.value) return; wearItem(c, selIdx, slotSel.value); HUD.sel.bag=null; o.refresh(); };
    // ย้ายของข้ามกระเป๋าของแฝด (ทั้งกอง) รวมกองถ้าเป็นของเดียวกัน
    const otherKey = isB ? 'A' : 'B';
    const moveBtn = o.twin ? h('button',{class:'small movebtn',title:`ย้ายของชิ้นนี้ไปกระเป๋าของ${bodyName(c, otherKey)}`,onclick:()=>{ const dst = bagOf(c, otherKey); const same = dst.find(x=>x.name===row.name && (x.effect||'')===(row.effect||'') && +x.weight===+row.weight); if (same) same.qty = (same.qty||1) + (row.qty||1); else dst.push(row); inv.splice(selIdx,1); HUD.sel.bag=null; o.refresh(); },text:`⇄ ย้ายไปร่าง ${otherKey}`}) : null;
    detailHost.append(h('div',{class:'hud-detail top'}, h('div',{class:'kicker',text:'ของที่เลือก'}),
      h('div',{class:'row',style:'gap:6px;align-items:center'}, o.txt(row,'name','ชื่อไอเทม'), h('label',{class:'dim',text:'×'}), h('input',{type:'number',value:row.qty,style:'width:58px',onchange:(e)=>{row.qty=+e.target.value||0; o.refresh();}}), h('label',{class:'dim',text:'กก.'}), h('input',{type:'number',step:'0.1',value:row.weight,style:'width:70px',onchange:(e)=>{row.weight=+e.target.value||0; o.refresh();}})),
      o.grow(o.txt(row,'effect','คุณสมบัติ / ผลของไอเทม',true)),
      h('div',{class:'row',style:'gap:6px;margin-top:6px'}, gslot? h('button',{class:'small primary',onclick:()=>{ wearItem(c, selIdx, gslot); HUD.sel.bag=null; o.refresh(); },text:'สวม → '+EQUIP_SLOTS.find(x=>x[0]===gslot)[1]}):null, slotSel, moveBtn, h('button',{class:'small ghost',style:'margin-left:auto',onclick:()=>{ if (!confirm(`ทิ้ง "${row.name}"?`)) return; inv.splice(selIdx,1); HUD.sel.bag=null; o.refresh(); },text:'ทิ้ง'}))));
  } else detailHost.append(h('p',{class:'dim hud-hint',text:'แตะช่องเพื่อดูรายละเอียด สวม หรือแก้ไข'}));
}
/* ---- คัมภีร์: หน้าซ้ายสารบัญ หน้าขวารายละเอียด ---- */
function renderBookWin(c, d, body, head, sks){
  head.querySelector('.hud-sub').textContent = `${sks.length} ทักษะ`;
  if (!HUD.sel.book || !sks.includes(HUD.sel.book)) HUD.sel.book = sks[0] || null;
  const left = h('div',{class:'page toc'});
  const groups = {};
  for (const n of sks){ const sk = SKILL_BY_NAME[n]; const g = sk ? (sk.category==='Sorcery' ? sk.subcategory : (sk.subcategory||sk.category||'อื่น ๆ')) : 'อื่น ๆ'; (groups[g] = groups[g]||[]).push(n); }
  for (const [g, names] of Object.entries(groups)){
    left.append(h('div',{class:'toc-h',text:g}));
    for (const n of names){ const sk = SKILL_BY_NAME[n]; left.append(h('button',{class:'toc-i'+(HUD.sel.book===n?' on':''),onclick:()=>{ HUD.sel.book = n; renderHUD(c, d, hudCtx); }}, h('span',{class: sk ? hueCls(sk.nameEn, sk.type, sk.effect).trim() : '', text:n}), sk && sk.cost? h('span',{class:'dim',text:sk.cost}):null)); }
  }
  if (!sks.length) left.append(h('div',{class:'dim',text:'ยังไม่มีทักษะ ใช้ Insight Point ซื้อได้ที่หน้าชีท'}));
  if (c.talent) left.append(h('div',{class:'toc-h',style:'margin-top:10px',text:'Talent'}), h('div',{class:'dim',style:'font-size:12px',text:DATA.talents.find(t=>t.key===c.talent).label}));
  const right = h('div',{class:'page detail'});
  const n = HUD.sel.book; const sk = n ? SKILL_BY_NAME[n] : null;
  if (sk){
    right.append(...[h('h3',{class: hueCls(sk.nameEn, sk.type, sk.effect).trim()}, sk.nameEn, h('span',{class:'en',text:' '+(sk.nameTh||'')})),
      h('div',{class:'gives'}, tag(sk.subcategory, sk.category==='Sorcery'?'prop':''), sk.tier? tag(sk.tier, sk.tier==='Master'?'neg':sk.tier==='Expert'?'warn':'ok'):null, sk.type? tag(sk.type.length>40? sk.type.slice(0,40)+'…' : sk.type):null, sk.cost? tag('Cost '+sk.cost,'stat'):null, sk.components? tag('Comp '+sk.components):null, sk.ipCost!=null? tag(sk.ipCost+' IP'):null),
      h('div',{class:'txt'}, h('b',{text:'Effect '}), T(sk.effect||'')),
      sk.condition? h('div',{class:'txt lim'}, h('b',{text:'Limitation '}), T(sk.condition)) : null,
      sk.extra&&sk.extra.length? h('div',{class:'txt'}, sk.extra.map(x=>h('div',{class:'desc'}, T(x)))) : null,
      sk.branch? h('div',{class:'dim',style:'font-size:11px;margin-top:8px',text:sk.branch}) : null].filter(Boolean));
  } else if (n) right.append(h('h3',{text:n}), h('p',{class:'dim',text:'ไม่พบรายละเอียดในฐานข้อมูลสกิล'}));
  body.append(h('div',{class:'book'}, left, right));
}
/* ---- ถุงย่าม: หุ่นสวมใส่ (paper doll) + รายละเอียดช่องที่เลือก ---- */
const DOLL_LAYOUT = [ // [slot, column(1-3), row] — อาวุธและโล่แยกไปอยู่ "สายคาดอาวุธ" ด้านบน
  ['head',2,1], ['neck',3,1], ['cape',1,1],
  ['shirt',2,2], ['back',3,2],
  ['chestIn',2,3], ['hands',1,3],
  ['chestOut',2,4], ['waist',3,4],
  ['legs',2,5], ['feet',2,6],
];
const WEAPON_SLOTS = ['weapon1','weapon2','shield'];
/* สายคาดอาวุธ: อาวุธสองมือและโล่ เห็นชัดและกดดูได้ ใช้ทั้งในถุงย่ามและในชีท */
function weaponBoard(c, d, onPick, sel){
  const board = h('div',{class:'wboard'});
  for (const k of WEAPON_SLOTS){
    const e = c.equip[k]; const filled = e && (e.name||'').trim();
    const eff = filled ? String(e.effect||'') : '';
    const dmg = (eff.match(/(\d+)\s*PDMG/)||[])[1]; const props = weaponPropsText(eff).split('·')[0].trim();
    const need = filled ? weaponStrNeed(eff) : 0; const short = need && weaponStrShort(eff, d); // v1.15: STR ไม่ถึง = โจมตีด้วยอาวุธนี้ติด Disadvantage
    board.append(h('div',{class:'wslot'+(filled?' filled':'')+(sel===k?' sel':'')+(k==='shield'?' shield':''), tabindex:0, onclick: onPick ? ()=>onPick(k) : null},
      h('div',{class:'sl',text: k==='shield' ? 'โล่ / มือรอง' : k==='weapon1' ? 'อาวุธหลัก' : 'อาวุธรอง'}),
      h('div',{class:'nm',text: filled ? e.name.replace(/\s*\(.*?\)\s*/g,' ').trim() : '— ว่าง —'}), filled && isFleshforgeItem(c, e.name) ? h('span',{class:'ffbadge',title:'ไอเทมมีชีวิตของ Fleshforge',text:'🧬'}) : null,
      filled ? h('div',{class:'ef'}, dmg ? h('b',{text:dmg+' PDMG'}) : null, dmg ? ' ' : '', props.length>60 ? props.slice(0,60)+'…' : props) : h('div',{class:'ef dim',text:'เปิดกระเป๋าแล้วกด "สวม"'}),
      need ? h('div',{class:'strreq'+(short?' short':''),title:'หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage',text: short ? `STR ${need} ไม่ถึง: โจมตีติด Disadvantage` : `ต้องมี STR ${need}`}) : null,
      filled && e.weight ? h('span',{class:'wt',text:e.weight+' กก.'}) : null));
  }
  return board;
}
const DOLL_LABEL = {weapon1:'Weapon 1', weapon2:'Weapon 2', shield:'Shield', head:'Head', neck:'Neck', back:'Back', shirt:'Shirt', chestIn:'Chest (In)', chestOut:'Chest (Out)', hands:'Hands', waist:'Waist', legs:'Legs', feet:'Feet', cape:'Cape'};
function renderPouchWin(c, d, body, head, o){
  head.querySelector('.hud-sub').textContent = `${o.eqW.toFixed(1)} กก. · Parry Dice ${d.parryDice}`;
  const detailHost = h('div',{class:'hud-detail-host'}); body.append(detailHost);
  body.append(h('div',{class:'kicker',style:'margin-bottom:4px',text:'สายคาดอาวุธ'}), weaponBoard(c, d, (k)=>{ HUD.sel.pouch = HUD.sel.pouch===k ? null : k; renderHUD(c, d, hudCtx); }, HUD.sel.pouch));
  body.append(h('div',{class:'kicker',style:'margin:8px 0 4px',text:'เครื่องสวมใส่'}));
  const doll = h('div',{class:'doll'});
  doll.innerHTML = '<svg class="sil" viewBox="0 0 120 300" aria-hidden="true"><ellipse cx="60" cy="30" rx="18" ry="22"/><path d="M42 58h36l14 20v70l-10 6V98h-6v70l8 110h-20l-8-90-8 90H28l8-110V98h-6v56l-10-6V78z"/></svg>';
  const sel = HUD.sel.pouch;
  for (const [k,col,row] of DOLL_LAYOUT){
    const label = EQUIP_SLOTS.find(x=>x[0]===k)[1]; const e = c.equip[k];
    const filled = e && (e.name||'').trim();
    doll.append(h('div',{class:'dslot'+(filled?' filled':'')+(sel===k?' sel':''),style:`grid-column:${col};grid-row:${row}`,tabindex:0,onclick:()=>{ HUD.sel.pouch = sel===k ? null : k; renderHUD(c, d, hudCtx); }}, h('div',{class:'sl',text:DOLL_LABEL[k]||label}), h('div',{class:'nm',text: filled? e.name : '—'}), filled && e.weight? h('span',{class:'wt',text:e.weight+' กก.'}):null));
  }
  body.append(doll);
  body.append(h('div',{class:'row',style:'justify-content:space-between;margin-top:6px'}, h('span',{class:'dim',style:'font-size:12px',text:'แตะช่องเพื่อดู แก้ หรือถอด · ของในกระเป๋ากด "สวม" ได้จากหน้าต่างกระเป๋า'}), h('button',{class:'small ghost',onclick:()=>{ if (!confirm('ถอดทุกชิ้นกลับกระเป๋าแล้วสวมใหม่อัตโนมัติ?')) return; autoEquip(c); o.refresh(); },text:'สวมอัตโนมัติ'})));
  if (sel){
    const e = c.equip[sel]; const label = EQUIP_SLOTS.find(x=>x[0]===sel)[1];
    if (e){
      detailHost.append(h('div',{class:'hud-detail top'}, h('div',{class:'kicker',text:label}),
        h('div',{class:'row',style:'gap:6px;align-items:center'}, o.txt(e,'name','ชื่อไอเทม'), h('label',{class:'dim',text:'กก.'}), h('input',{type:'number',step:'0.1',value:e.weight||0,style:'width:70px',onchange:(ev)=>{ e.weight=+ev.target.value||0; recalcParry(c); o.refresh(); }})),
        o.grow(o.txt(e,'effect','คุณสมบัติ',true)),
        h('div',{class:'row',style:'margin-top:6px'}, h('button',{class:'small',onclick:()=>{ unequip(c, sel); HUD.sel.pouch=null; o.refresh(); },text:'ถอดกลับกระเป๋า'}))));
    } else {
      const cands = c.inventory.map((r,i)=>({r,i})).filter(x=>{ const g = itemSlot(x.r.name, x.r.effect); return g && (g===sel || (g==='weapon' && /^weapon/.test(sel))); });
      detailHost.append(h('div',{class:'hud-detail top'}, h('div',{class:'kicker',text:label+' · ว่าง'}),
        cands.length ? h('div',{class:'row',style:'gap:6px;flex-wrap:wrap'}, h('span',{class:'dim',style:'font-size:12px',text:'ในกระเป๋ามี:'}), cands.map(x=>h('button',{class:'small',onclick:()=>{ wearItem(c, x.i, sel); o.refresh(); },text:'สวม '+x.r.name}))) : null,
        h('div',{class:'row',style:'margin-top:6px'}, h('button',{class:'small ghost',onclick:()=>{ c.equip[sel]={name:'',effect:'',weight:0}; o.refresh(); },text:'+ เขียนของใหม่ลงช่องนี้'}))));
    }
  }
}
let hudCtx = null;
