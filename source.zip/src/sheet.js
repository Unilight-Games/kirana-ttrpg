/* ===== Character list + sheet + dice ===== */
let charsQuery = '';
function renderChars(){
  const root = clearKeep($('#v-chars'));
  const q = h('input',{class:'charsearch',placeholder:'ค้นหาชื่อ วงศา หรือชุดเริ่มต้น',value:charsQuery,oninput:(e)=>{ charsQuery = e.target.value; drawLists(); }});
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'ตัวละครของฉัน'}), h('p',{text: Store.online ? 'ชีทเป็นของบัญชีคุณคนเดียว GM กับเพื่อนร่วมโต๊ะจะเห็นก็ต่อเมื่อคุณหยิบตัวละครลงบอร์ดในห้องนั้น' : 'เก็บไว้ในเบราว์เซอร์นี้ ส่งออกเป็น JSON ไว้ย้ายเครื่องได้'})),
    h('div',{class:'row'}, q, h('button',{class:'primary',onclick:()=>{ startWizard(null); location.hash='#wizard'; },text:'+ สร้างตัวละครใหม่'}), h('button',{onclick:importChar,text:'นำเข้า JSON'}))));
  const host = h('div'); root.append(host);
  const match = (c)=>{ const k = charsQuery.trim().toLowerCase(); if (!k) return true; const kin = c.kin ? KIN[c.kin] : null; return [c.name, kin && kin.name, c.starterSet, c.talent, c.ownerName].filter(Boolean).some(x=>String(x).toLowerCase().includes(k)); };
  const card = (c)=>{ const d=compute(c); const kin=c.kin?KIN[c.kin]:null;
    const portrait = c.portrait ? h('img',{class:'portrait',src:c.portrait,alt:c.name||'',onclick:()=>{ if (c.done) location.hash='#sheet-'+c.id; }}) : h('div',{class:'portrait ph',text:(c.name||'?').slice(0,1)});
    return h('div',{class:'card charcard'}, portrait, h('div',null,
      h('h3',{style:'margin:0'}, c.name||'(ยังไม่ตั้งชื่อ)', h('span',{class:'en',text: kin? kin.name : 'ร่าง'})),
      h('div',{class:'gives'}, c.done? tag('พร้อมเล่น','ok') : tag(`ร่าง ขั้น ${(c.step||0)+1}/8`,'warn'), c.starterSet? tag(c.starterSet,'prop'):null, c.talent? tag('Talent '+c.talent):null, Store.inCampaign(c)? tag('อยู่ในแคมเปญ','neg'):null),
      kin? h('div',{class:'statgrid'}, STATS.map(s=>h('div',{class:'statbox'}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:d.raw[s]}), h('div',{class:'m num',text:signed(d.mod[s])})))) : null,
      h('div',{class:'row',style:'margin-top:8px'}, c.done? h('button',{class:'primary small',onclick:()=>{location.hash='#sheet-'+c.id;},text:'เปิดชีท'}):null, (c.done && Store.inCampaign(c) && !Store.isDevUid) ? h('button',{class:'small',disabled:true,title:'ตัวละครอยู่ในแคมเปญแล้ว ค่าพื้นฐานล็อก เติบโตผ่าน IP และแก้รายละเอียดได้ในชีท',text:'🔒 อยู่ในแคมเปญ'}) : h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#wizard'; },text:c.done?'แก้ไขในวิซาร์ด':'ทำต่อ'}), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}), h('button',{class:'small ghost danger',onclick:()=>{ if(confirm(`ลบ ${c.name||'ตัวละครนี้'} ถาวร?${Store.inCampaign(c) ? ' สำเนาในห้องและหมากบนบอร์ดจะถูกถอนออกด้วย' : ''}`)){ Store.remove(c.id); toast('ลบตัวละครแล้ว'); } renderChars(); },text:'ลบ'}), !Store.isMine(c) && Store.isDevUid ? h('button',{class:'small ghost',title:'ย้ายตัวละครนี้มาเป็นของบัญชีผู้พัฒนา',onclick:()=>{ if(!confirm(`อ้างสิทธิ์ ${c.name} มาเป็นของคุณ?`)) return; c.ownerId = Store.me; Store.upsert(c); renderChars(); },text:'อ้างสิทธิ์'}) : null),
      !Store.isMine(c) ? h('div',{class:'dim',style:'font-size:12px;margin-top:4px',text:'เจ้าของ: '+(c.ownerName||c.ownerId||'?')}) : null));
  };
  function drawLists(){
    clear(host);
    const mine = Store.chars.filter(c=>Store.isMine(c)); const others = Store.chars.filter(c=>!Store.isMine(c));
    const fm = mine.filter(match), fo = others.filter(match);
    if (!mine.length && !others.length){ host.append(h('div',{class:'card',text:'ยังไม่มีตัวละคร เริ่มจากปุ่มสร้างตัวละครใหม่'})); return; }
    if (charsQuery.trim() && !fm.length && !fo.length){ host.append(h('div',{class:'card dim',text:`ไม่พบตัวละครที่ตรงกับ "${charsQuery.trim()}"`})); return; }
    if (fm.length) host.append(h('div',{class:'grid wide'}, fm.map(card)));
    if (fo.length){ host.append(h('h3',{style:'margin:18px 0 8px',text:'ตัวละครของผู้เล่นคนอื่น (มุมมองผู้พัฒนา)'})); host.append(h('div',{class:'grid wide'}, fo.map(card))); }
  }
  drawLists();
}
function exportChar(c){
  const txt = JSON.stringify(c, null, 1);
  const ta = h('textarea',{style:'min-height:300px;font-family:monospace;font-size:12px'}); ta.value = txt;
  modal(h('div',null, h('h3',{text:'ส่งออกตัวละคร (คัดลอกข้อความนี้ไปเก็บ)'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ navigator.clipboard.writeText(txt).then(()=>toast('คัดลอกแล้ว')).catch(()=>toast('คัดลอกไม่ได้ เลือกข้อความแล้วคัดลอกเอง')); },text:'คัดลอก'}))));
}
function importChar(){
  const ta = h('textarea',{style:'min-height:240px;font-family:monospace;font-size:12px',placeholder:'วาง JSON ของตัวละครที่นี่'});
  modal(h('div',null, h('h3',{text:'นำเข้าตัวละคร'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ try{ const c=JSON.parse(ta.value); if(!c || !c.id || !('kin' in c)) throw new Error('bad'); const restoringMine = !!(Store.me && c.ownerId === Store.me) && !Store.get(c.id); if (!restoringMine) c.id = uid(); /* สำเนาของคนอื่นต้องได้ id ใหม่ ไม่งั้นชนกับเอกสารของเจ้าของเดิมบนเว็บ */ c.ownerId = Store.me||null; delete c.synced; c.roomIds = restoringMine ? (c.roomIds||[]) : []; Store.upsert(c); modal(null); renderChars(); toast('นำเข้าแล้ว'); } catch(e){ toast('อ่าน JSON ไม่ได้'); } },text:'นำเข้า'}))));
}

/* ---- Dice panel (ใช้ร่วมกันทั้งชีทและโต๊ะ) ---- */
const RollLog = { entries: [], add(e){ this.entries.unshift(e); if (this.entries.length>60) this.entries.pop(); } };
function doRoll({label, mod=0, persSide=null, c=null, dc=null, mode='normal', kind='check', r=null}){
  r = r || roll2d6(mode);
  let pm = 0; if (persSide && c) pm = persMod(c, persSide);
  const total = r.sum + mod + pm;
  const j = kind==='luck' ? (total>=8 ? {cls:'res-full',text:'โชคเข้าข้าง (8+)'} : {cls:'res-fail',text:'โชคไม่เข้าข้าง'})
    : kind==='attack' ? {cls: r.double?'res-crit':'res-part', text: r.double? `Perfect Strike (คู่ ${r.kept[0]})` : `CV ${r.sum}`}
    : (kind==='parry' || kind==='evade') ? judgeDefense(total, dc, kind)
    : judge(total, r, dc);
  const e = {ts:Date.now(), label, r, mod, pm, persSide, total, judge:j, mode, dc, kind, who: c? c.name : ''};
  RollLog.add(e);
  return e;
}
/* ทอยหลายลูกแล้วให้ผู้เล่นเลือกเอง 2 ลูก (Parry ที่มี Parry Dice / Parry-Evade แบบ Advantage) */
function rollChoose(n, mode, title){
  const dice = Array.from({length:n}, rollD6);
  return new Promise(resolve => {
    const sel = new Set();
    const btns = dice.map((v,i)=>h('button',{class:'bigdie pickdie',onclick:()=>{ if (sel.has(i)) sel.delete(i); else { if (sel.size>=2) return; sel.add(i); } btns.forEach((b,j)=>b.classList.toggle('sel', sel.has(j))); ok.disabled = sel.size!==2; }}, h('span',{text:String(v)})));
    const ok = h('button',{class:'primary',disabled:true,onclick:()=>{ const idx=[...sel].sort((a,b)=>a-b); const kept = idx.map(i=>dice[i]); finish({dice, kept, keptIdx: idx, sum: kept[0]+kept[1], crit: kept[0]===6&&kept[1]===6?'success':(kept[0]===1&&kept[1]===1?'failure':null), double: kept[0]===kept[1], mode, chosen:true}); },text:'ใช้ 2 ลูกนี้'});
    const finish = (r)=>{ modal(null); resolve(r); };
    const box = h('div',{class:'pickbox'}, h('h3',{text:title||'เลือกเต๋า 2 ลูก'}), h('p',{class:'desc',text:`ทอยได้ ${n} ลูก เลือก 2 ลูกที่จะใช้ (จะเอาสูงสุด หรือเอาให้เท่ากับผลโจมตีของอีกฝ่ายเพื่อ Perfect ก็ได้)`}), h('div',{class:'dice-row'}, btns), h('div',{class:'row',style:'justify-content:center;margin-top:10px'}, ok));
    modal(box);
    const m = $('#modal'); m.onclick = ()=>{}; // ห้ามปิดด้วยการคลิกข้างนอก ต้องเลือกให้ครบ
    const closeBtn = m.querySelector('.box > .row:last-child'); if (closeBtn) closeBtn.remove();
  });
}
function rollEntryEl(e){
  const parts = [`2d6 ${e.r.kept[0]}+${e.r.kept[1]}`]; if (e.mod) parts.push(`Mod ${signed(e.mod)}`); if (e.pm) parts.push(`${e.persSide} ${signed(e.pm)}`);
  return h('div',{class:'e'}, h('div',{class:'row',style:'gap:6px'}, e.who? h('span',{class:'who',text:e.who}):null, h('b',{text:e.label}), e.mode!=='normal'? tag(e.mode==='adv'?'Advantage':'Disadvantage', e.mode==='adv'?'ok':'neg'):null, e.r.chosen? tag('เลือกลูกเอง','prop'):null, e.dc!=null? tag((e.kind==='parry'||e.kind==='evade')?'โจมตีมา '+e.dc:'DC '+e.dc):null),
    h('div',{class:'row',style:'gap:8px;margin-top:2px'}, renderDice(e.r), h('span',{class:'dim num',text:parts.join(' ')}), h('b',{class:'num',text:'= '+e.total}), h('span',{class:e.judge.cls,text:e.judge.text})));
}
function dicePanel(c, onRoll, opts={}){ // opts.guard(run) = ด่านล็อกการทอยของโต๊ะ, opts.noLog = ไม่แสดงบันทึกในแผง
  const st = {mode:'normal', pers:'', dc:''};
  const box = h('div',{class:'card dicepanel'});
  const modeBtns = h('div',{class:'row'}, ['normal','adv','dis'].map(m=>h('button',{class:'small'+(st.mode===m?' primary':''), onclick:(e)=>{ st.mode=m; for (const b of modeBtns.children) b.classList.toggle('primary', b.dataset.m===m); }, dataset:{m}, text: m==='normal'?'ปกติ 2d6':m==='adv'?'Advantage 3d6↑':'Disadvantage 3d6↓'})));
  const persSel = h('select',{onchange:(e)=>{st.pers=e.target.value;}}, h('option',{value:'',text:'ไม่บวกบุคลิกภาพ'}), DATA.meta.personality.flatMap(ax=>[ax.left, ax.right]).map(s=>h('option',{value:s, text: c? `${s} (${signed(persMod(c,s))})` : s})));
  const dcInp = h('input',{type:'number',placeholder:'DC / ผลโจมตีที่ต้องกัน (ว่าง = ไม่ตัดสิน)',style:'width:230px',oninput:(e)=>{st.dc=e.target.value;}});
  box.append(h('h3',{text:'ทอยเต๋า'}), h('div',{class:'row',style:'margin:8px 0'}, modeBtns), h('div',{class:'row',style:'margin-bottom:8px'}, persSel, dcInp));
  const log = h('div',{class:'log'});
  const refresh = ()=>{ clear(log); if(!RollLog.entries.length) log.append(h('div',{class:'dim',text:'ยังไม่มีการทอย'})); for (const e of RollLog.entries.slice(0,30)) log.append(rollEntryEl(e)); };
  const dcInp2 = ()=> st.dc===''?null:+st.dc;
  const fire = (label, mod, kind)=>{
    const run = ()=>{
      // Parry: เต๋า = 2 + Parry Dice (+1 เมื่อ Advantage) เลือกเอง 2 ลูก · Disadvantage = 2d6 เปล่า ๆ ไม่ได้ Parry Dice · Evade Advantage = 3d6 เลือกเอง
      let n = 0;
      if (kind==='parry'){ const pd = c ? compute(c).parryDice : 0; n = st.mode==='dis' ? 2 : 2 + pd + (st.mode==='adv'?1:0); }
      else if (kind==='evade' && st.mode==='adv') n = 3;
      if (n > 2){
        const title = kind==='parry' ? `Parry: ทอย ${n}d6 เลือก 2 ลูก` : `Evade (Advantage): ทอย 3d6 เลือก 2 ลูก`;
        return rollChoose(n, st.mode, title).then(r => { const e = doRoll({label, mod, persSide: st.pers||null, c, dc: dcInp2(), mode: st.mode, kind, r}); refresh(); if (onRoll) onRoll(e); return e; });
      }
      const mode = (kind==='parry' && st.mode==='dis') ? 'normal' : st.mode;
      const e = doRoll({label: label + (kind==='parry' && st.mode==='dis' ? ' (Disadvantage: 2d6 ไม่ใช้ Parry Dice)' : ''), mod, persSide: st.pers||null, c, dc: dcInp2(), mode, kind}); refresh(); if (onRoll) onRoll(e); return e;
    };
    if (opts.guard) opts.guard(run, label); else run();
  };
  if (c){ const d = compute(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, STATS.map(s=>h('button',{class:'small rollbtn',onclick:()=>fire(`${s} Check`, d.mod[s]), text:`${s} ${signed(d.mod[s])}`}))));
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small rollbtn',onclick:()=>fire('Initiative', d.initiative),text:`Initiative ${signed(d.initiative)}`}), h('button',{class:'small rollbtn',onclick:()=>{ const blk = (typeof Table!=='undefined' && Table.attackBlocked) ? Table.attackBlocked(c) : null; if (blk){ toast(blk); return; } fire('Attack Roll (Combat Dice)', 0, 'attack'); },text:'Attack 2d6 (CV)'}), h('button',{class:'small rollbtn',onclick:()=>fire('Parry', 0, 'parry'),text:`Parry ${2+d.parryDice}d6`}), h('button',{class:'small rollbtn',onclick:()=>fire('Evade (Reflex)', d.reflex, 'evade'),text:`Evade ${signed(d.reflex)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('VIT Saving Throw', d.fortitude),text:`VIT ST ${signed(d.fortitude)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('PER Saving Throw', d.will),text:`PER ST ${signed(d.will)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('Luck Saving Throw', 0, 'luck'),text:'Luck (8+)'})));
    const kl = knowledgeLevels(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, DATA.knowledge.map(k=>{ const kb2 = knowledgeBonus(c, d, k); return h('button',{class:'small ghost rollbtn',title:`ระดับความรู้ ${kb2.lv} (บวกบุคลิกภาพได้ด้วยตัวเลือกด้านบน)`,onclick:()=>fire(`${k.nameEn} Check (Lv${kb2.lv})`, kb2.total),text:`${k.nameEn} ${signed(kb2.total)}`}); })));
  } else {
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small rollbtn',onclick:()=>fire('2d6',0),text:'ทอย 2d6'}), h('button',{class:'small rollbtn',onclick:()=>fire('Luck Saving Throw',0,'luck'),text:'Luck (8+)'}), h('button',{class:'small rollbtn',onclick:()=>fire('Attack Roll',0,'attack'),text:'Attack 2d6'})));
  }
  const custom = h('input',{type:'number',placeholder:'Mod',style:'width:80px'});
  box.append(h('div',{class:'row',style:'margin-bottom:8px'}, custom, h('button',{class:'small rollbtn',onclick:()=>fire('ทอยกำหนดเอง', +custom.value||0),text:'ทอย 2d6 + Mod'})));
  if (!opts.noLog){ box.append(log); refresh(); }
  return box;
}

/* ---- Sheet (โครงตามชีท Duck Family: ซ้าย=ภาพ/ทรัพยากร, กลาง=ตัวตน/นิสัย/Trait/สกิล/ของ, ขวา=STATUS/บุคลิก/Combat Mod/ความรู้/เต๋า) ---- */
const SheetUI = { drawer: null };
const EQUIP_SLOTS = [['weapon1','Weapon 1 อาวุธหลัก'],['weapon2','Weapon 2 อาวุธสำรอง'],['shield','Shield โล่'],['head','Head'],['neck','Neck'],['back','Back'],['shirt','Shirt'],['chestIn','Chest (In)'],['chestOut','Chest (Out)'],['hands','Hands & Wrists'],['waist','Waist'],['legs','Legs'],['feet','Feet'],['cape','Cape']];
/* จัดช่องสวมใส่จากชื่อ/คุณสมบัติของไอเทม (ไฟล์ Starter Set ไม่ระบุช่อง) */
function itemSlot(name, effect){
  const n = name||'', e = effect||'';
  const has = (re)=>re.test(n);
  if (has(/โล่|Shield/i)) return 'shield';
  if (has(/หมวก|Helm|หน้ากาก|Mask|Hat\b|Coif|Beanie|Beret|Cap\b|Chaperon|Browband/i)) return 'head';
  if (has(/ถุงมือ|Gloves|ปลอกแขน|Bracers|แหวน|Ring\b/i)) return 'hands';
  if (has(/รองเท้า|Boots|Sandals/i)) return 'feet';
  if (has(/เข็มขัด|Belt/i)) return 'waist';
  if (has(/ผ้าคลุม|เสื้อคลุมมีฮู้ด|Cloak|Cape|Poncho/i)) return 'cape';
  if (has(/กางเกง|กระโปรง|Trousers|Breeches|Skirt/i)) return 'legs';
  if (has(/แกมเบสัน|Gambeson/i) || /ชั้นใน Armor/.test(e)) return 'chestIn';
  if (has(/เกราะ|Armor|โค้ท|Coat|เสื้อกั๊ก|Vest|เอี๊ยม|Apron|Robe|เสื้อคลุม/i)) return 'chestOut';
  if (has(/ทูนิค|Tunic|เชิ้ต|Shirt/i)) return 'shirt';
  if (has(/กระเป๋า|Satchel|Backpack|เป้/i)) return 'back';
  if (has(/สัญลักษณ์ศักดิ์สิทธิ์|Holy Symbol|สร้อย|Amulet|Necklace/i)) return 'neck';
  if (/\d\s*[PM]DMG|Might\s*\(/.test(e)) return 'weapon';
  return null;
}
/* ของสวมใส่ = {name, effect, weight} ต่อช่อง น้ำหนักนับรวมกับกระเป๋า · สวมแล้วย้ายออกจากกระเป๋า (ไม่นับซ้ำ) */
function equipWeight(c){ return Object.values(c.equip||{}).reduce((a,e)=>a + (e && e.weight ? +e.weight : 0), 0); }
function bagWeight(c){ return (c.inventory||[]).reduce((a,r)=>a + (r.qty||0)*(r.weight||0), 0); }
/* ค่า Armor ต่ออวัยวะจากของสวมใส่: รูปแบบในไฟล์ "Armor A/B (ชนิด)" = A กันกายภาพทั่วไป, B กันชนิดในวงเล็บ (ส่วนใหญ่ Blunt) · "Main Armor n ที่ลำตัว" (เข็มขัดโซ่) ไม่ทบกับเกราะลำตัว ใช้ค่าที่สูงกว่า (ข้อเคาะ 8 ของ Starter Set) · ชั้นใน + ชั้นนอกบวกกัน */
const ARMOR_SLOT_PARTS = {head:['head'], shirt:['torso'], chestIn:['torso'], chestOut:['torso'], cape:[], back:[], neck:[], hands:['armL','armR'], legs:['legL','legR'], feet:['legL','legR'], waist:['torso'], weapon1:[], weapon2:[], shield:[]};
function parseArmor(effect){ const m = /Armor\s+(\d+)\s*\/\s*(\d+)(?:\s*\(([^)]+)\))?/.exec(effect||''); if (m) return {a:+m[1], b:+m[2], type:(m[3]||'Blunt').trim()}; const m2 = /Armor\s+(\d+)(?!\s*\/)/.exec(effect||''); if (m2) return {a:+m2[1], b:+m2[1], type:''}; return null; }
function armorFromEquip(c){
  const parts = {}; for (const [k] of DATA.meta.bodyParts) parts[k] = {a:0, b:0, types:new Set(), belt:0};
  for (const [slot, e] of Object.entries(c.equip||{})){ if (!e || !e.effect) continue; const ar = parseArmor(e.effect); if (!ar) continue; const targets = ARMOR_SLOT_PARTS[slot] || [];
    for (const pk of targets){ if (slot==='waist') parts[pk].belt = Math.max(parts[pk].belt, ar.a); else { parts[pk].a += ar.a; parts[pk].b += ar.b; if (ar.type) parts[pk].types.add(ar.type); } } }
  const out = {};
  for (const [k,v] of Object.entries(parts)){ const a = Math.max(v.a, v.belt), b = Math.max(v.b, v.belt); if (!a && !b){ out[k]=''; continue; } const t = [...v.types].filter(x=>x && x!=='Blunt'); out[k] = `${a}/${b}` + (t.length? ` (${t.join('/')})` : ''); }
  return out;
}
function recalcArmor(c){ c.armor = armorFromEquip(c); c.armorAuto = true; }
function recalcParry(c){ c.current = c.current||{}; c.current.parryBonus = Object.values(c.equip||{}).reduce((a,e)=>{ const m=/\+(\d+)\s*Parry Dice/.exec((e&&e.effect)||''); return a + (m? +m[1] : 0); }, 0); }
function migrateEquip(c){ // ชีทเก่า (v0.4) เก็บช่องเป็นข้อความ "ชื่อ · คุณสมบัติ" และยังมีของชิ้นเดียวกันค้างในกระเป๋า
  let migrated = false;
  for (const [k,v] of Object.entries(c.equip||{})){ if (v && typeof v === 'string'){ const parts = v.split(' / ')[0].split(' · '); c.equip[k] = {name: parts[0].trim(), effect: parts.slice(1).join(' · ').trim(), weight: 0}; migrated = true; } else if (v && v.weight==null) v.weight = 0; }
  if (migrated && c.inventory){
    for (const e of Object.values(c.equip)){ if (!e || !e.name) continue; const i = c.inventory.findIndex(r=>r.name===e.name); if (i<0) continue; const row = c.inventory[i]; e.weight = +row.weight||0; if (!e.effect) e.effect = row.effect||''; if ((row.qty||1) > 1) row.qty--; else c.inventory.splice(i,1); }
    recalcParry(c);
  }
  if (c.inventory) for (const r of c.inventory) if (r.worn){ delete r.worn; } }
/* ใส่ไอเทมจากกระเป๋าลงช่อง: ของเดิมในช่องกลับเข้ากระเป๋า, ไอเทมที่มีหลายชิ้นลดจำนวนลง 1 */
function wearItem(c, idx, slot){
  const row = c.inventory[idx]; if (!row) return;
  unequip(c, slot);
  c.equip[slot] = {name: row.name, effect: row.effect||'', weight: +row.weight||0};
  if ((row.qty||1) > 1) row.qty--; else c.inventory.splice(idx,1);
  recalcParry(c); recalcArmor(c);
}
function unequip(c, slot){
  const e = c.equip[slot]; if (!e || !(e.name||'').trim()) { delete c.equip[slot]; return; }
  const same = c.inventory.find(r=>r.name===e.name && (r.effect||'')===(e.effect||'') && +r.weight===+e.weight);
  if (same) same.qty = (same.qty||0)+1; else c.inventory.push({name:e.name, effect:e.effect||'', qty:1, weight:+e.weight||0});
  delete c.equip[slot]; recalcParry(c); recalcArmor(c);
}
function autoEquip(c){
  // ถอดทุกอย่างกลับกระเป๋าก่อน แล้วสวมใหม่ตามชื่อ/คุณสมบัติ
  for (const k of Object.keys(c.equip||{})) unequip(c, k);
  c.equip = {};
  let w = 0;
  for (let i = 0; i < c.inventory.length; ){
    const row = c.inventory[i];
    if (/^หรือ\s/.test(row.name)) { i++; continue; } // ทางเลือกของชุด (เช่น ดาบ หรือ หอก) ไม่สวมอัตโนมัติ
    let slot = itemSlot(row.name, row.effect);
    if (slot==='weapon'){ if (w>=2){ i++; continue; } w++; slot = 'weapon'+w; }
    else if (slot==='chestIn' && c.equip.chestIn) slot = 'chestOut';
    if (!slot || c.equip[slot]) { i++; continue; }
    const before = c.inventory.length; wearItem(c, i, slot); if (c.inventory.length === before) i++; // ถ้าแถวถูกลบ ไม่ต้องขยับ index
  }
  // เครื่องแต่งกายของชุด (outfit) ไม่ใช่ไอเทมในกระเป๋า: สวมเป็นชิ้นน้ำหนัก 0 เฉพาะช่องที่ยังว่าง
  const set = c.starterSet ? DATA.sets.sets.find(x=>x.nameEn===c.starterSet) : null;
  if (set && set.outfit){ for (const piece of set.outfit.split(/,\s*|\s+กับ\s+/)){ const nm = piece.trim(); if (!nm) continue; let slot = itemSlot(nm, '') || 'shirt'; if (slot==='weapon') slot='shirt'; if (!c.equip[slot]) c.equip[slot] = {name:nm, effect:'เครื่องแต่งกาย', weight:0}; } }
  recalcParry(c); recalcArmor(c);
  c.equipAuto = true;
}
function ensureSheetState(c, d){
  migrateFaithSlots(c);
  c.current = Object.assign({hp:d.hp, mp:d.mp, sanity:d.sanity, temp:0, ap:3, ip:0, money:15, tough:{}}, c.current||{});
  for (const [k] of DATA.meta.bodyParts) if (c.current.tough[k]==null) c.current.tough[k] = d.toughness;
  c.armor = c.armor || {}; c.equip = c.equip || {}; c.details = c.details || {};
  c.extraText = Object.assign({languages: c.kin ? (KIN[c.kin].languages||'') : '', quest:'', note:'', reputation:'', relationship:''}, c.extraText||{});
  if (!c.inventory){
    c.inventory = [];
    const set = c.starterSet ? DATA.sets.sets.find(x=>x.nameEn===c.starterSet) : null;
    const items = [...(set? chosenSetItems(c, set) : []), ...DATA.sets.common.items];
    for (const it of items){ const m = it.name.match(/×\s*(\d+)/); c.inventory.push({name: it.name.replace(/\(เสนอ\)\s*/,'').replace(/\s*×\s*\d+/,'').trim(), effect: it.effect||'', qty: m? +m[1] : 1, weight: parseFloat(it.weight)||0}); }
  }
  migrateEquip(c);
  if (!c.armorAuto && !Object.values(c.armor||{}).some(v=>v && String(v).trim())) recalcArmor(c);
  // สวมของจากชุดเริ่มต้นให้ทันทีครั้งแรก (ตัวละครเก่าที่ยังไม่เคยสวมและช่องว่างทั้งหมดก็สวมให้)
  if (!c.equipAuto && !Object.values(c.equip).some(v=>v && (v.name||'').trim())) autoEquip(c);
}
function renderSheet(id){
  const root = clearKeep($('#v-sheet'));
  const c = Store.get(id);
  if (!c){ root.append(h('div',{class:'card'}, h('p',{text:'ไม่พบตัวละครนี้ในบัญชีของคุณ'}), h('p',{class:'dim',style:'font-size:13px',text:'ชีทของผู้เล่นคนอื่นเปิดได้เฉพาะจากห้องที่เขาหยิบตัวละครลงบอร์ด (กดปุ่ม "ชีท" ที่หมาก)'}), h('button',{style:'margin-top:8px',onclick:()=>{ location.hash = Table.roomId ? '#room-'+Table.roomId : '#chars'; },text:'← กลับ'}))); HUD.hide(); return; }
  const readOnly = !Store.canEdit(c); SheetUI.readOnly = readOnly;
  if (readOnly && c.shareMode==='min'){ if (Table.roomId) root.append(h('div',{class:'roombar'}, h('button',{class:'primary small',onclick:()=>{ location.hash='#room-'+Table.roomId; },text:'← กลับโต๊ะเล่น'}), h('span',{class:'dim',style:'font-size:13px',text:`ชีทย่อของ ${c.ownerName||'ผู้เล่นคนอื่น'}`}))); root.append(renderMinSheet(c)); HUD.hide(); return; }
  let d = compute(c); const kin = KIN[c.kin];
  ensureSheetState(c, d); d = compute(c); // สวมของอัตโนมัติอาจเปลี่ยน Parry Dice
  const cur = c.current; const det = c.details;
  const save = ()=>{ if (!readOnly) Store.upsert(c); };
  if (Table.roomId) root.append(h('div',{class:'roombar'}, h('button',{class:'primary small',onclick:()=>{ location.hash='#room-'+Table.roomId; },text:'← กลับโต๊ะเล่น'}), h('span',{class:'dim',style:'font-size:13px'}, 'ห้อง ', h('b',{text: Table.room ? Table.room.name : ''}), ' ยังเปิดอยู่ · ', readOnly ? `ชีทของ ${c.ownerName||'ผู้เล่นคนอื่น'} (อ่านอย่างเดียว)` : 'ชีทของคุณ ทอยจากชีทจะเด้งเข้าห้อง')));
  else if (readOnly) root.append(h('div',{class:'warnbox',style:'margin-bottom:10px'}, `ชีทของ ${c.ownerName||'ผู้เล่นคนอื่น'} (อ่านอย่างเดียว)`));
  const rerender = ()=>renderSheet(id);
  const txt = (obj, key, ph, multi) => { const el = multi ? h('textarea',{placeholder:ph||''}) : h('input',{placeholder:ph||''}); el.value = obj[key]||''; el.oninput = ()=>{ obj[key] = el.value; }; el.onblur = save; return el; };
  // ===== left =====
  const left = h('div');
  const portrait = h('div',{class:'portrait', title:'คลิกเพื่อใส่ภาพตัวละคร'});
  if (c.portrait) portrait.append(h('img',{src:c.portrait, alt:c.name})); else portrait.append(h('div',null, '[แทรกภาพตัวละคร]', h('div',{class:'muted',style:'font-size:11px',text:'คลิกเพื่อเลือกไฟล์'})));
  const fileInp = h('input',{type:'file',accept:'image/*',class:'sr',onchange:(e)=>{ const f=e.target.files[0]; if(!f) return; const img=new Image(); img.onload=()=>{ const cv=document.createElement('canvas'); const sc=Math.min(1, 360/Math.max(img.width,img.height)); cv.width=Math.round(img.width*sc); cv.height=Math.round(img.height*sc); cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height); c.portrait=cv.toDataURL('image/jpeg',0.82); save(); rerender(); if (Table.room){ const tk = Table.room.tokens.find(t=>t.charId===c.id); if (tk) makeThumb(c.portrait).then(th=>{ tk.thumb = th; Table.save(); }); } }; img.src=URL.createObjectURL(f); }});
  portrait.onclick = ()=>fileInp.click();
  left.append(h('div',{class:'box',dataset:{k:'portrait'}}, portrait, fileInp, h('div',{class:'idgrid',style:'margin-top:8px'}, h('span',{class:'k',text:'ชื่อผู้เล่น'}), txt(det,'player','Player name'))));
  const resBox = h('div',{class:'box',dataset:{k:'res'}}, h('h4',{text:'ทรัพยากร'}));
  const resbar = (label, key, max, color, term) => { const v = cur[key]||0; return h('div',{class:'resbar'}, h('div',{class:'l'}, h('b',{text:label}), h('span',{class:'num'}, `${v} / ${max}`)), h('div',{class:'bar'}, h('i',{style:`width:${Math.max(0,Math.min(100, max? v/max*100 : 0))}%;background:${color}`})), h('div',{class:'ctl'}, h('button',{class:'small',onclick:()=>{cur[key]=v-1; vit(); rerender();},text:'−'}), h('button',{class:'small',onclick:()=>{cur[key]=Math.min(max,v+1); vit(); rerender();},text:'+'}), h('input',{type:'number',value:v,onchange:(e)=>{cur[key]=+e.target.value||0; vit(); rerender();}}), h('button',{class:'small ghost',onclick:()=>{cur[key]=max; vit(); rerender();},text:'เต็ม'}))); };
  const vit = ()=>{ cur.at = Date.now(); save(); if (!readOnly && typeof pushVitalsFromSheet==='function') pushVitalsFromSheet(c); }; // HP/Sanity ที่แก้ในชีทไปโผล่ที่หมากในห้องทันที
  resBox.append(resbar('Sanity','sanity',d.sanity,'#a371f7','Sanity'), resbar('Health Points','hp',d.hp,'#e5484d','HP'), resbar('Mana Points','mp',d.mp,'#58b7ff','MP'));
  resBox.append(h('div',{class:'resbar'}, h('div',{class:'l'}, h('b',{text:'Temporary Health'}), h('span',{class:'num',text:String(cur.temp||0)})), h('div',{class:'bar'}, h('i',{style:`width:${Math.min(100,(cur.temp||0)*10)}%;background:#e8c547`})), h('div',{class:'ctl'}, h('button',{class:'small',onclick:()=>{cur.temp=Math.max(0,(cur.temp||0)-1); save(); rerender();},text:'−'}), h('button',{class:'small',onclick:()=>{cur.temp=(cur.temp||0)+1; save(); rerender();},text:'+'}), h('button',{class:'small ghost',onclick:()=>{cur.temp=0; save(); rerender();},text:'ล้าง'}))));
  resBox.append(h('div',{class:'idgrid',style:'margin-top:8px'}, h('span',{class:'k',text:'Insight Point'}), h('div',{class:'row',style:'gap:4px'}, h('button',{class:'small',onclick:()=>{cur.ip=Math.max(0,(cur.ip||0)-1); save(); rerender();},text:'−'}), h('b',{class:'num',text:String(cur.ip||0)}), h('button',{class:'small',onclick:()=>{cur.ip=(cur.ip||0)+1; save(); rerender();},text:'+'}), h('button',{class:'small primary',onclick:()=>openIpShop(c, ()=>{ save(); rerender(); }),text:'ใช้ IP ▸'})), h('span',{class:'k',text:'เกรฟ (เงิน)'}), h('input',{type:'number',value:cur.money||0,onchange:(e)=>{cur.money=+e.target.value||0; save();}})));
  left.append(resBox);
  const tb = h('div',{class:'box',dataset:{k:'tough'}}, h('h4',null, T('Toughness'), ' / ', T('Armor')));
  const bg2 = h('div',{class:'body2'}, h('span',{class:'dim',text:'ส่วน'}), h('span',{class:'dim',text:'Tough'}), h('span',{class:'dim',text:'เกราะ'}));
  for (const [k,label] of DATA.meta.bodyParts){ const v = cur.tough[k]; bg2.append(h('span',{text:label}), h('div',{class:'row',style:'gap:2px'}, h('button',{class:'small',onclick:()=>{cur.tough[k]=v-1; vit(); rerender();},text:'−'}), h('b',{class:'num',style:'min-width:38px;text-align:center;'+(v<=0?'color:var(--bad)':''),text:`${v}/${d.toughness}`}), h('button',{class:'small',onclick:()=>{cur.tough[k]=Math.min(d.toughness,v+1); vit(); rerender();},text:'+'})), h('input',{value:c.armor[k]||'',placeholder:'0',title:'A/B = กันกายภาพทั่วไป / กัน Blunt (หรือชนิดในวงเล็บ)',onchange:(e)=>{c.armor[k]=e.target.value; save();}})); }
  tb.append(bg2, h('div',{class:'row',style:'margin-top:6px;justify-content:space-between;align-items:center'}, h('span',{class:'dim',style:'font-size:11px',text:'เกราะ A/B = กันทั่วไป / กัน Blunt'}), h('button',{class:'small ghost',title:'คำนวณค่าเกราะจากของสวมใส่ใหม่',onclick:()=>{ recalcArmor(c); save(); rerender(); },text:'จากของสวมใส่'})), h('p',{class:'dim',style:'font-size:11px;margin:8px 0 0',text:'Hit Location: '+DATA.meta.hitLocation}));
  left.append(tb);
  // ===== middle =====
  const mid = h('div');
  const idb = h('div',{class:'box',dataset:{k:'id'}}, h('div',{class:'row',style:'justify-content:space-between'}, h('h2',{text:c.name}), h('div',{class:'row'}, readOnly? null : (Store.inCampaign(c) && !Store.isDevUid) ? h('span',{class:'tag',title:'ตัวละครอยู่ในแคมเปญแล้ว ค่าพื้นฐานจากวิซาร์ดล็อก เติบโตผ่าน IP และแก้รายละเอียดในชีทได้',text:'🔒 อยู่ในแคมเปญ'}) : h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#wizard'; },text:'แก้ไขในวิซาร์ด'}), readOnly? null : shareModeSel(c, save), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}), readOnly? null : h('button',{class:'small ghost danger',title:'ลบตัวละครนี้ออกจากบัญชีและจากทุกห้องที่อยู่',onclick:()=>{ if (!confirm(`ลบ ${c.name||'ตัวละครนี้'} ถาวร? สำเนาในห้องและหมากบนบอร์ดจะถูกถอนออกด้วย`)) return; Store.remove(c.id); toast('ลบตัวละครแล้ว'); location.hash = '#chars'; },text:'ลบตัวละคร'}))));
  const ig = h('div',{class:'idgrid',style:'margin-top:8px'});
  const kv = (k, v) => ig.append(h('span',{class:'k',text:k}), typeof v === 'string' ? h('span',{text:v}) : v);
  kv('Age อายุ', txt(det,'age')); kv('Gender เพศ', txt(det,'gender')); kv('Job อาชีพ', txt(det,'job', c.starterSet||'')); kv('Size ขนาด', d.size); kv('Height/Weight', txt(det,'height')); kv('Speed ความเร็ว', kin.speed); kv('Kin วงศา', kin.name);
  const ch = findBg(kin,c.childhood), ad = findBg(kin,c.adulthood);
  kv('Childhood', ch ? `${ch.name} (${ch.nameEn})` : '-'); kv('Adulthood', ad ? `${ad.name} (${ad.nameEn})` : '-'); kv('Languages ภาษา', txt(c.extraText,'languages'));
  idb.append(ig);
  mid.append(idb);
  const pt = h('div',{class:'box',dataset:{k:'traits'}}, h('h4',{text:'Personal Traits นิสัยส่วนตัว'}));
  const pg = h('div',{class:'idgrid two'});
  for (const [k,label,multi] of [['likes','Likes ชอบ'],['dislikes','Dislikes ไม่ชอบ'],['fears','Fears หวาดกลัว'],['want','Want'],['need','Need'],['manifest','Manifest'],['motivation','Motivation แรงจูงใจ',true],['appearance','Appearance',true],['backstory','Backstory',true],['signature','Signature Look',true]]) pg.append(h('span',{class:'k',text:label}), txt(det,k,'',multi));
  pt.append(pg); mid.append(pt);
  // Trait / Hindrance / Proficiency
  const TP = c.traitPicks || {}; const withPick = (text, key)=> TP[key] ? `${text} — เลือกไว้: ${TP[key]}` : text;
  const traits = [...kin.traits.map(t=>({name:`${t.name} (${t.nameEn})`, text:withPick(t.text,'kin:'+t.nameEn), src:'วงศา'})), ...[ch,ad].filter(Boolean).filter(b=>b.text).map(b=>({name:b.name, text:withPick(b.text,'bg:'+b.code), src: b===ch?'วัยเด็ก':'วัยผู้ใหญ่'})), ...kin.benefits.map(b=>({name:`${b.name} (${b.nameEn})`, text:withPick(b.text,'kin:'+b.nameEn), src:'Benefit'}))];
  if (c.evolver && c.evolver.kin){ const ek=KIN[c.evolver.kin]; const pick=c.evolver.pick||''; if (pick.startsWith('T:')){ const tr=ek.traits.find(t=>t.nameEn===pick.slice(2)); if (tr) traits.push({name:`${tr.name} (${tr.nameEn})`, text:tr.text, src:'ยืมจาก '+ek.name}); } }
  const hinds = kin.hindrances.map(x=>({name:`${x.name} (${x.nameEn})`, text:withPick(x.text,'kin:'+x.nameEn)}));
  if (c.evolver && c.evolver.kin && c.evolver.hindrance){ const ek=KIN[c.evolver.kin]; const hd=ek.hindrances.find(x=>x.nameEn===c.evolver.hindrance); if (hd) hinds.push({name:`${hd.name} (${hd.nameEn})`, text:hd.text}); }
  const profs = [];
  for (const k of DATA.knowledge){ for (const sl of Object.values(c.kslots||{})){ if (sl && sl.id===k.id && sl.prof && !sl.prof.startsWith('(')){ const pt = profTexts(k.id, sl); profs.push({name:`${profLabel(sl)} (${k.nameEn})`, text: pt.text + (pt.faithText ? ` · ${faithShort(sl.faith)}: ${pt.faithText}` : '')}); } } }
  if (c.adaptation) profs.push({name:'Adaptation: '+c.adaptation, text:'ได้ Advantage ในการทอยป้องกันผลจากสภาพแวดล้อมแบบนี้'});
  const ff = hasFleshforge(c); if (ff && c.fleshforge && c.fleshforge.item) traits.push({name:'🧬 ศาสตราชีวะ (Fleshforge)', text:`ไอเทมมีชีวิต: ${c.fleshforge.item} (ผูกถาวรตลอดเกม) เมื่อแปรร่างมี HP และ Toughness เท่ากับคุณ`, src:'Kins Unique'});
  const col = (title, items, cls, key) => h('div',{class:'box',dataset:{k:key}}, h('h4',null, T(title)), items.length ? items.map(it=>h('div',{style:'margin:6px 0;font-size:13px'}, h('div',null, tag(it.name, cls + hueCls(it.name, it.text)), it.src? h('span',{class:'muted',style:'font-size:11px',text:' '+it.src}):null), h('div',{class:'desc',style:'font-size:12px'}, T(it.text)))) : h('div',{class:'muted',text:'-'}));
  mid.append(h('div',{class:'grid three'}, col('Trait', traits, 'ok', 'trait'), col('Hindrance', hinds, 'neg', 'hind'), col('Proficiency Trait', profs, 'prop', 'prof')));
  if (ff && !readOnly && !(c.fleshforge && c.fleshforge.item)) mid.append(fleshforgePicker(c, {locked:false, onChange:()=>{ save(); rerender(); }, onInput: save})); // ได้ Fleshforge มาทีหลัง (เช่นซื้อด้วย IP) ต้องเลือกไอเทมผูกครั้งเดียว
  // ===== สกิล / ของสวมใส่ / กระเป๋า อยู่ใน HUD ลอยข้างจอ (hud.js) =====
  const grow = (ta)=>{ ta.rows = 1; const fit=()=>{ ta.style.height='auto'; ta.style.height = (ta.scrollHeight+2)+'px'; }; ta.addEventListener('input', fit); requestAnimationFrame(fit); return ta; };
  const nt = h('div',{class:'box notes',dataset:{k:'notes'}}, h('div',{class:'grid two'}, h('div',null, h('h4',{text:'Quest'}), txt(c.extraText,'quest','',true)), h('div',null, h('h4',{text:'Note'}), txt(c.extraText,'note','',true)), h('div',null, h('h4',{text:'Reputation (Faction)'}), txt(c.extraText,'reputation','',true)), h('div',null, h('h4',{text:'Relationship (Character)'}), txt(c.extraText,'relationship','',true))));
  mid.append(nt);
  // ===== right =====
  const right = h('div',{class:'cs-right'});
  const st = h('div',{class:'box',dataset:{k:'status'}}, h('h4',{text:'STATUS'}));
  const stt = h('table',{class:'stt'}, h('thead',null, h('tr',null, h('th'), h('th',{text:'BASE'}), h('th',{text:'CHILD'}), h('th',{text:'ADULT'}), h('th',{text:'EXTRA'}), h('th',{text:'RAW'}), h('th',{text:'MOD'}))));
  for (const s of STATS){ const chv = ch && ch.stats[s] || 0, adv = ad && ad.stats[s] || 0, exv = (c.extra||{})[s]||0, chc = (c.choiceStats||[]).filter(x=>x===s).length; stt.append(h('tr',{class:'sc-'+s}, h('td',{class:'n'}, T(s)), h('td',{text:kin.raw[s]}), h('td',{text:String(chv+chc)}), h('td',{text:String(adv)}), h('td',{text:String(exv)}), h('td',{text:String(d.raw[s])}), h('td',{class:'ov',text:signed(d.mod[s])}))); }
  st.append(h('div',{class:'tablewrap'}, stt)); right.append(st);
  const pb = h('div',{class:'box',dataset:{k:'pers'}}, h('h4',{text:'Personality Stats'}));
  const pg2 = h('div',{class:'ptable'});
  for (const ax of DATA.meta.personality){ const p=c.personality[ax.id]; const l = (!p||p.value==null)?0:(p.side==='left'?p.value:-p.value); pg2.append(h('span',{class:'lw'}, ax.left, h('span',{class:'dim',text:` (${ax.leftTh})`})), h('span',{class:'v',style:'color:#f08c2e',text:signed(l)}), h('span',{class:'dim',text:'/'}), h('span',{class:'v',style:'color:#58b7ff',text:signed(-l)}), h('span',{class:'rc'}, ax.right, h('span',{class:'dim',text:` (${ax.rightTh})`}))); }
  pb.append(pg2); right.append(pb);
  const cm = h('div',{class:'box',dataset:{k:'combat'}}, h('h4',null, 'Combat Mod.'));
  cm.append(h('div',{class:'gives'}, h('span',{class:'tag sc sc-AGI stat'}, T('Reflex'), ` ${signed(d.reflex)}`), h('span',{class:'tag sc sc-STR stat'}, T('Might'), ` ${signed(d.might)}`), h('span',{class:'tag sc sc-PER stat'}, T('Sight'), ` ${signed(d.sight)}`), h('span',{class:'tag sc sc-PER stat'}, T('Initiative'), ` ${signed(d.initiative)}`), h('span',{class:'tag sc sc-VIT stat'}, 'VIT ST', ` ${signed(d.fortitude)}`), h('span',{class:'tag sc sc-PER stat'}, 'PER ST', ` ${signed(d.will)}`), h('span',{class:'tag',title:'เต๋าเพิ่มตอน Parry (โล่ +1) แก้ตัวเลขได้'}, T('Parry Dice'), ' ', h('input',{type:'number',min:0,max:4,value:d.parryDice,style:'width:44px;padding:0 4px;font-size:12px',onchange:(e)=>{ cur.parryBonus=Math.max(0,+e.target.value||0); save(); rerender(); }})), h('span',{class:'tag'}, T('Passive PER'), ` ${d.passivePer}`), h('span',{class:'tag'}, T('Capacity'), ` ${d.capacity} กก.`)));
  cm.append(h('div',{class:'kicker',style:'margin-top:8px',text:'สายคาดอาวุธ'}), weaponBoard(c, d, (k)=>{ HUD.open='pouch'; HUD.sel.pouch=k; HUD.persist && HUD.persist(); rerender(); }, null));
  right.append(cm);
  const kl = knowledgeLevels(c);
  const kb = h('div',{class:'box',dataset:{k:'know'}}, h('h4',null, T('Knowledge'), ' ', h('span',{class:'dim',style:'font-size:11px;font-weight:400;font-family:var(--font-body)',text:'2d6 + ระดับความรู้ + บุคลิกภาพที่เกี่ยว'})));
  const kt = h('table',{class:'t'});
  for (const k of DATA.knowledge){ const kb2 = knowledgeBonus(c, d, k); kt.append(h('tr',null, h('td',null, h('b',{text:k.nameEn}), h('span',{class:'dim',style:'font-size:11px',text:` (${k.stats.join('/')})`})), h('td',{class:'num',text:'Lv'+kb2.lv}), h('td',{class:'num',title:`ระดับความรู้ ${kb2.lv} (ไม่รวม Mod ค่าพลัง)`,text:signed(kb2.total)}))); }
  kb.append(h('div',{class:'tablewrap'}, kt)); right.append(kb);
  // แผงทอยเต๋าอยู่ใน HUD (ปุ่มลอยข้างจอ) ไม่กินพื้นที่ชีท และเปิดค้างไว้ได้ขณะเลื่อนดูชีท
  const diceOpts = {onRoll: (e)=>{ if (Table.roomId) Table.postRoll(e, c); }, guard: Table.roomId ? (run,label)=>Table.guardedRoll(c.name, run, label) : null};
  const cs = h('div',{class:'cs'});
  // จัดกรอบลงคอลัมน์เท่ากัน 3 ช่อง (2 บนจอกลาง, 1 บนมือถือ) แบบเรียงให้คอลัมน์สูงใกล้เคียงกัน ไม่ทิ้งช่องว่าง
  const all = [...left.children, ...mid.children, ...right.children].flatMap(el => el.classList.contains('grid') ? [...el.children] : [el]);
  const ORDER = ['id','portrait','status','res','traits','pers','tough','combat','trait','hind','prof','know','notes'];
  const order = all.slice().sort((a,b)=>ORDER.indexOf(a.dataset.k) - ORDER.indexOf(b.dataset.k));
  // ปุ่มจัดวางกรอบเอง (ย้าย/ย่อขยายทุกกรอบ บันทึกต่อเบราว์เซอร์)
  const lay = loadLayout();
  idb.querySelector('.row .row').append(...[h('button',{class:'small ghost',title:'ลากย้ายและปรับขนาดทุกกรอบได้ตามถนัด',onclick:()=>{ if (lay.free){ lay.free=false; saveLayout(lay); } else { lay.free=true; saveLayout(lay); } rerender(); },text: lay.free ? 'กลับเป็นแบบตาราง' : 'จัดวางกรอบเอง'}), lay.free ? h('button',{class:'small ghost',onclick:()=>{ if (!confirm('ล้างการจัดวางที่บันทึกไว้?')) return; saveLayout({free:true, boxes:{}}); rerender(); },text:'รีเซ็ตตำแหน่ง'}) : null].filter(Boolean));
  root.append(cs);
  packColumns(cs, order);
  if (lay.free && vw() > 760) applyFreeLayout(cs, lay);
  renderHUD(c, d, {save, rerender, txt, grow, dice: diceOpts});
  if (readOnly) lockForm(root);
}
function lockForm(root){ for (const el of root.querySelectorAll('input,textarea,select')) el.disabled = true; for (const b of root.querySelectorAll('button')) { if (!b.classList.contains('rollbtn') && !/กลับ|JSON|ปิด|ซ่อน|คัมภีร์|กระเป๋า|ถุงย่าม|Advantage|Disadvantage|ปกติ/.test(b.textContent) && !b.closest('.hud-head,.hud-dock,.modeBtns')) b.disabled = true; } }

/* ===== จัดวางกรอบเอง: ทุกกรอบลากย้ายและย่อขยายได้ (บันทึกใน localStorage ของเบราว์เซอร์) ===== */
function loadLayout(){ try{ return Object.assign({free:false, boxes:{}}, JSON.parse(localStorage.getItem('kirana.sheetLayout')||'{}')); }catch(e){ return {free:false, boxes:{}}; } }
function saveLayout(l){ try{ localStorage.setItem('kirana.sheetLayout', JSON.stringify(l)); }catch(e){} }
function applyFreeLayout(cs, lay){
  const boxes = [...cs.querySelectorAll('.box[data-k]')];
  // ตำแหน่งตั้งต้น = ตำแหน่งในตารางปัจจุบัน (วัดก่อนปลดออกจากกริด)
  const base = cs.getBoundingClientRect(); const z0 = uiZoom(); // พิกัดจอ → พิกัดหลัง zoom
  const rects = boxes.map(b=>{ const r = b.getBoundingClientRect(); return {x:(r.left-base.left)/z0, y:(r.top-base.top)/z0, w:r.width/z0, h:r.height/z0}; });
  cs.classList.add('free');
  let maxBottom = 0;
  boxes.forEach((b,i)=>{
    const k = b.dataset.k; const saved = lay.boxes[k] || rects[i];
    const x = Math.max(0, saved.x), y = Math.max(0, saved.y), w = Math.max(160, saved.w), hgt = Math.max(60, saved.h);
    b.style.left = x+'px'; b.style.top = y+'px'; b.style.width = w+'px'; b.style.height = hgt+'px'; if (saved.z) b.style.zIndex = saved.z;
    maxBottom = Math.max(maxBottom, y+hgt);
    const grip = h('div',{class:'box-grip',title:'ลากเพื่อย้าย · ดึงมุมขวาล่างเพื่อปรับขนาด'}, h('span',{class:'dots',text:'⋮⋮'}), h('span',{class:'dim',text:'ย้าย'}));
    b.prepend(grip);
    let sx=0, sy=0, ox=0, oy=0, id=null, z=1;
    grip.addEventListener('pointerdown', (e)=>{ if (e.button!==0) return; lay.zTop = (lay.zTop||1)+1; b.style.zIndex = lay.zTop; id=e.pointerId; grip.setPointerCapture(id); z = uiZoom(); sx=e.clientX; sy=e.clientY; ox=parseFloat(b.style.left); oy=parseFloat(b.style.top); b.classList.add('dragging'); e.preventDefault(); });
    grip.addEventListener('pointermove', (e)=>{ if (id==null || e.pointerId!==id) return; const nx = Math.max(0, Math.min(cs.clientWidth - b.offsetWidth, ox + (e.clientX - sx)/z)), ny = Math.max(0, oy + (e.clientY - sy)/z); b.style.left = nx+'px'; b.style.top = ny+'px'; });
    const up = ()=>{ if (id==null) return; try{ grip.releasePointerCapture(id); }catch(x){} id=null; b.classList.remove('dragging'); store(); fitHeight(); };
    grip.addEventListener('pointerup', up); grip.addEventListener('pointercancel', up);
    const store = ()=>{ lay.boxes[k] = {x:parseFloat(b.style.left), y:parseFloat(b.style.top), w:b.offsetWidth, h:b.offsetHeight, z: +b.style.zIndex||0}; saveLayout(lay); };
    let first = true; const ro = new ResizeObserver(()=>{ if (first){ first=false; return; } store(); fitHeight(); }); ro.observe(b);
  });
  const fitHeight = ()=>{ let mb = 0; for (const b of boxes) mb = Math.max(mb, parseFloat(b.style.top) + b.offsetHeight); cs.style.height = (mb + 24) + 'px'; };
  cs.style.height = (maxBottom + 24) + 'px';
}

/* จัดกรอบลงคอลัมน์: วัดความสูงจริงแล้ววางทีละกรอบลงคอลัมน์ที่เตี้ยที่สุด (ลำดับคงเดิม) */
function packColumns(cs, boxes){
  const n = vw() <= 760 ? 1 : (vw() <= 1100 ? 2 : 3);
  const cols = Array.from({length:n}, ()=>h('div',{class:'cscol'}));
  cs.append(...cols);
  // วัดในคอลัมน์แรกก่อน (ทุกคอลัมน์กว้างเท่ากัน)
  for (const b of boxes) cols[0].append(b);
  const heights = boxes.map(b => b.offsetHeight + 14);
  const tot = Array(n).fill(0);
  const hOf = new Map(boxes.map((b,i)=>[b, heights[i]]));
  boxes.forEach((b,i)=>{ let j = 0; for (let k=1;k<n;k++) if (tot[k] < tot[j]) j = k; cols[j].append(b); tot[j] += heights[i]; });
  // ปรับสมดุล: ย้ายกรอบจากคอลัมน์ที่สูงสุดไปต่อท้ายคอลัมน์ที่เตี้ยสุด เลือกกรอบที่ทำให้ส่วนต่างเหลือน้อยที่สุด (ไม่ย้ายกรอบแรกของคอลัมน์)
  for (let it=0; it<8; it++){
    let T=0, S=0; for (let k=1;k<n;k++){ if (tot[k] > tot[T]) T=k; if (tot[k] < tot[S]) S=k; }
    if (T===S) break; const diff = tot[T]-tot[S]; let best=null, bestGap=diff;
    for (const b of [...cols[T].children].slice(1)){ const hb = hOf.get(b)||0; const gap = Math.abs(diff - 2*hb); if (hb < diff && gap < bestGap){ bestGap = gap; best = b; } }
    if (!best) break; const hb = hOf.get(best); cols[S].append(best); tot[T] -= hb; tot[S] += hb;
  }
}

/* ตัวเลือกว่าจะแชร์อะไรให้ห้อง */
function shareModeSel(c, save){
  const sel = h('select',{title:'สิ่งที่ GM และเพื่อนร่วมห้องเห็นเมื่อวางตัวละครลงบอร์ด',onchange:(e)=>{ c.shareMode = e.target.value; save(); toast(c.shareMode==='min' ? 'ห้องจะเห็นเฉพาะค่าหลัก (ชื่อ รูป วงศา HP Sanity เกราะ)' : 'ห้องจะเห็นชีทเต็ม (อ่านอย่างเดียว)'); }},
    h('option',{value:'full',text:'แชร์ให้ห้อง: ชีทเต็ม'}), h('option',{value:'min',text:'แชร์ให้ห้อง: เฉพาะค่าหลัก'}));
  sel.value = c.shareMode || 'full';
  return sel;
}
/* ชีทแบบย่อที่คนอื่นในห้องเห็น เมื่อเจ้าของเลือกแชร์เฉพาะค่าหลัก */
function renderMinSheet(c){
  const kin = c.kin ? KIN[c.kin] : null; const cur = c.current || {};
  const box = h('div',{class:'card minsheet'});
  box.append(h('div',{class:'row',style:'gap:14px;align-items:flex-start'},
    c.portrait ? h('img',{src:c.portrait,alt:c.name,style:'width:120px;height:160px;object-fit:cover;border-radius:8px;border:1px solid var(--line-2)'}) : null,
    h('div',null, h('h2',{text:c.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',text:(kin? kin.name : '') + (c.size? ' · '+c.size : '') + (c.ownerName? ' · ผู้เล่น '+c.ownerName : '')}),
      h('div',{class:'gives',style:'margin-top:8px'}, tag(`HP ${cur.hp??'?'}`,'neg'), tag(`MP ${cur.mp??'?'}`,'stat'), tag(`Sanity ${cur.sanity??'?'}`,'prop'), cur.temp? tag(`Temp HP ${cur.temp}`) : null),
      h('div',{class:'dim',style:'font-size:12.5px;margin-top:6px',text:'เจ้าของเลือกแชร์เฉพาะค่าหลัก ค่าพลัง ทักษะ กระเป๋า และเรื่องราวไม่เปิดเผย'}))));
  const tb = h('table',{class:'t',style:'margin-top:10px'}, h('thead',null, h('tr',null, h('th',{text:'อวัยวะ'}), h('th',{text:'Toughness'}), h('th',{text:'เกราะ A/B'}))));
  for (const [k,label] of DATA.meta.bodyParts) tb.append(h('tr',null, h('td',{text:label}), h('td',{class:'num',text:(cur.tough||{})[k]??'-'}), h('td',{class:'num',text:(c.armor||{})[k]||'-'})));
  box.append(h('div',{class:'tablewrap'}, tb));
  const det = c.details||{}; if (det.appearance) box.append(h('p',{class:'desc',style:'margin-top:8px'}, h('b',{text:'รูปลักษณ์: '}), det.appearance)); if (det.signature) box.append(h('p',{class:'desc'}, h('b',{text:'เอกลักษณ์: '}), det.signature));
  return box;
}
