/* ===== Character list + sheet + dice ===== */
let charsQuery = '';
function renderChars(){
  const root = clearKeep($('#v-chars'));
  const q = h('input',{class:'charsearch',placeholder:'ค้นหาชื่อ วงศา หรือชุดเริ่มต้น',value:charsQuery,oninput:(e)=>{ charsQuery = e.target.value; drawLists(); }});
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'ตัวละครของฉัน'}), h('p',{text: Store.online ? 'ชีทเป็นของบัญชีคุณคนเดียว GM กับเพื่อนร่วมโต๊ะจะเห็นก็ต่อเมื่อคุณหยิบตัวละครลงบอร์ดในห้องนั้น' : 'เก็บไว้ในเบราว์เซอร์นี้ ส่งออกเป็น JSON ไว้ย้ายเครื่องได้'})),
    h('div',{class:'row'}, q, h('button',{class:'primary',onclick:()=>{ startWizard(null); location.hash='#wizard'; },text:'+ สร้างตัวละครใหม่'}), h('button',{onclick:importChar,text:'นำเข้า JSON'}))));
  const host = h('div'); root.append(host);
  const match = (c)=>{ const k = charsQuery.trim().toLowerCase(); if (!k) return true; const kin = c.kin ? KIN[c.kin] : null; return [c.name, kin && kin.name, c.starterSet, c.talent, c.ownerName].filter(Boolean).some(x=>String(x).toLowerCase().includes(k)); };
  const card = (c)=>{ const d=compute(c); const kin=c.kin?KIN[c.kin]:null;
    const portrait = c.portrait ? h('img',{class:'portrait',src:c.portrait,alt:c.name||'',onclick:()=>{ if (c.done) location.hash='#sheet-'+c.id; }}) : h('div',{class:'portrait ph',text:(c.name||'?').slice(0,1)});
    return h('div',{class:'card charcard'}, portrait, h('div',null,
      h('h3',{style:'margin:0'}, c.name||'(ยังไม่ตั้งชื่อ)', h('span',{class:'en',text: kin? kin.name : 'ร่าง'})),
      h('div',{class:'gives'}, c.done? tag('พร้อมเล่น','ok') : tag(`ร่าง ขั้น ${(c.step||0)+1}/8`,'warn'), c.starterSet? tag(c.starterSet,'prop'):null, c.talent? tag('Talent '+c.talent):null, Store.inCampaign(c)? tag('อยู่ในแคมเปญ','neg'):null),
      kin? h('div',{class:'statgrid'}, STATS.map(s=>h('div',{class:'statbox'}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:d.raw[s]}), h('div',{class:'m num',text:signed(d.mod[s])})))) : null,
      h('div',{class:'row',style:'margin-top:8px'}, c.done? h('button',{class:'primary small',onclick:()=>{location.hash='#sheet-'+c.id;},text:'เปิดชีท'}):null, (c.done && Store.inCampaign(c) && !Store.isDevUid) ? h('button',{class:'small',disabled:true,title:'ตัวละครอยู่ในแคมเปญแล้ว ค่าพื้นฐานล็อก เติบโตผ่าน IP และแก้รายละเอียดได้ในชีท',text:'🔒 อยู่ในแคมเปญ'}) : h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#wizard'; },text:c.done?'แก้ไขในวิซาร์ด':'ทำต่อ'}), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}), h('button',{class:'small ghost danger',onclick:()=>{ if(confirm(`ลบ ${c.name||'ตัวละครนี้'} ถาวร?${Store.inCampaign(c) ? ' สำเนาในห้องและหมากบนบอร์ดจะถูกถอนออกด้วย' : ''}`)){ Store.remove(c.id); toast('ลบตัวละครแล้ว'); } renderChars(); },text:'ลบ'}), !Store.isMine(c) && Store.isDevUid ? h('button',{class:'small ghost',title:'ย้ายตัวละครนี้มาเป็นของบัญชีผู้พัฒนา',onclick:()=>{ if(!confirm(`อ้างสิทธิ์ ${c.name} มาเป็นของคุณ?`)) return; c.ownerId = Store.me; Store.upsert(c); renderChars(); },text:'อ้างสิทธิ์'}) : null),
      !Store.isMine(c) ? h('div',{class:'dim',style:'font-size:12px;margin-top:4px',text:'เจ้าของ: '+(c.ownerName||c.ownerId||'?')}) : null));
  };
  function drawLists(){
    clear(host);
    const mine = Store.chars.filter(c=>Store.isMine(c)); const others = Store.chars.filter(c=>!Store.isMine(c));
    const fm = mine.filter(match), fo = others.filter(match);
    if (!mine.length && !others.length){ host.append(h('div',{class:'card',text:'ยังไม่มีตัวละคร เริ่มจากปุ่มสร้างตัวละครใหม่'})); return; }
    if (charsQuery.trim() && !fm.length && !fo.length){ host.append(h('div',{class:'card dim',text:`ไม่พบตัวละครที่ตรงกับ "${charsQuery.trim()}"`})); return; }
    if (fm.length) host.append(h('div',{class:'grid wide'}, fm.map(card)));
    if (fo.length){ host.append(h('h3',{style:'margin:18px 0 8px',text:'ตัวละครของผู้เล่นคนอื่น (มุมมองผู้พัฒนา)'})); host.append(h('div',{class:'grid wide'}, fo.map(card))); }
  }
  drawLists();
}
function exportChar(c){
  const txt = JSON.stringify(c, null, 1);
  const ta = h('textarea',{style:'min-height:300px;font-family:monospace;font-size:12px'}); ta.value = txt;
  modal(h('div',null, h('h3',{text:'ส่งออกตัวละคร (คัดลอกข้อความนี้ไปเก็บ)'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ navigator.clipboard.writeText(txt).then(()=>toast('คัดลอกแล้ว')).catch(()=>toast('คัดลอกไม่ได้ เลือกข้อความแล้วคัดลอกเอง')); },text:'คัดลอก'}))));
}
function importChar(){
  const ta = h('textarea',{style:'min-height:240px;font-family:monospace;font-size:12px',placeholder:'วาง JSON ของตัวละครที่นี่'});
  modal(h('div',null, h('h3',{text:'นำเข้าตัวละคร'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ try{ const c=JSON.parse(ta.value); if(!c || !c.id || !('kin' in c)) throw new Error('bad'); const restoringMine = !!(Store.me && c.ownerId === Store.me) && !Store.get(c.id); if (!restoringMine) c.id = uid(); /* สำเนาของคนอื่นต้องได้ id ใหม่ ไม่งั้นชนกับเอกสารของเจ้าของเดิมบนเว็บ */ c.ownerId = Store.me||null; delete c.synced; c.roomIds = restoringMine ? (c.roomIds||[]) : []; Store.upsert(c); modal(null); renderChars(); toast('นำเข้าแล้ว'); } catch(e){ toast('อ่าน JSON ไม่ได้'); } },text:'นำเข้า'}))));
}

/* ---- Dice panel (ใช้ร่วมกันทั้งชีทและโต๊ะ) ---- */
const RollLog = { entries: [], add(e){ this.entries.unshift(e); if (this.entries.length>60) this.entries.pop(); } };
function doRoll({label, mod=0, persSide=null, c=null, dc=null, mode='normal', kind='check', r=null, dis=false, atk=null, def=null}){
  r = r || roll2d6(mode);
  let pm = 0; if (persSide && c) pm = persMod(c, persSide);
  const total = r.sum + mod + pm;
  // โจมตี: mod = ตัวปรับ CV (บวกทีหลัง ไม่ขยับตำแหน่ง) · atk.loc = ตำแหน่งที่เล็งด้วย Focus (Precise) · ป้องกัน: dc = ผลรวมเต๋าของผู้โจมตี def.cv = CV หลังบวก def.loc = ตำแหน่งที่ผู้โจมตีเล็ง
  let av = null;
  const j = kind==='luck' ? (total>=8 ? {cls:'res-full',text:'โชคเข้าข้าง (8+)'} : {cls:'res-fail',text:'โชคไม่เข้าข้าง'})
    : kind==='attack' ? (av = attackVerdict(r, {cvMod: mod + pm, loc: atk && atk.loc}))
    : (kind==='parry' || kind==='evade') ? judgeDefense(total, dc, kind, Object.assign({sum: r.sum, dis}, def||{}))
    : judge(total, r, dc);
  const e = {ts:Date.now(), label, r, mod, pm, persSide, total, judge:j, mode, dc, kind, who: c? c.name : ''};
  if (av) e.atk = {sum: av.sum, cv: av.cv, part: av.part||null, precise: av.precise, cvMod: mod + pm, pick: (atk && atk.pick) || null};
  if (def && (def.cv != null || def.loc)) e.def = {cv: def.cv != null ? def.cv : null, loc: def.loc || null};
  RollLog.add(e);
  return e;
}
/* ทอยหลายลูกแล้วเลือก 2 ลูก: Parry ที่มี Parry Dice · Parry/Evade แบบ Advantage · โจมตีแบบ Advantage หรือมี Combat Dice เกิน 2 (ผู้โจมตีเลือก) · โจมตีแบบ Disadvantage (ฝ่ายรับเลือก ส่ง ctx.dice ที่ทอยไว้แล้วมาได้) */
function rollChoose(n, mode, title, ctx){ // ctx = {kind:'parry'|'evade'|'attack', dc, mod, dis, cv, loc, cvMod, dice, forDefender}
  ctx = ctx || {};
  const dice = Array.isArray(ctx.dice) && ctx.dice.length >= 2 ? ctx.dice.slice() : Array.from({length:n}, rollD6); n = dice.length;
  return new Promise(resolve => {
    const sel = new Set();
    const live = h('div',{class:'picklive'});
    const dopt = {cv: ctx.cv, loc: ctx.loc};
    const showLive = ()=>{ clear(live); if (sel.size!==2){ live.append(h('span',{class:'dim',text:'เลือกให้ครบ 2 ลูก'})); return; } const idx = [...sel].sort((a,b)=>a-b); const s = idx.reduce((a,i)=>a+dice[i],0);
      if (ctx.kind==='attack'){ const av = attackVerdict({sum:s, kept:[dice[idx[0]], dice[idx[1]]], double: dice[idx[0]]===dice[idx[1]]}, {cvMod: ctx.cvMod||0, loc: ctx.loc}); live.append(h('b',{class:'num',text:`ผลรวม ${s}`}), h('div',{class:av.cls,text:av.text})); }
      else if (ctx.kind==='parry'){ const j = ctx.dc!=null ? judgeDefense(s, ctx.dc, 'parry', Object.assign({sum:s, dis:ctx.dis}, dopt)) : null; live.append(...[h('b',{class:'num',text:`ผลรวม ${s}`}), h('span',{class:'dim',text: hitText(s) ? ` กันการโจมตีที่ออก ${parryNumbers(s).join(' หรือ ')}` : ''}), j && j.text ? h('div',{class:j.cls,text:j.text}) : null].filter(Boolean)); }
      else { const tot = s + (ctx.mod||0); const j = ctx.dc!=null ? judgeDefense(tot, ctx.dc, 'evade', Object.assign({sum:s}, dopt)) : null; live.append(...[h('b',{class:'num',text:`ผลรวม ${s}${ctx.mod ? ' '+signed(ctx.mod)+' = '+tot : ''}`}), j && j.text ? h('div',{class:j.cls,text:j.text}) : null].filter(Boolean)); } };
    const btns = dice.map((v,i)=>h('button',{class:'bigdie pickdie',onclick:()=>{ if (sel.has(i)) sel.delete(i); else { if (sel.size>=2) return; sel.add(i); } btns.forEach((b,j)=>b.classList.toggle('sel', sel.has(j))); ok.disabled = sel.size!==2; showLive(); }}, h('span',{text:String(v)})));
    const ok = h('button',{class:'primary',disabled:true,onclick:()=>{ const idx=[...sel].sort((a,b)=>a-b); const kept = idx.map(i=>dice[i]); finish({dice, kept, keptIdx: idx, sum: kept[0]+kept[1], crit: ctx.kind==='attack' ? null : (kept[0]===6&&kept[1]===6?'success':(kept[0]===1&&kept[1]===1?'failure':null)), double: kept[0]===kept[1], mode, chosen:true}); },text:'ใช้ 2 ลูกนี้'});
    const finish = (r)=>{ modal(null); resolve(r); };
    const part = (ctx.loc && HIT_DEFEND[ctx.loc]) ? ctx.loc : (ctx.dc!=null ? hitPart(ctx.dc) : null);
    const nums = part ? HIT_DEFEND[part].slice() : []; const where = part ? partLabel(part) + (ctx.loc ? ' ที่ผู้โจมตีเล็ง' : '') : '';
    const evTarget = ctx.cv != null && ctx.cv !== ctx.dc ? `CV ${ctx.cv}` : String(ctx.dc);
    const hint = ctx.kind==='attack'
      ? (ctx.forDefender ? `การโจมตีนี้ติด Disadvantage ฝ่ายรับ (หรือ GM) เป็นคนเลือก 2 ลูก ผลรวมบอกทั้ง CV และตำแหน่งที่โดน (${hitListText(HIT_ATTACK)})` : `ผู้โจมตีเลือกเอง จะเอา CV สูงสุด ตำแหน่งที่ต้องการ หรือเลขเหมือนกันเพื่อ Perfect Strike ก็ได้ (${hitListText(HIT_ATTACK)})${ctx.loc ? ' · เล็ง' + partLabel(ctx.loc) + 'ไว้แล้ว ตำแหน่งไม่เปลี่ยนตามเต๋า' : ''}`)
      : ctx.kind==='parry'
      ? (ctx.dc!=null && nums.length ? (ctx.dis ? `โจมตีมา ${ctx.dc} (${where}) ติด Disadvantage ต้องได้ ${ctx.dc} พอดีเท่านั้น` : `โจมตีมา ${ctx.dc} (${where}) กันได้เมื่อผลรวมเป็น ${nums.join(' หรือ ')} · ได้ ${ctx.dc} พอดี = Perfect Parry`) : 'Parry สำเร็จเมื่อผลรวม 2 ลูกอยู่กลุ่มเดียวกับตำแหน่งที่ถูกโจมตี (หัว 2,3,11,12 · ขวา 4,9 · ซ้าย 5,10 · ลำตัว 6,7,8) เท่ากับผลโจมตีพอดี = Perfect')
      : (ctx.dc!=null ? `โจมตีมา ${ctx.dc} หลบได้เมื่อผลรวมหลังบวก Reflex ถึง ${evTarget} · เต๋าสองลูกรวมได้ ${ctx.dc} พอดี = Perfect Evade` : 'เอาสูงสุด หรือเอาให้เต๋าสองลูกรวมเท่ากับผลโจมตีของอีกฝ่ายเพื่อ Perfect ก็ได้');
    const box = h('div',{class:'pickbox'}, h('h3',{text:title||'เลือกเต๋า 2 ลูก'}), h('p',{class:'desc',text:`ทอยได้ ${n} ลูก เลือก 2 ลูกที่จะใช้ ${hint}`}), h('div',{class:'dice-row'}, btns), live, h('div',{class:'row',style:'justify-content:center;margin-top:10px'}, ok));
    showLive();
    modal(box);
    const m = $('#modal'); m.onclick = ()=>{}; // ห้ามปิดด้วยการคลิกข้างนอก ต้องเลือกให้ครบ
    const closeBtn = m.querySelector('.box > .row:last-child'); if (closeBtn) closeBtn.remove();
  });
}
function rollEntryEl(e){
  const parts = [`2d6 ${e.r.kept[0]}+${e.r.kept[1]}`]; if (e.mod) parts.push(`Mod ${signed(e.mod)}`); if (e.pm) parts.push(`${e.persSide} ${signed(e.pm)}`);
  return h('div',{class:'e'}, h('div',{class:'row',style:'gap:6px'}, e.who? h('span',{class:'who',text:e.who}):null, h('b',{text:e.label}), e.mode!=='normal'? tag(e.mode==='adv'?'Advantage':'Disadvantage', e.mode==='adv'?'ok':'neg'):null, e.atk && e.atk.pick==='def' ? tag('ฝ่ายรับเลือก','neg') : (e.r.chosen? tag('เลือกลูกเอง','prop'):null), e.dc!=null? tag((e.kind==='parry'||e.kind==='evade')?'โจมตีมา '+e.dc:'DC '+e.dc):null, e.def && e.def.cv!=null && e.def.cv!==e.dc ? tag('CV '+e.def.cv) : null, e.def && e.def.loc ? tag('เล็ง'+partLabel(e.def.loc)) : null),
    h('div',{class:'row',style:'gap:8px;margin-top:2px'}, renderDice(e.r), h('span',{class:'dim num',text:parts.join(' ')}), h('b',{class:'num',text:'= '+e.total}), h('span',{class:e.judge.cls,text:e.judge.text})));
}
function dicePanel(c, onRoll, opts={}){ // opts.guard(run) = ด่านล็อกการทอยของโต๊ะ · opts.noLog = ไม่แสดงบันทึกในแผง · opts.pendingPick(info) = ในห้อง: โพสต์เต๋าให้ฝ่ายรับเลือก · opts.lastAttack() = การโจมตีล่าสุดในแชตของห้อง
  const st = {mode:'normal', pers:'', dc:'', cv:'', loc:'', atkDice:2, cvMod:'', aim:''};
  const box = h('div',{class:'card dicepanel'});
  const modeBtns = h('div',{class:'row'}, ['normal','adv','dis'].map(m=>h('button',{class:'small'+(st.mode===m?' primary':''), onclick:(e)=>{ st.mode=m; for (const b of modeBtns.children) b.classList.toggle('primary', b.dataset.m===m); }, dataset:{m}, text: m==='normal'?'ปกติ 2d6':m==='adv'?'Advantage 3d6↑':'Disadvantage 3d6↓'})));
  const persSel = h('select',{onchange:(e)=>{st.pers=e.target.value;}}, h('option',{value:'',text:'ไม่บวกบุคลิกภาพ'}), DATA.meta.personality.flatMap(ax=>[ax.left, ax.right]).map(s=>h('option',{value:s, text: c? `${s} (${signed(persMod(c,s))})` : s})));
  const dcInp = h('input',{type:'number',placeholder:'DC / ผลโจมตีที่ต้องกัน (ว่าง = ไม่ตัดสิน)',style:'width:230px',oninput:(e)=>{st.dc=e.target.value;}});
  box.append(h('h3',{text:'ทอยเต๋า'}), h('div',{class:'row',style:'margin:8px 0'}, modeBtns), h('div',{class:'row',style:'margin-bottom:8px'}, persSel, dcInp));
  // v1.15: ตัวเลือกการต่อสู้ · โจมตี = จำนวน Combat Dice ตัวปรับ CV และตำแหน่งที่เล็งด้วย Focus (Precise) · ป้องกัน = CV หลังบวกและตำแหน่งที่ผู้โจมตีเล็ง (ช่องผลโจมตีด้านบนคือผลรวมเต๋าของผู้โจมตี)
  const partOpts = (first)=>[h('option',{value:'',text:first}), ...DATA.meta.bodyParts.map(([k,l])=>h('option',{value:k,text:l}))];
  const atkDiceSel = h('select',{class:'atkdice',title:'จำนวน Combat Dice (ปกติ 2 ลูก สกิลหรืออาวุธบางอย่างเพิ่มให้) มากกว่า 2 ลูกผู้โจมตีเลือกเอง 2 ลูก',onchange:(e)=>{st.atkDice=+e.target.value||2;}}, [2,3,4].map(n=>h('option',{value:n,text:`Combat Dice ${n} ลูก`})));
  const cvModInp = h('input',{type:'number',class:'cvmod',placeholder:'ตัวปรับ CV',title:'ตัวปรับ CV ของการโจมตี บวกหรือลบทีหลัง ไม่ขยับตำแหน่งที่โดน',style:'width:104px',oninput:(e)=>{st.cvMod=e.target.value;}});
  const aimSel = h('select',{class:'aimsel',title:'Focus (Precise): ประกาศตำแหน่งที่จะโจมตี ได้บวก CV ตาม Sight และตำแหน่งไม่เปลี่ยนตามเต๋า',onchange:(e)=>{st.aim=e.target.value;}}, partOpts('ไม่เล็ง (ตำแหน่งตามเต๋า)'));
  const cvInp = h('input',{type:'number',class:'defcv',placeholder:'CV ของผู้โจมตี',title:'CV หลังบวกตัวปรับของผู้โจมตี ใช้ตัดสิน Evade (ว่าง = เท่าผลรวมเต๋าในช่องผลโจมตี)',style:'width:128px',oninput:(e)=>{st.cv=e.target.value;}});
  const locSel = h('select',{class:'defloc',title:'ตำแหน่งที่ผู้โจมตีเล็งมาด้วย Focus (Precise) ถ้ามี',onchange:(e)=>{st.loc=e.target.value;}}, partOpts('ไม่ได้เล็ง'));
  const lastBtn = opts.lastAttack ? h('button',{class:'small ghost lastatk',title:'ใส่ผลรวมเต๋า CV และตำแหน่งจากการทอยโจมตีล่าสุดในแชตของห้อง',onclick:()=>{ const a = opts.lastAttack(); if (!a){ toast('ยังไม่มีการทอยโจมตีในแชตของห้องนี้'); return; } st.dc = String(a.sum); dcInp.value = st.dc; st.cv = a.cv !== a.sum ? String(a.cv) : ''; cvInp.value = st.cv; st.loc = a.precise && a.part ? a.part : ''; locSel.value = st.loc; toast(`รับการโจมตีของ ${a.who||'อีกฝ่าย'}: เต๋า ${a.sum}${a.cv!==a.sum ? ' CV '+a.cv : ''}${a.part ? ' '+partLabel(a.part) : ''}`); },text:'⤵ การโจมตีล่าสุด'}) : null;
  box.append(h('div',{class:'row combatopts'}, h('span',{class:'dim',text:'โจมตี'}), atkDiceSel, cvModInp, aimSel), h('div',{class:'row combatopts',style:'margin-bottom:8px'}, h('span',{class:'dim',text:'ป้องกัน'}), cvInp, locSel, lastBtn));
  const log = h('div',{class:'log'});
  const refresh = ()=>{ clear(log); if(!RollLog.entries.length) log.append(h('div',{class:'dim',text:'ยังไม่มีการทอย'})); for (const e of RollLog.entries.slice(0,30)) log.append(rollEntryEl(e)); };
  const numOr = (v)=> (v==='' || v==null || isNaN(+v)) ? null : +v;
  const dcInp2 = ()=> numOr(st.dc);
  const defOpts = ()=>({cv: numOr(st.cv), loc: st.loc || null});
  const fire = (label, mod, kind)=>{
    const run = ()=>{
      const done = (e)=>{ refresh(); if (onRoll && e) onRoll(e); return e; };
      if (kind==='attack'){
        // ผู้โจมตีเลือก 2 ลูกเองเมื่อทอยเกิน 2 ลูก (Advantage หรือ Combat Dice เพิ่ม) · Disadvantage ฝ่ายรับเลือกให้ (ผู้ใช้เคาะ 11 พ.ย. 2026)
        const d = c ? compute(c) : null; const aim = st.aim || null; const sight = aim && d ? (d.sight||0) : 0;
        const cvMod = (numOr(st.cvMod)||0) + sight; const base = Math.max(2, Math.min(4, st.atkDice||2)); const n = base + (st.mode==='normal' ? 0 : 1);
        const lab = label + (aim ? ` · Focus (Precise) ${partLabel(aim)}${sight ? ' Sight '+signed(sight) : ''}` : '');
        if (st.mode==='dis'){
          const dice = Array.from({length:n}, rollD6);
          if (opts.pendingPick){ opts.pendingPick({dice, label: lab, cvMod, loc: aim, c}); toast('ทอยแล้ว รอฝ่ายรับ (หรือ GM) เลือก 2 ลูกในแชต'); return null; }
          return rollChoose(n, 'dis', `โจมตี (Disadvantage): ฝ่ายรับเลือก 2 จาก ${n} ลูก`, {kind:'attack', dice, cvMod, loc: aim, forDefender:true}).then(r => done(doRoll({label: lab + ' (Disadvantage: ฝ่ายรับเลือก)', mod: cvMod, persSide: st.pers||null, c, mode:'dis', kind, r, atk:{loc: aim, pick:'def'}})));
        }
        if (n > 2) return rollChoose(n, st.mode, `โจมตี: ทอย ${n}d6 เลือก 2 ลูก`, {kind:'attack', cvMod, loc: aim}).then(r => done(doRoll({label: lab, mod: cvMod, persSide: st.pers||null, c, mode: st.mode, kind, r, atk:{loc: aim, pick:'atk'}})));
        return done(doRoll({label: lab, mod: cvMod, persSide: st.pers||null, c, mode:'normal', kind, atk:{loc: aim}}));
      }
      // Parry: เต๋า = 2 + Parry Dice (+1 เมื่อ Advantage) สูงสุด 4 ลูก เลือกเอง 2 ลูก · Disadvantage = 2d6 เปล่า ๆ ไม่ได้ Parry Dice · Evade Advantage = 3d6 เลือกเอง
      const isDef = kind==='parry' || kind==='evade'; const dop = isDef ? defOpts() : null;
      let n = 0;
      if (kind==='parry'){ const pd = c ? compute(c).parryDice : 0; n = st.mode==='dis' ? 2 : parryDiceCount(pd, st.mode==='adv'); }
      else if (kind==='evade' && st.mode==='adv') n = 3;
      if (n > 2){
        const title = kind==='parry' ? `Parry: ทอย ${n}d6 เลือก 2 ลูก` : `Evade (Advantage): ทอย 3d6 เลือก 2 ลูก`;
        return rollChoose(n, st.mode, title, {kind, dc: dcInp2(), mod: kind==='evade' ? mod : 0, cv: dop.cv, loc: dop.loc}).then(r => done(doRoll({label, mod, persSide: st.pers||null, c, dc: dcInp2(), mode: st.mode, kind, r, def: dop})));
      }
      const mode = (kind==='parry' && st.mode==='dis') ? 'normal' : st.mode;
      return done(doRoll({label: label + (kind==='parry' && st.mode==='dis' ? ' (Disadvantage: 2d6 ไม่ใช้ Parry Dice)' : ''), mod, persSide: st.pers||null, c, dc: dcInp2(), mode, kind, dis: kind==='parry' && st.mode==='dis', def: dop}));
    };
    if (opts.guard) opts.guard(run, label); else run();
  };
  if (c){ const d = compute(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, STATS.map(s=>h('button',{class:'small rollbtn',onclick:()=>fire(`${s} Check`, d.mod[s]), text:`${s} ${signed(d.mod[s])}`}))));
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small rollbtn',onclick:()=>fire('Initiative', d.initiative),text:`Initiative ${signed(d.initiative)}`}), h('button',{class:'small rollbtn',onclick:()=>{ const blk = (typeof Table!=='undefined' && Table.attackBlocked) ? Table.attackBlocked(c) : null; if (blk){ toast(blk); return; } fire('Attack Roll (Combat Dice)', 0, 'attack'); },text:'Attack 2d6 (CV)'}), h('button',{class:'small rollbtn',title:'ทอยได้สูงสุด 4 ลูกไม่ว่าเต๋าจะมาจาก Parry Dice หรือ Advantage',onclick:()=>fire('Parry', 0, 'parry'),text:`Parry ${parryDiceCount(d.parryDice, false)}d6`}), h('button',{class:'small rollbtn',onclick:()=>fire('Evade (Reflex)', d.reflex, 'evade'),text:`Evade ${signed(d.reflex)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('VIT Saving Throw', d.fortitude),text:`VIT ST ${signed(d.fortitude)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('PER Saving Throw', d.will),text:`PER ST ${signed(d.will)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('Luck Saving Throw', 0, 'luck'),text:'Luck (8+)'})));
    const kl = knowledgeLevels(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, DATA.knowledge.map(k=>{ const kb2 = knowledgeBonus(c, d, k); return h('button',{class:'small ghost rollbtn',title:`ระดับความรู้ ${kb2.lv} (บวกบุคลิกภาพได้ด้วยตัวเลือกด้านบน)`,onclick:()=>fire(`${knLabel(k)} Check (Lv${kb2.lv})`, kb2.total)}, k.nameTh||k.nameEn, k.nameTh ? h('span',{class:'nm-en',text:k.nameEn}) : null, signed(kb2.total)); })));
  } else {
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small rollbtn',onclick:()=>fire('2d6',0),text:'ทอย 2d6'}), h('button',{class:'small rollbtn',onclick:()=>fire('Luck Saving Throw',0,'luck'),text:'Luck (8+)'}), h('button',{class:'small rollbtn',onclick:()=>fire('Attack Roll',0,'attack'),text:'Attack 2d6'})));
  }
  const custom = h('input',{type:'number',placeholder:'Mod',style:'width:80px'});
  box.append(h('div',{class:'row',style:'margin-bottom:8px'}, custom, h('button',{class:'small rollbtn',onclick:()=>fire('ทอยกำหนดเอง', +custom.value||0),text:'ทอย 2d6 + Mod'})));
  if (!opts.noLog){ box.append(log); refresh(); }
  return box;
}

/* ===== v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026): บาดแผลฉกรรจ์ การพัก และการรักษาแผล =====
 * บาดแผล: Toughness ของส่วนใดเหลือ 0 ทอย 1d6 ตามตารางของส่วนนั้น ผลจดไว้ใต้ตาราง Toughness (c.current.wounds) และประกาศในแชตของห้อง */
function woundModal(c, part, body, onDone){
  const rows = woundRows(part); const res = rollWound(part); const cur = c.current = c.current || {};
  const who = isTwinborn(c) ? bodyName(c, body) : (c.name || 'ตัวละคร'); const row = res.row || {name:'ไม่พบตาราง', text:''};
  cur.wounds = cur.wounds || []; cur.wounds.push({part, body: body || 'A', die: res.die, name: row.name, text: row.text, at: Date.now()});
  if (typeof Table !== 'undefined' && Table.roomId) Table.post({kind:'sys', who:'', text:`${who}: บาดแผลฉกรรจ์ที่${partLabel(part)} ทอย 1d6 ได้ ${res.die} ${row.name} · ${row.text}`});
  if (onDone) onDone();
  modal(h('div',{class:'woundmodal'}, h('h3',{text:`บาดแผลฉกรรจ์: ${partLabel(part)}ของ ${who}`}), h('p',{class:'desc',style:'margin:4px 0 8px'}, 'ทอย 1d6 ได้ ', h('b',{class:'num woundroll',text:String(res.die)})),
    h('table',{class:'t'}, h('tbody',null, rows.map(r=>h('tr',{class: r===res.row ? 'woundhit' : ''}, h('td',{class:'num',text: r.faces.length > 1 ? `${r.faces[0]}-${r.faces[r.faces.length-1]}` : String(r.faces[0])}), h('td',null, h('b',{text:r.name}), h('div',{class:'desc',style:'font-size:12px'}, T(r.text))))))),
    h('p',{class:'dim',style:'font-size:12px;margin-top:8px',text:'จดผลนี้ไว้ใต้ตาราง Toughness แล้ว ลบออกได้เมื่อรักษาหาย ถ้าส่วนนี้โดนซ้ำ Toughness ติดลบต่อไปได้จนถึงค่าเต็ม'})));
}
/* เสบียงในกระเป๋า (แฝดนับทั้งสองร่าง) และการหักเสบียงตอนพัก */
function rationRows(c){ const out = []; for (const body of (isTwinborn(c) ? ['A','B'] : ['A'])) for (const row of bagOf(c, body)) if (/เสบียง|\bRation\b/i.test(row.name || '')) out.push({row, body}); return out; }
function rationCount(c){ return rationRows(c).reduce((a, x)=>a + (x.row.qty || 1), 0); }
function takeRations(c, n){ let left = n; for (const {row, body} of rationRows(c)){ if (left <= 0) break; const take = Math.min(left, row.qty || 1); row.qty = (row.qty || 1) - take; left -= take; if (row.qty <= 0){ const bag = bagOf(c, body); const i = bag.indexOf(row); if (i >= 0) bag.splice(i, 1); } } return n - left; }
/* การพัก: ค่า Recovery ของ HP = Max HP ของ MP = Max MP · พักสั้นฟื้นครึ่งหนึ่ง (ปัดลง) · พักยาวฟื้นเต็ม ฟื้น Toughness 1 หน่วยในส่วนที่เลือก และรับการรักษาแผลได้หนึ่งครั้ง
 * ยาม 1 คน: ฟื้น HP/MP ครึ่งเดียว ไม่ฟื้น Toughness ทอย 2d6 ได้ 12 รับ 1 IP · ยาม 2 คน: ฟื้นเต็ม ไม่ฟื้น Toughness · แฝด: สองร่างฟื้นแยกกันและกินเสบียงสองอัตรา */
function restModal(c, d, kind, onDone){
  const cur = c.current; const twin = isTwinborn(c); const bodies = twin ? ['A','B'] : ['A']; const need = bodies.length; const have = rationCount(c);
  const tOf = (body)=> cur[body==='B' ? 'tough2' : 'tough'];
  const lost = (body)=> DATA.meta.bodyParts.filter(([k])=>(tOf(body)[k] ?? d.toughness) < d.toughness).map(([k, l])=>({k, label:`${l} (${tOf(body)[k]}/${d.toughness})`}));
  const st = {watch:0, eat: have >= need, rows: bodies.map(body=>{ const o = lost(body); return {body, opts:o, part: o[0] ? o[0].k : '', treat:0, treatPart: o[0] ? o[0].k : ''}; })};
  const long = kind === 'long'; const box = h('div',{class:'restmodal'});
  const draw = ()=>{ clear(box);
    const hpG = restGain(d.hp, kind, st.watch), mpG = restGain(d.mp, kind, st.watch);
    box.append(h('h3',{text: long ? '🛏 พักยาว (Long Rest)' : '🌙 พักสั้น (Short Rest)'}),
      h('p',{class:'desc',style:'margin:4px 0 10px',text: long ? 'พักเต็มคืน ฟื้น HP และ MP เต็ม (ค่า Recovery เท่ากับค่าสูงสุด) ฟื้น Toughness 1 หน่วยในส่วนที่เลือก และรับการรักษาแผลได้หนึ่งครั้ง' : 'พักช่วงสั้น ฟื้น HP และ MP ครึ่งหนึ่งของค่าสูงสุด (ปัดลง) และรีเซ็ตความสามารถที่ระบุว่ารีเซ็ตด้วยพักสั้น'}));
    if (long) box.append(h('div',{class:'row',style:'gap:8px;margin-bottom:8px;align-items:center'}, h('span',{text:'การเฝ้ายาม'}), h('select',{class:'restwatch',onchange:(e)=>{ st.watch = +e.target.value; draw(); }}, [[0,'ไม่ได้เฝ้ายาม (พักเต็ม)'],[1,'เฝ้ายามคนเดียว (ฟื้นครึ่งเดียว ไม่ฟื้น Toughness)'],[2,'เฝ้ายามสองคน (ฟื้นเต็ม ไม่ฟื้น Toughness)']].map(([v,t])=>{ const o = h('option',{value:v,text:t}); if (v===st.watch) o.selected = true; return o; }))));
    const tb = h('table',{class:'t'}, h('thead',null, h('tr',null, h('th',{text: twin ? 'ร่าง' : 'ตัวละคร'}), h('th',{text:'HP'}), long ? h('th',{text:'Toughness จากการพัก'}) : null, long ? h('th',{text:'รักษาแผล (Medical DC 8)'}) : null)));
    for (const row of st.rows){ const hk = row.body==='B' ? 'hp2' : 'hp'; const before = cur[hk] ?? d.hp; const after = Math.max(before, Math.min(d.hp, before + hpG));
      const partSel = (key, dis)=>{ const sel = h('select',{disabled: dis || !row.opts.length, onchange:(e)=>{ row[key] = e.target.value; }}, row.opts.length ? row.opts.map(o=>{ const op = h('option',{value:o.k,text:o.label}); if (o.k===row[key]) op.selected = true; return op; }) : [h('option',{value:'',text:'ไม่มีส่วนที่เสีย Toughness'})]); return sel; };
      tb.append(h('tr',null, h('td',{text: twin ? bodyName(c, row.body) : (c.name||'')}), h('td',{class:'num',text:`${before} → ${after}`}),
        long ? h('td',null, st.watch ? h('span',{class:'dim',text:'ผู้เฝ้ายามไม่ฟื้น'}) : partSel('part', false)) : null,
        long ? h('td',null, h('div',{class:'row',style:'gap:4px;flex-wrap:nowrap'}, h('select',{class:'resttreat',title:'ผู้มี Medical ระดับ 1 ขึ้นไปทอย Medical Check DC 8 ให้ ผ่านแล้วฟื้นเพิ่ม 1 หน่วย (ผู้รักษามี Surgical Trainee ฟื้น 2 หน่วย) รับได้หนึ่งครั้งต่อการพักยาว',disabled: !row.opts.length, onchange:(e)=>{ row.treat = +e.target.value; }}, [[0,'ไม่ได้รักษา'],[1,'ผ่าน ฟื้น +1'],[2,'ผ่าน ฟื้น +2 (Surgical Trainee)']].map(([v,t])=>{ const o = h('option',{value:v,text:t}); if (v===row.treat) o.selected = true; return o; })), partSel('treatPart', false))) : null)); }
    box.append(h('div',{class:'tablewrap'}, tb), h('p',{style:'margin:8px 0 4px'}, 'MP ', h('b',{class:'num',text:`${cur.mp ?? d.mp} → ${Math.max(cur.mp ?? d.mp, Math.min(d.mp, (cur.mp ?? d.mp) + mpG))}`}), twin ? h('span',{class:'dim',text:' (สองร่างใช้ MP ร่วมกัน)'}) : null));
    box.append(h('label',{class:'fld chk',style:'margin-top:6px'}, (()=>{ const cb = h('input',{type:'checkbox',class:'resteat',disabled: have < need, onchange:(e)=>{ st.eat = e.target.checked; }}); cb.checked = st.eat && have >= need; return cb; })(), h('span',{text:`หักเสบียงจากกระเป๋า ${need} อัตรา (มีอยู่ ${have})`})),
      h('p',{class:'dim',style:'font-size:12px;margin:4px 0 0',text:`การพักทุกครั้งต้องกินเสบียงหรืออาหารอย่างน้อย 1 อัตรา${twin ? ' แฝดสองร่างกินสองอัตรา' : ''} ถ้ากินอาหารอย่างอื่นไม่ต้องติ๊กช่องนี้` + (long ? ' · พักยาวลดระดับ Exhaustion ได้ 1 ระดับ' : '')}),
      h('div',{class:'row',style:'margin-top:12px;gap:8px'}, h('button',{class:'primary restok',onclick:apply,text: long ? 'พักยาว' : 'พักสั้น'}), h('button',{class:'small ghost',onclick:()=>modal(null),text:'ยกเลิก'})));
  };
  const apply = ()=>{
    const hpG = restGain(d.hp, kind, st.watch), mpG = restGain(d.mp, kind, st.watch); const notes = [];
    for (const row of st.rows){ const hk = row.body==='B' ? 'hp2' : 'hp'; const before = cur[hk] ?? d.hp; cur[hk] = Math.max(before, Math.min(d.hp, before + hpG)); if (cur[hk] !== before) notes.push(`${twin ? bodyName(c, row.body)+' ' : ''}HP ${before} เป็น ${cur[hk]}`);
      const tm = tOf(row.body); const up = (k, n, why)=>{ if (!k || tm[k] == null || n <= 0) return; const b = tm[k]; tm[k] = Math.min(d.toughness, b + n); if (tm[k] !== b) notes.push(`${twin ? bodyName(c, row.body)+' ' : ''}${partLabel(k)} Toughness ${b} เป็น ${tm[k]} (${why})`); };
      if (long && !st.watch) up(row.part, 1, 'พัก'); if (long && row.treat) up(row.treatPart, row.treat, 'รักษาแผล'); }
    const mb = cur.mp ?? d.mp; cur.mp = Math.max(mb, Math.min(d.mp, mb + mpG)); if (cur.mp !== mb) notes.push(`MP ${mb} เป็น ${cur.mp}`);
    if (st.eat && have >= need){ takeRations(c, need); notes.push(`กินเสบียง ${need} อัตรา`); }
    if (long && st.watch === 1){ const r = roll2d6('normal'); if (r.sum === 12){ cur.ip = (cur.ip||0) + 1; notes.push('เฝ้ายามทอย 2d6 ได้ 12 รับ 1 IP'); } else notes.push(`เฝ้ายามทอย 2d6 ได้ ${r.sum} (ได้ 12 จึงรับ IP)`); }
    cur.at = Date.now(); modal(null); if (onDone) onDone();
    const head = `${c.name||'ตัวละคร'} ${long ? 'พักยาว' : 'พักสั้น'}`; toast(notes.length ? `${head}: ${notes.join(' · ')}` : `${head}: ไม่มีค่าที่ต้องฟื้น`);
    if (typeof Table !== 'undefined' && Table.roomId) Table.post({kind:'sys', who:'', text: notes.length ? `${head}: ${notes.join(' · ')}` : `${head}`});
  };
  draw(); modal(box);
}

/* ---- Sheet (โครงตามชีท Duck Family: ซ้าย=ภาพ/ทรัพยากร, กลาง=ตัวตน/นิสัย/Trait/สกิล/ของ, ขวา=STATUS/บุคลิก/Combat Mod/ความรู้/เต๋า) ---- */
const SheetUI = { drawer: null };
const EQUIP_SLOTS = [['weapon1','Weapon 1 อาวุธหลัก'],['weapon2','Weapon 2 อาวุธสำรอง'],['shield','Shield โล่'],['head','Head'],['neck','Neck'],['back','Back'],['shirt','Shirt'],['chestIn','Chest (In)'],['chestOut','Chest (Out)'],['hands','Hands & Wrists'],['waist','Waist'],['legs','Legs'],['feet','Feet'],['cape','Cape']];
/* จัดช่องสวมใส่จากชื่อ/คุณสมบัติของไอเทม (ไฟล์ Starter Set ไม่ระบุช่อง) */
function itemSlot(name, effect){
  const n = name||'', e = effect||'';
  const has = (re)=>re.test(n);
  if (has(/โล่|Shield/i)) return 'shield';
  if (has(/หมวก|Helm|หน้ากาก|Mask|Hat\b|Coif|Beanie|Beret|Cap\b|Chaperon|Browband/i)) return 'head';
  if (has(/ถุงมือ|Gloves|ปลอกแขน|Bracers|แหวน|Ring\b/i)) return 'hands';
  if (has(/รองเท้า|Boots|Sandals/i)) return 'feet';
  if (has(/เข็มขัด|Belt/i)) return 'waist';
  if (has(/ผ้าคลุม|เสื้อคลุมมีฮู้ด|Cloak|Cape|Poncho/i)) return 'cape';
  if (has(/กางเกง|กระโปรง|Trousers|Breeches|Skirt/i)) return 'legs';
  if (has(/แกมเบสัน|Gambeson/i) || /ชั้นใน Armor/.test(e)) return 'chestIn';
  if (has(/เกราะ|Armor|โค้ท|Coat|เสื้อกั๊ก|Vest|เอี๊ยม|Apron|Robe|เสื้อคลุม/i)) return 'chestOut';
  if (has(/ทูนิค|Tunic|เชิ้ต|Shirt/i)) return 'shirt';
  if (has(/กระเป๋า|Satchel|Backpack|เป้/i)) return 'back';
  if (has(/สัญลักษณ์ศักดิ์สิทธิ์|Holy Symbol|สร้อย|Amulet|Necklace/i)) return 'neck';
  if (/\d\s*[PM]DMG|Might\s*\(/.test(e)) return 'weapon';
  return null;
}
/* ของสวมใส่ = {name, effect, weight} ต่อช่อง น้ำหนักนับรวมกับกระเป๋า · สวมแล้วย้ายออกจากกระเป๋า (ไม่นับซ้ำ) */
function equipWeight(c){ return Object.values(c.equip||{}).reduce((a,e)=>a + (e && e.weight ? +e.weight : 0), 0); }
function listWeight(list){ return (list||[]).reduce((a,r)=>a + (r.qty||0)*(r.weight||0), 0); }
function bagWeight(c){ return listWeight(c.inventory); }
/* ค่า Armor ต่ออวัยวะจากของสวมใส่: รูปแบบในไฟล์ "Armor A/B (ชนิด)" = A กันกายภาพทั่วไป, B กันชนิดในวงเล็บ (ส่วนใหญ่ Blunt) · "Main Armor n ที่ลำตัว" (เข็มขัดโซ่) ไม่ทบกับเกราะลำตัว ใช้ค่าที่สูงกว่า (ข้อเคาะ 8 ของ Starter Set) · ชั้นใน + ชั้นนอกบวกกัน */
const ARMOR_SLOT_PARTS = {head:['head'], shirt:['torso'], chestIn:['torso'], chestOut:['torso'], cape:[], back:[], neck:[], hands:['armL','armR'], legs:['legL','legR'], feet:['legL','legR'], waist:['torso'], weapon1:[], weapon2:[], shield:[]};
function parseArmor(effect){ const m = /Armor\s+(\d+)\s*\/\s*(\d+)(?:\s*\(([^)]+)\))?/.exec(effect||''); if (m) return {a:+m[1], b:+m[2], type:(m[3]||'Blunt').trim()}; const m2 = /Armor\s+(\d+)(?!\s*\/)/.exec(effect||''); if (m2) return {a:+m2[1], b:+m2[1], type:''}; return null; }
function armorFromEquip(c){
  const parts = {}; for (const [k] of DATA.meta.bodyParts) parts[k] = {a:0, b:0, types:new Set(), belt:0};
  for (const [slot, e] of Object.entries(c.equip||{})){ if (!e || !e.effect) continue; const ar = parseArmor(e.effect); if (!ar) continue; const targets = ARMOR_SLOT_PARTS[slot] || [];
    for (const pk of targets){ if (slot==='waist') parts[pk].belt = Math.max(parts[pk].belt, ar.a); else { parts[pk].a += ar.a; parts[pk].b += ar.b; if (ar.type) parts[pk].types.add(ar.type); } } }
  const out = {};
  for (const [k,v] of Object.entries(parts)){ const a = Math.max(v.a, v.belt), b = Math.max(v.b, v.belt); if (!a && !b){ out[k]=''; continue; } const t = [...v.types].filter(x=>x && x!=='Blunt'); out[k] = `${a}/${b}` + (t.length? ` (${t.join('/')})` : ''); }
  return out;
}
function recalcArmor(c){ c.armor = armorFromEquip(c); c.armorAuto = true; }
function recalcParry(c){ c.current = c.current||{}; c.current.parryBonus = Object.values(c.equip||{}).reduce((a,e)=>{ const m=/\+(\d+)\s*Parry Dice/.exec((e&&e.effect)||''); return a + (m? +m[1] : 0); }, 0); }
function migrateEquip(c){ // ชีทเก่า (v0.4) เก็บช่องเป็นข้อความ "ชื่อ · คุณสมบัติ" และยังมีของชิ้นเดียวกันค้างในกระเป๋า
  let migrated = false;
  for (const [k,v] of Object.entries(c.equip||{})){ if (v && typeof v === 'string'){ const parts = v.split(' / ')[0].split(' · '); c.equip[k] = {name: parts[0].trim(), effect: parts.slice(1).join(' · ').trim(), weight: 0}; migrated = true; } else if (v && v.weight==null) v.weight = 0; }
  if (migrated && c.inventory){
    for (const e of Object.values(c.equip)){ if (!e || !e.name) continue; const i = c.inventory.findIndex(r=>r.name===e.name); if (i<0) continue; const row = c.inventory[i]; e.weight = +row.weight||0; if (!e.effect) e.effect = row.effect||''; if ((row.qty||1) > 1) row.qty--; else c.inventory.splice(i,1); }
    recalcParry(c);
  }
  if (c.inventory) for (const r of c.inventory) if (r.worn){ delete r.worn; } }
/* ใส่ไอเทมจากกระเป๋าลงช่อง: ของเดิมในช่องกลับเข้ากระเป๋า, ไอเทมที่มีหลายชิ้นลดจำนวนลง 1 */
function wearItem(c, idx, slot){
  const row = c.inventory[idx]; if (!row) return;
  unequip(c, slot);
  c.equip[slot] = {name: row.name, effect: row.effect||'', weight: +row.weight||0};
  if ((row.qty||1) > 1) row.qty--; else c.inventory.splice(idx,1);
  recalcParry(c); recalcArmor(c);
}
function unequip(c, slot){
  const e = c.equip[slot]; if (!e || !(e.name||'').trim()) { delete c.equip[slot]; return; }
  const same = c.inventory.find(r=>r.name===e.name && (r.effect||'')===(e.effect||'') && +r.weight===+e.weight);
  if (same) same.qty = (same.qty||0)+1; else c.inventory.push({name:e.name, effect:e.effect||'', qty:1, weight:+e.weight||0});
  delete c.equip[slot]; recalcParry(c); recalcArmor(c);
}
function autoEquip(c){
  // ถอดทุกอย่างกลับกระเป๋าก่อน แล้วสวมใหม่ตามชื่อ/คุณสมบัติ
  for (const k of Object.keys(c.equip||{})) unequip(c, k);
  c.equip = {};
  let w = 0;
  for (let i = 0; i < c.inventory.length; ){
    const row = c.inventory[i];
    if (/^หรือ\s/.test(row.name)) { i++; continue; } // ทางเลือกของชุด (เช่น ดาบ หรือ หอก) ไม่สวมอัตโนมัติ
    let slot = itemSlot(row.name, row.effect);
    if (slot==='weapon'){ if (w>=2){ i++; continue; } w++; slot = 'weapon'+w; }
    else if (slot==='chestIn' && c.equip.chestIn) slot = 'chestOut';
    if (!slot || c.equip[slot]) { i++; continue; }
    const before = c.inventory.length; wearItem(c, i, slot); if (c.inventory.length === before) i++; // ถ้าแถวถูกลบ ไม่ต้องขยับ index
  }
  // เครื่องแต่งกายของชุด (outfit) ไม่ใช่ไอเทมในกระเป๋า: สวมเป็นชิ้นน้ำหนัก 0 เฉพาะช่องที่ยังว่าง
  const set = c.starterSet ? DATA.sets.sets.find(x=>x.nameEn===c.starterSet) : null;
  if (set && set.outfit){ for (const piece of set.outfit.split(/,\s*|\s+กับ\s+/)){ const nm = piece.trim(); if (!nm) continue; let slot = itemSlot(nm, '') || 'shirt'; if (slot==='weapon') slot='shirt'; if (!c.equip[slot]) c.equip[slot] = {name:nm, effect:'เครื่องแต่งกาย', weight:0}; } }
  recalcParry(c); recalcArmor(c);
  c.equipAuto = true;
}
function ensureSheetState(c, d){
  migrateFaithSlots(c); migrateNames(c);
  c.current = Object.assign({hp:d.hp, mp:d.mp, sanity:d.sanity, temp:0, ap:3, ip:0, money:15, tough:{}}, c.current||{});
  for (const [k] of DATA.meta.bodyParts) if (c.current.tough[k]==null) c.current.tough[k] = d.toughness;
  c.armor = c.armor || {}; c.equip = c.equip || {}; c.details = c.details || {};
  c.extraText = Object.assign({languages:'', quest:'', note:'', reputation:'', relationship:''}, c.extraText||{});
  migrateLanguages(c); // v1.18: ช่องภาษากลายเป็นป้ายภาษา ข้อความตั้งต้นของวงศาที่ไม่มีใครแก้ถูกล้าง ส่วนที่ผู้เล่นพิมพ์เองเก็บเป็นหมายเหตุ
  if (!c.inventory){
    c.inventory = [];
    const set = c.starterSet ? DATA.sets.sets.find(x=>x.nameEn===c.starterSet) : null;
    const items = [...(set? chosenSetItems(c, set) : []), ...DATA.sets.common.items];
    for (const it of items){ const m = it.name.match(/×\s*(\d+)/); c.inventory.push({name: it.name.replace(/\(เสนอ\)\s*/,'').replace(/\s*×\s*\d+/,'').trim(), effect: it.effect||'', qty: m? +m[1] : 1, weight: parseFloat(it.weight)||0}); }
  }
  migrateEquip(c);
  // Twinborn: ร่าง B มี HP และกระเป๋าของตัวเอง (เริ่ม HP เต็ม กระเป๋าว่าง) · ถ้าเลิกเป็นแฝด (แก้พื้นหลังในวิซาร์ด) ของในกระเป๋าร่าง B กลับเข้ากระเป๋าหลัก
  if (isTwinborn(c)){ if (c.current.hp2 == null) c.current.hp2 = d.hp; if (!Array.isArray(c.inventory2)) c.inventory2 = []; c.twinborn = Object.assign({nameB:'', apart:false, control:'A'}, c.twinborn||{});
    // v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026): แต่ละร่างมี Toughness และเกราะของตัวเอง · ตัวละครที่สร้างก่อนหน้านี้ให้ร่าง B เริ่มจากค่าของร่าง A ณ ตอนนั้น
    if (!c.current.tough2){ c.current.tough2 = {}; for (const [k] of DATA.meta.bodyParts) c.current.tough2[k] = c.current.tough[k] != null ? c.current.tough[k] : d.toughness; }
    for (const [k] of DATA.meta.bodyParts) if (c.current.tough2[k]==null) c.current.tough2[k] = d.toughness;
    if (!c.armor2) c.armor2 = Object.assign({}, c.armor||{}); }
  else if (Array.isArray(c.inventory2)){ if (c.inventory2.length) c.inventory.push(...c.inventory2); delete c.inventory2; }
  if (!c.armorAuto && !Object.values(c.armor||{}).some(v=>v && String(v).trim())) recalcArmor(c);
  // สวมของจากชุดเริ่มต้นให้ทันทีครั้งแรก (ตัวละครเก่าที่ยังไม่เคยสวมและช่องว่างทั้งหมดก็สวมให้)
  if (!c.equipAuto && !Object.values(c.equip).some(v=>v && (v.name||'').trim())) autoEquip(c);
}
function renderSheet(id){
  const root = clearKeep($('#v-sheet'));
  const c = Store.get(id);
  if (!c){ root.append(h('div',{class:'card'}, h('p',{text:'ไม่พบตัวละครนี้ในบัญชีของคุณ'}), h('p',{class:'dim',style:'font-size:13px',text:'ชีทของผู้เล่นคนอื่นเปิดได้เฉพาะจากห้องที่เขาหยิบตัวละครลงบอร์ด (กดปุ่ม "ชีท" ที่หมาก)'}), h('button',{style:'margin-top:8px',onclick:()=>{ location.hash = Table.roomId ? '#room-'+Table.roomId : '#chars'; },text:'← กลับ'}))); HUD.hide(); return; }
  const readOnly = !Store.canEdit(c); SheetUI.readOnly = readOnly;
  if (readOnly && c.shareMode==='min'){ if (Table.roomId) root.append(h('div',{class:'roombar'}, h('button',{class:'primary small',onclick:()=>{ location.hash='#room-'+Table.roomId; },text:'← กลับโต๊ะเล่น'}), h('span',{class:'dim',style:'font-size:13px',text:`ชีทย่อของ ${c.ownerName||'ผู้เล่นคนอื่น'}`}))); root.append(renderMinSheet(c)); HUD.hide(); return; }
  let d = compute(c); const kin = KIN[c.kin];
  ensureSheetState(c, d); d = compute(c); // สวมของอัตโนมัติอาจเปลี่ยน Parry Dice
  const cur = c.current; const det = c.details;
  const save = ()=>{ if (!readOnly) Store.upsert(c); };
  if (Table.roomId) root.append(h('div',{class:'roombar'}, h('button',{class:'primary small',onclick:()=>{ location.hash='#room-'+Table.roomId; },text:'← กลับโต๊ะเล่น'}), h('span',{class:'dim',style:'font-size:13px'}, 'ห้อง ', h('b',{text: Table.room ? Table.room.name : ''}), ' ยังเปิดอยู่ · ', readOnly ? `ชีทของ ${c.ownerName||'ผู้เล่นคนอื่น'} (อ่านอย่างเดียว)` : 'ชีทของคุณ ทอยจากชีทจะเด้งเข้าห้อง')));
  else if (readOnly) root.append(h('div',{class:'warnbox',style:'margin-bottom:10px'}, `ชีทของ ${c.ownerName||'ผู้เล่นคนอื่น'} (อ่านอย่างเดียว)`));
  const rerender = ()=>renderSheet(id);
  const txt = (obj, key, ph, multi) => { const el = multi ? h('textarea',{placeholder:ph||''}) : h('input',{placeholder:ph||''}); el.value = obj[key]||''; el.oninput = ()=>{ obj[key] = el.value; }; el.onblur = save; return el; };
  // ===== left =====
  const left = h('div');
  const portrait = h('div',{class:'portrait', title:'คลิกเพื่อใส่ภาพตัวละคร'});
  if (c.portrait) portrait.append(h('img',{src:c.portrait, alt:c.name})); else portrait.append(h('div',null, '[แทรกภาพตัวละคร]', h('div',{class:'muted',style:'font-size:11px',text:'คลิกเพื่อเลือกไฟล์'})));
  const fileInp = h('input',{type:'file',accept:'image/*',class:'sr',onchange:(e)=>{ const f=e.target.files[0]; if(!f) return; const img=new Image(); img.onload=()=>{ const cv=document.createElement('canvas'); const sc=Math.min(1, 360/Math.max(img.width,img.height)); cv.width=Math.round(img.width*sc); cv.height=Math.round(img.height*sc); cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height); c.portrait=cv.toDataURL('image/jpeg',0.82); save(); rerender(); if (Table.room){ const tks = Table.room.tokens.filter(t=>t.charId===c.id); if (tks.length) makeThumb(c.portrait).then(th=>{ for (const tk of tks) tk.thumb = th; Table.save(); }); } }; img.src=URL.createObjectURL(f); }});
  portrait.onclick = ()=>fileInp.click();
  left.append(h('div',{class:'box',dataset:{k:'portrait'}}, portrait, fileInp, h('div',{class:'idgrid',style:'margin-top:8px'}, h('span',{class:'k',text:'ชื่อผู้เล่น'}), txt(det,'player','Player name'))));
  const resBox = h('div',{class:'box',dataset:{k:'res'}}, h('h4',{text:'ทรัพยากร'}));
  const resbar = (label, key, max, color, term) => { const v = cur[key]||0; return h('div',{class:'resbar'}, h('div',{class:'l'}, h('b',{text:label}), h('span',{class:'num'}, `${v} / ${max}`)), h('div',{class:'bar'}, h('i',{style:`width:${Math.max(0,Math.min(100, max? v/max*100 : 0))}%;background:${color}`})), h('div',{class:'ctl'}, h('button',{class:'small',onclick:()=>{cur[key]=v-1; vit(); rerender();},text:'−'}), h('button',{class:'small',onclick:()=>{cur[key]=Math.min(max,v+1); vit(); rerender();},text:'+'}), h('input',{type:'number',value:v,onchange:(e)=>{cur[key]=+e.target.value||0; vit(); rerender();}}), h('button',{class:'small ghost',onclick:()=>{cur[key]=max; vit(); rerender();},text:'เต็ม'}))); };
  const vit = ()=>{ cur.at = Date.now(); save(); if (!readOnly && typeof pushVitalsFromSheet==='function') pushVitalsFromSheet(c); }; // HP/Sanity ที่แก้ในชีทไปโผล่ที่หมากในห้องทันที
  const twin = isTwinborn(c); // Twinborn (Lunaryn): สองร่าง HP และกระเป๋าแยกกัน · MP กับ Sanity ใช้ร่วมกัน (ผู้ใช้เคาะ 10 พ.ย. 2026)
  resBox.append(...[resbar('Sanity','sanity',d.sanity,'#a371f7','Sanity'), resbar(twin ? 'Health Points · ร่าง A' : 'Health Points','hp',d.hp,'#e5484d','HP'), twin ? resbar('Health Points · ร่าง B','hp2',d.hp,'#d9623b','HP') : null, resbar('Mana Points','mp',d.mp,'#58b7ff','MP')].filter(Boolean));
  if (twin) resBox.append(h('p',{class:'dim',style:'font-size:11px;margin:4px 0 0',text:'แฝดสองร่างมี HP แยกกัน ส่วน Sanity และ MP ใช้ร่วมกัน'}));
  resBox.append(h('div',{class:'resbar'}, h('div',{class:'l'}, h('b',{text:'Temporary Health'}), h('span',{class:'num',text:String(cur.temp||0)})), h('div',{class:'bar'}, h('i',{style:`width:${Math.min(100,(cur.temp||0)*10)}%;background:#e8c547`})), h('div',{class:'ctl'}, h('button',{class:'small',onclick:()=>{cur.temp=Math.max(0,(cur.temp||0)-1); save(); rerender();},text:'−'}), h('button',{class:'small',onclick:()=>{cur.temp=(cur.temp||0)+1; save(); rerender();},text:'+'}), h('button',{class:'small ghost',onclick:()=>{cur.temp=0; save(); rerender();},text:'ล้าง'}))));
  resBox.append(h('div',{class:'idgrid',style:'margin-top:8px'}, h('span',{class:'k',text:'Insight Point'}), h('div',{class:'row',style:'gap:4px'}, h('button',{class:'small',onclick:()=>{cur.ip=Math.max(0,(cur.ip||0)-1); save(); rerender();},text:'−'}), h('b',{class:'num',text:String(cur.ip||0)}), h('button',{class:'small',onclick:()=>{cur.ip=(cur.ip||0)+1; save(); rerender();},text:'+'}), h('button',{class:'small primary',onclick:()=>openIpShop(c, ()=>{ save(); rerender(); }),text:'ใช้ IP ▸'})), h('span',{class:'k',text:'เกรฟ (เงิน)'}), h('input',{type:'number',value:cur.money||0,onchange:(e)=>{cur.money=+e.target.value||0; save();}})));
  if (!readOnly) resBox.append(h('div',{class:'row restrow',style:'margin-top:8px;gap:6px'}, h('button',{class:'small restbtn',dataset:{rest:'short'},title:'พักสั้น: ฟื้น HP และ MP ครึ่งหนึ่งของค่าสูงสุด (ปัดลง)',onclick:()=>restModal(c, d, 'short', ()=>{ vit(); rerender(); }),text:'🌙 พักสั้น'}), h('button',{class:'small restbtn',dataset:{rest:'long'},title:'พักยาว: ฟื้น HP และ MP เต็ม ฟื้น Toughness 1 หน่วย และรับการรักษาแผลได้',onclick:()=>restModal(c, d, 'long', ()=>{ vit(); rerender(); }),text:'🛏 พักยาว'})));
  left.append(resBox);
  const tb = h('div',{class:'box',dataset:{k:'tough'}}, h('h4',null, T('Toughness'), ' / ', T('Armor')));
  // ผู้ใช้เคาะ 10 พ.ย. 2026: ชื่อส่วนกับ Tough ชิดกัน ช่องจดเกราะกว้างเต็มที่ที่เหลือ และบอกเลขตำแหน่งใต้ชื่อส่วน (โดน = ผลรวมเต๋าโจมตี · กัน = เลขที่ Parry ได้)
  // v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026): Toughness ติดลบได้ถึงค่าเต็ม · เหลือ 0 = ทอยตารางบาดแผลฉกรรจ์ · ติดลบถึงค่าเต็ม = แขนขาขาด หัว/ลำตัว = Mortal Wound · แฝดมี Toughness และเกราะแยกร่าง
  const tBody = twin && SheetUI.toughBody==='B' ? 'B' : 'A'; const tKey = tBody==='B' ? 'tough2' : 'tough'; const aKey = tBody==='B' ? 'armor2' : 'armor';
  const tMap = cur[tKey]; const aMap = c[aKey] = c[aKey] || {};
  if (twin) tb.append(h('div',{class:'bagtabs toughtabs'}, ['A','B'].map(k=>h('button',{class:'small bagtab'+(tBody===k?' primary':''),dataset:{tbody:k},title:`Toughness และเกราะของ${bodyName(c, k)}`,onclick:()=>{ SheetUI.toughBody = k; rerender(); },text:bodyName(c, k)}))));
  const bg2 = h('div',{class:'body2'}, h('span',{class:'dim',text:'ส่วน'}), h('span',{class:'dim',text:'Tough'}), h('span',{class:'dim',text:'เกราะ A/B (จดเพิ่มได้)'}));
  const tFloor = toughFloor(d.toughness);
  const tSay = (msg)=>{ toast(msg); if (!readOnly && typeof Table !== 'undefined' && Table.roomId) Table.post({kind:'sys', who:'', text:`${twin ? bodyName(c, tBody) : (c.name||'ตัวละคร')}: ${msg}`}); }; // ประกาศในแชตของห้องด้วย เหมือนตอนแก้จากหมาก
  for (const [k,label] of DATA.meta.bodyParts){ const v = tMap[k]; const atk = HIT_ATTACK[k]||[], def = HIT_DEFEND[k]||[]; const same = atk.join()===def.join(); const stt = toughState(k, v, d.toughness);
    bg2.append(h('div',{class:'bp'}, h('span',{text:label}), h('span',{class:'hitnum',title:'ผลรวมเต๋า 2 ลูก · โดน: การโจมตีที่ออกเลขนี้เข้าส่วนนี้ · กัน: Parry การโจมตีที่เข้าส่วนนี้สำเร็จเมื่อทอยได้เลขใดเลขหนึ่ง',text: same ? `โดน/กัน ${atk.join(' ')}` : `โดน ${atk.join(' ')} · กัน ${def.join(' ')}`}),
        stt ? h('span',{class:'tstate ts-'+stt,title: stt==='wound' ? 'Toughness เหลือ 0 หรือต่ำกว่า: ทอยตารางบาดแผลฉกรรจ์ของส่วนนี้ โดนซ้ำติดลบต่อได้จนถึงค่าเต็ม' : (stt==='lost' ? 'ติดลบถึงค่าเต็ม: แขนหรือขาส่วนนี้ขาด' : 'ติดลบถึงค่าเต็ม: ให้ผลเท่ากับบาดแผลลึกช้ำใน (HP เหลือ 0 เข้าสู่ใกล้ตาย เสียแต้มยื้อชีวิต 1 แต้ม)'),text:toughStateText(stt)}) : null,
        (stt==='wound' && !readOnly) ? h('button',{class:'small ghost woundbtn',dataset:{part:k},title:'ทอย 1d6 ตามตารางบาดแผลฉกรรจ์ของส่วนนี้',onclick:()=>woundModal(c, k, tBody, ()=>{ vit(); rerender(); }),text:'🎲 บาดแผล'}) : null),
      h('div',{class:'row',style:'gap:2px;flex-wrap:nowrap'}, h('button',{class:'small',onclick:()=>{ const nv = Math.max(tFloor, v-1); tMap[k] = nv; if (nv===0 && v>0) tSay(`${label}เหลือ Toughness 0 ทอยตารางบาดแผลฉกรรจ์ของส่วนนี้`); else if (nv <= tFloor && v > tFloor) tSay(`Toughness ของ${label}ติดลบถึงค่าเต็ม ${(k==='head' || k==='torso') ? 'ให้ผลเท่ากับ Mortal Wound (HP เหลือ 0 เข้าสู่ใกล้ตาย)' : 'ส่วนนี้ขาด'}`); vit(); rerender(); },text:'−'}), h('b',{class:'num',style:'min-width:38px;text-align:center;'+(v<=0?'color:var(--bad)':''),text:`${v}/${d.toughness}`}), h('button',{class:'small',onclick:()=>{tMap[k]=Math.min(d.toughness,v+1); vit(); rerender();},text:'+'})),
      h('input',{value:aMap[k]||'',placeholder:'A/B',title:'A/B = กันกายภาพทั่วไป / กัน Blunt (หรือชนิดในวงเล็บ) จดรายละเอียดเพิ่มต่อท้ายได้',onchange:(e)=>{aMap[k]=e.target.value; save();}})); }
  const wl = (cur.wounds||[]).filter(w=>(w.body||'A')===tBody);
  tb.append(...[bg2, h('div',{class:'row',style:'margin-top:6px;justify-content:space-between;align-items:center'}, h('span',{class:'dim',style:'font-size:11px',text:'เกราะ A/B = กันทั่วไป / กัน Blunt'}), tBody==='A' ? h('button',{class:'small ghost',title:'คำนวณค่าเกราะจากของสวมใส่ใหม่ (ทับข้อความที่จดไว้ในช่องเกราะ)',onclick:()=>{ recalcArmor(c); save(); rerender(); },text:'จากของสวมใส่'}) : h('span',{class:'dim',style:'font-size:11px',text:'เกราะของร่างนี้จดเองในช่อง'})),
    wl.length ? h('div',{class:'woundlist'}, wl.map(w=>h('div',{class:'wound'}, h('b',{text:`${partLabel(w.part)}: ${w.name}`}), h('span',{class:'dim',text:` (ทอยได้ ${w.die})`}), readOnly ? null : h('button',{class:'small ghost',title:'ลบบาดแผลนี้ออกจากรายการ (รักษาหายแล้วหรือจดผิด)',onclick:()=>{ cur.wounds = (cur.wounds||[]).filter(x=>x!==w); vit(); rerender(); },text:'×'}), h('div',{class:'desc',style:'font-size:11.5px'}, T(w.text||''))))) : null,
    h('p',{class:'dim hitnote',style:'font-size:11px;margin:8px 0 0',text:'ตำแหน่งที่โดนดูจากผลรวมเต๋าโจมตี 2 ลูก (เลข "โดน") ตัวปรับ CV ไม่ขยับตำแหน่ง · Parry สำเร็จเมื่อผลรวม 2 ลูกที่เลือกเป็นเลขใดเลขหนึ่งในช่อง "กัน" ของส่วนที่ถูกโจมตี แขนกับขาข้างเดียวกันใช้เลขร่วมกัน · ได้เท่ากับผลโจมตีพอดี = Perfect Parry · เกราะที่หักความเสียหายกายภาพจนเหลือ 0 ทำให้ส่วนนั้นไม่เสีย Toughness'})].filter(Boolean));
  left.append(tb);
  // ===== middle =====
  const mid = h('div');
  const idb = h('div',{class:'box',dataset:{k:'id'}}, h('div',{class:'row',style:'justify-content:space-between'}, h('h2',{text:c.name}), h('div',{class:'row'}, readOnly? null : (Store.inCampaign(c) && !Store.isDevUid) ? h('span',{class:'tag',title:'ตัวละครอยู่ในแคมเปญแล้ว ค่าพื้นฐานจากวิซาร์ดล็อก เติบโตผ่าน IP และแก้รายละเอียดในชีทได้',text:'🔒 อยู่ในแคมเปญ'}) : h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#wizard'; },text:'แก้ไขในวิซาร์ด'}), readOnly? null : shareModeSel(c, save), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}), readOnly? null : h('button',{class:'small ghost danger',title:'ลบตัวละครนี้ออกจากบัญชีและจากทุกห้องที่อยู่',onclick:()=>{ if (!confirm(`ลบ ${c.name||'ตัวละครนี้'} ถาวร? สำเนาในห้องและหมากบนบอร์ดจะถูกถอนออกด้วย`)) return; Store.remove(c.id); toast('ลบตัวละครแล้ว'); location.hash = '#chars'; },text:'ลบตัวละคร'}))));
  const ig = h('div',{class:'idgrid',style:'margin-top:8px'});
  const kv = (k, v) => ig.append(h('span',{class:'k',text:k}), typeof v === 'string' ? h('span',{text:v}) : v);
  kv('Age อายุ', txt(det,'age')); kv('Gender เพศ', txt(det,'gender')); kv('Job อาชีพ', txt(det,'job', c.starterSet||'')); kv('Size ขนาด', d.size); kv('Height/Weight', txt(det,'height')); kv('Speed ความเร็ว', kin.speed); kv('Kin วงศา', kin.name);
  const ch = findBg(kin,c.childhood), ad = findBg(kin,c.adulthood);
  kv('Childhood', ch ? `${ch.name} (${ch.nameEn})` : '-'); kv('Adulthood', ad ? `${ad.name} (${ad.nameEn})` : '-'); { const lg = h('div',{class:'langs sheetlangs'}, langChips(c)); if (!readOnly) lg.append(h('button',{class:'small ghost langedit',title:'เลือกภาษาตามสิทธิ์ของวงศา เพิ่มภาษาที่ได้ระหว่างเล่น หรือจดหมายเหตุ',onclick:()=>langModal(c, ()=>{ save(); rerender(); }),text:'แก้ภาษา'})); if (String(c.extraText.languages||'').trim()) lg.append(h('div',{class:'langnote-view',text:c.extraText.languages})); kv('Languages ภาษา', lg); }
  idb.append(ig);
  mid.append(idb);
  const pt = h('div',{class:'box',dataset:{k:'traits'}}, h('h4',{text:'Personal Traits นิสัยส่วนตัว'}));
  // v1.17 (ผู้ใช้แจ้ง 12 พ.ย. 2026 ว่าช่องเขียนเล็กเกินไป): ป้ายอยู่เหนือช่อง ทุกช่องเป็นหลายบรรทัดกว้างเต็มกล่อง สูงเริ่มต้น 2 บรรทัด (ช่องยาว 3 บรรทัด) แล้วยืดตามข้อความ
  if (AREA_RO) AREA_RO.disconnect(); // ช่องของการวาดรอบก่อนถูกทิ้งไปแล้ว
  const ptShort = h('div',{class:'ptshort'}); const pg = h('div',{class:'ptgrid'}, ptShort); // หกช่องสั้นเรียงสองคอลัมน์เมื่อกล่องกว้างพอ (ช่องละ 230px ขึ้นไป) กล่องแคบเรียงคอลัมน์เดียว
  for (const [k,label,long] of [['likes','Likes ชอบ'],['dislikes','Dislikes ไม่ชอบ'],['fears','Fears หวาดกลัว'],['want','Want'],['need','Need'],['manifest','Manifest'],['motivation','Motivation แรงจูงใจ',true],['appearance','Appearance',true],['backstory','Backstory',true],['signature','Signature Look',true]]){ const ta = txt(det,k,'',true); ta.classList.add('ag'); if (long) ta.classList.add('long'); ta.dataset.f = k; ta.addEventListener('input', ()=>fitArea(ta)); if (AREA_RO) AREA_RO.observe(ta); (long ? pg : ptShort).append(h('label',{class:'k'}, label, ta)); }
  pt.append(pg); mid.append(pt);
  // Trait / Hindrance / Proficiency
  const TP = c.traitPicks || {}; const withPick = (text, key)=> TP[key] ? `${text} — เลือกไว้: ${TP[key]}` : text;
  const traits = [...kin.traits.map(t=>({name:`${t.name} (${t.nameEn})`, text:withPick(t.text,'kin:'+t.nameEn), src:'วงศา'})), ...[ch,ad].filter(Boolean).filter(b=>b.text).map(b=>({name:b.name, text:withPick(b.text,'bg:'+b.code), src: b===ch?'วัยเด็ก':'วัยผู้ใหญ่'})), ...kin.benefits.map(b=>({name:`${b.name} (${b.nameEn})`, text:withPick(b.text,'kin:'+b.nameEn), src:'Benefit'}))];
  if (c.evolver && c.evolver.kin){ const ek=KIN[c.evolver.kin]; const pick=c.evolver.pick||''; if (pick.startsWith('T:')){ const tr=ek.traits.find(t=>t.nameEn===pick.slice(2)); if (tr) traits.push({name:`${tr.name} (${tr.nameEn})`, text:tr.text, src:'ยืมจาก '+ek.name}); } }
  const hinds = kin.hindrances.map(x=>({name:`${x.name} (${x.nameEn})`, text:withPick(x.text,'kin:'+x.nameEn)}));
  if (c.evolver && c.evolver.kin && c.evolver.hindrance){ const ek=KIN[c.evolver.kin]; const hd=ek.hindrances.find(x=>x.nameEn===c.evolver.hindrance); if (hd) hinds.push({name:`${hd.name} (${hd.nameEn})`, text:hd.text}); }
  const profs = [];
  for (const k of DATA.knowledge){ for (const sl of Object.values(c.kslots||{})){ if (sl && sl.id===k.id && sl.prof && !sl.prof.startsWith('(')){ const pt = profTexts(k.id, sl); profs.push({name:`${profLabel(sl)} (${k.nameTh||k.nameEn})`, text: pt.text + (pt.faithText ? ` · ${faithShort(sl.faith)}: ${pt.faithText}` : '')}); } } }
  if (c.adaptation) profs.push({name:'Adaptation: '+c.adaptation, text:'ได้ Advantage ในการทอยป้องกันผลจากสภาพแวดล้อมแบบนี้'});
  const ff = hasFleshforge(c); if (ff && c.fleshforge && c.fleshforge.item) traits.push({name:'🧬 ศาสตราชีวะ (Fleshforge)', text:`ไอเทมมีชีวิต: ${c.fleshforge.item} (ผูกถาวรตลอดเกม)${c.fleshforge.effect ? ' · เอฟเฟกต์ของไอเทม: ' + c.fleshforge.effect : ''} · เมื่อแปรร่างมี HP และ Toughness เท่ากับคุณ`, src:'Kins Unique', warn: fleshforgeIssue(c) ? `ไอเทมที่ผูกไว้ไม่ผ่านเกณฑ์ที่เคาะ 11 พ.ย. 2026 (${fleshforgeIssue(c)}) ให้ GM ตัดสินว่าจะคงไว้หรือเปลี่ยน` : ''});
  // Trait และ Proficiency Trait ที่ได้มาทีหลัง (ผู้ใช้เคาะ 10 พ.ย. 2026): กด "+ เพิ่ม" เขียนชื่อกับรายละเอียดเอง แก้และลบได้ เก็บใน c.customTraits / c.customProfs
  for (const x of c.customTraits||[]) traits.push({name:x.name, text:x.text||'', src:'เพิ่มเอง', custom:x});
  for (const x of c.customProfs||[]) profs.push({name:x.name, text:x.text||'', src:'เพิ่มเอง', custom:x});
  const editCustom = (key, title, item)=>{
    const isNew = !item; const nameI = h('input',{placeholder:'ชื่อ',style:'width:100%'}); nameI.value = item ? item.name||'' : '';
    const textI = h('textarea',{placeholder:'เอฟเฟกต์หรือรายละเอียด',style:'min-height:120px;width:100%'}); textI.value = item ? item.text||'' : '';
    const okb = h('button',{class:'primary',onclick:()=>{ const nm = nameI.value.trim(); if (!nm){ toast('ใส่ชื่อก่อน'); nameI.focus(); return; } if (isNew){ c[key] = c[key]||[]; c[key].push({id:uid(), name:nm, text:textI.value.trim(), at:Date.now()}); } else { item.name = nm; item.text = textI.value.trim(); } save(); modal(null); rerender(); },text: isNew ? 'เพิ่ม' : 'บันทึก'});
    const del = isNew ? null : h('button',{class:'ghost danger',onclick:()=>{ if (!confirm(`ลบ "${item.name}" ออกจาก ${title}?`)) return; c[key] = (c[key]||[]).filter(x=>x!==item); save(); modal(null); rerender(); },text:'ลบรายการนี้'});
    modal(h('div',{class:'customtrait'}, h('h3',{text:(isNew ? 'เพิ่ม ' : 'แก้ไข ') + title}), h('p',{class:'desc',style:'margin:4px 0 10px',text:'ใช้จดสิ่งที่ตัวละครได้มาระหว่างเล่น เช่น ของที่ GM มอบให้จากเหตุการณ์ในเรื่อง รายการที่เพิ่มเองจะมีป้าย "เพิ่มเอง" กำกับ'}), h('label',{text:'ชื่อ'}), nameI, h('label',{style:'margin-top:8px;display:block',text:'รายละเอียด'}), textI, h('div',{class:'row',style:'margin-top:10px;gap:8px'}, okb, del)));
    setTimeout(()=>nameI.focus(), 30);
  };
  const col = (title, items, cls, key, addKey) => h('div',{class:'box traitbox',dataset:{k:key}}, h('div',{class:'row boxhead'}, h('h4',null, T(title)), addKey && !readOnly ? h('button',{class:'small ghost addbtn',title:`เพิ่ม ${title} ที่ได้มาทีหลัง`,onclick:()=>editCustom(addKey, title, null),text:'+ เพิ่ม'}) : null),
    items.length ? items.map(it=>h('div',{class:'titem'+(it.custom?' custom':'')}, h('div',null, tag(it.name, cls + hueCls(it.name, it.text)), it.src? h('span',{class:'muted',style:'font-size:11px',text:' '+it.src}):null, it.warn ? h('span',{class:'tag neg ffissue',style:'margin-left:6px',title:it.warn,text:'⚠ '+it.warn}) : null, it.custom && !readOnly ? h('button',{class:'small ghost editbtn',title:'แก้ไขหรือลบรายการนี้',onclick:()=>editCustom(addKey, title, it.custom),text:'✎ แก้'}) : null), h('div',{class:'desc'}, T(it.text)))) : h('div',{class:'muted',text:'-'}));
  mid.append(h('div',{class:'grid three'}, col('Trait', traits, 'ok', 'trait', 'customTraits'), col('Hindrance', hinds, 'neg', 'hind'), col('Proficiency Trait', profs, 'prop', 'prof', 'customProfs')));
  if (ff && !readOnly && !(c.fleshforge && c.fleshforge.item)){ const fb = fleshforgePicker(c, {locked:false, confirmBind:true, onChange:()=>{ save(); rerender(); }}); fb.classList.add('box'); fb.dataset.k = 'ff'; mid.append(fb); } // ได้ Fleshforge มาทีหลัง (เช่นซื้อด้วย IP) ต้องเลือกไอเทมผูกครั้งเดียว
  // กล่องแฝด (Twinborn): ชื่อร่าง B สถานะเดินแยกกัน และใครคุมร่างไหน
  if (twin){ const st = twinbornState(c); const other = st.control==='A' ? 'B' : 'A';
    const tbx = h('div',{class:'box twinbox',dataset:{k:'twinborn'}}, h('h4',{text:'แฝด (Twinborn)'}));
    tbx.append(h('p',{class:'desc',style:'font-size:12.5px;margin:0 0 8px',text:'สองร่าง วิญญาณดวงเดียว: HP, Toughness, เกราะ และกระเป๋าแยกกัน (สลับร่างได้ที่แท็บในกล่อง Toughness และในหน้าต่างกระเป๋า) ส่วน MP, Sanity และ Action ของเทิร์นใช้ร่วมกัน'}),
      h('ul',{class:'twinrules'}, ['ทั้งสองร่าง Defend ได้ตามปกติ ส่วน Attack of Opportunity ทำได้รวมกัน 1 ครั้งต่อรอบ', 'ร่างที่ HP เหลือ 0 เข้าสู่ใกล้ตายตามปกติ อีกร่างยังกระทำได้ ถ้าร่างหนึ่งตาย อีกร่างเข้าสู่ใกล้ตายทันที', 'สภาวะทางจิตใจ (เช่น Frightened, Charmed) ติดทั้งสองร่างพร้อมกัน', 'พักแต่ละครั้งสองร่างกินเสบียงสองอัตรา และแต่ละร่างแบกของได้ตาม Capacity ของตัวเอง', 'เมื่อแยกกันอยู่คนละฉาก แต่ละร่างได้ Action ครบชุดในฉากของตัวเอง'].map(t=>h('li',{text:t}))));
    const nameB = h('input',{placeholder:`${c.name||'ตัวละคร'} (ร่าง B)`,title:'ชื่อที่ใช้กับหมากและกระเป๋าของร่าง B'}); nameB.value = (c.twinborn||{}).nameB||''; nameB.oninput = ()=>{ c.twinborn = Object.assign({}, c.twinborn||{}, {nameB: nameB.value}); }; nameB.onblur = ()=>{ save(); if (typeof renameTwinTokens==='function') renameTwinTokens(c); };
    tbx.append(h('div',{class:'idgrid'}, h('span',{class:'k',text:'ร่าง A'}), h('span',{text:c.name||'-'}), h('span',{class:'k',text:'ร่าง B'}), nameB));
    const sel = h('select',{class:'twinsel',style:'width:100%;margin-top:8px',onchange:(e)=>{ const v = e.target.value; setTwinbornState(c, v!=='together', v==='apartB' ? 'B' : 'A'); rerender(); }},
      h('option',{value:'together',text:'อยู่ด้วยกัน: ผู้เล่นบังคับทั้งสองร่าง'}), h('option',{value:'apartA',text:'เดินแยกกัน: ผู้เล่นบังคับร่าง A · GM คุมร่าง B หลังฉาก'}), h('option',{value:'apartB',text:'เดินแยกกัน: ผู้เล่นบังคับร่าง B · GM คุมร่าง A หลังฉาก'}));
    sel.value = !st.apart ? 'together' : (st.control==='B' ? 'apartB' : 'apartA');
    tbx.append(sel);
    if (st.apart){ const log = h('textarea',{placeholder:`จดสิ่งที่ GM เล่าถึง${bodyName(c, other)}`,style:'min-height:60px;margin-top:6px'}); log.value = (c.twinborn||{}).log||''; log.oninput = ()=>{ c.twinborn = Object.assign({}, c.twinborn||{}, {log: log.value}); }; log.onblur = save;
      tbx.append(...[h('p',{class:'dim',style:'font-size:12px;margin:8px 0 0',text:`${bodyName(c, other)} อยู่ในมือ GM หลังฉาก ถามถึงเหตุการณ์ของอีกร่างได้ตลอดเวลา และยังเป็นคนเลือกเองเมื่ออีกร่างเจอเหตุการณ์ที่ต้องเลือก`}), log,
        Table.roomId && !readOnly ? h('div',{class:'row',style:'margin-top:6px'}, h('button',{class:'small',onclick:()=>askAboutTwin(c),text:'💬 ถาม GM ถึงอีกร่าง'})) : null].filter(Boolean)); }
    mid.append(tbx); }
  // ===== สกิล / ของสวมใส่ / กระเป๋า อยู่ใน HUD ลอยข้างจอ (hud.js) =====
  const grow = (ta)=>{ ta.rows = 1; const fit=()=>{ ta.style.height='auto'; ta.style.height = (ta.scrollHeight+2)+'px'; }; ta.addEventListener('input', fit); requestAnimationFrame(fit); return ta; };
  const nt = h('div',{class:'box notes',dataset:{k:'notes'}}, h('div',{class:'grid two'}, h('div',null, h('h4',{text:'Quest'}), txt(c.extraText,'quest','',true)), h('div',null, h('h4',{text:'Note'}), txt(c.extraText,'note','',true)), h('div',null, h('h4',{text:'Reputation (Faction)'}), txt(c.extraText,'reputation','',true)), h('div',null, h('h4',{text:'Relationship (Character)'}), txt(c.extraText,'relationship','',true))));
  mid.append(nt);
  // ===== right =====
  const right = h('div',{class:'cs-right'});
  const st = h('div',{class:'box',dataset:{k:'status'}}, h('h4',{text:'STATUS'}));
  const stt = h('table',{class:'stt'}, h('thead',null, h('tr',null, h('th'), h('th',{text:'BASE'}), h('th',{text:'CHILD'}), h('th',{text:'ADULT'}), h('th',{text:'EXTRA'}), h('th',{text:'RAW'}), h('th',{text:'MOD'}))));
  for (const s of STATS){ const chv = ch && ch.stats[s] || 0, adv = ad && ad.stats[s] || 0, exv = (c.extra||{})[s]||0, chc = (c.choiceStats||[]).filter(x=>x===s).length; stt.append(h('tr',{class:'sc-'+s}, h('td',{class:'n'}, T(s)), h('td',{text:kin.raw[s]}), h('td',{text:String(chv+chc)}), h('td',{text:String(adv)}), h('td',{text:String(exv)}), h('td',{text:String(d.raw[s])}), h('td',{class:'ov',text:signed(d.mod[s])}))); }
  st.append(h('div',{class:'tablewrap'}, stt)); right.append(st);
  const pb = h('div',{class:'box',dataset:{k:'pers'}}, h('h4',{text:'Personality Stats'}));
  const pg2 = h('div',{class:'ptable'});
  for (const ax of DATA.meta.personality){ const p=c.personality[ax.id]; const l = (!p||p.value==null)?0:(p.side==='left'?p.value:-p.value); pg2.append(h('span',{class:'lw'}, ax.left, h('span',{class:'dim',text:` (${ax.leftTh})`})), h('span',{class:'v',style:'color:#f08c2e',text:signed(l)}), h('span',{class:'dim',text:'/'}), h('span',{class:'v',style:'color:#58b7ff',text:signed(-l)}), h('span',{class:'rc'}, ax.right, h('span',{class:'dim',text:` (${ax.rightTh})`}))); }
  pb.append(pg2); right.append(pb);
  const cm = h('div',{class:'box',dataset:{k:'combat'}}, h('h4',null, 'Combat Mod.'));
  cm.append(h('div',{class:'gives'}, h('span',{class:'tag sc sc-AGI stat'}, T('Reflex'), ` ${signed(d.reflex)}`), h('span',{class:'tag sc sc-STR stat'}, T('Might'), ` ${signed(d.might)}`), h('span',{class:'tag sc sc-PER stat'}, T('Sight'), ` ${signed(d.sight)}`), h('span',{class:'tag sc sc-PER stat'}, T('Initiative'), ` ${signed(d.initiative)}`), h('span',{class:'tag sc sc-VIT stat'}, 'VIT ST', ` ${signed(d.fortitude)}`), h('span',{class:'tag sc sc-PER stat'}, 'PER ST', ` ${signed(d.will)}`), h('span',{class:'tag',title:'เต๋าเพิ่มตอน Parry (โล่ +1) แก้ตัวเลขได้'}, T('Parry Dice'), ' ', h('input',{type:'number',min:0,max:4,value:d.parryDice,style:'width:44px;padding:0 4px;font-size:12px',onchange:(e)=>{ cur.parryBonus=Math.max(0,+e.target.value||0); save(); rerender(); }})), h('span',{class:'tag'}, T('Passive PER'), ` ${d.passivePer}`), h('span',{class:'tag'}, T('Capacity'), ` ${d.capacity} กก.`)));
  cm.append(h('div',{class:'kicker',style:'margin-top:8px',text:'สายคาดอาวุธ'}), weaponBoard(c, d, (k)=>{ HUD.open='pouch'; HUD.sel.pouch=k; HUD.persist && HUD.persist(); rerender(); }, null));
  right.append(cm);
  const kl = knowledgeLevels(c);
  const kb = h('div',{class:'box',dataset:{k:'know'}}, h('h4',null, T('Knowledge'), ' ', h('span',{class:'dim',style:'font-size:11px;font-weight:400;font-family:var(--font-body)',text:'2d6 + ระดับความรู้ + บุคลิกภาพที่เกี่ยว'})));
  const kt = h('table',{class:'t'});
  for (const k of DATA.knowledge){ const kb2 = knowledgeBonus(c, d, k); kt.append(h('tr',null, h('td',null, h('b',{text:k.nameTh||k.nameEn}), h('span',{class:'dim',style:'font-size:11px',text:` ${k.nameTh? k.nameEn+' ' : ''}(${k.stats.join('/')})`})), h('td',{class:'num',text:'Lv'+kb2.lv}), h('td',{class:'num',title:`ระดับความรู้ ${kb2.lv} (ไม่รวม Mod ค่าพลัง)`,text:signed(kb2.total)}))); }
  kb.append(h('div',{class:'tablewrap'}, kt)); right.append(kb);
  // แผงทอยเต๋าอยู่ใน HUD (ปุ่มลอยข้างจอ) ไม่กินพื้นที่ชีท และเปิดค้างไว้ได้ขณะเลื่อนดูชีท
  const diceOpts = {onRoll: (e)=>{ if (Table.roomId) Table.postRoll(e, c); }, guard: Table.roomId ? (run,label)=>Table.guardedRoll(c.name, run, label) : null, pendingPick: Table.roomId ? (o)=>Table.postPick(o) : null, lastAttack: Table.roomId ? ()=>Table.lastAttack() : null};
  const cs = h('div',{class:'cs'});
  // จัดกรอบลงคอลัมน์เท่ากัน 3 ช่อง (2 บนจอกลาง, 1 บนมือถือ) แบบเรียงให้คอลัมน์สูงใกล้เคียงกัน ไม่ทิ้งช่องว่าง
  const all = [...left.children, ...mid.children, ...right.children].flatMap(el => el.classList.contains('grid') ? [...el.children] : [el]);
  const ORDER = ['id','portrait','status','res','twinborn','tough','ff','trait','prof','pers','combat','hind','traits','know','notes'];
  const rank = (el)=>{ const i = ORDER.indexOf(el.dataset.k); return i < 0 ? ORDER.length : i; };
  const order = all.slice().sort((a,b)=>rank(a) - rank(b));
  // ปุ่มจัดวางกรอบเอง (ย้าย/ย่อขยายทุกกรอบ บันทึกต่อเบราว์เซอร์)
  const lay = loadLayout();
  idb.querySelector('.row .row').append(...[h('button',{class:'small ghost',title:'ลากย้ายและปรับขนาดทุกกรอบได้ตามถนัด',onclick:()=>{ if (lay.free){ lay.free=false; saveLayout(lay); } else { lay.free=true; saveLayout(lay); } rerender(); },text: lay.free ? 'กลับเป็นแบบตาราง' : 'จัดวางกรอบเอง'}), lay.free ? h('button',{class:'small ghost',onclick:()=>{ if (!confirm('ล้างการจัดวางที่บันทึกไว้?')) return; saveLayout({free:true, boxes:{}}); rerender(); },text:'รีเซ็ตตำแหน่ง'}) : null].filter(Boolean));
  root.append(cs);
  // v1.18 (ผู้ใช้สั่ง 12 พ.ย. 2026): ช่องว่างท้ายคอลัมน์ที่ทำให้หน้ากระดาษไม่สมมาตรกลายเป็นพื้นที่จด (Memo) · ข้อความเก็บแยกตามคอลัมน์ใน extraText.pad0 ถึง pad2
  const pads = { text: (j)=>String(c.extraText['pad'+j]||''),
    make: (j)=>{ const ta = h('textarea',{class:'memo-ta',placeholder: readOnly ? '' : 'จดได้ตามใจ เช่น ชื่อคน เบาะแส นัดหมาย',dataset:{pad:j}}); ta.value = c.extraText['pad'+j]||''; ta.oninput = ()=>{ c.extraText['pad'+j] = ta.value; }; ta.onblur = save; return h('div',{class:'box memo',dataset:{k:'memo'+j}}, h('h4',{text:'Memo พื้นที่จด'}), ta); } };
  packColumns(cs, order, pads);
  if (lay.free && vw() > 760) applyFreeLayout(cs, lay);
  renderHUD(c, d, {save, rerender, txt, grow, dice: diceOpts});
  if (readOnly) lockForm(root);
}
function lockForm(root){ for (const el of root.querySelectorAll('input,textarea,select')) el.disabled = true; for (const b of root.querySelectorAll('button')) { if (!b.classList.contains('rollbtn') && !/กลับ|JSON|ปิด|ซ่อน|คัมภีร์|กระเป๋า|ถุงย่าม|Advantage|Disadvantage|ปกติ/.test(b.textContent) && !b.closest('.hud-head,.hud-dock,.modeBtns')) b.disabled = true; } }

/* ===== จัดวางกรอบเอง: ทุกกรอบลากย้ายและย่อขยายได้ (บันทึกใน localStorage ของเบราว์เซอร์) ===== */
function loadLayout(){ try{ return Object.assign({free:false, boxes:{}}, JSON.parse(localStorage.getItem('kirana.sheetLayout')||'{}')); }catch(e){ return {free:false, boxes:{}}; } }
function saveLayout(l){ try{ localStorage.setItem('kirana.sheetLayout', JSON.stringify(l)); }catch(e){} }
function applyFreeLayout(cs, lay){
  const boxes = [...cs.querySelectorAll('.box[data-k]')];
  // ตำแหน่งตั้งต้น = ตำแหน่งในตารางปัจจุบัน (วัดก่อนปลดออกจากกริด)
  const base = cs.getBoundingClientRect(); const z0 = uiZoom(); // พิกัดจอ → พิกัดหลัง zoom
  const rects = boxes.map(b=>{ const r = b.getBoundingClientRect(); return {x:(r.left-base.left)/z0, y:(r.top-base.top)/z0, w:r.width/z0, h:r.height/z0}; });
  // v1.18: แผ่นจด (memo0 ถึง memo2) ที่ยังไม่มีตำแหน่งบันทึก ถ้าผู้ใช้จัดกรอบอื่นไว้แล้ว ตำแหน่งจากตารางอาจทับกรอบเหล่านั้น จึงเรียงต่อท้ายผังแทน
  if (Object.keys(lay.boxes||{}).length){ let yb = 0; boxes.forEach((b,i)=>{ if (/^memo\d$/.test(b.dataset.k)) return; const r = lay.boxes[b.dataset.k] || rects[i]; yb = Math.max(yb, r.y + r.h); });
    boxes.forEach((b,i)=>{ if (!/^memo\d$/.test(b.dataset.k) || lay.boxes[b.dataset.k]) return; const hh = Math.max(160, Math.min(320, rects[i].h)); rects[i] = {x: rects[i].x, y: yb + 14, w: rects[i].w, h: hh}; yb += hh + 14; }); }
  cs.classList.add('free');
  let maxBottom = 0;
  boxes.forEach((b,i)=>{
    const k = b.dataset.k; const saved = lay.boxes[k] || rects[i];
    const x = Math.max(0, saved.x), y = Math.max(0, saved.y), w = Math.max(160, saved.w), hgt = Math.max(60, saved.h);
    b.style.left = x+'px'; b.style.top = y+'px'; b.style.width = w+'px'; b.style.height = hgt+'px'; if (saved.z) b.style.zIndex = saved.z;
    maxBottom = Math.max(maxBottom, y+hgt);
    const grip = h('div',{class:'box-grip',title:'ลากเพื่อย้าย · ดึงมุมขวาล่างเพื่อปรับขนาด'}, h('span',{class:'dots',text:'⋮⋮'}), h('span',{class:'dim',text:'ย้าย'}));
    b.prepend(grip);
    let sx=0, sy=0, ox=0, oy=0, id=null, z=1;
    grip.addEventListener('pointerdown', (e)=>{ if (e.button!==0) return; lay.zTop = (lay.zTop||1)+1; b.style.zIndex = lay.zTop; id=e.pointerId; grip.setPointerCapture(id); z = uiZoom(); sx=e.clientX; sy=e.clientY; ox=parseFloat(b.style.left); oy=parseFloat(b.style.top); b.classList.add('dragging'); e.preventDefault(); });
    grip.addEventListener('pointermove', (e)=>{ if (id==null || e.pointerId!==id) return; const nx = Math.max(0, Math.min(cs.clientWidth - b.offsetWidth, ox + (e.clientX - sx)/z)), ny = Math.max(0, oy + (e.clientY - sy)/z); b.style.left = nx+'px'; b.style.top = ny+'px'; });
    const up = ()=>{ if (id==null) return; try{ grip.releasePointerCapture(id); }catch(x){} id=null; b.classList.remove('dragging'); store(); fitHeight(); };
    grip.addEventListener('pointerup', up); grip.addEventListener('pointercancel', up);
    const store = ()=>{ lay.boxes[k] = {x:parseFloat(b.style.left), y:parseFloat(b.style.top), w:b.offsetWidth, h:b.offsetHeight, z: +b.style.zIndex||0}; saveLayout(lay); };
    let first = true; const ro = new ResizeObserver(()=>{ if (first){ first=false; return; } store(); fitHeight(); }); ro.observe(b);
  });
  const fitHeight = ()=>{ let mb = 0; for (const b of boxes) mb = Math.max(mb, parseFloat(b.style.top) + b.offsetHeight); cs.style.height = (mb + 24) + 'px'; };
  cs.style.height = (maxBottom + 24) + 'px';
}

/* ผังชีท 3 คอลัมน์ (ผู้ใช้เคาะ 10 พ.ย. 2026): Personal Traits อยู่คอลัมน์ขวา · Trait กับ Proficiency Trait ได้คอลัมน์กลางใต้รูป มีที่ให้รายการที่เพิ่มทีหลัง
   กรอบที่ไม่อยู่ในรายการ (Hindrance, Knowledge, Quest/Note) ลงคอลัมน์ที่เตี้ยที่สุดตามลำดับ */
const SHEET_COLS = [['id','pers','combat'], ['portrait','ff','trait','prof'], ['status','res','twinborn','tough','traits']];
/* จัดกรอบลงคอลัมน์: วัดความสูงจริงแล้ววางทีละกรอบลงคอลัมน์ที่เตี้ยที่สุด (ลำดับคงเดิม) */
/* ช่องข้อความที่ยืดตามเนื้อหา (คลาส ag): วัดก่อนจัดคอลัมน์ ความสูงของกรอบที่ใช้จัดผังจึงรวมส่วนที่ยืดแล้ว */
function fitArea(ta){ if (!ta || !ta.isConnected) return; ta.style.height = 'auto'; ta.style.height = (ta.scrollHeight + 2) + 'px'; }
/* ความกว้างของช่องเปลี่ยน (ย่อขยายหน้าต่าง หรือลากขนาดกรอบในโหมดจัดวางเอง) ข้อความตัดบรรทัดใหม่ จึงวัดความสูงใหม่ ไม่อย่างนั้นบรรทัดท้ายจะถูกซ่อน */
const AREA_RO = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(entries=>{ for (const e of entries){ const ta = e.target; const w = Math.round(e.contentRect.width); if (ta.__w !== w){ ta.__w = w; requestAnimationFrame(()=>fitArea(ta)); } } }) : null;
/* พื้นที่จด (Memo): คอลัมน์ที่เตี้ยกว่าคอลัมน์สูงสุดตั้งแต่ MEMO_MIN_GAP ขึ้นไปได้แผ่นจดต่อท้าย แผ่นยืดเต็มช่องว่างด้วย CSS (flex) ทุกคอลัมน์จึงจบที่เส้นเดียวกัน
   แผ่นที่มีข้อความอยู่แล้วแสดงเสมอ แม้คอลัมน์ของมันไม่เหลือช่องว่างหรือจอแคบจนคอลัมน์นั้นหายไป (ย้ายไปต่อท้ายคอลัมน์ที่เตี้ยที่สุด) ข้อความจึงไม่หาย */
const MEMO_MIN_GAP = 120, MEMO_MIN_H = 132;
function addMemoPads(cols, tot, pads){
  if (!pads) return; const n = cols.length; const colHas = Array(n).fill(false);
  const shortest = ()=>{ let s = 0; for (let k=1;k<n;k++) if (tot[k] < tot[s]) s = k; return s; };
  for (let j=0;j<3;j++){ if (!pads.text(j).trim()) continue; const col = (n > 1 && j < n) ? j : shortest(); cols[col].append(pads.make(j)); tot[col] += MEMO_MIN_H + 14; colHas[col] = true; }
  if (n < 2) return;
  const max = Math.max(...tot);
  for (let j=0;j<n;j++){ if (colHas[j]) continue; if (max - tot[j] >= MEMO_MIN_GAP){ cols[j].append(pads.make(j)); colHas[j] = true; } }
}
function packColumns(cs, boxes, pads){
  const n = vw() <= 760 ? 1 : (vw() <= 1100 ? 2 : 3);
  const cols = Array.from({length:n}, ()=>h('div',{class:'cscol'}));
  cs.append(...cols);
  // วัดในคอลัมน์แรกก่อน (ทุกคอลัมน์กว้างเท่ากัน)
  for (const b of boxes) cols[0].append(b);
  for (const ta of cols[0].querySelectorAll('textarea.ag')) fitArea(ta);
  const heights = boxes.map(b => b.offsetHeight + 14);
  const tot = Array(n).fill(0);
  const hOf = new Map(boxes.map((b,i)=>[b, heights[i]]));
  if (n === 3){ // จอกว้าง: ตำแหน่งหลักตายตัว ที่เหลือเติมคอลัมน์ที่เตี้ยที่สุด
    const used = new Set(); const put = (b, j)=>{ cols[j].append(b); tot[j] += hOf.get(b)||0; used.add(b); };
    SHEET_COLS.forEach((keys, j)=>{ for (const k of keys){ const b = boxes.find(x=>x.dataset.k===k); if (b) put(b, j); } });
    for (const b of boxes){ if (used.has(b)) continue; let j = 0; for (let k=1;k<n;k++) if (tot[k] < tot[j]) j = k; put(b, j); }
    addMemoPads(cols, tot, pads);
    return;
  }
  boxes.forEach((b,i)=>{ let j = 0; for (let k=1;k<n;k++) if (tot[k] < tot[j]) j = k; cols[j].append(b); tot[j] += heights[i]; });
  // ปรับสมดุล: ย้ายกรอบจากคอลัมน์ที่สูงสุดไปต่อท้ายคอลัมน์ที่เตี้ยสุด เลือกกรอบที่ทำให้ส่วนต่างเหลือน้อยที่สุด (ไม่ย้ายกรอบแรกของคอลัมน์)
  for (let it=0; it<8; it++){
    let T=0, S=0; for (let k=1;k<n;k++){ if (tot[k] > tot[T]) T=k; if (tot[k] < tot[S]) S=k; }
    if (T===S) break; const diff = tot[T]-tot[S]; let best=null, bestGap=diff;
    for (const b of [...cols[T].children].slice(1)){ const hb = hOf.get(b)||0; const gap = Math.abs(diff - 2*hb); if (hb < diff && gap < bestGap){ bestGap = gap; best = b; } }
    if (!best) break; const hb = hOf.get(best); cols[S].append(best); tot[T] -= hb; tot[S] += hb;
  }
  addMemoPads(cols, tot, pads);
}

/* ตัวเลือกว่าจะแชร์อะไรให้ห้อง */
function shareModeSel(c, save){
  const sel = h('select',{title:'สิ่งที่ GM และเพื่อนร่วมห้องเห็นเมื่อวางตัวละครลงบอร์ด',onchange:(e)=>{ c.shareMode = e.target.value; save(); toast(c.shareMode==='min' ? 'ห้องจะเห็นเฉพาะค่าหลัก (ชื่อ รูป วงศา HP Sanity เกราะ)' : 'ห้องจะเห็นชีทเต็ม (อ่านอย่างเดียว)'); }},
    h('option',{value:'full',text:'แชร์ให้ห้อง: ชีทเต็ม'}), h('option',{value:'min',text:'แชร์ให้ห้อง: เฉพาะค่าหลัก'}));
  sel.value = c.shareMode || 'full';
  return sel;
}
/* ชีทแบบย่อที่คนอื่นในห้องเห็น เมื่อเจ้าของเลือกแชร์เฉพาะค่าหลัก */
function renderMinSheet(c){
  const kin = c.kin ? KIN[c.kin] : null; const cur = c.current || {};
  const box = h('div',{class:'card minsheet'});
  box.append(h('div',{class:'row',style:'gap:14px;align-items:flex-start'},
    c.portrait ? h('img',{src:c.portrait,alt:c.name,style:'width:120px;height:160px;object-fit:cover;border-radius:8px;border:1px solid var(--line-2)'}) : null,
    h('div',null, h('h2',{text:c.name||'(ไม่มีชื่อ)'}), h('div',{class:'dim',text:(kin? kin.name : '') + (c.size? ' · '+c.size : '') + (c.ownerName? ' · ผู้เล่น '+c.ownerName : '')}),
      h('div',{class:'gives',style:'margin-top:8px'}, tag(`HP ${cur.hp??'?'}`,'neg'), cur.hp2!=null ? tag(`HP ร่าง B ${cur.hp2}`,'neg') : null, tag(`MP ${cur.mp??'?'}`,'stat'), tag(`Sanity ${cur.sanity??'?'}`,'prop'), cur.temp? tag(`Temp HP ${cur.temp}`) : null),
      h('div',{class:'dim',style:'font-size:12.5px;margin-top:6px',text:'เจ้าของเลือกแชร์เฉพาะค่าหลัก ค่าพลัง ทักษะ กระเป๋า และเรื่องราวไม่เปิดเผย'}))));
  // v1.15: แฝดมี Toughness และเกราะแยกร่าง ชีทย่อจึงมีสองคู่คอลัมน์เมื่อมีร่าง B
  const two = cur.hp2 != null && !!cur.tough2;
  const tb = h('table',{class:'t',style:'margin-top:10px'}, h('thead',null, h('tr',null, h('th',{text:'อวัยวะ'}), h('th',{text: two ? 'Toughness ร่าง A' : 'Toughness'}), h('th',{text: two ? 'เกราะร่าง A' : 'เกราะ A/B'}), two ? h('th',{text:'Toughness ร่าง B'}) : null, two ? h('th',{text:'เกราะร่าง B'}) : null)));
  for (const [k,label] of DATA.meta.bodyParts) tb.append(h('tr',null, h('td',{text:label}), h('td',{class:'num',text:(cur.tough||{})[k]??'-'}), h('td',{class:'num',text:(c.armor||{})[k]||'-'}), two ? h('td',{class:'num',text:(cur.tough2||{})[k]??'-'}) : null, two ? h('td',{class:'num',text:(c.armor2||{})[k]||'-'}) : null));
  box.append(h('div',{class:'tablewrap'}, tb));
  if ((cur.wounds||[]).length) box.append(h('div',{class:'woundlist'}, cur.wounds.map(w=>h('div',{class:'wound'}, h('b',{text:`${two ? 'ร่าง '+(w.body||'A')+' · ' : ''}${partLabel(w.part)}: ${w.name}`}), h('span',{class:'dim',text:` (ทอยได้ ${w.die})`})))));
  const det = c.details||{}; if (det.appearance) box.append(h('p',{class:'desc',style:'margin-top:8px'}, h('b',{text:'รูปลักษณ์: '}), det.appearance)); if (det.signature) box.append(h('p',{class:'desc'}, h('b',{text:'เอกลักษณ์: '}), det.signature));
  return box;
}
