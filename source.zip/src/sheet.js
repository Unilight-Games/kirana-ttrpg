/* ===== Character list + sheet + dice ===== */
function renderChars(){
  const root = clear($('#v-chars'));
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'ตัวละครของฉัน'}), h('p',{text: Store.online ? 'ตัวละครที่บันทึกบนเว็บจะเห็นร่วมกันทั้งโต๊ะ (GM เปิดชีทผู้เล่นได้)' : 'บันทึกไว้ในเบราว์เซอร์นี้ ส่งออกเป็น JSON เพื่อย้ายเครื่องได้'})),
    h('div',{class:'row'}, h('button',{class:'primary',onclick:()=>{ startWizard(null); location.hash='#create'; },text:'+ สร้างตัวละครใหม่'}), h('button',{onclick:importChar,text:'นำเข้า JSON'}))));
  const mine = Store.chars.filter(c=>!Store.me || !c.ownerId || c.ownerId===Store.me);
  const others = Store.chars.filter(c=>Store.me && c.ownerId && c.ownerId!==Store.me);
  const list=(arr)=>h('div',{class:'grid two'}, arr.map(c=>{ const d=compute(c); const kin=c.kin?KIN[c.kin]:null;
    return h('div',{class:'card'}, h('h3',null, c.name||'(ยังไม่ตั้งชื่อ)', h('span',{class:'en',text: kin? kin.name : 'ร่าง'})),
      h('div',{class:'gives'}, c.done? tag('พร้อมเล่น','ok') : tag(`ร่าง ขั้น ${(c.step||0)+1}/8`,'warn'), c.starterSet? tag(c.starterSet,'prop'):null, c.talent? tag('Talent '+c.talent):null),
      kin? h('div',{class:'statgrid'}, STATS.map(s=>h('div',{class:'statbox'}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:d.raw[s]}), h('div',{class:'m num',text:signed(d.mod[s])})))) : null,
      h('div',{class:'row',style:'margin-top:8px'}, c.done? h('button',{class:'primary small',onclick:()=>{location.hash='#sheet-'+c.id;},text:'เปิดชีท'}):null, h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#create'; },text:c.done?'แก้ไขในวิซาร์ด':'ทำต่อ'}), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}), h('button',{class:'small ghost',onclick:()=>{ if(confirm(`ลบ ${c.name||'ตัวละครนี้'}?`)) Store.remove(c.id); renderChars(); },text:'ลบ'})));
  }));
  if (!mine.length && !others.length) root.append(h('div',{class:'card',text:'ยังไม่มีตัวละคร เริ่มจากปุ่มสร้างตัวละครใหม่'}));
  if (mine.length) root.append(list(mine));
  if (others.length){ root.append(h('h3',{style:'margin:18px 0 8px',text:'ตัวละครของผู้เล่นคนอื่นในโต๊ะ'})); root.append(list(others)); }
}
function exportChar(c){
  const txt = JSON.stringify(c, null, 1);
  const ta = h('textarea',{style:'min-height:300px;font-family:monospace;font-size:12px'}); ta.value = txt;
  modal(h('div',null, h('h3',{text:'ส่งออกตัวละคร (คัดลอกข้อความนี้ไปเก็บ)'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ navigator.clipboard.writeText(txt).then(()=>toast('คัดลอกแล้ว')).catch(()=>toast('คัดลอกไม่ได้ เลือกข้อความแล้วคัดลอกเอง')); },text:'คัดลอก'}))));
}
function importChar(){
  const ta = h('textarea',{style:'min-height:240px;font-family:monospace;font-size:12px',placeholder:'วาง JSON ของตัวละครที่นี่'});
  modal(h('div',null, h('h3',{text:'นำเข้าตัวละคร'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ try{ const c=JSON.parse(ta.value); if(!c || !c.id || !('kin' in c)) throw new Error('bad'); if (Store.get(c.id)) c.id = uid(); c.ownerId = Store.me||null; Store.upsert(c); modal(null); renderChars(); toast('นำเข้าแล้ว'); } catch(e){ toast('อ่าน JSON ไม่ได้'); } },text:'นำเข้า'}))));
}

/* ---- Dice panel (ใช้ร่วมกันทั้งชีทและโต๊ะ) ---- */
const RollLog = { entries: [], add(e){ this.entries.unshift(e); if (this.entries.length>60) this.entries.pop(); } };
function doRoll({label, mod=0, persSide=null, c=null, dc=null, mode='normal', kind='check'}){
  const r = roll2d6(mode);
  let pm = 0; if (persSide && c) pm = persMod(c, persSide);
  const total = r.sum + mod + pm;
  const j = kind==='luck' ? (total>=8 ? {cls:'res-full',text:'โชคเข้าข้าง (8+)'} : {cls:'res-fail',text:'โชคไม่เข้าข้าง'}) : (kind==='attack' ? {cls: r.double?'res-crit':'res-part', text: r.double? `Perfect Strike (คู่ ${r.kept[0]})` : `CV ${r.sum}`} : judge(total, r, dc));
  const e = {ts:Date.now(), label, r, mod, pm, persSide, total, judge:j, mode, dc, kind, who: c? c.name : ''};
  RollLog.add(e);
  return e;
}
function rollEntryEl(e){
  const parts = [`2d6 ${e.r.kept[0]}+${e.r.kept[1]}`]; if (e.mod) parts.push(`Mod ${signed(e.mod)}`); if (e.pm) parts.push(`${e.persSide} ${signed(e.pm)}`);
  return h('div',{class:'e'}, h('div',{class:'row',style:'gap:6px'}, e.who? h('span',{class:'who',text:e.who}):null, h('b',{text:e.label}), e.mode!=='normal'? tag(e.mode==='adv'?'Advantage':'Disadvantage', e.mode==='adv'?'ok':'neg'):null, e.dc!=null? tag('DC '+e.dc):null),
    h('div',{class:'row',style:'gap:8px;margin-top:2px'}, renderDice(e.r), h('span',{class:'dim num',text:parts.join(' ')}), h('b',{class:'num',text:'= '+e.total}), h('span',{class:e.judge.cls,text:e.judge.text})));
}
function dicePanel(c, onRoll, opts={}){ // opts.guard(run) = ด่านล็อกการทอยของโต๊ะ, opts.noLog = ไม่แสดงบันทึกในแผง
  const st = {mode:'normal', pers:'', dc:''};
  const box = h('div',{class:'card dicepanel'});
  const modeBtns = h('div',{class:'row'}, ['normal','adv','dis'].map(m=>h('button',{class:'small'+(st.mode===m?' primary':''), onclick:(e)=>{ st.mode=m; for (const b of modeBtns.children) b.classList.toggle('primary', b.dataset.m===m); }, dataset:{m}, text: m==='normal'?'ปกติ 2d6':m==='adv'?'Advantage 3d6↑':'Disadvantage 3d6↓'})));
  const persSel = h('select',{onchange:(e)=>{st.pers=e.target.value;}}, h('option',{value:'',text:'ไม่บวกบุคลิกภาพ'}), DATA.meta.personality.flatMap(ax=>[ax.left, ax.right]).map(s=>h('option',{value:s, text: c? `${s} (${signed(persMod(c,s))})` : s})));
  const dcInp = h('input',{type:'number',placeholder:'DC (ว่าง = Degrees)',style:'width:150px',oninput:(e)=>{st.dc=e.target.value;}});
  box.append(h('h3',{text:'ทอยเต๋า'}), h('div',{class:'row',style:'margin:8px 0'}, modeBtns), h('div',{class:'row',style:'margin-bottom:8px'}, persSel, dcInp));
  const log = h('div',{class:'log'});
  const refresh = ()=>{ clear(log); if(!RollLog.entries.length) log.append(h('div',{class:'dim',text:'ยังไม่มีการทอย'})); for (const e of RollLog.entries.slice(0,30)) log.append(rollEntryEl(e)); };
  const fire = (label, mod, kind)=>{ const run = ()=>{ const e = doRoll({label, mod, persSide: st.pers||null, c, dc: st.dc===''?null:+st.dc, mode: st.mode, kind}); refresh(); if (onRoll) onRoll(e); return e; }; if (opts.guard) opts.guard(run, label); else run(); };
  if (c){ const d = compute(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, STATS.map(s=>h('button',{class:'small rollbtn',onclick:()=>fire(`${s} Check`, d.mod[s]), text:`${s} ${signed(d.mod[s])}`}))));
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small rollbtn',onclick:()=>fire('Initiative', d.initiative),text:`Initiative ${signed(d.initiative)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('Attack Roll (Combat Dice)', 0, 'attack'),text:'Attack 2d6 (CV)'}), h('button',{class:'small rollbtn',onclick:()=>fire('Parry', d.parryDice, 'attack'),text:'Parry 2d6'}), h('button',{class:'small rollbtn',onclick:()=>fire('Evade (Reflex)', d.reflex),text:`Evade ${signed(d.reflex)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('Fortitude ST', d.fortitude),text:`Fortitude ${signed(d.fortitude)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('Will ST', d.will),text:`Will ${signed(d.will)}`}), h('button',{class:'small rollbtn',onclick:()=>fire('Luck Saving Throw', 0, 'luck'),text:'Luck (8+)'})));
    const kl = knowledgeLevels(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, DATA.knowledge.map(k=>{ const profs = Object.values(c.kslots||{}).filter(s=>s&&s.id===k.id&&s.prof&&!s.prof.startsWith('(')).length; return h('button',{class:'small ghost rollbtn',onclick:()=>fire(`${k.nameEn} Check`, profs),text:`${k.nameEn} +${profs}`}); })));
  } else {
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small rollbtn',onclick:()=>fire('2d6',0),text:'ทอย 2d6'}), h('button',{class:'small rollbtn',onclick:()=>fire('Luck Saving Throw',0,'luck'),text:'Luck (8+)'}), h('button',{class:'small rollbtn',onclick:()=>fire('Attack Roll',0,'attack'),text:'Attack 2d6'})));
  }
  const custom = h('input',{type:'number',placeholder:'Mod',style:'width:80px'});
  box.append(h('div',{class:'row',style:'margin-bottom:8px'}, custom, h('button',{class:'small rollbtn',onclick:()=>fire('ทอยกำหนดเอง', +custom.value||0),text:'ทอย 2d6 + Mod'})));
  if (!opts.noLog){ box.append(log); refresh(); }
  return box;
}

/* ---- Sheet (โครงตามชีท Duck Family: ซ้าย=ภาพ/ทรัพยากร, กลาง=ตัวตน/นิสัย/Trait/สกิล/ของ, ขวา=STATUS/บุคลิก/Combat Mod/ความรู้/เต๋า) ---- */
const EQUIP_SLOTS = [['weapon1','Weapon 1 อาวุธหลัก'],['weapon2','Weapon 2 อาวุธสำรอง'],['shield','Shield โล่'],['head','Head'],['neck','Neck'],['back','Back'],['shirt','Shirt'],['chestIn','Chest (In)'],['chestOut','Chest (Out)'],['hands','Hands & Wrists'],['waist','Waist'],['legs','Legs'],['feet','Feet'],['cape','Cape']];
/* จัดช่องสวมใส่จากชื่อ/คุณสมบัติของไอเทม (ไฟล์ Starter Set ไม่ระบุช่อง) */
function itemSlot(name, effect){
  const n = name||'', e = effect||'';
  const has = (re)=>re.test(n);
  if (has(/โล่|Shield/i)) return 'shield';
  if (has(/หมวก|Helm|หน้ากาก|Mask|Hat\b|Coif|Beanie|Beret|Cap\b|Chaperon|Browband/i)) return 'head';
  if (has(/ถุงมือ|Gloves|ปลอกแขน|Bracers|แหวน|Ring\b/i)) return 'hands';
  if (has(/รองเท้า|Boots|Sandals/i)) return 'feet';
  if (has(/เข็มขัด|Belt/i)) return 'waist';
  if (has(/ผ้าคลุม|เสื้อคลุมมีฮู้ด|Cloak|Cape|Poncho/i)) return 'cape';
  if (has(/กางเกง|กระโปรง|Trousers|Breeches|Skirt/i)) return 'legs';
  if (has(/แกมเบสัน|Gambeson/i) || /ชั้นใน Armor/.test(e)) return 'chestIn';
  if (has(/เกราะ|Armor|โค้ท|Coat|เสื้อกั๊ก|Vest|เอี๊ยม|Apron|Robe|เสื้อคลุม/i)) return 'chestOut';
  if (has(/ทูนิค|Tunic|เชิ้ต|Shirt/i)) return 'shirt';
  if (has(/กระเป๋า|Satchel|Backpack|เป้/i)) return 'back';
  if (has(/สัญลักษณ์ศักดิ์สิทธิ์|Holy Symbol|สร้อย|Amulet|Necklace/i)) return 'neck';
  if (/\d\s*[PM]DMG|Might\s*\(/.test(e)) return 'weapon';
  return null;
}
function autoEquip(c){
  c.equip = {}; const put = (slot, text)=>{ c.equip[slot] = c.equip[slot] ? c.equip[slot] + ' / ' + text : text; };
  let w = 0;
  for (const row of c.inventory||[]){
    row.worn = false;
    if (/^หรือ\s/.test(row.name)) continue; // ทางเลือกของชุด (เช่น ดาบ หรือ หอก) ไม่สวมอัตโนมัติ
    let slot = itemSlot(row.name, row.effect); if (!slot) continue;
    const label = row.name + (row.effect ? ' · ' + row.effect : '');
    if (slot==='weapon'){ const n = Math.max(1, Math.min(2, row.qty||1)); for (let i=0;i<n && w<2;i++){ w++; put('weapon'+w, label); row.worn = true; } continue; }
    if (slot==='chestIn' && c.equip.chestIn) slot = 'chestOut';
    put(slot, label); row.worn = true;
  }
  // เครื่องแต่งกายของชุด (outfit) ไม่ใช่ไอเทมในกระเป๋า สวมเป็นข้อความ
  const set = c.starterSet ? DATA.sets.sets.find(x=>x.nameEn===c.starterSet) : null;
  if (set && set.outfit){ for (const piece of set.outfit.split(/,\s*|\s+กับ\s+/)){ const nm = piece.trim(); if (!nm) continue; const slot = itemSlot(nm, '') || 'shirt'; put(slot==='weapon'?'shirt':slot, nm); } }
  c.equipAuto = true;
}
function ensureSheetState(c, d){
  c.current = Object.assign({hp:d.hp, mp:d.mp, sanity:d.sanity, temp:0, ap:3, ip:0, money:15, tough:{}}, c.current||{});
  for (const [k] of DATA.meta.bodyParts) if (c.current.tough[k]==null) c.current.tough[k] = d.toughness;
  c.armor = c.armor || {}; c.equip = c.equip || {}; c.details = c.details || {};
  c.extraText = Object.assign({languages: c.kin ? (KIN[c.kin].languages||'') : '', quest:'', note:'', reputation:'', relationship:''}, c.extraText||{});
  if (!c.inventory){
    c.inventory = [];
    const set = c.starterSet ? DATA.sets.sets.find(x=>x.nameEn===c.starterSet) : null;
    const items = [...(set? set.items : []), ...DATA.sets.common.items];
    for (const it of items){ const m = it.name.match(/×\s*(\d+)/); c.inventory.push({name: it.name.replace(/\(เสนอ\)\s*/,'').replace(/\s*×\s*\d+/,'').trim(), effect: it.effect||'', qty: m? +m[1] : 1, weight: parseFloat(it.weight)||0}); }
  }
  // สวมของจากชุดเริ่มต้นให้ทันทีครั้งแรก (ตัวละครเก่าที่ยังไม่เคยสวมและช่องว่างทั้งหมดก็สวมให้)
  if (!c.equipAuto && !Object.values(c.equip).some(v=>v && String(v).trim())) autoEquip(c);
}
function renderSheet(id){
  const root = clear($('#v-sheet'));
  const c = Store.get(id);
  if (!c){ root.append(h('div',{class:'card',text:'ไม่พบตัวละครนี้'})); return; }
  const d = compute(c); const kin = KIN[c.kin];
  ensureSheetState(c, d);
  const cur = c.current; const det = c.details;
  const save = ()=>{ Store.upsert(c); };
  const rerender = ()=>renderSheet(id);
  const txt = (obj, key, ph, multi) => { const el = multi ? h('textarea',{placeholder:ph||''}) : h('input',{placeholder:ph||''}); el.value = obj[key]||''; el.oninput = ()=>{ obj[key] = el.value; }; el.onblur = save; return el; };
  // ===== left =====
  const left = h('div');
  const portrait = h('div',{class:'portrait', title:'คลิกเพื่อใส่ภาพตัวละคร'});
  if (c.portrait) portrait.append(h('img',{src:c.portrait, alt:c.name})); else portrait.append(h('div',null, '[แทรกภาพตัวละคร]', h('div',{class:'muted',style:'font-size:11px',text:'คลิกเพื่อเลือกไฟล์'})));
  const fileInp = h('input',{type:'file',accept:'image/*',class:'sr',onchange:(e)=>{ const f=e.target.files[0]; if(!f) return; const img=new Image(); img.onload=()=>{ const cv=document.createElement('canvas'); const sc=Math.min(1, 360/Math.max(img.width,img.height)); cv.width=Math.round(img.width*sc); cv.height=Math.round(img.height*sc); cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height); c.portrait=cv.toDataURL('image/jpeg',0.82); save(); rerender(); }; img.src=URL.createObjectURL(f); }});
  portrait.onclick = ()=>fileInp.click();
  left.append(h('div',{class:'box'}, portrait, fileInp, h('div',{class:'idgrid',style:'margin-top:8px'}, h('span',{class:'k',text:'ชื่อผู้เล่น'}), txt(det,'player','Player name'))));
  const resBox = h('div',{class:'box'}, h('h4',{text:'ทรัพยากร'}));
  const resbar = (label, key, max, color, term) => { const v = cur[key]||0; return h('div',{class:'resbar'}, h('div',{class:'l'}, h('b',null, T(term||label)), h('span',{class:'num'}, `${v} / ${max}`)), h('div',{class:'bar'}, h('i',{style:`width:${Math.max(0,Math.min(100, max? v/max*100 : 0))}%;background:${color}`})), h('div',{class:'ctl'}, h('button',{class:'small',onclick:()=>{cur[key]=v-1; save(); rerender();},text:'−'}), h('button',{class:'small',onclick:()=>{cur[key]=Math.min(max,v+1); save(); rerender();},text:'+'}), h('input',{type:'number',value:v,onchange:(e)=>{cur[key]=+e.target.value||0; save(); rerender();}}), h('button',{class:'small ghost',onclick:()=>{cur[key]=max; save(); rerender();},text:'เต็ม'}))); };
  resBox.append(resbar('Sanity','sanity',d.sanity,'#a371f7','Sanity'), resbar('Health Points','hp',d.hp,'#e5484d','HP'), resbar('Mana Points','mp',d.mp,'#58b7ff','MP'));
  resBox.append(h('div',{class:'resbar'}, h('div',{class:'l'}, h('b',null, T('Temporary Health')), h('span',{class:'num',text:String(cur.temp||0)})), h('div',{class:'bar'}, h('i',{style:`width:${Math.min(100,(cur.temp||0)*10)}%;background:#e8c547`})), h('div',{class:'ctl'}, h('button',{class:'small',onclick:()=>{cur.temp=Math.max(0,(cur.temp||0)-1); save(); rerender();},text:'−'}), h('button',{class:'small',onclick:()=>{cur.temp=(cur.temp||0)+1; save(); rerender();},text:'+'}), h('button',{class:'small ghost',onclick:()=>{cur.temp=0; save(); rerender();},text:'ล้าง'}))));
  resBox.append(h('div',{class:'idgrid',style:'margin-top:8px'}, h('span',{class:'k'}, T('Insight Point')), h('div',{class:'row',style:'gap:4px'}, h('button',{class:'small',onclick:()=>{cur.ip=Math.max(0,(cur.ip||0)-1); save(); rerender();},text:'−'}), h('b',{class:'num',text:String(cur.ip||0)}), h('button',{class:'small',onclick:()=>{cur.ip=(cur.ip||0)+1; save(); rerender();},text:'+'})), h('span',{class:'k'}, T('เกรฟ')), h('input',{type:'number',value:cur.money||0,onchange:(e)=>{cur.money=+e.target.value||0; save();}})));
  left.append(resBox);
  const tb = h('div',{class:'box'}, h('h4',null, T('Toughness'), ' / ', T('Armor')));
  const bg2 = h('div',{class:'body2'}, h('span',{class:'dim',text:'ส่วน'}), h('span',{class:'dim',text:'Tough'}), h('span',{class:'dim',text:'เกราะ'}));
  for (const [k,label] of DATA.meta.bodyParts){ const v = cur.tough[k]; bg2.append(h('span',{text:label}), h('div',{class:'row',style:'gap:2px'}, h('button',{class:'small',onclick:()=>{cur.tough[k]=v-1; save(); rerender();},text:'−'}), h('b',{class:'num',style:'min-width:38px;text-align:center;'+(v<=0?'color:var(--bad)':''),text:`${v}/${d.toughness}`}), h('button',{class:'small',onclick:()=>{cur.tough[k]=Math.min(d.toughness,v+1); save(); rerender();},text:'+'})), h('input',{value:c.armor[k]||'',placeholder:'0',onchange:(e)=>{c.armor[k]=e.target.value; save();}})); }
  tb.append(bg2, h('p',{class:'dim',style:'font-size:11px;margin:8px 0 0'}, T('Hit Location: '+DATA.meta.hitLocation)));
  left.append(tb);
  // ===== middle =====
  const mid = h('div');
  const idb = h('div',{class:'box'}, h('div',{class:'row',style:'justify-content:space-between'}, h('h2',{text:c.name}), h('div',{class:'row'}, h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#create'; },text:'แก้ไขในวิซาร์ด'}), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}))));
  const ig = h('div',{class:'idgrid',style:'margin-top:8px'});
  const kv = (k, v) => ig.append(h('span',{class:'k'}, T(k)), typeof v === 'string' ? h('span',null, T(v)) : v);
  kv('Age อายุ', txt(det,'age')); kv('Gender เพศ', txt(det,'gender')); kv('Job อาชีพ', txt(det,'job', c.starterSet||'')); kv('Size ขนาด', d.size); kv('Height/Weight', txt(det,'height')); kv('Speed ความเร็ว', kin.speed); kv('Kin วงศา', kin.name);
  const ch = findBg(kin,c.childhood), ad = findBg(kin,c.adulthood);
  kv('Childhood', ch ? `${ch.name} (${ch.nameEn})` : '-'); kv('Adulthood', ad ? `${ad.name} (${ad.nameEn})` : '-'); kv('Languages ภาษา', txt(c.extraText,'languages'));
  idb.append(ig);
  mid.append(idb);
  const pt = h('div',{class:'box'}, h('h4',{text:'Personal Traits นิสัยส่วนตัว'}));
  const pg = h('div',{class:'idgrid'});
  for (const [k,label,multi] of [['likes','Likes ชอบ'],['dislikes','Dislikes ไม่ชอบ'],['fears','Fears หวาดกลัว'],['motivation','Motivation แรงจูงใจ',true],['want','Want',false],['need','Need',false],['manifest','Manifest',false],['appearance','Appearance',true],['backstory','Backstory',true],['signature','Signature Look',true]]) pg.append(h('span',{class:'k'}, T(label)), txt(det,k,'',multi));
  pt.append(pg); mid.append(pt);
  // Trait / Hindrance / Proficiency
  const traits = [...kin.traits.map(t=>({name:`${t.name} (${t.nameEn})`, text:t.text, src:'วงศา'})), ...[ch,ad].filter(Boolean).filter(b=>b.text).map(b=>({name:b.name, text:b.text, src: b===ch?'วัยเด็ก':'วัยผู้ใหญ่'})), ...kin.benefits.map(b=>({name:`${b.name} (${b.nameEn})`, text:b.text, src:'Benefit'}))];
  if (c.evolver && c.evolver.kin){ const ek=KIN[c.evolver.kin]; const pick=c.evolver.pick||''; if (pick.startsWith('T:')){ const tr=ek.traits.find(t=>t.nameEn===pick.slice(2)); if (tr) traits.push({name:`${tr.name} (${tr.nameEn})`, text:tr.text, src:'ยืมจาก '+ek.name}); } }
  const hinds = kin.hindrances.map(x=>({name:`${x.name} (${x.nameEn})`, text:x.text}));
  if (c.evolver && c.evolver.kin && c.evolver.hindrance){ const ek=KIN[c.evolver.kin]; const hd=ek.hindrances.find(x=>x.nameEn===c.evolver.hindrance); if (hd) hinds.push({name:`${hd.name} (${hd.nameEn})`, text:hd.text}); }
  const profs = [];
  for (const k of DATA.knowledge){ for (const sl of Object.values(c.kslots||{})){ if (sl && sl.id===k.id && sl.prof && !sl.prof.startsWith('(')){ let text=''; for (const L of Object.values(k.levels)){ const f=L.proficiencies.find(x=>x.name===sl.prof); if (f) text=f.text; } profs.push({name:`${sl.prof} (${k.nameEn})`, text}); } } }
  if (c.adaptation) profs.push({name:'Adaptation: '+c.adaptation, text:'ได้ Advantage ในการทอยป้องกันผลจากสภาพแวดล้อมแบบนี้'});
  const col = (title, items, cls) => h('div',{class:'box'}, h('h4',null, T(title)), items.length ? items.map(it=>h('div',{style:'margin:6px 0;font-size:13px'}, h('div',null, tag(it.name, cls), it.src? h('span',{class:'muted',style:'font-size:11px',text:' '+it.src}):null), h('div',{class:'desc',style:'font-size:12px'}, T(it.text)))) : h('div',{class:'muted',text:'-'}));
  mid.append(h('div',{class:'grid three'}, col('Trait', traits, 'ok'), col('Hindrance', hinds, 'neg'), col('Proficiency Trait', profs, 'prop')));
  // skills
  const sks = allSkills(c);
  const skb = h('div',{class:'box'}, h('h4',null, T('Skill'), ` (${sks.length})`));
  skb.append(h('div',{class:'grid two'}, sks.map(n=>{ const sk=SKILL_BY_NAME[n]; if(!sk) return h('div',{class:'skcard'}, h('b',{text:n})); return h('div',{class:'skcard'}, h('div',{class:'h'}, h('b',{text:sk.nameEn}), h('span',{class:'typ',text:sk.type||sk.subcategory})), h('div',{class:'dim',style:'font-size:12px',text:`${sk.nameTh||''} · ${sk.subcategory}${sk.tier? ' · '+sk.tier:''}${sk.components? ' · '+sk.components:''}`}), h('div',{style:'margin-top:4px'}, h('b',{text:'Effect: '}), T(sk.effect||'')), sk.condition? h('div',{class:'lim'}, h('b',{text:'Limitation: '}), T(sk.condition)) : null, sk.cost? h('div',{class:'cost'}, h('b',{text:'Cost: '}), T(sk.cost)) : null, sk.extra&&sk.extra.length? h('details',null, h('summary',{text:'เพิ่มเติม'}), sk.extra.map(x=>h('div',{class:'desc',style:'font-size:12px'}, T(x)))) : null); })));
  if (c.talent) skb.append(h('div',{class:'gives',style:'margin-top:8px'}, tag('Talent: '+DATA.talents.find(t=>t.key===c.talent).label,'prop')));
  mid.append(skb);
  // equipment
  const grow = (ta)=>{ ta.rows = 1; const fit=()=>{ ta.style.height='auto'; ta.style.height = (ta.scrollHeight+2)+'px'; }; ta.addEventListener('input', fit); requestAnimationFrame(fit); return ta; };
  const eq = h('div',{class:'box'}, h('div',{class:'row',style:'justify-content:space-between'}, h('h4',{text:'Equipment ของสวมใส่'}), h('button',{class:'small ghost',title:'ล้างช่องสวมใส่แล้วสวมของจากชุดเริ่มต้นและกระเป๋าใหม่',onclick:()=>{ if (!confirm('สวมของจากชุดเริ่มต้นใหม่? ข้อความในช่องสวมใส่ทั้งหมดจะถูกแทนที่')) return; autoEquip(c); save(); rerender(); },text:'สวมของจากชุดเริ่มต้น'})));
  const sg = h('div',{class:'slots'});
  for (const [k,label] of EQUIP_SLOTS) sg.append(h('span',{class:'k',text:label}), grow(txt(c.equip,k,'ชื่อไอเทม · คุณสมบัติ',true)));
  eq.append(sg); mid.append(eq);
  const inv = h('div',{class:'box inv'}, h('h4',{text:'Inventory สัมภาระ'}));
  const list = h('div',{class:'invlist'});
  let total = 0;
  c.inventory.forEach((row,i)=>{ total += (row.qty||0)*(row.weight||0);
    list.append(h('div',{class:'invitem'+(row.worn?' worn':'')},
      h('div',{class:'row',style:'gap:6px;align-items:center'}, txt(row,'name','ชื่อไอเทม'), row.worn? tag('สวมอยู่','ok'):null, h('label',{class:'dim',text:'จำนวน'}), h('input',{type:'number',value:row.qty,style:'width:60px',onchange:(e)=>{row.qty=+e.target.value||0; save(); rerender();}}), h('label',{class:'dim',text:'กก.'}), h('input',{type:'number',step:'0.1',value:row.weight,style:'width:70px',onchange:(e)=>{row.weight=+e.target.value||0; save(); rerender();}}), h('button',{class:'small ghost',title:'ลบ',onclick:()=>{ c.inventory.splice(i,1); save(); rerender(); },text:'✕'})),
      grow(txt(row,'effect','คุณสมบัติ',true)))); });
  inv.append(list, h('div',{class:'row',style:'margin-top:8px;justify-content:space-between'}, h('button',{class:'small',onclick:()=>{ c.inventory.push({name:'',effect:'',qty:1,weight:0}); save(); rerender(); },text:'+ เพิ่มของ'}), h('span',{class:'num '+(total>d.capacity?'res-fail':''),text:`น้ำหนักรวม ${total.toFixed(1)} / แบกได้ ${d.capacity} กก.`})));
  mid.append(inv);
  const nt = h('div',{class:'box notes'}, h('div',{class:'grid two'}, h('div',null, h('h4',{text:'Quest'}), txt(c.extraText,'quest','',true)), h('div',null, h('h4',{text:'Note'}), txt(c.extraText,'note','',true)), h('div',null, h('h4',{text:'Reputation (Faction)'}), txt(c.extraText,'reputation','',true)), h('div',null, h('h4',{text:'Relationship (Character)'}), txt(c.extraText,'relationship','',true))));
  mid.append(nt);
  // ===== right =====
  const right = h('div',{class:'cs-right'});
  const st = h('div',{class:'box'}, h('h4',{text:'STATUS'}));
  const stt = h('table',{class:'stt'}, h('thead',null, h('tr',null, h('th'), h('th',{text:'BASE'}), h('th',{text:'CHILD'}), h('th',{text:'ADULT'}), h('th',{text:'EXTRA'}), h('th',{text:'RAW'}), h('th',{text:'MOD'}))));
  for (const s of STATS){ const chv = ch && ch.stats[s] || 0, adv = ad && ad.stats[s] || 0, exv = (c.extra||{})[s]||0, chc = (c.choiceStats||[]).filter(x=>x===s).length; stt.append(h('tr',{class:'sc-'+s}, h('td',{class:'n'}, T(s)), h('td',{text:kin.raw[s]}), h('td',{text:String(chv+chc)}), h('td',{text:String(adv)}), h('td',{text:String(exv)}), h('td',{text:String(d.raw[s])}), h('td',{class:'ov',text:signed(d.mod[s])}))); }
  st.append(h('div',{class:'tablewrap'}, stt)); right.append(st);
  const pb = h('div',{class:'box'}, h('h4',{text:'Personality Stats'}));
  const pg2 = h('div',{class:'ptable'});
  for (const ax of DATA.meta.personality){ const p=c.personality[ax.id]; const l = (!p||p.value==null)?0:(p.side==='left'?p.value:-p.value); pg2.append(h('span',{class:'lw'}, T(ax.left), h('span',{class:'dim',text:` (${ax.leftTh})`})), h('span',{class:'v',style:'color:#f08c2e',text:signed(l)}), h('span',{class:'dim',text:'/'}), h('span',{class:'v',style:'color:#58b7ff',text:signed(-l)}), h('span',{class:'rc'}, T(ax.right), h('span',{class:'dim',text:` (${ax.rightTh})`}))); }
  pb.append(pg2); right.append(pb);
  const cm = h('div',{class:'box'}, h('h4',null, 'Combat Mod. ', tag('เสนอ','prop')));
  cm.append(h('div',{class:'gives'}, h('span',{class:'tag sc sc-AGI stat'}, T('Reflex'), ` ${signed(d.reflex)}`), h('span',{class:'tag sc sc-STR stat'}, T('Might'), ` ${signed(d.might)}`), h('span',{class:'tag sc sc-PER stat'}, T('Sight'), ` ${signed(d.sight)}`), h('span',{class:'tag sc sc-PER stat'}, T('Initiative'), ` ${signed(d.initiative)}`), h('span',{class:'tag sc sc-VIT stat'}, T('Fortitude'), ` ${signed(d.fortitude)}`), h('span',{class:'tag sc sc-INF stat'}, T('Will'), ` ${signed(d.will)}`), h('span',{class:'tag'}, T('Parry Dice'), ` ${d.parryDice}`), h('span',{class:'tag'}, T('Passive PER'), ` ${d.passivePer}`), h('span',{class:'tag'}, T('Capacity'), ` ${d.capacity} กก.`)));
  right.append(cm);
  const kl = knowledgeLevels(c);
  const kb = h('div',{class:'box'}, h('h4',null, T('Knowledge'), ' (2d6 + Proficiency)'));
  const kt = h('table',{class:'t'});
  for (const k of DATA.knowledge){ const n = Object.values(c.kslots||{}).filter(s=>s&&s.id===k.id&&s.prof&&!s.prof.startsWith('(')).length; kt.append(h('tr',null, h('td',null, h('b',{text:k.nameEn}), h('span',{class:'dim',style:'font-size:11px',text:` (${k.stats.join('/')})`})), h('td',{class:'num',text:'Lv'+kl[k.id]}), h('td',{class:'num',text:'+'+n}))); }
  kb.append(h('div',{class:'tablewrap'}, kt)); right.append(kb);
  right.append(dicePanel(c, (e)=>{ if (Table.roomId) Table.postRoll(e, c); }));
  root.append(h('div',{class:'cs'}, left, mid, right));
}
