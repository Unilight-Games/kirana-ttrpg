/* ===== v1.27 (Non สั่ง 16 พ.ย. 2026): NPC สองประเภท สัตว์ (Fauna) กับผู้คน (Humanoid) ใส่ไอเทมและพฤติกรรมได้แบบเอกสาร Fauna, Enemy & Companion =====
 * "แบ่ง NPC ออกเป็นสองประเภทคือสัตว์ (Fauna) และผู้คน (Humanoid) แล้วทำให้ตอนสร้าง NPC สามารถ insert item และพฤติกรรม ใส่ให้ได้ด้วย เหมือนในเอกสาร Fauna, Enemy & Companion"
 * สแตตบล็อกในเอกสารมี ขนาด ความเร็ว ค่าพลังดัดแปลง ค่าสถานะ การโจมตี Reaction ความสามารถพิเศษ ของดรอปสี่ชั้น และยุทโธปกรณ์ (เฉพาะผู้คน)
 * ช่องที่เพิ่มในรายการคลังและหมาก (ไม่มีช่องไหนบังคับ รายการเดิมที่ไม่มี nkind นับเป็นผู้คน):
 *   nkind fauna|humanoid · size Tiny..Huge · speed · ap · mp (หมากเก็บ mp กับ mpMax) · armorAll · extra (ค่าสถานะอื่น เช่น Sorcery Resistant)
 *   attacks [{name, text}] · defend parry|evade|both|none · defendNote
 *   reactions [{name, text}] · behaviors [{name, text}] (ความสามารถพิเศษ ในเว็บเรียกพฤติกรรม) · drops [{t, r, name, qty, note}] · tpl แม่แบบที่มา
 *   drops.t: g ได้แน่นอน · c ทอย 1d6 เลือกแถวตามช่วง r · u ทอย 1d6 ได้ถ้าออกตาม r · x ทอย 1d10 ได้ถ้าออกตาม r · e ยุทโธปกรณ์ ทอย 1d6 ตามช่วง r
 * แม่แบบ 47 รายการมาจาก DATA.bestiary (tools/parse_bestiary.py อ่านเอกสาร แล้ว tools/splice_v127.py ใส่ลง data.json)
 * Non เคาะ 16 พ.ย. 2026 "ใช้กฎเดียวกัน": NPC ใช้กฎเดียวกับตัวละครผู้เล่นและคู่มือสร้างอสูรในไฟล์แกน
 *   Might Reflex Sight Passive PER คิดจากค่าพลังดัดแปลงเสมอ (ไม่มีค่าแก้เอง) · Initiative = PER Mod (it.init เก็บค่าเดียวกันไว้ให้ส่วนที่อ่าน init ตรง ๆ)
 *   ขนาด: จิ๋ว -1 · ใหญ่ +1 · มหึมา +2 All Toughness และ ใหญ่ +1 · มหึมา +2 All Armor คิดให้เอง tgh กับ armorAll ในรายการคลังจึงเป็นค่าพื้นฐาน หมากเก็บยอดรวม
 *   ผู้คนที่สวมเกราะ: เกราะรายส่วนมาจากชุดที่สวม แม่แบบจึงไม่ใส่ All Armor ที่เอกสารย่อมาจากชุดเดียวกัน */
const NPC_KINDS = [['humanoid','ผู้คน','Humanoid','🧑'], ['fauna','สัตว์','Fauna','🐾']];
const NPC_SIZES = ['Tiny','Small','Medium','Large','Huge'];
const NPC_SIZE_TH = {Tiny:'จิ๋ว', Small:'เล็ก', Medium:'ปานกลาง', Large:'ใหญ่', Huge:'มหึมา'};
const NPC_SIZE_ARMOR = {Large:1, Huge:2}; // ตารางขนาดในเอกสาร Fauna: Large +1 All Armor · Huge +2 All Armor
const NPC_SIZE_TOUGH = {Tiny:-1, Large:1, Huge:2}; // คู่มือสร้างอสูรในไฟล์แกนและตารางขนาด: All Toughness
const NPC_DEFEND = [['','ไม่ระบุ'], ['parry','Parry'], ['evade','Evade'], ['both','เลือก Parry หรือ Evade'], ['none','ไม่ป้องกัน (None)']];
const NPC_DROP_T = [['g','ได้แน่นอน','Guaranteed Drop',''], ['c','ของดรอปทั่วไป','Common Drop','ทอย 1d6 ได้แถวที่ช่วงตรงกับแต้ม'], ['u','ของดรอปหายาก','Uncommon Drop','ทอย 1d6 ได้ทุกแถวถ้าแต้มตรงกับช่วง'], ['x','ของดรอปหายากมาก','Rare Drop','ทอย 1d10 ได้ทุกแถวถ้าแต้มตรงกับช่วง'], ['e','ยุทโธปกรณ์ที่สวมอยู่','Equipment','ทอย 1d6 ได้ชิ้นที่ช่วงตรงกับแต้ม']];
const NPC_STAT_KEYS = ['nkind','size','speed','ap','armorAll','extra','attacks','defend','defendNote','reactions','behaviors','drops','tpl'];
function npcKind(it){ return it && it.nkind === 'fauna' ? 'fauna' : 'humanoid'; }
function npcKindInfo(k){ return NPC_KINDS.find(x=>x[0]===k) || NPC_KINDS[0]; }
function npcKindLabel(k){ const x = npcKindInfo(k); return `${x[3]} ${x[1]} (${x[2]})`; }
function npcListClean(list, max, nameMax, textMax){ if (!Array.isArray(list)) return null; const out = [];
  for (const x of list){ if (out.length >= max) break; if (!x || typeof x !== 'object') continue; const name = libStr(x.name, nameMax).trim(), text = libStr(x.text, textMax).trim(); if (name || text) out.push({name, text}); }
  return out.length ? out : null; }
function npcDropsClean(list){ if (!Array.isArray(list)) return null; const out = [];
  for (const d of list){ if (out.length >= 40) break; if (!d || typeof d !== 'object') continue; const name = libStr(d.name, 100).trim(); if (!name) continue;
    const t = NPC_DROP_T.some(x=>x[0]===d.t) ? d.t : 'g'; const r = /^\d{1,2}(?:-\d{1,2})?$/.test(String(d.r||'').trim()) ? String(d.r).trim() : '';
    out.push({t, r: t==='g' ? '' : r, name, qty: libStr(d.qty, 16).trim(), note: libStr(d.note, 160).trim()}); }
  return out.length ? out : null; }
/* ใส่ช่องสแตตบล็อกที่ผ่านการตรวจลงใน o (รายการคลังหรือหมาก) · ข้อมูลจากฐานข้อมูลเป็นของที่ไม่น่าไว้ใจ ทุกช่องจึงบังคับชนิดและความยาว */
function npcStatClean(x, o){ if (!x || typeof x !== 'object') return o;
  if (x.nkind === 'fauna' || x.nkind === 'humanoid') o.nkind = x.nkind;
  if (NPC_SIZES.includes(x.size)) o.size = x.size;
  const sp = libStr(x.speed, 160).trim(); if (sp) o.speed = sp;
  const ap = libInt(x.ap, 0, 9); if (ap) o.ap = ap;
  const aa = libInt(x.armorAll, -5, 9); if (aa) o.armorAll = aa;
  const ex = libStr(x.extra, 300).trim(); if (ex) o.extra = ex;
  const at = npcListClean(x.attacks, 12, 80, 600); if (at) o.attacks = at;
  if (['parry','evade','both','none'].includes(x.defend)) o.defend = x.defend;
  const dn = libStr(x.defendNote, 200).trim(); if (dn) o.defendNote = dn;
  const re = npcListClean(x.reactions, 8, 80, 1200); if (re) o.reactions = re;
  const be = npcListClean(x.behaviors, 16, 80, 2000); if (be) o.behaviors = be;
  const dr = npcDropsClean(x.drops); if (dr) o.drops = dr;
  const tpl = libStr(x.tpl, 80).trim(); if (tpl) o.tpl = tpl;
  return o; }
function npcStatCopy(from, to){ for (const k of NPC_STAT_KEYS) delete to[k]; return npcStatClean(from, to); }
function npcSizeArmor(it){ return NPC_SIZE_ARMOR[it && it.size] || 0; }
function npcAllArmor(it){ return (+(it && it.armorAll) || 0) + npcSizeArmor(it); }
function npcSizeTough(it){ return NPC_SIZE_TOUGH[it && it.size] || 0; }
function npcTough(it){ return Math.max(0, (+(it && it.tgh) || 0) + npcSizeTough(it)); } // Toughness รวมขนาด (รายการคลังเก็บค่าพื้นฐาน)
function npcInit(it){ return ((npcModsClean(it && it.mods) || {}).PER) || 0; } // Initiative = PER Mod
/* Initiative = PER Mod: NPC เดิมที่ตั้ง Initiative ไว้แต่ไม่มี PER Mod ย้ายค่าไปเป็น PER Mod (ลำดับเทิร์นเท่าเดิม) แล้ว init ตาม PER Mod */
function npcInitRule(o){ const mods = npcModsClean(o.mods) || {}; const init = Math.round(+o.init || 0);
  if (!mods.PER && init) mods.PER = Math.max(-10, Math.min(10, init));
  const clean = npcModsClean(mods); if (clean) o.mods = clean; else delete o.mods; o.init = (clean && clean.PER) || 0; return o; }
function npcKindTag(it){ const k = npcKind(it); const x = npcKindInfo(k); const el = tag(`${x[3]} NPC ${x[1]}`, (k==='fauna' ? 'ok' : 'neg') + ' npckindtag'); el.title = `${x[1]} (${x[2]})`; return el; }
function npcStatTags(it){ const tags = [];
  if (it.size && it.size !== 'Medium') tags.push(tag(`ขนาด${NPC_SIZE_TH[it.size]} (${it.size})`,'prop'));
  if (+it.ap) tags.push(tag(`AP ${it.ap}`,'stat')); if (+it.mp) tags.push(tag(`MP ${it.mp}`,'stat sc sc-INT'));
  const aa = npcAllArmor(it); if (aa) tags.push(tag(`All Armor ${signed(aa)}`,'stat'));
  if ((it.attacks||[]).length) tags.push(tag(`⚔ โจมตี ${it.attacks.length}`,'neg'));
  if ((it.behaviors||[]).length) tags.push(tag(`พฤติกรรม ${it.behaviors.length}`,'prop'));
  if ((it.drops||[]).length) tags.push(tag(`ของดรอป ${it.drops.length}`,'ok'));
  if (it.tpl) tags.push(tag('📖 จากเอกสาร','prop'));
  return tags; }

/* ---- แม่แบบจากเอกสาร ---- */
function npcBestiary(){ return (typeof DATA !== 'undefined' && DATA.bestiary) || {entries:[], groups:[], sizes:[]}; }
let NPC_BEH_CACHE = null;
function npcBehaviorList(){ if (NPC_BEH_CACHE) return NPC_BEH_CACHE; const out = [], seen = new Set();
  for (const e of npcBestiary().entries) for (const [kind, arr] of [['ability', e.abilities], ['reaction', e.reactions]]) for (const b of arr||[]){
    const key = kind + '|' + b.name + '|' + b.text; if (seen.has(key)) continue; seen.add(key); out.push({kind, name: b.name, text: b.text, src: e.th || e.name, srcEn: e.en, type: e.type}); }
  return (NPC_BEH_CACHE = out); }
function npcCatalogFind(name){ const cat = itemCatalog(); const n = String(name||'').trim(); if (!n) return null;
  let hit = cat.find(i=>i.name===n); if (hit) return hit;
  const en = (n.match(/\(([^()]*[A-Za-z][^()]*)\)\s*$/)||[])[1]; const th = n.replace(/\s*\([^()]*\)\s*$/, '').trim();
  if (en){ const k = en.toLowerCase().replace(/\s+/g,' ').trim(); hit = cat.find(i=>{ const m = i.name.match(/\(([^()]*)\)\s*$/); return m && m[1].toLowerCase().split('/').map(s=>s.trim()).includes(k); }); if (hit) return hit; }
  return th ? cat.find(i=>i.name.replace(/\s*\([^()]*\)\s*$/, '').trim() === th) || null : null; }
/* สร้างรายการคลังจากแม่แบบ: ค่าที่เอกสารพิมพ์ใช้ตามเอกสาร ค่าพลังรองกับ Initiative คิดจากค่าพลังดัดแปลง · Toughness เก็บเป็นค่าพื้นฐาน (ยอดในเอกสารลบโบนัสขนาด) */
function npcFromTemplate(e){
  const it = NpcLib.newItem('npc', e.type);
  it.name = (e.th || e.name || 'NPC').slice(0, 80);
  it.hp = Math.max(1, +e.hp||10); it.tgh = Math.max(0, (+e.tgh||0) - (NPC_SIZE_TOUGH[e.size] || 0));
  const mods = npcModsClean(e.mods); if (mods) it.mods = mods; it.init = (mods && mods.PER) || 0;
  const extra = String(e.statsExtra||'').split(' · ').filter(x=>!/^Toughness\s*\(/.test(x.trim())).join(' · ');
  const src = { nkind: e.type, size: e.size, speed: e.speed, ap: e.ap, armorAll: e.armorAll, extra, attacks: e.attacks, defend: e.defend, defendNote: e.defendNote,
    reactions: e.reactions, behaviors: e.abilities, drops: e.drops, tpl: `${e.type}:${e.en || e.name}` };
  npcStatClean(src, it);
  if (+e.mp) it.mp = Math.min(999, +e.mp);
  if (/ว่ายน้ำ|ดำน้ำ/.test(e.speed||'') || /สัตว์น้ำ|ในน้ำลึก/.test((e.abilities||[]).map(b=>b.name).join(' '))) it.aquatic = true;
  if (/Dark ?Vision|มองเห็นในความมืด|มองในที่มืด|ไม่ติด Disadvantage จากการต่อสู้ในที่มืด/i.test(JSON.stringify([e.abilities, e.reactions]))) it.nv = true; // เอกสารเขียนแบบหลังกับ Vandel
  if (e.type === 'humanoid' && (e.equip||[]).length){ const eq = [];
    for (const nm of e.equip){ const c = npcCatalogFind(nm); eq.push(c ? {name: c.name, effect: c.effect||'', slot: npcSlotGuess(c), weight: +c.weight||0} : {name: nm, effect: '', slot: npcSlotGuess({name: nm}), weight: 0}); }
    const clean = npcEquipClean(eq); if (clean) it.equip = clean;
    if (it.armorAll && (it.equip||[]).some(x=>parseArmor(x.effect||''))) delete it.armorAll; } // All Armor ในเอกสารย่อมาจากเกราะที่สวม บนเว็บเกราะรายส่วนมาจากชุดเองตามกฎ PC
  const grp = e.group ? npcBestiary().groups.find(g=>g.key===e.group) : null;
  const notes = [];
  if (e.concept) notes.push('แนวคิด: ' + e.concept);
  if (grp && grp.scaling.length) notes.push('ปรับระดับความท้าทาย (' + e.group + '): ' + grp.scaling.map(s=>`${s.tier} ${s.adj}`).join(' · '));
  notes.push('ที่มา: เอกสาร Fauna, Enemy & Companion · ' + (e.type==='fauna' ? `หมวดขนาด${NPC_SIZE_TH[e.size]||''}` : `กลุ่ม ${e.group||''}`) + (e.equipPack ? ' · ' + e.equipPack : ''));
  it.note = notes.join('\n\n').slice(0, 4000);
  return it; }
function npcTemplateRow(e, onUse){
  return h('div',{class:'gift npctpl',dataset:{en:e.en||''}},
    h('div',{style:'min-width:0'}, h('div',null, h('b',{text:e.th||e.name}), h('span',{class:'dim',style:'font-size:12px',text:' ' + (e.en||'')})),
      h('div',{class:'gives'}, tag(e.type==='fauna' ? `ขนาด${NPC_SIZE_TH[e.size]||''}` : (e.group||''),'prop'), tag(`HP ${e.hp}`), tag(`Toughness ${e.tgh}`), e.ap ? tag(`AP ${e.ap}`,'stat') : null, e.mp ? tag(`MP ${e.mp}`,'stat sc sc-INT') : null),
      h('div',{class:'dim',style:'font-size:12px'}, '⚔ ', (e.attacks||[]).map(a=>a.name || a.text.slice(0, 30)).join(' · ') || '-'),
      h('div',{class:'dim',style:'font-size:12px'}, 'พฤติกรรม: ', [...(e.abilities||[]), ...(e.reactions||[])].map(b=>b.name.replace(/\s*\([^()]*\)\s*$/, '')).join(' · ') || '-')),
    h('button',{class:'small primary npctpl-use',onclick:(ev)=>onUse(e, ev.currentTarget),text:'สร้างจากแม่แบบ'})); }
/* หน้าต่างเลือกแม่แบบ: แท็บสัตว์ (เรียงตามขนาด) กับผู้คน (ตามกลุ่ม) */
function npcTemplatePicker(onCreate){
  const B = npcBestiary(); let kind = 'fauna';
  const q = h('input',{type:'search',placeholder:'ค้นหาชื่อ พฤติกรรม หรือการโจมตี',style:'min-width:220px;flex:1'});
  const tabs = h('div',{class:'row',style:'gap:4px'}); const list = h('div',{class:'giftlist npctpllist'});
  const drawTabs = ()=>{ clear(tabs); for (const [k, th, en, ic] of [['fauna','สัตว์','Fauna','🐾'], ['humanoid','ผู้คน','Humanoid','🧑']]) tabs.append(h('button',{class:'small'+(kind===k?' on':''),dataset:{kind:k},onclick:()=>{ kind = k; drawTabs(); draw(); },text:`${ic} ${th} (${en}) ${B.entries.filter(e=>e.type===k).length}`})); };
  const draw = ()=>{ clear(list); const k = q.value.trim().toLowerCase();
    const all = B.entries.filter(e=>e.type===kind && (!k || JSON.stringify([e.name, e.en, e.attacks, e.abilities, e.reactions]).toLowerCase().includes(k)));
    const groups = kind==='fauna' ? NPC_SIZES.map(s=>[`ขนาด${NPC_SIZE_TH[s]} (${s})`, all.filter(e=>e.size===s)]) : [...new Set(all.map(e=>e.group))].map(g=>[g, all.filter(e=>e.group===g)]);
    for (const [title, arr] of groups){ if (!arr.length) continue; list.append(h('div',{class:'kicker',style:'margin-top:8px',text:`${title} · ${arr.length}`}));
      for (const e of arr) list.append(npcTemplateRow(e, async (tpl, btn)=>{ btn.disabled = true; try { await onCreate(tpl); } finally { btn.disabled = false; } })); }
    if (!all.length) list.append(h('div',{class:'dim',text:'ไม่พบแม่แบบที่ตรงกับคำค้น'})); };
  q.oninput = draw; drawTabs(); draw();
  modal(h('div',{class:'npctplpick'}, h('h3',{text:'สร้าง NPC จากแม่แบบในเอกสาร Fauna, Enemy & Companion'}),
    h('p',{class:'dim',style:'font-size:12.5px;margin:2px 0 6px',text:`${B.entries.length} แม่แบบ ได้ค่าพลัง ค่าสถานะ การโจมตี Reaction พฤติกรรม ของดรอป และยุทโธปกรณ์ตามเอกสาร แล้วแก้ต่อได้ในคลังของคุณ`}),
    h('div',{class:'row',style:'gap:8px'}, tabs, q), list));
  setTimeout(()=>q.focus(), 50); }

/* ---- รายการชื่อกับข้อความ (การโจมตี Reaction พฤติกรรม) ---- */
function npcNamedListBox(get, set, opts){ opts = opts || {};
  const box = h('div',{class:'npcnl ' + (opts.cls||'')});
  const commit = (nl)=>{ set(nl); draw(); };
  const draw = ()=>{ clear(box); const list = get() || [];
    if (!list.length) box.append(h('p',{class:'dim',style:'font-size:12.5px;margin:4px 0',text: opts.empty || 'ยังไม่มี'}));
    list.forEach((x, i)=>{ const nm = h('input',{value:x.name,placeholder: opts.namePh || 'ชื่อ',maxlength:80,class:'npcnl-name',oninput:(e)=>{ const nl = (get()||[]).slice(); nl[i] = {name: e.target.value, text: nl[i].text}; set(nl); }});
      const tx = h('textarea',{placeholder: opts.textPh || 'รายละเอียด',maxlength: opts.textMax || 2000,class:'npcnl-text',oninput:(e)=>{ const nl = (get()||[]).slice(); nl[i] = {name: nl[i].name, text: e.target.value}; set(nl); }}); tx.value = x.text;
      box.append(h('div',{class:'npcnl-row'}, h('div',{class:'npcnl-head'}, nm, h('button',{class:'small ghost',title:'เลื่อนขึ้น',disabled: i===0,onclick:()=>{ const nl = (get()||[]).slice(); [nl[i-1], nl[i]] = [nl[i], nl[i-1]]; commit(nl); },text:'↑'}), h('button',{class:'small ghost npcnl-del',title:'เอาออก',onclick:()=>{ const nl = (get()||[]).slice(); nl.splice(i, 1); commit(nl); },text:'✕'})), tx)); });
    const row = h('div',{class:'row',style:'gap:6px;margin-top:6px'});
    if (opts.pick) row.append(h('button',{class:'small primary npcnl-pick',onclick:()=>opts.pick((b)=>{ const cur = get() || []; if (cur.length >= opts.max){ toast(`ใส่ได้ไม่เกิน ${opts.max} รายการ`); return false; } set([...cur, {name: b.name, text: b.text}]); draw(); return true; }),text: opts.pickLabel || '+ เลือกจากเอกสาร'}));
    row.append(h('button',{class:'small npcnl-add',onclick:()=>{ const cur = get() || []; if (cur.length >= opts.max){ toast(`ใส่ได้ไม่เกิน ${opts.max} รายการ`); return; } commit([...cur, {name:'', text:''}]); const ins = box.querySelectorAll('.npcnl-name'); if (ins.length) ins[ins.length - 1].focus(); },text: opts.addLabel || '+ เขียนเอง'}));
    box.append(row); };
  box.refresh = draw; draw(); return box; }
/* หน้าต่างเลือกพฤติกรรมจากเอกสาร: ความสามารถพิเศษและ Reaction ของสัตว์และผู้คนทุกตัว */
function npcBehaviorPicker(opts){ opts = opts || {}; let kind = opts.kind || 'ability', type = opts.type || 'all';
  const all = npcBehaviorList(); const q = h('input',{type:'search',placeholder:'ค้นหาชื่อ คำอธิบาย หรือชื่อสัตว์',style:'min-width:200px;flex:1'});
  const chips = h('div',{class:'row',style:'gap:4px;flex-wrap:wrap'}); const list = h('div',{class:'giftlist npcbehlist'}); const note = h('div',{class:'dim npcbeh-added',style:'font-size:12px;min-height:18px'});
  const drawChips = ()=>{ clear(chips);
    for (const [k, l] of [['ability','ความสามารถพิเศษ'], ['reaction','Reaction']]) chips.append(h('button',{class:'small'+(kind===k?' on':''),dataset:{bk:k},onclick:()=>{ kind = k; drawChips(); draw(); },text:`${l} (${all.filter(b=>b.kind===k).length})`}));
    chips.append(h('span',{class:'dim',style:'font-size:12px;margin:0 2px 0 8px',text:'จาก'}));
    for (const [k, l] of [['all','ทุกตัว'], ['fauna','สัตว์'], ['humanoid','ผู้คน']]) chips.append(h('button',{class:'small'+(type===k?' on':''),dataset:{bt:k},onclick:()=>{ type = k; drawChips(); draw(); },text:l})); };
  const draw = ()=>{ clear(list); const k = q.value.trim().toLowerCase();
    const hits = all.filter(b=>b.kind===kind && (type==='all' || b.type===type) && (!k || (b.name + ' ' + b.text + ' ' + b.src + ' ' + b.srcEn).toLowerCase().includes(k)));
    for (const b of hits.slice(0, 80)) list.append(h('div',{class:'gift npcbeh'}, h('div',{style:'min-width:0'}, h('b',{text:b.name}), ' ', tag(b.src, b.type==='fauna' ? 'ok' : 'stat'), h('div',{class:'desc',style:'font-size:12px'}, T(b.text))),
      h('button',{class:'small primary',onclick:()=>{ if (opts.onPick(b) !== false){ note.textContent = `ใส่ ${b.name} แล้ว เลือกต่อได้เลย`; toast(`ใส่ ${b.name} แล้ว`); } },text:'ใส่'})));
    if (!hits.length) list.append(h('div',{class:'dim',text:'ไม่พบ ลองคำค้นอื่น หรือกด "+ เขียนเอง" ในตัวแก้'}));
    if (hits.length > 80) list.append(h('div',{class:'dim',style:'font-size:12px',text:`แสดง 80 จาก ${hits.length} พิมพ์ค้นหาเพิ่มเพื่อกรอง`})); };
  q.oninput = draw; drawChips(); draw();
  modal(h('div',{class:'npcbehpick'}, h('h3',{text: opts.title || 'ใส่พฤติกรรมจากเอกสาร'}),
    h('p',{class:'dim',style:'font-size:12.5px;margin:2px 0 6px',text:'ความสามารถพิเศษและ Reaction ของสัตว์และผู้คนในเอกสาร Fauna, Enemy & Companion ใส่แล้วแก้ข้อความต่อได้ หน้าต่างนี้เปิดค้างไว้ให้ใส่ต่อ'}),
    opts.back ? h('button',{class:'small',style:'margin-bottom:6px',onclick:opts.back,text:'← กลับ'}) : null,
    h('div',{class:'row',style:'gap:8px;margin-top:4px'}, chips, q), note, list));
  setTimeout(()=>q.focus(), 50); }

/* ---- ของดรอป ---- */
function npcDropPicker(onPick, back){
  const cat = itemCatalog(); const q = h('input',{type:'search',placeholder:'ค้นหาไอเทม เช่น เนื้อ หนัง ยา เหรียญ',style:'min-width:200px;flex:1'}); const list = h('div',{class:'giftlist npcdroplist'});
  const cats = [...new Set(cat.map(i=>i.cat).filter(Boolean))];
  const catSel = h('select',null, h('option',{value:'',text:`ทุกหมวด (${cat.length})`}), cats.map(k=>h('option',{value:k,text:`${k} (${cat.filter(i=>i.cat===k).length})`})));
  const note = h('div',{class:'dim',style:'font-size:12px;min-height:18px'});
  const draw = ()=>{ clear(list); const k = q.value.trim().toLowerCase(); const ck = catSel.value;
    const all = cat.filter(it=>(!ck || it.cat===ck) && (!k || (it.name + ' ' + it.effect + ' ' + (it.desc||'')).toLowerCase().includes(k))); const hits = all.slice(0, 60);
    for (const it of hits) list.append(h('div',{class:'gift'}, h('div',{style:'min-width:0'}, h('b',{text:it.name}), h('span',{class:'dim',style:'font-size:11px',text:` · ${it.sub || it.cat}`}), it.effect ? h('div',{class:'desc',style:'font-size:12px'}, T(it.effect)) : null),
      h('button',{class:'small primary',onclick:()=>{ if (onPick(it) !== false){ note.textContent = `ใส่ ${itemNameSplit(it.name)[0]} แล้ว เลือกต่อได้เลย`; toast(`ใส่ ${itemNameSplit(it.name)[0]} แล้ว`); } },text:'ใส่'})));
    if (!hits.length) list.append(h('div',{class:'dim',text:'ไม่พบ ปิดหน้าต่างนี้แล้วกด "+ พิมพ์เอง" ได้'}));
    if (all.length > hits.length) list.append(h('div',{class:'dim',style:'font-size:12px',text:`แสดง ${hits.length} จาก ${all.length} พิมพ์ค้นหาเพิ่มเพื่อกรอง`})); };
  q.oninput = draw; catSel.onchange = draw; draw();
  modal(h('div',{class:'npcdroppick'}, h('h3',{text:'ใส่ของดรอปจากคลังไอเทม'}), h('p',{class:'dim',style:'font-size:12.5px;margin:2px 0 6px',text:'รายการจาก Item All และชุดเริ่มต้น ของที่ใส่เข้าไปเริ่มเป็น "ได้แน่นอน" เปลี่ยนชั้นและช่วงแต้มได้ในรายการ หน้าต่างนี้เปิดค้างไว้ให้ใส่ต่อ'}),
    back ? h('button',{class:'small',style:'margin-bottom:6px',onclick:back,text:'← กลับ'}) : null,
    h('div',{class:'row',style:'margin-top:4px'}, q, catSel), note, list));
  setTimeout(()=>q.focus(), 50); }
/* เงินในเอกสาร (เงิน (Coins) หรือเหรียญ) ถือเป็นเกรฟ เข้าช่องเกรฟ (เงิน) ของชีท: ชุดเริ่มต้นให้เงิน 15 เกรฟ และทหารรับจ้างในเอกสารพกเหรียญ 15 เท่ากัน */
function npcIsMoney(name){ return /^(?:เงิน\s*\(Coins?\)|เงิน|เหรียญ|Coins?|เกรฟ)$/i.test(String(name||'').trim()); }
function npcDropText(d){ return `${d.name}${d.qty ? ' ×' + d.qty : ''}${d.note ? ' ' + d.note : ''}`; } // หมายเหตุในเอกสารส่วนใหญ่ขึ้นด้วยหน่วย เช่น ชิ้น คู่ ซี่
function npcDropBox(get, set, opts){ opts = opts || {};
  const box = h('div',{class:'npcdrop'});
  const commit = (nl)=>{ set(nl); draw(); };
  const draw = ()=>{ clear(box); const list = get() || []; const kind = opts.kind ? opts.kind() : 'humanoid';
    const cats = itemCatalog(); const dl = h('datalist',{id:'npcdrop-names'}, cats.slice(0, 600).map(i=>h('option',{value:i.name})));
    box.append(dl);
    if (!list.length) box.append(h('p',{class:'dim',style:'font-size:12.5px;margin:4px 0',text:'ยังไม่มีของดรอป กด "+ จากคลังไอเทม" หรือ "+ พิมพ์เอง"'}));
    for (const [t, th, en, how] of NPC_DROP_T){ const rows = list.map((d, i)=>[d, i]).filter(([d])=>d.t===t); if (!rows.length) continue;
      box.append(h('div',{class:'npcdrop-head'}, h('b',{text:th}), h('span',{class:'dim',text:` ${en}${how ? ' · ' + how : ''}`})));
      for (const [d, i] of rows){
        const upd = (patch)=>{ const nl = (get()||[]).slice(); nl[i] = Object.assign({}, nl[i], patch); set(nl); };
        const tSel = h('select',{class:'npcdrop-t',title:'ชั้นของดรอป',onchange:(e)=>{ const nl = (get()||[]).slice(); nl[i] = Object.assign({}, nl[i], {t: e.target.value, r: e.target.value==='g' ? '' : (nl[i].r || (e.target.value==='x' ? '10' : e.target.value==='u' ? '6' : '1-3'))}); commit(nl); }}, NPC_DROP_T.map(([k, l])=>h('option',{value:k, selected: d.t===k, text:l})));
        const r = h('input',{class:'npcdrop-r',value:d.r,placeholder: t==='g' ? '' : t==='c' || t==='e' ? '1-3' : t==='x' ? '10' : '6',maxlength:5,title: t==='u' || t==='x' ? 'แต้มที่ได้ของ เช่น 6 หรือ 5-6' : 'ช่วงแต้มของแถวนี้ เช่น 1-3',disabled: t==='g',oninput:(e)=>upd({r: e.target.value.trim()})});
        box.append(h('div',{class:'npcdrop-row',dataset:{t}}, tSel, r,
          h('input',{class:'npcdrop-name',value:d.name,list:'npcdrop-names',maxlength:100,placeholder:'ชื่อของ',oninput:(e)=>upd({name: e.target.value})}),
          h('input',{class:'npcdrop-qty',value:d.qty,maxlength:16,placeholder:'จำนวน',title:'ตัวเลข หรือเต๋า เช่น 1d3 2d6+3 · X = ตามจำนวนที่ล้มได้',oninput:(e)=>upd({qty: e.target.value.trim()})}),
          h('input',{class:'npcdrop-note',value:d.note,maxlength:160,placeholder:'หน่วยหรือหมายเหตุ เช่น ชิ้น',oninput:(e)=>upd({note: e.target.value})}),
          h('button',{class:'small ghost',title:'เอาออก',onclick:()=>{ const nl = (get()||[]).slice(); nl.splice(i, 1); commit(nl); },text:'✕'}))); } }
    const add = (row)=>{ const cur = get() || []; if (cur.length >= 40){ toast('ใส่ของดรอปได้ไม่เกิน 40 แถว'); return false; } set([...cur, row]); return true; };
    box.append(h('div',{class:'row',style:'gap:6px;margin-top:8px'},
      h('button',{class:'small primary npcdrop-pick',onclick:()=>npcDropPicker((it)=>{ const ok = add({t:'g', r:'', name: it.name, qty:'1', note:''}); if (ok && !opts.back) draw(); return ok; }, opts.back),text:'+ จากคลังไอเทม'}),
      h('button',{class:'small npcdrop-add',onclick:()=>{ if (add({t:'g', r:'', name:'ของใหม่', qty:'1', note:''})) draw(); },text:'+ พิมพ์เอง'}),
      kind==='humanoid' ? h('button',{class:'small ghost npcdrop-fromeq',title:'ทำแถวยุทโธปกรณ์จากอาวุธและชุดเกราะที่ใส่ไว้ แบ่งแต้ม 1-6 ให้เท่า ๆ กัน',onclick:()=>{ const eq = (opts.equip ? opts.equip() : []) || []; if (!eq.length){ toast('ยังไม่ได้ใส่อาวุธหรือชุดเกราะ'); return; }
        const cur = (get()||[]).filter(d=>d.t!=='e'); const n = Math.min(6, eq.length); const step = 6 / n; const rows = eq.slice(0, n).map((e, k)=>{ const lo = Math.floor(k*step) + 1, hi = Math.floor((k+1)*step); return {t:'e', r: lo===hi ? String(lo) : `${lo}-${hi}`, name: e.name, qty:'', note:''}; });
        commit([...cur, ...rows].slice(0, 40)); },text:'ทำแถวยุทโธปกรณ์จากของที่สวม'}) : null));
    const warn = npcDropWarn(list); if (warn) box.append(h('div',{class:'warnbox npcdrop-warn',style:'margin-top:6px',text:warn})); };
  box.refresh = draw; draw(); return box; }
/* เตือนช่วงแต้มที่ไม่ครบหรือซ้อนกันของชั้นที่ทอยตามช่วง */
function npcDropWarn(list){ const out = [];
  for (const t of ['c','e']){ const rows = (list||[]).filter(d=>d.t===t); if (!rows.length) continue; const hit = [0,0,0,0,0,0,0];
    for (const d of rows){ const m = String(d.r||'').match(/^(\d+)(?:-(\d+))?$/); if (!m){ out.push(`${d.name}: ช่วงแต้มว่างหรืออ่านไม่ออก`); continue; } for (let v = +m[1]; v <= +(m[2]||m[1]); v++) if (v>=1 && v<=6) hit[v]++; }
    const miss = [1,2,3,4,5,6].filter(v=>!hit[v]); if (miss.length) out.push(`${t==='c' ? 'ของดรอปทั่วไป' : 'ยุทโธปกรณ์'} ยังไม่มีแถวของแต้ม ${miss.join(' ')}`); }
  return out.join(' · '); }
/* ทอยของดรอป: ชั้นละหนึ่งครั้ง จำนวนที่เขียนเป็นเต๋าทอยให้ด้วย */
function npcRollQty(q){ q = String(q||'').replace(/\s+/g, ''); if (!q) return {n:1, txt:'1'}; if (/^X$/i.test(q)) return {n:null, txt:'X'};
  let m = q.match(/^(\d{1,2})d(\d{1,3})([+\-]\d{1,3})?$/i);
  if (m){ const rolls = []; for (let i = 0; i < +m[1]; i++) rolls.push(1 + Math.floor(Math.random() * +m[2])); const n = Math.max(0, rolls.reduce((a, b)=>a + b, 0) + +(m[3]||0)); return {n, txt:`${n} (${q}: ${rolls.join('+')}${m[3]||''})`}; }
  m = q.match(/^(\d{1,4})(?:-(\d{1,4}))?$/); if (m){ if (m[2]){ const lo = +m[1], hi = Math.max(+m[1], +m[2]); const n = lo + Math.floor(Math.random() * (hi - lo + 1)); return {n, txt:`${n} (${q})`}; } return {n: +m[1], txt: m[1]}; }
  return {n:null, txt:q}; }
function npcInRange(r, v){ const m = String(r||'').match(/^(\d+)(?:-(\d+))?$/); if (!m) return false; return v >= +m[1] && v <= +(m[2]||m[1]); }
function npcRollDrops(drops){ const out = {rolls: [], items: []}; const d = (n)=>1 + Math.floor(Math.random() * n);
  const by = (t)=>(drops||[]).filter(x=>x.t===t);
  for (const x of by('g')) out.items.push(Object.assign({}, x, {q: npcRollQty(x.qty)}));
  for (const [t, sides, dflt] of [['c',6,''], ['u',6,'6'], ['x',10,'10'], ['e',6,'']]){ const rows = by(t); if (!rows.length) continue; const v = d(sides);
    const got = rows.filter(x=>npcInRange(x.r || dflt, v)); out.rolls.push({t, die:'1d' + sides, v, got: got.length});
    for (const x of got) out.items.push(Object.assign({}, x, {q: npcRollQty(x.qty)})); }
  return out; }
function npcDropModal(t, r){
  const res = npcRollDrops(t.drops); t.looted = Date.now(); Table.save();
  const tname = (k)=>(NPC_DROP_T.find(x=>x[0]===k)||[])[1] || k;
  const summary = res.rolls.map(x=>`${tname(x.t)} ${x.die} = ${x.v}${x.got ? '' : ' (ไม่ได้)'}`).join(' · ');
  const itemsTxt = res.items.map(x=>`${x.name} ×${x.q.n == null ? x.q.txt : x.q.n}`).join(', ') || 'ไม่มี';
  Table.post({kind:'sys', who:'GM', text:`ของดรอปจาก ${t.name}: ${itemsTxt}${summary ? ' (' + summary + ')' : ''}`, gmOnly:true});
  const pcs = (r.tokens||[]).filter(x=>x.charId && x.kind==='pc');
  const list = h('div',{class:'npcdroproll'});
  if (!res.items.length) list.append(h('p',{class:'dim',text:'รอบนี้ไม่มีของดรอป'}));
  for (const x of res.items){ const money = npcIsMoney(x.name); const cat = money ? null : npcCatalogFind(x.name);
    const qty = h('input',{type:'number',min:1,max:999,value: x.q.n == null ? 1 : Math.max(1, x.q.n),style:'width:64px',title: x.q.n == null ? `เอกสารเขียน ${x.q.txt} ใส่จำนวนเอง` : x.q.txt});
    const to = h('select',null, pcs.length ? pcs.map(p=>h('option',{value:p.id,text:p.name})) : h('option',{value:'',text:'ไม่มีตัวละครบนบอร์ด'}));
    list.append(h('div',{class:'gift'}, h('div',{style:'min-width:0'}, h('b',{text:x.name}), ' ', tag((NPC_DROP_T.find(y=>y[0]===x.t)||[])[1] || '', x.t==='g' ? 'ok' : 'prop'), h('span',{class:'dim',style:'font-size:12px',text:` จำนวน ${x.q.txt}${x.note ? ' · ' + x.note : ''}${money ? ' · เข้าช่องเกรฟ (เงิน) ของชีท' : cat ? '' : ' · ไม่อยู่ในคลังไอเทม ส่งเป็นของกำหนดเอง'}`})),
      h('div',{class:'row',style:'gap:4px;flex-wrap:nowrap'}, qty, to, h('button',{class:'small primary',disabled: !pcs.length,onclick:async(ev)=>{ const tok = pcs.find(p=>p.id===to.value); if (!tok) return; ev.currentTarget.disabled = true;
        const btn = ev.currentTarget; await sendGift(r, tok, money ? {money: Math.max(1, +qty.value||1)} : {name: cat ? cat.name : x.name, effect: cat ? cat.effect : (x.note||''), weight: cat ? +cat.weight||0 : 0, qty: Math.max(1, +qty.value||1)}); btn.textContent = 'มอบแล้ว'; },text:'มอบ'})))); }
  modal(h('div',{class:'npcdropmodal'}, h('h3',{text:`ของดรอปจาก ${t.name}`}), summary ? h('p',{class:'dim',style:'font-size:12.5px',text:summary}) : null,
    h('p',{class:'dim',style:'font-size:12px;margin:0 0 6px',text:'ผลทอยลงแชตแบบ GM เห็นคนเดียวแล้ว เลือกตัวละครแล้วกดมอบ ของเข้ากระเป๋าของเจ้าของทันทีที่เขาออนไลน์'}), list,
    h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'small',onclick:()=>npcDropModal(t, r),text:'🎲 ทอยใหม่'}), h('button',{class:'small ghost',onclick:()=>modal(null),text:'ปิด'})))); }

/* ---- ตัวแก้ในคลัง (#npcedit-<id>) ---- */
function npcEditorTop(it, markDirty, onKind){
  const kindRow = h('div',{class:'row npckind',role:'radiogroup','aria-label':'ประเภท NPC'});
  const drawKind = ()=>{ clear(kindRow); kindRow.append(h('span',{class:'dim',style:'font-size:12px',text:'ประเภท'}));
    for (const [k, th, en, ic] of NPC_KINDS) kindRow.append(h('button',{class:'small npckindbtn'+(npcKind(it)===k?' on':''),role:'radio','aria-checked': npcKind(it)===k ? 'true' : 'false',dataset:{kind:k},onclick:()=>{ it.nkind = k; drawKind(); markDirty(); if (onKind) onKind(); },text:`${ic} ${th} (${en})`})); };
  drawKind();
  const size = h('select',{dataset:{f:'size'},onchange:(e)=>{ if (e.target.value) it.size = e.target.value; else delete it.size; markDirty(); if (onKind) onKind(); }}, h('option',{value:'',text:'ไม่ระบุ (ปานกลาง)'}), NPC_SIZES.map(s=>h('option',{value:s, selected: it.size===s, text:`${NPC_SIZE_TH[s]} (${s})${NPC_SIZE_TOUGH[s] ? ' · ' + signed(NPC_SIZE_TOUGH[s]) + ' Toughness' : ''}${NPC_SIZE_ARMOR[s] ? ' · +' + NPC_SIZE_ARMOR[s] + ' All Armor' : ''}`})));
  const speed = h('input',{value: it.speed||'',maxlength:160,placeholder:'เช่น เดิน 2 ม./วินาที, วิ่ง 10 ม./วินาที',style:'min-width:220px;flex:1',dataset:{f:'speed'},oninput:(e)=>{ it.speed = e.target.value; markDirty(); }});
  return h('div',{class:'npctop'}, kindRow, h('div',{class:'row',style:'margin-top:6px'}, h('label',{class:'fld',title:'คิดให้เองตามคู่มือสร้างอสูรและตารางขนาด: จิ๋ว -1 Toughness · ใหญ่ +1 Toughness และ +1 All Armor · มหึมา +2 Toughness และ +2 All Armor'}, h('span',{text:'ขนาด'}), size), h('label',{class:'fld',style:'flex:1'}, h('span',{text:'ความเร็ว'}), speed))); }
function npcEditorStats(it, num, markDirty){
  const aaHint = h('span',{class:'dim npcaa-hint',style:'font-size:11.5px'}), tgHint = h('span',{class:'dim npctg-hint',style:'font-size:11.5px'});
  const initEl = h('b',{class:'num npcinit',style:'min-width:30px'});
  const refresh = ()=>{ const s = npcSizeArmor(it), t = npcSizeTough(it); aaHint.textContent = s ? `รวมจากขนาด ${signed(s)} = ${signed(npcAllArmor(it))}` : ''; tgHint.textContent = t ? `รวมจากขนาด ${signed(t)} = ${npcTough(it)}` : ''; initEl.textContent = signed(npcInit(it)); };
  const extra = h('input',{value: it.extra||'',maxlength:300,placeholder:'ค่าอื่น เช่น +2 Sorcery Resistant หรือ (สำหรับฝูงเต็ม 3 ตัว)',style:'min-width:240px;flex:1',dataset:{f:'extra'},oninput:(e)=>{ it.extra = e.target.value; markDirty(); }});
  const aa = num('armorAll', -5, 9, 56); aa.addEventListener('input', refresh);
  const tg = num('tgh', 0, 99, 56); tg.addEventListener('input', refresh);
  const row = h('div',{class:'row npcstats'}, h('label',{class:'fld'}, h('span',{text:'HP สูงสุด'}), num('hp', 1, 999)), h('label',{class:'fld',title:'MP สูงสุดของ NPC ที่ร่ายเวท ใส่ 0 ถ้าไม่ใช้ บนโต๊ะติดตามได้เหมือน HP'}, h('span',{text:'MP (0 = ไม่ใช้)'}), num('mp', 0, 999, 64)),
    h('label',{class:'fld',title:'Toughness พื้นฐานของ NPC ใส่ 0 ถ้ายังไม่ใช้ โบนัสจากขนาดบวกให้เอง แก้บนโต๊ะได้'}, h('span',{text:'Toughness'}), tg), tgHint, h('label',{class:'fld',title:'Action Point ต่อเทิร์น'}, h('span',{text:'AP'}), num('ap', 0, 9, 50)),
    h('label',{class:'fld',title:'Initiative = PER Mod ตามกฎของตัวละครผู้เล่นและคู่มือสร้างอสูร แก้ที่ PER Mod ด้านล่าง'}, h('span',{text:'Initiative'}), initEl), h('label',{class:'fld',title:'เกราะที่บวกให้ทุกส่วน เช่น เปลือกแข็งของสัตว์ เกราะจากชุดที่สวมคิดในการ์ดอาวุธและชุดเกราะ'}, h('span',{text:'All Armor'}), aa), aaHint);
  refresh();
  const out = [row, h('div',{class:'row',style:'margin-top:4px'}, h('label',{class:'fld',style:'flex:1'}, h('span',{text:'ค่าสถานะอื่น'}), extra))];
  out.refresh = refresh; return out; }
function npcEditorCards(it, markDirty, equipCard){
  const kindNow = ()=>npcKind(it);
  /* ตัวแก้เก็บรายการตามที่พิมพ์ (แถวว่างอยู่ได้ระหว่างพิมพ์) · NpcLib.save ตรวจและตัดแถวว่างก่อนเขียนลงฐานข้อมูล */
  const keep = (key)=>(v)=>{ if (Array.isArray(v) && v.length) it[key] = v; else delete it[key]; markDirty(); };
  const attacks = npcNamedListBox(()=>it.attacks, keep('attacks'),
    {max:12, cls:'npcatk', empty:'ยังไม่มีการโจมตี อาวุธในการ์ดอาวุธและชุดเกราะคิดความเสียหายให้เอง ส่วนเขี้ยว กรงเล็บ หรือเวทใส่ที่นี่', namePh:'ชื่อ เช่น กัด (Bite)', textPh:'เช่น CV Bonus +2, Damage 1d6 + Might Piercing', textMax:600, addLabel:'+ เพิ่มการโจมตี'});
  const defSel = h('select',{dataset:{f:'defend'},onchange:(e)=>{ if (e.target.value) it.defend = e.target.value; else delete it.defend; markDirty(); }}, NPC_DEFEND.map(([k, l])=>h('option',{value:k, selected:(it.defend||'')===k, text:l})));
  const defNote = h('input',{value: it.defendNote||'',maxlength:200,placeholder:'หมายเหตุ เช่น ติด Disadvantage ในการ Evade',style:'min-width:200px;flex:1',dataset:{f:'defendNote'},oninput:(e)=>{ it.defendNote = e.target.value; markDirty(); }});
  const reactions = npcNamedListBox(()=>it.reactions, keep('reactions'),
    {max:8, cls:'npcreact', empty:'ยังไม่มี Reaction พิเศษ', namePh:'ชื่อ Reaction', textPh:'เงื่อนไขและผล', textMax:1200,
     pick:(add)=>npcBehaviorPicker({kind:'reaction', type: kindNow(), title:'ใส่ Reaction จากเอกสาร', onPick:(b)=>add(b)})});
  const behaviors = npcNamedListBox(()=>it.behaviors, keep('behaviors'),
    {max:16, cls:'npcbehv', empty:'ยังไม่มีพฤติกรรม กด "+ เลือกจากเอกสาร" เพื่อหยิบความสามารถพิเศษของสัตว์หรือผู้คนในเอกสาร หรือเขียนเอง', namePh:'ชื่อ เช่น กลยุทธ์ฝูง (Pack Tactics)', textPh:'ทำอะไร เมื่อไร ได้ผลอย่างไร', textMax:2000,
     pick:(add)=>npcBehaviorPicker({kind:'ability', type: kindNow(), title:'ใส่พฤติกรรมจากเอกสาร', onPick:(b)=>add(b)})});
  const drops = npcDropBox(()=>it.drops, keep('drops'), {kind: kindNow, equip: ()=>it.equip});
  const eqWrap = h('div',{class:'npceqwrap'});
  const placeEquip = ()=>{ clear(eqWrap); if (!equipCard) return; if (kindNow()==='fauna') eqWrap.append(h('details',{class:'card npceqfold',style:'margin-bottom:10px'}, h('summary',{text:'อาวุธและชุดเกราะ (สัตว์ส่วนใหญ่ไม่ใช้ เปิดเมื่อสัตว์ตัวนี้สวมเกราะหรือถืออาวุธ)'}), equipCard)); else eqWrap.append(h('div',{class:'card npceqcard',style:'margin-bottom:10px'}, h('h3',{text:'อาวุธและชุดเกราะ'}), equipCard)); };
  placeEquip();
  const card = (title, sub, ...kids)=>h('div',{class:'card npcstatcard',style:'margin-bottom:10px'}, h('h3',{text:title}), sub ? h('p',{class:'dim',style:'font-size:12px;margin:2px 0 8px',text:sub}) : null, ...kids);
  const cards = [
    card('การโจมตี', 'ตามแบบสแตตบล็อกในเอกสาร: ชื่อการโจมตี แล้วตามด้วย CV Bonus และความเสียหาย', attacks),
    card('การป้องกันและ Reaction', null, h('div',{class:'row',style:'margin-bottom:6px'}, h('label',{class:'fld'}, h('span',{text:'ป้องกัน (Defend)'}), defSel), defNote), reactions),
    card('พฤติกรรมและความสามารถพิเศษ', 'ความสามารถพิเศษในสแตตบล็อก เช่น กลยุทธ์ฝูง หวาดกลัวแสงไฟ ระเบียบวินัย GM เห็นบนแผงหมากระหว่างเล่น', behaviors),
    eqWrap,
    card('ไอเทมที่ดรอป', 'สี่ชั้นแบบเอกสาร: ได้แน่นอน · ทั่วไป (ทอย 1d6 ตามช่วง) · หายาก (ทอย 1d6) · หายากมาก (ทอย 1d10) · ยุทโธปกรณ์ที่สวมอยู่ (ผู้คน) บนโต๊ะ GM กดทอยแล้วมอบให้ผู้เล่นได้', drops)];
  cards.refreshKind = ()=>{ placeEquip(); drops.refresh(); };
  cards.refreshDrops = ()=>drops.refresh();
  return cards; }
/* สแตตบล็อกอ่านอย่างเดียว เรียงแบบในเอกสาร: ใช้ในหน้าดูรายการและตัวอย่างในตัวแก้ */
function npcStatBlock(it){
  const k = npcKind(it); const box = h('div',{class:'npcblock',dataset:{kind:k}});
  const line = (label, ...val)=>h('div',{class:'npcblock-l'}, h('b',{text:label + ': '}), ...val);
  const named = (x)=>[x.name ? h('b',{class:'npcblock-n',text:x.name + ' '}) : null, T(x.text || '')];
  box.append(h('div',{class:'kicker',text:'สแตตบล็อก'}));
  box.append(line('ประเภท', `${npcKindLabel(k)}${it.size ? ' · ขนาด' + NPC_SIZE_TH[it.size] + ' (' + it.size + ')' : ''}`));
  if (it.speed) box.append(line('ความเร็ว', it.speed));
  const aa = npcAllArmor(it);
  const tg = npcTough(it), tgs = npcSizeTough(it);
  box.append(line('ค่าสถานะ', [`HP ${+it.hp||0}`, +it.mp ? `MP ${+it.mp}` : null, tg ? `Toughness ${tg}${tgs ? ' (' + Math.max(0, +it.tgh||0) + ' ' + (tgs > 0 ? '+' : '-') + ' ' + Math.abs(tgs) + ' จากขนาด)' : ''}` : null, +it.ap ? `AP ${+it.ap}` : null, `Initiative ${signed(npcInit(it))}`, aa ? `All Armor ${signed(aa)}${npcSizeArmor(it) ? ' (รวมขนาด)' : ''}` : null].filter(Boolean).join(' · ') + (it.extra ? ' ' + it.extra : '')));
  const d = npcDerived(it.mods); box.append(line('ค่าพลังรอง', `Reflex ${signed(d.reflex)} · Might ${signed(d.might)} · Sight ${signed(d.sight)}`));
  if ((it.attacks||[]).length) box.append(h('div',{class:'npcblock-sec'}, h('b',{text:'⚔ การโจมตี'}), it.attacks.map(a=>h('div',{class:'npcblock-i'}, named(a)))));
  const defl = (NPC_DEFEND.find(x=>x[0]===it.defend)||[])[1];
  if (it.defend) box.append(line('ป้องกัน', defl + (it.defendNote ? ' (' + it.defendNote + ')' : '')));
  if ((it.reactions||[]).length) box.append(h('div',{class:'npcblock-sec'}, h('b',{text:'Reaction'}), it.reactions.map(a=>h('div',{class:'npcblock-i'}, named(a)))));
  if ((it.behaviors||[]).length) box.append(h('div',{class:'npcblock-sec'}, h('b',{text:'พฤติกรรมและความสามารถพิเศษ'}), it.behaviors.map(a=>h('div',{class:'npcblock-i'}, named(a)))));
  if ((it.equip||[]).length) box.append(line('ยุทโธปกรณ์', it.equip.map(e=>itemNameSplit(e.name)[0]).join(' · ')));
  const dr = it.drops||[];
  if (dr.length){ const sec = h('div',{class:'npcblock-sec npcblock-drop'}, h('b',{text:'ของที่อาจได้รับ'}));
    for (const [t, th] of NPC_DROP_T){ const rows = dr.filter(x=>x.t===t && x.name); if (!rows.length) continue;
      sec.append(h('div',{class:'npcblock-i'}, h('span',{class:'dim',text:th + ': '}), rows.map((x, i)=>[i ? ' · ' : '', x.r ? h('span',{class:'num',text:`(${x.r}) `}) : null, npcDropText(x)]))); }
    box.append(sec); }
  if (it.tpl) box.append(h('div',{class:'dim',style:'font-size:11.5px;margin-top:4px',text:'แม่แบบ: ' + it.tpl.replace(/^(fauna|humanoid):/, '') + ' จากเอกสาร Fauna, Enemy & Companion'}));
  return box; }

/* ---- บนโต๊ะ: แผงหมาก NPC (GM เห็นคนเดียว) ---- */
const NPC_TOK_OPEN = new Set(); // จำว่ากล่องไหนของหมากไหนเปิดอยู่ แผงหมากวาดใหม่ทุกครั้งที่ห้องบันทึก
function npcKeepOpen(el, key){ if (NPC_TOK_OPEN.has(key)) el.open = true; el.addEventListener('toggle', ()=>{ if (el.open) NPC_TOK_OPEN.add(key); else NPC_TOK_OPEN.delete(key); }); return el; }
function npcTokenStatSection(t, r){
  const k = npcKind(t); const sec = h('div',{class:'cp-sec npcstat-tok',dataset:{kind:k}});
  const aa = npcAllArmor(t);
  const kindSel = h('select',{class:'npckindsel',title:'ประเภทของหมากนี้ (หมากที่เพิ่มจากปุ่ม + NPC บนโต๊ะเริ่มเป็นผู้คน)',onchange:(e)=>{ t.nkind = e.target.value; Table.save(); }}, NPC_KINDS.map(([kk, th, en, ic])=>h('option',{value:kk, selected: k===kk, text:`${ic} ${th} (${en})`})));
  sec.append(h('div',{class:'row',style:'gap:6px;align-items:center;flex-wrap:wrap'}, kindSel, h('div',{class:'gives'}, t.size ? tag(`ขนาด${NPC_SIZE_TH[t.size]}`,'prop') : null, +t.ap ? tag(`AP ${t.ap}`,'stat') : null, aa ? tag(`All Armor ${signed(aa)} ทุกส่วน`,'stat') : null, t.extra ? tag(t.extra,'prop') : null)));
  if (t.speed) sec.append(h('div',{class:'dim',style:'font-size:12px;margin-top:2px',text:'ความเร็ว: ' + t.speed}));
  if ((t.attacks||[]).length) sec.append(h('div',{class:'npcstat-atk'}, h('b',{text:'⚔ การโจมตี'}), (t.attacks||[]).map(a=>h('div',{class:'npcstat-line'}, a.name ? h('b',{text:a.name + ': '}) : null, T(a.text)))));
  const defl = (NPC_DEFEND.find(x=>x[0]===t.defend)||[])[1];
  if (defl || (t.reactions||[]).length) sec.append(npcKeepOpen(h('details',{class:'npcstat-re'}, h('summary',null, h('b',{text:'🛡 ป้องกัน '}), defl || '-', t.defendNote ? ` (${t.defendNote})` : '', (t.reactions||[]).length ? ` · Reaction ${t.reactions.length}` : ''),
    (t.reactions||[]).map(a=>h('div',{class:'npcstat-line'}, h('b',{text:a.name + ': '}), T(a.text)))), t.id + ':re'));
  if ((t.behaviors||[]).length){ const bh = h('details',{class:'npcstat-beh'}, h('summary',null, h('b',{text:`พฤติกรรม ${t.behaviors.length}`}), ': ' + t.behaviors.map(b=>b.name.replace(/\s*\([^()]*\)\s*$/, '')).join(' · ')));
    for (const [i, b] of t.behaviors.entries()) bh.append(h('div',{class:'npcstat-line'}, h('b',{text:b.name + ': '}), T(b.text), ' ', h('button',{class:'small ghost npcstat-delbeh',title:'เอาพฤติกรรมนี้ออกจากหมากตัวนี้',onclick:()=>{ t.behaviors.splice(i, 1); if (!t.behaviors.length) delete t.behaviors; Table.save(); },text:'✕'})));
    sec.append(npcKeepOpen(bh, t.id + ':beh')); }
  const dr = t.drops||[];
  sec.append(h('div',{class:'dim npcstat-drop',style:'font-size:12px;margin-top:2px'}, h('b',{text:'ของดรอป: '}), dr.length ? NPC_DROP_T.map(([x, l])=>[l, dr.filter(d=>d.t===x).length]).filter(([, n])=>n).map(([l, n])=>`${l} ${n}`).join(' · ') : 'ไม่มี'));
  sec.append(h('div',{class:'row',style:'gap:6px;margin-top:4px'},
    h('button',{class:'small ghost npcstat-addbeh',title:'ใส่พฤติกรรมจากเอกสารให้หมากตัวนี้ (รายการในคลังไม่เปลี่ยน กด 💾 เก็บเข้าคลังถ้าอยากให้เปลี่ยนตาม)',onclick:()=>npcBehaviorPicker({kind:'ability', type:k, title:`ใส่พฤติกรรมให้ ${t.name}`, onPick:(b)=>{ t.behaviors = t.behaviors || []; if (t.behaviors.length >= 16){ toast('ใส่ได้ไม่เกิน 16 รายการ'); return false; } t.behaviors.push({name:b.name, text:b.text}); NPC_TOK_OPEN.add(t.id + ':beh'); Table.save(); return true; }}),text:'+ พฤติกรรม'}),
    dr.length ? h('button',{class:'small primary npcdroproll-btn',style:'margin-left:auto',title:'ทอยของดรอปตามตารางของหมากนี้ ผลลงแชตแบบ GM เห็นคนเดียว แล้วเลือกมอบให้ตัวละครบนบอร์ด',onclick:()=>{ if (t.looted && !confirm(`${t.name} ทอยของดรอปไปแล้ว ทอยอีกครั้งไหม?`)) return; npcDropModal(t, r); },text: t.looted ? '🎲 ทอยของดรอปอีกครั้ง' : '🎲 ทอยของดรอป'}) : null));
  return sec; }
