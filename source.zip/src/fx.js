/* ===== v1.21 (ผู้ใช้สั่ง 13 พ.ย. 2026): เอฟเฟกต์บนแผนที่ และป๊อปอัปเต๋าชนกัน =====
 * ชั้น #fx-layer อยู่ระดับ body (position: fixed) จึงไม่หายเมื่อโต๊ะวาดใหม่กลางแอนิเมชัน ตำแหน่งคิดจากช่องบนกริดตอนเริ่มเล่น
 * ทุกเอฟเฟกต์เป็นของประดับ ไม่มีผลต่อกติกา เครื่องที่ตั้ง prefers-reduced-motion จะเห็นแบบนิ่ง (วาบสั้น ๆ กับตัวหนังสือ) */
const FX_HUE = { fire:'#ff7a3d', plasma:'#9fe8ff', light:'#ffe9a6', electric:'#c9a6ff', wind:'#cfeee0', earth:'#c9a877', water:'#5fb6ff', frost:'#a9e4ff', nature:'#7ed67a', chaos:'#b46bff', blood:'#e0483e', ritual:'#d4a84a', steel:'#e6e1d6', qi:'#4fd1c5', stance:'#e0a53a', trick:'#9aa4b1', survival:'#a3b86c', kin:'#d4a84a', heal:'#5bb97a', necrotic:'#9a83c4', poison:'#8fbf3f', sonic:'#f2c14e' };
/* สีตามสำนักของสกิล (subcategory ในข้อมูล) */
function fxHueOfSkill(sk){
  const s = (((sk && sk.subcategory) || '') + ' ' + ((sk && sk.category) || '')).toLowerCase();
  const table = [['chaos','chaos'],['plasma','plasma'],['electric','electric'],['fire','fire'],['wind','wind'],['solid','earth'],['liquid','water'],['sylvian','nature'],['ritual','ritual'],['blood','blood'],['qi','qi'],['stance','stance'],['trick','trick'],['survival','survival'],['kins unique','kin'],['martial','steel']];
  for (const [k, v] of table) if (s.includes(k)) return v;
  return 'ritual';
}
/* สีตามประเภทความเสียหาย */
function fxHueOfDamage(type){
  const t = String(type || '').toLowerCase();
  const table = [['fire','fire'],['burn','fire'],['plasma','plasma'],['electric','electric'],['frost','frost'],['necrotic','necrotic'],['sonic','sonic'],['acid','poison'],['corrode','poison'],['poison','poison'],['light','light'],['sanity','chaos'],['heal','heal']];
  for (const [k, v] of table) if (t.includes(k)) return v;
  return 'steel';
}
const Fx = {
  calm(){ try { return !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); } catch(e){ return false; } },
  layer(){ let l = document.getElementById('fx-layer'); if (!l){ l = h('div',{id:'fx-layer','aria-hidden':'true'}); document.body.append(l); } return l; },
  /* จุดกึ่งกลางของช่อง (x,y) บนกริดของห้อง เป็นพิกัดในระบบของ body (หารขนาด UI ออกแล้ว) · คืน null ถ้าไม่ได้เปิดหน้าโต๊ะอยู่ */
  point(x, y){
    const g = document.querySelector('#v-table .gridmap'); if (!g || !g.isConnected) return null;
    const cell = g.querySelector('.cell[data-x="' + (+x) + '"][data-y="' + (+y) + '"]'); if (!cell) return null;
    const rc = cell.getBoundingClientRect(); if (!rc.width) return null; const z = uiZoom();
    return { x: (rc.left + rc.width / 2) / z, y: (rc.top + rc.height / 2) / z, s: rc.width / z };
  },
  tokenPoint(id){ const r = Table.room; const t = r && (r.tokens || []).find(k => k.id === id); return t ? this.point(t.x, t.y) : null; },
  node(cls, pt, hue, size){
    const el = h('div',{class:'fx ' + cls}); el.style.left = pt.x + 'px'; el.style.top = pt.y + 'px';
    // สีมาจากข้อความในแชตได้ จึงรับเฉพาะชื่อสีในตาราง FX_HUE (ค่าอื่นใช้สีเหล็ก) กันการยัด url() เข้ามาใน CSS
    el.style.setProperty('--fx', Object.prototype.hasOwnProperty.call(FX_HUE, hue) ? FX_HUE[hue] : FX_HUE.steel); el.style.setProperty('--s', Math.round(size || pt.s || 30) + 'px');
    this.layer().append(el); return el;
  },
  gone(el, ms){ setTimeout(()=>{ try { el.remove(); } catch(e){} }, ms); },
  anim(el, frames, opt){ try { return el.animate(frames, opt); } catch(e){ return null; } },
  /* ตัวหนังสือลอยเหนือหมาก: ความเสียหาย การฟื้นฟู ผลป้องกัน */
  float(pt, text, cls, delay){
    if (!pt || !text) return;
    setTimeout(()=>{ const el = this.node('fx-float ' + (['dmg','heal','miss','info'].includes(cls) ? cls : ''), pt); el.textContent = String(text);
      if (this.calm()){ this.gone(el, 1300); return; }
      this.anim(el, [{transform:'translate(-50%,-60%) scale(.7)',opacity:0},{transform:'translate(-50%,-130%) scale(1.15)',opacity:1,offset:.18},{transform:'translate(-50%,-190%) scale(1)',opacity:1,offset:.7},{transform:'translate(-50%,-230%) scale(1)',opacity:0}], {duration:1500,easing:'ease-out',fill:'forwards'});
      this.gone(el, 1550); }, delay || 0);
  },
  burst(pt, hue, big){
    if (!pt) return; const size = pt.s * (big ? 2.6 : 1.6);
    const ring = this.node('fx-ring', pt, hue, size);
    if (this.calm()){ this.gone(ring, 500); return; }
    this.anim(ring, [{transform:'translate(-50%,-50%) scale(.2)',opacity:.95},{transform:'translate(-50%,-50%) scale(1)',opacity:0}], {duration:520,easing:'ease-out',fill:'forwards'}); this.gone(ring, 560);
    for (let i = 0; i < 7; i++){ const a = (Math.PI * 2 * i) / 7 + Math.random() * .5; const d = size * (.45 + Math.random() * .35); const p = this.node('fx-spark', pt, hue, Math.max(4, pt.s * .14));
      this.anim(p, [{transform:'translate(-50%,-50%)',opacity:1},{transform:`translate(calc(-50% + ${Math.cos(a) * d}px), calc(-50% + ${Math.sin(a) * d}px))`,opacity:0}], {duration:480 + Math.random() * 160,easing:'cubic-bezier(.1,.7,.3,1)',fill:'forwards'}); this.gone(p, 700); }
  },
  slash(pt, hue){
    if (!pt) return; const el = this.node('fx-slash', pt, hue, pt.s * 1.9);
    if (this.calm()){ this.gone(el, 400); return; }
    this.anim(el, [{transform:'translate(-50%,-50%) rotate(-70deg) scale(.5)',opacity:0},{transform:'translate(-50%,-50%) rotate(-20deg) scale(1)',opacity:1,offset:.35},{transform:'translate(-50%,-50%) rotate(40deg) scale(1.1)',opacity:0}], {duration:380,easing:'ease-out',fill:'forwards'}); this.gone(el, 420);
  },
  /* ลูกพลังพุ่งจาก from ไป to แล้วเรียก then */
  proj(from, to, hue, then){
    if (!to){ if (then) then(); return; } if (!from || this.calm()){ if (then) then(); return; }
    const dx = to.x - from.x, dy = to.y - from.y; const dist = Math.hypot(dx, dy); if (dist < 4){ if (then) then(); return; }
    const el = this.node('fx-orb', from, hue, Math.max(10, from.s * .38)); const ms = Math.min(620, 220 + dist * .9);
    const tr = this.node('fx-trail', from, hue, dist); tr.style.transform = `translate(0,-50%) rotate(${Math.atan2(dy, dx)}rad)`;
    this.anim(tr, [{opacity:0,clipPath:'inset(0 100% 0 0)'},{opacity:.7,clipPath:'inset(0 0 0 0)',offset:.7},{opacity:0,clipPath:'inset(0 0 0 85%)'}], {duration:ms + 140,easing:'linear',fill:'forwards'}); this.gone(tr, ms + 180);
    this.anim(el, [{transform:'translate(-50%,-50%)'},{transform:`translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`}], {duration:ms,easing:'cubic-bezier(.4,0,.8,.6)',fill:'forwards'});
    setTimeout(()=>{ try { el.remove(); } catch(e){} if (then) then(); }, ms);
  },
  aura(pt, hue){
    if (!pt) return; for (let i = 0; i < 2; i++){ const el = this.node('fx-ring fx-aura', pt, hue, pt.s * 1.7);
      if (this.calm()){ this.gone(el, 500); continue; }
      this.anim(el, [{transform:'translate(-50%,-50%) scale(.55)',opacity:0},{transform:'translate(-50%,-50%) scale(.9)',opacity:.95,offset:.3},{transform:'translate(-50%,-50%) scale(1.35)',opacity:0}], {duration:900,delay:i * 260,easing:'ease-out',fill:'both'}); this.gone(el, 1300); }
  },
  heal(pt){
    if (!pt) return; this.aura(pt, 'heal'); if (this.calm()) return;
    for (let i = 0; i < 4; i++){ const el = this.node('fx-plus', {x: pt.x + (Math.random() - .5) * pt.s * .9, y: pt.y, s: pt.s}, 'heal', pt.s * .42); el.textContent = '+';
      this.anim(el, [{transform:'translate(-50%,-20%)',opacity:0},{transform:'translate(-50%,-90%)',opacity:1,offset:.3},{transform:'translate(-50%,-220%)',opacity:0}], {duration:1000,delay:i * 130,easing:'ease-out',fill:'both'}); this.gone(el, 1600); }
  },
  shield(pt, hue){
    if (!pt) return; const el = this.node('fx-shield', pt, hue || 'qi', pt.s * 1.5); el.textContent = '🛡';
    if (this.calm()){ this.gone(el, 600); return; }
    this.anim(el, [{transform:'translate(-50%,-50%) scale(.4)',opacity:0},{transform:'translate(-50%,-50%) scale(1.15)',opacity:1,offset:.3},{transform:'translate(-50%,-50%) scale(1)',opacity:1,offset:.7},{transform:'translate(-50%,-50%) scale(1.2)',opacity:0}], {duration:800,easing:'ease-out',fill:'forwards'}); this.gone(el, 840);
  },
  /* พื้นที่สี่เหลี่ยม: cells = จำนวนช่องจากจุดกลางออกไปแต่ละด้าน */
  zone(pt, cells, hue){
    if (!pt) return; const el = this.node('fx-zone', pt, hue, pt.s * (cells * 2 + 1) + cells * 2);
    if (this.calm()){ this.gone(el, 900); return; }
    this.anim(el, [{transform:'translate(-50%,-50%) scale(.6)',opacity:0},{transform:'translate(-50%,-50%) scale(1)',opacity:.85,offset:.2},{transform:'translate(-50%,-50%) scale(1)',opacity:.55,offset:.7},{transform:'translate(-50%,-50%) scale(1.04)',opacity:0}], {duration:1300,easing:'ease-out',fill:'forwards'}); this.gone(el, 1350);
  },
  /* spec = {k: 'proj'|'slash'|'burst'|'aura'|'heal'|'shield'|'zone'|'float', from:{x,y}, to:{x,y}, hue, cells, text, cls, floats:[{x,y,text,cls}]} พิกัดเป็นช่องบนกริด */
  play(spec){
    if (!spec || typeof spec !== 'object') return;
    const cellPt = (p)=> (p && isFinite(+p.x) && isFinite(+p.y)) ? this.point(+p.x, +p.y) : null;
    const from = cellPt(spec.from), to = cellPt(spec.to) || from; const hue = spec.hue || 'steel';
    if (!to) return;
    const floats = ()=>{ for (const [i, f] of (Array.isArray(spec.floats) ? spec.floats : []).slice(0, 12).entries()) this.float(cellPt(f), String(f.text || '').slice(0, 24), f.cls, i * 90); if (spec.text) this.float(to, String(spec.text).slice(0, 24), spec.cls); };
    switch (spec.k){
      case 'slash': this.slash(to, hue); this.burst(to, hue); floats(); break;
      case 'burst': this.burst(to, hue, true); floats(); break;
      case 'aura': this.aura(to, hue); floats(); break;
      case 'heal': this.heal(to); floats(); break;
      case 'shield': this.shield(to, hue); floats(); break;
      case 'zone': this.proj(from, to, hue, ()=>{ this.zone(to, Math.max(0, Math.min(8, +spec.cells || 1)), hue); this.burst(to, hue, true); floats(); }); break;
      case 'float': floats(); break;
      default: this.proj(from, to, hue, ()=>{ this.burst(to, hue); floats(); });
    }
  },
};

/* ---- ป๊อปอัปเต๋าชนกัน: เต๋าของผู้โจมตีอยู่ซ้าย ของฝ่ายรับอยู่ขวา พุ่งเข้าชนกันแล้วขึ้นผล (ข้อมูลมาจากข้อความ kind 'clash' ในแชตของห้อง) ---- */
const CLASH_SHOW_MS = 5600;
function clashDice(roll, side){
  const dice = (roll && Array.isArray(roll.dice)) ? roll.dice.slice(0, 6) : []; const kept = (roll && Array.isArray(roll.keptIdx)) ? roll.keptIdx : [];
  return dice.map((v, i)=>h('div',{class:'bigdie cl-die ' + side + (kept.includes(i) ? '' : ' drop'),dataset:{v:String(v)}}, h('span',{text:'?'})));
}
function clashBox(m){
  const def = m.def || {}; const res = m.res || {}; const none = !def.roll;
  const aDice = clashDice(m.atkRoll, 'atk'); const dDice = none ? [] : clashDice(def.roll, 'def');
  const left = h('div',{class:'cl-side cl-atk'}, h('div',{class:'cl-name',text:(m.a && m.a.name) || 'ผู้โจมตี'}), h('div',{class:'dice-row'}, aDice), h('div',{class:'cl-sum',text:''}));
  const right = h('div',{class:'cl-side cl-def'}, h('div',{class:'cl-name',text:(m.t && m.t.name) || 'ฝ่ายรับ'}), none ? h('div',{class:'cl-none',text: def.kind === 'skill' ? '✨' : '✋'}) : h('div',{class:'dice-row'}, dDice), h('div',{class:'cl-sum',text:''}));
  const spark = h('div',{class:'cl-spark',text:'✦'});
  const verdict = h('div',{class:'cl-verdict',text:''}); const lines = h('div',{class:'cl-lines'});
  const box = h('div',{class:'dicebox clashbox'}, h('div',{class:'dice-who'}, h('b',{text:'⚔ ' + ((m.w && m.w.name) || 'โจมตี')}), m.gmOnly ? [' ', h('span',{class:'gm',text:'ลับ'})] : null), h('div',{class:'cl-arena'}, left, spark, right), verdict, lines);
  const calm = Fx.calm();
  const settle = (els)=>{ for (const el of els){ el.firstChild.textContent = el.dataset.v; el.classList.remove('tumble'); } };
  const fill = ()=>{
    left.querySelector('.cl-sum').textContent = m.atkRoll ? `${(m.atkRoll.kept || []).join('+')} = ${m.atkRoll.sum}${m.cv != null && m.cv !== m.atkRoll.sum ? ' → CV ' + m.cv : ''}${m.part ? ' · ' + partLabel(m.part) : ''}` : '';
    right.querySelector('.cl-sum').textContent = none ? (def.text || 'ไม่ป้องกัน') : `${def.label || ''} ${(def.roll.kept || []).join('+')}${def.mod ? ' ' + signed(def.mod) : ''} = ${def.total}`;
  };
  const finish = ()=>{
    box.classList.add(m.hit ? 'hit' : 'blocked'); if (m.perfect && m.hit) box.classList.add('crit'); if (def.perfect) box.classList.add('pdef');
    verdict.textContent = m.headline || (m.hit ? 'โดน' : 'กันได้'); verdict.className = 'cl-verdict show ' + (m.hit ? 'res-fail' : (def.perfect ? 'res-crit' : 'res-full'));
    for (const ln of (Array.isArray(res.lines) ? res.lines : []).slice(0, 7)) lines.append(h('div',{text:String(ln)})); lines.classList.add('show');
  };
  for (const el of aDice) el.classList.add('tumble'); for (const el of dDice) el.classList.add('tumble');
  if (calm){ settle(aDice); settle(dDice); fill(); finish(); return box; }
  let tick = 0; const spin = setInterval(()=>{ tick++; for (const el of [...aDice, ...dDice]) if (el.classList.contains('tumble')) el.firstChild.textContent = 1 + Math.floor(Math.random() * 6); if (tick === 6) settle(aDice); if (tick >= 12){ settle(dDice); clearInterval(spin); fill(); } }, 70);
  setTimeout(()=>{ box.classList.add('charge'); }, 1150);
  setTimeout(()=>{ box.classList.add('impact'); }, 1480);
  setTimeout(finish, 1750);
  return box;
}
