/* ---------- v1.23 ระบบตั้งชื่อจากภาษาแห่งคีรันนา (Non สั่ง 13 พ.ย. 2026) ----------
   "ทำระบบตั้งชื่อตัวละครจากภาษาในคีรันนาพร้อมความหมาย (เมื่อนำคำมาประกอบกันจะได้ความหมายของชื่อใหม่)"
   ข้อมูล: DATA.names จาก tools/parse_names.py (คลังคำใน ภาษาแห่งคีรันนา.md) และ tools/names_ways.py (วิถีตั้งชื่อของแต่ละภาษา)
   แม่แบบ name ประกอบรูปคำ แม่แบบ mean ประกอบความหมาย ภาษาแม่แบบอธิบายไว้หัวไฟล์ names_ways.py
   ผลที่เก็บในตัวละคร: c.name และ c.nameMeaning = {text, name, reading, lang, langTh, way, wayTh, parts:[{k,w,r,m}], state, at}
   คำอ่านภาษาไทยของชื่อประกอบเป็นคำอ่านโดยประมาณ ผู้เล่นแก้ได้ก่อนกดใช้ */
const NM = DATA.names || null;
const NM_VOW = 'aeiouyáéíóúýàèìòùâêîôûäëïöüāēīōūæœøåÿǫ';
const nmIsV = ch => !!ch && NM_VOW.includes(ch.toLowerCase());
const nmFold = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const nmCap = s => String(s).replace(/^(['’]?)(\p{L})/u, (m, a, b) => a + b.toUpperCase());
const nmLow = s => String(s).replace(/^(['’]?)(\p{L})/u, (m, a, b) => a + b.toLowerCase());
const nmRand = a => a[Math.floor(Math.random() * a.length)];

function nmLang(id){ return (NM && NM.langs.find(l => l.id === id)) || null; }
function nmWay(L, id){ return L ? (L.ways.find(w => w.id === id) || L.ways[0]) : null; }
/* ภาษาตั้งต้นตามวงศา · ริมเมนที่เลือกภาษาบ้านเกิดซีเลสเทียได้ซีเลสเทีย */
function nmDefaultLang(c){
  if (!NM) return null;
  const kin = c && c.kin; const byPick = kin && NM.kinByLangPick[kin];
  if (byPick && c.langPick && byPick[c.langPick]) return byPick[c.langPick];
  return (kin && NM.kin[kin]) || 'althalani';
}
function nmKnownLangs(c){ try { return new Set(charLanguages(c).map(o => o.id).filter(Boolean)); } catch (e){ return new Set(); } }

/* ---- คลังคำของภาษา (รวมคำของภาษาฐาน เช่น จันทร์โลหิตใช้รากศัพท์อัลธาลานีได้ทั้งหมด) ---- */
const _nmLex = {};
function nmLex(lid){
  if (_nmLex[lid]) return _nmLex[lid];
  const L = nmLang(lid); const out = [];
  const add = (src) => { const S = nmLang(src); const pre = src !== lid ? (S ? S.th.split(' (')[0] : src) + ' · ' : '';
    (NM.words[src] || []).forEach((r, i) => out.push({ id: src + ':' + i, w: r[0], r: r[1] || '', m: r[2], p: r[3] || 'n', c: pre + ((NM.cats[src] || [])[r[4]] || ''), f: r[5] || 0, src })); };
  add(lid); if (L && L.base) add(L.base);
  return (_nmLex[lid] = out);
}
function nmEntry(lid, v){ if (!v || !v.w) return null; const lex = nmLex(lid); const lw = v.w.toLowerCase();
  return lex.find(e => e.id === v.id && e.w === v.w) || lex.find(e => e.w.toLowerCase() === lw && e.m.includes(v.m)) || lex.find(e => e.w.toLowerCase() === lw) || null; }
function nmSearch(lid, q, cat, prefer){
  const tq = String(q || '').trim(), fq = nmFold(tq); const out = [];
  for (const e of nmLex(lid)){
    if (cat && e.c !== cat) continue;
    let sc = 0;
    if (!tq) sc = 1;
    else {
      const fw = nmFold(e.w);
      if (fw === fq) sc = 100; else if (fw.startsWith(fq)) sc = 60; else if (fq.length >= 2 && fw.includes(fq)) sc = 30;
      const core = e.m.map(nmCore);   // ค้น "รัก" เจอ "ความรัก" ก่อน "รักษา"
      if (e.m.includes(tq) || core.includes(tq)) sc = Math.max(sc, 90); else if (core.some(m => m.startsWith(tq))) sc = Math.max(sc, 50); else if (e.m.some(m => m.includes(tq))) sc = Math.max(sc, 20);
    }
    if (!sc) continue;
    if (prefer && [...e.p].some(p => prefer.includes(p))) sc += 5;
    if (e.f === 2) sc -= 1;
    out.push([sc, e]);
  }
  out.sort((a, b) => b[0] - a[0] || a[1].w.localeCompare(b[1].w));
  return out.map(x => x[1]);
}
const nmCore = m => m.replace(/^(การ|ความ)(?=.)/, '');
function nmPickSense(e, q){ const tq = String(q || '').trim(); let i = tq ? e.m.findIndex(m => m === tq || nmCore(m) === tq) : -1; if (i < 0 && tq) i = e.m.findIndex(m => m.includes(tq)); return Math.max(0, i); }
function nmSetWord(st, k, e, si){ si = si || 0; st.v[k] = { id: e.id, w: e.w, r: e.r, m: e.m[si], p: e.p[si] || e.p[0] || 'n', f: e.f, si, clip: false }; }

/* ---- แม่แบบ: {K} {K.r} {K.g} {K:mod} {+lit|อ่าน} {+a?|อ่าน} [ก|ข] ---- */
const _nmTpl = {};
function nmTpl(t){
  if (_nmTpl[t]) return _nmTpl[t];
  let i = 0;
  const seq = (stop) => { const out = []; let buf = ''; const flush = () => { if (buf){ out.push({ t: 'lit', s: buf }); buf = ''; } };
    while (i < t.length){
      const ch = t[i];
      if (stop.includes(ch)) break;
      if (ch === '['){ flush(); i++; const a = seq('|]'); let b = null; if (t[i] === '|'){ i++; b = seq(']'); } i++; out.push({ t: 'opt', a, b }); continue; }
      if (ch === '{'){ flush(); const j = t.indexOf('}', i); const body = t.slice(i + 1, j); i = j + 1;
        if (body[0] === '+'){ const [lit, rd] = body.slice(1).split('|'); const cond = lit.endsWith('?'); out.push({ t: 'suf', s: cond ? lit.slice(0, -1) : lit, r: rd || '', cond }); }
        else { const m = body.match(/^([A-Z])(?:\.([a-z]))?(?::([a-z]+))?$/); out.push({ t: 'slot', k: m[1], prop: m[2] || '', mod: m[3] || '' }); }
        continue; }
      buf += ch; i++;
    }
    flush(); return out; };
  return (_nmTpl[t] = seq(''));
}
function nmSlotNodes(nodes, acc){ acc = acc || []; for (const n of nodes){ if (n.t === 'slot') acc.push(n); else if (n.t === 'opt'){ nmSlotNodes(n.a, acc); if (n.b) nmSlotNodes(n.b, acc); } } return acc; }
const nmDef = (way, k) => way.slots.find(s => s.k === k);
function nmItem(d, v){ return v && v.i != null && v.i >= 0 ? (NM.lists[d.list] || [])[v.i] || null : null; }
function nmHas(way, st, k){ const d = nmDef(way, k), v = st.v[k]; if (!d || !v) return false;
  if (d.t === 'word') return !!v.w; if (d.t === 'fixed') return !!nmItem(d, v); return !!String(v.text || '').trim(); }

/* ---- เสียงและรูปคำ ---- */
function nmClip(w){ const m = String(w).match(/^[^aeiouyáéíóúâêîôûäëïöü]*[aeiouyáéíóúâêîôûäëïöü]+[^aeiouyáéíóúâêîôûäëïöü]?/i); return m ? m[0] : w; }
function nmClipR(w, r){ const c = nmClip(w); if (!r || c === w) return r; let t = r.slice(0, Math.max(1, Math.round(r.length * c.length / w.length))); if (/r$/i.test(c) && /ร$/.test(t)) t += '์'; return t; }
/* โนเม'เอลารา: kh→k th→t ph→p · h ต้นคำเป็นเสียงกัก (') · สระยาวเป็นสระสั้น (หัวข้อการเปลี่ยนแปลงด้านเสียงในไฟล์ภาษา) */
function nmNome(s, r){
  let t = s, rr = r || '';
  if (/kh/i.test(t)){ t = t.replace(/kh/g, 'k').replace(/K[hH]/g, 'K'); rr = rr.replace('ค', 'ก'); }
  if (/th/i.test(t)){ t = t.replace(/th/g, 't').replace(/T[hH]/g, 'T'); rr = rr.replace(/ธ/g, 'ต'); }
  if (/ph/i.test(t)){ t = t.replace(/ph/g, 'p').replace(/P[hH]/g, 'P'); rr = rr.replace('พ', 'ป'); }
  if (/^h[aeiouyáéíóúāēīōū]/i.test(t)){ t = "'" + t.slice(1); rr = rr.replace(/^ฮ/, 'อ'); }
  t = t.replace(/[āēīōū]/g, ch => ({ 'ā': 'a', 'ē': 'e', 'ī': 'i', 'ō': 'o', 'ū': 'u' })[ch]);
  return [t, rr];
}
/* อัซ-ซิลลินาร์: al- กลืนเสียงกับพยัญชนะต้นบางตัว (an-Nuhur, az-Zulmah) */
function nmArticle(w){
  const TH = { sh: 'อัช', th: 'อัษ', dh: 'อัซ', t: 'อัต', d: 'อัด', r: 'อัร', z: 'อัซ', s: 'อัส', l: 'อัล', n: 'อัน' };
  const lw = String(w).toLowerCase(); const dg = ['sh', 'th', 'dh'].find(x => lw.startsWith(x));
  if (dg) return ['a' + dg, TH[dg]];
  const b = nmFold(lw[0]); if ('tdrzsln'.includes(b)) return ['a' + lw[0], TH[b]];
  return ['al', 'อัล'];
}
/* นอร์ทโบราณ: รูปแสดงความเป็นเจ้าของก่อน -son/-dóttir (Björn → Björns-son · Úlfr → Úlfs-son) */
function nmGen(w){ const V = /[aeiouyáéíóúýæöøǫ]$/i; let t = String(w); if (/r$/i.test(t) && !V.test(t.slice(0, -1))) t = t.slice(0, -1); if (V.test(t) || /s$/i.test(t)) return t; return t + 's'; }
/* คำอ่านไทย: พยางค์ที่ขึ้นต้นด้วยสระ (อัน อิล เอล) ต่อเข้ากับตัวสะกดของคำหน้า · ตัดสระท้ายเมื่อรูปคำตัดสระทิ้ง */
function nmThDropV(r){
  if (!r) return r; const t = r.replace(/[่้๊๋]$/, ''); const last = t.slice(-1);
  if ('ะาิีึืุูำ'.includes(last)) return t.slice(0, -1);
  const m = t.match(/[เแโใไ]([ก-ฮ]{1,2})$/); if (m) return t.slice(0, t.length - m[0].length) + m[1];
  return r;
}
function nmThJoin(a, b, force){
  if (!a) return b || ''; if (!b) return a;
  const endC = /[ก-ฮ]์?$/.test(a) && (force || !/[เแโใไ][ก-ฮ]$/.test(a));
  if (endC && /^อ[ะาิีึืุูั็ำ]/.test(b)) return a.replace(/์$/, '') + b.slice(1);
  if (endC && /^[เแโใไ]อ/.test(b)){ const m = a.match(/([ก-ฮ])์?$/); return a.slice(0, a.length - m[0].length) + b[0] + m[1] + b.slice(2); }
  return a + b;
}

/* ---- ประกอบชื่อ ---- */
function nmNameSegs(L, way, st, nodes, sink, miss){
  for (const n of nodes){
    if (n.t === 'lit') sink.push({ s: n.s, r: n.s, kind: 'lit' });
    else if (n.t === 'suf') sink.push({ s: n.s, r: n.r, kind: 'suf', cond: n.cond });
    else if (n.t === 'opt'){ if (nmSlotNodes(n.a).every(x => nmHas(way, st, x.k))) nmNameSegs(L, way, st, n.a, sink, miss); else if (n.b) nmNameSegs(L, way, st, n.b, sink, miss); }
    else {
      const d = nmDef(way, n.k), v = st.v[n.k];
      if (!nmHas(way, st, n.k)){ if (d && !d.opt) miss.push(n.k); continue; }
      if (d.t === 'word'){
        let s = v.clip ? nmClip(v.w) : v.w, r = v.clip ? nmClipR(v.w, v.r) : (v.r || '');
        if (L.shift === 'nome' && st.shift !== false) [s, r] = nmNome(s, r);
        if (n.mod === 'al'){ const [a, ar] = nmArticle(s); sink.push({ s: a + '-', r: ar + '-', kind: 'art' }); }
        if (n.mod === 'gen') s = nmGen(s);
        sink.push({ s, r, kind: n.mod === 'low' ? 'low' : 'word' });
      } else if (d.t === 'fixed'){
        const it = nmItem(d, v);
        if (it.sep) sink.push({ s: it.sep, r: it.sep, kind: 'lit' });
        sink.push({ s: it.w, r: it.r || '', kind: n.mod === 'low' ? 'low' : 'fix', vjoin: it.vjoin, vjoinR: it.vjoinR });
      } else { const t = String(v.text).trim(); sink.push({ s: t, r: t, kind: 'free' }); }
    }
  }
}
function nmJoin(L, segs){
  let out = '', rd = '';
  for (const g of segs){
    let dropped = false;
    let s = g.s, r = g.r || '';
    if (!s) continue;
    const prev = out.slice(-1);
    const initial = !out || prev === ' ' || (prev === '-' && L.hyphenCap);
    if (g.kind === 'word' || g.kind === 'fix') s = initial ? nmCap(s) : nmLow(s);
    else if (g.kind === 'free') s = initial ? nmCap(s) : s;
    else if (g.kind === 'suf') s = initial ? nmCap(s) : nmLow(s);   // {+Kai|ไค} ต้นชื่อขึ้นตัวใหญ่
    else if (g.kind !== 'lit') s = nmLow(s);
    const glued = out && !/[\s'’-]$/.test(out) && !/^[\s'’-]/.test(s);
    if (glued){
      const lv = nmIsV(prev), rv = nmIsV(s[0]);
      if (g.kind === 'suf' && g.cond){ if (lv) continue; }                 // {+a?} เติมเมื่อคำหน้าลงท้ายด้วยพยัญชนะ (sir → Kasira)
      else if (g.vjoin && lv){ s = g.vjoin + s; r = (g.vjoinR || '') + r.replace(/^อ(?=[ะาิีึืุูั็ำ])/, ''); }   // thae + is → Thaelis
      else if ((g.kind === 'suf' || g.kind === 'fix') && lv && rv && out.split(/[\s'’-]/).pop().length > 1){ out = out.slice(0, -1); rd = nmThDropV(rd); dropped = true; }   // Sola + an → Solan · Thraza + il → Thrazil
      else if (lv && rv && nmFold(prev) === nmFold(s[0])) s = s.slice(1);   // สระเดียวกันที่รอยต่อคำ เหลือตัวเดียว
    }
    out += s; rd = /[\s-]$/.test(rd) || !rd ? rd + r : nmThJoin(rd, r, dropped);
  }
  // เสียงกักซ้อน (Lhas + ' + 'at จาก hath) เหลือตัวเดียว
  return { name: out.replace(/['’]{2,}/g, "'").replace(/\s+/g, ' ').trim(), reading: rd.replace(/['’]{2,}/g, "'").replace(/\s+/g, ' ').trim() };
}

/* ---- ประกอบความหมาย ---- */
function nmNoun(m, p){ if (/^(การ|ความ|ผู้|นัก)/.test(m)) return m; if (p === 'v') return 'การ' + m; if (p === 'a') return 'ความ' + m; return m; }
const NM_FRAMES = [['auto', 'อัตโนมัติ'], ['ผู้', 'ผู้…'], ['ผู้แห่ง', 'ผู้แห่ง…'], ['ผู้มี', 'ผู้มี…'], ['ผู้เป็นดั่ง', 'ผู้เป็นดั่ง…']];
function nmWho(m, p, fr){
  const bare = m.replace(/^การ/, '');
  if (fr === 'ผู้') return 'ผู้' + bare;
  if (fr === 'ผู้แห่ง' || fr === 'ผู้มี' || fr === 'ผู้เป็นดั่ง') return fr + nmNoun(m, p);
  if (/^(ผู้|นัก)/.test(m)) return m;
  if (/^การ/.test(m)) return 'ผู้' + bare;
  if (/^ความ/.test(m)) return 'ผู้มี' + m;
  if (p === 'v' || p === 'a') return 'ผู้' + m;
  return 'ผู้แห่ง' + m;
}
function nmMean(way, st, tpl){
  const val = (n) => {
    const d = nmDef(way, n.k), v = st.v[n.k]; if (!d || !nmHas(way, st, n.k)) return '';
    if (n.prop === 'r'){ if (d.t === 'word') return v.r || v.w; if (d.t === 'fixed') return (nmItem(d, v) || {}).r || ''; return nmCap(String(v.text).trim()); }
    if (n.prop === 'g'){ const it = nmItem(d, v); return it && it.g ? render(nmTpl(it.g)) : ''; }
    if (d.t === 'word'){
      if (v.f === 2) return '';   // ชื่อคนในตัวอย่างของไฟล์ลอร์ ไม่มีความหมายให้ประกอบ
      const m = v.m, p = v.p || 'n';
      if (n.mod === 'n') return nmNoun(m, p);
      if (n.mod === 'who') return nmWho(m, p, st.frame[n.k]);
      if (n.mod === 'doer') return 'ผู้' + m.replace(/^การ/, '');
      if (n.mod === 'mod') return (p === 'a' || p === 'v') ? m : 'แห่ง' + nmNoun(m, p);
      return m;
    }
    if (d.t === 'fixed'){ const it = nmItem(d, v); return it ? (it.g || it.m) : ''; }
    return nmCap(String(v.text).trim());   // ชื่อตัวที่พิมพ์เอง ขึ้นตัวใหญ่เหมือนในชื่อ
  };
  const render = (nodes) => nodes.map(n => n.t === 'lit' ? n.s : n.t === 'suf' ? '' : n.t === 'slot' ? val(n)
    : (nmSlotNodes(n.a).every(x => nmHas(way, st, x.k) && val(x) !== '') ? render(n.a) : (n.b ? render(n.b) : ''))).join('');
  return render(nmTpl(tpl)).replace(/\s+/g, ' ').replace(/\(\s*\)/g, '').trim();
}
function nmWhoKeys(way, st){ const t = (st.flip && way.flip) ? way.flip : way.mean; return nmSlotNodes(nmTpl(t)).filter(n => n.mod === 'who').map(n => n.k); }
function nmParts(way, st){
  return way.slots.filter(d => nmHas(way, st, d.k)).map(d => { const v = st.v[d.k];
    if (d.t === 'word') return { k: d.k, w: v.clip ? nmClip(v.w) : v.w, r: v.clip ? nmClipR(v.w, v.r) : (v.r || ''), m: v.f === 2 ? 'ชื่อในตัวอย่าง' : v.m };
    if (d.t === 'fixed'){ const it = nmItem(d, v); return { k: d.k, w: it.w, r: it.r || '', m: it.m }; }
    return { k: d.k, w: String(v.text).trim(), r: '', m: 'ชื่อตัวที่ตั้งเอง' }; });
}
function nmCompose(st){
  const L = nmLang(st.lang), way = nmWay(L, st.way);
  const segs = [], miss = [];
  nmNameSegs(L, way, st, nmTpl(way.name), segs, miss);
  const nm = nmJoin(L, segs);
  const tpl = (st.flip && way.flip) ? way.flip : way.mean;
  return { L, way, name: nm.name, reading: nm.reading, meaning: miss.length ? '' : nmMean(way, st, tpl), parts: nmParts(way, st), missing: miss };
}

/* ---- สถานะ สุ่ม และบันทึก ---- */
function nmRandomWord(lid, d){ const lex = nmLex(lid).filter(e => e.f !== 2); const pref = d && d.prefer ? lex.filter(e => [...e.p].some(p => d.prefer.includes(p))) : []; return nmRand(pref.length ? pref : lex); }
function nmRandomSlot(st, way, d, force){
  if (d.opt && !force && Math.random() < 0.6){ delete st.v[d.k]; return; }
  if (d.t === 'word'){ const e = nmRandomWord(st.lang, d); nmSetWord(st, d.k, e, Math.floor(Math.random() * e.m.length)); }
  else if (d.t === 'fixed') st.v[d.k] = { i: Math.floor(Math.random() * (NM.lists[d.list] || [0]).length) };
  else st.v[d.k] = { text: nmCap(nmRandomWord(st.lang, null).w) };
}
function nmRandomAll(st){ const way = nmWay(nmLang(st.lang), st.way); st.v = {}; st.frame = {}; st.flip = false; st.edit = null; for (const d of way.slots) nmRandomSlot(st, way, d, false); }
function nmSwitchWay(st, id){
  const L = nmLang(st.lang), old = nmWay(L, st.way), way = nmWay(L, id); const keep = {};
  for (const d of way.slots){ const od = nmDef(old, d.k); if (od && od.t === d.t && od.list === d.list && st.v[d.k]) keep[d.k] = st.v[d.k]; }
  st.way = way.id; st.v = keep; st.flip = false; st.edit = null; st.open = null;
  for (const d of way.slots) if (!d.opt && !nmHas(way, st, d.k)) nmRandomSlot(st, way, d, true);
}
function nmStateSave(st){
  // ไม่มีค่า undefined ในก้อนที่บันทึก (Firestore ไม่รับ undefined)
  const v = {}; for (const [k, x] of Object.entries(st.v)) v[k] = x.w ? { w: x.w, r: x.r || '', m: x.m || '', p: x.p || 'n', f: x.f || 0, clip: !!x.clip } : x.i != null ? { i: x.i } : { text: String(x.text || '') };
  return { lang: st.lang, way: st.way, flip: !!st.flip, shift: st.shift !== false, frame: Object.assign({}, st.frame), v };
}
function nmInitState(c){
  const prev = c && c.nameMeaning && c.nameMeaning.state;
  if (prev && nmLang(prev.lang)){
    const st = { lang: prev.lang, way: nmWay(nmLang(prev.lang), prev.way).id, v: {}, frame: Object.assign({}, prev.frame), flip: !!prev.flip, shift: prev.shift !== false, open: null, q: {}, cat: {}, edit: null };
    for (const [k, x] of Object.entries(prev.v || {})){ if (x.w){ const e = nmEntry(st.lang, x); st.v[k] = Object.assign({}, x, e ? { id: e.id, r: e.r || x.r || '' } : {}); } else st.v[k] = Object.assign({}, x); }
    return st;
  }
  const st = { lang: nmDefaultLang(c), way: null, v: {}, frame: {}, flip: false, shift: true, open: null, q: {}, cat: {}, edit: null };
  st.way = nmLang(st.lang).ways[0].id; nmRandomAll(st);
  return st;
}
function nmResult(st, r){
  return { name: r.name, meaning: { text: String(st.edit.m || '').trim(), name: r.name, reading: String(st.edit.r || '').trim(), lang: st.lang, langTh: r.L.th, way: r.way.id, wayTh: r.way.th,
    parts: r.parts, state: nmStateSave(st), at: Date.now() } };
}

/* ---- หน้าต่างตั้งชื่อ ---- */
function openNameBuilder(c, onPick){
  if (!NM) return;
  const st = nmInitState(c);
  const root = h('div', { class: 'nmb' });
  const draw = () => { const box = root.closest('.box'); const y = box ? box.scrollTop : 0; clear(root); nmView(root, st, c, draw, (res) => { modal(null); onPick(res); }); if (box) box.scrollTop = y; };
  draw(); modal(root);
  const box = root.closest('.box'); if (box) box.classList.add('wide');
}
function nmView(root, st, c, draw, pick){
  const L = nmLang(st.lang), way = nmWay(L, st.way); st.way = way.id;
  const known = nmKnownLangs(c), def = nmDefaultLang(c);
  root.append(h('h3', { text: 'ตั้งชื่อจากภาษาแห่งคีรันนา' }),
    h('div', { class: 'nm-sub', text: 'เลือกรากศัพท์ตามวิถีตั้งชื่อของแต่ละภาษา ความหมายของชื่อประกอบจากความหมายของคำที่เลือก คลังคำมาจากไฟล์ภาษาแห่งคีรันนา' }));
  const sel = h('select', { class: 'nm-lang', onchange: (e) => { st.lang = e.target.value; st.way = nmLang(st.lang).ways[0].id; st.open = null; nmRandomAll(st); draw(); } },
    NM.langs.map(l => h('option', { value: l.id, selected: l.id === st.lang }, l.th + (known.has(l.game) ? ' ✓' : '') + (l.id === def ? ' · ตามวงศา' : ''))));
  root.append(h('div', { class: 'nm-top' }, h('label', { text: 'ภาษา' }), sel, h('span', { class: 'dim nm-key', text: '✓ = ภาษาที่ตัวละครพูดได้' })));
  root.append(h('div', { class: 'nm-about' }, L.about, L.draft ? h('div', { class: 'nm-draft', text: L.draft }) : null));
  root.append(h('div', { class: 'nm-ways' }, L.ways.map(w => h('button', { class: 'small nm-way' + (w.id === way.id ? ' sel' : ''), onclick: () => { nmSwitchWay(st, w.id); draw(); }, text: w.th }))));
  root.append(h('div', { class: 'nm-wnote' }, way.note, h('div', { class: 'nm-ex' }, h('b', { text: 'ตัวอย่างในไฟล์ลอร์: ' }), way.ex)));
  const out = h('div', { class: 'nm-out' });
  const drawOut = () => nmOutView(out, st, draw, pick);
  const whoKeys = nmWhoKeys(way, st);
  root.append(h('div', { class: 'nm-slots' }, way.slots.map(d => nmSlotView(st, L, way, d, whoKeys.includes(d.k), draw, drawOut))));
  root.append(out); drawOut();
}
function nmSlotView(st, L, way, d, who, draw, drawOut){
  const v = st.v[d.k], has = nmHas(way, st, d.k);
  const box = h('div', { class: 'nm-slot', dataset: { k: d.k } }, h('div', { class: 'nm-shead' }, h('span', { class: 'nm-lab', text: d.label }), d.opt ? h('span', { class: 'tag', text: 'ไม่บังคับ' }) : null));
  const dice = h('button', { class: 'small ghost nm-dice', title: 'สุ่มช่องนี้', onclick: () => { nmRandomSlot(st, way, d, true); draw(); }, text: '🎲' });
  if (d.t === 'word'){
    const e = has ? nmEntry(st.lang, v) : null;
    const row = h('div', { class: 'nm-val' });
    if (has){
      row.append(h('span', { class: 'nm-word' }, h('b', { text: v.clip ? nmClip(v.w) : v.w }), v.r ? h('span', { class: 'dim', text: ' ' + (v.clip ? nmClipR(v.w, v.r) : v.r) }) : null, e ? h('span', { class: 'nm-cat', text: ' · ' + e.c }) : null));
      if (v.f === 2) row.append(h('span', { class: 'nm-sense1', text: 'ชื่อในตัวอย่างของไฟล์ลอร์' }));
      else if (e && e.m.length > 1) row.append(h('span', { class: 'nm-senses' }, e.m.map((m, i) => h('button', { class: 'small nm-sense' + (m === v.m ? ' sel' : ''), title: 'ใช้ความหมายนี้', onclick: () => { v.m = m; v.p = e.p[i] || e.p[0]; v.si = i; draw(); }, text: m }))));
      else row.append(h('span', { class: 'nm-sense1', text: v.m }));
    } else row.append(h('span', { class: 'dim', text: d.opt ? 'ไม่ใส่' : 'ยังไม่ได้เลือกคำ' }));
    row.append(h('span', { class: 'nm-acts' }, dice,
      h('button', { class: 'small ghost nm-find' + (st.open === d.k ? ' sel' : ''), onclick: () => { st.open = st.open === d.k ? null : d.k; draw(); }, text: st.open === d.k ? 'ปิดคลังคำ' : 'ค้นคลังคำ' }),
      has && d.opt ? h('button', { class: 'small ghost', title: 'เอาคำออก', onclick: () => { delete st.v[d.k]; draw(); }, text: '✕' }) : null));
    box.append(row);
    if (has && st.lang === 'gromdul' && nmClip(v.w) !== v.w) box.append(h('label', { class: 'nm-clip' }, h('input', { type: 'checkbox', checked: !!v.clip, onchange: (ev) => { v.clip = ev.target.checked; draw(); } }), ` ตัดเหลือพยางค์แรก (${v.w} → ${nmClip(v.w)})`));
    if (has && who && v.f !== 2) box.append(h('div', { class: 'nm-frames' }, h('span', { class: 'dim', text: 'กรอบความหมาย ' }), NM_FRAMES.map(([id, lab]) => h('button', { class: 'small nm-fr' + ((st.frame[d.k] || 'auto') === id ? ' sel' : ''), onclick: () => { st.frame[d.k] = id; draw(); }, text: lab }))));
    if (st.open === d.k) box.append(nmSearchView(st, d, draw));
  } else if (d.t === 'fixed'){
    const list = NM.lists[d.list] || [];
    const s = h('select', { class: 'nm-fix', onchange: (ev) => { const i = +ev.target.value; if (i < 0) delete st.v[d.k]; else st.v[d.k] = { i }; draw(); } },
      d.opt ? h('option', { value: -1, selected: !has }, '— ไม่ใส่ —') : null,
      list.map((it, i) => h('option', { value: i, selected: has && v.i === i }, it.m)));
    box.append(h('div', { class: 'nm-val' }, s, dice));
  } else {
    const inp = h('input', { type: 'text', class: 'nm-free', value: has ? v.text : '', placeholder: 'พิมพ์ชื่อตัว', oninput: (ev) => { st.v[d.k] = { text: ev.target.value }; drawOut(); } });
    box.append(h('div', { class: 'nm-val' }, inp, dice));
  }
  return box;
}
function nmSearchView(st, d, draw){
  const cats = [...new Set(nmLex(st.lang).map(e => e.c))];
  const list = h('div', { class: 'nm-hits' });
  const q = h('input', { type: 'search', class: 'nm-q', value: st.q[d.k] || '', placeholder: 'ค้นด้วยความหมายภาษาไทยหรือรากศัพท์ เช่น ไฟ ดาว gor' });
  const cs = h('select', { class: 'nm-catsel' }, h('option', { value: '' }, 'ทุกหมวด'), cats.map(x => h('option', { value: x, selected: st.cat[d.k] === x }, x)));
  const fill = () => {
    clear(list);
    const hits = nmSearch(st.lang, q.value, cs.value, d.prefer);
    if (!hits.length) list.append(h('div', { class: 'dim', text: 'ไม่พบคำ ลองคำอื่นหรือเปลี่ยนหมวด' }));
    hits.slice(0, 60).forEach(e => list.append(h('button', { class: 'nm-hit', onclick: () => { nmSetWord(st, d.k, e, nmPickSense(e, q.value)); st.open = null; draw(); } },
      h('b', { text: e.w }), e.r ? h('span', { class: 'dim', text: ' ' + e.r }) : null, h('span', { text: ' · ' + (e.f === 2 ? 'ชื่อในตัวอย่าง' : e.m.join(', ')) }), h('span', { class: 'nm-cat', text: ' · ' + e.c }))));
    if (hits.length > 60) list.append(h('div', { class: 'dim', text: `แสดง 60 จาก ${hits.length} คำ พิมพ์เพิ่มเพื่อกรอง` }));
  };
  q.oninput = () => { st.q[d.k] = q.value; fill(); };
  cs.onchange = () => { st.cat[d.k] = cs.value; fill(); };
  fill(); setTimeout(() => q.focus(), 0);
  return h('div', { class: 'nm-search' }, h('div', { class: 'nm-srow' }, q, cs), list);
}
function nmOutView(out, st, draw, pick){
  clear(out);
  const r = nmCompose(st);
  if (r.missing.length){ out.append(h('div', { class: 'dim', text: 'เลือกคำให้ครบทุกช่องที่ไม่ได้เขียนว่า "ไม่บังคับ" ก่อน' })); return; }
  const sig = r.name + '|' + r.reading + '|' + r.meaning;
  if (!st.edit || st.edit.sig !== sig) st.edit = { sig, r: r.reading, m: r.meaning };
  const rd = h('input', { type: 'text', class: 'nm-rd', value: st.edit.r, oninput: (e) => { st.edit.r = e.target.value; } });
  const mn = h('input', { type: 'text', class: 'nm-mn', value: st.edit.m, oninput: (e) => { st.edit.m = e.target.value; } });
  out.append(h('div', { class: 'nm-name', text: r.name }),
    h('div', { class: 'nm-fields' }, h('label', null, h('span', { text: 'คำอ่านโดยประมาณ' }), rd), h('label', null, h('span', { text: 'ความหมาย' }), mn)),
    h('div', { class: 'nm-break' }, h('b', { text: 'ที่มา ' }), r.parts.map(p => `${p.w}${p.r ? ' (' + p.r + ')' : ''} = ${p.m}`).join(' + ')),
    h('div', { class: 'nm-btns' },
      r.way.flip ? h('button', { class: 'small nm-flip', title: 'สลับว่าคำไหนเป็นคำหลักในความหมาย', onclick: () => { st.flip = !st.flip; draw(); }, text: '⇄ สลับลำดับความหมาย' }) : null,
      r.L.shift ? h('label', { class: 'nm-shift' }, h('input', { type: 'checkbox', checked: st.shift !== false, onchange: (e) => { st.shift = e.target.checked; draw(); } }), " เสียงโนเม (th→t kh→k ph→p h→')") : null,
      h('button', { class: 'small nm-rand', onclick: () => { nmRandomAll(st); draw(); }, text: '🎲 สุ่มทั้งชื่อ' }),
      h('button', { class: 'primary nm-use', onclick: () => pick(nmResult(st, r)), text: 'ใช้ชื่อนี้' })));
}
/* ข้อความความหมายของชื่อบนชีทและในตัวสร้าง */
function nameMeaningTitle(nm){
  if (!nm) return '';
  const parts = (nm.parts || []).map(p => `${p.w}${p.r ? ' (' + p.r + ')' : ''} = ${p.m}`).join(' + ');
  return [nm.langTh && nm.wayTh ? `${nm.langTh} · ${nm.wayTh}` : '', parts].filter(Boolean).join('\n');
}
function nameMeaningLine(c, readOnly, onSave){
  const nm = c && c.nameMeaning; const text = nm ? String(nm.text || '').trim() : '';
  const reading = nm && nm.reading && nm.name === c.name ? nm.reading : '';
  if (!text && !reading && readOnly) return null;
  const line = h('div', { class: 'namemean', title: nameMeaningTitle(nm) });
  if (reading) line.append(h('span', { class: 'nm-r', text: 'อ่านว่า ' + reading }));
  if (text) line.append(h('span', { class: 'nm-t', text: (reading ? ' · ' : '') + 'ความหมาย: ' + text }));
  if (!readOnly) line.append(h('button', { class: 'small ghost nm-edit', title: 'จดหรือแก้ความหมายของชื่อ', onclick: () => nameMeaningModal(c, onSave), text: text ? 'แก้' : 'ความหมายของชื่อ' }));
  return line;
}
function nameMeaningModal(c, onSave){
  const ta = h('textarea', { class: 'nm-ta', rows: 2, placeholder: 'ความหมายของชื่อ เช่น หัวใจแห่งหิน' }); ta.value = (c.nameMeaning && c.nameMeaning.text) || '';
  modal(h('div', null, h('h3', { text: 'ความหมายของชื่อ ' + (c.name || '') }),
    h('div', { class: 'dim', style: 'font-size:12.5px;margin:4px 0 8px', text: 'ตัวตั้งชื่อจากภาษาคีรันนาอยู่ในขั้นข้อมูลตัวละครตอนสร้าง หน้านี้จดหรือแก้ความหมายของชื่อที่ใช้อยู่' }), ta,
    h('div', { class: 'row', style: 'justify-content:flex-end;margin-top:8px' }, h('button', { class: 'primary small nm-save', onclick: () => { c.nameMeaning = Object.assign({}, c.nameMeaning || {}, { text: ta.value.trim() }); modal(null); onSave(); }, text: 'บันทึก' }))));
}
