/* ===== v1.28 (Non สั่ง 13 พ.ย. 2026 ต่อบนฐาน v1.27 เมื่อ 16 พ.ย. 2026): ลาก Skill และ Sorcery ลงใช้ในโต๊ะเล่น =====
 * แถบสกิลอยู่ใต้แผนที่ ลากป้ายสกิลไปปล่อยบนหมากหรือช่อง (หรือคลิกแล้วเลือกเป้า) → หน้าต่างยืนยัน → หักค่าร่าย ประกาศในแชต และเล่นเอฟเฟกต์ให้ทุกคนในห้องเห็น
 * ระบบอ่านกลไกที่เขียนเป็นแบบแผนในข้อความของสกิล (Saving Throw กับ DC · Clash / Challenge · ความเสียหาย · ฟื้นฟู · สภาวะ · Melee / Range Attack) แล้วทำเป็นปุ่มในการ์ดของแชต
 * กลไกที่ข้อความเขียนเป็นเงื่อนไขเฉพาะจะยังเป็นข้อความให้ GM ตัดสิน · ข้อความที่มาจากแชตถือว่าไม่น่าไว้ใจ ทุกค่าถูกตรวจชนิดและความยาวก่อนใช้
 * NPC ที่มีสแตตบล็อก (v1.27) ได้ป้ายจากการโจมตี Reaction และพฤติกรรมของมันเอง ข้อความของสแตตบล็อกเป็นของ GM จึงไม่ลงแชตเว้นแต่ GM ติ๊กให้แสดง
 * ความเสียหายของทักษะที่ไม่มีตำแหน่งที่โดนหักด้วยเกราะลำตัว ความเสียหายจาก Stack ไม่หักเกราะ (Non เคาะ 15 พ.ย. 2026)
 * ===== v1.29 (Non สั่ง 16 พ.ย. 2026 รอบสอง) =====
 *   6. ทักษะที่มีผลกับตัวเองไม่ให้เลือกเป้าอื่น · 7. ค่าร่ายจ่ายตามที่ข้อความบอก เปลี่ยนได้เฉพาะเมื่อมีของหรือความสามารถมาเปลี่ยน (GM แก้ได้) · 10. Reaction เล็งผู้โจมตีเอง
 *   ทักษะหัก Action ตามประเภท (Cast Swift Basic) ผ่าน Action Track · [เพ่งสมาธิ] ต้อง Focus (Swift Action) · [คอมโบ] ใช้เป็น Free Action ได้เทิร์นละครั้ง · ร่ายเวทแล้วหลุดจากการซ่อนตัว
 *   แถบสกิลกลายเป็นแผงบังคับตัวละคร: ค่าชีวิต Action Track ปุ่มลงมือ และป้ายสกิลแยกตามชนิด Action อยู่ที่เดียวใต้แผนที่ */

/* ---------- ตัวอ่านข้อความของสกิล ---------- */
function suSides(){ if (!suSides.list) suSides.list = DATA.meta.personality.flatMap(ax=>[ax.left, ax.right]); return suSides.list; }
function suStatKnown(name){ return STATS.includes(name) || suSides().includes(name) || ['Sight','Might','Reflex'].includes(name); }
function suStatMod(name, c, d, t){
  name = String(name || '').trim();
  if (c && d){
    if (STATS.includes(name)) return d.mod[name];
    if (name === 'Sight') return d.sight; if (name === 'Might') return d.might; if (name === 'Reflex') return d.reflex;
    if (suSides().includes(name)){ try { return persMod(c, name); } catch(e){ return null; } }
    return null;
  }
  // NPC ที่ไม่มีชีท: ค่าพลังดัดแปลงบนหมาก (ไม่ได้ตั้ง = 0) และค่าพลังรองจากสูตรเดียวกับผู้เล่น · ค่าบุคลิกภาพไม่มีให้อ่าน
  const nd = (t && typeof Combat !== 'undefined') ? Combat.npcDer(t) : null; if (!nd) return null;
  if (STATS.includes(name)) return cbInt((t.mods || {})[name]);
  if (name === 'Sight') return nd.sight; if (name === 'Might') return nd.might; if (name === 'Reflex') return nd.reflex;
  return null;
}
/* DC ที่เขียนเป็นสูตร เช่น "8 + Order Mod." · "6 + Logic Mod. ของคุณ" · "10" · "2d6 + Chaos" คิดจากชีทของผู้ใช้ทักษะ อ่านไม่ออกคืน null */
function suDcValue(txt, c, d, t){
  const s = String(txt || '').replace(/ของคุณ|ของผู้ร่าย[^+]*/g, '').trim(); let m = /^(\d{1,2})$/.exec(s); if (m) return {value: +m[1], text: m[1]};
  m = /^(?:(\d+d\d+|\d{1,2})\s*\+\s*)?([A-Za-z]+)(?:\s*Mod\.?)?$/.exec(s); if (!m) return null;
  const mod = suStatMod(m[2], c, d, t); if (mod == null) return null; let base = 0, btxt = '';
  if (m[1]){ if (/d/.test(m[1])){ const r = cbRollExpr(m[1]); base = r.total; btxt = r.text; } else { base = +m[1]; btxt = m[1]; } }
  return {value: base + mod, text: `${btxt ? btxt + ' ' : ''}${mod < 0 ? '-' : '+'}${Math.abs(mod)} ${m[2]}`};
}
function suParseCost(cost){
  const raw = String(cost || '').trim(); const parts = []; const rx = /(\d+d\d+(?:\s*\+\s*\d+)?|\d+)\s*(MP|Sanity|HP)/g; let m;
  while ((m = rx.exec(raw)) && parts.length < 4) parts.push({expr: m[1].replace(/\s+/g, ''), res: m[2] === 'MP' ? 'mp' : m[2] === 'HP' ? 'hp' : 'san'});
  return {raw, parts, alt: parts.length > 1 && /หรือ|\/|แต่/.test(raw), other: /Stack|\bCP\b|หรือ/.test(raw) && !(parts.length > 1 && /หรือ/.test(raw)) && /Stack|\bCP\b/.test(raw), firstFree: /ฟรี\s*1\s*ครั้งต่อวัน/.test(raw)};
}
const SU_RES = {mp: 'MP', san: 'Sanity', hp: 'HP'};
/* ประเภทของทักษะบอก Action ที่ใช้ (ไฟล์แกน: เทิร์นละ 1 Swift 1 Basic 1 Cast · Reaction และ Free Action ไม่เสีย Action · Passive ทำงานตลอด)
 * "AP / Free Action [คอมโบ]" จ่าย AP ช่องใดก็ได้ · ทักษะที่ใช้เวลาเป็นนาทีหรือชั่วโมง หรือเขียนว่านอกการต่อสู้ ไม่หัก Action ในฉากต่อสู้ */
function suActKinds(type){
  const s = String(type || ''); const out = [];
  const long = /นอกการต่อสู้|ระหว่างการพัก|ระหว่างพัก|ช่วงพัก|Downtime|ตลอดทั้งคืน/.test(s) || /ใช้เวลา(?:นาน)?\s*\d+\s*(?:นาที|ชั่วโมง)|\(\d+\s*นาที\)/.test(s);
  if (/^\s*AP\b/.test(s)) out.push('b', 'c');
  if (/Swift/i.test(s)) out.push('s'); if (/Basic\s*Actio/i.test(s)) out.push('b'); if (/\bCast\b/i.test(s)) out.push('c');
  if (!out.length && /^\s*Action\b/.test(s)) out.push('b');
  const reaction = /Reaction/i.test(s); const passive = !out.length && !reaction && /Passive|Trait/i.test(s);
  return {kinds: [...new Set(out)], passive, reaction, free: /Free Action/i.test(s), combo: /\[คอมโบ\]/.test(s), focus: /\[เพ่ง(?:สมาธิ|จิต)\]/.test(s), long, stance: /กระบวนท่า/.test(s)};
}
/* ขีดจำกัดจำนวนครั้งที่เขียนไว้ในประเภทหรือต้นข้อความ: ต่อการต่อสู้ ต่อการพักสั้น ต่อการพักยาว ต่อวัน */
function suLimit(sk){
  if (!sk || sk.npc || sk.synthetic) return null; const s = `${sk.type || ''} ${String(sk.effect || '').slice(0, 40)}`; const m = /1 ครั้งต่อ(?:การ)?(ต่อสู้|พักสั้น|พักยาว|วัน)/.exec(s); if (!m) return null;
  return m[1] === 'ต่อสู้' ? 'combat' : m[1] === 'พักสั้น' ? 'short' : m[1] === 'พักยาว' ? 'long' : 'day';
}
/* ทักษะที่มีผลกับผู้ใช้เองเท่านั้น: ข้อความพูดถึง "คุณ" และไม่เอ่ยถึงเป้าหมาย ศัตรู พันธมิตร พื้นที่ ระยะ หรือการทอยแข่งกับใคร (Non สั่ง 16 พ.ย. 2026 ข้อ 6) */
const SU_OTHER_RX = /เป้าหมาย|ศัตรู|พันธมิตร|ตัวละคร(?:อื่น|ทุก|ใด|หนึ่ง|ที่)|สิ่งมีชีวิต|ผู้อื่น|ผู้เข้าร่วม|ผู้พิทักษ์|วัตถุ|ชิ้นหนึ่ง|ทุกตน|ทุกคน|สัมผัส(?!ปฐพี)|ในระยะ|รัศมี|ระยะ\s*\d+|พื้นที่|จุดที่|กำแพง|Zone|เลือก 1 อย่าง|ทำตามนี้|Saving Throw \(DC|Clash|Challenge|Melee Attack|Rang(?:e|ed) Attack/;
/* ข้อความที่ขึ้นต้นด้วยผลกับผู้ใช้เอง (บัฟของการโจมตีครั้งถัดไป ผลที่อยู่ถึงเทิร์นถัดไปของคุณ การเปลี่ยนร่างของตัวเอง) นับเป็นทักษะใช้กับตัวเอง แม้ประโยคหลังจะเอ่ยถึงเป้าของการโจมตีครั้งนั้น */
const SU_SELF_LEAD_RX = /^\s*(?:(?:จนกว่าจะถึง|จนถึง)เทิร์นถัดไป(?:ของคุณ)?[ ,]*(?:คุณ|การโจมตี|Melee Attack)|การ\s*(?:Melee Attack|Rang(?:e|ed) Attack|โจมตี\S*?)\s*(?:\([^)]*\)\s*)?(?:ครั้งถัดไป)?\s*ของคุณ|การโจมตี\S*?\s*(?:\([^)]*\)\s*)?ครั้งถัดไป|คุณเข้าสู่สภาวะ|คุณเปลี่ยนร่างกายของคุณ|คุณปรับ\S*?ของคุณ|คุณ(?:จะ)?ได้รับ\s*(?:Focus|\+\d|[A-Z]{3} Advantage)|ได้รับ\s*[A-Z]{3} Advantage)/;
function suSelfOnly(sk, mech){
  if (!sk || sk.npc || sk.synthetic) return false; const ak = suActKinds(sk.type); if (ak.stance || ak.passive) return true;
  if (mech.saves.length || mech.clashes.length || mech.attack || mech.area) return false; const eff = String(sk.effect || '');
  if (SU_SELF_LEAD_RX.test(eff)) return true;
  if (mech.rangeM) return false;
  return /คุณ/.test(eff) && !SU_OTHER_RX.test(eff);
}
function suParse(sk){
  if (!sk) return {saves: [], clashes: [], checks: [], dmg: [], heal: [], conds: [], tough: null, attack: null, rangeM: null, area: null, passive: false, reaction: false, half: false, self: false};
  const eff = String(sk.effect || '').replace(/\\/g, ''); const type = String(sk.type || ''); let x;
  const ck = (sk.npc || sk.synthetic) ? null : sk.nameEn; if (!suParse.cache) suParse.cache = new Map();
  if (ck){ const hit = suParse.cache.get(ck); if (hit && hit.eff === eff && hit.type === type) return hit.m; }
  const m = {saves: [], clashes: [], checks: [], dmg: [], heal: [], conds: [], tough: null, attack: null, rangeM: null, area: null, passive: /Passive/i.test(type), reaction: /Reaction/i.test(type), half: /สำเร็จ[^.]{0,40}ครึ่ง/.test(eff), self: false};
  const rxS = /([A-Za-z][A-Za-z&' ]*?) Saving Throw \(DC ?=? ?([^)]*)\)/g; while ((x = rxS.exec(eff)) && m.saves.length < 3) m.saves.push({stat: x[1].trim(), dc: x[2].trim()});
  const rxC = /([A-Za-z][A-Za-z&']*) (Clash|Challenge) ([A-Za-z][A-Za-z&']*)/g; while ((x = rxC.exec(eff)) && m.clashes.length < 2){ const alt = /^\s*หรือ\s*([A-Z]{3})\b/.exec(eff.slice(x.index + x[0].length)); m.clashes.push({a: x[1], kind: x[2], b: x[3], bAlt: (alt && alt[1] !== x[3]) ? alt[1] : null}); }
  const rxK = /([A-Za-z][A-Za-z&' ()]*?) Check \(DC ?=? ?([^)]*)\)/g; while ((x = rxK.exec(eff)) && m.checks.length < 3) m.checks.push({stat: x[1].trim(), dc: x[2].trim()});
  const rxD = /(\d+d\d+|\d+)\s*(?:\+\s*([A-Za-z]+)(?: Mod\.?)?\s*)?([A-Z][A-Za-z]+) (?:Damage|DMG)|(\d+d\d+|\d+)\s*PDMG/g;
  while ((x = rxD.exec(eff)) && m.dmg.length < 4){ if (x[4]){ m.dmg.push({expr: x[4], mod: null, type: 'Physical'}); continue; } if (/^Tough/.test(x[3])){ if (!m.tough) m.tough = x[1]; continue; } if (x[3] === 'All') continue; m.dmg.push({expr: x[1], mod: x[2] || null, type: x[3] === 'Sanity' ? 'Sanity' : cbNormType(x[3])}); }
  const rxH = /ฟื้นฟู\s*(?:(HP|MP|Sanity)\s*)?(\d+d\d+(?:\s*\+\s*\d+)?|\d+)\s*(HP|MP|Sanity)?/g; while ((x = rxH.exec(eff)) && m.heal.length < 2){ const res = x[1] || x[3]; if (!res) continue; m.heal.push({expr: x[2].replace(/\s+/g, ''), res: res === 'MP' ? 'mp' : res === 'HP' ? 'hp' : 'san'}); }
  // ทักษะที่ "ทำ Melee Attack" คือการโจมตี · ประโยคเงื่อนไข (หากทำ เมื่อทำ ทุกครั้งที่คุณทำ) เป็นบัฟของการโจมตีครั้งอื่น ไม่เปิดหน้าต่างโจมตี
  const rxA = /(?:^|ทำการ\s*|ทำ\s*|ด้วยการ\s*)(Melee|Rang(?:e|ed)) Attack/g; let am;
  while ((am = rxA.exec(eff))){ if (/(?:หาก|เมื่อ|ครั้งที่|ที่|ถ้า)(?:คุณ)?\s*$/.test(eff.slice(Math.max(0, am.index - 14), am.index))) continue;
    const head = eff.slice(0, am.index); const sent = head.slice(Math.max(head.lastIndexOf('.'), head.lastIndexOf('·')) + 1); if (/(?:เมื่อ|หาก|ถ้า|ทุกครั้งที่)\s*(?:ศัตรู|เป้าหมาย|มี|พันธมิตร|ตัวละคร)/.test(sent)) continue; // การโจมตีของคนอื่น (เช่น "เมื่อศัตรู...ทำการ Melee Attack") ไม่ใช่การโจมตีของผู้ใช้ทักษะ
    m.attack = am[1] === 'Melee' ? 'melee' : 'ranged'; break; }
  if (m.passive) m.attack = null; // ทักษะติดตัวไม่ใช่การกดโจมตี
  m.conds = cbFindConds(eff).slice(0, 5);
  const rg = /ระยะ(?:ไม่เกิน)?\s*(\d+)\s*เมตร/.exec(eff); if (rg) m.rangeM = +rg[1];
  const ar = /รัศมี\s*(\d+)\s*เมตร/.exec(eff); const sq = /(\d+)\s*x\s*(\d+)\s*เมตร/.exec(eff);
  if (ar) m.area = {r: +ar[1]}; else if (sq) m.area = {sq: +sq[1]}; else if (/รูปกรวย|\bCone\b/.test(eff)) m.area = {cone: true};
  m.self = suSelfOnly(sk, m);
  if (ck) suParse.cache.set(ck, {eff, type, m}); return m;
}
/* พื้นที่ของสกิลคิดเป็นจำนวนช่องจากจุดกลางออกไปแต่ละด้าน (หนึ่งช่อง 2 เมตร) */
function suAreaCells(area){ if (!area) return 0; if (area.r) return Math.max(1, Math.min(8, Math.floor(area.r / CELL_M))); if (area.sq) return Math.max(0, Math.min(8, Math.floor(area.sq / CELL_M / 2))); if (area.cone) return 1; return 0; }
function suFxKind(mech, self, cells){
  if (mech.heal.length) return 'heal'; if (mech.attack === 'melee') return 'slash'; if (cells > 0) return 'zone';
  if (mech.reaction && !mech.dmg.length) return 'shield'; if (mech.passive || self) return 'aura';
  return 'proj';
}
const SU_FX = [['proj','ลูกพลังพุ่งใส่เป้า'],['slash','รอยฟัน'],['burst','ระเบิด'],['zone','พื้นที่'],['aura','ออร่ารอบตัว'],['heal','ฟื้นฟู'],['shield','โล่']];
const SU_HUES = [['fire','ไฟ'],['plasma','พลาสมา'],['electric','สายฟ้า'],['wind','ลม'],['earth','ดินและโลหะ'],['water','น้ำ'],['frost','น้ำแข็ง'],['nature','พฤกษา'],['chaos','เคออส'],['blood','เลือด'],['necrotic','ความตาย'],['poison','พิษ'],['ritual','ทอง'],['steel','เหล็ก'],['qi','ปราณ']];
function suClean(s, n){ return String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n); }
/* Basic Action ที่ไม่ใช่สกิลแต่เดินตามขั้นตอนเดียวกัน (ไฟล์แกน บทระบบการต่อสู้): Grab */
const SU_BASIC = {
  grab: {synthetic: true, key: 'basic:grab', nameEn: 'Grab', nameTh: 'จับ', type: 'Basic Action', category: 'Basic', cost: '', effect: 'จับเป้าหมายในเขตปะทะ ทอย STR Challenge AGI หรือ STR ของเป้าหมาย หากชนะ เป้าหมายติด Grappled และต้องใช้ 1 AP ในเทิร์นของตนทอย STR Challenge STR หรือ AGI ให้ชนะเพื่อหลุดออก'},
};
/* สิ่งที่เปลี่ยนค่าร่ายได้ (Non เคาะ 16 พ.ย. 2026: จ่ายตามที่ข้อความบอก ยกเว้นมีเอฟเฟกต์อื่นมาเปลี่ยน) ระบบตรวจของที่สวมและ Proficiency ให้ ผู้ใช้ติ๊กเฉพาะข้อที่เข้าเงื่อนไข
 * eff: minus (ลด MP) · half (จ่าย MP ครึ่งเดียว ปัดลง) · free (ไม่จ่าย) · edit (ให้แก้จำนวนเอง) */
function suCostMods(t, c, sk, cost){
  const out = []; if (!sk || sk.npc || sk.synthetic || !c || !cost.parts.length) return out;
  const equipHas = (rx)=> Object.values(c.equip || {}).some(e=>e && rx.test(String(e.name || '')) && !(typeof durBroken === 'function' && durBroken(e)));
  const feats = (typeof Feats !== 'undefined') ? Feats.list(c) : []; const has = (id)=>feats.some(f=>f.id === id);
  const sorc = sk.category === 'Sorcery'; const mpMax = Math.max(0, ...cost.parts.filter(p=>p.res === 'mp' && /^\d+$/.test(p.expr)).map(p=>+p.expr)); const hasMp = cost.parts.some(p=>p.res === 'mp'); const hasSan = cost.parts.some(p=>p.res === 'san');
  const melee = (typeof Act !== 'undefined') ? !!Act.flag(t, 'melee') : false; const cast = /\bCast\b/i.test(sk.type || '');
  if (sorc && hasMp && mpMax >= 3 && equipHas(/Sorcery Staff|ไม้เท้าเวท/)) out.push({id: 'staff', label: 'ไม้เท้าเวท: Sorcery ที่ค่าร่ายตั้งแต่ 3 MP ลด 1 MP', on: true, minus: 1});
  if (hasMp && /Ritual/i.test(sk.subcategory || '') && equipHas(/Holy Symbol|สัญลักษณ์ศักดิ์สิทธิ์/)) out.push({id: 'holy', label: 'สัญลักษณ์ศักดิ์สิทธิ์: Ritual Sorcery ลดค่าร่าย 1 MP', on: true, minus: 1});
  if (hasMp && cast && has('Martial Artist')) out.push({id: 'martial', label: 'Martial Artist: Cast หลังการ Melee Attack จ่ายน้อยลง 1 MP', on: melee, minus: 1});
  let own = []; try { own = allSkills(c); } catch(e){ own = []; }
  if (hasMp && sorc && /Liquid/i.test(sk.subcategory || '') && own.includes('Drain Dry')) out.push({id: 'ddry', label: 'Drain Dry: เป้าทอย Saving Throw ไม่ผ่านมาก่อน Liquid Sorcery ครั้งนี้ใช้น้อยลง 2 MP', on: false, minus: 2});
  if (hasMp && sorc && has('Trickster III')) out.push({id: 'trick3', label: 'Trickster III: Sorcery เสริมพลังลงอาวุธหรืออุปกรณ์ที่มี Throwable จ่าย MP ครึ่งเดียว', on: false, half: true});
  if (hasMp && sorc && has('Dual Caster')) out.push({id: 'dual', label: 'Dual Caster: ร่าย 2 Sorceries ต่างประเภทพร้อมกัน จ่าย MP ครึ่งเดียว (ปัดลง)', on: false, half: true});
  if ((hasMp || hasSan) && has('Substitution')) out.push({id: 'subst', label: 'Substitution (จ่าย 1 AP ไว้แล้วในเทิร์นนี้): สลับจ่าย 5 MP กับ 1 Sanity แก้จำนวนเองในช่องค่าร่าย', on: false, edit: true});
  if (hasMp && sorc && has('Skin as a Scroll')) out.push({id: 'yantra', label: 'ผิวกายคือคัมภีร์ (Skin as a Scroll): เวทที่สักไว้ร่ายได้โดยไม่จ่าย MP', on: false, free: true, use: {per: 'day', max: 1}}); // Trait ของพื้นหลัง Yantra Master (Nightkin A3) ทะเบียนความสามารถใช้ชื่อ Trait ไม่ใช่ชื่อพื้นหลัง
  if (hasSan && has('Soul Chamber')) out.push({id: 'soul', label: 'Soul Chamber: จ่าย Soul แทน Sanity (หัก Soul เองบนชีท)', on: false, free: true});
  if (cost.firstFree) out.push({id: 'first', label: 'ครั้งแรกของวัน: ใช้ได้ฟรี', on: false, free: true, use: {per: 'day', max: 1}});
  // ตัวเลือกที่ใช้ได้วันละครั้งและใช้ไปแล้ว (จดในชีทตอนใช้ รีเซ็ตเมื่อพักยาว) ติ๊กซ้ำไม่ได้ · เวทที่สักไว้มีบทเดียว จึงนับรวมทุกทักษะ
  const uses = (c.current && c.current.uses && typeof c.current.uses === 'object') ? c.current.uses : {};
  for (const md of out) if (md.use){ md.useKey = md.id === 'yantra' ? 'cost:yantra' : 'cost:' + md.id + ':' + sk.nameEn; if (uses[md.useKey]){ md.spent = true; md.on = false; md.label += ' (ใช้ไปแล้ว รีเซ็ตเมื่อพักยาว)'; } }
  return out;
}

const SkillUse = {
  tokId: null, q: '', collapsed: null, pick: false, st: null, modes: {},
  reset(){ this.pick = false; this.st = null; this.modes = {}; this.hint(null); },
  isCollapsed(){ if (this.collapsed == null){ try { this.collapsed = localStorage.getItem('kirana.skillbar') === '1'; } catch(e){ this.collapsed = false; } } return this.collapsed; },
  setCollapsed(v){ this.collapsed = !!v; try { localStorage.setItem('kirana.skillbar', v ? '1' : '0'); } catch(e){} },
  /* ความสามารถในสแตตบล็อกของ NPC ทำเป็นป้ายแบบเดียวกับทักษะ: การโจมตี (ลากใส่เป้า = เปิดหน้าต่างโจมตีด้วยท่านั้น) · Reaction · พฤติกรรมและความสามารถพิเศษ */
  npcSkills(t){
    if (typeof Combat === 'undefined' || !Combat.isNpc(t)) return []; const out = [];
    const add = (list, kind, type, max)=>{ (Array.isArray(list) ? list : []).slice(0, max).forEach((x, i)=>{ if (!x || typeof x !== 'object') return; const full = suClean(x.name, 80) || (kind === 'a' ? 'การโจมตี' : kind === 'r' ? 'Reaction' : 'ความสามารถ'); const sp = (typeof itemNameSplit === 'function') ? itemNameSplit(full) : [full, ''];
      out.push({npc: true, npcKind: kind, key: `npc:${kind}:${i}`, full, nameTh: sp[0] || full, nameEn: sp[1] || sp[0] || full, type, category: 'NPC', cost: '', effect: String(x.text || '').slice(0, 2000)}); }); };
    add(t.attacks, 'a', 'การโจมตี', 12); add(t.reactions, 'r', 'Reaction', 8); add(t.behaviors, 'b', 'พฤติกรรม', 16);
    return out;
  },
  skillByKey(t, key){ if (key === '*' || key == null) return null; const k = String(key); if (k.indexOf('npc:') === 0) return this.npcSkills(t).find(x=>x.key === k) || null; if (k.indexOf('basic:') === 0) return Object.prototype.hasOwnProperty.call(SU_BASIC, k.slice(6)) ? SU_BASIC[k.slice(6)] : null; return Object.prototype.hasOwnProperty.call(SKILL_BY_NAME, k) ? SKILL_BY_NAME[k] : null; },
  nameOf(sk){ return !sk ? '' : (sk.npc ? sk.full : skLabel(sk)); },
  skillsOf(t){
    const npc = this.npcSkills(t); if (npc.length) return npc;
    const c = Combat.charOf(t); if (!c || (c.shareMode === 'min' && !Store.isMine(c))) return [];
    let names = []; try { names = allSkills(c); } catch(e){ names = []; }
    const list = names.map(n=>SKILL_BY_NAME[n]).filter(Boolean); return [...list.filter(sk=>!/Passive/i.test(sk.type || '')), ...list.filter(sk=>/Passive/i.test(sk.type || ''))];
  },
  /* กลุ่มของป้ายสกิลในแผงบังคับ ตามชนิด Action ที่ใช้ */
  groupOf(sk){ if (!sk) return 'o'; if (sk.npc) return sk.npcKind === 'a' ? 'b' : sk.npcKind === 'r' ? 'r' : 'o'; const ak = suActKinds(sk.type); if (ak.passive) return 'p'; if (ak.long) return 'o'; if (ak.kinds.length) return ak.kinds[0]; return ak.reaction ? 'r' : 'o'; },
  /* ---------- แผงบังคับตัวละครใต้แผนที่ (v1.29: เดิมคือแถบสกิล) ----------
   * รวมสิ่งที่ต้องใช้ในเทิร์นไว้ที่เดียว: หมากที่บังคับ ค่าชีวิต สภาวะ Action Track ปุ่มลงมือ กระบวนท่า และป้ายสกิลแยกตามชนิด Action (ชนิดที่ใช้ไปแล้วในเทิร์นนี้จางลง) */
  bar(r, gm){
    const list = Combat.myTokens(r); if (!list.length) return null;
    const sel = list.find(x=>x.id === Table.sel); let t = sel || list.find(x=>x.id === this.tokId) || list.find(x=>x.kind === 'pc' && ownsTok(x)) || list[0]; this.tokId = t.id;
    const sks = this.skillsOf(t); const col = this.isCollapsed(); const enc = Act.on(r); const myTurn = enc && Act.isTurn(t, r);
    const box = h('div',{class:'card skillbar dock' + (col ? ' collapsed' : '') + (myTurn ? ' myturn' : ''),dataset:{tok:t.id}});
    const who = list.length > 1 ? cbSelect(list.map(x=>[x.id, x.name]), t.id, (v)=>{ this.tokId = v; Table.sel = v; renderTable(); }, {class:'skb-who',title:'หมากที่จะบังคับ'}) : h('b',{class:'skb-who',text:t.name});
    const search = sks.length > 10 ? h('input',{class:'skb-q',placeholder:'ค้นหาทักษะ',style:'width:150px'}) : null;
    if (search){ search.value = this.q; search.oninput = ()=>{ this.q = search.value; drawChips(); }; }
    box.append(...cbKids(h('h3',{class:'row',style:'justify-content:space-between;gap:8px'}, h('span',{text:'🎮 แผงบังคับตัวละคร'}), h('span',{class:'row',style:'gap:6px'}, who, col ? null : search, h('button',{class:'small ghost skb-toggle',title: col ? 'กางแผงบังคับ' : 'พับแผงบังคับ',onclick:()=>{ this.setCollapsed(!col); renderTable(); },text: col ? '▸ กาง' : '▾ พับ'})))));
    // แถวสถานะ: ค่าชีวิต สภาวะ Action Track และปุ่มจบเทิร์น (เห็นแม้พับแผง)
    const turnBtn = enc ? ((gm || Table.localMode) ? h('button',{class:'small primary dock-next',title:'จบเทิร์นของหมากปัจจุบัน แล้วเริ่มเทิร์นของหมากถัดไป',onclick:()=>advanceTurn(r),text:'เทิร์นถัดไป →'}) : (myTurn && ownsTok(Act.holder(t)) ? h('button',{class:'small primary dock-next endturn2',title:'จบเทิร์นของคุณ ส่งต่อให้หมากถัดไปในลำดับ',onclick:()=>advanceTurn(r),text:'จบเทิร์น →'}) : null)) : null;
    const curT = enc ? (r.tokens || []).find(x=>x.id === Act.curId(r)) : null;
    box.append(...cbKids(h('div',{class:'row dock-status'}, h('span',{class:'dock-vit num',title:'HP ของหมากที่บังคับอยู่',text:`HP ${cbInt(t.hp)}/${cbInt(t.hpMax)}`}), t.sanMax ? h('span',{class:'dock-vit num san',text:`SAN ${cbInt(t.san)}/${cbInt(t.sanMax)}`}) : null,
      (t.conds || []).length ? h('span',{class:'dock-conds',title:(t.conds || []).map(c=>c.id + (c.lv ? ' ' + c.lv : '')).join(', '),text:(t.conds || []).map(c=>condIcon(c.id) + (c.lv ? c.lv : '')).join(' ')}) : null,
      enc ? (Act.chips(t, r, {big: true}) || null) : h('span',{class:'dim',style:'font-size:12px',text:'ยังไม่เริ่มฉากต่อสู้ ไม่นับ Action'}),
      enc ? h('span',{class:'dock-turn' + (myTurn ? ' on' : ''),text: myTurn ? 'เทิร์นของหมากนี้' : (curT && (gm || !curT.hidden) ? `เทิร์นของ ${curT.name}` : 'ยังไม่ถึงเทิร์น')}) : null, turnBtn)));
    if (col) return box;
    // ปุ่มลงมือที่ใช้บ่อย
    const prone = (t.conds || []).find(c=>c.id === 'Prone' && c.auto !== 'cling'); const acts = h('div',{class:'row dock-acts'});
    acts.append(...cbKids(h('button',{class:'small primary dock-atk',title:'เปิดหน้าต่างโจมตี (Basic Action)',onclick:()=>Combat.openAttack(t.id, null),text:'⚔ โจมตี'}),
      h('button',{class:'small dock-focus',title:'Focus (1 Swift Action) แล้วโจมตี: เล็งตำแหน่ง Non-Lethal หรือเทคนิคของอาวุธ',onclick:()=>Combat.openAttack(t.id, null, {focus: 'precise'}),text:'🎯 เล็งแล้วโจมตี'}),
      h('button',{class:'small dock-grab',title:'Grab (Basic Action): ทอย STR Challenge AGI หรือ STR ชนะแล้วเป้าติด Grappled',onclick:()=>this.basic(t.id, 'grab'),text:'🤼 จับ'}),
      enc ? h('button',{class:'small dock-ow' + (Act.holder(t).ow ? ' on' : ''),disabled: !!Act.holder(t).ow,title:'Overwatch (Basic Action): ตั้งท่าป้องกัน ใช้ไม่ได้ถ้า Maneuver ไปแล้วในเทิร์นนี้',onclick:()=>{ if (cbInt(Act.flag(t, 'mv')) > 0 && !(gm || Table.localMode)){ toast('เคลื่อนที่ไปแล้วในเทิร์นนี้ จึงใช้ Overwatch ไม่ได้'); return; } if (Act.manualKeepOw(t, 'b', 'Overwatch')){ Act.holder(t).ow = 1; Table.save(); } },text:'🛡 Overwatch'}) : null,
      (enc && prone) ? h('button',{class:'small dock-stand',title:'ใช้ 1 Maneuver (Swift Action) ลุกขึ้นยืน',onclick:()=>{ if (Act.manual(t, 's', 'ลุกขึ้นยืน (Maneuver)', ()=>Act.markManeuver(t))) removeCond(t, r, prone, 'ลุกขึ้นยืน'); },text:'🧍 ลุกขึ้น'}) : null,
      t.charId ? h('button',{class:'small ghost dock-sheet',onclick:()=>{ location.hash = '#sheet-' + t.charId; },text:'📜 ชีท'}) : null,
      t.stance ? h('span',{class:'tag prop dock-stance',title:'กระบวนท่าที่ตั้งอยู่ ผลของท่าเข้าหน้าต่างโจมตีและป้องกันเอง'}, `🥋 ${String(t.stance.th || t.stance.id).slice(0, 40)}`, h('button',{class:'cadj',title:'เลิกท่านี้',onclick:()=>{ const th = t.stance.th || t.stance.id; delete t.stance; delete t.rhythm; Table.save(); if (!t.hidden) Table.post({kind: 'sys', who: '', text: `${t.name} เลิกกระบวนท่า ${th}`}); },text:'×'})) : null));
    box.append(...cbKids(acts));
    box.append(...cbKids(h('p',{class:'dim skb-hint',text:'ลากป้ายสกิลไปปล่อยบนหมากหรือช่องบนแผนที่ หรือคลิกป้ายแล้วเลือกเป้า ทุกคนในห้องเห็นเอฟเฟกต์ · ลากหมากเพื่อเคลื่อนที่ (Swift Action)'})));
    const chips = h('div',{class:'skgroups'}); box.append(...cbKids(chips));
    const GROUPS = [['c', '✦ Cast'], ['s', '⚡ Swift'], ['b', '⚔ Basic'], ['r', '↺ Reaction'], ['p', '◈ ติดตัว'], ['o', 'อื่น ๆ']];
    const drawChips = ()=>{ clear(chips); const k = this.q.trim().toLowerCase();
      const shown = sks.filter(sk=>!k || [sk.nameTh, sk.nameEn, sk.type, sk.subcategory, sk.npc ? sk.effect : ''].filter(Boolean).some(x=>String(x).toLowerCase().includes(k)));
      for (const [g, label] of GROUPS){ const part = shown.filter(sk=>this.groupOf(sk) === g); if (!part.length && g !== 'o') continue;
        const spent = myTurn && ['c', 's', 'b'].includes(g) && Act.left(t, g) <= 0;
        const row = h('div',{class:'skgroup g-' + g + (spent ? ' spent' : ''),dataset:{g}}, h('span',{class:'skg-label',title: spent ? 'Action ชนิดนี้ใช้ไปแล้วในเทิร์นนี้' : null,text: label + (spent ? ' (ใช้ไปแล้ว)' : '')}), h('div',{class:'skchips'}, part.map(sk=>this.chip(t, sk)), g === 'o' ? this.chip(t, null) : null));
        chips.append(...cbKids(row)); }
      if (!sks.length) chips.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text: t.charId ? 'ตัวละครนี้ยังไม่มีทักษะ หรือเจ้าของแชร์เฉพาะค่าหลัก' : 'หมากนี้ยังไม่มีการโจมตี Reaction หรือพฤติกรรมในสแตตบล็อก เพิ่มได้ที่แผงหมาก หรือใช้ป้าย "ความสามารถอื่น" แล้วพิมพ์ชื่อกับผลเอง'})));
      else if (!shown.length) chips.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`ไม่พบทักษะที่ตรงกับ "${this.q.trim()}"`}))); };
    drawChips();
    return box;
  },
  chip(t, sk){
    const mech = suParse(sk); const hue = sk ? fxHueOfSkill(sk) : 'ritual'; const key = !sk ? '*' : (sk.npc ? sk.key : sk.nameEn);
    const ico = !sk ? '＋' : sk.npc ? (sk.npcKind === 'a' ? '⚔' : sk.npcKind === 'r' ? '↺' : '◈') : mech.passive ? '◈' : mech.reaction ? '↺' : sk.category === 'Sorcery' ? '✦' : '⚔'; const name = sk ? skTh(sk) : 'ความสามารถอื่น';
    const stanceOn = !!(sk && t.stance && t.stance.id === sk.nameEn);
    const b = h('button',{class:'skchip' + (mech.passive ? ' passive' : '') + (sk ? '' : ' custom') + (sk && sk.npc ? ' npc' : '') + (stanceOn ? ' on' : ''),dataset:{sk:key},title: sk ? `${this.nameOf(sk)}\n${sk.type || ''}${sk.cost ? ' · ' + sk.cost : ''}\n${String(sk.effect || '').slice(0, 240)}` : 'พิมพ์ชื่อและผลของความสามารถเอง ใช้กับ NPC หรือความสามารถที่ไม่อยู่ในรายการ'},
      h('i',{class:'skdot',text:ico}), h('span',{class:'sknm',text:name}), (sk && sk.cost && !/^none$/i.test(sk.cost)) ? h('span',{class:'skcost',text: sk.cost.length > 14 ? sk.cost.slice(0, 13) + '…' : sk.cost}) : null);
    b.style.setProperty('--fx', FX_HUE[hue] || FX_HUE.ritual);
    b.addEventListener('pointerdown', (e)=>this.startDrag(e, t.id, key, name));
    b.addEventListener('click', (e)=>{ if (e.detail === 0) this.use(t.id, key, null); }); // คีย์บอร์ด: Enter หรือ Space บนป้าย
    return b;
  },
  /* ลากด้วย pointer: ฟังที่ window การวาดโต๊ะใหม่กลางทางจึงไม่ทำให้การลากหลุด · ไม่ขยับ = คลิก */
  startDrag(ev, tokId, key, label){
    if (ev.button != null && ev.button !== 0) return; ev.preventDefault();
    const sx = ev.clientX, sy = ev.clientY; let ghost = null, moved = false, last = null, px = sx, py = sy, timer = null;
    const gridEl = ()=>document.querySelector('#v-table .gridmap');
    const mark = ()=>{ const g = gridEl(); const cell = g ? cellAtPoint(g, px, py) : null; if (cell !== last){ if (last) last.classList.remove('drop'); if (cell) cell.classList.add('drop'); last = cell; } };
    const move = (e)=>{ px = e.clientX; py = e.clientY; if (!moved && Math.hypot(px - sx, py - sy) < 6) return;
      if (!moved){ moved = true; ghost = h('div',{class:'skghost',text:'⚡ ' + label}); document.body.append(...cbKids(ghost)); document.body.classList.add('sk-dragging');
        // ลากไปใกล้ขอบบนหรือล่างของจอ หน้าเลื่อนตามเอง จะได้ลากถึงหมากที่อยู่นอกจอ
        timer = setInterval(()=>{ const edge = 64; if (py < edge) window.scrollBy(0, -16); else if (py > window.innerHeight - edge) window.scrollBy(0, 16); else return; mark(); }, 30); }
      const z = uiZoom(); ghost.style.left = (px / z + 12) + 'px'; ghost.style.top = (py / z + 12) + 'px'; mark(); };
    const up = (e)=>{ window.removeEventListener('pointermove', move, true); window.removeEventListener('pointerup', up, true); window.removeEventListener('pointercancel', up, true);
      if (timer) clearInterval(timer); document.body.classList.remove('sk-dragging'); if (ghost) ghost.remove(); if (last) last.classList.remove('drop');
      if (e.type === 'pointercancel') return; if (!moved){ this.use(tokId, key, null); return; }
      const g = gridEl(); const cell = g ? cellAtPoint(g, e.clientX, e.clientY) : null; if (!cell){ toast('ลากไปปล่อยบนหมากหรือช่องบนแผนที่'); return; }
      this.use(tokId, key, {x: +cell.dataset.x, y: +cell.dataset.y}); };
    window.addEventListener('pointermove', move, true); window.addEventListener('pointerup', up, true); window.addEventListener('pointercancel', up, true);
  },
  /* Basic Action ที่เดินตามขั้นตอนของทักษะ (Grab) และการพาไปที่แผงบังคับ */
  basic(tokId, what){ if (!Object.prototype.hasOwnProperty.call(SU_BASIC, what)) return; this.use(tokId, 'basic:' + what, null); },
  focusBar(tokId){ this.tokId = tokId; if (this.isCollapsed()) this.setCollapsed(false); Table.sel = tokId; renderTable(); setTimeout(()=>{ const el = document.querySelector('#v-table .skillbar'); if (el){ el.scrollIntoView({block: 'nearest', behavior: 'smooth'}); el.classList.add('flash'); setTimeout(()=>el.classList.remove('flash'), 1200); } }, 60); },
  /* ---------- สถานะของการใช้ทักษะหนึ่งครั้ง ---------- */
  build(t, key, cell, extra){
    const sk = this.skillByKey(t, key); const mech = suParse(sk); const cost = suParseCost(sk ? sk.cost : ''); extra = extra || null; const c = Combat.charOf(t);
    const st = {tokId: t.id, key, sk, mech, cost, cell: null, targets: [], alt: 0, noPay: false, reveal: false, unhide: !!(sk && !sk.npc && !sk.synthetic && sk.category === 'Sorcery' && !mech.passive && !/Hidden|Invisible/.test(String(sk.effect || ''))), amt: cost.parts.map(p=>p.expr), extra,
      ak: suActKinds(sk ? sk.type : ''), act: 'auto', force: false, self: !!(sk && mech.self), otherTg: false, fixed: !!(extra && Array.isArray(extra.targets)), mods: {}, limit: suLimit(sk), custom: {name: '', text: '', fx: 'proj', hue: 'ritual', dmg: '', dtype: 'Fire', save: '', dc: ''}};
    st.costMods = suCostMods(t, c, sk, cost); for (const md of st.costMods) st.mods[md.id] = !!md.on;
    if (st.fixed) st.targets = extra.targets.filter(id=>typeof id === 'string').slice(0, 12);
    return st;
  },
  /* จำนวนครั้งที่ใช้ไปของทักษะที่มีขีดจำกัด: ต่อการต่อสู้เก็บบนหมาก ที่เหลือเก็บในชีทของเจ้าของ */
  limitUsed(t, c, st){ if (!st.limit || !st.sk) return false; const key = 'sk:' + st.sk.nameEn; if (st.limit === 'combat') return !!((t.used || {})[key]); const u = c && c.current && c.current.uses; return !!(u && u[key]); },
  limitMark(t, c, st){ if (!st.limit || !st.sk) return; const key = 'sk:' + st.sk.nameEn; if (st.limit === 'combat'){ if (!Act.on()) return; t.used = (t.used && typeof t.used === 'object') ? t.used : {}; t.used[key] = {n: 1}; return; }
    if (c && Store.isMine(c) && Store.chars.includes(c) && c.current){ c.current.uses = (c.current.uses && typeof c.current.uses === 'object') ? c.current.uses : {}; c.current.uses[key] = {n: 1, per: st.limit}; Store.upsert(c); } },
  limitText(l){ return l === 'combat' ? 'ต่อการต่อสู้' : l === 'short' ? 'ต่อการพักสั้น' : l === 'long' ? 'ต่อการพักยาว' : 'ต่อวัน'; },
  /* Action ที่การใช้ทักษะครั้งนี้ต้องจ่าย และเหตุที่ใช้ไม่ได้ (ถ้ามี) */
  actPlan(t, st){
    const r = Table.room; const enc = Act.on(r); const out = {enc, kind: null, need: {}, block: '', note: '', opts: [], focus: false};
    const c = Combat.charOf(t); if (this.limitUsed(t, c, st)) out.block = `${this.label(st)} ใช้ได้ 1 ครั้ง${this.limitText(st.limit)} และใช้ไปแล้ว`;
    if (!enc) return out;
    const ak = st.ak; const myTurn = Act.isTurn(t, r); const react = !!(st.extra && st.extra.react); const gm = Table.isGM() || Table.localMode;
    if (!st.sk){ out.opts = [['free', 'ไม่ใช้ Action'], ['s', ACT_DEF[Act.kindFor(t, 's')].full], ['b', ACT_DEF[Act.kindFor(t, 'b')].full], ['c', ACT_DEF[Act.kindFor(t, 'c')].full]]; out.kind = st.act === 'auto' ? 'free' : st.act; }
    else if (ak.passive){ out.note = 'ทักษะติดตัว ไม่ใช้ Action'; return out; }
    else if (ak.long){ out.note = 'ทักษะนี้ใช้เวลานานกว่าหนึ่งเทิร์นหรือใช้นอกการต่อสู้ ระบบไม่หัก Action'; return out; }
    else {
      let kinds = ak.kinds.slice(); if (st.sk.npc) kinds = st.sk.npcKind === 'a' ? ['b'] : [];
      if (st.sk.synthetic && st.sk.key === 'basic:grab' && typeof Feats !== 'undefined' && Feats.has(t, 'Primal Grappler')) kinds.push('s');
      const canFree = react || ak.reaction || ak.free || ak.combo || (st.sk.npc && st.sk.npcKind === 'r') || (st.sk.synthetic && typeof Feats !== 'undefined' && Feats.has(t, 'Fist Fighter'));
      for (const k of kinds) out.opts.push([k, ACT_DEF[Act.kindFor(t, k)].full + (Act.left(t, k) > 0 ? '' : ' (ใช้ไปแล้ว)')]);
      if (canFree || gm) out.opts.push(['free', ak.combo ? 'Free Action [คอมโบ] (เป้าติดสภาวะทางกายภาพจากคุณ เทิร์นละครั้ง)' : (ak.reaction || react) ? 'Reaction (ไม่เสีย Action)' : canFree ? 'ไม่เสีย Action ตามเงื่อนไขของความสามารถ' : 'ไม่ใช้ Action (GM อนุญาต)']);
      // ค่าตั้งต้น: Reaction ที่ใช้ตอบโต้หรือใช้นอกเทิร์น = ไม่เสีย Action · คอมโบที่เป้าติดสภาวะทางกายภาพจากผู้ใช้ = Free Action · นอกนั้นใช้ช่องแรกที่ยังเหลือ
      const comboOk = ak.combo && !cbInt(Act.flag(t, 'combo')) && st.targets.some(id=>{ const x = Combat.tok(id); return !!x && (x.conds || []).some(cd=>cd && cd.by === t.id && FT_PHYS.includes(cd.id)); });
      const firstLeft = kinds.find(k=>Act.left(t, k) > 0) || kinds[0] || null;
      const def = react ? 'free' : (!myTurn && (ak.reaction || !kinds.length)) ? 'free' : comboOk ? 'free' : (firstLeft || 'free');
      out.kind = st.act === 'auto' ? def : st.act; if (!out.opts.some(o=>o[0] === out.kind)) out.kind = def;
      if (!out.block && out.kind !== 'free' && !myTurn) out.block = `ยังไม่ถึงเทิร์นของ ${t.name} ทักษะนี้ใช้ ${ACT_DEF[Act.kindFor(t, out.kind)].full} จึงใช้ได้ในเทิร์นของตัวเอง`;
      if (!out.block && out.kind === 'free' && ak.combo && !ak.reaction && !react && cbInt(Act.flag(t, 'combo')) > 0 && !(typeof Feats !== 'undefined' && Feats.has(t, 'Bloodthirsty Beast Stance'))) out.block = 'ใช้ [คอมโบ] แบบ Free Action ไปแล้วในเทิร์นนี้ (ได้เทิร์นละครั้ง)';
    }
    const add = (k)=>{ const kk = Act.kindFor(t, k); out.need[kk] = (out.need[kk] || 0) + 1; };
    if (out.kind && out.kind !== 'free') add(out.kind);
    if (ak.focus && st.sk && !st.sk.npc){ out.focus = true; if (myTurn || !react){ add('s'); if (!out.block && cbInt(Act.flag(t, 'mv')) > 0) out.block = 'ทักษะ [เพ่งสมาธิ] ต้อง Focus ก่อนใช้ และ Focus ไม่ได้ถ้า Maneuver ไปแล้วในเทิร์นนี้'; if (!out.block && !myTurn) out.block = `ทักษะ [เพ่งสมาธิ] ต้อง Focus (Swift Action) จึงใช้ได้ในเทิร์นของตัวเอง`; } }
    const lock = Act.locked(t); if (!out.block && lock) out.block = `${t.name} ${lock}`;
    if (!out.block) for (const [kk, n] of Object.entries(out.need)) if (Act.left(t, kk) < n){ out.block = `${ACT_DEF[kk].full} ของ ${t.name} ${Act.total(t, kk) ? (Act.left(t, kk) ? `เหลือ ${Act.left(t, kk)} แต่ต้องใช้ ${n}` : 'ใช้ไปแล้วในเทิร์นนี้') : 'ไม่มีในเทิร์นนี้'}`; break; }
    const bits = Object.entries(out.need).map(([kk, n])=>ACT_DEF[kk].full + (n > 1 ? ` ×${n}` : '')); out.note = bits.length ? 'จะใช้ ' + bits.join(' และ ') + (out.focus ? ' (รวม Focus ของ [เพ่งสมาธิ])' : '') : 'ไม่เสีย Action';
    return out;
  },
  /* ---------- หน้าต่างยืนยันการใช้ ---------- */
  use(tokId, key, cell, extra){
    const r = Table.room; const t = Combat.tok(tokId); if (!r || !t || !Combat.controls(t)){ toast('ใช้ทักษะของหมากนี้ไม่ได้'); return; }
    const sk = this.skillByKey(t, key); if (key !== '*' && !sk){ toast('ไม่พบทักษะนี้ในข้อมูลของเว็บ'); return; }
    if (sk && sk.npc && sk.npcKind === 'a' && !cbParseNpcAttack(sk.full, sk.effect).save){ // การโจมตีในสแตตบล็อกที่ทอย Attack Roll: เปิดหน้าต่างโจมตีด้วยท่านี้ เป้าคือหมากในช่องที่ปล่อย
      const at = cell ? Combat.visible(r).find(x=>x.x === cell.x && x.y === cell.y && x.id !== t.id && (x.kind !== 'asset' || x.hpMax > 0)) : null; Combat.openAttack(t.id, at ? at.id : null, {pick: sk.full}); return; }
    // v1.29 (ข้อ 10 และ 11): Reaction ที่กดจากแผงบังคับ ระบบพาไปที่การโจมตีที่เกี่ยวข้องเอง ไม่ต้องเลือกเป้า
    //   มีการโจมตีค้างใส่หมากนี้ → เปิดหน้าต่างป้องกันของการโจมตีนั้น (Reaction ที่ระบบรู้จักมีปุ่มกดครั้งเดียว อันอื่นอยู่ในรายการทักษะอื่น)
    //   เพิ่งป้องกันสำเร็จ → Reaction ที่ใช้หลังป้องกัน (ประกายแสง ไอเหมันต์ ม้วนตัวหลบ) ตั้งเป้าให้ตามผลนั้น
    if (sk && !sk.npc && !sk.synthetic && !(extra && extra.react) && suActKinds(sk.type).reaction){
      const own = (o, k)=>Object.prototype.hasOwnProperty.call(o, k); const known = own(CB_REACT, sk.nameEn), post = own(CB_REACT_POST, sk.nameEn); const pend = Combat.pendingOn(t);
      if (post){ const spec = CB_REACT_POST[sk.nameEn]; const cm = Combat.recentClashOn(t, (m)=>spec.fit(m) && !Table.chat.some(x=>x && x.of === m.id && x.kind === 'skill' && x.sk === sk.nameEn));
        if (cm) extra = Object.assign({}, extra || {}, {react: cm.of || true, targets: Combat.postReactTargets(cm, t, spec), of: cm.id});
        else if (!suActKinds(sk.type).kinds.length) toast(`${skTh(sk)} ใช้หลังป้องกันการโจมตีสำเร็จ ปุ่มจะขึ้นในการ์ดผลเมื่อเข้าเงื่อนไข`); }
      else if (pend){ Combat.snooze.delete(pend.id); modal(null); Combat.prompting = null; Combat.openDefense(pend, known ? null : {view: 'skill'}); toast(known ? `${skTh(sk)}: กดปุ่ม ใช้ ในหน้าต่างป้องกัน เป้าหมายคือผู้โจมตีอยู่แล้ว` : `${skTh(sk)}: เลือกจากรายการในหน้าต่างป้องกัน เป้าหมายคือผู้โจมตีอยู่แล้ว`); return; }
      else if (known && !suActKinds(sk.type).kinds.length) toast(`${skTh(sk)} เป็น Reaction ใช้ตอนถูกโจมตี ปุ่มจะขึ้นในหน้าต่างป้องกันเมื่อมีการโจมตีเข้ามา`);
    }
    const st = this.build(t, key, cell, extra);
    this.st = st; this.pick = false; if (!st.fixed && !(st.self && !st.otherTg)) this.aim(st, cell); this.drawPanel();
  },
  /* ตั้งเป้าจากช่องที่ปล่อย: สกิลที่มีพื้นที่เก็บทุกหมากในพื้นที่ (ไม่รวมผู้ใช้) สกิลอื่นเก็บหมากที่อยู่ในช่องนั้น */
  aim(st, cell){
    const r = Table.room; const t = Combat.tok(st.tokId); st.cell = cell || null; st.targets = []; if (!cell || !r || !t) return;
    const vis = Combat.visible(r); const at = vis.find(x=>x.x === cell.x && x.y === cell.y); const n = suAreaCells(st.mech.area);
    if (n > 0) st.targets = vis.filter(x=>x.kind !== 'asset' && x.id !== t.id && cellDist(x, cell) <= n).map(x=>x.id).slice(0, 12);
    else if (at) st.targets = [at.id];
  },
  label(st){ return st.sk ? this.nameOf(st.sk) : (suClean(st.custom.name, 60) || 'ความสามารถ'); },
  hint(text){
    let el = document.getElementById('pickhint'); if (!text){ if (el) el.remove(); document.body.classList.remove('cb-picking'); if (Combat.comp) document.body.classList.add('cb-picking'); return; }
    if (!el){ el = h('div',{id:'pickhint',class:'pickhint',role:'status'}); document.body.append(...cbKids(el)); } clear(el);
    el.append(...cbKids(h('span',{text:text}), h('button',{class:'small ghost',onclick:()=>{ this.pick = false; this.hint(null); if (this.st) this.drawPanel(); },text:'ยกเลิก'}))); document.body.classList.add('cb-picking');
  },
  onTokenClick(t){ if (!this.pick || !this.st) return false; this.pick = false; this.hint(null); this.aim(this.st, {x: t.x, y: t.y}); this.drawPanel(); return true; },
  onCellClick(x, y){ if (!this.pick || !this.st) return false; this.pick = false; this.hint(null); this.aim(this.st, {x, y}); this.drawPanel(); return true; },
  cancel(){ const st = this.st; this.st = null; this.pick = false; this.hint(null); modal(null); if (st && st.extra && st.extra.cancel) st.extra.cancel(); },
  /* ค่าร่ายที่ต้องจ่ายจริงของแต่ละส่วน หลังคิดสิ่งที่มาเปลี่ยนค่าร่าย (ไม่ทอยเต๋า ใช้แสดงผล): คืน [{i, res, expr, minus, half, free}] */
  costPlan(st){
    const on = st.costMods.filter(md=>st.mods[md.id]); const minus = on.reduce((n, md)=>n + (md.minus || 0), 0); const half = on.some(md=>md.half);
    const idx = st.cost.alt ? [st.alt] : st.cost.parts.map((_, i)=>i);
    const freeFor = (res)=> !!st.noPay || on.some(md=>md.free && (md.id === 'soul' ? res === 'san' : md.id === 'yantra' ? res === 'mp' : true));
    return idx.map(i=>{ const p = st.cost.parts[i]; const mp = p.res === 'mp'; return {i, res: p.res, expr: st.amt[i], minus: mp ? minus : 0, half: mp && half, free: freeFor(p.res)}; });
  },
  costFinal(n, pl){ if (pl.free) return 0; let v = Math.max(0, n - pl.minus); if (pl.half) v = Math.floor(v / 2); return v; },
  drawPanel(){
    const st = this.st; const r = Table.room; if (!st || !r) return; const t = Combat.tok(st.tokId); if (!t){ this.cancel(); return; }
    const c = Combat.charOf(t); const d = Combat.derived(c); const sk = st.sk; const mech = st.mech; const redraw = ()=>this.drawPanel(); const gm = Table.isGM() || Table.localMode;
    const box = h('div',{class:'subox'});
    box.append(...cbKids(h('h3',{class:'su-title',text:'⚡ ' + (sk ? this.nameOf(sk) : 'ความสามารถอื่น')})));
    if (sk) box.append(...cbKids(h('div',{class:'gives'}, sk.type ? tag(sk.type.slice(0, 50)) : null, (sk.cost && !/^none$/i.test(sk.cost)) ? tag(sk.cost.slice(0, 50), 'stat') : null, (sk.components && !sk.npc) ? compTag(sk.components, sorceryLv(c)) : null, sk.subcategory ? tag(sk.subcategory.replace(/\s*\(.*$/, ''), 'prop') : null, sk.npc ? tag('สแตตบล็อกของ ' + t.name, 'prop') : null)));
    else {
      const cu = st.custom; const inp = (k, ph, w, max)=>{ const el = h('input',{class:'su-c' + k,placeholder:ph,style:`width:${w}`,maxlength:max}); el.value = cu[k]; el.onchange = ()=>{ cu[k] = el.value.trim(); redraw(); }; return el; };
      const ta = h('textarea',{class:'su-ctext',placeholder:'ผลของความสามารถ (ทุกคนในห้องเห็นข้อความนี้ในแชต)',style:'min-height:60px',maxlength:600}); ta.value = cu.text; ta.onchange = ()=>{ cu.text = ta.value.trim(); };
      box.append(...cbKids(h('div',{class:'row',style:'gap:6px;margin:6px 0'}, inp('name', 'ชื่อความสามารถ', '220px', 60), cbSelect(SU_FX, cu.fx, (v)=>{ cu.fx = v; }, {class:'su-cfx',title:'เอฟเฟกต์ภาพ'}), cbSelect(SU_HUES, cu.hue, (v)=>{ cu.hue = v; }, {class:'su-chue',title:'สีของเอฟเฟกต์'})), ta,
        h('div',{class:'row',style:'gap:6px;margin-top:6px'}, h('span',{class:'dim',text:'ความเสียหาย'}), inp('dmg', 'เช่น 1d6+1', '90px', 12), cbSelect(CB_DTYPES.map(x=>[x, x]), cu.dtype, (v)=>{ cu.dtype = v; }, {class:'su-cdtype'}), h('span',{class:'dim',text:'Saving Throw'}), cbSelect([['', 'ไม่มี'], ...[...STATS, ...suSides()].map(x=>[x, x])], cu.save, (v)=>{ cu.save = v; redraw(); }, {class:'su-csave'}), cu.save ? inp('dc', 'DC', '60px', 2) : null)));
    }
    // เป้าหมาย: ทักษะที่มีผลกับตัวเองไม่มีให้เลือกเป้า · Reaction และการกระทำต่อเนื่องตั้งเป้าให้แล้ว
    const vis = Combat.visible(r); const selfOnly = st.self && !st.otherTg;
    if (selfOnly){ st.targets = []; st.cell = null;
      box.append(...cbKids(h('div',{class:'row su-targets su-self',style:'gap:6px;margin-top:8px;align-items:center'}, h('span',{class:'dim',text:'เป้าหมาย'}), h('span',{class:'tag prop su-tg',text:`${t.name} (ตัวเอง)`}), h('span',{class:'dim',style:'font-size:12px',text:'ทักษะนี้มีผลกับผู้ใช้เอง'}), gm ? h('button',{class:'small ghost su-othertg',title:'GM ให้ทักษะนี้เลือกเป้าหมายอื่นได้',onclick:()=>{ st.otherTg = true; redraw(); },text:'เลือกเป้าอื่น (GM)'}) : null))); }
    else {
      const tg = st.targets.map(id=>vis.find(x=>x.id === id) || (st.fixed ? Combat.tok(id) : null)).filter(Boolean); st.targets = tg.map(x=>x.id);
      const tRow = h('div',{class:'row su-targets' + (st.fixed ? ' su-fixed' : ''),style:'gap:6px;margin-top:8px;align-items:center'}, h('span',{class:'dim',text:'เป้าหมาย'}));
      for (const x of tg) tRow.append(...cbKids(h('span',{class:'tag prop su-tg',dataset:{id:x.id}}, `${x.name}${x.id === t.id ? ' (ตัวเอง)' : ` (${cellDist(t, x) * CELL_M} ม.)`}`, st.fixed ? null : h('button',{class:'cadj',title:'เอาเป้านี้ออก',onclick:()=>{ st.targets = st.targets.filter(id=>id !== x.id); redraw(); },text:'×'}))));
      if (st.fixed){ tRow.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text: tg.length ? 'ระบบตั้งเป้าให้แล้ว' : 'ไม่มีเป้าหมาย'}), gm ? h('button',{class:'small ghost su-unfix',onclick:()=>{ st.fixed = false; redraw(); },text:'แก้เป้า (GM)'}) : null)); }
      else {
        if (!tg.length) tRow.append(...cbKids(h('span',{class:'dim',style:'font-size:12.5px',text: st.cell ? `ช่อง (${st.cell.x},${st.cell.y}) ไม่มีหมาก` : 'ยังไม่ได้เลือก (ใช้กับตัวเองหรือไม่มีเป้าก็กดใช้ได้เลย)'})));
        const rest = vis.filter(x=>!st.targets.includes(x.id) && x.kind !== 'asset');
        if (rest.length) tRow.append(...cbKids(cbSelect([['', '+ เพิ่มเป้า'], ...rest.map(x=>[x.id, `${x.name}${x.id === t.id ? ' (ตัวเอง)' : ''}`])], '', (v)=>{ if (v){ st.targets = [...st.targets, v].slice(0, 12); if (!st.cell){ const x = vis.find(k=>k.id === v); if (x) st.cell = {x: x.x, y: x.y}; } redraw(); } }, {class:'su-addtg'})));
        tRow.append(...cbKids(h('button',{class:'small ghost su-pick',title:'ปิดหน้าต่างนี้ชั่วคราว แล้วคลิกหมากหรือช่องบนแผนที่',onclick:()=>{ this.pick = true; modal(null); this.hint(`🎯 คลิกหมากหรือช่องเป้าหมายของ ${this.label(st)}`); },text:'🎯 เลือกบนแผนที่'})));
      }
      box.append(...cbKids(tRow));
      const area = suAreaCells(mech.area); if (area > 0 && !st.fixed) box.append(...cbKids(h('div',{class:'dim',style:'font-size:12px;margin-top:2px',text:`ทักษะนี้มีพื้นที่ ระบบเก็บหมากที่อยู่ห่างจุดปล่อยไม่เกิน ${area} ช่องมาให้แล้ว เอาออกหรือเพิ่มได้`})));
      if (mech.rangeM){ const far = tg.filter(x=>cellDist(t, x) * CELL_M > mech.rangeM); if (far.length) box.append(...cbKids(h('div',{class:'atkc-note bad su-far',text:`ไกลเกินระยะ ${mech.rangeM} ม. ที่ข้อความของทักษะระบุ: ${far.map(x=>`${x.name} ${cellDist(t, x) * CELL_M} ม.`).join(', ')} ให้ GM ตัดสินว่าใช้ได้ไหม`}))); }
    }
    // Action ที่ใช้
    const ap = this.actPlan(t, st); st.plan = ap;
    if (ap.enc && (ap.opts.length || ap.note)) box.append(...cbKids(h('div',{class:'row su-actrow',style:'gap:6px;margin-top:8px;align-items:center'}, h('span',{class:'dim',text:'ใช้ Action'}), ap.opts.length > 1 ? cbSelect([['auto', 'ตามกฎ'], ...ap.opts], st.act, (v)=>{ st.act = v; redraw(); }, {class:'su-act'}) : null, h('span',{class:'dim su-actnote',style:'font-size:12.5px',text:ap.note}))));
    if (st.limit) box.append(...cbKids(h('div',{class:'dim su-limit',style:'font-size:12px;margin-top:2px',text:`ทักษะนี้ใช้ได้ 1 ครั้ง${this.limitText(st.limit)}${st.limit === 'combat' ? '' : ' ระบบจดไว้ในชีทของเจ้าของ และคืนให้เมื่อพัก'}`})));
    if (ap.block) box.append(...cbKids(h('div',{class:'atkc-note bad su-block',text:ap.block}), gm ? cbCheck('ให้ใช้ได้โดยไม่หัก Action (GM อนุญาต)', st.force, (v)=>{ st.force = v; redraw(); }, {class:'fld chk su-force'}) : null));
    // ค่าร่าย: จ่ายตามที่ข้อความบอก สิ่งที่มาเปลี่ยนค่าร่ายเป็นตัวเลือกให้ติ๊ก (GM แก้จำนวนหรือยกเว้นได้)
    const cost = st.cost; const cRow = h('div',{class:'su-cost',style:'margin-top:8px'}); const editOk = gm || st.costMods.some(md=>md.edit && st.mods[md.id]);
    if (cost.parts.length){
      const have = (res)=> res === 'mp' ? (c && c.current ? (c.current.mp != null ? c.current.mp : (d ? d.mp : null)) : (gm && !t.charId && +t.mpMax > 0 ? cbInt(t.mp) : null)) : res === 'hp' ? t.hp : (t.sanMax ? t.san : null);
      const plan = this.costPlan(st);
      cost.parts.forEach((p, i)=>{ const on = cost.alt ? st.alt === i : true; const hv = have(p.res); const pl = plan.find(x=>x.i === i);
        const pickEl = cost.alt ? (()=>{ const rb = h('input',{type:'radio',name:'su-alt'}); rb.checked = on; rb.onchange = ()=>{ st.alt = i; redraw(); }; return rb; })() : null;
        const amtEl = editOk ? (()=>{ const el = h('input',{class:'su-amt',style:'width:72px',title:'จำนวนที่จะหัก ตัวเลขหรือรูปแบบเต๋า'}); el.value = st.amt[i]; el.disabled = !on || st.noPay; el.onchange = ()=>{ st.amt[i] = el.value.trim(); redraw(); }; return el; })() : h('b',{class:'num su-amtfix',text:String(st.amt[i])});
        const fin = (pl && /^\d+$/.test(String(pl.expr))) ? this.costFinal(+pl.expr, pl) : null; const changed = pl && (pl.free || pl.minus || pl.half);
        cRow.append(...cbKids(h('label',{class:'fld su-costrow' + (on ? '' : ' off')}, pickEl, h('span',{text:'ค่าร่าย'}), amtEl, h('b',{text:SU_RES[p.res]}), (on && changed) ? h('span',{class:'tag ok su-final',text: fin != null ? `จ่ายจริง ${fin} ${SU_RES[p.res]}` : (pl.free ? 'ไม่ต้องจ่าย' : `หลังทอย ลด ${pl.minus}${pl.half ? ' แล้วเหลือครึ่ง' : ''}`)}) : null, hv != null ? h('span',{class:'dim',text:`(มี ${hv})`}) : h('span',{class:'dim',text: p.res === 'mp' ? '(MP อยู่ในชีทของเจ้าของ ระบบหักให้ไม่ได้)' : ''})))); });
      for (const md of st.costMods){ const el = cbCheck(md.label, st.mods[md.id] && !md.spent, (v)=>{ st.mods[md.id] = v; redraw(); }, {class:'fld chk su-mod' + (md.spent ? ' off' : ''),dataset:{mod:md.id}}); if (md.spent) el.querySelector('input').disabled = true; cRow.append(...cbKids(el)); }
      if (cost.other) cRow.append(...cbKids(h('div',{class:'dim',style:'font-size:12px',text:`ข้อความค่าร่ายมีทางเลือกอื่นที่ระบบหักให้ไม่ได้ (${cost.raw.slice(0, 80)}) ถ้าจ่ายทางนั้นให้ GM ยกเว้นค่าร่ายครั้งนี้แล้วหักเองบนชีท`})));
      if (gm) cRow.append(...cbKids(cbCheck('ไม่หักค่าร่ายครั้งนี้ (GM อนุญาต)', st.noPay, (v)=>{ st.noPay = v; redraw(); }, {class:'fld chk su-nopay'})));
    } else if (cost.raw && !/^none$/i.test(cost.raw)) cRow.append(...cbKids(h('div',{class:'dim',style:'font-size:12.5px',text:`ค่าร่าย: ${cost.raw} (ระบบอ่านเป็นตัวเลขไม่ออก หักเองบนชีท)`})));
    box.append(...cbKids(cRow));
    // กลไกที่อ่านได้
    const pv = []; const dcOf = (sv)=>{ const v = suDcValue(sv.dc, c, d, t); return v ? `DC ${v.value}` : `DC ${sv.dc} (ให้ GM บอกค่า)`; };
    for (const sv of mech.saves.slice(0, 1)) pv.push(`เป้าหมายทอย ${sv.stat} Saving Throw (${dcOf(sv)})`);
    for (const cl of mech.clashes.slice(0, 1)) pv.push(`${cl.a} ${cl.kind} ${cl.b}${cl.bAlt ? ' หรือ ' + cl.bAlt : ''}: ผู้ใช้ทอย ${cl.a} เป้าหมายทอย ${cl.b}${cl.bAlt ? ' หรือ ' + cl.bAlt : ''}`);
    for (const dm of mech.dmg.slice(0, 2)) pv.push(`ความเสียหาย ${dm.expr}${dm.mod ? ' + ' + dm.mod : ''} ${dm.type}${mech.half ? ' (ครึ่งเดียวเมื่อ Saving Throw สำเร็จ)' : ''}`);
    for (const hl of mech.heal.slice(0, 1)) pv.push(`ฟื้นฟู ${hl.expr} ${SU_RES[hl.res]}`);
    if (mech.conds.length) pv.push('สภาวะที่ข้อความเอ่ยถึง: ' + mech.conds.map(x=>x.id + (x.lv ? ' ' + x.lv : '')).join(', '));
    if (mech.attack) pv.push(`เป็นการโจมตี${mech.attack === 'melee' ? 'ประชิด' : 'ระยะไกล'}: กดใช้แล้วหน้าต่างโจมตีจะเปิดให้ทอย`);
    if (mech.passive) pv.push('ทักษะติดตัว ทำงานตลอดเวลา การกดใช้คือการประกาศและแสดงเอฟเฟกต์');
    if (st.ak.stance) pv.push('กระบวนท่า: กดใช้แล้วหมากตั้งท่านี้ ผลของท่าเข้าหน้าต่างโจมตีและป้องกันเองจนกว่าจะเปลี่ยนท่า');
    if (pv.length) box.append(...cbKids(h('div',{class:'su-mech'}, h('div',{class:'kicker',text:'สิ่งที่ระบบจะทำต่อ'}), pv.map(x=>h('div',{text:'• ' + x})))));
    if (sk) box.append(...cbKids(h('details',{class:'su-eff',open: true}, h('summary',{text: sk.npc ? 'ข้อความในสแตตบล็อก' : sk.synthetic ? 'กฎของการกระทำนี้' : 'ข้อความของทักษะ'}), sk.flavor ? h('div',{class:'flavor',style:'font-size:12.5px'}, T(sk.flavor)) : null, h('div',{class:'desc',style:'font-size:13px'}, T(sk.effect || '')), ...((sk.npc || sk.synthetic) ? [] : skillRollLines(sk, 'desc', 'font-size:13px')))));
    if (sk && sk.npc) box.append(...cbKids(cbCheck('แสดงข้อความนี้ให้ผู้เล่นเห็นในแชต (ปกติแชตขึ้นแค่ชื่อกับปุ่มทอย)', st.reveal, (v)=>{ st.reveal = v; }, {class:'fld chk su-reveal'})));
    if (Combat.has(t, 'Hidden') || Combat.has(t, 'Invisible') || t.hidden){ // ร่ายเวทแล้วหลุดจากการซ่อนตัวเสมอ (Non เคาะ 16 พ.ย. 2026) GM เท่านั้นที่ยกเว้นได้ · ทักษะที่ไม่ใช่เวท ผู้ใช้ติ๊กเองเมื่อการใช้เปิดเผยตำแหน่ง
      const sorc = !!(sk && !sk.npc && !sk.synthetic && sk.category === 'Sorcery' && !mech.passive); const el = cbCheck(sorc ? 'ร่ายเวทแล้วหลุดจากการซ่อนตัว' + (gm ? ' (GM ยกเว้นได้)' : '') : 'ใช้แล้วหลุดจากการซ่อนตัว (การกระทำนี้เปิดเผยตำแหน่ง)', st.unhide, (v)=>{ st.unhide = v; }, {class:'fld chk su-unhide',title:'เมื่อโจมตีหรือร่ายเวท ตัวละครหลุดจากสถานะซ่อนตัว หมากที่ GM ซ่อนไว้จะถูกเปิดเผย'});
      if (sorc && !gm) el.querySelector('input').disabled = true; box.append(...cbKids(el)); }
    const go = h('button',{class:'primary su-go',onclick:()=>this.cast(),text:'✨ ใช้ทักษะ'}); if (ap.block && !st.force) go.disabled = true;
    box.append(...cbKids(h('div',{class:'row',style:'justify-content:flex-end;gap:8px;margin-top:12px'}, h('button',{class:'ghost su-cancel',onclick:()=>this.cancel(),text:'ยกเลิก'}), go)));
    modal(box);
    const mEl = $('#modal'); if (mEl){ mEl.onclick = ()=>{}; const close = mEl.querySelector('.box > .row:last-child'); if (close && close !== box) close.remove(); if (typeof cbDragBox === 'function') cbDragBox(mEl.querySelector('.box'), '.su-title', Combat); }
  },
  /* หักค่าร่าย: MP อยู่ในชีท (หักได้เฉพาะชีทของตัวเอง) NPC ที่ตั้ง MP ไว้หักจากหมาก · Sanity กับ HP อยู่บนหมาก */
  pay(t, c, d, st){
    const out = {ok: true, paid: [], note: '', mods: st.costMods.filter(md=>st.mods[md.id]).map(md=>md.label.split(':')[0])}; if (!st.cost.parts.length) return out;
    const plan = [];
    for (const pl of this.costPlan(st)){ if (!cbExprOk(pl.expr)){ out.ok = false; out.msg = 'ค่าร่ายต้องเป็นตัวเลขหรือรูปแบบเต๋า เช่น 3 หรือ 1d3'; return out; } const rr = cbRollExpr(pl.expr); const n = this.costFinal(Math.max(0, rr.total), pl); plan.push({res: pl.res, n, text: rr.rolls.length ? rr.text : String(rr.total), free: pl.free}); }
    const npcMp = !t.charId && +t.mpMax > 0;
    for (const p of plan){ if (p.free || !p.n){ p.skip = true; continue; }
      if (p.res === 'mp'){ if (npcMp){ if (cbInt(t.mp) < p.n){ out.ok = false; out.msg = `MP ไม่พอ (มี ${cbInt(t.mp)} ต้องใช้ ${p.n})`; return out; } continue; }
        if (!c || !Store.isMine(c) || !c.current){ out.note = 'MP อยู่ในชีทของเจ้าของ ระบบหักให้ไม่ได้ ให้เจ้าของหักเอง'; p.skip = true; continue; } const have = c.current.mp != null ? c.current.mp : (d ? d.mp : 0); if (have < p.n){ out.ok = false; out.msg = `MP ไม่พอ (มี ${have} ต้องใช้ ${p.n})`; return out; } }
      else if (p.res === 'san'){ if (!t.sanMax){ p.skip = true; continue; } if (cbInt(t.san) < p.n){ out.ok = false; out.msg = `Sanity ไม่พอ (มี ${cbInt(t.san)} ต้องใช้ ${p.n})`; return out; } }
      else if (cbInt(t.hp) < p.n){ out.ok = false; out.msg = `HP ไม่พอ (มี ${cbInt(t.hp)} ต้องใช้ ${p.n})`; return out; }
    }
    for (const p of plan){ if (p.skip) continue;
      if (p.res === 'mp'){ if (npcMp) tokenVitals(t, 'mp', cbInt(t.mp) - p.n); else { const have = c.current.mp != null ? c.current.mp : (d ? d.mp : 0); c.current.mp = have - p.n; Store.upsert(c); } }
      else if (p.res === 'san') tokenVitals(t, 'san', cbInt(t.san) - p.n);
      else tokenVitals(t, 'hp', cbInt(t.hp) - p.n);
      out.paid.push({res: p.res, n: p.n, text: p.text}); }
    return out;
  },
  cast(){ const st = this.st; if (!st) return; const ok = this.castSt(st, true); if (ok === 'gone') this.cancel(); },
  /* ใช้ทักษะตามสถานะ st: ตรวจ Action และขีดจำกัด หักค่าร่าย หัก Action ประกาศในแชต · ui = มีหน้าต่างยืนยันเปิดอยู่ (ปิดให้เมื่อสำเร็จ) คืน true เมื่อใช้ได้ */
  castSt(st, ui){
    const r = Table.room; if (!st || !r) return false; const t = Combat.tok(st.tokId); if (!t) return 'gone';
    const c = Combat.charOf(t); const d = Combat.derived(c); const sk = st.sk; const cu = st.custom; const gm = Table.isGM() || Table.localMode;
    if (!sk && !suClean(cu.name, 60)){ toast('ใส่ชื่อความสามารถก่อน'); return false; }
    if (!sk && cu.dmg && !cbExprOk(cu.dmg)){ toast('ความเสียหายต้องเป็นตัวเลขหรือรูปแบบเต๋า เช่น 2 หรือ 1d6+1'); return false; }
    const ap = this.actPlan(t, st); const forced = !!(ap.block && st.force && gm); if (ap.block && !forced){ toast(ap.block); return false; }
    const paid = this.pay(t, c, d, st); if (!paid.ok){ toast(paid.msg); return false; }
    // หัก Action ธงของเทิร์น ขีดจำกัดจำนวนครั้ง และตัวนับของสิ่งที่เปลี่ยนค่าร่าย
    if (ap.enc && !forced){ for (const [kk, n] of Object.entries(ap.need)) for (let i = 0; i < n; i++) Act.spend(t, kk); if (ap.kind === 'free' && st.ak.combo && !(st.extra && st.extra.react) && !st.ak.reaction) Act.setFlag(t, 'combo', 1); }
    this.limitMark(t, c, st);
    for (const md of st.costMods) if (st.mods[md.id]){ if (md.clear) delete t[md.clear]; if (md.use && c && Store.isMine(c) && Store.chars.includes(c) && c.current){ c.current.uses = (c.current.uses && typeof c.current.uses === 'object') ? c.current.uses : {}; c.current.uses[md.useKey || ('cost:' + md.id + ':' + (sk ? sk.nameEn : ''))] = {n: 1, per: md.use.per}; Store.upsert(c); } }
    const src = sk ? st.mech : {saves: cu.save ? [{stat: cu.save, dc: String(cbInt(cu.dc) || '')}] : [], clashes: [], dmg: cu.dmg ? [{expr: cu.dmg, mod: null, type: cu.dtype}] : [], heal: [], conds: cbFindConds(cu.text).slice(0, 5), half: false, attack: null, area: null, passive: false, reaction: false};
    const vis = Combat.visible(r); const tg = (st.self && !st.otherTg) ? [] : st.targets.map(id=>vis.find(x=>x.id === id) || (st.fixed ? Combat.tok(id) : null)).filter(Boolean).slice(0, 12);
    const mech = {
      saves: src.saves.slice(0, 1).map(sv=>{ const v = suDcValue(sv.dc, c, d, t); return {stat: sv.stat, dc: v ? v.value : null, dcText: v ? v.text : suClean(sv.dc, 60)}; }),
      clashes: src.clashes.slice(0, 1).map(cl=>({a: cl.a, kind: cl.kind, b: cl.b, bAlt: cl.bAlt || null})),
      dmg: src.dmg.slice(0, 2).map(dm=>{ const mv = dm.mod ? suStatMod(dm.mod, c, d, t) : 0; return {expr: dm.expr, mod: dm.mod || null, modVal: mv == null ? 0 : mv, type: dm.type}; }),
      heal: src.heal.slice(0, 1).map(x=>({expr: x.expr, res: x.res})), conds: src.conds.slice(0, 5), half: !!src.half, attack: src.attack || null};
    const label = this.label(st); const self = !tg.length || (tg.length === 1 && tg[0].id === t.id); const cells = suAreaCells(src.area);
    const hue = sk ? fxHueOfSkill(sk) : cu.hue; const kind = sk ? suFxKind(src, self, cells) : cu.fx; const to = st.cell || (tg[0] ? {x: tg[0].x, y: tg[0].y} : {x: t.x, y: t.y});
    const react = st.extra && st.extra.react;
    const hid = Combat.has(t, 'Hidden') || Combat.has(t, 'Invisible') || !!t.hidden; const unhide = hid && !!st.unhide;
    const fx = {k: react ? 'shield' : kind, from: {x: t.x, y: t.y}, to: react ? {x: t.x, y: t.y} : to, hue, cells, floats: [{x: t.x, y: t.y, text: suClean(sk ? skTh(sk) : cu.name, 22), cls: 'info'}]};
    const who = (t.hidden && !unhide) ? 'บางสิ่งที่มองไม่เห็น' : t.name;
    const actBits = ap.enc ? Object.entries(forced ? {} : ap.need).map(([kk, n])=>ACT_DEF[kk].full + (n > 1 ? ` ×${n}` : '')) : [];
    const costNote = [paid.note, (st.noPay && st.cost.parts.length) ? 'GM ยกเว้นค่าร่ายครั้งนี้' : '', paid.mods.length ? 'ค่าร่ายเปลี่ยนจาก ' + paid.mods.join(', ') : '', actBits.length ? 'ใช้ ' + actBits.join(' และ ') : '', forced ? 'GM อนุญาตให้ใช้โดยไม่หัก Action' : ''].filter(Boolean).join(' · ');
    Table.post({kind: 'skill', who, text: `${who} ใช้ ${label}${tg.length ? ' ใส่ ' + tg.map(x=>x.name).join(', ') : ''}`, sk: (sk && !sk.npc && !sk.synthetic) ? sk.nameEn : null, label, hue, caster: {id: t.id, name: who}, targets: tg.map(x=>({id: x.id, name: x.name})), cell: st.cell || null,
      cost: paid.paid, costNote, mech, note: sk ? (sk.synthetic ? suClean(sk.effect, 600) : (sk.npc && st.reveal) ? suClean(sk.effect, 600) : '') : suClean(cu.text, 600), react: react || null, of: (st.extra && typeof st.extra.of === 'string') ? st.extra.of : null, fx, gmOnly: false});
    if (sk && st.ak.stance){ if (!(t.stance && t.stance.id === sk.nameEn)) delete t.rhythm; t.stance = {id: sk.nameEn, th: skTh(sk)}; if (!t.hidden) Table.post({kind: 'sys', who: '', text: `${t.name} ตั้งกระบวนท่า ${skTh(sk)}`}); }
    if (unhide){ for (const idc of ['Hidden', 'Invisible']){ const hc = (t.conds || []).find(x=>x.id === idc); if (hc) removeCond(t, r, hc, 'ร่ายเวทแล้ว'); } if (t.hidden){ t.hidden = false; Table.post({kind: 'sys', who: '', text: `${t.name} ปรากฏตัวที่ (${t.x},${t.y}) หลังร่ายเวทจากการซ่อนตัว`}); } }
    Table.save();
    const extra = st.extra; if (ui){ this.st = null; this.pick = false; this.hint(null); modal(null); }
    if (extra && extra.done){ extra.done(); return true; }
    if (mech.attack && !react){ const dm = mech.dmg[0]; const target = tg.find(x=>x.id !== t.id); // Reaction ที่ใช้ตอบโต้การโจมตีไม่เปิดหน้าต่างโจมตีเอง (การโจมตีสวนมีปุ่มของมันในการ์ดผล)
      const weapon = dm ? Object.assign(cbParseWeapon(label, ''), {found: true, src: 'skill', dmg: dm.modVal ? (/d/i.test(dm.expr) ? `${dm.expr}${signed(dm.modVal)}` : String(cbInt(dm.expr) + dm.modVal)) : dm.expr, dtypes: [dm.type === 'Sanity' ? 'Physical' : dm.type], physical: cbIsPhysical(dm.type), statKind: 'none', conds: mech.conds, hits: [], text: sk ? (sk.effect || '') : cu.text}) : null;
      setTimeout(()=>Combat.openAttack(t.id, target ? target.id : null, {weapon, mode: mech.attack, skill: label}), 60); }
    return true;
  },
  /* ใช้ทักษะทันทีโดยไม่เปิดหน้าต่างยืนยัน (Reaction ที่ระบบรู้จักในหน้าต่างป้องกัน): ค่าร่ายที่มีทางเลือกหรือสิ่งที่เปลี่ยนค่าร่ายใช้ค่าตั้งต้น คืน true เมื่อใช้ได้ */
  instant(t, sk, extra){ if (!t || !sk) return false; const st = this.build(t, sk.nameEn, null, extra || {}); return this.castSt(st, false) === true; },
  /* ฝ่ายรับใช้ทักษะตอบโต้การโจมตี (เรียกจากหน้าต่างป้องกัน): เป้าหมายคือผู้โจมตี ไม่ต้องเลือก */
  quick(t, sk, opts, done, cancel){ opts = opts || {}; this.use(t.id, sk.nameEn, null, {react: opts.react || true, targets: Array.isArray(opts.targets) ? opts.targets : [], done, cancel}); },
  onMessage(m){ if (m && m.fx) Fx.play(m.fx); },

  /* ---------- การ์ดในแชตและปุ่มต่อเนื่อง ---------- */
  follow(m){ return Table.chat.filter(x=>x && x.of === m.id); },
  mechOf(m){
    const raw = (m && m.mech && typeof m.mech === 'object') ? m.mech : {}; const arr = (v)=>Array.isArray(v) ? v : []; const conds = cbCondNames();
    return {
      saves: arr(raw.saves).slice(0, 1).filter(s=>s && suStatKnown(String(s.stat))).map(s=>({stat: String(s.stat), dc: (typeof s.dc === 'number' && isFinite(s.dc)) ? Math.max(0, Math.min(40, Math.round(s.dc))) : null, dcText: suClean(s.dcText, 60)})),
      clashes: arr(raw.clashes).slice(0, 1).filter(c=>c && suStatKnown(String(c.a)) && suStatKnown(String(c.b)) && (c.kind === 'Clash' || c.kind === 'Challenge')).map(c=>({a: String(c.a), b: String(c.b), kind: c.kind, bAlt: (c.bAlt && suStatKnown(String(c.bAlt)) && String(c.bAlt) !== String(c.b)) ? String(c.bAlt) : null})),
      dmg: arr(raw.dmg).slice(0, 2).filter(x=>x && cbExprOk(x.expr)).map(x=>({expr: String(x.expr).trim(), mod: x.mod ? suClean(x.mod, 16) : null, modVal: Math.max(-20, Math.min(20, cbInt(x.modVal))), type: x.type === 'Sanity' ? 'Sanity' : (CB_DTYPES.includes(cbNormType(x.type)) ? cbNormType(x.type) : 'Physical')})),
      heal: arr(raw.heal).slice(0, 1).filter(x=>x && cbExprOk(x.expr) && SU_RES[x.res]).map(x=>({expr: String(x.expr).trim(), res: x.res})),
      conds: arr(raw.conds).slice(0, 5).filter(x=>x && conds.includes(x.id)).map(x=>({id: x.id, lv: x.lv ? Math.max(1, Math.min(20, cbInt(x.lv, 1))) : null})),
      half: !!raw.half, attack: raw.attack === 'melee' || raw.attack === 'ranged' ? raw.attack : null};
  },
  card(m, time){
    const mech = this.mechOf(m); const fol = this.follow(m); const sk = (m.sk && Object.prototype.hasOwnProperty.call(SKILL_BY_NAME, m.sk)) ? SKILL_BY_NAME[m.sk] : null;
    const targets = (Array.isArray(m.targets) ? m.targets : []).slice(0, 12).filter(x=>x && typeof x.id === 'string'); const caster = m.caster && typeof m.caster.id === 'string' ? Combat.tok(m.caster.id) : null;
    const el = h('div',{class:'e skillmsg'}); el.style.setProperty('--fx', FX_HUE[m.hue] || FX_HUE.ritual);
    el.append(...cbKids(h('div',{class:'row',style:'gap:6px'}, chatWho(m), h('span',{class:'dim',text:'ใช้'}), h('b',{class:'sk-name',text: sk ? skLabel(sk) : suClean(m.label, 80)}), targets.length ? h('span',{class:'dim',text:'→ ' + targets.map(x=>suClean(x.name, 40)).join(', ')}) : null, m.react ? tag('ตอบโต้', 'prop') : null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time}))));
    const paid = (Array.isArray(m.cost) ? m.cost : []).slice(0, 4).filter(p=>p && SU_RES[p.res]).map(p=>`${cbInt(p.n)} ${SU_RES[p.res]}${/\[/.test(String(p.text || '')) ? ' (' + suClean(p.text, 40) + ')' : ''}`);
    if (paid.length || m.costNote) el.append(...cbKids(h('div',{class:'dim',style:'font-size:12px',text:(paid.length ? 'หักค่าร่าย ' + paid.join(' และ ') : '') + (m.costNote ? (paid.length ? ' · ' : '') + suClean(m.costNote, 120) : '')})));
    if (sk) el.append(...cbKids(h('details',{class:'cp-d'}, h('summary',{text:'ข้อความของทักษะ'}), h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect || '')), ...skillRollLines(sk, 'desc', 'font-size:12px'))));
    else if (m.note) el.append(...cbKids(h('div',{class:'desc',style:'font-size:12.5px',text:suClean(m.note, 600)})));
    const label = sk ? skTh(sk) : suClean(m.label, 60);
    // Clash / Challenge: ฝั่งผู้ใช้ทอยหนึ่งครั้ง ใช้เทียบกับทุกเป้า
    const cl = mech.clashes[0]; let aRoll = null;
    if (cl){ aRoll = fol.find(x=>x.step === 'clashA') || null; const row = h('div',{class:'row sk-follow',style:'gap:6px;margin-top:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:`${cl.a} ${cl.kind} ${cl.b}`}));
      if (aRoll) row.append(...cbKids(tag(`ผู้ใช้ทอยได้ ${cbInt(aRoll.total)}`, 'stat')));
      else if (caster && Combat.controls(caster)) row.append(...cbKids(this.modeSel(m.id + '|A', this.unbDis(caster, cl.a)), h('button',{class:'small primary sk-clasha',onclick:()=>this.rollStat(m, caster, cl.a, null, 'clashA', null, `${cl.a} ${cl.kind} · ${label}`),text:`🎲 ทอย ${cl.a} (ผู้ใช้)`})));
      else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:'รอผู้ใช้ทักษะทอย'})));
      el.append(...cbKids(row)); }
    for (const tg of targets){
      const t = Combat.tok(tg.id); const can = !!t && Combat.controls(t); const row = h('div',{class:'row sk-follow',style:'gap:6px;margin-top:4px;align-items:center',dataset:{tg:tg.id}}, h('b',{style:'font-size:12.5px',text:suClean(tg.name, 40)}));
      const sv = mech.saves[0]; let saved = null;
      if (sv){ const done = fol.find(x=>x.step === 'save' && x.tg === tg.id); if (done){ saved = /res-(full|crit)/.test((done.judge && done.judge.cls) || '') && !/Failure|ล้มเหลว/.test((done.judge && done.judge.text) || ''); row.append(...cbKids(tag(`${sv.stat} ST ${cbInt(done.total)}: ${sv.dc == null ? 'รอ GM ตัดสิน' : (saved ? 'ผ่าน' : 'ไม่ผ่าน')}`, sv.dc == null ? '' : (saved ? 'ok' : 'neg')))); if (sv.dc == null) saved = null; }
        else if (can) row.append(...cbKids(this.modeSel(m.id + '|' + tg.id), h('button',{class:'small primary sk-save',onclick:()=>this.rollStat(m, t, sv.stat, sv.dc, 'save', tg.id, `${sv.stat} Saving Throw · ต้าน ${label}`),text:`🎲 ${sv.stat} Saving Throw${sv.dc != null ? ' (DC ' + sv.dc + ')' : ''}`})));
        else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`รอทอย ${sv.stat} Saving Throw${sv.dc != null ? ' (DC ' + sv.dc + ')' : ''}`}))); }
      if (cl){ const bRoll = fol.find(x=>x.step === 'clashB' && x.tg === tg.id);
        if (bRoll && aRoll){ const av = cbInt(aRoll.total), bv = cbInt(bRoll.total); const aWin = av > bv || (av === bv && cl.kind === 'Clash'); row.append(...cbKids(tag(`ต้านได้ ${bv} ปะทะ ${av}: ${aWin ? 'ผู้ใช้ชนะ' : 'เป้าหมายชนะ'}${av === bv ? ' (เท่ากัน)' : ''}`, aWin ? 'neg' : 'ok'))); }
        else if (bRoll) row.append(...cbKids(tag(`ต้านได้ ${cbInt(bRoll.total)}`, 'stat')));
        else if (can) row.append(...cbKids(this.modeSel(m.id + '|' + tg.id + '|B', this.unbDis(t, cl.b)), h('button',{class:'small primary sk-clashb',onclick:()=>this.rollStat(m, t, cl.b, null, 'clashB', tg.id, `${cl.b} ต้าน ${cl.kind} · ${label}`),text:`🎲 ทอย ${cl.b}`}), cl.bAlt ? h('button',{class:'small primary sk-clashb sk-clashb2',title:'ผู้ถูกท้าเลือกค่าที่ใช้ต้านได้',onclick:()=>this.rollStat(m, t, cl.bAlt, null, 'clashB', tg.id, `${cl.bAlt} ต้าน ${cl.kind} · ${label}`),text:`🎲 หรือทอย ${cl.bAlt}`}) : null));
        else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`รอทอย ${cl.b}`}))); }
      mech.dmg.forEach((dm, i)=>{ const done = fol.find(x=>x.step === 'dmg' && x.tg === tg.id && x.idx === i); const txt = `${dm.expr}${dm.modVal ? signed(dm.modVal) : ''} ${dm.type}`;
        if (done) row.append(...cbKids(tag(`รับแล้ว ${cbInt(done.n)} ${dm.type}`, 'neg'))); else if (can && !mech.attack) row.append(...cbKids(h('button',{class:'small sk-dmg' + (saved === true && !mech.half ? ' ghost' : ''),onclick:()=>this.dmgModal(m, t, dm, i, saved === true && mech.half, label),text:`💥 ${txt}`}))); });
      mech.heal.forEach((hl, i)=>{ const done = fol.find(x=>x.step === 'heal' && x.tg === tg.id && x.idx === i); if (done) row.append(...cbKids(tag(`ฟื้นฟูแล้ว ${cbInt(done.n)} ${SU_RES[hl.res]}`, 'ok'))); else if (can && hl.res !== 'mp') row.append(...cbKids(h('button',{class:'small sk-heal',onclick:()=>this.heal(m, t, hl, i, label),text:`✚ ฟื้นฟู ${hl.expr} ${SU_RES[hl.res]}`}))); });
      if (can) for (const cd of mech.conds){ const key = m.id + '|' + tg.id + '|' + cd.id; const b = h('button',{class:'small ghost sk-cond',dataset:{cond:cd.id},disabled: Combat.done.has(key),onclick:()=>{ if (Combat.done.has(key)) return; Combat.done.add(key); b.disabled = true; if (!Combat.applyHitCond(t, Table.room, (caster && caster.id !== t.id) ? caster : null, cd.id, cd.lv || 1, {})){ Combat.done.delete(key); b.disabled = false; toast('ติดสถานะนี้อยู่แล้ว'); } },text:`${condIcon(cd.id)} ${cd.id}${cd.lv ? ' ' + cd.lv : ''}`}); row.append(...cbKids(b)); }
      if (row.children.length > 1) el.append(...cbKids(row));
    }
    if (mech.attack) el.append(...cbKids(h('div',{class:'dim',style:'font-size:12px;margin-top:3px',text:'ทักษะนี้เป็นการโจมตี ผลดูจากการทอยโจมตีที่ตามมา'})));
    return el;
  },
  modeSel(key, def){ if (def && this.modes[key] === undefined) this.modes[key] = def; const el = cbSelect([['normal', 'ปกติ'], ['adv', 'Advantage'], ['dis', 'Disadvantage']], this.modes[key] || 'normal', (v)=>{ this.modes[key] = v; }, {class:'sk-mode',title:'โหมดการทอยครั้งนี้'}); el.dataset.key = key; return el; },
  /* Unbalanced: การทอย Challenge หรือ Clash ที่ใช้ STR หรือ AGI ติด Disadvantage (ไฟล์แกน บทสภาวะ) ตั้งโหมดให้เอง แก้ได้ */
  unbDis(t, stat){ return (t && (stat === 'STR' || stat === 'AGI') && Combat.has(t, 'Unbalanced')) ? 'dis' : null; },
  /* ถามตัวบวกเมื่อไม่มีชีทให้อ่าน (NPC หรือชีทที่เจ้าของแชร์เฉพาะค่าหลัก) */
  askMod(title){
    return new Promise(resolve=>{ const inp = h('input',{type:'number',class:'su-askmod',style:'width:90px',placeholder:'0'}); inp.value = '0';
      const ok = h('button',{class:'primary su-askok',onclick:()=>{ modal(null); resolve(cbInt(inp.value)); },text:'ทอย'});
      modal(h('div',{class:'pickbox'}, h('h3',{text:title}), h('p',{class:'desc',text:'ระบบอ่านค่านี้ของหมากไม่ได้ (ไม่มีชีท หรือเป็นค่าบุคลิกภาพของ NPC) ใส่ตัวบวกของการทอยครั้งนี้ (ไม่มีให้ใส่ 0)'}), h('div',{class:'row',style:'justify-content:center;gap:8px'}, h('span',{text:'2d6 +'}), inp, ok)));
      const mEl = $('#modal'); if (mEl){ mEl.onclick = ()=>{}; const close = mEl.querySelector('.box > .row:last-child'); if (close) close.querySelector('button').onclick = ()=>{ modal(null); resolve(null); }; } });
  },
  rollStat(m, t, stat, dc, step, tgId, text){
    const key = step === 'clashA' ? m.id + '|A' : step === 'clashB' ? m.id + '|' + tgId + '|B' : m.id + '|' + tgId; const mode = this.modes[key] || 'normal';
    if (this.follow(m).some(x=>x.step === step && (tgId == null || x.tg === tgId))){ toast('ทอยรายการนี้ไปแล้ว'); return; }
    Table.guardedRoll(t.name, async ()=>{
      const c = Combat.charOf(t); const d = Combat.derived(c); let mod = suStatMod(stat, c, d, t);
      if (mod == null){ mod = await this.askMod(`${t.name}: ${text}`); if (mod == null) return; }
      if (this.follow(m).some(x=>x.step === step && (tgId == null || x.tg === tgId))){ toast('มีคนทอยรายการนี้ไปก่อนแล้ว'); return; }
      const rr = roll2d6(mode); const total = rr.sum + mod; const j = judge(total, rr, dc);
      Table.post({kind: 'roll', fixedId: `${step}-${m.id}${tgId ? '-' + tgId : ''}`, who: t.hidden ? 'บางสิ่งที่มองไม่เห็น' : t.name, text, roll: {dice: rr.dice, kept: rr.kept, keptIdx: rr.keptIdx, sum: rr.sum, crit: rr.crit, double: rr.double, mode}, mod, pm: 0, total, judge: j, dc: dc != null ? dc : null, gmOnly: false, of: m.id, tg: tgId || null, step});
    }, text);
  },
  /* ความเสียหายของทักษะที่ไม่ได้ทอยโจมตี: ไม่มีตำแหน่งที่โดนจึงหักด้วยเกราะลำตัว (Non เคาะ 15 พ.ย. 2026) เลือกส่วนอื่นหรือไม่หักเกราะได้
   * กฎลด Toughness 1 ในไฟล์แกนเขียนไว้กับการโจมตีที่ป้องกันด้วย Parry หรือ Evade ไม่สำเร็จ ที่นี่จึงเป็นตัวเลือกให้ GM ติ๊กเอง */
  dmgModal(m, t, dm, idx, half, label){
    const rr = cbRollExpr(dm.expr); const total = Math.max(0, rr.total + dm.modVal); const sanity = dm.type === 'Sanity'; const physical = cbIsPhysical(dm.type);
    const st = {n: total, half: !!half, part: sanity ? 'none' : 'torso', weak: false, tough: false};
    const parts = [['torso', 'ลำตัว (ทักษะที่ไม่มีตำแหน่งที่โดน)'], ...DATA.meta.bodyParts.filter(([k])=>k !== 'torso').map(([k, l])=>[k, l]), ['none', 'ไม่หักเกราะ (ความเสียหายจาก Stack หรือผลที่ข้ามเกราะ)']];
    const box = h('div',{class:'pickbox dmgbox'});
    const draw = ()=>{ clear(box); const fin = st.half ? Math.floor(st.n / 2) : st.n;
      box.append(...cbKids(h('h3',{text:`💥 ${t.name} รับความเสียหายจาก ${label}`}), h('p',{class:'desc',text:`${rr.rolls.length ? `${dm.expr} [${rr.rolls.join(',')}]` : rr.total}${dm.modVal ? ` ${signed(dm.modVal)} ${dm.mod || ''}` : ''}${(rr.rolls.length || dm.modVal) ? ` = ${total}` : ''} ${dm.type}`}),
        h('div',{class:'row',style:'justify-content:center;gap:10px'}, h('label',{class:'fld'}, h('span',{text:'จำนวน'}), cbNum(st.n, (v)=>{ st.n = Math.max(0, v || 0); draw(); }, {class:'dm-n',style:'width:70px',min:0})), cbCheck('ครึ่งเดียว (ปัดลง)', st.half, (v)=>{ st.half = v; draw(); }, {class:'fld chk dm-half'}), sanity ? null : cbCheck('แพ้ทาง ×2', st.weak, (v)=>{ st.weak = v; draw(); }, {class:'fld chk dm-weak'})),
        sanity ? null : h('div',{class:'row',style:'justify-content:center;gap:8px;margin-top:8px'}, h('span',{class:'dim',text:'หักเกราะที่'}), cbSelect(parts, st.part, (v)=>{ st.part = v; draw(); }, {class:'dm-part',title: physical ? 'โดนชนิดในวงเล็บของค่าเกราะหักเกราะหลักบวกเกราะรอง ชนิดอื่นหักเกราะหลัก' : 'ความเสียหายเวทหักเกราะหลักบวก Sorceries Resistance ของส่วนที่เลือก'})),
        (sanity || st.part === 'none') ? null : h('div',{class:'row',style:'justify-content:center;margin-top:6px'}, cbCheck('ลด Toughness ของส่วนนี้ 1 ด้วย (GM ตัดสินว่านับเป็นการโจมตีที่โดน)', st.tough, (v)=>{ st.tough = v; }, {class:'fld chk dm-tough',title:'เกราะที่หักความเสียหายจนเหลือ 0 ทำให้ส่วนนั้นไม่เสีย Toughness'})),
        h('div',{class:'row',style:'justify-content:center;gap:8px;margin-top:12px'}, h('button',{class:'primary dm-ok',onclick:()=>{ modal(null); this.applyDmg(m, t, dm, idx, fin, st, label); },text: sanity ? `ลด Sanity ${fin}` : `ลงความเสียหาย ${fin}`})))); };
    draw(); modal(box);
  },
  applyDmg(m, t, dm, idx, n, st, label){
    const r = Table.room; if (!r || !Combat.tok(t.id)) return; if (this.follow(m).some(x=>x.step === 'dmg' && x.tg === t.id && x.idx === idx)){ toast('ความเสียหายรายการนี้ลงไปแล้ว'); return; }
    let text, got = n;
    if (dm.type === 'Sanity'){ const s0 = cbInt(t.san); const s1 = Math.max(0, s0 - n); if (t.sanMax) tokenVitals(t, 'san', s1); text = `${t.name} เสีย Sanity ${n} จาก ${label}${t.sanMax ? `: Sanity ${s0} → ${s1}` : ''}`; }
    else { const part = (st.part && st.part !== 'none') ? st.part : null;
      const res = Combat.damage(t, {raw: n, dtype: dm.type, physical: cbIsPhysical(dm.type), part, noArmor: !part, viaTorso: part === 'torso', weak: st.weak}); got = res.fin; const more = [];
      if (part && st.tough){ if (res.zeroed) more.push(`เกราะรับความเสียหายไว้หมด Toughness ของ${partLabel(part)}ไม่ลด`); else { const row = Combat.toughHit(t, res.c, res.tmax, part, 1, ''); if (row) more.push(Combat.toughLine(row)); } }
      text = `${t.name} รับ ${res.fin} ${dm.type} จาก ${label}: ${[...res.lines, ...more].join(' · ')}`;
      const stun = (t.conds || []).find(c=>c.id === 'Stunned'); if (stun && res.hp1 < res.hp0) setTimeout(()=>removeCond(t, r, stun, 'เสีย HP'), 0); }
    t.vitalsAt = Date.now(); Table.save();
    Table.post({kind: 'sys', fixedId: `dmg-${m.id}-${t.id}-${idx}`, who: '', text, of: m.id, tg: t.id, step: 'dmg', idx, n: got, fx: {k: 'burst', to: {x: t.x, y: t.y}, hue: fxHueOfDamage(dm.type), floats: [{x: t.x, y: t.y, text: `−${got}`, cls: 'dmg'}]}});
  },
  heal(m, t, hl, idx, label){
    const r = Table.room; if (!r) return; if (this.follow(m).some(x=>x.step === 'heal' && x.tg === t.id && x.idx === idx)){ toast('ฟื้นฟูรายการนี้ไปแล้ว'); return; }
    const rr = cbRollExpr(hl.expr); const n = Math.max(0, rr.total); const key = hl.res === 'san' ? 'san' : 'hp'; const max = key === 'san' ? (t.sanMax || 0) : (t.hpMax || 0); const v0 = cbInt(t[key]); const v1 = max ? Math.min(max, v0 + n) : v0 + n;
    tokenVitals(t, key, v1); Table.save();
    Table.post({kind: 'sys', fixedId: `heal-${m.id}-${t.id}-${idx}`, who: '', text: `${t.name} ฟื้นฟู ${SU_RES[hl.res]} ${rr.rolls.length ? rr.text : n} จาก ${label}: ${v0} → ${v1}`, of: m.id, tg: t.id, step: 'heal', idx, n: v1 - v0, fx: {k: 'heal', to: {x: t.x, y: t.y}, hue: 'heal', floats: [{x: t.x, y: t.y, text: `+${v1 - v0}`, cls: 'heal'}]}});
  },
  afterRender(){ if (this.pick && !this.st){ this.pick = false; this.hint(null); } },
};
