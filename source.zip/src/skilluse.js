/* ===== v1.28 (Non สั่ง 13 พ.ย. 2026 ต่อบนฐาน v1.27 เมื่อ 16 พ.ย. 2026): ลาก Skill และ Sorcery ลงใช้ในโต๊ะเล่น =====
 * แถบสกิลอยู่ใต้แผนที่ ลากป้ายสกิลไปปล่อยบนหมากหรือช่อง (หรือคลิกแล้วเลือกเป้า) → หน้าต่างยืนยัน → หักค่าร่าย ประกาศในแชต และเล่นเอฟเฟกต์ให้ทุกคนในห้องเห็น
 * ระบบอ่านกลไกที่เขียนเป็นแบบแผนในข้อความของสกิล (Saving Throw กับ DC · Clash / Challenge · ความเสียหาย · ฟื้นฟู · สภาวะ · Melee / Range Attack) แล้วทำเป็นปุ่มในการ์ดของแชต
 * กลไกที่ข้อความเขียนเป็นเงื่อนไขเฉพาะจะยังเป็นข้อความให้ GM ตัดสิน · ข้อความที่มาจากแชตถือว่าไม่น่าไว้ใจ ทุกค่าถูกตรวจชนิดและความยาวก่อนใช้
 * NPC ที่มีสแตตบล็อก (v1.27) ได้ป้ายจากการโจมตี Reaction และพฤติกรรมของมันเอง ข้อความของสแตตบล็อกเป็นของ GM จึงไม่ลงแชตเว้นแต่ GM ติ๊กให้แสดง
 * ความเสียหายของทักษะที่ไม่มีตำแหน่งที่โดนหักด้วยเกราะลำตัว ความเสียหายจาก Stack ไม่หักเกราะ (Non เคาะ 15 พ.ย. 2026) */

/* ---------- ตัวอ่านข้อความของสกิล ---------- */
function suSides(){ if (!suSides.list) suSides.list = DATA.meta.personality.flatMap(ax=>[ax.left, ax.right]); return suSides.list; }
function suStatKnown(name){ return STATS.includes(name) || suSides().includes(name) || ['Sight','Might','Reflex'].includes(name); }
function suStatMod(name, c, d, t){
  name = String(name || '').trim();
  if (c && d){
    if (STATS.includes(name)) return d.mod[name];
    if (name === 'Sight') return d.sight; if (name === 'Might') return d.might; if (name === 'Reflex') return d.reflex;
    if (suSides().includes(name)){ try { return persMod(c, name); } catch(e){ return null; } }
    return null;
  }
  // NPC ที่ไม่มีชีท: ค่าพลังดัดแปลงบนหมาก (ไม่ได้ตั้ง = 0) และค่าพลังรองจากสูตรเดียวกับผู้เล่น · ค่าบุคลิกภาพไม่มีให้อ่าน
  const nd = (t && typeof Combat !== 'undefined') ? Combat.npcDer(t) : null; if (!nd) return null;
  if (STATS.includes(name)) return cbInt((t.mods || {})[name]);
  if (name === 'Sight') return nd.sight; if (name === 'Might') return nd.might; if (name === 'Reflex') return nd.reflex;
  return null;
}
/* DC ที่เขียนเป็นสูตร เช่น "8 + Order Mod." · "6 + Logic Mod. ของคุณ" · "10" · "2d6 + Chaos" คิดจากชีทของผู้ใช้ทักษะ อ่านไม่ออกคืน null */
function suDcValue(txt, c, d, t){
  const s = String(txt || '').replace(/ของคุณ|ของผู้ร่าย[^+]*/g, '').trim(); let m = /^(\d{1,2})$/.exec(s); if (m) return {value: +m[1], text: m[1]};
  m = /^(?:(\d+d\d+|\d{1,2})\s*\+\s*)?([A-Za-z]+)(?:\s*Mod\.?)?$/.exec(s); if (!m) return null;
  const mod = suStatMod(m[2], c, d, t); if (mod == null) return null; let base = 0, btxt = '';
  if (m[1]){ if (/d/.test(m[1])){ const r = cbRollExpr(m[1]); base = r.total; btxt = r.text; } else { base = +m[1]; btxt = m[1]; } }
  return {value: base + mod, text: `${btxt ? btxt + ' ' : ''}${mod < 0 ? '-' : '+'}${Math.abs(mod)} ${m[2]}`};
}
function suParseCost(cost){
  const raw = String(cost || '').trim(); const parts = []; const rx = /(\d+d\d+(?:\s*\+\s*\d+)?|\d+)\s*(MP|Sanity|HP)/g; let m;
  while ((m = rx.exec(raw)) && parts.length < 4) parts.push({expr: m[1].replace(/\s+/g, ''), res: m[2] === 'MP' ? 'mp' : m[2] === 'HP' ? 'hp' : 'san'});
  return {raw, parts, alt: parts.length > 1 && /หรือ|\/|แต่/.test(raw)};
}
const SU_RES = {mp: 'MP', san: 'Sanity', hp: 'HP'};
function suParse(sk){
  if (!sk) return {saves: [], clashes: [], checks: [], dmg: [], heal: [], conds: [], tough: null, attack: null, rangeM: null, area: null, passive: false, reaction: false, half: false};
  const eff = String(sk.effect || '').replace(/\\/g, ''); const type = String(sk.type || ''); let x;
  const ck = sk.npc ? null : sk.nameEn; if (!suParse.cache) suParse.cache = new Map();
  if (ck){ const hit = suParse.cache.get(ck); if (hit && hit.eff === eff && hit.type === type) return hit.m; }
  const m = {saves: [], clashes: [], checks: [], dmg: [], heal: [], conds: [], tough: null, attack: null, rangeM: null, area: null, passive: /Passive/i.test(type), reaction: /Reaction/i.test(type), half: /สำเร็จ[^.]{0,40}ครึ่ง/.test(eff)};
  const rxS = /([A-Za-z][A-Za-z&' ]*?) Saving Throw \(DC ?=? ?([^)]*)\)/g; while ((x = rxS.exec(eff)) && m.saves.length < 3) m.saves.push({stat: x[1].trim(), dc: x[2].trim()});
  const rxC = /([A-Za-z][A-Za-z&']*) (Clash|Challenge) ([A-Za-z][A-Za-z&']*)/g; while ((x = rxC.exec(eff)) && m.clashes.length < 2) m.clashes.push({a: x[1], kind: x[2], b: x[3]});
  const rxK = /([A-Za-z][A-Za-z&' ()]*?) Check \(DC ?=? ?([^)]*)\)/g; while ((x = rxK.exec(eff)) && m.checks.length < 3) m.checks.push({stat: x[1].trim(), dc: x[2].trim()});
  const rxD = /(\d+d\d+|\d+)\s*(?:\+\s*([A-Za-z]+)(?: Mod\.?)?\s*)?([A-Z][A-Za-z]+) (?:Damage|DMG)|(\d+d\d+|\d+)\s*PDMG/g;
  while ((x = rxD.exec(eff)) && m.dmg.length < 4){ if (x[4]){ m.dmg.push({expr: x[4], mod: null, type: 'Physical'}); continue; } if (/^Tough/.test(x[3])){ if (!m.tough) m.tough = x[1]; continue; } if (x[3] === 'All') continue; m.dmg.push({expr: x[1], mod: x[2] || null, type: x[3] === 'Sanity' ? 'Sanity' : cbNormType(x[3])}); }
  const rxH = /ฟื้นฟู\s*(?:(HP|MP|Sanity)\s*)?(\d+d\d+(?:\s*\+\s*\d+)?|\d+)\s*(HP|MP|Sanity)?/g; while ((x = rxH.exec(eff)) && m.heal.length < 2){ const res = x[1] || x[3]; if (!res) continue; m.heal.push({expr: x[2].replace(/\s+/g, ''), res: res === 'MP' ? 'mp' : res === 'HP' ? 'hp' : 'san'}); }
  const am = /(?:^|ทำการ\s*|ทำ\s*|ด้วยการ\s*)(Melee|Rang(?:e|ed)) Attack/.exec(eff); if (am) m.attack = am[1] === 'Melee' ? 'melee' : 'ranged';
  m.conds = cbFindConds(eff).slice(0, 5);
  const rg = /ระยะ(?:ไม่เกิน)?\s*(\d+)\s*เมตร/.exec(eff); if (rg) m.rangeM = +rg[1];
  const ar = /รัศมี\s*(\d+)\s*เมตร/.exec(eff); const sq = /(\d+)\s*x\s*(\d+)\s*เมตร/.exec(eff);
  if (ar) m.area = {r: +ar[1]}; else if (sq) m.area = {sq: +sq[1]}; else if (/รูปกรวย|\bCone\b/.test(eff)) m.area = {cone: true};
  if (ck) suParse.cache.set(ck, {eff, type, m}); return m;
}
/* พื้นที่ของสกิลคิดเป็นจำนวนช่องจากจุดกลางออกไปแต่ละด้าน (หนึ่งช่อง 2 เมตร) */
function suAreaCells(area){ if (!area) return 0; if (area.r) return Math.max(1, Math.min(8, Math.floor(area.r / CELL_M))); if (area.sq) return Math.max(0, Math.min(8, Math.floor(area.sq / CELL_M / 2))); if (area.cone) return 1; return 0; }
function suFxKind(mech, self, cells){
  if (mech.heal.length) return 'heal'; if (mech.attack === 'melee') return 'slash'; if (cells > 0) return 'zone';
  if (mech.reaction && !mech.dmg.length) return 'shield'; if (mech.passive || self) return 'aura';
  return 'proj';
}
const SU_FX = [['proj','ลูกพลังพุ่งใส่เป้า'],['slash','รอยฟัน'],['burst','ระเบิด'],['zone','พื้นที่'],['aura','ออร่ารอบตัว'],['heal','ฟื้นฟู'],['shield','โล่']];
const SU_HUES = [['fire','ไฟ'],['plasma','พลาสมา'],['electric','สายฟ้า'],['wind','ลม'],['earth','ดินและโลหะ'],['water','น้ำ'],['frost','น้ำแข็ง'],['nature','พฤกษา'],['chaos','เคออส'],['blood','เลือด'],['necrotic','ความตาย'],['poison','พิษ'],['ritual','ทอง'],['steel','เหล็ก'],['qi','ปราณ']];
function suClean(s, n){ return String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n); }

const SkillUse = {
  tokId: null, q: '', collapsed: null, pick: false, st: null, modes: {},
  reset(){ this.pick = false; this.st = null; this.modes = {}; this.hint(null); },
  isCollapsed(){ if (this.collapsed == null){ try { this.collapsed = localStorage.getItem('kirana.skillbar') === '1'; } catch(e){ this.collapsed = false; } } return this.collapsed; },
  setCollapsed(v){ this.collapsed = !!v; try { localStorage.setItem('kirana.skillbar', v ? '1' : '0'); } catch(e){} },
  /* ความสามารถในสแตตบล็อกของ NPC ทำเป็นป้ายแบบเดียวกับทักษะ: การโจมตี (ลากใส่เป้า = เปิดหน้าต่างโจมตีด้วยท่านั้น) · Reaction · พฤติกรรมและความสามารถพิเศษ */
  npcSkills(t){
    if (typeof Combat === 'undefined' || !Combat.isNpc(t)) return []; const out = [];
    const add = (list, kind, type, max)=>{ (Array.isArray(list) ? list : []).slice(0, max).forEach((x, i)=>{ if (!x || typeof x !== 'object') return; const full = suClean(x.name, 80) || (kind === 'a' ? 'การโจมตี' : kind === 'r' ? 'Reaction' : 'ความสามารถ'); const sp = (typeof itemNameSplit === 'function') ? itemNameSplit(full) : [full, ''];
      out.push({npc: true, npcKind: kind, key: `npc:${kind}:${i}`, full, nameTh: sp[0] || full, nameEn: sp[1] || sp[0] || full, type, category: 'NPC', cost: '', effect: String(x.text || '').slice(0, 2000)}); }); };
    add(t.attacks, 'a', 'การโจมตี', 12); add(t.reactions, 'r', 'Reaction', 8); add(t.behaviors, 'b', 'พฤติกรรม', 16);
    return out;
  },
  skillByKey(t, key){ if (key === '*' || key == null) return null; if (String(key).indexOf('npc:') === 0) return this.npcSkills(t).find(x=>x.key === key) || null; return Object.prototype.hasOwnProperty.call(SKILL_BY_NAME, key) ? SKILL_BY_NAME[key] : null; },
  nameOf(sk){ return !sk ? '' : (sk.npc ? sk.full : skLabel(sk)); },
  skillsOf(t){
    const npc = this.npcSkills(t); if (npc.length) return npc;
    const c = Combat.charOf(t); if (!c || (c.shareMode === 'min' && !Store.isMine(c))) return [];
    let names = []; try { names = allSkills(c); } catch(e){ names = []; }
    const list = names.map(n=>SKILL_BY_NAME[n]).filter(Boolean); return [...list.filter(sk=>!/Passive/i.test(sk.type || '')), ...list.filter(sk=>/Passive/i.test(sk.type || ''))];
  },
  /* ---------- แถบสกิลใต้แผนที่ ---------- */
  bar(r, gm){
    const list = Combat.myTokens(r); if (!list.length) return null;
    const sel = list.find(x=>x.id === Table.sel); let t = sel || list.find(x=>x.id === this.tokId) || list.find(x=>x.kind === 'pc' && ownsTok(x)) || list[0]; this.tokId = t.id;
    const sks = this.skillsOf(t); const col = this.isCollapsed();
    const box = h('div',{class:'card skillbar' + (col ? ' collapsed' : '')});
    const who = list.length > 1 ? cbSelect(list.map(x=>[x.id, x.name]), t.id, (v)=>{ this.tokId = v; Table.sel = v; renderTable(); }, {class:'skb-who',title:'หมากที่จะใช้ทักษะ'}) : h('b',{class:'skb-who',text:t.name});
    const search = sks.length > 10 ? h('input',{class:'skb-q',placeholder:'ค้นหาทักษะ',style:'width:150px'}) : null;
    if (search){ search.value = this.q; search.oninput = ()=>{ this.q = search.value; drawChips(); }; }
    box.append(...cbKids(h('h3',{class:'row',style:'justify-content:space-between;gap:8px'}, h('span',{text:'⚡ สกิลและเวท'}), h('span',{class:'row',style:'gap:6px'}, who, col ? null : search, h('button',{class:'small ghost skb-toggle',title: col ? 'กางแถบสกิล' : 'พับแถบสกิล',onclick:()=>{ this.setCollapsed(!col); renderTable(); },text: col ? '▸ กาง' : '▾ พับ'})))));
    if (col) return box;
    box.append(...cbKids(h('p',{class:'dim skb-hint',text:'ลากป้ายไปปล่อยบนหมากหรือช่องบนแผนที่ หรือคลิกป้ายแล้วเลือกเป้า ทุกคนในห้องเห็นเอฟเฟกต์'})));
    const chips = h('div',{class:'skchips'}); box.append(...cbKids(chips));
    const drawChips = ()=>{ clear(chips); const k = this.q.trim().toLowerCase();
      const shown = sks.filter(sk=>!k || [sk.nameTh, sk.nameEn, sk.type, sk.subcategory, sk.npc ? sk.effect : ''].filter(Boolean).some(x=>String(x).toLowerCase().includes(k)));
      for (const sk of shown) chips.append(...cbKids(this.chip(t, sk)));
      chips.append(...cbKids(this.chip(t, null)));
      if (!sks.length) chips.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text: t.charId ? 'ตัวละครนี้ยังไม่มีทักษะ หรือเจ้าของแชร์เฉพาะค่าหลัก' : 'หมากนี้ยังไม่มีการโจมตี Reaction หรือพฤติกรรมในสแตตบล็อก เพิ่มได้ที่แผงหมาก หรือใช้ป้าย "ความสามารถอื่น" แล้วพิมพ์ชื่อกับผลเอง'})));
      else if (!shown.length) chips.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`ไม่พบทักษะที่ตรงกับ "${this.q.trim()}"`}))); };
    drawChips();
    return box;
  },
  chip(t, sk){
    const mech = suParse(sk); const hue = sk ? fxHueOfSkill(sk) : 'ritual'; const key = !sk ? '*' : (sk.npc ? sk.key : sk.nameEn);
    const ico = !sk ? '＋' : sk.npc ? (sk.npcKind === 'a' ? '⚔' : sk.npcKind === 'r' ? '↺' : '◈') : mech.passive ? '◈' : mech.reaction ? '↺' : sk.category === 'Sorcery' ? '✦' : '⚔'; const name = sk ? skTh(sk) : 'ความสามารถอื่น';
    const b = h('button',{class:'skchip' + (mech.passive ? ' passive' : '') + (sk ? '' : ' custom') + (sk && sk.npc ? ' npc' : ''),dataset:{sk:key},title: sk ? `${this.nameOf(sk)}\n${sk.type || ''}${sk.cost ? ' · ' + sk.cost : ''}\n${String(sk.effect || '').slice(0, 240)}` : 'พิมพ์ชื่อและผลของความสามารถเอง ใช้กับ NPC หรือความสามารถที่ไม่อยู่ในรายการ'},
      h('i',{class:'skdot',text:ico}), h('span',{class:'sknm',text:name}), (sk && sk.cost) ? h('span',{class:'skcost',text: sk.cost.length > 14 ? sk.cost.slice(0, 13) + '…' : sk.cost}) : null);
    b.style.setProperty('--fx', FX_HUE[hue] || FX_HUE.ritual);
    b.addEventListener('pointerdown', (e)=>this.startDrag(e, t.id, key, name));
    b.addEventListener('click', (e)=>{ if (e.detail === 0) this.use(t.id, key, null); }); // คีย์บอร์ด: Enter หรือ Space บนป้าย
    return b;
  },
  /* ลากด้วย pointer: ฟังที่ window การวาดโต๊ะใหม่กลางทางจึงไม่ทำให้การลากหลุด · ไม่ขยับ = คลิก */
  startDrag(ev, tokId, key, label){
    if (ev.button != null && ev.button !== 0) return; ev.preventDefault();
    const sx = ev.clientX, sy = ev.clientY; let ghost = null, moved = false, last = null, px = sx, py = sy, timer = null;
    const gridEl = ()=>document.querySelector('#v-table .gridmap');
    const mark = ()=>{ const g = gridEl(); const cell = g ? cellAtPoint(g, px, py) : null; if (cell !== last){ if (last) last.classList.remove('drop'); if (cell) cell.classList.add('drop'); last = cell; } };
    const move = (e)=>{ px = e.clientX; py = e.clientY; if (!moved && Math.hypot(px - sx, py - sy) < 6) return;
      if (!moved){ moved = true; ghost = h('div',{class:'skghost',text:'⚡ ' + label}); document.body.append(...cbKids(ghost)); document.body.classList.add('sk-dragging');
        // ลากไปใกล้ขอบบนหรือล่างของจอ หน้าเลื่อนตามเอง จะได้ลากถึงหมากที่อยู่นอกจอ
        timer = setInterval(()=>{ const edge = 64; if (py < edge) window.scrollBy(0, -16); else if (py > window.innerHeight - edge) window.scrollBy(0, 16); else return; mark(); }, 30); }
      const z = uiZoom(); ghost.style.left = (px / z + 12) + 'px'; ghost.style.top = (py / z + 12) + 'px'; mark(); };
    const up = (e)=>{ window.removeEventListener('pointermove', move, true); window.removeEventListener('pointerup', up, true); window.removeEventListener('pointercancel', up, true);
      if (timer) clearInterval(timer); document.body.classList.remove('sk-dragging'); if (ghost) ghost.remove(); if (last) last.classList.remove('drop');
      if (e.type === 'pointercancel') return; if (!moved){ this.use(tokId, key, null); return; }
      const g = gridEl(); const cell = g ? cellAtPoint(g, e.clientX, e.clientY) : null; if (!cell){ toast('ลากไปปล่อยบนหมากหรือช่องบนแผนที่'); return; }
      this.use(tokId, key, {x: +cell.dataset.x, y: +cell.dataset.y}); };
    window.addEventListener('pointermove', move, true); window.addEventListener('pointerup', up, true); window.addEventListener('pointercancel', up, true);
  },
  /* ---------- หน้าต่างยืนยันการใช้ ---------- */
  use(tokId, key, cell, extra){
    const r = Table.room; const t = Combat.tok(tokId); if (!r || !t || !Combat.controls(t)){ toast('ใช้ทักษะของหมากนี้ไม่ได้'); return; }
    const sk = this.skillByKey(t, key); if (key !== '*' && !sk){ toast('ไม่พบทักษะนี้ในข้อมูลของเว็บ'); return; }
    if (sk && sk.npc && sk.npcKind === 'a' && !cbParseNpcAttack(sk.full, sk.effect).save){ // การโจมตีในสแตตบล็อกที่ทอย Attack Roll: เปิดหน้าต่างโจมตีด้วยท่านี้ เป้าคือหมากในช่องที่ปล่อย
      const at = cell ? Combat.visible(r).find(x=>x.x === cell.x && x.y === cell.y && x.id !== t.id && (x.kind !== 'asset' || x.hpMax > 0)) : null; Combat.openAttack(t.id, at ? at.id : null, {pick: sk.full}); return; }
    const mech = suParse(sk); const cost = suParseCost(sk ? sk.cost : '');
    const st = {tokId, key, sk, mech, cost, cell: null, targets: [], alt: 0, noPay: false, reveal: false, amt: cost.parts.map(p=>p.expr), extra: extra || null, custom: {name: '', text: '', fx: 'proj', hue: 'ritual', dmg: '', dtype: 'Fire', save: '', dc: ''}};
    this.st = st; this.pick = false; this.aim(st, cell); this.drawPanel();
  },
  /* ตั้งเป้าจากช่องที่ปล่อย: สกิลที่มีพื้นที่เก็บทุกหมากในพื้นที่ (ไม่รวมผู้ใช้) สกิลอื่นเก็บหมากที่อยู่ในช่องนั้น */
  aim(st, cell){
    const r = Table.room; const t = Combat.tok(st.tokId); st.cell = cell || null; st.targets = []; if (!cell || !r || !t) return;
    const vis = Combat.visible(r); const at = vis.find(x=>x.x === cell.x && x.y === cell.y); const n = suAreaCells(st.mech.area);
    if (n > 0) st.targets = vis.filter(x=>x.kind !== 'asset' && x.id !== t.id && cellDist(x, cell) <= n).map(x=>x.id).slice(0, 12);
    else if (at) st.targets = [at.id];
  },
  label(st){ return st.sk ? this.nameOf(st.sk) : (suClean(st.custom.name, 60) || 'ความสามารถ'); },
  hint(text){
    let el = document.getElementById('pickhint'); if (!text){ if (el) el.remove(); document.body.classList.remove('cb-picking'); if (Combat.comp) document.body.classList.add('cb-picking'); return; }
    if (!el){ el = h('div',{id:'pickhint',class:'pickhint',role:'status'}); document.body.append(...cbKids(el)); } clear(el);
    el.append(...cbKids(h('span',{text:text}), h('button',{class:'small ghost',onclick:()=>{ this.pick = false; this.hint(null); if (this.st) this.drawPanel(); },text:'ยกเลิก'}))); document.body.classList.add('cb-picking');
  },
  onTokenClick(t){ if (!this.pick || !this.st) return false; this.pick = false; this.hint(null); this.aim(this.st, {x: t.x, y: t.y}); this.drawPanel(); return true; },
  onCellClick(x, y){ if (!this.pick || !this.st) return false; this.pick = false; this.hint(null); this.aim(this.st, {x, y}); this.drawPanel(); return true; },
  cancel(){ const st = this.st; this.st = null; this.pick = false; this.hint(null); modal(null); if (st && st.extra && st.extra.cancel) st.extra.cancel(); },
  drawPanel(){
    const st = this.st; const r = Table.room; if (!st || !r) return; const t = Combat.tok(st.tokId); if (!t){ this.cancel(); return; }
    const c = Combat.charOf(t); const d = Combat.derived(c); const sk = st.sk; const mech = st.mech; const redraw = ()=>this.drawPanel(); const gm = Table.isGM() || Table.localMode;
    const box = h('div',{class:'subox'});
    box.append(...cbKids(h('h3',{text:'⚡ ' + (sk ? this.nameOf(sk) : 'ความสามารถอื่น')})));
    if (sk) box.append(...cbKids(h('div',{class:'gives'}, sk.type ? tag(sk.type.slice(0, 50)) : null, sk.cost ? tag(sk.cost.slice(0, 50), 'stat') : null, (sk.components && !sk.npc) ? compTag(sk.components, sorceryLv(c)) : null, sk.subcategory ? tag(sk.subcategory.replace(/\s*\(.*$/, ''), 'prop') : null, sk.npc ? tag('สแตตบล็อกของ ' + t.name, 'prop') : null)));
    else {
      const cu = st.custom; const inp = (k, ph, w, max)=>{ const el = h('input',{class:'su-c' + k,placeholder:ph,style:`width:${w}`,maxlength:max}); el.value = cu[k]; el.onchange = ()=>{ cu[k] = el.value.trim(); redraw(); }; return el; };
      const ta = h('textarea',{class:'su-ctext',placeholder:'ผลของความสามารถ (ทุกคนในห้องเห็นข้อความนี้ในแชต)',style:'min-height:60px',maxlength:600}); ta.value = cu.text; ta.onchange = ()=>{ cu.text = ta.value.trim(); };
      box.append(...cbKids(h('div',{class:'row',style:'gap:6px;margin:6px 0'}, inp('name', 'ชื่อความสามารถ', '220px', 60), cbSelect(SU_FX, cu.fx, (v)=>{ cu.fx = v; }, {class:'su-cfx',title:'เอฟเฟกต์ภาพ'}), cbSelect(SU_HUES, cu.hue, (v)=>{ cu.hue = v; }, {class:'su-chue',title:'สีของเอฟเฟกต์'})), ta,
        h('div',{class:'row',style:'gap:6px;margin-top:6px'}, h('span',{class:'dim',text:'ความเสียหาย'}), inp('dmg', 'เช่น 1d6+1', '90px', 12), cbSelect(CB_DTYPES.map(x=>[x, x]), cu.dtype, (v)=>{ cu.dtype = v; }, {class:'su-cdtype'}), h('span',{class:'dim',text:'Saving Throw'}), cbSelect([['', 'ไม่มี'], ...[...STATS, ...suSides()].map(x=>[x, x])], cu.save, (v)=>{ cu.save = v; redraw(); }, {class:'su-csave'}), cu.save ? inp('dc', 'DC', '60px', 2) : null)));
    }
    // เป้าหมาย
    const vis = Combat.visible(r); const tg = st.targets.map(id=>vis.find(x=>x.id === id)).filter(Boolean); st.targets = tg.map(x=>x.id);
    const tRow = h('div',{class:'row su-targets',style:'gap:6px;margin-top:8px;align-items:center'}, h('span',{class:'dim',text:'เป้าหมาย'}));
    for (const x of tg) tRow.append(...cbKids(h('span',{class:'tag prop su-tg',dataset:{id:x.id}}, `${x.name} (${cellDist(t, x) * CELL_M} ม.)`, h('button',{class:'cadj',title:'เอาเป้านี้ออก',onclick:()=>{ st.targets = st.targets.filter(id=>id !== x.id); redraw(); },text:'×'}))));
    if (!tg.length) tRow.append(...cbKids(h('span',{class:'dim',style:'font-size:12.5px',text: st.cell ? `ช่อง (${st.cell.x},${st.cell.y}) ไม่มีหมาก` : 'ยังไม่ได้เลือก (ใช้กับตัวเองหรือไม่มีเป้าก็กดใช้ได้เลย)'})));
    const rest = vis.filter(x=>!st.targets.includes(x.id) && x.kind !== 'asset');
    if (rest.length) tRow.append(...cbKids(cbSelect([['', '+ เพิ่มเป้า'], ...rest.map(x=>[x.id, `${x.name}${x.id === t.id ? ' (ตัวเอง)' : ''}`])], '', (v)=>{ if (v){ st.targets = [...st.targets, v].slice(0, 12); if (!st.cell){ const x = vis.find(k=>k.id === v); if (x) st.cell = {x: x.x, y: x.y}; } redraw(); } }, {class:'su-addtg'})));
    tRow.append(...cbKids(h('button',{class:'small ghost su-pick',title:'ปิดหน้าต่างนี้ชั่วคราว แล้วคลิกหมากหรือช่องบนแผนที่',onclick:()=>{ this.pick = true; modal(null); this.hint(`🎯 คลิกหมากหรือช่องเป้าหมายของ ${this.label(st)}`); },text:'🎯 เลือกบนแผนที่'})));
    box.append(...cbKids(tRow));
    const area = suAreaCells(mech.area); if (area > 0) box.append(...cbKids(h('div',{class:'dim',style:'font-size:12px;margin-top:2px',text:`ทักษะนี้มีพื้นที่ ระบบเก็บหมากที่อยู่ห่างจุดปล่อยไม่เกิน ${area} ช่องมาให้แล้ว เอาออกหรือเพิ่มได้`})));
    if (mech.rangeM){ const far = tg.filter(x=>cellDist(t, x) * CELL_M > mech.rangeM); if (far.length) box.append(...cbKids(h('div',{class:'atkc-note bad su-far',text:`ไกลเกินระยะ ${mech.rangeM} ม. ที่ข้อความของทักษะระบุ: ${far.map(x=>`${x.name} ${cellDist(t, x) * CELL_M} ม.`).join(', ')} ให้ GM ตัดสินว่าใช้ได้ไหม`}))); }
    // ค่าร่าย
    const cost = st.cost; const cRow = h('div',{class:'su-cost',style:'margin-top:8px'});
    if (cost.parts.length){
      const have = (res)=> res === 'mp' ? (c && c.current ? (c.current.mp != null ? c.current.mp : (d ? d.mp : null)) : null) : res === 'hp' ? t.hp : (t.sanMax ? t.san : null);
      cost.parts.forEach((p, i)=>{ const on = cost.alt ? st.alt === i : true; const hv = have(p.res);
        const pickEl = cost.alt ? (()=>{ const rb = h('input',{type:'radio',name:'su-alt'}); rb.checked = on; rb.onchange = ()=>{ st.alt = i; redraw(); }; return rb; })() : null;
        const amt = h('input',{class:'su-amt',style:'width:72px',title:'จำนวนที่จะหัก ตัวเลขหรือรูปแบบเต๋า แก้ได้เมื่อมีของลดค่าร่าย'}); amt.value = st.amt[i]; amt.disabled = !on || st.noPay; amt.onchange = ()=>{ st.amt[i] = amt.value.trim(); redraw(); };
        cRow.append(...cbKids(h('label',{class:'fld su-costrow' + (on ? '' : ' off')}, pickEl, h('span',{text:'ค่าร่าย'}), amt, h('b',{text:SU_RES[p.res]}), hv != null ? h('span',{class:'dim',text:`(มี ${hv})`}) : h('span',{class:'dim',text: p.res === 'mp' ? '(MP อยู่ในชีทของเจ้าของ ระบบหักให้ไม่ได้)' : ''})))); });
      cRow.append(...cbKids(cbCheck('ไม่หักค่าร่ายครั้งนี้', st.noPay, (v)=>{ st.noPay = v; redraw(); }, {class:'fld chk su-nopay'})));
    } else if (cost.raw && !/^none$/i.test(cost.raw)) cRow.append(...cbKids(h('div',{class:'dim',style:'font-size:12.5px',text:`ค่าร่าย: ${cost.raw} (ระบบอ่านเป็นตัวเลขไม่ออก หักเองบนชีท)`})));
    box.append(...cbKids(cRow));
    // กลไกที่อ่านได้
    const pv = []; const dcOf = (sv)=>{ const v = suDcValue(sv.dc, c, d, t); return v ? `DC ${v.value}` : `DC ${sv.dc} (ให้ GM บอกค่า)`; };
    for (const sv of mech.saves.slice(0, 1)) pv.push(`เป้าหมายทอย ${sv.stat} Saving Throw (${dcOf(sv)})`);
    for (const cl of mech.clashes.slice(0, 1)) pv.push(`${cl.a} ${cl.kind} ${cl.b}: ผู้ใช้ทอย ${cl.a} เป้าหมายทอย ${cl.b}`);
    for (const dm of mech.dmg.slice(0, 2)) pv.push(`ความเสียหาย ${dm.expr}${dm.mod ? ' + ' + dm.mod : ''} ${dm.type}${mech.half ? ' (ครึ่งเดียวเมื่อ Saving Throw สำเร็จ)' : ''}`);
    for (const hl of mech.heal.slice(0, 1)) pv.push(`ฟื้นฟู ${hl.expr} ${SU_RES[hl.res]}`);
    if (mech.conds.length) pv.push('สภาวะที่ข้อความเอ่ยถึง: ' + mech.conds.map(x=>x.id + (x.lv ? ' ' + x.lv : '')).join(', '));
    if (mech.attack) pv.push(`เป็นการโจมตี${mech.attack === 'melee' ? 'ประชิด' : 'ระยะไกล'}: กดใช้แล้วหน้าต่างโจมตีจะเปิดให้ทอย`);
    if (mech.passive) pv.push('ทักษะติดตัว ทำงานตลอดเวลา การกดใช้คือการประกาศและแสดงเอฟเฟกต์');
    if (pv.length) box.append(...cbKids(h('div',{class:'su-mech'}, h('div',{class:'kicker',text:'ปุ่มที่จะขึ้นในการ์ดของแชต'}), pv.map(x=>h('div',{text:'• ' + x})))));
    if (sk) box.append(...cbKids(h('details',{class:'su-eff',open: true}, h('summary',{text: sk.npc ? 'ข้อความในสแตตบล็อก' : 'ข้อความของทักษะ'}), sk.flavor ? h('div',{class:'flavor',style:'font-size:12.5px'}, T(sk.flavor)) : null, h('div',{class:'desc',style:'font-size:13px'}, T(sk.effect || '')), ...(sk.npc ? [] : skillRollLines(sk, 'desc', 'font-size:13px')))));
    if (sk && sk.npc) box.append(...cbKids(cbCheck('แสดงข้อความนี้ให้ผู้เล่นเห็นในแชต (ปกติแชตขึ้นแค่ชื่อกับปุ่มทอย)', st.reveal, (v)=>{ st.reveal = v; }, {class:'fld chk su-reveal'})));
    box.append(...cbKids(h('div',{class:'row',style:'justify-content:flex-end;gap:8px;margin-top:12px'}, h('button',{class:'ghost su-cancel',onclick:()=>this.cancel(),text:'ยกเลิก'}), h('button',{class:'primary su-go',onclick:()=>this.cast(),text:'✨ ใช้ทักษะ'}))));
    modal(box);
    const mEl = $('#modal'); if (mEl){ mEl.onclick = ()=>{}; const close = mEl.querySelector('.box > .row:last-child'); if (close && close !== box) close.remove(); }
  },
  /* หักค่าร่าย: MP อยู่ในชีท (หักได้เฉพาะชีทของตัวเอง) · Sanity กับ HP อยู่บนหมาก */
  pay(t, c, d, st){
    const out = {ok: true, paid: [], note: ''}; if (st.noPay || !st.cost.parts.length) return out;
    const idx = st.cost.alt ? [st.alt] : st.cost.parts.map((_, i)=>i); const plan = [];
    for (const i of idx){ const p = st.cost.parts[i]; const ex = st.amt[i]; if (!cbExprOk(ex)){ out.ok = false; out.msg = 'ค่าร่ายต้องเป็นตัวเลขหรือรูปแบบเต๋า เช่น 3 หรือ 1d3'; return out; } const rr = cbRollExpr(ex); plan.push({res: p.res, n: Math.max(0, rr.total), text: rr.rolls.length ? rr.text : String(rr.total)}); }
    for (const p of plan){
      if (p.res === 'mp'){ if (!c || !Store.isMine(c) || !c.current){ out.note = 'MP อยู่ในชีทของเจ้าของ ระบบหักให้ไม่ได้ ให้เจ้าของหักเอง'; p.skip = true; continue; } const have = c.current.mp != null ? c.current.mp : (d ? d.mp : 0); if (have < p.n){ out.ok = false; out.msg = `MP ไม่พอ (มี ${have} ต้องใช้ ${p.n})`; return out; } }
      else if (p.res === 'san'){ if (!t.sanMax){ p.skip = true; continue; } if (cbInt(t.san) < p.n){ out.ok = false; out.msg = `Sanity ไม่พอ (มี ${cbInt(t.san)} ต้องใช้ ${p.n})`; return out; } }
      else if (cbInt(t.hp) < p.n){ out.ok = false; out.msg = `HP ไม่พอ (มี ${cbInt(t.hp)} ต้องใช้ ${p.n})`; return out; }
    }
    let room = false;
    for (const p of plan){ if (p.skip) continue;
      if (p.res === 'mp'){ const have = c.current.mp != null ? c.current.mp : (d ? d.mp : 0); c.current.mp = have - p.n; Store.upsert(c); }
      else if (p.res === 'san'){ tokenVitals(t, 'san', cbInt(t.san) - p.n); room = true; }
      else { tokenVitals(t, 'hp', cbInt(t.hp) - p.n); room = true; }
      out.paid.push({res: p.res, n: p.n, text: p.text}); }
    if (room) Table.save();
    return out;
  },
  cast(){
    const st = this.st; const r = Table.room; if (!st || !r) return; const t = Combat.tok(st.tokId); if (!t){ this.cancel(); return; }
    const c = Combat.charOf(t); const d = Combat.derived(c); const sk = st.sk; const cu = st.custom;
    if (!sk && !suClean(cu.name, 60)){ toast('ใส่ชื่อความสามารถก่อน'); return; }
    if (!sk && cu.dmg && !cbExprOk(cu.dmg)){ toast('ความเสียหายต้องเป็นตัวเลขหรือรูปแบบเต๋า เช่น 2 หรือ 1d6+1'); return; }
    const paid = this.pay(t, c, d, st); if (!paid.ok){ toast(paid.msg); return; }
    const src = sk ? st.mech : {saves: cu.save ? [{stat: cu.save, dc: String(cbInt(cu.dc) || '')}] : [], clashes: [], dmg: cu.dmg ? [{expr: cu.dmg, mod: null, type: cu.dtype}] : [], heal: [], conds: cbFindConds(cu.text).slice(0, 5), half: false, attack: null, area: null, passive: false, reaction: false};
    const vis = Combat.visible(r); const tg = st.targets.map(id=>vis.find(x=>x.id === id)).filter(Boolean).slice(0, 12);
    const mech = {
      saves: src.saves.slice(0, 1).map(sv=>{ const v = suDcValue(sv.dc, c, d, t); return {stat: sv.stat, dc: v ? v.value : null, dcText: v ? v.text : suClean(sv.dc, 60)}; }),
      clashes: src.clashes.slice(0, 1).map(cl=>({a: cl.a, kind: cl.kind, b: cl.b})),
      dmg: src.dmg.slice(0, 2).map(dm=>{ const mv = dm.mod ? suStatMod(dm.mod, c, d, t) : 0; return {expr: dm.expr, mod: dm.mod || null, modVal: mv == null ? 0 : mv, type: dm.type}; }),
      heal: src.heal.slice(0, 1).map(x=>({expr: x.expr, res: x.res})), conds: src.conds.slice(0, 5), half: !!src.half, attack: src.attack || null};
    const label = this.label(st); const self = !tg.length || (tg.length === 1 && tg[0].id === t.id); const cells = suAreaCells(src.area);
    const hue = sk ? fxHueOfSkill(sk) : cu.hue; const kind = sk ? suFxKind(src, self, cells) : cu.fx; const to = st.cell || (tg[0] ? {x: tg[0].x, y: tg[0].y} : {x: t.x, y: t.y});
    const react = st.extra && st.extra.react;
    const fx = {k: react ? 'shield' : kind, from: {x: t.x, y: t.y}, to: react ? {x: t.x, y: t.y} : to, hue, cells, floats: [{x: t.x, y: t.y, text: suClean(sk ? skTh(sk) : cu.name, 22), cls: 'info'}]};
    const who = t.hidden ? 'บางสิ่งที่มองไม่เห็น' : t.name;
    Table.post({kind: 'skill', who, text: `${who} ใช้ ${label}${tg.length ? ' ใส่ ' + tg.map(x=>x.name).join(', ') : ''}`, sk: (sk && !sk.npc) ? sk.nameEn : null, label, hue, caster: {id: t.id, name: who}, targets: tg.map(x=>({id: x.id, name: x.name})), cell: st.cell || null,
      cost: paid.paid, costNote: paid.note || (st.noPay && st.cost.parts.length ? 'ไม่หักค่าร่ายครั้งนี้' : ''), mech, note: sk ? ((sk.npc && st.reveal) ? suClean(sk.effect, 600) : '') : suClean(cu.text, 600), react: react || null, fx, gmOnly: false});
    const extra = st.extra; this.st = null; this.pick = false; this.hint(null); modal(null);
    if (extra && extra.done){ extra.done(); return; }
    if (mech.attack){ const dm = mech.dmg[0]; const target = tg.find(x=>x.id !== t.id);
      const weapon = dm ? Object.assign(cbParseWeapon(label, ''), {found: true, src: 'skill', dmg: dm.modVal ? (/d/i.test(dm.expr) ? `${dm.expr}${signed(dm.modVal)}` : String(cbInt(dm.expr) + dm.modVal)) : dm.expr, dtypes: [dm.type === 'Sanity' ? 'Physical' : dm.type], physical: cbIsPhysical(dm.type), statKind: 'none', conds: mech.conds, text: sk ? (sk.effect || '') : cu.text}) : null;
      setTimeout(()=>Combat.openAttack(t.id, target ? target.id : null, {weapon, mode: mech.attack, skill: label}), 60); }
  },
  /* ฝ่ายรับใช้ทักษะตอบโต้การโจมตี (เรียกจากหน้าต่างป้องกัน) */
  quick(t, sk, opts, done, cancel){ this.use(t.id, sk.nameEn, null, {react: (opts && opts.react) || true, done, cancel}); },
  onMessage(m){ if (m && m.fx) Fx.play(m.fx); },

  /* ---------- การ์ดในแชตและปุ่มต่อเนื่อง ---------- */
  follow(m){ return Table.chat.filter(x=>x && x.of === m.id); },
  mechOf(m){
    const raw = (m && m.mech && typeof m.mech === 'object') ? m.mech : {}; const arr = (v)=>Array.isArray(v) ? v : []; const conds = cbCondNames();
    return {
      saves: arr(raw.saves).slice(0, 1).filter(s=>s && suStatKnown(String(s.stat))).map(s=>({stat: String(s.stat), dc: (typeof s.dc === 'number' && isFinite(s.dc)) ? Math.max(0, Math.min(40, Math.round(s.dc))) : null, dcText: suClean(s.dcText, 60)})),
      clashes: arr(raw.clashes).slice(0, 1).filter(c=>c && suStatKnown(String(c.a)) && suStatKnown(String(c.b)) && (c.kind === 'Clash' || c.kind === 'Challenge')).map(c=>({a: String(c.a), b: String(c.b), kind: c.kind})),
      dmg: arr(raw.dmg).slice(0, 2).filter(x=>x && cbExprOk(x.expr)).map(x=>({expr: String(x.expr).trim(), mod: x.mod ? suClean(x.mod, 16) : null, modVal: Math.max(-20, Math.min(20, cbInt(x.modVal))), type: x.type === 'Sanity' ? 'Sanity' : (CB_DTYPES.includes(cbNormType(x.type)) ? cbNormType(x.type) : 'Physical')})),
      heal: arr(raw.heal).slice(0, 1).filter(x=>x && cbExprOk(x.expr) && SU_RES[x.res]).map(x=>({expr: String(x.expr).trim(), res: x.res})),
      conds: arr(raw.conds).slice(0, 5).filter(x=>x && conds.includes(x.id)).map(x=>({id: x.id, lv: x.lv ? Math.max(1, Math.min(20, cbInt(x.lv, 1))) : null})),
      half: !!raw.half, attack: raw.attack === 'melee' || raw.attack === 'ranged' ? raw.attack : null};
  },
  card(m, time){
    const mech = this.mechOf(m); const fol = this.follow(m); const sk = (m.sk && Object.prototype.hasOwnProperty.call(SKILL_BY_NAME, m.sk)) ? SKILL_BY_NAME[m.sk] : null;
    const targets = (Array.isArray(m.targets) ? m.targets : []).slice(0, 12).filter(x=>x && typeof x.id === 'string'); const caster = m.caster && typeof m.caster.id === 'string' ? Combat.tok(m.caster.id) : null;
    const el = h('div',{class:'e skillmsg'}); el.style.setProperty('--fx', FX_HUE[m.hue] || FX_HUE.ritual);
    el.append(...cbKids(h('div',{class:'row',style:'gap:6px'}, chatWho(m), h('span',{class:'dim',text:'ใช้'}), h('b',{class:'sk-name',text: sk ? skLabel(sk) : suClean(m.label, 80)}), targets.length ? h('span',{class:'dim',text:'→ ' + targets.map(x=>suClean(x.name, 40)).join(', ')}) : null, m.react ? tag('ตอบโต้', 'prop') : null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time}))));
    const paid = (Array.isArray(m.cost) ? m.cost : []).slice(0, 4).filter(p=>p && SU_RES[p.res]).map(p=>`${cbInt(p.n)} ${SU_RES[p.res]}${/\[/.test(String(p.text || '')) ? ' (' + suClean(p.text, 40) + ')' : ''}`);
    if (paid.length || m.costNote) el.append(...cbKids(h('div',{class:'dim',style:'font-size:12px',text:(paid.length ? 'หักค่าร่าย ' + paid.join(' และ ') : '') + (m.costNote ? (paid.length ? ' · ' : '') + suClean(m.costNote, 120) : '')})));
    if (sk) el.append(...cbKids(h('details',{class:'cp-d'}, h('summary',{text:'ข้อความของทักษะ'}), h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect || '')), ...skillRollLines(sk, 'desc', 'font-size:12px'))));
    else if (m.note) el.append(...cbKids(h('div',{class:'desc',style:'font-size:12.5px',text:suClean(m.note, 600)})));
    const label = sk ? skTh(sk) : suClean(m.label, 60);
    // Clash / Challenge: ฝั่งผู้ใช้ทอยหนึ่งครั้ง ใช้เทียบกับทุกเป้า
    const cl = mech.clashes[0]; let aRoll = null;
    if (cl){ aRoll = fol.find(x=>x.step === 'clashA') || null; const row = h('div',{class:'row sk-follow',style:'gap:6px;margin-top:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:`${cl.a} ${cl.kind} ${cl.b}`}));
      if (aRoll) row.append(...cbKids(tag(`ผู้ใช้ทอยได้ ${cbInt(aRoll.total)}`, 'stat')));
      else if (caster && Combat.controls(caster)) row.append(...cbKids(this.modeSel(m.id + '|A'), h('button',{class:'small primary sk-clasha',onclick:()=>this.rollStat(m, caster, cl.a, null, 'clashA', null, `${cl.a} ${cl.kind} · ${label}`),text:`🎲 ทอย ${cl.a} (ผู้ใช้)`})));
      else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:'รอผู้ใช้ทักษะทอย'})));
      el.append(...cbKids(row)); }
    for (const tg of targets){
      const t = Combat.tok(tg.id); const can = !!t && Combat.controls(t); const row = h('div',{class:'row sk-follow',style:'gap:6px;margin-top:4px;align-items:center',dataset:{tg:tg.id}}, h('b',{style:'font-size:12.5px',text:suClean(tg.name, 40)}));
      const sv = mech.saves[0]; let saved = null;
      if (sv){ const done = fol.find(x=>x.step === 'save' && x.tg === tg.id); if (done){ saved = /res-(full|crit)/.test((done.judge && done.judge.cls) || '') && !/Failure|ล้มเหลว/.test((done.judge && done.judge.text) || ''); row.append(...cbKids(tag(`${sv.stat} ST ${cbInt(done.total)}: ${sv.dc == null ? 'รอ GM ตัดสิน' : (saved ? 'ผ่าน' : 'ไม่ผ่าน')}`, sv.dc == null ? '' : (saved ? 'ok' : 'neg')))); if (sv.dc == null) saved = null; }
        else if (can) row.append(...cbKids(this.modeSel(m.id + '|' + tg.id), h('button',{class:'small primary sk-save',onclick:()=>this.rollStat(m, t, sv.stat, sv.dc, 'save', tg.id, `${sv.stat} Saving Throw · ต้าน ${label}`),text:`🎲 ${sv.stat} Saving Throw${sv.dc != null ? ' (DC ' + sv.dc + ')' : ''}`})));
        else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`รอทอย ${sv.stat} Saving Throw${sv.dc != null ? ' (DC ' + sv.dc + ')' : ''}`}))); }
      if (cl){ const bRoll = fol.find(x=>x.step === 'clashB' && x.tg === tg.id);
        if (bRoll && aRoll){ const av = cbInt(aRoll.total), bv = cbInt(bRoll.total); const aWin = av > bv || (av === bv && cl.kind === 'Clash'); row.append(...cbKids(tag(`${cl.b} ${bv} ปะทะ ${av}: ${aWin ? 'ผู้ใช้ชนะ' : 'เป้าหมายชนะ'}${av === bv ? ' (เท่ากัน)' : ''}`, aWin ? 'neg' : 'ok'))); }
        else if (bRoll) row.append(...cbKids(tag(`${cl.b} ${cbInt(bRoll.total)}`, 'stat')));
        else if (can) row.append(...cbKids(this.modeSel(m.id + '|' + tg.id + '|B'), h('button',{class:'small primary sk-clashb',onclick:()=>this.rollStat(m, t, cl.b, null, 'clashB', tg.id, `${cl.b} ต้าน ${cl.kind} · ${label}`),text:`🎲 ทอย ${cl.b}`})));
        else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`รอทอย ${cl.b}`}))); }
      mech.dmg.forEach((dm, i)=>{ const done = fol.find(x=>x.step === 'dmg' && x.tg === tg.id && x.idx === i); const txt = `${dm.expr}${dm.modVal ? signed(dm.modVal) : ''} ${dm.type}`;
        if (done) row.append(...cbKids(tag(`รับแล้ว ${cbInt(done.n)} ${dm.type}`, 'neg'))); else if (can && !mech.attack) row.append(...cbKids(h('button',{class:'small sk-dmg' + (saved === true && !mech.half ? ' ghost' : ''),onclick:()=>this.dmgModal(m, t, dm, i, saved === true && mech.half, label),text:`💥 ${txt}`}))); });
      mech.heal.forEach((hl, i)=>{ const done = fol.find(x=>x.step === 'heal' && x.tg === tg.id && x.idx === i); if (done) row.append(...cbKids(tag(`ฟื้นฟูแล้ว ${cbInt(done.n)} ${SU_RES[hl.res]}`, 'ok'))); else if (can && hl.res !== 'mp') row.append(...cbKids(h('button',{class:'small sk-heal',onclick:()=>this.heal(m, t, hl, i, label),text:`✚ ฟื้นฟู ${hl.expr} ${SU_RES[hl.res]}`}))); });
      if (can) for (const cd of mech.conds){ const key = m.id + '|' + tg.id + '|' + cd.id; const b = h('button',{class:'small ghost sk-cond',dataset:{cond:cd.id},disabled: Combat.done.has(key),onclick:()=>{ if (Combat.done.has(key)) return; Combat.done.add(key); b.disabled = true; if (!applyCond(t, Table.room, cd.id, {lv: cd.lv || 1, by: (caster && caster.id !== t.id) ? caster : undefined})){ Combat.done.delete(key); b.disabled = false; } },text:`${condIcon(cd.id)} ${cd.id}${cd.lv ? ' ' + cd.lv : ''}`}); row.append(...cbKids(b)); }
      if (row.children.length > 1) el.append(...cbKids(row));
    }
    if (mech.attack) el.append(...cbKids(h('div',{class:'dim',style:'font-size:12px;margin-top:3px',text:'ทักษะนี้เป็นการโจมตี ผลดูจากการทอยโจมตีที่ตามมา'})));
    return el;
  },
  modeSel(key){ const el = cbSelect([['normal', 'ปกติ'], ['adv', 'Advantage'], ['dis', 'Disadvantage']], this.modes[key] || 'normal', (v)=>{ this.modes[key] = v; }, {class:'sk-mode',title:'โหมดการทอยครั้งนี้'}); el.dataset.key = key; return el; },
  /* ถามตัวบวกเมื่อไม่มีชีทให้อ่าน (NPC หรือชีทที่เจ้าของแชร์เฉพาะค่าหลัก) */
  askMod(title){
    return new Promise(resolve=>{ const inp = h('input',{type:'number',class:'su-askmod',style:'width:90px',placeholder:'0'}); inp.value = '0';
      const ok = h('button',{class:'primary su-askok',onclick:()=>{ modal(null); resolve(cbInt(inp.value)); },text:'ทอย'});
      modal(h('div',{class:'pickbox'}, h('h3',{text:title}), h('p',{class:'desc',text:'ระบบอ่านค่านี้ของหมากไม่ได้ (ไม่มีชีท หรือเป็นค่าบุคลิกภาพของ NPC) ใส่ตัวบวกของการทอยครั้งนี้ (ไม่มีให้ใส่ 0)'}), h('div',{class:'row',style:'justify-content:center;gap:8px'}, h('span',{text:'2d6 +'}), inp, ok)));
      const mEl = $('#modal'); if (mEl){ mEl.onclick = ()=>{}; const close = mEl.querySelector('.box > .row:last-child'); if (close) close.querySelector('button').onclick = ()=>{ modal(null); resolve(null); }; } });
  },
  rollStat(m, t, stat, dc, step, tgId, text){
    const key = step === 'clashA' ? m.id + '|A' : step === 'clashB' ? m.id + '|' + tgId + '|B' : m.id + '|' + tgId; const mode = this.modes[key] || 'normal';
    if (this.follow(m).some(x=>x.step === step && (tgId == null || x.tg === tgId))){ toast('ทอยรายการนี้ไปแล้ว'); return; }
    Table.guardedRoll(t.name, async ()=>{
      const c = Combat.charOf(t); const d = Combat.derived(c); let mod = suStatMod(stat, c, d, t);
      if (mod == null){ mod = await this.askMod(`${t.name}: ${text}`); if (mod == null) return; }
      if (this.follow(m).some(x=>x.step === step && (tgId == null || x.tg === tgId))){ toast('มีคนทอยรายการนี้ไปก่อนแล้ว'); return; }
      const rr = roll2d6(mode); const total = rr.sum + mod; const j = judge(total, rr, dc);
      Table.post({kind: 'roll', fixedId: `${step}-${m.id}${tgId ? '-' + tgId : ''}`, who: t.hidden ? 'บางสิ่งที่มองไม่เห็น' : t.name, text, roll: {dice: rr.dice, kept: rr.kept, keptIdx: rr.keptIdx, sum: rr.sum, crit: rr.crit, double: rr.double, mode}, mod, pm: 0, total, judge: j, dc: dc != null ? dc : null, gmOnly: false, of: m.id, tg: tgId || null, step});
    }, text);
  },
  /* ความเสียหายของทักษะที่ไม่ได้ทอยโจมตี: ไม่มีตำแหน่งที่โดนจึงหักด้วยเกราะลำตัว (Non เคาะ 15 พ.ย. 2026) เลือกส่วนอื่นหรือไม่หักเกราะได้
   * กฎลด Toughness 1 ในไฟล์แกนเขียนไว้กับการโจมตีที่ป้องกันด้วย Parry หรือ Evade ไม่สำเร็จ ที่นี่จึงเป็นตัวเลือกให้ GM ติ๊กเอง */
  dmgModal(m, t, dm, idx, half, label){
    const rr = cbRollExpr(dm.expr); const total = Math.max(0, rr.total + dm.modVal); const sanity = dm.type === 'Sanity'; const physical = cbIsPhysical(dm.type);
    const st = {n: total, half: !!half, part: sanity ? 'none' : 'torso', weak: false, tough: false};
    const parts = [['torso', 'ลำตัว (ทักษะที่ไม่มีตำแหน่งที่โดน)'], ...DATA.meta.bodyParts.filter(([k])=>k !== 'torso').map(([k, l])=>[k, l]), ['none', 'ไม่หักเกราะ (ความเสียหายจาก Stack หรือผลที่ข้ามเกราะ)']];
    const box = h('div',{class:'pickbox dmgbox'});
    const draw = ()=>{ clear(box); const fin = st.half ? Math.floor(st.n / 2) : st.n;
      box.append(...cbKids(h('h3',{text:`💥 ${t.name} รับความเสียหายจาก ${label}`}), h('p',{class:'desc',text:`${rr.rolls.length ? `${dm.expr} [${rr.rolls.join(',')}]` : rr.total}${dm.modVal ? ` ${signed(dm.modVal)} ${dm.mod || ''}` : ''}${(rr.rolls.length || dm.modVal) ? ` = ${total}` : ''} ${dm.type}`}),
        h('div',{class:'row',style:'justify-content:center;gap:10px'}, h('label',{class:'fld'}, h('span',{text:'จำนวน'}), cbNum(st.n, (v)=>{ st.n = Math.max(0, v || 0); draw(); }, {class:'dm-n',style:'width:70px',min:0})), cbCheck('ครึ่งเดียว (ปัดลง)', st.half, (v)=>{ st.half = v; draw(); }, {class:'fld chk dm-half'}), sanity ? null : cbCheck('แพ้ทาง ×2', st.weak, (v)=>{ st.weak = v; draw(); }, {class:'fld chk dm-weak'})),
        sanity ? null : h('div',{class:'row',style:'justify-content:center;gap:8px;margin-top:8px'}, h('span',{class:'dim',text:'หักเกราะที่'}), cbSelect(parts, st.part, (v)=>{ st.part = v; draw(); }, {class:'dm-part',title: physical ? 'โดนชนิดในวงเล็บของค่าเกราะหักเกราะหลักบวกเกราะรอง ชนิดอื่นหักเกราะหลัก' : 'ความเสียหายเวทหักเกราะหลักบวก Sorceries Resistance ของส่วนที่เลือก'})),
        (sanity || st.part === 'none') ? null : h('div',{class:'row',style:'justify-content:center;margin-top:6px'}, cbCheck('ลด Toughness ของส่วนนี้ 1 ด้วย (GM ตัดสินว่านับเป็นการโจมตีที่โดน)', st.tough, (v)=>{ st.tough = v; }, {class:'fld chk dm-tough',title:'เกราะที่หักความเสียหายจนเหลือ 0 ทำให้ส่วนนั้นไม่เสีย Toughness'})),
        h('div',{class:'row',style:'justify-content:center;gap:8px;margin-top:12px'}, h('button',{class:'primary dm-ok',onclick:()=>{ modal(null); this.applyDmg(m, t, dm, idx, fin, st, label); },text: sanity ? `ลด Sanity ${fin}` : `ลงความเสียหาย ${fin}`})))); };
    draw(); modal(box);
  },
  applyDmg(m, t, dm, idx, n, st, label){
    const r = Table.room; if (!r || !Combat.tok(t.id)) return; if (this.follow(m).some(x=>x.step === 'dmg' && x.tg === t.id && x.idx === idx)){ toast('ความเสียหายรายการนี้ลงไปแล้ว'); return; }
    let text, got = n;
    if (dm.type === 'Sanity'){ const s0 = cbInt(t.san); const s1 = Math.max(0, s0 - n); if (t.sanMax) tokenVitals(t, 'san', s1); text = `${t.name} เสีย Sanity ${n} จาก ${label}${t.sanMax ? `: Sanity ${s0} → ${s1}` : ''}`; }
    else { const part = (st.part && st.part !== 'none') ? st.part : null;
      const res = Combat.damage(t, {raw: n, dtype: dm.type, physical: cbIsPhysical(dm.type), part, noArmor: !part, viaTorso: part === 'torso', weak: st.weak}); got = res.fin; const more = [];
      if (part && st.tough){ if (res.zeroed) more.push(`เกราะรับความเสียหายไว้หมด Toughness ของ${partLabel(part)}ไม่ลด`); else { const row = Combat.toughHit(t, res.c, res.tmax, part, 1, ''); if (row) more.push(Combat.toughLine(row)); } }
      text = `${t.name} รับ ${res.fin} ${dm.type} จาก ${label}: ${[...res.lines, ...more].join(' · ')}`;
      const stun = (t.conds || []).find(c=>c.id === 'Stunned'); if (stun && res.hp1 < res.hp0) setTimeout(()=>removeCond(t, r, stun, 'เสีย HP'), 0); }
    t.vitalsAt = Date.now(); Table.save();
    Table.post({kind: 'sys', fixedId: `dmg-${m.id}-${t.id}-${idx}`, who: '', text, of: m.id, tg: t.id, step: 'dmg', idx, n: got, fx: {k: 'burst', to: {x: t.x, y: t.y}, hue: fxHueOfDamage(dm.type), floats: [{x: t.x, y: t.y, text: `−${got}`, cls: 'dmg'}]}});
  },
  heal(m, t, hl, idx, label){
    const r = Table.room; if (!r) return; if (this.follow(m).some(x=>x.step === 'heal' && x.tg === t.id && x.idx === idx)){ toast('ฟื้นฟูรายการนี้ไปแล้ว'); return; }
    const rr = cbRollExpr(hl.expr); const n = Math.max(0, rr.total); const key = hl.res === 'san' ? 'san' : 'hp'; const max = key === 'san' ? (t.sanMax || 0) : (t.hpMax || 0); const v0 = cbInt(t[key]); const v1 = max ? Math.min(max, v0 + n) : v0 + n;
    tokenVitals(t, key, v1); Table.save();
    Table.post({kind: 'sys', fixedId: `heal-${m.id}-${t.id}-${idx}`, who: '', text: `${t.name} ฟื้นฟู ${SU_RES[hl.res]} ${rr.rolls.length ? rr.text : n} จาก ${label}: ${v0} → ${v1}`, of: m.id, tg: t.id, step: 'heal', idx, n: v1 - v0, fx: {k: 'heal', to: {x: t.x, y: t.y}, hue: 'heal', floats: [{x: t.x, y: t.y, text: `+${v1 - v0}`, cls: 'heal'}]}});
  },
  afterRender(){ if (this.pick && !this.st){ this.pick = false; this.hint(null); } },
};
