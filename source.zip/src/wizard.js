/* ===== Character creation wizard (8 ขั้นตามไฟล์แกน V.2 บรรทัด 195-247) ===== */
const STEP_DEFS = [
  {key:'kin', title:'1. เลือกวงศา (Choose Kin)', blurb:'วงศาคือรากของตัวละคร ให้ค่าดิบตั้งต้น Trait ติดตัว ข้อเสียที่ต้องแบก แต้ม Extra และทักษะเริ่มต้น เลือกจากการ์ด อยากอ่านยาว ๆ ก็กดดูรายละเอียด'},
  {key:'bg', title:'2. พื้นหลังวัยเด็กและวัยผู้ใหญ่', blurb:'เลือกวัยเด็กหนึ่งใบ วัยผู้ใหญ่หนึ่งใบ แต่ละใบให้แต้มค่าพลังกับ Trait พิเศษ และบอกว่าตัวละครผ่านอะไรมาก่อนจะมานั่งโต๊ะนี้'},
  {key:'pers', title:'3. กำหนดบุคลิกภาพ (Personality)', blurb:'แจกค่า 3 2 2 1 1 0 ให้หกคู่ คู่ละค่าเดียว แล้วเลือกว่าเอียงไปข้างไหน ข้างที่เลือกเป็นบวก ข้างตรงข้ามติดลบเท่ากันทันที เวลาทอยอะไรที่เข้ากับนิสัย ค่านี้บวกเข้าไปด้วย'},
  {key:'extra', title:'4. ใช้แต้ม Extra', blurb:'เอาแต้ม Extra ของวงศาไปใส่ค่าดิบที่อยากยก Mod คือค่าดิบหารสองลบห้า ปัดลง สูงสุด +5 และเลขคู่เท่านั้นที่ขยับ Mod'},
  {key:'talent', title:'5. พรสวรรค์ ความรู้ และทักษะ', blurb:'เลือก Talent หนึ่งอย่างตามค่าพลังที่สูงที่สุด หรือเลือก Educated ถ้าถนัดเรียนมากกว่า แล้วอัปเกรดความรู้หนึ่งระดับ รับทักษะเริ่มต้นจากวงศา ขั้นนี้ยาวหน่อย ค่อย ๆ ดูทีละช่อง'},
  {key:'calc', title:'6. ค่าพลังหลักและค่าพลังรอง', blurb:'เว็บคิดค่าพลังรองให้หมดตามตารางค่าสถานะศักยภาพในไฟล์แกน ตรวจดูว่าตัวเลขเป็นอย่างที่คิดไหม ถ้าอยากแก้ ย้อนกลับไปขั้นก่อนได้'},
  {key:'details', title:'7. รายละเอียดตัวละคร', blurb:'ตั้งชื่อ แล้วเล่าว่านางหรือเขาเป็นใคร อยากได้อะไร ต้องการอะไรจริง ๆ และแสดงออกแบบไหน รูปลักษณ์กับเอกลักษณ์ (Signature Look) คุยกับ GM ให้ตรงกัน'},
  {key:'set', title:'8. ชุดเริ่มต้น (Starter Set)', blurb:'เลือกชุดเริ่มต้นหนึ่งชุดจากสิบเจ็ดชุดให้เข้ากับพื้นหลัง ทุกคนได้ชุดยังชีพและเงิน 15 เกรฟเท่ากัน ของในชุดจะถูกสวมให้เองตอนเปิดชีท'},
];
const W = { char: null, step: 0, skFilter: '' };

function startWizard(existing){
  W.char = existing ? JSON.parse(JSON.stringify(existing)) : newChar();
  W.step = existing ? (existing.step||0) : 0;
  renderWizard();
}
function wizSave(){ W.char.step = W.step; Store.upsert(W.char); }

function renderWizard(){
  const root = clearKeep($('#v-create'));
  if (!W.char) { root.append(h('div',{class:'card'}, h('h2',{text:'สร้างตัวละครใหม่'}), h('p',{class:'dim',text:'เดินทีละขั้น ทุกตัวเลือกบอกว่าได้อะไร แผงด้านขวาสรุปค่าปัจจุบันตลอดทาง'}), h('button',{class:'primary',onclick:()=>startWizard(null),text:'เริ่มสร้างตัวละคร'}))); return; }
  const c = W.char; migrateFaithSlots(c); migrateNames(c); const d = compute(c);
  const steps = h('div',{class:'steps'}, STEP_DEFS.map((s,i)=>h('button',{class: i===W.step?'cur':(stepDone(i)?'done':''), onclick:()=>{W.step=i; renderWizard();}, text:`${i+1}. ${s.key==='kin'?'วงศา':s.key==='bg'?'พื้นหลัง':s.key==='pers'?'บุคลิก':s.key==='extra'?'Extra':s.key==='talent'?'พรสวรรค์':s.key==='calc'?'คำนวณ':s.key==='details'?'รายละเอียด':'ชุดเริ่มต้น'}`})));
  const def = STEP_DEFS[W.step];
  const head = h('div',{class:'stephead'}, h('div',null, h('h2',{text:def.title}), h('p',null, T(def.blurb))), h('div',{class:'row'}, h('button',{class:'small ghost',onclick:()=>{wizSave(); toast('บันทึกร่างแล้ว');},text:'บันทึกร่าง'}), h('button',{class:'small ghost',onclick:()=>{ if (confirm('ล้างตัวละครนี้และเริ่มใหม่?')) { startWizard(null);} },text:'เริ่มใหม่'})));
  const body = h('div');
  ({kin:stepKin, bg:stepBg, pers:stepPers, extra:stepExtra, talent:stepTalent, calc:stepCalc, details:stepDetails, set:stepSet})[def.key](body, c, d);
  const nav = h('div',{class:'navbtns'},
    h('button',{disabled: W.step===0, onclick:()=>{W.step--; renderWizard();}, text:'← ย้อนกลับ'}),
    W.step < STEP_DEFS.length-1
      ? h('button',{class:'primary', onclick:()=>{ const err = stepBlocker(W.step); if (err){ toast(err); return; } wizSave(); W.step++; renderWizard(); window.scrollTo({top:0}); }, text:'ขั้นต่อไป →'})
      : h('button',{class:'primary', onclick:finishWizard, text:'เสร็จสิ้น บันทึกตัวละคร'}));
  root.append(h('div',{class:'wiz'}, h('div',null, steps, head, body, nav), h('aside',{class:'side'}, coachPanel(c,d), sidePanel(c,d))));
}
function stepDone(i){ const c=W.char; const d=compute(c);
  switch(i){ case 0: return !!c.kin; case 1: return !!(c.childhood && c.adulthood); case 2: return budgetState(c).left.length===0;
    case 3: return c.kin && d.extraLeft===0; case 4: return !!c.talent; case 5: return !!c.kin; case 6: return !!c.name; case 7: return !!c.starterSet; }
  return false; }
function stepBlocker(i){ const c=W.char, d=compute(c);
  if (i===0 && !c.kin) return 'เลือกวงศาก่อน';
  if (i===0 && c.kin==='lunaryn' && c.evolver && c.evolver.kin && (!c.evolver.pick || !c.evolver.hindrance)) return 'Descendants of Evolver: เลือกทั้ง Trait/Skill และ Hindrance ของวงศาที่ยืมมา';
  if (i===1 && (!c.childhood || !c.adulthood)) return 'เลือกพื้นหลังทั้งวัยเด็กและวัยผู้ใหญ่';
  if (i===1){ const b=findBg(KIN[c.kin], c.childhood); if (b && b.statsChoice && (c.choiceStats||[]).length!==b.statsChoice.count) return `พื้นหลังนี้ให้เลือกค่าพลัง ${b.statsChoice.count} ค่า`; }
  if (i===2 && budgetState(c).left.length) return 'แจกค่าบุคลิกภาพให้ครบทั้ง 6 คู่';
  if (i===3 && d.extraLeft!==0) return d.extraLeft>0 ? `ยังเหลือแต้ม Extra ${d.extraLeft} แต้ม` : 'ใช้แต้ม Extra เกิน';
  if (i===4 && !c.talent) return 'เลือก Talent ก่อน';
  if (i===7 && c.starterSet && hasFleshforge(c) && !(c.fleshforge && c.fleshforge.item)) return 'Fleshforge: เลือกไอเทมที่ร่างของคุณจะผูกด้วย (ชิ้นเดียว ตลอดทั้งเกม)';
  if (i===4){ const t = DATA.talents.find(x=>x.key===c.talent); const kin = KIN[c.kin];
    for (let j=0;j<t.steps.length;j++){ const st=t.steps[j]; const key=`talent-${j}`;
      if (st.kind==='skills' && ((c.skillSlots||{})[key]||[]).length < st.count) return `ขั้น ${j+1} ของ Talent: เลือกทักษะให้ครบ ${st.count}`;
      if (st.kind==='knowledge'){ const keys = st.count>1 ? Array.from({length:st.count},(_,q)=>`${key}-${q}`) : [key]; for (const kk of keys){ const sl=(c.kslots||{})[kk]; if (slotIncomplete(sl)) return `ขั้น ${j+1} ของ Talent: เลือกความรู้ Proficiency (และความเชื่อ) ให้ครบ`; } }
      if (st.kind==='choice' && !(c.talentPicks||{})[key]) return `ขั้น ${j+1} ของ Talent: เลือก 1 อย่าง`;
      if (st.kind==='grant' && st.altPools && (kin.traits.some(x=>x.nameEn==='Nimble Grace') || kin.starterSkills.some(x=>x.name.includes('Nimble Grace'))) && ((c.skillSlots||{})[key]||[]).length<1) return `ขั้น ${j+1} ของ Talent: เลือก Tactical & General Skill แทน Nimble Grace`;
    }
    const fr=(c.kslots||{}).free; if (slotIncomplete(fr)) return 'อัปเกรด Knowledge 1 ระดับ และเลือก Proficiency (ขั้น 5 ของไฟล์แกน)';
    for (let g=0; g<kin.knowledgeGrants.length; g++){ const sl=(c.kslots||{})[`kin-${g}`]; if (slotIncomplete(sl)) return `ของจากวงศา (${kin.knowledgeGrants[g].source}): เลือกความรู้และ Proficiency`; }
    if (kin.adaptationChoice && !c.adaptation) return 'เลือก Adaptation 1 อย่าง (Cross-Cultural Adaptation)';
  }
  if (i===6 && !c.name.trim()) return 'ตั้งชื่อตัวละครก่อน';
  return null; }

/* ---------- side panel: ตอนนี้ได้อะไรแล้ว ---------- */
function sidePanel(c,d){
  const kin = c.kin ? KIN[c.kin] : null;
  const box = h('div',{class:'card summary'});
  box.append(h('h3',{text: c.name || 'ตัวละครใหม่'}), h('div',{class:'dim',style:'font-size:13px',text: kin ? kin.name + (c.size?` · ${c.size}`:'') : 'ยังไม่เลือกวงศา'}));
  box.append(h('div',{class:'statgrid'}, STATS.map(s=>h('div',{class:'statbox sc-'+s}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:d.raw[s]}), h('div',{class:'m num',text:'Mod '+signed(d.mod[s])})))));
  if (kin){
    const dl = h('dl');
    const add=(k,v)=>dl.append(h('dt',null, T(k)), h('dd',{class:'num',text:v}));
    add('Extra เหลือ', `${d.extraLeft} / ${d.extraTotal}`);
    add('HP', d.hp); add('MP', d.mp); add('Sanity', d.sanity); add('Toughness/ส่วน', d.toughness);
    add('Passive PER', d.passivePer); add('แบกได้', `${d.capacity} กก.`);
    box.append(dl);
    const th = toughnessHint(d); if (th) box.append(h('p',{class:'toughhint',text:th}));
  }
  // พื้นหลังที่เลือกแล้ว
  const bgs = [['วัยเด็ก', findBg(kin, c.childhood)], ['วัยผู้ใหญ่', findBg(kin, c.adulthood)]].filter(x=>x[1]);
  if (bgs.length){
    const bb = h('div',{style:'margin-top:10px'});
    for (const [label, b] of bgs) bb.append(h('div',{class:'infobox',style:'margin-top:6px'}, h('div',{class:'row',style:'gap:6px'}, h('span',{class:'tag',text:label}), h('b',{text:b.name}), ...Object.entries(b.stats).map(([k,v])=>h('span',{class:'tag stat sc sc-'+k, text:`${signed(v)} ${k}`}))), b.text ? h('div',{class:'desc',style:'font-size:12px;margin-top:4px'}, T(b.text.length>140 ? b.text.slice(0,140)+'…' : b.text)) : null));
    box.append(bb);
  }
  const pers = DATA.meta.personality.map(ax=>{ const p=c.personality[ax.id]; if(!p||p.value==null) return null; const name = p.side==='left'?ax.left:ax.right; return h('span',{class:'tag', style: p.value? (p.side==='left'?'border-color:#f08c2e;color:#f08c2e':'border-color:#58b7ff;color:#58b7ff') : '', text:`${name} ${signed(p.value)}`}); }).filter(Boolean);
  if (pers.length) box.append(h('div',{class:'gives',style:'margin-top:8px'}, pers));
  const prof = personalityProfile(c, d);
  if (prof){
    const pc = h('div',{class:'infobox profile',style:'margin-top:8px'});
    pc.append(h('b',{text:'ลักษณะนิสัยโดยรวม'}));
    pc.append(h('div',{class:'desc',style:'margin-top:4px',text: prof.lines.join(' ') + (prof.zero.length ? ` ส่วนเรื่อง ${prof.zero.join(', ')} ยังไม่เอนไปทางใด` : '')}));
    pc.append(h('div',{class:'arch'}, prof.top.map((a,i)=>h('span',{class:'tag '+(i===0?'prop':''), text:`${a.id} (${a.th})`}))));
    pc.append(h('div',{class:'desc',style:'font-size:12px'}, 'เหมาะกับสาย ', h('b',{text: prof.top[0].id}), prof.top[1] ? [' หรือ ', h('b',{text: prof.top[1].id})] : null, prof.talentHint.length ? ` · Talent ที่เข้ากัน: ${prof.talentHint.join(', ')}` : '', prof.sets.length ? ` · ชุดเริ่มต้นที่เข้ากัน: ${prof.sets.join(', ')}` : ''));
    box.append(pc);
  }
  const kl = Object.entries(knowledgeLevels(c)).filter(([k,v])=>v>0).map(([k,v])=>tag(`${knLabel(KNOW[k])} Lv${v}`,'stat'));
  if (kl.length) box.append(h('div',{class:'gives',style:'margin-top:8px'}, kl));
  const sk = allSkills(c);
  if (sk.length) box.append(h('div',{class:'gives'}, sk.map(s=>tag(skLabel(s)))));
  if (c.starterSet) box.append(h('div',{class:'gives'}, tag('Starter: '+c.starterSet,'prop')));
  return box;
}

/* ---------- Step 1: Kin ---------- */
function kinPros(k){
  const good = [...k.traits.map(t=>t.name + (t.nameEn?` (${t.nameEn})`:'')), ...k.benefits.map(b=>b.name + (b.nameEn?` (${b.nameEn})`:''))];
  const bad = k.hindrances.map(x=>x.name + (x.nameEn?` (${x.nameEn})`:''));
  return {good, bad};
}
function kinDetailModal(k, c){
  const det = h('div');
  det.append(h('h2',null, k.name), h('div',{class:'dim',style:'font-size:13px;margin-bottom:8px',text:k.archetype}));
  for (const p of k.intro) det.append(h('p',{class:'desc'}, T(p)));
  det.append(h('div',{class:'kin-stats'}, STATS.map(s=>h('div',{class:'s sc-'+s}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:k.raw[s]}), h('div',{class:'m num',text:'Mod '+signed(modOf(k.raw[s]))})))));
  const dl = h('dl'); const add=(a,b)=>dl.append(h('dt',{text:a}),h('dd',null,T(b)));
  add('แต้ม Extra', String(k.extra)); add('อายุขัย', k.age); add('ขนาด', k.size); add('ความเร็ว', k.speed); add('ภาษา', k.languages);
  det.append(h('div',{class:'summary'}, dl));
  const sec=(title, items, cls)=>{ if(!items.length) return; det.append(h('h4',{style:'margin-top:12px'}, T(title))); for (const it of items) det.append(h('div',{style:'margin:4px 0'}, tag(it.name + (it.nameEn?` (${it.nameEn})`:''), cls + hueCls(it.nameEn, it.name, it.text)), ' ', h('span',{class:'desc'}, T(it.text)))); };
  sec('Benefits', k.benefits, 'prop'); sec('Traits ติดตัว', k.traits, 'ok'); sec('Hindrances ข้อเสีย', k.hindrances, 'neg');
  if (k.starterSkills.length){ det.append(h('h4',{style:'margin-top:12px'}, T('Starter Skill (ได้อัตโนมัติเมื่อเข้าเงื่อนไข ตรวจหลังใส่ Extra)'))); for (const s of k.starterSkills){ const sk = SKILL_BY_NAME[cleanSkillName(s.name)]; det.append(h('div',{style:'margin:4px 0'}, tag(starterLabel(s),'stat'), s.condition? h('span',{class:'desc',text:' เงื่อนไข: '+s.condition}):h('span',{class:'desc',text:' ไม่มีเงื่อนไข'}), sk && sk.flavor? h('div',{class:'flavor',style:'font-size:12px'}, T(sk.flavor)) : null, sk? h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect)) : null)); } }
  if (k.notes && k.notes.length){ det.append(h('h4',{style:'margin-top:12px',text:'กฎพิเศษของวงศา'})); for (const n of k.notes) det.append(h('p',{class:'desc'}, T(n))); }
  det.append(h('h4',{style:'margin-top:12px',text:'พื้นหลังของวงศานี้'}));
  det.append(h('div',{class:'desc',style:'font-size:12px'}, 'วัยเด็ก: ' + k.childhood.concat(k.specialChildhood).map(b=>b.name).join(' · ')), h('div',{class:'desc',style:'font-size:12px'}, 'วัยผู้ใหญ่: ' + k.adulthood.map(b=>b.name).join(' · ')));
  det.append(h('div',{class:'row',style:'margin-top:14px'}, h('button',{class:'primary',onclick:()=>{ modal(null); selectKin(c, k.id); },text: c.kin===k.id ? 'เลือกวงศานี้อยู่แล้ว' : 'เลือกวงศานี้'})));
  modal(det);
}
function selectKin(c, id){
  const k = KIN[id];
  if (c.kin!==id){ c.kin=id; c.size=k.sizes[0]; c.childhood=null; c.adulthood=null; c.choiceStats=[]; c.extra={}; c.evolver={kin:null,pick:null,hindrance:null}; c.talent=null; c.talentPicks={}; c.kslots={}; c.skillSlots={}; c.adaptation=null; }
  renderWizard();
}
function stepKin(body, c, d){
  body.append(h('div',{class:'infobox',style:'margin-bottom:12px'}, T('การ์ดบอกแค่จุดเด่น จุดด้อย และค่าพลังเริ่มต้น กด "ดูรายละเอียด" เพื่ออ่านคำอธิบายเต็มของ Trait, Hindrance, Benefit และพื้นหลังทั้งหมดก่อนตัดสินใจ')));
  const grid = h('div',{class:'grid two'});
  for (const k of DATA.kins){
    const sel = c.kin===k.id; const pr = kinPros(k);
    const card = h('div',{class:'card pick kin-card'+(sel?' sel':''), tabindex:0, role:'button', onclick:()=>selectKin(c, k.id), onkeydown:(e)=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); e.currentTarget.click(); } }},
      h('h3',null, k.name, h('span',{class:'en'}, tag(k.archetype,'prop'))),
      h('div',{class:'kin-stats'}, STATS.map(s=>h('div',{class:'s sc-'+s}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:k.raw[s]}), h('div',{class:'m num',text:signed(modOf(k.raw[s]))})))),
      h('div',{class:'gives'}, tag(`Extra ${k.extra}`,'stat'), tag(`ขนาด ${k.sizes.join('/')}`), tag(`พื้นหลัง ${k.childhood.length+k.specialChildhood.length}+${k.adulthood.length}`)),
      h('div',{class:'pros'}, h('div',null, h('b',{class:'good',text:'จุดเด่น'}), h('ul',null, pr.good.map(x=>h('li',{text:x})))), h('div',null, h('b',{class:'bad',text:'จุดด้อย'}), h('ul',null, pr.bad.map(x=>h('li',{text:x}))))),
      h('div',{class:'desc',style:'margin-top:8px',text: k.intro[0] ? k.intro[0].slice(0,120) + (k.intro[0].length>120?'…':'') : ''}),
      h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'small ghost',onclick:(e)=>{ e.stopPropagation(); kinDetailModal(k, c); },text:'ดูรายละเอียดวงศา'}), sel? tag('เลือกแล้ว','ok') : null));
    grid.append(card);
  }
  body.append(grid);
  if (c.kin){
    const k = KIN[c.kin];
    const det = h('div',{class:'card',style:'margin-top:14px'});
    det.append(h('h3',null, k.name, h('span',{class:'en',text:'ตัวเลือกของวงศาที่ต้องตัดสินตอนนี้'})));
    if (k.sizes.length>1) det.append(h('div',{class:'row',style:'margin-top:8px'}, h('label',{text:'เลือกขนาดของคุณ'}), ...k.sizes.map(s=>h('button',{class:'small'+(c.size===s?' primary':''), onclick:()=>{c.size=s; renderWizard();}, text:s}))));
    else det.append(h('div',{class:'desc',style:'margin-top:6px'}, T(`ขนาด ${k.sizes[0]} · ${k.speed}`)));
    if (k.evolver) det.append(evolverUI(c));
    // Trait / Hindrance ของวงศาที่มีทางเลือกย่อยในข้อความ → ให้ระบุ
    for (const x of [...k.traits, ...k.benefits, ...k.hindrances]) if (traitNeedsPick(x.text)) det.append(h('div',{class:'infobox',style:'margin-top:8px'}, h('b',{text:`${x.name} (${x.nameEn})`}), h('div',{class:'desc',style:'font-size:12.5px'}, T(x.text)), traitPickInput(c, 'kin:'+x.nameEn, 'ระบุทางเลือกของ Trait นี้')));
    det.append(h('div',{class:'row',style:'margin-top:10px'}, h('button',{class:'small ghost',onclick:()=>kinDetailModal(k, c),text:'อ่านรายละเอียดเต็มของ '+k.name})));
    body.append(det);
  }
}
/* Lunaryn: Descendants of Evolver — ยืม Trait หรือ Starter Skill จากวงศาอื่น 1 อย่าง แล้วรับ Hindrance 1 อย่างของวงศานั้น */
function evolverUI(c){
  const box = h('div',{class:'infobox',style:'margin-top:12px'});
  box.append(h('h4',{text:'ทายาทแห่งผู้วิวัฒน์ (Descendants of Evolver)'}), h('p',{class:'desc',text:'เลือก Trait หรือ Starter Skill จากวงศาใด ๆ 1 อย่าง จากนั้นต้องรับ Hindrance 1 อย่างของวงศานั้นด้วย'}));
  const ev = c.evolver || (c.evolver={kin:null,pick:null,hindrance:null});
  const sel = h('select',{onchange:(e)=>{ ev.kin=e.target.value||null; ev.pick=null; ev.hindrance=null; renderWizard(); }}, h('option',{value:'',text:'— ไม่ใช้ / เลือกวงศา —'}), DATA.kins.filter(k=>k.id!=='lunaryn').map(k=>h('option',{value:k.id, selected: ev.kin===k.id, text:k.name})));
  box.append(h('div',{class:'row'}, h('label',{text:'ยืมจากวงศา'}), sel));
  if (ev.kin){
    const k = KIN[ev.kin];
    const opts = [...k.traits.map(t=>({key:'T:'+t.nameEn, label:`Trait: ${t.name} (${t.nameEn})`, text:t.text})), ...k.starterSkills.map(s=>({key:'S:'+s.name, label:`Starter Skill: ${starterLabel(s)}`, text:s.condition?('เงื่อนไข: '+s.condition):''}))];
    box.append(h('div',{style:'margin-top:8px'}, h('label',{text:'เลือก 1 อย่าง'}), h('div',{class:'grid',style:'margin-top:4px'}, opts.map(o=>h('div',{class:'sk'+(ev.pick===o.key?' sel':''), onclick:()=>{ev.pick=o.key; renderWizard();}}, h('div',{class:'h'}, h('b',{text:o.label})), h('div',{class:'eff'}, T(o.text)))))));
    box.append(h('div',{style:'margin-top:8px'}, h('label',{text:'รับ Hindrance 1 อย่าง'}), h('div',{class:'grid',style:'margin-top:4px'}, k.hindrances.map(hd=>h('div',{class:'sk'+(ev.hindrance===hd.nameEn?' sel':''), onclick:()=>{ev.hindrance=hd.nameEn; renderWizard();}}, h('div',{class:'h'}, h('b',{text:`${hd.name} (${hd.nameEn})`})), h('div',{class:'eff'}, T(hd.text)))))));
  }
  return box;
}

/* ---------- Step 2: Backgrounds ---------- */
function bgCard(c, b, field){
  const sel = c[field]===b.code;
  const chips = Object.entries(b.stats).map(([k,v])=>h('span',{class:'tag stat sc sc-'+k, text:`${signed(v)} ${k}`}));
  if (b.statsChoice) chips.push(tag(`${signed(b.statsChoice.each)} ค่าพลังใดก็ได้ ${b.statsChoice.count} ค่า`,'stat'));
  const card = h('div',{class:'card pick'+(sel?' sel':''), tabindex:0, role:'button', onclick:()=>{ c[field]=b.code; if(field==='childhood') c.choiceStats=[]; renderWizard(); }, onkeydown:(e)=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); e.currentTarget.click(); } }},
    h('h3',null, b.name, h('span',{class:'en',text:b.nameEn})),
    h('div',{class:'gives'}, tag(b.code), ...chips),
    h('div',{class:'desc'}, T(b.text || '(ไม่มี Trait ให้แต้มสถานะอย่างเดียว)')));
  if (sel && traitNeedsPick(b.text)){ const tp = traitPickInput(c, 'bg:'+b.code, 'ระบุทางเลือกของ Trait นี้ เช่น กลุ่มเป้าหมาย'); tp.onclick = (e)=>e.stopPropagation(); card.append(tp); }
  if (sel && b.statsChoice){
    const cs = c.choiceStats || (c.choiceStats=[]);
    card.append(h('div',{class:'row',style:'margin-top:8px'}, h('label',{text:`เลือก ${b.statsChoice.count} ค่า:`}), ...STATS.map(s=>h('button',{class:'small'+(cs.includes(s)?' primary':''), onclick:(e)=>{ e.stopPropagation(); const i=cs.indexOf(s); if(i>=0) cs.splice(i,1); else if (cs.length<b.statsChoice.count) cs.push(s); renderWizard(); }, text:s}))));
  }
  return card;
}
function stepBg(body, c){
  if (!c.kin){ body.append(h('div',{class:'warnbox',text:'เลือกวงศาก่อน'})); return; }
  const k = KIN[c.kin];
  const note = k.id==='lunaryn' || k.id==='solrin' || k.id==='nightkin' || k.id==='rimmen' || k.id==='norlan' ? 'พื้นหลังของกลุ่มมนุษย์ให้ 3 แต้ม วงศาอื่นให้ 2 แต้ม (ตามไฟล์ Kins V.2)' : 'พื้นหลังของวงศานี้ให้ 2 แต้มต่อใบ (กลุ่มมนุษย์ให้ 3)';
  body.append(h('div',{class:'infobox',style:'margin-bottom:12px',text:note}));
  body.append(h('h3',{text:'วัยเด็ก (Childhood) เลือก 1'}));
  body.append(h('div',{class:'grid two',style:'margin:8px 0 18px'}, k.childhood.map(b=>bgCard(c,b,'childhood'))));
  if (k.specialChildhood.length){ body.append(h('h3',{text:'วัยเด็กพิเศษ (Special Childhood) เลือกแทนวัยเด็กปกติได้'})); body.append(h('div',{class:'grid two',style:'margin:8px 0 18px'}, k.specialChildhood.map(b=>bgCard(c,b,'childhood')))); }
  body.append(h('h3',{text:'วัยผู้ใหญ่ (Adulthood) เลือก 1'}));
  body.append(h('div',{class:'grid two',style:'margin:8px 0'}, k.adulthood.map(b=>bgCard(c,b,'adulthood'))));
  if (k.specialAdulthood.length){ body.append(h('h3',{text:'วัยผู้ใหญ่พิเศษ'})); body.append(h('div',{class:'grid two',style:'margin:8px 0'}, k.specialAdulthood.map(b=>bgCard(c,b,'adulthood')))); }
}

/* ---------- Step 3: Personality ---------- */
function stepPers(body, c){
  const bs = budgetState(c);
  body.append(h('div',{class:'budget',style:'margin-bottom:12px'}, h('span',{class:'dim',text:'ค่าที่เหลือให้แจก:'}), ...DATA.meta.personalityBudget.map((v,i)=>{ const usedCount = bs.used.filter(x=>x===v).length; const idxAmong = DATA.meta.personalityBudget.slice(0,i).filter(x=>x===v).length; return h('span',{class:'chip'+(idxAmong < usedCount ? ' used':''), text:v}); }), h('span',{class:'dim',style:'font-size:12px;margin-left:8px',text:'โทนร้อน = ฝั่งซ้าย · โทนเย็น = ฝั่งขวา แถบสีจะกลืนไปตามระดับที่ให้'})));
  for (const ax of DATA.meta.personality){
    const p = c.personality[ax.id] || (c.personality[ax.id] = {side:'left', value:null});
    const avail = new Set(bs.left.concat(p.value!=null?[p.value]:[]));
    const setVal = (side, v) => { p.side = side; p.value = v; renderWizard(); };
    const lvlBtns = (side) => h('div',{class:'lvl'}, [3,2,1].map(v=>h('button',{class:'small'+(p.side===side&&p.value===v?' primary':''), disabled: !avail.has(v), title: avail.has(v)?'':'ค่านี้ใช้ไปแล้ว', onclick:()=>setVal(side, v), text: side==='left'? `${v}` : `${v}`})));
    const warmFrac = p.value==null ? 0.5 : (p.side==='left' ? 0.5 + p.value/6 : 0.5 - p.value/6);
    const shown = p.value==null ? 'ยังไม่เลือก' : p.value===0 ? '0 / 0' : (p.side==='left' ? `${signed(p.value)} / ${signed(-p.value)}` : `${signed(-p.value)} / ${signed(p.value)}`);
    const row = h('div',{class:'axis'+(p.value!=null?' on':'')},
      h('div',{class:'pole warm'+(p.side==='left'&&p.value?' active':'')}, h('b',null, T(ax.left), ` (${ax.leftTh})`), h('div',{class:'desc'}, T(ax.leftUse)), h('div',{class:'row',style:'margin-top:6px'}, lvlBtns('left'))),
      h('div',{class:'ctl'}, h('div',{class:'val num',text:shown}), h('button',{class:'small'+(p.value===0?' primary':''), disabled: !avail.has(0), onclick:()=>setVal(p.side, 0), text:'0 กลาง'}), p.value!=null ? h('button',{class:'small ghost',onclick:()=>{ p.value=null; renderWizard(); },text:'ล้าง'}) : null),
      h('div',{class:'pole r cool'+(p.side==='right'&&p.value?' active':'')}, h('b',null, T(ax.right), ` (${ax.rightTh})`), h('div',{class:'desc'}, T(ax.rightUse)), h('div',{class:'row',style:'margin-top:6px;justify-content:flex-end'}, lvlBtns('right'))),
      h('div',{class:'pbar'}, h('div',{class:'warm',style:`width:${warmFrac*100}%`}), h('div',{class:'cool',style:`width:${(1-warmFrac)*100}%`})));
    body.append(row);
  }
  body.append(h('p',{class:'dim',style:'margin-top:10px;font-size:13px'}, T('ค่า 0 คือคู่ที่ตัวละครยังไม่เอนไปทางใด ค่าสูงสุดตอนสร้างตัวละครคือ 3 ยกเพิ่มภายหลังได้ด้วย Manifest')));
}

/* ---------- Step 4: Extra points ---------- */
/* v1.15: สูตร Toughness ตัดที่ผลรวม VIT + STR ทุก 10 แต้ม และค่านี้คงที่ตลอดชีวิต บอกผู้เล่นเมื่อขาดอีก 1 ถึง 2 แต้มจะได้ +1 ทั้งหกส่วน */
function toughnessHint(d){ if (!d || !d.raw) return ''; const sum = (d.raw.VIT||0) + (d.raw.STR||0); const need = 10 - (sum % 10); return (need <= 2 && sum > 0) ? `ผลรวม VIT + STR ตอนนี้ ${sum} เพิ่มอีก ${need} แต้มจะได้ Toughness +1 ทั้งหกส่วน ค่านี้คงที่ตลอดชีวิตตัวละคร` : ''; }
function stepExtra(body, c, d){
  if (!c.kin){ body.append(h('div',{class:'warnbox',text:'เลือกวงศาก่อน'})); return; }
  const prof = personalityProfile(c, d);
  const auto = h('div',{class:'card',style:'margin-bottom:12px'});
  auto.append(h('h4',null, 'Auto Fill ตามแนวทาง ', h('span',{class:'dim',style:'font-weight:400;font-family:var(--font-body);font-size:13px',text:'(ไม่อยากลงเอง ให้ระบบแจกให้ แล้วปรับทีหลังได้)'})));
  auto.append(h('div',{class:'row',style:'margin-top:6px'}, ARCH.map(a=>h('button',{class:'small'+(prof && prof.top[0] && prof.top[0].id===a.id ? ' primary' : ''), title: Object.entries(a.weights).map(([k,v])=>`${k}×${v}`).join(' '), onclick:()=>{ autoFillExtra(c, a.id); toast(`แจกแต้มตามสาย ${a.id} แล้ว`); renderWizard(); }, text:`${a.id} (${a.th})`}))));
  if (prof) auto.append(h('div',{class:'desc',style:'margin-top:6px'}, 'จากบุคลิกภาพที่เลือก ระบบแนะนำสาย ', h('b',{text:prof.top[0].id}), prof.top[1] ? [' หรือ ', h('b',{text:prof.top[1].id})] : null, ' (ปุ่มที่ไฮไลต์)'));
  body.append(auto);
  body.append(h('div',{class:'row',style:'margin-bottom:12px'}, h('span',{class:'tag '+(d.extraLeft===0?'ok':(d.extraLeft<0?'neg':'warn')), text:`Extra เหลือ ${d.extraLeft} / ${d.extraTotal}`}), h('button',{class:'small ghost',onclick:()=>{c.extra={}; renderWizard();},text:'ล้างการแจก'})));
  const grid = h('div',{class:'alloc'});
  for (const s of STATS){
    const ex = c.extra[s]||0;
    grid.append(h('div',{class:'box sc-'+s, style:'border-top:3px solid var(--sc)'}, h('div',{class:'k',style:'color:var(--sc)',text:`${s} · ${STAT_TH[s]}`}), h('div',{class:'big num',text:d.raw[s]}), h('div',{class:'num dim',text:`Mod ${signed(d.mod[s])}` + (modOf(d.raw[s]+1)>d.mod[s] ? ` · +1 แต้มจะเป็น Mod ${signed(modOf(d.raw[s]+1))}` : ` · อีก ${nextModAt(d.raw[s])} แต้มถึง Mod ${signed(d.mod[s]+1)}`)}),
      h('div',{class:'ctl'}, h('button',{class:'small',disabled:ex<=0,onclick:()=>{c.extra[s]=ex-1; renderWizard();},text:'−'}), h('span',{class:'num',text:`Extra ${signed(ex)}`}), h('button',{class:'small',disabled:d.extraLeft<=0 || d.raw[s]>=20,onclick:()=>{c.extra[s]=ex+1; renderWizard();},text:'+'})),
      h('div',{class:'desc',style:'margin-top:6px'}, T(DATA.meta.stats.find(x=>x.key===s).use))));
  }
  body.append(grid);
  body.append(h('p',{class:'dim',style:'font-size:13px;margin-top:10px'}, T('ค่าคู่เท่านั้นที่ขยับ Mod (10→0, 12→+1, 14→+2, 16→+3, 18→+4, 20→+5) แต้มคี่จึงเป็นการ "ปูทาง" ให้ IP ภายหลัง Talent จะเลือกจากค่าพลังที่ Mod สูงสุดหลังขั้นนี้')));
}
function nextModAt(v){ let n=0; const m=modOf(v); while (modOf(v+n)===m && n<30) n++; return n; }

/* ---------- Step 5: Talent + knowledge + skills ---------- */
/* ลำดับช่องความรู้ตามที่ปรากฏบนหน้า: Talent (talent-*) → ฟรี (free) → ของวงศา (kin-*) → ซื้อด้วย IP (ip*) แล้วเรียงตามชื่อ เลือกช่องล่างไม่กระทบช่องบน */
function slotGroup(key){ return key.startsWith('talent') ? 0 : key==='free' ? 1 : key.startsWith('kin-') ? 2 : 3; } // เรียงตามลำดับที่ปรากฏบนหน้า: Talent → ฟรี → ของวงศา → IP
function slotBefore(a, b){ const ga = slotGroup(a), gb = slotGroup(b); if (ga !== gb) return ga < gb; return a.localeCompare(b, undefined, {numeric:true}) < 0; }
function knowledgeLevels(c){
  const lv = Object.fromEntries(DATA.knowledge.map(k=>[k.id,0]));
  for (const slot of Object.values(c.kslots||{})) if (slot && slot.id) lv[slot.id] = Math.min(3, lv[slot.id]+1);
  return lv;
}
function allSkills(c){
  const out = new Set();
  for (const arr of Object.values(c.skillSlots||{})) for (const n of arr||[]) out.add(SKILL_ALIAS[n] || n);
  for (const g of c.grants||[]) out.add(SKILL_ALIAS[g] || g);
  const kin = c.kin ? KIN[c.kin] : null;
  if (kin){ const d = compute(c); for (const s of kin.starterSkills) if (starterCondOk(s.condition, d)) out.add(cleanSkillName(s.name)); }
  if (c.evolver && c.evolver.pick && c.evolver.pick.startsWith('S:')) out.add(cleanSkillName(c.evolver.pick.slice(2)));
  return [...out];
}
const SKILL_LC = Object.fromEntries(DATA.skills.map(s => [s.nameEn.toLowerCase(), s.nameEn]));
function cleanSkillName(n){ const cands = []; const m = n.match(/\(([A-Za-z][^)]*)\)/); if (m) cands.push(m[1].trim()); const m2 = n.match(/^([A-Za-z][A-Za-z' \-]+)/); if (m2) cands.push(m2[1].trim()); for (const c of cands){ if (SKILL_BY_NAME[c]) return c; if (SKILL_LC[c.toLowerCase()]) return SKILL_LC[c.toLowerCase()]; } return n.replace(/:.*$/,'').trim(); }
function starterCondOk(cond, d){
  if (!cond) return true;
  const m = cond.match(/(\d+)\s*(STR|AGI|VIT|PER|INF|INT)/);
  if (m && d.raw[m[2]] < +m[1]) return false;
  return true; // เงื่อนไขอื่น (เช่น เพศ) ให้ผู้เล่นตัดสินเอง แสดงไว้ในชีท
}
function poolMatch(sk, pool, kin){
  if (sk.category==='Granted') return false;
  switch(pool){
    case '*': return true;
    case 'Sorcery:Novice': return sk.category==='Sorcery' && sk.tier==='Novice';
    case 'Kins Unique': return sk.category==='Kins Unique' && kin && kin.uniqueGroups.includes(sk.subcategory);
    case 'Qi': return sk.subcategory==='Qi';
    case 'Stance': return sk.subcategory==='Stance';
    case 'Trick': return sk.category==='Trick';
    case 'Survival': return sk.category==='Survival';
    case 'Martial': return sk.category==='Martial';
    case 'Martial:notQiStance': return sk.category==='Martial' && sk.subcategory!=='Qi' && sk.subcategory!=='Stance';
    default: return sk.subcategory===pool;
  }
}
function starterLabel(s){ const sk = SKILL_BY_NAME[cleanSkillName(s.name)]; return sk ? skLabel(sk) : s.name; } // v1.16: Starter Skill ของวงศาแสดงชื่อเดียวกับคัมภีร์
function skillCard(sk, selected, onToggle, disabled){
  const meta = [sk.category!=='Sorcery' ? tag(sk.subcategory) : tag(sk.subcategory,'prop'), sk.tier? tag(sk.tier, sk.tier==='Master'?'neg':sk.tier==='Expert'?'warn':'ok') : null, sk.ipCost!=null ? tag(`${sk.ipCost} IP`) : null, sk.type? tag(sk.type.length>40? sk.type.slice(0,40)+'…' : sk.type) : null, sk.cost? tag('Cost '+sk.cost,'stat'):null, sk.components? tag('Comp '+sk.components):null];
  const el = h('div',{class:'sk'+(selected?' sel':'')+(disabled?' disabled':''), onclick:()=>{ if(!disabled||selected) onToggle(); }},
    h('div',{class:'h'}, h('b',{class: hueCls(sk.nameEn, sk.type, sk.flavor, sk.effect).trim(), text:skTh(sk)}), h('span',{class:'dim',text:skEn(sk)}), ...meta),
    sk.condition ? h('div',{class:'eff',style:'color:var(--warn)'}, 'เงื่อนไข: ', T(sk.condition)) : null,
    sk.flavor ? h('div',{class:'eff flavor'}, T(sk.flavor)) : null,
    h('div',{class:'eff'}, T(sk.effect||'')),
    sk.extra && sk.extra.length ? h('details',null, h('summary',{text:'รายละเอียดเพิ่ม'}), sk.extra.map(x=>h('div',{class:'eff'}, T(x)))) : null);
  return el;
}
function skillPicker(c, slotKey, pools, count, title){
  const kin = c.kin ? KIN[c.kin] : null;
  c.skillSlots = c.skillSlots || {};
  const chosen = c.skillSlots[slotKey] || (c.skillSlots[slotKey] = []);
  const box = h('div',{class:'card',style:'margin-top:10px'});
  box.append(h('h4',null, title, ' ', h('span',{class:'tag '+(chosen.length===count?'ok':'warn'), text:`เลือกแล้ว ${chosen.length}/${count}`})));
  const taken = new Set(allSkills(c).filter(n=>!chosen.includes(n)));
  let list = DATA.skills.filter(sk => pools.some(p=>poolMatch(sk,p,kin)) && !taken.has(sk.nameEn));
  const filterKey = slotKey;
  const q = (W.skFilter[filterKey]||'');
  const subcats = [...new Set(list.map(s=>s.subcategory))];
  const inp = h('input',{type:'search',placeholder:'ค้นชื่อหรือข้อความ',value:q.text||'', oninput:(e)=>{ W.skFilter[filterKey]={...(W.skFilter[filterKey]||{}), text:e.target.value}; renderWizard(); }});
  const catSel = h('select',{onchange:(e)=>{ W.skFilter[filterKey]={...(W.skFilter[filterKey]||{}), cat:e.target.value}; renderWizard(); }}, h('option',{value:'',text:'ทุกหมวด'}), subcats.map(sc=>h('option',{value:sc, selected:(q.cat===sc), text:sc})));
  box.append(h('div',{class:'skfilter'}, inp, catSel, h('span',{class:'dim',style:'font-size:13px',text:`${list.length} รายการ`})));
  if (q.text){ const t=q.text.toLowerCase(); list = list.filter(s=> (s.nameEn+' '+s.nameTh+' '+(s.flavor||'')+' '+(s.effect||'')).toLowerCase().includes(t)); }
  if (q.cat) list = list.filter(s=>s.subcategory===q.cat);
  const full = chosen.length>=count;
  const lst = h('div',{class:'sklist'});
  // chosen first
  for (const n of chosen){ const sk=SKILL_BY_NAME[n]; if (sk) lst.append(skillCard(sk,true,()=>{ chosen.splice(chosen.indexOf(n),1); renderWizard(); })); }
  for (const sk of list){ if (chosen.includes(sk.nameEn)) continue; lst.append(skillCard(sk,false,()=>{ chosen.push(sk.nameEn); renderWizard(); }, full)); }
  box.append(lst);
  return box;
}
function knowledgePicker(c, slotKey, opts, title){
  // opts: {from:[], exclude:[], fixed:'', maxLevel:2, maxBefore:1}
  c.kslots = c.kslots || {};
  const slot = c.kslots[slotKey] || (c.kslots[slotKey] = {id:null, prof:null});
  if (opts.fixed) slot.id = opts.fixed;
  const box = h('div',{class:'card',style:'margin-top:10px'});
  box.append(h('h4',null, title, ' ', h('span',{class:'tag '+(!slotIncomplete(slot) ? 'ok':'warn'), text: slot.id ? (slot.prof ? `${knLabel(KNOW[slot.id])} · ${profLabel(slot)}` + (slotIncomplete(slot) ? ' (เลือกความเชื่อ)' : '') : 'เลือก Proficiency') : 'ยังไม่เลือก'})));
  // ระดับ "ก่อนช่องนี้" นับเฉพาะช่องที่มาก่อนตามลำดับคงที่ (Talent → ฟรี → ของวงศา → IP ตามลำดับบนหน้า) ไม่งั้นสองช่องที่เลือกความรู้เดียวกันจะนับกันเองแล้วเด้งไประดับถัดไปทั้งคู่ ทำให้ Proficiency ที่เลือกไว้หายไฮไลต์
  const others = Object.entries(c.kslots).filter(([k])=>k!==slotKey).map(([,v])=>v);
  const before = Object.entries(c.kslots).filter(([k])=>k!==slotKey && slotBefore(k, slotKey)).map(([,v])=>v);
  const lvBefore = Object.fromEntries(DATA.knowledge.map(k=>[k.id,0]));
  for (const s of before) if (s && s.id) lvBefore[s.id]++;
  if (!opts.fixed){
    const btns = DATA.knowledge.filter(k => (!opts.from || opts.from.includes(k.id)) && !(opts.exclude||[]).includes(k.id)).map(k=>{
      const before = lvBefore[k.id]; const after = before+1;
      const blocked = after>3 || (opts.maxLevel && after>opts.maxLevel) || (opts.maxBefore!=null && before>opts.maxBefore);
      return h('button',{class:'small'+(slot.id===k.id?' primary':''), disabled: blocked && slot.id!==k.id, title: blocked?'ระดับเกินเพดานของช่องนี้':'', onclick:()=>{ slot.id=k.id; slot.prof=null; renderWizard(); }, text:`${knLabel(k)} · ${k.stats.join('/')} · Lv${before}→${after}`});
    });
    box.append(h('div',{class:'row',style:'margin:6px 0'}, btns));
  }
  if (slot.id){
    const k = KNOW[slot.id]; const newLv = Math.min(3, lvBefore[slot.id]+1);
    const L = k.levels[String(newLv)];
    // ถ้าช่องก่อนหน้าเปลี่ยนจนระดับของช่องนี้ขยับ Proficiency เดิมอาจไม่อยู่ในระดับใหม่ → ล้างให้เลือกใหม่ (ไม่ปล่อยให้ค้างแบบมองไม่เห็น)
    if (slot.prof && !slot.prof.startsWith('(') && L && L.proficiencies.length && !L.proficiencies.some(p=>p.name===slot.prof)){ slot.prof = null; slot.faith = null; }
    box.append(h('div',{class:'infobox'}, h('b',{text:`${knLabel(k)} · ค่าพลังกำกับ ${k.stats.join(', ')} · ระดับ ${newLv}`}), h('div',{class:'desc'}, T(L && L.text ? L.text : ''))));
    if (L && L.proficiencies.length){
      box.append(h('div',{class:'dim',style:'margin-top:6px;font-size:13px',text: (L.profLabel||'เลือก Proficiency') + ' 1 อย่าง'}));
      const usedProfs = new Set(others.filter(s=>s && s.id===slot.id && s.prof).map(s=>s.prof));
      const groups = profGroups(L);
      box.append(h('div',{class:'grid',style:'margin-top:6px'}, groups.map(g=>{ const p = g.prof; const taken = usedProfs.has(p.name) && slot.prof!==p.name; return h('div',{class:'sk'+(slot.prof===p.name?' sel':'')+(taken?' disabled':''), onclick:()=>{ if (taken){ toast('Proficiency นี้เลือกไปแล้วในช่องอื่น'); return; } if (slot.prof!==p.name){ slot.prof=p.name; slot.faith=null; } renderWizard();}}, h('div',{class:'h'}, h('b',{text:p.name}), g.subs.length ? tag(`เลือกความเชื่อ 1 จาก ${g.subs.length}`,'prop') : null, taken? tag('เลือกแล้ว','warn'):null), p.flavor ? h('div',{class:'eff flavor'}, T(p.flavor)) : null, h('div',{class:'eff'}, T(p.text))); })));
      const sel = groups.find(g=>g.prof.name===slot.prof);
      if (sel && sel.subs.length){
        const have = charFaith(c, slotKey);
        box.append(h('div',{class:'infobox',style:'margin-top:8px'}, h('b',{text:`${slot.prof}: เลือกความเชื่อ 1 อย่าง`}), have ? h('div',{class:'dim',style:'font-size:12.5px',text:`ตัวละครนี้นับถือ "${have}" อยู่แล้ว เลือกได้เฉพาะความเชื่อเดียวกัน`}) : null,
          h('div',{class:'grid',style:'margin-top:6px'}, sel.subs.map(f=>{ const key = faithKey(f.name); const blocked = !!(have && key && have!==key); return h('div',{class:'sk'+(slot.faith===f.name?' sel':'')+(blocked?' disabled':''), onclick:()=>{ if (blocked){ toast('ต้องเป็นความเชื่อเดียวกับที่ตัวละครมีอยู่'); return; } slot.faith = f.name; renderWizard(); }}, h('div',{class:'h'}, h('b',{text:faithShort(f.name)})), h('div',{class:'eff'}, T(f.text))); }))));
      } else slot.faith = null;
    } else if (L) { slot.prof = slot.prof || '(ระดับนี้ไม่มี Proficiency ให้เลือก)'; }
  }
  return box;
}
function stepTalent(body, c, d){
  if (!c.kin){ body.append(h('div',{class:'warnbox',text:'เลือกวงศาก่อน'})); return; }
  const kin = KIN[c.kin];
  c.kslots = c.kslots || {}; c.skillSlots = c.skillSlots || {}; c.grants = c.grants || [];
  // eligible talents
  body.append(h('div',{class:'infobox',style:'margin-bottom:10px'}, `ค่าพลังหลักที่ Mod สูงสุดตอนนี้: `, h('b',{text:d.highest.join(', ') + ` (Mod ${signed(d.mod[d.highest[0]])})`}), ` เลือก Talent ได้จากค่าเหล่านี้ 1 อย่าง หรือเลือก Educated แทน`));
  const tl = h('div',{class:'grid three'});
  for (const t of DATA.talents){
    const ok = t.key==='EDU' || d.highest.includes(t.key);
    tl.append(h('div',{class:'card pick'+(c.talent===t.key?' sel':'')+(ok?'':' disabled'), onclick:()=>{ if(!ok) return; if (c.talent!==t.key){ c.talent=t.key; c.talentPicks={}; for (const k of Object.keys(c.kslots)) if (k.startsWith('talent')) delete c.kslots[k]; for (const k of Object.keys(c.skillSlots)) if (k.startsWith('talent')) delete c.skillSlots[k]; c.grants = c.grants.filter(g=>!['Nimble Grace','Robust','Tactical Expert','Observation Mastery','Interceptor'].includes(g)); } renderWizard(); }},
      h('h3',{text:t.label}), h('ol',{style:'margin:6px 0;padding-left:18px;font-size:13px;color:var(--bone-dim)'}, t.steps.map(s=>h('li',null, T(s.text))))));
  }
  body.append(tl);
  if (c.talent){
    const t = DATA.talents.find(x=>x.key===c.talent);
    body.append(h('h3',{style:'margin-top:16px',text:`ของจาก ${t.label}`}));
    t.steps.forEach((s,i)=>{
      const key = `talent-${i}`;
      if (s.kind==='skills') body.append(skillPicker(c, key, s.pools, s.count, `ขั้น ${i+1}: ${s.text}`));
      else if (s.kind==='knowledge'){
        if (s.count && s.count>1){ for (let j=0;j<s.count;j++) body.append(knowledgePicker(c, `${key}-${j}`, {from:s.from, exclude:s.exclude}, `ขั้น ${i+1} (${j+1}/${s.count}): ${s.text}`)); }
        else body.append(knowledgePicker(c, key, {from:s.from, exclude:s.exclude, fixed:s.fixed, maxBefore:s.maxBefore}, `ขั้น ${i+1}: ${s.text}`));
      } else if (s.kind==='choice'){
        const pick = c.talentPicks[key];
        const box = h('div',{class:'card',style:'margin-top:10px'}, h('h4',{text:`ขั้น ${i+1}: ${s.text}`}));
        box.append(h('div',{class:'grid',style:'margin-top:6px'}, s.options.map(o=>{ const sk=SKILL_BY_NAME[o]; return skillCard(sk, pick===o, ()=>{ c.talentPicks[key]=o; c.grants = c.grants.filter(g=>!s.options.includes(g)); c.grants.push(o); renderWizard(); }); })));
        body.append(box);
      } else if (s.kind==='grant'){
        const already = s.skill==='Nimble Grace' && (kin.traits.some(t=>t.nameEn==='Nimble Grace') || kin.starterSkills.some(x=>x.name.includes('Nimble Grace')));
        if (already && s.altPools){ body.append(h('div',{class:'infobox',style:'margin-top:10px',text:`วงศานี้มี Nimble Grace อยู่แล้ว จึงได้เลือก Tactical & General Skill 1 อย่างแทน`})); body.append(skillPicker(c, key, s.altPools, 1, `ขั้น ${i+1}: เลือก Tactical & General Skill แทน Nimble Grace`)); }
        else { if (!c.grants.includes(s.skill)) c.grants.push(s.skill); const sk=SKILL_BY_NAME[s.skill]; body.append(h('div',{class:'card',style:'margin-top:10px'}, h('h4',{text:`ขั้น ${i+1}: ได้รับอัตโนมัติ`}), sk? skillCard(sk,true,()=>{}) : h('div',{class:'desc',text:s.text}))); }
      }
    });
  }
  body.append(h('h3',{style:'margin-top:18px',text:'อัปเกรด Knowledge 1 ระดับ (ทุกตัวละคร ขั้น 5 ของไฟล์แกน)'}));
  body.append(knowledgePicker(c, 'free', {}, 'Upgrade Knowledge ใด ๆ 1 ระดับ'));
  if (kin.knowledgeGrants.length){
    body.append(h('h3',{style:'margin-top:18px',text:'ของจากวงศา (Benefits)'}));
    kin.knowledgeGrants.forEach((g,i)=>{ body.append(knowledgePicker(c, `kin-${i}`, {fixed:g.fixed, maxLevel:g.maxLevel}, `${g.source}: ` + (g.fixed ? `ได้ ${knLabel(KNOW[g.fixed])} 1 ระดับ` : 'เพิ่มระดับความรู้ใด ๆ 1 ขั้น (ไม่ถึงระดับ 3 ตอนสร้าง)'))); });
    if (kin.adaptationChoice){ body.append(h('div',{class:'card',style:'margin-top:10px'}, h('h4',{text:'Cross-Cultural Adaptation: เลือก Adaptation 1 อย่าง'}), h('div',{class:'row',style:'margin-top:6px'}, kin.adaptationChoice.map(a=>h('button',{class:'small'+(c.adaptation===a?' primary':''),onclick:()=>{c.adaptation=a; renderWizard();},text:a}))))); }
  }
  // starter skills status
  if (kin.starterSkills.length){
    body.append(h('h3',{style:'margin-top:18px',text:'Starter Skill ของวงศา'}));
    const box = h('div',{class:'card',style:'margin-top:8px'});
    for (const s of kin.starterSkills){ const ok = starterCondOk(s.condition, d); const sk = SKILL_BY_NAME[cleanSkillName(s.name)]; box.append(h('div',{style:'margin:4px 0'}, tag(ok?'ได้รับ':'ไม่เข้าเงื่อนไข', ok?'ok':'neg'), ' ', h('b',{text:starterLabel(s)}), s.condition? h('span',{class:'desc',text:` เงื่อนไข: ${s.condition}`}):null, sk? h('div',{class:'desc',text:sk.effect}):null)); }
    body.append(box);
  }
}

/* ---------- Step 6: computed ---------- */
function stepCalc(body, c, d){
  if (!c.kin){ body.append(h('div',{class:'warnbox',text:'เลือกวงศาก่อน'})); return; }
  const tb = h('table',{class:'t'}, h('thead',null, h('tr',null, h('th',{text:'ค่า'}), h('th',{text:'ผล'}), h('th',{text:'ที่มา / สูตร'}))));
  const row=(k,v,src,prop)=>tb.append(h('tr',null, h('td',null, T(k), prop? [' ', tag('เสนอ','prop')] : null), h('td',{class:'num'}, h('b',{text:v})), h('td',{class:'dim'}, T(src))));
  for (const s of STATS) row(`${s} (Raw / Mod)`, `${d.raw[s]} / ${signed(d.mod[s])}`, `${KIN[c.kin].raw[s]} จากวงศา ${d.from[s].join(', ')} · Mod = (ค่า/2) - 5 ปัดลง`);
  row('Max HP', d.hp, '10 + VIT Mod + STR Mod');
  row('Max MP', d.mp, '10 + INF Mod + INT Mod (ไฟล์แกนบรรทัด 161 พิมพ์หัวข้อว่า Max HP ซ้ำ อ่านเป็น MP)');
  row('Toughness (แยกตามอวัยวะ 6 ส่วน)', d.toughness, '((Raw VIT + Raw STR) / 10) + 1 ปัดลง' + (d.toughSizeBonus? ` + ${d.toughSizeBonus} จากขนาด ${d.size}` : '') + ' ใช้กับ ศีรษะ ลำตัว แขน 2 ขา 2 แยกกัน · คงที่ตลอดชีวิต ยกได้ด้วยอุปกรณ์เท่านั้น' + (toughnessHint(d) ? ' · ' + toughnessHint(d) : ''));
  row('Max Sanity', d.sanity, '5 + INF Mod');
  row('Passive PER', d.passivePer, '7 + PER Mod ใช้เป็น DC ให้คนอื่นทอยซ่อนจากคุณ');
  row('Capacity (แบกได้)', `${d.capacity} กก.`, `STR × ${d.capMult} (${d.size})` + (d.capNote? ' · '+d.capNote : ''));
  row('Speed', '', d.speed + ' (ตามวงศา; ไฟล์แกน: Run = Speed + AGI Mod ต่อวินาที)');
  row('Initiative', signed(d.initiative), 'PER Mod ทอย 2d6 + Initiative');
  row('Reflex', signed(d.reflex), '(AGI Mod / 2) + 1 ปัดลง');
  row('Might', signed(d.might), '(STR Mod / 2) + 1 ปัดลง บวกความเสียหายประชิด Perfect Strike คูณ 2');
  row('Sight', signed(d.sight), '(PER Mod / 2) + 1 ปัดลง ใช้กับ Focus (Precise) และ Range');
  row('VIT Saving Throw', signed(d.fortitude), 'ทอยป้องกันทางกาย = 2d6 + VIT Mod');
  row('PER Saving Throw', signed(d.will), 'ทอยป้องกันทางใจ = 2d6 + PER Mod');
  row('Parry Dice', d.parryDice, 'เริ่ม 0 โล่และของบางชิ้นให้ +1 = ทอยเต๋าเพิ่มตอน Parry แล้วเลือกเอง 2 ลูก');
  row('Combat Dice', d.combatDice, 'ปกติ 2d6 เลือก 2 ลูกเป็น CV เลขเหมือนกัน = Perfect Strike');
  body.append(h('div',{class:'tablewrap'}, tb));
  const kl = knowledgeLevels(c);
  const kt = h('table',{class:'t',style:'margin-top:14px'}, h('thead',null, h('tr',null, h('th',{text:'Knowledge'}), h('th',{text:'ระดับ'}), h('th',{text:'Proficiency'}), h('th',{text:'ทอย'}))));
  for (const k of DATA.knowledge){ const profs = Object.values(c.kslots||{}).filter(s=>s&&s.id===k.id&&s.prof&&!s.prof.startsWith('(')).map(s=>profLabel(s)); const kb2 = knowledgeBonus(c, d, k); kt.append(h('tr',null, h('td',{text:knLabel(k)}), h('td',{class:'num',text:kl[k.id]}), h('td',{text:profs.join(', ')||'—'}), h('td',{class:'dim num',text:`2d6 ${signed(kb2.total)} (ระดับ ${kb2.lv})`}))); }
  body.append(h('h3',{style:'margin-top:16px',text:'ความรู้ 13 สาขา'}), h('div',{class:'tablewrap'}, kt));
  body.append(h('p',{class:'dim',style:'font-size:13px;margin-top:10px',text:'Knowledge Check = 2d6 + ระดับความรู้ + บุคลิกภาพที่เกี่ยวข้อง ไม่รวม Mod ของค่าพลัง (คำตัดสิน 9 พ.ย. 2026) Proficiency Trait คือความสามารถพิเศษของระดับนั้น ไม่ได้บวกเลขทอย'}));
}

/* ---------- Step 7: details ---------- */
function stepDetails(body, c){
  c.details = Object.assign({player:'',age:'',gender:'',job:'',height:'',likes:'',dislikes:'',fears:'',motivation:'',want:'',need:'',manifest:'',backstory:'',appearance:'',signature:''}, c.details||{});
  const f=(label, key, multi, ph)=>{ let inp; if (multi){ inp = h('textarea',{placeholder:ph||'',oninput:(e)=>{c.details[key]=e.target.value; coachLater();}}); inp.value = c.details[key]||''; } else inp = h('input',{style:'width:100%',value:c.details[key]||'',placeholder:ph||'', oninput:(e)=>{c.details[key]=e.target.value; coachLater();}}); return h('div',{style:'margin-bottom:10px'}, h('label',null, T(label)), h('div',null, inp)); };
  const name = h('input',{style:'width:100%',value:c.name, placeholder:'ชื่อตัวละคร (อิงธรรมเนียมของวงศาได้)', oninput:(e)=>{c.name=e.target.value; coachLater();}});
  body.append(h('div',{class:'grid two'},
    h('div',{class:'card'}, h('h4',{text:'ตัวตน'}), h('div',{style:'margin-bottom:10px'}, h('label',{text:'ชื่อตัวละคร (Character Name)'}), h('div',null,name)), f('ชื่อผู้เล่น (Player name)','player'), f('อายุ (Age)','age'), f('เพศ (Gender)','gender'), f('อาชีพ (Job)','job',false,'เช่น ทหารรับจ้าง นักบวช'), f('ส่วนสูง/น้ำหนัก (Height/Weight)','height'), f('รูปลักษณ์ (Appearance)','appearance',true)),
    h('div',{class:'card'}, h('h4',{text:'นิสัยส่วนตัว (Personal Traits)'}), f('ชอบ (Likes)','likes'), f('ไม่ชอบ (Dislikes)','dislikes'), f('หวาดกลัว (Fears)','fears'), f('แรงจูงใจของตัวละคร (Character Motivation)','motivation',true), f('Want สิ่งที่ต้องการ','want'), f('Need สิ่งที่จำเป็น','need'), f('Manifest การตกผลึก','manifest'))));
  body.append(h('div',{class:'card',style:'margin-top:12px'}, f('เรื่องราว (Backstory) ให้สอดคล้องกับวงศาและพื้นหลังที่เลือก','backstory',true), f('เอกลักษณ์ (Signature Look) ไอเทมหรือลักษณะเฉพาะที่ตกลงกับ GM เป็น Trait 1 อย่าง ไอเทมเอกลักษณ์ไม่กินช่องเก็บของ ไม่นับน้ำหนัก','signature',true)));
}

/* ---------- Step 8: starter set ---------- */
function stepSet(body, c, d){
  const S = DATA.sets;
  body.append(h('div',{class:'infobox',style:'margin-bottom:12px'}, h('b',{text:'ชุดยังชีพ (ทุกชุดได้เหมือนกัน) + เงิน 15 เกรฟ: '}), S.common.items.map(i=>`${i.name} (${i.price} เกรฟ, ${i.weight} กก.)`).join(' · ')));
  const grid = h('div',{class:'grid two'});
  for (const s of S.sets){
    const sel = c.starterSet===s.nameEn;
    const wt = parseFloat(s.totalWeight) || 0; const over = wt + 2.8 > d.capacity;
    grid.append(h('div',{class:'card pick'+(sel?' sel':''), tabindex:0, role:'button', onclick:()=>{c.starterSet=s.nameEn; renderWizard();}, onkeydown:(e)=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); e.currentTarget.click(); } }},
      h('h3',null, s.nameEn, h('span',{class:'en',text:s.nameTh})),
      h('div',{class:'gives'}, tag(s.archetype,'prop'), tag(`มูลค่า ${s.total}`), tag(`น้ำหนัก ${s.totalWeight} กก.`, over?'neg':''), over? tag(`เกินแบก ${d.capacity} กก.`,'neg') : null),
      h('div',{class:'desc',text:s.desc}),
      h('div',{class:'desc',style:'margin-top:6px'}, h('b',{text:'ของหลัก: '}), s.items.map(i=>i.name.replace(/\s*\(.*?\)\s*/,' ').trim()).join(', '))));
  }
  body.append(grid);
  if (c.starterSet){
    const s = S.sets.find(x=>x.nameEn===c.starterSet);
    c.starterPicks = c.starterPicks || {};
    const groups = setItemGroups(s);
    const altBox = h('div');
    groups.forEach((g, gi) => { if (g.items.length < 2) return; const cur = Math.min(g.items.length-1, +(c.starterPicks[gi]||0));
      altBox.append(h('div',{class:'card',style:'margin-top:12px'}, h('h4',{text:'ชุดนี้ให้เลือกอาวุธ 1 อย่าง'}), h('div',{class:'altpick'}, g.items.map((it, ii)=>{ const rq = itemRequirement(it.name); const ok = !rq || (d.raw[rq.stat]||0) >= rq.value;
        return h('label',{class:'opt'+(cur===ii?' sel':'')}, h('input',{type:'radio',name:'alt'+gi,checked:cur===ii,onchange:()=>{ c.starterPicks[gi]=ii; renderWizard(); }}), h('div',null, h('b',{text:cleanAltName(it.name)}), rq ? (ok ? tag(`ต้องการ ${rq.label} ✓`,'ok') : tag(`ต้องการ ${rq.label} ค่าไม่ถึง`,'warn')) : null, h('div',{class:'desc',style:'font-size:12.5px'}, T(it.effect||'')), h('div',{class:'dim',style:'font-size:11.5px',text:`ราคา ${it.price} · ${it.weight} กก.`}))); }))));
    });
    body.append(altBox);
    const tb = h('table',{class:'t'}, h('thead',null, h('tr',null, h('th',{text:'ไอเทม'}), h('th',{text:'ราคา'}), h('th',{text:'กก.'}), h('th',{text:'ทำอะไรให้'}))));
    for (const i of chosenSetItems(c, s)) tb.append(h('tr',null, h('td',null, i.name, i.flags.length? [' ', ...i.flags.map(f=>tag(f,'warn'))] : null), h('td',{class:'num',text:i.price}), h('td',{class:'num',text:i.weight}), h('td',{class:'dim',text:i.effect})));
    const det = h('div',{class:'card',style:'margin-top:14px'}, h('h3',null, s.nameEn, h('span',{class:'en',text:s.nameTh})), h('div',{class:'tablewrap'}, tb));
    const dl = h('dl'); const add=(a,b)=>{ if(b) dl.append(h('dt',{text:a}),h('dd',{text:b})); };
    add('ตั้งตัวด้วย', s.income); add('แต่งกายแนะนำ', s.outfit); add('พื้นหลังที่เข้าชุด', s.backgrounds); add('หมายเหตุ', s.notes);
    det.append(h('div',{class:'summary',style:'margin-top:10px'}, dl));
    body.append(det);
  }
  if (hasFleshforge(c)) body.append(fleshforgePicker(c, {locked: Store.inCampaign(c) && !Store.isDevUid, onChange: renderWizard}));
  body.append(h('details',{style:'margin-top:12px'}, h('summary',{text:'กติกาชุดเริ่มต้น 10 ข้อ'}), h('ol',{style:'font-size:13px;color:var(--bone-dim)'}, S.rules.map(r=>h('li',{text:r})))));
}

function finishWizard(){
  const c = W.char;
  for (let i=0;i<STEP_DEFS.length;i++){ const e=stepBlocker(i); if (e){ toast(e); W.step=i; renderWizard(); return; } }
  const d = compute(c);
  c.current = c.current || {hp:d.hp, mp:d.mp, sanity:d.sanity, tough:Object.fromEntries(DATA.meta.bodyParts.map(([k])=>[k,d.toughness])), ap:3, ip:0, money:15};
  c.step = STEP_DEFS.length;
  c.done = true;
  Store.upsert(c);
  toast('บันทึกตัวละครแล้ว');
  location.hash = '#sheet-' + c.id;
}
