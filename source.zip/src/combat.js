/* ===== v1.28 (Non สั่ง 13 พ.ย. 2026 ต่อบนฐาน v1.27 เมื่อ 16 พ.ย. 2026): ระบบโจมตีแบบมีขั้นตอนในโต๊ะเล่น =====
 * ลำดับ: ผู้โจมตีเปิดหน้าต่างโจมตี เลือกเป้า (คลิกหมากบนแผนที่ได้) อาวุธ และแบบการโจมตี หน้าต่างบอกระยะ ว่าไกลเกินหรือโดนลด CV
 *        → ทอยโจมตี (ข้อความ kind 'roll' ที่มี flow) → ฝ่ายรับ (เจ้าของหมาก หรือ GM ถ้าเป็น NPC) เลือก Parry / Evade / ใช้ทักษะ / ไม่ป้องกัน
 *        → เต๋าชนกัน (ข้อความ kind 'clash') → เครื่องของฝ่ายรับคิดความเสียหาย หักเกราะ ลง HP และ Toughness ให้
 * กฎที่ใช้: ไฟล์แกน บท "ระบบการต่อสู้" ข้อ 2 ถึง 5 คุณสมบัติอาวุธในไฟล์ Item All และคำเคาะ 15 ถึง 16 พ.ย. 2026
 *   (เกราะหลักบวกเกราะรองของชนิดในวงเล็บ · เกราะหลักหักเวทด้วย · ของพังเหลือครึ่ง · NPC ใช้กฎเดียวกับผู้เล่น)
 * ค่าของ NPC อ่านจากสิ่งที่หมากมีอยู่แล้ว: ค่าพลังดัดแปลง (t.mods) อาวุธและชุดเกราะ (t.equip) การโจมตีในสแตตบล็อก (t.attacks) วิธีป้องกัน (t.defend)
 * ===== v1.29 (Non สั่ง 16 พ.ย. 2026 รอบสอง) =====
 *   1. ยิงเกินระยะแม่น -1 CV ต่อทุก 2 ม. · 3. ประชิดบวก Might อาวุธระยะไกลและการขว้างบวก Sight (ตายตัว GM เปลี่ยนได้) · 4. Rip ระบบตรวจเองแล้วถามผู้โจมตีในการ์ดผล
 *   5. Focus เสีย 1 Swift Action และการโจมตีหัก Action ตาม Action Track (actions.js) · 8. Trait ที่เกี่ยวกับการป้องกันเป็นตัวเลือกให้ติ๊ก (feats.js)
 *   9. Parry Dice ตายตัวตามอุปกรณ์และความสามารถ GM ให้เพิ่มได้ · 10 และ 11. Reaction เล็งผู้โจมตีเอง สกิลที่ระบบรู้จักกดครั้งเดียวจบ · 12. หน้าต่างลากย้ายได้
 *   13. Parry ดูกลุ่มจากเลขที่ทอยได้แม้ถูกเล็ง · 14. โจมตีจากการซ่อนตัว = Advantage และ Perfect Strike แล้วหลุดจากการซ่อนตัว · 15. Trait เข้าหน้าต่างโจมตี
 * ข้อความเอฟเฟกต์ของอาวุธที่เขียนเป็นแบบแผน (On-Hit ติดสภาวะ) ระบบทำให้เอง ส่วนที่เป็นเงื่อนไขเฉพาะขึ้นเป็นปุ่มหรือข้อความให้ตัดสิน ไม่เดาแทน */

/* ---------- 1. ตัวอ่านข้อความกฎ (ไม่แตะหน้าจอ) ---------- */
const CB_PHYS = ['Slashing','Piercing','Blunt','Physical'];
const CB_DTYPES = ['Slashing','Piercing','Blunt','Physical','Fire','Plasma','Electric','Frost','Necrotic','Sonic','Acid','Poison','Light'];
const CB_PENDING_MS = 15 * 60 * 1000;        // การโจมตีที่ค้างเกินนี้ไม่เด้งถามฝ่ายรับอีก
function cbInt(v, d){ const n = parseInt(v, 10); return isFinite(n) ? n : (d || 0); }
function cbNormType(t){
  const s = String(t || '').trim(); if (!s) return '';
  const k = s.toLowerCase();
  if (/^slash/.test(k)) return 'Slashing'; if (/^pierc/.test(k)) return 'Piercing'; if (/^(blunt|bludgeon)/.test(k)) return 'Blunt'; if (/^(phys|pdmg)/.test(k)) return 'Physical'; if (/^corrode/.test(k)) return 'Acid'; if (/^burn/.test(k)) return 'Fire';
  return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
}
function cbIsPhysical(t){ return CB_PHYS.includes(cbNormType(t)); }
/* ทอยนิพจน์ความเสียหาย: "2" · "1d6" · "2d6+1" · "1d3" (อย่างอื่นนับเป็น 0) */
const CB_DICE_RX = /^\s*(\d{1,2})\s*d\s*(\d{1,3})\s*(?:([+-])\s*(\d{1,3}))?\s*$/i;
function cbRollExpr(expr){
  const s = String(expr == null ? '' : expr).trim(); const m = CB_DICE_RX.exec(s);
  if (!m){ const n = parseInt(s, 10); const v = isFinite(n) ? n : 0; return {total: v, rolls: [], add: 0, text: String(v)}; }
  const cnt = Math.min(20, Math.max(1, +m[1])), sides = Math.min(100, Math.max(2, +m[2])); const add = m[3] ? (m[3] === '-' ? -1 : 1) * (+m[4]) : 0;
  const rolls = Array.from({length: cnt}, ()=>rollDie(sides)); const total = rolls.reduce((a, b)=>a + b, 0) + add;
  return {total, rolls, add, text: `${cnt}d${sides}${add ? signed(add) : ''} [${rolls.join(',')}]${add ? ' ' + signed(add) : ''} = ${total}`};
}
function cbExprOk(expr){ const s = String(expr == null ? '' : expr).trim(); return /^\d{1,3}$/.test(s) || CB_DICE_RX.test(s); }
function cbExprAvg(expr){ const s = String(expr == null ? '' : expr).trim(); const m = CB_DICE_RX.exec(s); if (!m) return cbInt(s); return (+m[1]) * ((+m[2]) + 1) / 2 + (m[3] ? (m[3] === '-' ? -1 : 1) * (+m[4]) : 0); }
/* สภาวะที่ข้อความเอ่ยถึง พร้อมระดับถ้าเขียนไว้ติดกัน ใช้เป็นปุ่มเสนอในการ์ดผล ไม่ใส่ให้เอง */
const CB_COND_ALIAS = {Burn:'Burning', Stun:'Stunned', Poison:'Poisoned', Bleed:'Bleeding', Root:'Rooted', Blind:'Blinded'};
/* สภาวะที่อาวุธใส่ให้เป้าได้ (ตัดสภาวะเชิงบวกและสภาวะจากสภาพแวดล้อมออกจากปุ่มเสนอของอาวุธ) */
const CB_HIT_CONDS = new Set(['Stunned','Unbalanced','Prone','Bleeding','Deepwound','Burning','Poisoned','Rooted','Grappled','Blinded','Deafened','Frightened','Confused','Silenced','Sundered','Marked','Incapacitated']);
function cbCondNames(){ if (!cbCondNames.list) cbCondNames.list = Object.entries(GLOSSARY).filter(([k, v])=>/Condition/.test((v && v.cat) || '')).map(([k])=>k); return cbCondNames.list; }
function cbFindConds(text){
  const out = []; const seen = new Set(); const s = String(text || '');
  const tryAdd = (id, word)=>{ if (!id || seen.has(id)) return;
    const rx = new RegExp('(?:(\\d+)\\s*)?["“”\']?\\b' + word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b["“”\']?(?:\\s*(\\d+)(?!\\s*(?:เมตร|รอบ|เทิร์น|นาที|ชั่วโมง|วินาที|ครั้ง|%|ม\\.)))?');
    const m = rx.exec(s); if (!m) return; seen.add(id);
    out.push({id, lv: (typeof COND_STACK !== 'undefined' && COND_STACK.has(id)) ? Math.max(1, Math.min(20, cbInt(m[1] || m[2], 1))) : null}); };
  for (const id of cbCondNames()) tryAdd(id, id);
  for (const [w, id] of Object.entries(CB_COND_ALIAS)) tryAdd(id, w);
  return out;
}
/* อ่านอาวุธจากชื่อและข้อความเอฟเฟกต์: ความเสียหายตั้งต้น ประเภท คุณสมบัติ (on = อยู่ในรายการคุณสมบัติหลัก ไม่มีเงื่อนไขนำหน้า) */
const CB_PROPS = [['rip',/\bRip\b/],['ap',/\bArmor Penetrate\b/],['gb',/\bGuard Break\b/],['impact',/\bImpact\b/],['headshot',/\bHead\s?[Ss]hot\b/],['impale',/\bImpale\b/],['cleave',/\bCleave\b/],['delay',/\bDelay\b/],['throwable',/\bThrowable\b/],['reach',/\bReach\b/],['reload',/\bReload\b/],['cone',/\bCone Attack\b/]];
const CB_PROP_LABEL = {rip:'Rip', ap:'Armor Penetrate', gb:'Guard Break', impact:'Impact', headshot:'Headshot', impale:'Impale', cleave:'Cleave', delay:'Delay', throwable:'Throwable', reach:'Reach', reload:'Reload', cone:'Cone Attack'};
const CB_COND_RX = /หาก|เมื่อ|สามารถ|เลือก|On-?[Hh]it|Perfect|มิฉะนั้น|ถ้า/;
function cbItemCat(name){ if (!cbItemCat.map){ cbItemCat.map = {}; for (const it of DATA.items || []) cbItemCat.map[it.name] = it.cat || ''; } return cbItemCat.map[String(name || '')] || ''; }
function cbParseWeaponText(name, effect){
  const raw = String(effect || '').replace(/\\/g, '');
  const eff = (typeof weaponPropsText === 'function' ? weaponPropsText(raw) : raw).replace(/\(ต้องการ STR\s*\d+\)\s*/, '');
  const w = {name: String(name || '').trim() || 'อาวุธ', text: raw, dmg: '0', dtypes: ['Physical'], physical: true, props: {}, sharpnel: 0, toughX: 0, toughOpt: 0, toughPerfect: 0, ranged: false, bomb: false, statKind: 'might', conds: [], strNeed: 0, found: false};
  const dm = /(^|[^+\d])(\d+(?:d\d+)?)\s*(PDMG|Might|[A-Z][a-z]+ Damage)\s*(?:\(([^)]+)\)|(Slashing|Piercing|Blunt)\b)?/.exec(eff);
  let headFrom = 0, headTo = eff.length;
  if (dm && !/^(Tough|Toughness|Sanity)\b/.test(dm[3])){
    w.found = true; w.dmg = dm[2]; headFrom = dm.index;
    if (dm[3] === 'PDMG' || dm[3] === 'Might'){ const ts = (dm[4] || dm[5] || '').split(/[\/,]/).map(cbNormType).filter(t=>CB_DTYPES.includes(t)); w.dtypes = ts.length ? [...new Set(ts)] : ['Physical']; }
    else w.dtypes = [cbNormType(dm[3].replace(/ Damage$/, ''))];
    const after = dm.index + dm[0].length; const cm = CB_COND_RX.exec(eff.slice(after)); if (cm) headTo = after + cm.index;
  } else { const cm = CB_COND_RX.exec(eff); if (cm) headTo = cm.index; }
  w.physical = cbIsPhysical(w.dtypes[0]);
  const head = eff.slice(headFrom, headTo);
  // v1.29: คุณสมบัติที่เขียนเป็นคำเดี่ยวในรายการคั่นจุลภาค (เช่น "Grab On-Hit , Reach ," ของไม้ง่าม) เปิดอยู่เสมอ แม้อยู่หลังคำเงื่อนไขของข้ออื่น · "ขว้างได้ (Throwable)" ของมีดพรานก็เช่นกัน
  const toks = eff.split('· ชนิด')[0].split(/[,.·]/).map(x=>x.trim()).filter(x=>x && x.length <= 24);
  for (const [k, rx] of CB_PROPS) if (rx.test(eff)){ const whole = new RegExp('^' + rx.source + '$'); w.props[k] = {on: rx.test(head) || toks.some(x=>whole.test(x))}; }
  if (w.props.throwable && !w.props.throwable.on && /ขว้างได้\s*\(Throwable\)/.test(eff)) w.props.throwable.on = true;
  const sh = /(\d+)\s*Sharpnel\b|\bSharpnel\s*(\d+)/.exec(eff); if (sh) w.sharpnel = Math.min(6, cbInt(sh[1] || sh[2]));
  const tp = /Perfect Strike[^,.·]{0,24}?\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(eff); if (tp) w.toughPerfect = Math.min(6, cbInt(tp[1]));
  const th = /\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(head); if (th) w.toughX = Math.min(6, cbInt(th[1]));
  // "On-Hit ... +N Toughness Damage" ที่ไม่มีเงื่อนไขอื่นนำหน้าในประโยคเดียวกัน = เข้าทุกครั้งที่โดน (เช่น ขวานศึก)
  const oh = !th ? /(?:Attack\s+)?On-?[Hh]it[^.·]{0,40}?\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(eff) : null;
  if (oh){ const before = eff.slice(0, oh.index); const sent = before.slice(Math.max(before.lastIndexOf('.'), before.lastIndexOf('·')) + 1); if (!/หาก|เมื่อ|ถ้า|Perfect|เลือก/.test(sent)) w.toughX = Math.min(6, cbInt(oh[1])); }
  if (w.toughX){ /* มีค่าแน่นอนแล้ว */ } else { const to = /\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(eff.replace(/Perfect Strike[^,.·]{0,24}?\+\s*\d+\s*Tough(?:ness)?\s*Damage/, '')); if (to) w.toughOpt = Math.min(6, cbInt(to[1])); }
  w.bomb = /ชนิด:[^·]*ระเบิด/.test(eff);
  w.ranged = !!w.props.reload || /ชนิด:[^·]*(ธนู|ปืน|หน้าไม้|อาวุธเป่า|อาวุธปา|ระเบิด)/.test(eff) || cbItemCat(w.name) === 'อาวุธระยะไกล';
  w.ranged = !!(w.props.reload && w.props.reload.on) || /ชนิด:[^·]*(ธนู|ปืน|หน้าไม้|อาวุธเป่า|อาวุธปา|ระเบิด)/.test(eff.replace(/อุปกรณ์เสริม[^,·]*/g, '')) || cbItemCat(w.name) === 'อาวุธระยะไกล'; // v1.29: Reload ที่ถูกเอ่ยถึงแบบมีเงื่อนไข และชนิด อุปกรณ์เสริมปืน (ดาบปลายปืน) ไม่ทำให้เป็นอาวุธยิง
  const gba = /CV\s*สูงกว่า\s*(\d+)[^.·,]{0,60}Guard Break/.exec(eff); if (gba) w.gbAbove = Math.min(20, +gba[1]); // ค้อนสงคราม: Guard Break เมื่อโจมตีด้วย CV สูงกว่า 7 ระบบตรวจตอนฝ่ายรับเปิดหน้าต่างป้องกัน
  w.thrown = w.bomb || (/ชนิด:[^·]*อาวุธปา/.test(eff) && !!(w.props.throwable && w.props.throwable.on)); // อาวุธปาที่มี Throwable ตั้งต้นเป็นการขว้าง สลิงยังเป็นการยิง
  w.statKind = w.bomb ? 'none' : 'auto'; // v1.29 (Non เคาะ 16 พ.ย. 2026): ค่าพลังมาจากแบบการโจมตี ประชิดบวก Might ระยะไกลและขว้างบวก Sight (cbStatKind) ระเบิดความเสียหายคงที่
  const fn = /ต้อง Focus เพื่อโจมตี\s*\(มิฉะนั้น\s*-\s*(\d+)\s*CV\)/.exec(eff); if (fn) w.focusNeed = Math.min(9, +fn[1]);
  const aa = /ประกาศยิงโดยใช้\s*((?:Swift|Cast|Basic) Action(?:\s*(?:และ|หรือ)\s*(?:Swift|Cast|Basic) Action)*)\s*ด้วย Disadvantage/.exec(eff); if (aa) w.actAlt = [...aa[1].matchAll(/(Swift|Cast|Basic) Action/g)].map(x=>({k: x[1] === 'Swift' ? 's' : x[1] === 'Cast' ? 'c' : 'b', dis: true}));
  if (/ใช้\s*1\s*Swift Action\s*เพื่อโจมตี/.test(eff)) w.act = 's';
  const ab = /ระยะความแม่นยำ[^.·]{0,50}เพิ่มขึ้น\s*(\d+)\s*เมตร/.exec(eff); if (ab) w.accBonus = Math.min(100, +ab[1]);
  const tsg = /เมื่อ Throw\s*:\s*\+\s*(\d+)\s*Sight/.exec(eff); if (tsg) w.throwSight = Math.min(9, +tsg[1]);
  const bmul = /ทำความเสียหายกับสัตว์\s*[x×]\s*(\d)/.exec(eff); if (bmul) w.beastMul = Math.max(2, Math.min(4, +bmul[1]));
  if (/Impale เมื่อขว้างโดน/.test(eff)) w.impaleThrown = true;
  const tarm = /โจมตีโดนส่วนที่มีเกราะ\s*\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(eff); if (tarm){ w.toughArmored = Math.min(6, +tarm[1]); if (w.toughOpt === w.toughArmored) w.toughOpt = 0; }
  w.hits = cbHitRules(eff);
  w.strNeed = (typeof weaponStrNeed === 'function' ? weaponStrNeed(raw) : 0) || cbInt((/ต้องการ STR\s*(\d+)/.exec(raw) || [])[1]);
  w.conds = cbFindConds(eff).filter(x=>CB_HIT_CONDS.has(x.id));
  return w;
}
/* ของพัง (Durability 0): PDMG เหลือครึ่งปัดลง และคุณสมบัติพิเศษหาย (ไฟล์แกน บทเศรษฐศาสตร์ ข้อ 3 · คำเคาะ 15 พ.ย. 2026) */
function cbBrokenWeapon(w){
  w.broken = true; if (/^\d+$/.test(w.dmg)) w.dmg = String(Math.floor(+w.dmg / 2)); else w.halve = true;
  for (const k of Object.keys(w.props)) w.props[k] = {on: false, lost: true};
  w.sharpnel = 0; w.toughX = 0; w.toughOpt = 0; w.toughPerfect = 0; w.toughArmored = 0; w.conds = []; w.hits = []; return w;
}
function cbBaseName(name){ const m = /\(([^()]+)\)\s*$/.exec(String(name || '')); return (m ? m[1] : String(name || '')).trim().toLowerCase(); }
/* การโจมตีในสแตตบล็อกของ NPC (เอกสาร Fauna, Enemy & Companion) เช่น "CV Bonus +2, Damage 1d6 + Might Piercing (มีคุณสมบัติ Rip)"
 * อ่าน CV Bonus · Range Attack · สูตรความเสียหาย (ตัวเลข เต๋า หรือ N PDMG) · ค่าพลังที่บวก · ชนิด · คุณสมบัติอาวุธ
 * บรรทัดที่เขียน N PDMG โดยไม่บอกค่าพลัง ใช้กฎเดียวกับผู้เล่น: ประชิดบวก Might ระยะไกลและขว้างบวก Sight (v1.29)
 * บรรทัดที่ให้ทอย Saving Throw โดยไม่มี CV Bonus คือความสามารถที่ไม่ได้ทอยโจมตี (save:true) ใช้ทางแถบสกิล */
const CB_NPC_TYPES = '(?:Slashing|Slash|Piercing|Blunt|Physical|Fire|Plasma|Electric|Frost|Necrotic|Sonic|Acid|Corrode|Poison|Light)';
const CB_NPC_DMG_RX = new RegExp('(?:Damage\\s*)?(\\d{1,2}d\\d{1,3}(?:\\s*[+-]\\s*\\d{1,2})?|[Xx]d\\d{1,3}|\\d{1,3})\\s*(?:\\+\\s*(Might|Sight)\\s*)?(?:(PDMG)\\s*|Damage\\s*)?\\(?\\s*(' + CB_NPC_TYPES + '(?:\\s*/\\s*' + CB_NPC_TYPES + ')*)');
function cbParseNpcAttack(name, text){
  const raw = String(text || '').replace(/\\/g, '').slice(0, 600);
  const w = cbParseWeapon(name, raw); w.src = 'npc'; w.text = raw;
  const cvb = /CV\s*Bonus\s*\+?\s*(-?\d{1,2})/i.exec(raw); w.cvBonus = cvb ? Math.max(-9, Math.min(9, +cvb[1])) : 0;
  w.save = /Saving Throw/i.test(raw) && !cvb;
  const m = CB_NPC_DMG_RX.exec(raw.replace(/CV\s*Bonus\s*\+?\s*-?\d{1,2}\s*,?/i, ' '));
  if (m){
    w.found = true; w.dmg = m[1].replace(/\s+/g, ''); const ts = [...new Set(m[4].split('/').map(cbNormType).filter(t=>CB_DTYPES.includes(t)))]; w.dtypes = ts.length ? ts : ['Physical'];
    w.physical = cbIsPhysical(w.dtypes[0]);
    w.statKind = m[2] ? m[2].toLowerCase() : (m[3] ? 'auto' : 'none');
  } else { w.found = false; w.dmg = '0'; w.statKind = 'none'; }
  w.ranged = !!w.ranged || /Rang(?:e|ed)\s+(?:Sorcery\s+)?Attack/i.test(raw);
  w.bomb = /ระเบิด|Bomb\b/i.test(w.name); w.thrown = w.bomb || /ขว้าง|\bThrow/i.test(w.name);
  return w;
}
/* เกราะที่หักจริงของหนึ่งส่วน อ่านด้วยตัวอ่านเดียวกับชีท (armorHits) ตามคำเคาะ 15 พ.ย. 2026:
 * โดนชนิดที่อยู่ในวงเล็บหักเกราะหลักบวกเกราะรองของชนิดนั้น · ชนิดอื่นหักเกราะหลักอย่างเดียว · ความเสียหายเวทหักเกราะหลักบวก Sorceries Resistance ของส่วนนั้น
 * extra = เกราะที่มีทั้งตัว (All Armor ของ NPC) นับเป็นเกราะหลัก · ข้อความที่จดเองนอกรูปแบบคืน known:false (ไม่เดา)
 * ค่าอัตโนมัติรุ่นก่อน v1.25 เขียน A/B ไม่มีวงเล็บ หมายถึงเกราะรองกัน Blunt (ชีทจะแปลงเป็น A/B (Blunt) เมื่อเจ้าของเปิดอีกครั้ง) จึงอ่านแบบเดียวกัน */
function cbArmorCut(text, dtype, physical, extra){
  const add = Math.max(0, cbInt(extra)); const s = String(text || '').trim();
  let r = s ? ((typeof armorHits === 'function') ? armorHits(s) : null) : {main: 0, sec: {}};
  if (!r){ const old = /^(\d+)\s*\/\s*(\d+)$/.exec(s); if (old) r = {main: +old[1], sec: {Blunt: +old[2]}}; }
  if (!r) return {known: false, main: add, sec: 0, v: add, any: add > 0, key: ''};
  const key = physical ? cbNormType(dtype) : 'Sorceries Resistance'; const sec = r.sec[key] || 0; const main = r.main + add;
  return {known: true, main, sec, v: main + sec, any: main > 0 || Object.values(r.sec).some(v=>v > 0), key};
}
/* ระยะกับแบบการโจมตี: ประชิดต้องอยู่เขตปะทะ (Reach เอื้อมได้อีกหนึ่งช่อง) · ขว้างได้ถึงเขตใกล้เคียง (thrownFar = ความสามารถที่ขยายถึงเขตไกล) · ยิงเกินระยะแม่นหัก 1 CV ต่อทุก 2 เมตรที่เกิน (rangePenalty ของ map.js) */
function cbRangeVerdict(o){
  const cells = Math.max(0, o.cells | 0); const m = cells * CELL_M; const band = rangeBand(cells);
  if (o.mode === 'melee'){ const max = o.reach ? 2 : 1; const ok = cells <= max;
    return {ok, cv: 0, m, band, cls: ok ? 'ok' : 'bad', text: ok ? (cells > 1 ? `เป้าห่าง ${m} ม. เอื้อมถึงด้วย Reach` : `เป้าอยู่ในเขตปะทะ (${m} ม.) โจมตีประชิดได้`) : `ไกลเกิน: เป้าห่าง ${m} ม. (${band.label}) ต้องเข้าเขตปะทะก่อน`}; }
  if (o.mode === 'thrown'){ const ok = band.id !== 'far' || !!o.thrownFar;
    return {ok, cv: 0, m, band, cls: ok ? 'ok' : 'bad', text: ok ? (band.id === 'far' ? `เป้าห่าง ${m} ม. (${band.label}) ขว้างถึงด้วยความสามารถที่ขยายระยะขว้าง` : `เป้าห่าง ${m} ม. (${band.label}) ขว้างถึง`) : `ไกลเกิน: อาวุธขว้างไปได้ถึงเขตใกล้เคียง (${NEAR_MAX_M} ม.) เป้าห่าง ${m} ม.`}; }
  const acc = o.acc || rangeAccM(0); const over = Math.max(0, m - acc); const cv = -rangePenalty(m, acc);
  return {ok: true, cv, m, band, acc, cls: cv ? 'warn' : 'ok', text: cv ? `เป้าห่าง ${m} ม. เกินระยะแม่น ${acc} ม. ไป ${over} ม. โดนลด CV ${cv} (ลด 1 ต่อทุก 2 ม. ที่เกิน)` : `เป้าห่าง ${m} ม. อยู่ในระยะแม่น ${acc} ม. ไม่โดนลด CV`};
}

/* ---------- 2. ตัวช่วยสร้างช่องกรอก ---------- */
function cbSelect(opts, val, on, attrs){ const el = h('select', attrs || null, opts.map(([v, l, dis])=>{ const o = h('option',{value:String(v), text:l}); if (dis) o.disabled = true; return o; })); el.value = String(val == null ? '' : val); el.onchange = ()=>on(el.value); return el; }
function cbNum(val, on, attrs, live){ const el = h('input', Object.assign({type:'number'}, attrs || {})); el.value = (val == null || val === '') ? '' : String(val); const fire = ()=>on(el.value === '' ? null : +el.value); if (live) el.oninput = fire; else el.onchange = fire; return el; }
function cbCheck(label, checked, on, attrs){ const box = h('input',{type:'checkbox'}); box.checked = !!checked; box.onchange = ()=>on(box.checked); return h('label', Object.assign({class:'fld chk'}, attrs || {}), box, h('span',{text:label})); }
/* ลูกของ Element.append: แตกอาร์เรย์และข้ามค่าว่าง (append ของเบราว์เซอร์พิมพ์ null กับอาร์เรย์ออกมาเป็นข้อความ) */
function cbKids(...a){ return a.flat(4).filter(x=>x != null && x !== false && x !== ''); }
function cbRollOf(r){ return {dice: (r.dice || []).slice(), kept: (r.kept || []).slice(), keptIdx: (r.keptIdx || []).slice(), sum: r.sum, double: !!r.double}; }

/* ---------- 2ข. ตัวช่วยของกติกา v1.29 ---------- */
/* ธงบนหมากที่ความสามารถตั้งหรือล้างได้ (ชื่ออื่นไม่ยอมให้ข้อความจากทะเบียนแตะหมาก) */
const CB_FLAGS = ['rof', 'iflame', 'missed', 'bmps', 'boto', 'tactic', 'fabs', 'rhythm'];
/* ค่าพลังที่บวกความเสียหาย (Non เคาะ 16 พ.ย. 2026): การโจมตีระยะประชิดบวก Might อาวุธระยะไกลและการขว้างบวก Sight
 * อาวุธที่ความเสียหายคงที่ (ระเบิด) และบรรทัดการโจมตีของ NPC ที่เขียนสูตรไว้ชัด ใช้ตามที่เขียน */
function cbStatKind(w, mode){ const k = (w && w.statKind) || 'auto'; return k === 'auto' ? (mode === 'melee' ? 'might' : 'sight') : k; }
/* รวมผลของตัวเลือกความสามารถที่เปิดอยู่ (ทะเบียนใน feats.js) เป็นก้อนเดียว ใช้ทั้งฝั่งโจมตีและฝั่งป้องกัน */
function cbMergeEff(opts){
  const E = {adv: false, dis: false, perfect: false, cv: 0, dice: 0, might: 0, sight: 0, dmg: 0, dmgDice: [], hpDice: [], mul: 2, perfectOn: [], ignoreArmor: 0, tough: 0, toughDice: [], hitCond: [], perfectCond: [], saveCond: [], sumCond: [], noDmgCond: null,
    free: false, freeFocus: false, focusAnytime: false, impact: false, impactOnPerfect: false, rip: false, ap: false, noStr: false, noDelay: false, pickPart: false, perfectDmg: 0, throwable: false, thrownFar: false, noCover: false, notes: [], clear: [], set: [], act: null,
    evadeMeleeOk: false, reflex: 0, pd: 0, armor: 0, reduce: 0, min1: false, tempHp: 0, evadeBy5: false, okTemp: 0, parryDmg: ''};
  for (const p of opts || []){ const e = (p && p.eff) || {};
    for (const k of ['adv', 'dis', 'perfect', 'free', 'freeFocus', 'focusAnytime', 'impact', 'impactOnPerfect', 'rip', 'ap', 'noStr', 'noDelay', 'pickPart', 'throwable', 'thrownFar', 'noCover', 'evadeMeleeOk', 'min1', 'evadeBy5']) if (e[k]) E[k] = true;
    for (const k of ['cv', 'dice', 'might', 'sight', 'dmg', 'ignoreArmor', 'tough', 'perfectDmg', 'reflex', 'pd', 'armor', 'reduce', 'tempHp', 'okTemp']) if (e[k]) E[k] += cbInt(e[k]);
    if (e.parryDmg && cbExprOk(e.parryDmg) && !E.parryDmg) E.parryDmg = String(e.parryDmg);
    if (e.mul) E.mul = Math.max(E.mul, Math.min(4, cbInt(e.mul, 2))); if (['s', 'b', 'c'].includes(e.act)) E.act = e.act;
    for (const k of ['dmgDice', 'hpDice', 'toughDice']) if (e[k] && cbExprOk(e[k])) E[k].push(String(e[k]));
    if (Array.isArray(e.perfectOn)) E.perfectOn.push(...e.perfectOn.map(n=>cbInt(n)).filter(n=>n >= 2 && n <= 12));
    for (const k of ['hitCond', 'perfectCond']) if (Array.isArray(e[k])) E[k].push(...e[k].filter(x=>x && x.id));
    if (e.saveCond && e.saveCond.id) E.saveCond.push(e.saveCond); if (e.sumCond && e.sumCond.id) E.sumCond.push(e.sumCond); if (e.noDmgCond && e.noDmgCond.id) E.noDmgCond = e.noDmgCond;
    if (e.note) E.notes.push(String(e.note).slice(0, 200)); if (e.clear) E.clear.push(String(e.clear)); if (e.set) E.set.push({k: String(e.set), v: e.setVal != null ? e.setVal : 1});
  }
  return E;
}
/* อ่านกติกา On-Hit ของอาวุธที่เขียนเป็นแบบแผน เช่น "Attack On-Hit จะติด Unbalanced" · "หากโจมตีโดนเป้าหมายจะติดสถานะ Unbalanced" · "Perfect Strike On-Hit ที่หัว เป้าหมายติด Deepwound"
 * "On-Hit เป้าหมายจะต้องทอย VIT Check (DC 10) หาก Failed จะติด Unbalanced" · "หากโจมตีด้วย CV ต่ำกว่า 6 On-Hit จะติด Unbalanced"
 * คืนรายการ {id, lv, perfect, focus, mode, part, exceptPart, unarmored, cvBelow, lvHp, turns, save, ask}
 * ask = มีเงื่อนไขที่ระบบตรวจเองไม่ได้ (ครั้งแรกของรอบ เป้าที่ถือโล่ การ Grab ฯลฯ) จึงขึ้นเป็นปุ่มให้ฝ่ายรับหรือ GM กดเมื่อเข้าเงื่อนไข ระบบไม่ใส่ให้เอง */
const CB_ONHIT_RX = /(Perfect (?:Strike|Attack)\s+)?((?:Focus\s+|Grab\s+|Melee\s+)?(?:Attack\s+)?)(On-?[Hh]it|โจมตีโดน)/g;
const CB_ALTHEAD_RX = /หากโดนหัว(?:จะ)?ติด\s*["“”']?([A-Za-z]+)["“”']?\s*(แทน|ด้วย)?/;
function cbCondId(word){ const w = String(word || '').trim(); if (!w) return null; const id = Object.prototype.hasOwnProperty.call(CB_COND_ALIAS, w) ? CB_COND_ALIAS[w] : w; return (cbCondNames().includes(id) && CB_HIT_CONDS.has(id)) ? id : null; }
function cbHitRules(eff){
  const s = String(eff || '').replace(/\\/g, ''); const out = []; let m; CB_ONHIT_RX.lastIndex = 0;
  while ((m = CB_ONHIT_RX.exec(s)) && out.length < 6){
    const start = m.index, end = start + m[0].length; const from = Math.max(s.lastIndexOf('.', start - 1), s.lastIndexOf('·', start - 1), s.lastIndexOf(',', start - 1)) + 1; const pre = s.slice(from, start);
    const tail = s.slice(end, end + 220); const stop = tail.search(/[.·]/); const sent = stop < 0 ? tail : tail.slice(0, stop); const alt = CB_ALTHEAD_RX.exec(sent);
    const main = alt ? sent.slice(0, alt.index) : sent; const c1 = main.indexOf(','); let p = c1 < 0 ? main : main.slice(0, c1); let q;
    const r = {perfect: !!m[1] || /Perfect (?:Strike|Attack)\s*$/.test(pre), ask: false};
    if (/Focus/.test(m[2]) || /Focus[^,.·]{0,24}$/.test(pre)) r.focus = true;
    if (/Grab/.test(m[2]) || /Grab[^,.·]{0,12}$/.test(pre)) r.ask = true;
    if (/ระยะไกล|Ranged?\s*Attack\)?\s*$/.test(pre)) r.mode = 'ranged'; else if (/ระยะประชิด\s*$/.test(pre)) r.mode = 'melee';
    const cvb = /CV ต่ำกว่า\s*(\d+)/.exec(pre); if (cvb) r.cvBelow = +cvb[1];
    const preRest = pre.replace(/Perfect (?:Strike|Attack)|Focus(?:\s*แล้วโจมตี)?|หากโจมตีด้วย CV ต่ำกว่า\s*\d+|ทุกครั้งที่|การโจมตี(?:ระยะไกล|ระยะประชิด)?|\(Ranged Attack\)|Impact|หาก|เมื่อ|มัน|อาวุธนี้|[\s:]/g, '');
    if (preRest.length || /^\s*ครั้งแรก/.test(p)) r.ask = true;
    if ((q = /^\s*(?:ที่|ใน)?\s*(หัว|ลำตัว)/.exec(p))){ r.part = q[1] === 'หัว' ? 'head' : 'torso'; p = p.slice(q[0].length); }
    if ((q = /^\s*(?:ใน)?(?:จุด|ส่วน)ที่ไม่มี\s*(?:เกราะ|Armor)/.exec(p))){ r.unarmored = true; p = p.slice(q[0].length); }
    const sv = /^\s*(?:เป้าหมาย)?(?:จะ)?ต้องทอย\s*([A-Z]{3})\s*(?:Check|Saving Throw)\s*\(DC\s*(\d+)\)\s*หาก\s*(?:Failed|พลาด|ล้มเหลว)\s*จะติด(?:สถานะ)?\s*["“”']?([A-Za-z]+)/.exec(p);
    if (sv){ const id = cbCondId(sv[3]); if (id) out.push(Object.assign(r, {id, save: {stat: sv[1], dc: Math.min(40, +sv[2])}})); continue; }
    let cm = /^[\s:]*(?:เป้าหมาย)?\s*(?:จะ)?\s*(?:ทำให้เป้าหมาย)?\s*ติด(?:สถานะ)?\s*(?:(\d+)\s*)?["“”']?([A-Z][a-z]+)["“”']?(?:\s*(\d+)\s*หน่วย)?/.exec(p);
    if (!cm){ cm = /ติด(?:สถานะ)?\s*(?:(\d+)\s*)?["“”']?([A-Z][a-z]+)["“”']?(?:\s*(\d+)\s*หน่วย)?/.exec(p); if (cm) r.ask = true; }
    const id = cm ? cbCondId(cm[2]) : null;
    if (id){ r.id = id; const lv = cbInt(cm[1] || cm[3]); if (lv && typeof COND_STACK !== 'undefined' && COND_STACK.has(id)) r.lv = Math.min(20, lv);
      if (/ตาม Damage ที่เข้า HP/.test(p)) r.lvHp = true; if (/จนจบรอบ|เป็นเวลา\s*1\s*รอบ/.test(sent)) r.turns = 1; out.push(r); }
    if (alt){ const id2 = cbCondId(alt[1]); if (id2){ out.push({id: id2, perfect: r.perfect, focus: !!r.focus, part: 'head', ask: r.ask}); if (alt[2] === 'แทน' && id) r.exceptPart = 'head'; } }
  }
  return out;
}
/* Reaction ของฝ่ายรับที่ระบบทำผลให้เอง (Non สั่ง 16 พ.ย. 2026 "ระบำเหินหาวตอนเอามากด Reaction มันมั่วสุดๆ ... สกิลอื่นๆที่ใช้ Reaction ผมก็คิดว่าน่าจะมั่วเหมือนกัน")
 * fit(x) = ใช้กับการโจมตีนี้ได้ไหม · text(x) = คำอธิบายสั้น · apply(x, rx, r) = ใส่ผลให้การป้องกันครั้งนี้ คืนข้อความสรุป · run = ขั้นตอนที่ระบบทอยให้ทั้งสองฝ่าย · arm = เตรียมไว้ใช้เมื่อพลาด
 * x = {t ฝ่ายรับ, a ผู้โจมตี, f ข้อมูลการโจมตี, mode, dtype, physical, adjacent, mod(ชื่อค่า)} */
const CB_REACT = {
  'Waltzing Vault': {run: 'vault', text: (x)=>`ทอย AGI ${signed(x.mod('AGI'))} ปะทะ Sight ของ ${x.f.a.name} (ระบบทอยให้ทั้งสองฝ่าย) ชนะหรือเท่ากันนับว่า Evade ผ่าน แล้วเคลื่อนที่ข้ามหัวได้ 3 เมตร ใช้แทนการ Parry หรือ Evade`},
  'Umbral Bindings': {run: 'umbral', fit: (x)=>x.mode === 'melee' && x.adjacent, text: (x)=>`${x.f.a.name} ทอย AGI Saving Throw (DC ${8 + x.mod('Cautious')}) ไม่ผ่าน = การโจมตีพลาดเป้าและติด Rooted จนถึงเทิร์นถัดไปของคุณ ผ่าน = เลือกวิธีป้องกันต่อ`},
  'Wind Shield': {text: (x)=>`Reflex +${Math.max(0, x.mod('AGI'))} (AGI Mod) สำหรับ Evade การโจมตีครั้งนี้`, apply: (x, rx)=>{ const n = Math.max(0, x.mod('AGI')); rx.reflex += n; return `Reflex +${n} สำหรับ Evade ครั้งนี้`; }},
  'Steel Veil': {fit: (x)=>!(x.f.w && x.f.w.skill), text: (x)=>`เกราะทุกส่วน +${Math.max(0, x.mod('VIT'))} (VIT Mod) สำหรับการโจมตีด้วยอาวุธครั้งนี้`, apply: (x, rx)=>{ const n = Math.max(0, x.mod('VIT')); rx.armor += n; return `เกราะทุกส่วน +${n} สำหรับการโจมตีครั้งนี้`; }},
  'Crimson Shield': {text: (x)=>`Temporary HP 1d3 ${signed(x.mod('VIT'))} (VIT Mod) ใช้ลดความเสียหายของการโจมตีครั้งนี้`, apply: (x, rx)=>{ const rr = cbRollExpr('1d3'); const n = Math.max(0, rr.total + x.mod('VIT')); rx.tempHp += n; return `Temporary HP ${n} (1d3 ได้ ${rr.total} ${signed(x.mod('VIT'))}) สำหรับการโจมตีครั้งนี้`; }},
  'Iron Body - Iwatong': {fit: (x)=>x.physical, text: (x)=>`Temporary HP 1d3 ${signed(x.mod('Confront'))} (Confront Mod ขั้นต่ำ 1) ใช้ลดความเสียหายกายภาพครั้งนี้`, apply: (x, rx)=>{ const rr = cbRollExpr('1d3'); const n = Math.max(1, rr.total + x.mod('Confront')); rx.tempHp += n; return `Temporary HP ${n} (1d3 ได้ ${rr.total} ${signed(x.mod('Confront'))}) สำหรับการโจมตีครั้งนี้`; }},
  'Embrace the Void': {text: ()=>'ไม่ได้รับความเสียหายทุกประเภทจากการโจมตีครั้งนี้ จากนั้นเสีย Sanity 1d6', apply: (x, rx)=>{ rx.immune = 'โอบกอดความว่างเปล่า'; rx.sanity = '1d6'; return 'ไม่ได้รับความเสียหายจากการโจมตีครั้งนี้ แล้วเสีย Sanity 1d6'; }},
  'Fire Absorption': {fit: (x)=>x.dtype === 'Fire', text: ()=>'ไม่ได้รับ Fire Damage ครั้งนี้ และการโจมตีหรือเวทไฟครั้งถัดไปเพิ่มครึ่งหนึ่งของที่ดูดกลืน', apply: (x, rx)=>{ rx.immune = 'ดูดกลืนอัคคี'; rx.absorb = true; return 'ไม่ได้รับ Fire Damage ครั้งนี้ และเก็บพลังไว้'; }},
  'Absolute Blaze': {text: ()=>'All Damage Reduction +2 กับทุกความเสียหายที่เล็งมาในรอบการเล่นนี้ (Absorb Stack นับเอง)', apply: (x, rx, r)=>{ if (r && r.enc && r.enc.active) x.t.ablaze = r.enc.round; else rx.reduce += 2; return 'All Damage Reduction +2 ในรอบนี้'; }},
  'Flexible Resilience': {arm: 'flex', text: ()=>'เตรียมไว้: ถ้า Evade พลาด ระบบทอย AGI Saving Throw (DC เท่าความเสียหายที่จะได้รับ) ผ่านแล้วรับครึ่งเดียว (ปัดลง)'},
};
/* Reaction ที่ใช้หลังรู้ผลการป้องกัน: ขึ้นเป็นปุ่มในการ์ดผล เป้าหมายตั้งให้เอง (ผู้โจมตี หมากในเขตปะทะ หรือตัวเอง) */
const CB_REACT_POST = {
  'Flash': {to: 'attacker', fit: (m)=>!m.hit && !!m.def && (m.def.kind === 'evade' || m.def.asEvade) && m.mode === 'melee'},
  'Frost Shock': {to: 'zone', fit: (m)=>!m.hit && !!m.def && (m.def.kind === 'evade' || m.def.kind === 'parry' || m.def.asEvade)},
  'Tactical Roll': {to: 'self', fit: (m)=>!m.hit && !!m.def && (m.def.kind === 'evade' || m.def.asEvade) && m.mode !== 'melee'},
};
/* ลากกล่องหน้าต่างกลางจอ (หน้าต่างป้องกัน) ด้วยหัวข้อ: เลื่อนด้วย transform จึงไม่กระทบการจัดกึ่งกลางเดิม ตำแหน่งจำไว้ที่ owner.defPos ตลอดการเปิดห้อง */
function cbDragBox(box, sel, owner){
  if (!box) return; const pos = Object.assign({x: 0, y: 0}, owner.defPos || {}); let id = null, sx = 0, sy = 0, ox = 0, oy = 0, z = 1;
  const apply = ()=>{ box.style.transform = (pos.x || pos.y) ? `translate(${pos.x}px, ${pos.y}px)` : ''; };
  const clamp = ()=>{ const rc = box.getBoundingClientRect(); const W = window.innerWidth, H = window.innerHeight; if (rc.top < 4) pos.y += Math.round((4 - rc.top) / z); else if (rc.top > H - 60) pos.y -= Math.round((rc.top - (H - 60)) / z); if (rc.right < 90) pos.x += Math.round((90 - rc.right) / z); else if (rc.left > W - 90) pos.x -= Math.round((rc.left - (W - 90)) / z); apply(); };
  apply(); z = uiZoom(); clamp();
  box.addEventListener('pointerdown', (e)=>{ if (e.button !== 0 || !e.target.closest || !e.target.closest(sel)) return; id = e.pointerId; try { box.setPointerCapture(id); } catch(x){} z = uiZoom(); sx = e.clientX; sy = e.clientY; ox = pos.x; oy = pos.y; box.classList.add('dragging'); e.preventDefault(); });
  box.addEventListener('pointermove', (e)=>{ if (id == null || e.pointerId !== id) return; pos.x = Math.round(ox + (e.clientX - sx) / z); pos.y = Math.round(oy + (e.clientY - sy) / z); apply(); });
  const up = ()=>{ if (id == null) return; try { box.releasePointerCapture(id); } catch(x){} id = null; box.classList.remove('dragging'); clamp(); owner.defPos = {x: pos.x, y: pos.y}; };
  box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
}

/* ---------- v1.29 ข้อความเต็มของไอเทมจากคลัง ----------
 * ของในชุดเริ่มต้นจดเอฟเฟกต์แบบย่อ (เช่น "ต้อง Focus ก่อนยิง ไม่ Focus ติด -3 CV" หรือ "ดาเมจ ×2 กับสัตว์") ส่วนตัวอ่านกติกาเขียนตามข้อความเต็มใน Item All
 * เมื่อชื่อไอเทมตรงกับคลัง และข้อความที่จดเป็นข้อความย่อของชุดเริ่มต้น ระบบอ่านกติกาจากข้อความเต็มของไอเทมเดียวกันในคลัง ตัวละครจากชุดเริ่มต้นจึงได้กติกาครบเท่าของที่ซื้อจากคลัง
 * ข้อความที่ผู้เล่นหรือ GM แก้เองบนชีท (ไม่ตรงทั้งคลังและชุดเริ่มต้น) ยังอ่านตามที่จดไว้ */
function cbNameKeys(name){ const s = String(name || '').replace(/ต้องการ STR\s*\d+/g, '').replace(/^(?:หรือ|และ)\s+/, '').replace(/\s*[×x]\s*\d+\s*$/, '').trim(); const m = /\(([^()]+)\)/.exec(s); const en = (m ? m[1] : '').trim().toLowerCase(); const th = (m ? s.slice(0, m.index) : s).trim().toLowerCase(); return {en, th, parts: en ? en.split('/').map(x=>x.trim()).filter(Boolean) : []}; }
function cbEffNorm(e){ return String(e || '').replace(/\\/g, '').replace(/\s*·\s*ต้องการ STR\s*\d+\s*$/, '').replace(/\(ต้องการ STR\s*\d+\)\s*/, '').replace(/\s+/g, ' ').trim(); }
function cbCatalog(){
  if (cbCatalog.m) return cbCatalog.m; const full = new Map(), alias = new Map(), short = new Map(); const items = (typeof DATA !== 'undefined' && Array.isArray(DATA.items)) ? DATA.items : [];
  for (const it of items){ const k = cbNameKeys(it.name); if (k.en && !full.has(k.en)) full.set(k.en, it); }
  for (const it of items){ const k = cbNameKeys(it.name); for (const p of k.parts) if (!full.has(p) && !alias.has(p)) alias.set(p, it); if (k.th && !alias.has('th:' + k.th)) alias.set('th:' + k.th, it); }
  const sets = (typeof DATA !== 'undefined' && DATA.sets && Array.isArray(DATA.sets.sets)) ? DATA.sets.sets : [];
  for (const st of sets) for (const it of st.items || []){ const k = cbNameKeys(it.name); const keys = [k.en, ...k.parts, k.th ? 'th:' + k.th : ''].filter(Boolean); for (const key of keys){ if (!short.has(key)) short.set(key, new Set()); short.get(key).add(cbEffNorm(it.effect)); } }
  return (cbCatalog.m = {full, alias, short});
}
function cbCatalogItem(name){ const k = cbNameKeys(name); const C = cbCatalog(); return (k.en && (C.full.get(k.en) || C.alias.get(k.en))) || k.parts.map(p=>C.full.get(p) || C.alias.get(p)).find(Boolean) || (k.th && C.alias.get('th:' + k.th)) || null; }
function cbParseWeapon(name, effect){
  const cat = cbCatalogItem(name);
  if (cat){ const own = cbEffNorm(effect); if (own && own !== cbEffNorm(cat.effect)){ const k = cbNameKeys(name); const C = cbCatalog(); const known = [k.en, ...k.parts, k.th ? 'th:' + k.th : ''].filter(Boolean).some(key=>C.short.has(key) && C.short.get(key).has(own));
      if (known){ const w = cbParseWeaponText(name, cat.effect); if (w.found){ if (!w.strNeed) w.strNeed = cbInt((/ต้องการ STR\s*(\d+)/.exec(String(effect || '')) || [])[1]); w.fromCat = true; return w; } } } }
  return cbParseWeaponText(name, effect);
}

/* ---------- 3. Combat: สถานะและกติกา ---------- */
const Combat = {
  comp: null, ready: false, seen: new Set(), snooze: new Set(), timers: {}, prompting: null, done: new Set(), inited: new Set(),
  reset(){ this.closeComposer(); this.ready = false; this.seen = new Set(); this.snooze = new Set(); this.prompting = null; this.done = new Set(); for (const k of Object.keys(this.timers)) clearTimeout(this.timers[k]); this.timers = {}; if (typeof SkillUse !== 'undefined') SkillUse.reset(); },
  tok(id){ const r = Table.room; return r ? ((r.tokens || []).find(t=>t.id === id) || null) : null; },
  controls(t){ return !!t && (Table.localMode || Table.isGM() || ownsTok(t)); },
  charOf(t){ const c = t && t.charId ? Store.get(t.charId) : null;
    // ชีทของฉันที่ยังไม่เคยเปิด (หมากที่วางไว้ตั้งแต่รุ่นก่อน): เตรียมค่าปัจจุบัน กระเป๋า และของสวมใส่ก่อนเหมือนตอนเปิดชีท แล้วส่งสำเนาเข้าห้อง
    if (c && c.done && Store.isMine(c) && Store.chars.includes(c) && (!c.current || !c.equip || !c.inventory) && !this.inited.has(c.id)){ this.inited.add(c.id); try { ensureSheetState(c, compute(c)); Store.upsert(c); } catch(e){ console.warn('sheet init', e); } }
    return c; },
  derived(c){ try { return c ? compute(c) : null; } catch(e){ return null; } },
  levels(c){ try { return c ? knowledgeLevels(c) : {}; } catch(e){ return {}; } },
  has(t, id){ return !!t && (t.conds || []).some(c=>c.id === id); },
  side(t){ return t && t.kind === 'pc' ? 'pc' : 'npc'; },
  alive(t){ return !!t && t.kind !== 'asset' && !t.inside && (t.hp == null || t.hp > 0); },
  visible(r){ const gm = Table.isGM(); const vis = gm ? null : computeVisibility(r, Store.me); return (r.tokens || []).filter(t=>(gm || !t.hidden || ownsTok(t)) && (!vis || ownsTok(t) || vis.has(t.x + ',' + t.y)) && !t.inside); },
  myTokens(r){ return (r.tokens || []).filter(t=>t.kind !== 'asset' && !t.inside && this.controls(t)); },
  /* ค่าของผู้โจมตีและฝ่ายรับ: ตัวละครที่มีชีทอ่านจากชีท · NPC คิดจากค่าพลังดัดแปลงบนหมากด้วยสูตรเดียวกับผู้เล่น (Non เคาะ 16 พ.ย. 2026 ไม่มีช่องแก้เอง) */
  isNpc(t){ return !!t && !t.charId && t.kind === 'npc'; },
  npcDer(t){ return (this.isNpc(t) && typeof npcDerived === 'function') ? npcDerived(t.mods) : null; },
  atkStats(t){ const c = this.charOf(t); const d = this.derived(c); const nd = d ? null : this.npcDer(t);
    return {might: d ? d.might : (nd ? nd.might : 0), sight: d ? d.sight : (nd ? nd.sight : 0), rangeLv: (typeof tokenRangeLv === 'function') ? tokenRangeLv(t) : 0, sheet: !!d, npc: !!nd}; },
  defStats(t){ const c = this.charOf(t); const d = this.derived(c); const nd = d ? null : this.npcDer(t); const lv = this.levels(c);
    return {reflex: d ? d.reflex : (nd ? nd.reflex : 0), pd: Math.max(0, d ? cbInt(d.parryDice) : ((nd && typeof npcParryDice === 'function') ? npcParryDice(t.equip) : 0)), meleeLv: d ? (lv.melee || 0) : 0, sheet: !!d, npc: !!nd}; },
  weaponsOf(t){
    const out = []; const c = this.charOf(t); const d = this.derived(c);
    if (c && c.equip && !(c.shareMode === 'min' && !Store.isMine(c))){
      const slots = [...new Set([...(typeof WEAPON_SLOTS !== 'undefined' ? WEAPON_SLOTS : ['weapon1','weapon2','shield']), ...Object.keys(c.equip)])];
      for (const k of slots){ const e = c.equip[k]; if (!e || !(e.name || '').trim()) continue; const w = cbParseWeapon(e.name, e.effect); if (!w.found) continue; w.src = k; w.strShort = !!(w.strNeed && d && d.raw && (d.raw.STR || 0) < w.strNeed);
        if (typeof durBroken === 'function' && durBroken(e)) cbBrokenWeapon(w); out.push(w); }
      try { if (typeof hasFleshforge === 'function' && hasFleshforge(c) && c.fleshforge && c.fleshforge.item){ const w = cbParseWeapon(c.fleshforge.item, c.fleshforge.effect); if (w.found){ w.src = 'fleshforge'; out.push(w); } } } catch(e){}
      try { if (typeof Feats !== 'undefined') for (const fw of Feats.weapons(c)){ const w = cbParseWeapon(fw.name, fw.effect); if (w.found){ w.src = 'natural'; if (fw.ignoreArmor) w.ignoreArmor = fw.ignoreArmor; out.push(w); } } } catch(e){} // v1.29: อาวุธตามธรรมชาติจาก Trait และทักษะติดตัว
    }
    if (this.isNpc(t)){ // การโจมตีในสแตตบล็อกก่อน แล้วตามด้วยอาวุธที่สวมซึ่งยังไม่มีบรรทัดโจมตีชื่อเดียวกัน
      const seen = new Set();
      for (const a of (Array.isArray(t.attacks) ? t.attacks : []).slice(0, 12)){ if (!a || typeof a !== 'object') continue; const w = cbParseNpcAttack(String(a.name || 'การโจมตี').slice(0, 80), a.text); if (w.save) continue; seen.add(cbBaseName(w.name)); out.push(w); }
      for (const e of (Array.isArray(t.equip) ? t.equip : []).slice(0, 16)){ if (!e || (e.slot !== 'weapon' && e.slot !== 'shield') || !(e.name || '').trim()) continue; const w = cbParseWeapon(e.name, e.effect); if (!w.found || seen.has(cbBaseName(w.name))) continue; w.src = 'npceq'; seen.add(cbBaseName(w.name)); out.push(w); }
    }
    out.push(Object.assign(cbParseWeapon('มือเปล่า (Unarmed)', '0 PDMG (Blunt)'), {src:'unarmed'}));
    out.push(Object.assign(cbParseWeapon('กำหนดเอง', ''), {src:'custom', found: true, dmg: '1', dtypes: CB_DTYPES.slice()}));
    return out;
  },
  /* ศัตรู (คนละฝั่ง pc กับ npc) ที่ยืนติดหมากนี้ */
  foesNear(r, t){ return (r.tokens || []).filter(o=>o !== t && this.alive(o) && !o.hidden && this.side(o) !== this.side(t) && cellDist(o, t) <= 1); },
  alliesNear(r, t){ return (r.tokens || []).filter(o=>o !== t && this.alive(o) && !o.hidden && this.side(o) === this.side(t) && cellDist(o, t) <= 1); },
  /* เหตุที่ทำให้ได้ Advantage ติด Disadvantage นับเป็น Perfect Strike หรือได้บวก CV: อ่านจากสภาวะบนหมากและตำแหน่งบนแผนที่ ผู้โจมตีติ๊กออกได้ทุกข้อ */
  atkReasons(r, a, t, w, mode){
    const out = []; const add = (key, kind, label)=>out.push({key, kind, label}); const melee = mode === 'melee';
    if (t){
      if (this.has(t, 'Stunned') && melee) add('stun', 'adv', 'เป้าติด Stunned: โจมตีประชิดได้ Advantage');
      if (this.has(t, 'Prone')) add('prone', melee ? 'adv' : 'dis', melee ? 'เป้าติด Prone: โจมตีประชิดได้ Advantage' : 'เป้าติด Prone: โจมตีระยะไกลติด Disadvantage');
      if (this.has(t, 'Blinded')) add('tblind', 'adv', 'เป้าติด Blinded: การโจมตีใส่เป้าได้ Advantage');
      if (this.has(t, 'Invisible')) add('tinvis', 'dis', 'เป้า Invisible: การโจมตีใส่เป้าติด Disadvantage');
      if (this.has(t, 'Cover') && !melee) add('cover', 'dis', 'เป้ามี Cover: โจมตีระยะไกลติด Disadvantage');
      if (this.has(t, 'Incapacitated')) add('incap', 'perfect', 'เป้า Incapacitated: นับเป็น Perfect Strike');
      if (this.has(t, 'Marked')) add('marked', 'cv', 'เป้าติด Marked: CV บวกตาม Sight ของผู้โจมตี');
      if (melee && cellDist(a, t) <= 1 && this.side(a) !== this.side(t)){ const foes = this.foesNear(r, t).length; if (foes >= 2 && !this.alliesNear(r, t).length) add('gang', 'adv', `รุม: ศัตรู ${foes} ตัวอยู่ในเขตปะทะของเป้า และเป้าไม่มีพันธมิตรติดตัว`); }
      if (typeof Act !== 'undefined' && Act.holder(t) && Act.holder(t).ow) add('tow', 'dis', 'เป้าตั้ง Overwatch อยู่: การโจมตีที่เล็งมายังเป้าติด Disadvantage');
      if (t.tactic === 'off') add('tacoff', 'adv', 'เป้าใช้ท่ารุกของยุทธวิธีนอกตำรา: การโจมตีใส่เป้าได้ Advantage'); else if (t.tactic === 'def') add('tacdef', 'dis', 'เป้าใช้ท่ารับของยุทธวิธีนอกตำรา: การโจมตีใส่เป้าติด Disadvantage');
    }
    if (this.has(a, 'Prone')) add('aprone', 'dis', 'ผู้โจมตีติด Prone: Attack ติด Disadvantage');
    if (this.has(a, 'Poisoned')) add('apois', 'dis', 'ผู้โจมตีติด Poisoned: Attack ติด Disadvantage');
    if (this.has(a, 'Frightened')) add('afear', 'dis', 'ผู้โจมตีติด Frightened: Attack ติด Disadvantage');
    if (this.has(a, 'Blinded')) add('ablind', 'dis', 'ผู้โจมตีติด Blinded: Attack ติด Disadvantage');
    const gr = (a.conds || []).find(c=>c.id === 'Grappled'); if (gr && t && gr.by && gr.by !== t.id) add('agrap', 'dis', 'ผู้โจมตีถูกจับอยู่: โจมตีเป้าอื่นติด Disadvantage');
    if (this.has(a, 'Invisible')) add('ainvis', 'adv', 'ผู้โจมตี Invisible: Attack ได้ Advantage');
    // v1.29 (Non เคาะ 16 พ.ย. 2026): โจมตีจากการซ่อนตัวได้ Advantage นับเป็น Perfect Strike แล้วหลุดจากการซ่อนตัว · หมากที่ GM กดซ่อนไว้นับเป็นการซ่อนตัวด้วย (ติ๊กออกได้)
    if (this.has(a, 'Hidden') || a.hidden){ const flagOnly = !!a.hidden && !this.has(a, 'Hidden'); add('ahid', 'adv', flagOnly ? 'หมากนี้ซ่อนอยู่: โจมตีจากการซ่อนตัวได้ Advantage แล้วหมากจะถูกเปิดเผย' : 'โจมตีจากการซ่อนตัว: Advantage แล้วหลุดจากการซ่อนตัว'); add('ahidp', 'perfect', 'โจมตีจากการซ่อนตัว: นับเป็น Perfect Strike'); }
    else if (this.has(a, 'Invisible')) add('ainvisp', 'perfect', 'ผู้โจมตี Invisible นับว่าอยู่ในสถานะซ่อนตัว: นับเป็น Perfect Strike'); // ไฟล์แกน: Invisible นับว่าอยู่ในสถานะซ่อนตัวเสมอ จึงได้ผลของการโจมตีจากการซ่อนตัวด้วย (ติ๊กออกได้)
    for (const foe of this.foesNear(r, a)) if (foe.stance && foe.stance.id === 'Night Blinder Stance'){ const encN = typeof Act !== 'undefined' && Act.on(r); const firstN = !encN || (Act.isTurn(a, r) && cbInt(Act.flag(a, 'atk')) <= 0); out.push({key: 'nblind', kind: 'cvn', n: -2, short: 'พรายดับตะวัน', def: firstN, label: `อยู่ในเขตปะทะของ ${foe.name} ที่ตั้งท่าพรายดับตะวัน: การโจมตีครั้งแรกของเทิร์น CV −2 (ถ้าเริ่มเทิร์นในเขตปะทะนั้น)`}); break; }
    if (cbInt(a.fabs) > 0) out.push({key: 'fabs', kind: 'dmgn', n: Math.min(99, cbInt(a.fabs)), def: !!(w && Array.isArray(w.dtypes) && w.dtypes.includes('Fire')), label: `ดูดกลืนอัคคี: การโจมตีไฟครั้งนี้ Fire Damage +${Math.min(99, cbInt(a.fabs))}`});
    if (mode === 'ranged' && this.foesNear(r, a).length) add('reng', 'dis', 'ใช้อาวุธระยะไกลขณะมีศัตรูอยู่ในเขตปะทะ: Disadvantage');
    if (w && w.strShort) add('str', 'dis', `STR ไม่ถึง ${w.strNeed}: โจมตีด้วยอาวุธนี้ติด Disadvantage`);
    else if (w && w.strNeed && w.src === 'npceq') add('strq', 'dis', `อาวุธนี้ต้องมี STR ${w.strNeed}: ติ๊กเมื่อ STR ของ NPC ไม่ถึง (Disadvantage)`);
    return out;
  },

  /* ---------- 4. หน้าต่างโจมตี ----------
   * v1.29 (Non สั่ง 16 พ.ย. 2026): ค่าพลังที่บวกความเสียหายตายตัวตามแบบการโจมตี · Focus (เล็ง Non-Lethal เทคนิคอาวุธ) เสีย 1 Swift Action · การโจมตีใช้ Action ตาม Action Track
   * Trait Proficiency ทักษะติดตัว และกระบวนท่าของผู้โจมตีเข้ามาเป็นตัวเลือก (feats.js) · ตัวปรับที่กรอกเองอยู่ในส่วนที่พับไว้ และขึ้นในแชตทุกครั้งที่ใช้
   * หน้าต่างลากย้ายได้ที่แถบหัว ความสูงคิดจากจอที่ถูก zoom แล้ว ปุ่มทอยเกาะขอบล่างเสมอ */
  openAttack(aid, tid, preset){
    const r = Table.room; if (!r){ toast('เปิดห้องก่อนจึงจะโจมตีได้'); return; }
    const mine = this.myTokens(r); if (!mine.length){ toast('ไม่มีหมากที่คุณบังคับได้บนบอร์ด วางตัวละครลงบอร์ดก่อน'); return; }
    let a = mine.find(t=>t.id === aid) || null;
    if (!a){ const sel = mine.find(t=>t.id === Table.sel); a = sel || mine[0]; }
    preset = (preset && typeof preset === 'object') ? preset : null;
    const fc = (preset && preset.focus) ? (['precise', 'nl', 'tech'].includes(preset.focus) ? preset.focus : 'precise') : '';
    this.comp = {a: a.id, t: (tid && tid !== a.id) ? tid : null, wi: 0, off: {}, feat: {}, advX: false, disX: false, perfectX: false, dice: 2, cvX: 0, focus: fc, aim: 'torso', act: (preset && ['s', 'b', 'c', 'free'].includes(preset.act)) ? preset.act : 'auto', force: false, statOv: '', hideName: !!a.hidden, far: false, cname: '', remember: false, preset};
    this.syncWeapon(true);
    if (preset && preset.pick){ const key = cbBaseName(preset.pick); const i = this.comp.list.findIndex(x=>cbBaseName(x.name) === key); if (i >= 0){ this.comp.wi = i; this.syncWeapon(); } }
    document.body.classList.add('cb-picking'); this.drawComposer();
  },
  closeComposer(){ const had = !!this.comp; this.comp = null; if (!(typeof SkillUse !== 'undefined' && SkillUse.pick)) document.body.classList.remove('cb-picking'); const el = document.getElementById('atkc'); if (el) el.remove(); if (had && Table.room) setTimeout(()=>this.checkPrompts(), 60); },
  /* คลิกหมากบนแผนที่ระหว่างเปิดหน้าต่างโจมตี = เลือกเป้า (คืน true เมื่อรับคลิกไว้) */
  onTokenClick(t){
    if (typeof SkillUse !== 'undefined' && SkillUse.onTokenClick(t)) return true;
    const s = this.comp; if (!s) return false; if (t.id === s.a) return false;
    if (t.kind === 'asset' && !(t.hpMax > 0)){ toast('สิ่งของนี้ไม่ได้ตั้งค่าความทนทาน จึงเลือกเป็นเป้าไม่ได้'); return true; }
    s.t = t.id; this.drawDyn(); return true;
  },
  syncWeapon(first){
    const s = this.comp; const a = this.tok(s.a); if (!a) return; const list = this.weaponsOf(a);
    if (first && s.preset && s.preset.weapon){ list.unshift(s.preset.weapon); s.wi = 0; }
    s.list = list; if (s.wi >= list.length) s.wi = 0; const w = list[s.wi];
    s.dmg = w.dmg; s.dtype = w.src === 'custom' ? 'Physical' : w.dtypes[0]; s.bonus = 0; s.toughX = w.toughX || 0; s.statOv = ''; s.off.strq = true; // STR ของ NPC ไม่มีค่าดิบให้เทียบ เหตุข้อนี้จึงเริ่มแบบไม่ติ๊ก
    s.props = {ap: !!(w.props.ap && w.props.ap.on), gb: !!(w.props.gb && w.props.gb.on), impact: !!(w.props.impact && w.props.impact.on), headshot: !!(w.props.headshot && w.props.headshot.on), impale: !!(w.props.impale && w.props.impale.on), rip: !!(w.props.rip && w.props.rip.on), wall: false, sharpnel: w.sharpnel || 0};
    s.mode = (s.preset && s.preset.mode && first) ? s.preset.mode : ((w.bomb || w.thrown) ? 'thrown' : (w.ranged ? 'ranged' : 'melee'));
    if (w.impaleThrown && s.mode === 'thrown') s.props.impale = true;
    if (!(first && s.preset && s.preset.act)) s.act = 'auto';
    s.cname = w.src === 'custom' ? (s.cname || '') : '';
  },
  setMode(k){ const s = this.comp; if (!s) return; const w = s.list[s.wi] || s.list[0]; s.mode = k; if (w && w.impaleThrown) s.props.impale = (k === 'thrown'); },
  /* คำนวณทุกอย่างของการโจมตีที่ตั้งอยู่ในหน้าต่าง: เหตุของ Advantage ความสามารถที่มีผล ค่าพลัง ระยะ Focus และ Action ที่ต้องใช้ */
  current(){
    const s = this.comp; const r = Table.room; if (!s || !r) return null; const a = this.tok(s.a); if (!a) return null; const t = s.t ? this.tok(s.t) : null;
    const w = s.list[s.wi] || s.list[0]; const st = this.atkStats(a); const gm = Table.isGM() || Table.localMode; const c = this.charOf(a);
    const enc = Act.on(r), myTurn = enc && Act.isTurn(a, r); const cells = t ? cellDist(a, t) : 0; const focus = s.focus || '';
    const isOn = (x)=> s.off[x.key] === undefined ? x.def !== false : !s.off[x.key];
    let reasons = this.atkReasons(r, a, t, w, s.mode).map(x=>Object.assign(x, {on: isOn(x)}));
    const hidden = reasons.some(x=>(x.key === 'ahid' || x.key === 'ainvisp') && x.on); // โจมตีจากการซ่อนตัว (รวม Invisible ที่นับว่าซ่อนตัวอยู่)
    const statKind = s.statOv || cbStatKind(w, s.mode);
    const shield = !!(c && c.equip && c.equip.shield && String(c.equip.shield.name || '').trim());
    const fb = Feats.build(a, FEAT_ATK, {r, a, t, w, mode: s.mode, statKind, dtype: s.dtype, focus, cells, enc, myTurn, hidden, allies: this.alliesNear(r, a).length, shield, again: (s.preset && s.preset.again) || null}, s.feat);
    const E = cbMergeEff(fb.opts.filter(p=>p.on));
    if (E.noStr) reasons = reasons.filter(x=>x.key !== 'str' && x.key !== 'strq');
    if (E.noCover) reasons = reasons.filter(x=>x.key !== 'cover');
    const impact = !!s.props.impact || E.impact;
    if (impact && s.mode === 'melee' && t && (this.has(t, 'Prone') || this.has(t, 'Stunned'))){ const x = {key: 'impactp', kind: 'perfect', label: 'Impact ใส่เป้าที่ติด Prone หรือ Stunned: Perfect Strike และความเสียหาย +1d3'}; x.on = isOn(x); reasons.push(x); }
    if (w.beastMul && t && !t.charId && t.kind === 'npc'){ const x = {key: 'beast', kind: 'mul', n: w.beastMul, def: t.nkind === 'fauna', label: `อาวุธนี้ทำความเสียหายกับสัตว์ ×${w.beastMul}`}; x.on = isOn(x); reasons.push(x); }
    // Action ที่การโจมตีครั้งนี้ใช้: เทิร์นของตัวเองใช้ Basic Action (หรือช่องที่อาวุธระบุ) นอกเทิร์นคือ Reaction หรือ Opportunity Attack ที่ไม่เสีย Action
    const alts = Array.isArray(w.actAlt) ? w.actAlt : []; let actKind = null, altDis = false; const actDef = (s.preset && (s.preset.skill || s.preset.free)) ? 'free' : (myTurn ? (w.act || 'b') : 'free');
    if (enc){ actKind = E.free ? 'free' : (s.act === 'auto' ? (E.act || actDef) : s.act); altDis = actKind !== 'free' && actKind !== (w.act || 'b') && alts.some(x=>x.k === actKind && x.dis); }
    if (altDis) reasons.push({key: 'altact', kind: 'dis', label: `โจมตีด้วย ${ACT_DEF[actKind].full} แทน Basic Action: Disadvantage`, on: true, fixed: true});
    const act = (k)=>reasons.some(x=>x.kind === k && x.on);
    const adv = act('adv') || s.advX || E.adv, dis = act('dis') || s.disX || E.dis; const mode = adv && dis ? 'normal' : adv ? 'adv' : dis ? 'dis' : 'normal';
    const perfect = act('perfect') || s.perfectX || E.perfect; const impactX = impact && (reasons.some(x=>x.key === 'impactp' && x.on) || !!s.props.wall);
    const might = st.might + E.might, sight = st.sight + E.sight + (s.mode === 'thrown' ? cbInt(w.throwSight) : 0);
    const statVal = statKind === 'none' ? 0 : (statKind === 'sight' ? sight : might);
    const reach = !!(w.props.reach) && !w.broken; const acc = rangeAccM(st.rangeLv) + (s.mode === 'ranged' ? cbInt(w.accBonus) : 0);
    const range = t ? cbRangeVerdict({mode: s.mode, cells, reach, acc, thrownFar: E.thrownFar}) : null;
    // Focus: Swift Action ของเทิร์นตัวเอง ใช้ไม่ได้ถ้า Maneuver ไปแล้ว (อาวุธระยะไกลทำได้เมื่อ Range ระดับ 2)
    const fcs = {kind: focus, cost: 0, block: ''};
    if (focus && enc){
      const rangedOk = s.mode !== 'melee' && st.rangeLv >= 2;
      if (!myTurn && !E.focusAnytime) fcs.block = 'Focus เป็น Swift Action ใช้ได้ในเทิร์นของตัวเอง';
      else if (cbInt(Act.flag(a, 'mv')) > 0 && !rangedOk && !E.focusAnytime) fcs.block = 'เคลื่อนที่ (Maneuver) ไปแล้วในเทิร์นนี้ จึง Focus ไม่ได้' + (s.mode !== 'melee' ? ' (อาวุธระยะไกลทำได้เมื่อ Range ถึงระดับ 2)' : '');
      fcs.cost = E.freeFocus ? 0 : 1;
    }
    const need = {}; const addNeed = (k)=>{ const kk = Act.kindFor(a, k); need[kk] = (need[kk] || 0) + 1; };
    if (enc && actKind && actKind !== 'free') addNeed(actKind); if (fcs.cost) addNeed('s');
    let actBlock = '';
    if (enc){ const lock = Act.locked(a);
      if (lock) actBlock = `${a.name} ${lock}`; else if (fcs.block) actBlock = fcs.block;
      else for (const [kk, n] of Object.entries(need)) if (Act.left(a, kk) < n){ actBlock = `${ACT_DEF[kk].full} ของ ${a.name} ${Act.total(a, kk) ? (Act.left(a, kk) ? `เหลือ ${Act.left(a, kk)} แต่ต้องใช้ ${n}` : 'ใช้ไปแล้วในเทิร์นนี้') : 'ไม่มีในเทิร์นนี้'}`; break; } }
    const cvParts = []; if (w.cvBonus) cvParts.push({label: 'CV Bonus', n: w.cvBonus}); if (range && range.cv) cvParts.push({label: 'ระยะ', n: range.cv});
    if (focus === 'precise') cvParts.push({label: 'Focus (Precise) Sight', n: sight});
    if (w.focusNeed && !focus) cvParts.push({label: 'ไม่ได้ Focus ก่อนยิง', n: -w.focusNeed});
    if (reasons.some(x=>x.key === 'marked' && x.on)) cvParts.push({label: 'Marked', n: sight});
    for (const x of reasons) if (x.kind === 'cvn' && x.on) cvParts.push({label: x.short || 'สภาวะ', n: x.n});
    if (E.cv) cvParts.push({label: 'ความสามารถ', n: E.cv}); if (s.cvX) cvParts.push({label: 'ปรับเอง', n: s.cvX});
    const cvMod = cvParts.reduce((x, p)=>x + p.n, 0);
    const base = Math.max(2, Math.min(4, s.dice | 0)) + Math.max(0, Math.min(2, E.dice)); const n = Math.min(6, base + (mode === 'normal' ? 0 : 1));
    const loc = (focus === 'precise' || E.pickPart) ? ((s.aim && HIT_DEFEND[s.aim]) ? s.aim : 'torso') : null;
    const dmgMul = reasons.filter(x=>x.kind === 'mul' && x.on).reduce((m, x)=>m * Math.max(1, cbInt(x.n, 1)), 1); const dmgAdd = reasons.filter(x=>x.kind === 'dmgn' && x.on).reduce((n0, x)=>n0 + cbInt(x.n), 0);
    let block = null;
    if (!t) block = 'เลือกเป้าหมายก่อน (คลิกหมากบนแผนที่ หรือเลือกจากรายการ)';
    else if (range && !range.ok && !s.far) block = range.text;
    else if (/^x\s*d/i.test(String(s.dmg || '').trim())) block = 'สูตรความเสียหายของการโจมตีนี้มี X ที่ต้องนับเอง ใส่จำนวนลูกเต๋าแทน X ในช่องความเสียหาย (เช่น 3d3)';
    else if (!cbExprOk(s.dmg)) block = 'ความเสียหายของอาวุธต้องเป็นตัวเลขหรือรูปแบบเต๋า เช่น 2 หรือ 1d6+1';
    else if (c && Table.attackBlocked && Table.attackBlocked(c)) block = Table.attackBlocked(c);
    else if (actBlock && !s.force) block = actBlock;
    const los = (t && s.mode !== 'melee') ? losClear(r.map, a, t) : true;
    return {s, r, a, t, w, st, c, gm, enc, myTurn, cells, range, reasons, mode, perfect, impact, impactX, statKind, statVal, might, sight, cvParts, cvMod, n, block, los, focus, fcs, actKind, actDef, need, actBlock, E, fb, loc, alts, dmgMul, dmgAdd, hidden};
  },
  /* ช่องความเสียหายแก้ได้เมื่อไร: GM แก้ได้เสมอ ผู้เล่นแก้ได้เฉพาะการโจมตีที่กำหนดเอง สูตรที่มี X หรือบรรทัดที่ระบบอ่านไม่ออก */
  dmgEditable(w, gm){ return gm || w.src === 'custom' || (w.src === 'npc' && !w.found) || /^x\s*d/i.test(String(w.dmg || '')) || !cbExprOk(w.dmg); },
  /* วาดหน้าต่างโจมตี: ส่วนคงที่ (ช่องกรอก) วาดใหม่เมื่อโครงเปลี่ยน ส่วนที่คำนวณ (ระยะ เหตุ ความสามารถ สรุป ปุ่มทอย) วาดใหม่ทุกครั้งที่ค่าเปลี่ยน
   * ช่องพิมพ์อัปเดตด้วย input แล้ววาดเฉพาะส่วนคำนวณ ช่องที่กำลังพิมพ์จึงไม่ถูกทำลายกลางคัน */
  drawComposer(){
    if (this.drawing){ this.redrawAgain = true; return; }
    const cur = this.current(); if (!cur){ this.closeComposer(); return; }
    this.drawing = true;
    try {
      const {s, r, a, w, st, gm, enc} = cur;
      let root = document.getElementById('atkc');
      if (!root){ root = h('div',{id:'atkc',class:'atkc',role:'dialog','aria-label':'หน้าต่างโจมตี'}); document.body.append(...cbKids(root));
        if (this.pos && !isNarrow()){ root.style.left = this.pos.x + 'px'; root.style.top = this.pos.y + 'px'; root.style.right = 'auto'; } }
      let body = root.querySelector('.atkc-body'); const keepScroll = body ? body.scrollTop : 0; clear(root); const redraw = ()=>this.drawComposer(); const dyn = ()=>this.drawDyn();
      const head = h('div',{class:'atkc-head',title:'ลากแถบนี้เพื่อย้ายหน้าต่าง'}, h('b',{text:'⚔ โจมตี'}), h('span',{class:'dim',text:' คลิกหมากบนแผนที่เพื่อเลือกเป้า'}), h('button',{class:'small ghost atkc-x',title:'ปิดหน้าต่างโจมตี',onclick:()=>this.closeComposer(),text:'✕'}));
      body = h('div',{class:'atkc-body'}); const foot = h('div',{class:'atkc-foot'});
      root.append(...cbKids(head, body, foot));
      if (typeof makeDraggable === 'function' && !isNarrow()) makeDraggable(root, head, (p)=>{ this.pos = {x: Math.round(p.x), y: Math.round(p.y)}; });
      const mine = this.myTokens(r);
      const tgts = this.visible(r).filter(x=>x.id !== a.id && (x.kind !== 'asset' || x.hpMax > 0));
      const grid = h('div',{class:'atkc-grid'});
      grid.append(...cbKids(h('label',{text:'ผู้โจมตี'}), mine.length > 1 ? cbSelect(mine.map(x=>[x.id, x.name]), a.id, (v)=>{ s.a = v; if (s.t === v) s.t = null; s.wi = 0; s.feat = {}; s.off = {}; s.hideName = !!(this.tok(v) || {}).hidden; this.syncWeapon(); redraw(); }, {class:'atkc-a'}) : h('b',{class:'atkc-a',text:a.name})));
      grid.append(...cbKids(h('label',{text:'เป้าหมาย'}), cbSelect([['', 'เลือกเป้า หรือคลิกหมากบนแผนที่'], ...tgts.map(x=>[x.id, `${x.name} (${cellDist(a, x) * CELL_M} ม.)`])], s.t || '', (v)=>{ s.t = v || null; dyn(); }, {class:'atkc-t'})));
      grid.append(...cbKids(h('label',{text:'อาวุธ'}), cbSelect(s.list.map((x, i)=>[i, x.name + (x.found && x.src !== 'custom' ? ` · ${x.dmg} ${x.dtypes.join('/')}` : '')]), s.wi, (v)=>{ s.wi = +v; this.syncWeapon(); redraw(); }, {class:'atkc-w'})));
      if (w.src === 'custom'){ const nm = h('input',{class:'atkc-cname',placeholder:'ชื่อการโจมตี เช่น กรงเล็บ',maxlength:60}); nm.value = s.cname || ''; nm.oninput = ()=>{ s.cname = nm.value.trim().slice(0, 60); }; grid.append(...cbKids(h('label',{text:'ชื่อ'}), nm)); }
      const modeBtn = (k, label, tip)=>h('button',{class:'small atkc-mode' + (s.mode === k ? ' primary' : ''),dataset:{mode:k},title:tip,onclick:()=>{ this.setMode(k); redraw(); },text:label});
      grid.append(...cbKids(h('label',{text:'แบบการโจมตี'}), h('div',{class:'row',style:'gap:6px'}, modeBtn('melee', 'ประชิด', 'ต้องอยู่เขตปะทะ อาวุธ Reach เอื้อมได้อีกหนึ่งช่อง ความเสียหายบวก Might'), modeBtn('thrown', 'ขว้าง', 'ขว้างได้ถึงเขตใกล้เคียง ไม่ติด Disadvantage จากการมีศัตรูประชิด ความเสียหายบวก Sight'), modeBtn('ranged', 'ยิง', 'เกินระยะแม่นหัก 1 CV ต่อทุก 2 เมตรที่เกิน มีศัตรูในเขตปะทะติด Disadvantage ความเสียหายบวก Sight'))));
      // ความเสียหาย: ตัวเลขของอาวุธตายตัวตามชีท ผู้เล่นเลือกได้แค่ประเภทเมื่ออาวุธมีหลายประเภท ค่าพลังที่บวกมาจากแบบการโจมตี
      const types = (w.src === 'custom' || (w.src === 'npc' && !w.found)) ? CB_DTYPES : w.dtypes; const canDmg = this.dmgEditable(w, gm);
      const dmgEl = canDmg ? (()=>{ const el = h('input',{class:'atkc-dmg',title:'ความเสียหายตั้งต้นของอาวุธ ตัวเลขหรือรูปแบบเต๋า เช่น 2 หรือ 1d6+1',style:'width:74px'}); el.value = s.dmg; el.oninput = ()=>{ s.dmg = el.value.trim(); dyn(); }; return el; })() : h('b',{class:'num atkc-dmgfix',title:'ความเสียหายของอาวุธตามชีท',text:String(s.dmg)});
      grid.append(...cbKids(h('label',{text:'ความเสียหาย'}), h('div',{class:'row',style:'gap:6px'}, dmgEl, types.length > 1 ? cbSelect(types.map(x=>[x, x]), s.dtype, (v)=>{ s.dtype = v; dyn(); }, {class:'atkc-dtype',title:'ประเภทความเสียหายของการโจมตีครั้งนี้'}) : tag(s.dtype, 'prop'), h('span',{class:'atkc-statfix'}))));
      if (enc){
        const kOpt = (k)=>[k, ACT_DEF[Act.kindFor(a, k)].full + (Act.left(a, k) > 0 ? '' : ' (ใช้ไปแล้ว)')];
        const extra = [...new Set([w.act, ...(Array.isArray(w.actAlt) ? w.actAlt.map(x=>x.k) : [])].filter(k=>k && k !== 'b'))];
        const opts = [['auto', 'ตามกฎ'], kOpt('b'), ...extra.map(kOpt), ['free', 'ไม่ใช้ Action (Reaction · Opportunity Attack · Free Action)']];
        if (s.act !== 'auto' && !opts.some(o=>o[0] === s.act)) opts.splice(1, 0, kOpt(s.act));
        grid.append(...cbKids(h('label',{text:'ใช้ Action'}), h('div',{class:'row',style:'gap:6px'}, cbSelect(opts, s.act, (v)=>{ s.act = v; dyn(); }, {class:'atkc-act',title:'เทิร์นของตัวเองใช้ Basic Action (หรือ Action ที่อาวุธระบุ) · นอกเทิร์นคือ Reaction หรือ Opportunity Attack ที่ไม่เสีย Action'}), h('span',{class:'dim atkc-actnote'}))));
      }
      const fSel = cbSelect([['', 'ไม่ Focus (ตำแหน่งตามเต๋า)'], ['precise', 'Precise: เล็งตำแหน่ง บวก CV ตาม Sight'], ['nl', 'Non-Lethal: เสียแค่ HP ไม่ติดสภาวะทางกาย'], ['tech', 'Equipment Technique: ใช้เทคนิคของอาวุธ']], s.focus, (v)=>{ s.focus = v; redraw(); }, {class:'atkc-focus',title:'Focus เป็น Swift Action เลือกได้หนึ่งอย่างต่อการโจมตี ใช้ไม่ได้ถ้า Maneuver ไปแล้วในเทิร์นนี้'});
      const aimSel = (s.focus === 'precise' || cur.E.pickPart) ? cbSelect(DATA.meta.bodyParts.map(([k, l])=>[k, (s.focus === 'precise' ? 'เล็ง' : 'เลือก') + l]), s.aim, (v)=>{ s.aim = v; dyn(); }, {class:'atkc-aim',title:'ตำแหน่งที่จะโดน ไม่เปลี่ยนตามหน้าเต๋า ฝ่ายรับที่ Parry ยังดูกลุ่มจากเลขที่ทอยได้'}) : null;
      grid.append(...cbKids(h('label',{text:'Focus'}), h('div',{class:'row',style:'gap:6px'}, fSel, aimSel)));
      body.append(...cbKids(grid, h('div',{class:'atkc-dyn1'})));
      // ตัวปรับที่กรอกเองและคุณสมบัติของการโจมตีครั้งนี้ (พับไว้): ใช้เมื่อสกิล สถานการณ์ หรือคำตัดสินของ GM เปลี่ยนค่าจากที่ระบบคิดให้
      const adv = h('details',{class:'atkc-adv'}); adv.open = !!this.advOpen || w.src === 'custom'; adv.ontoggle = ()=>{ this.advOpen = adv.open; };
      adv.append(...cbKids(h('summary',{text:'ตัวปรับและคุณสมบัติเพิ่มเติม (สกิล สถานการณ์ หรือคำตัดสินของ GM)'})));
      adv.append(...cbKids(h('div',{class:'row atkc-opts',style:'gap:6px'}, cbSelect([[2, 'Combat Dice 2 ลูก'], [3, 'Combat Dice 3 ลูก'], [4, 'Combat Dice 4 ลูก']], s.dice, (v)=>{ s.dice = +v; dyn(); }, {class:'atkc-dice',title:'ปกติ 2 ลูก สกิลหรืออาวุธบางอย่างเพิ่มให้'}),
        cbNum(s.cvX || '', (v)=>{ s.cvX = v || 0; dyn(); }, {class:'atkc-cvx',style:'width:92px',placeholder:'ตัวปรับ CV',title:'ตัวปรับ CV อื่นที่ระบบไม่ได้คิดให้'}, true),
        h('span',{class:'dim',text:'โบนัสความเสียหาย'}), cbNum(s.bonus || '', (v)=>{ s.bonus = v || 0; dyn(); }, {class:'atkc-bonus',style:'width:56px',placeholder:'0',title:'ความเสียหายเพิ่มจากสกิลหรือสถานการณ์ที่ระบบไม่ได้คิดให้'}, true),
        gm ? cbSelect([['', 'ค่าพลังตามกฎ'], ['might', `บวก Might ${signed(st.might)}`], ['sight', `บวก Sight ${signed(st.sight)}`], ['none', 'ไม่บวกค่าพลัง']], s.statOv, (v)=>{ s.statOv = v; dyn(); }, {class:'atkc-stat',title:'GM เปลี่ยนค่าพลังที่บวกความเสียหายของการโจมตีครั้งนี้ได้ (กฎ: ประชิดบวก Might ระยะไกลบวก Sight)'}) : null)));
      const pr = h('div',{class:'atkc-props'}); const propBox = (k, label, tip, full)=>cbCheck(label, s.props[k], (v)=>{ s.props[k] = v; if (full) redraw(); else dyn(); }, {class:'fld chk pp' + (w.props[k] ? '' : ' off'),title:tip,dataset:{prop:k}});
      pr.append(...cbKids(propBox('ap', 'Armor Penetrate', 'เกราะของจุดที่โดนเหลือครึ่งเดียว (ปัดลง)'), propBox('gb', 'Guard Break', 'ฝ่ายรับ Parry แบบ Advantage ไม่ได้ และไม่ได้ Parry Dice'), propBox('impact', 'Impact', 'โดนเป้าที่ติด Prone หรือ Stunned หรือผลักไปชนกำแพง = Perfect Strike และ +1d3', true), propBox('headshot', 'Headshot', 'เต๋าออกตำแหน่งศีรษะ (ไม่ได้เล็ง) = Perfect Strike'), propBox('impale', 'Impale', 'โดนแล้วเป้าติด Rooted'), propBox('rip', 'Rip', 'โดนส่วนที่ไม่มีเกราะ ผู้โจมตีเลือกเปลี่ยนความเสียหายที่เข้า HP เป็น Bleeding ได้ ระบบตรวจเกราะและถามหลังรู้ผล')));
      if (s.props.impact) pr.append(...cbKids(cbCheck('ผลักไปชนกำแพง', s.props.wall, (v)=>{ s.props.wall = v; dyn(); }, {class:'fld chk pp',dataset:{prop:'wall'}})));
      pr.append(...cbKids(h('label',{class:'fld'}, h('span',{text:'Toughness Damage เพิ่ม'}), cbNum(s.toughX || '', (v)=>{ s.toughX = Math.max(0, Math.min(6, v || 0)); }, {class:'atkc-toughx',style:'width:52px',placeholder:'0',min:0,max:6}, true)), h('label',{class:'fld'}, h('span',{text:'Sharpnel'}), cbNum(s.props.sharpnel || '', (v)=>{ s.props.sharpnel = Math.max(0, Math.min(6, v || 0)); }, {class:'atkc-sharp',style:'width:52px',placeholder:'0',min:0,max:6}, true))));
      if (w.toughOpt) pr.append(...cbKids(h('span',{class:'dim',style:'font-size:11.5px',text:`อาวุธนี้มี +${w.toughOpt} Toughness Damage แบบมีเงื่อนไข ใส่ตัวเลขเองเมื่อเข้าเงื่อนไข`})));
      adv.append(...cbKids(pr, h('div',{class:'row atkc-xrow',style:'gap:10px;margin-top:6px'}, cbCheck('Advantage อื่น', s.advX, (v)=>{ s.advX = v; dyn(); }, {class:'fld chk atkc-advx'}), cbCheck('Disadvantage อื่น', s.disX, (v)=>{ s.disX = v; dyn(); }, {class:'fld chk atkc-disx'}), cbCheck('นับเป็น Perfect Strike', s.perfectX, (v)=>{ s.perfectX = v; dyn(); }, {class:'fld chk atkc-perfx',title:'สกิลหรือสถานการณ์ที่ให้ Perfect Strike โดยไม่ต้องทอยได้หน้าเหมือน'}))));
      body.append(...cbKids(adv));
      if (a.hidden) body.append(...cbKids(cbCheck('ปกปิดชื่อผู้โจมตีในแชต (ใช้ได้เมื่อไม่นับเป็นการโจมตีจากการซ่อนตัว)', s.hideName, (v)=>{ s.hideName = v; }, {class:'fld chk atkc-hide'})));
      if (gm && st.npc && w.src === 'custom') body.append(...cbKids(cbCheck('จำการโจมตีนี้ไว้ในสแตตบล็อกของหมาก', s.remember, (v)=>{ s.remember = v; }, {class:'fld chk atkc-rem',title:'เพิ่มเป็นบรรทัดการโจมตีของหมากตัวนี้ แก้หรือลบได้ที่แผงหมาก'})));
      if (w.text && w.src !== 'unarmed') body.append(...cbKids(h('details',{class:'atkc-eff'}, h('summary',{text:'ข้อความเอฟเฟกต์ของอาวุธ'}), h('div',{class:'desc',style:'font-size:12px'}, T(w.text)))));
      foot.append(...cbKids(h('div',{class:'atkc-dyn2'})));
      body.scrollTop = keepScroll;
    } finally { this.drawing = false; }
    this.drawDyn();
    const root = document.getElementById('atkc'); if (root && typeof clampToViewport === 'function') clampToViewport(root);
    if (this.redrawAgain){ this.redrawAgain = false; this.drawComposer(); }
  },
  /* ส่วนที่คำนวณของหน้าต่างโจมตี: ระยะ คำเตือน เหตุของ Advantage และ Disadvantage ความสามารถของตัวละคร สรุปการทอย และปุ่มทอย */
  drawDyn(){
    const root = document.getElementById('atkc'); if (!root) return; const d1 = root.querySelector('.atkc-dyn1'), d2 = root.querySelector('.atkc-dyn2'); if (!d1 || !d2) return;
    const cur = this.current(); if (!cur){ this.closeComposer(); return; }
    const {s, r, a, t, w, gm, enc, myTurn, range, reasons, mode, perfect, statKind, statVal, cvParts, cvMod, n, focus, fcs, actKind, E, fb} = cur; const dyn = ()=>this.drawDyn();
    const tSel = root.querySelector('.atkc-t'); if (tSel && tSel.value !== (s.t || '')) tSel.value = s.t || '';
    const sf = root.querySelector('.atkc-statfix'); if (sf){ sf.textContent = statKind === 'none' ? 'ไม่บวกค่าพลัง' : `บวก ${statKind === 'sight' ? 'Sight' : 'Might'} ${signed(statVal)}`; sf.title = s.statOv ? 'GM เปลี่ยนค่าพลังของการโจมตีครั้งนี้' : (w.statKind === 'auto' || !w.statKind ? 'กฎ: การโจมตีระยะประชิดบวก Might อาวุธระยะไกลและการขว้างบวก Sight' : 'ตามสูตรที่บรรทัดการโจมตีนี้เขียนไว้'); }
    const an = root.querySelector('.atkc-actnote'); if (an){ const bits = []; if (actKind && actKind !== 'free') bits.push(ACT_DEF[Act.kindFor(a, actKind)].full); if (fcs.cost) bits.push('Swift Action (Focus)'); an.textContent = bits.length ? 'จะใช้ ' + bits.join(' และ ') : (myTurn ? 'ไม่เสีย Action' : 'นอกเทิร์น ไม่เสีย Action'); }
    clear(d1); clear(d2);
    if (s.mode === 'thrown' && !w.props.throwable && w.src !== 'custom' && !w.bomb && !E.throwable) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'อาวุธนี้ไม่มีคุณสมบัติ Throwable ขว้างได้เมื่อมีความสามารถรองรับ (เช่น Trickster) หรือ GM อนุญาต'})));
    if (w.broken) d1.append(...cbKids(h('div',{class:'atkc-note warn atkc-broken',text:'อาวุธนี้พัง (Durability 0): PDMG เหลือครึ่งปัดลง และคุณสมบัติพิเศษหาย'})));
    if (w.src === 'npc' && !w.found) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'ระบบอ่านสูตรความเสียหายจากบรรทัดการโจมตีนี้ไม่ออก ใส่ความเสียหายและประเภทเองได้ในช่องด้านบน'})));
    if (range) d1.append(...cbKids(h('div',{class:'atkc-range ' + range.cls,text:range.text})));
    if (range && !range.ok && gm) d1.append(...cbKids(cbCheck('โจมตีทั้งที่ไกลเกิน (GM อนุญาต)', s.far, (v)=>{ s.far = v; dyn(); }, {class:'fld chk atkc-far'})));
    if (t && !cur.los) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'มีสิ่งกีดขวางบังแนวยิงระหว่างสองหมาก ให้ GM ตัดสินว่ายิงได้ไหม'})));
    if (w.props.delay && !E.noDelay && enc && !myTurn) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'อาวุธนี้มี Delay ใช้โจมตีได้เฉพาะในเทิร์นของตัวเอง'})));
    if (w.focusNeed && !focus) d1.append(...cbKids(h('div',{class:'atkc-note warn atkc-needfocus',text:`อาวุธนี้ต้อง Focus ก่อนโจมตี ยิงโดยไม่ Focus โดนลด CV ${w.focusNeed}`})));
    if (focus === 'tech') d1.append(...cbKids(h('div',{class:'atkc-note',text:'Focus (Equipment Technique): ใช้ความสามารถของอาวุธตามข้อความเอฟเฟกต์ ผลที่ระบบไม่ได้คิดให้ ใส่ในตัวปรับเพิ่มเติม'})));
    if (a.hp != null && a.hp <= 0) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:`${a.name} เหลือ HP 0 ให้ GM ตัดสินว่ายังลงมือได้ไหม`})));
    if (cur.actBlock) d1.append(...cbKids(h('div',{class:'atkc-note bad atkc-actblock',text:cur.actBlock}), gm ? cbCheck('ให้ลงมือได้โดยไม่หัก Action (GM อนุญาต)', s.force, (v)=>{ s.force = v; dyn(); }, {class:'fld chk atkc-force'}) : h('div',{class:'dim',style:'font-size:12px',text:'ขอให้ GM คืน Action ที่ Action Track ถ้าลงมือได้'})));
    const rs = h('div',{class:'atkc-reasons'});
    for (const x of reasons){ const el = cbCheck(x.label, x.on, (v)=>{ s.off[x.key] = !v; dyn(); }, {class:'fld chk rs-' + x.kind,dataset:{key:x.key}}); if (x.fixed) el.querySelector('input').disabled = true; rs.append(...cbKids(el)); }
    for (const p of fb.opts){ const el = cbCheck(p.label, p.on, (v)=>{ s.feat[p.id] = v; if (v && p.group) for (const q of fb.opts) if (q.group === p.group && q.id !== p.id) s.feat[q.id] = false; this.drawComposer(); }, {class:'fld chk rs-feat' + (p.off ? ' off' : ''),dataset:{feat:p.id},title:String(p.f.text || '').slice(0, 500)}); if (p.off) el.querySelector('input').disabled = true; rs.append(...cbKids(el)); }
    if (rs.children.length) d1.append(...cbKids(rs));
    const more = Feats.remindBox(a, fb.list, FT_ATK_RX, FEAT_ATK, 'ความสามารถอื่นของตัวละครที่เกี่ยวกับการโจมตี ระบบไม่ได้คิดให้'); if (more) d1.append(...cbKids(more));
    const mul = perfect ? E.mul : 1; const avg = (cbExprAvg(s.dmg) + (statKind === 'none' ? 0 : statVal * mul) + (s.bonus || 0) + E.dmg + cur.dmgAdd + E.dmgDice.reduce((x, e)=>x + cbExprAvg(e), 0)) * cur.dmgMul;
    const extraTxt = [(s.bonus || 0) + E.dmg + cur.dmgAdd ? signed((s.bonus || 0) + E.dmg + cur.dmgAdd) : '', ...E.dmgDice.map(e=>'+' + e), cur.dmgMul > 1 ? `×${cur.dmgMul}` : ''].filter(Boolean).join(' ');
    d2.append(...cbKids(h('div',{class:'atkc-sum'}, h('span',{text:`ทอย ${n}d6${mode === 'adv' ? ' Advantage ผู้โจมตีเลือก 2 ลูก' : mode === 'dis' ? ' Disadvantage ฝ่ายรับเลือก 2 ลูก' : (n > 2 ? ' ผู้โจมตีเลือก 2 ลูก' : '')}`}), cvMod ? h('span',{class:'num',text:` · CV ${signed(cvMod)} (${cvParts.map(p=>p.label + ' ' + signed(p.n)).join(', ')})`}) : null,
      h('span',{class:'num',text:` · ถ้าโดน ${s.dmg}${statKind !== 'none' && statVal ? ` ${signed(statVal)}${perfect ? '×' + E.mul : ''}` : ''}${extraTxt ? ' ' + extraTxt : ''}${(/d/i.test(s.dmg) || E.dmgDice.length) ? ` (เฉลี่ย ${Math.round(avg * 10) / 10})` : ` = ${avg}`} ${s.dtype}`}), perfect ? h('span',{class:'tag prop',text:'Perfect Strike'}) : null)));
    const go = h('button',{class:'primary atkc-go',onclick:()=>this.fire(),text:'🎲 ทอยโจมตี'}); if (cur.block){ go.disabled = true; d2.append(...cbKids(h('div',{class:'atkc-note bad atkc-block',text:cur.block}))); }
    d2.append(...cbKids(h('div',{class:'row',style:'justify-content:flex-end;gap:8px;margin-top:8px'}, h('button',{class:'small ghost',onclick:()=>this.closeComposer(),text:'ยกเลิก'}), go)));
    this.markTarget();
  },
  /* วงแดงรอบหมากที่ถูกเลือกเป็นเป้า */
  markTarget(){ for (const el of document.querySelectorAll('.gridmap .gtok.cb-tgt')) el.classList.remove('cb-tgt'); const id = this.comp && this.comp.t; if (!id) return; const el = document.querySelector('#v-table .gridmap .gtok[data-id="' + String(id).replace(/[^A-Za-z0-9_-]/g, '') + '"]'); if (el) el.classList.add('cb-tgt'); },
  /* ทอยโจมตีตามค่าที่ตั้งในหน้าต่าง หัก Action และจำนวนครั้งของความสามารถ แล้วโพสต์เป็นข้อความที่รอฝ่ายรับ */
  fire(){
    const cur = this.current(); if (!cur || cur.block){ if (cur && cur.block) toast(cur.block); return; }
    const {s, r, a, t, w, enc, mode, perfect, impact, impactX, statKind, statVal, cvParts, cvMod, n, cells, reasons, focus, fcs, actKind, E, fb, loc} = cur;
    const wname = w.src === 'custom' ? (s.cname || 'การโจมตี') : w.name; const fromHide = cur.hidden;
    const who = (a.hidden && s.hideName && !fromHide) ? 'บางสิ่งที่มองไม่เห็น' : a.name; const nonLethal = focus === 'nl';
    const adj = []; if (s.advX) adj.push('Advantage'); if (s.disX) adj.push('Disadvantage'); if (s.perfectX) adj.push('Perfect Strike'); if (s.cvX) adj.push(`CV ${signed(s.cvX)}`); if (s.bonus) adj.push(`ความเสียหาย ${signed(s.bonus)}`); if (s.dice > 2) adj.push(`Combat Dice ${s.dice} ลูก`);
    if (s.statOv) adj.push(s.statOv === 'none' ? 'ไม่บวกค่าพลัง' : `บวก ${s.statOv === 'sight' ? 'Sight' : 'Might'}`); if (s.force && cur.actBlock) adj.push('GM อนุญาตให้ลงมือโดยไม่หัก Action'); if (s.far) adj.push('GM อนุญาตให้โจมตีไกลเกินระยะ');
    const rules = [...(Array.isArray(w.hits) && !w.broken ? w.hits : []), ...E.hitCond.map(x=>({id: x.id, lv: x.lv || null, ends: x.ends || null})), ...E.perfectCond.map(x=>({id: x.id, lv: x.lv || null, ends: x.ends || null, perfect: true})),
      ...E.saveCond.map(x=>({id: x.id, lv: x.lv || null, save: {stat: x.stat, dc: x.dc}})), ...E.sumCond.map(x=>({id: x.id, sumMin: x.min != null ? x.min : null, sumMax: x.max != null ? x.max : null}))].slice(0, 10);
    const ruled = new Set(rules.map(x=>x.id)); const acts = []; const willPay = enc && !(s.force && cur.actBlock);
    if (willPay && actKind && actKind !== 'free') acts.push(ACT_DEF[Act.kindFor(a, actKind)].full); if (willPay && fcs.cost) acts.push('Swift Action (Focus)');
    const flow = {v: 2, type: 'attack', a: {id: a.id, name: who, kind: a.kind}, t: {id: t.id, name: t.name, kind: t.kind}, mode: s.mode, cells, m: cells * CELL_M, focus: focus || null,
      w: {name: wname, dmg: s.dmg, dtype: s.dtype, physical: cbIsPhysical(s.dtype), stat: statKind === 'none' ? 0 : statVal, statKind, bonus: (s.bonus || 0) + E.dmg + cur.dmgAdd, mul: E.mul, dmgMul: cur.dmgMul, dmgDice: E.dmgDice.slice(0, 4), hpDice: E.hpDice.slice(0, 4), perfectDmg: E.perfectDmg,
        toughX: (s.toughX || 0) + E.tough, toughDice: E.toughDice.slice(0, 2), toughPerfect: w.toughPerfect || 0, toughArmored: w.broken ? 0 : (w.toughArmored || 0), sharpnel: s.props.sharpnel || 0, rip: (!!s.props.rip || E.rip) && !w.broken, ap: !!s.props.ap || E.ap, gb: !!s.props.gb, gbAbove: (!s.props.gb && !w.broken && w.gbAbove != null) ? cbInt(w.gbAbove) : null, impact, impactX: !!impactX, impactOnPerfect: E.impactOnPerfect,
        headshot: !!s.props.headshot, impale: !!s.props.impale, nonLethal, ignoreArmor: cbInt(w.ignoreArmor) + E.ignoreArmor, perfectOn: [...new Set(E.perfectOn)].slice(0, 4), noDmg: E.noDmgCond ? {id: E.noDmgCond.id, ends: E.noDmgCond.ends || null} : null, hits: rules,
        conds: (w.conds || []).filter(x=>!ruled.has(x.id)).slice(0, 6), halve: !!w.halve, broken: !!w.broken, skill: (s.preset && s.preset.skill) || null},
      perfect: !!perfect, reasons: reasons.filter(x=>x.on).map(x=>x.label).slice(0, 10), feats: fb.opts.filter(p=>p.on).map(p=>String(p.label).slice(0, 180)).slice(0, 10), adj: adj.slice(0, 8), acts, notes: E.notes.slice(0, 4), cvParts};
    const part = loc; const label = `โจมตี ${t.name} ด้วย ${wname}` + (focus === 'precise' ? ` · เล็ง${partLabel(part)}` : (part ? ` · เลือก${partLabel(part)}` : '')) + (nonLethal ? ' · Non-Lethal' : focus === 'tech' ? ' · Focus เทคนิคอาวุธ' : '');
    const id = 'atk-' + uid();
    if (s.remember && w.src === 'custom' && this.controls(a) && this.isNpc(a)){ // เก็บเป็นบรรทัดการโจมตีแบบเดียวกับสแตตบล็อก ตัวอ่านเดียวกันอ่านกลับได้
      const line = `${s.mode === 'melee' ? '' : 'Range Attack, '}CV Bonus +0, Damage ${s.dmg}${statKind === 'might' ? ' + Might' : statKind === 'sight' ? ' + Sight' : ''} ${s.dtype}`;
      a.attacks = [{name: wname, text: line}, ...(Array.isArray(a.attacks) ? a.attacks : []).filter(x=>x && x.name !== wname)].slice(0, 12); }
    /* ก่อนทอย: หัก Action จำนวนครั้งของความสามารถ และธงบนหมาก (ทุกอย่างบันทึกพร้อมกันหลังโพสต์) */
    const pre = (known)=>{ const notes = [];
      if (willPay){ if (actKind && actKind !== 'free') Act.spend(a, actKind); if (fcs.cost) Act.spend(a, 's'); }
      if (enc){ Act.setFlag(a, 'atk', cbInt(Act.flag(a, 'atk')) + 1); if (focus) Act.setFlag(a, 'focus', 1); }
      for (const p of fb.opts) if (p.on && p.o.use){ const nt = Feats.spend(a, fb.c, p.f, p.o); if (nt) notes.push(nt); }
      for (const k of E.clear) if (CB_FLAGS.includes(k)) delete a[k]; for (const x of E.set) if (CB_FLAGS.includes(x.k)) a[x.k] = x.v;
      if (reasons.some(x=>x.on && x.key === 'fabs')) delete a.fabs;
      if (Feats.has(t, 'Ring of Fire')) t.rof = 1;
      return notes; };
    const run = async ()=>{
      if (mode === 'dis'){ const dice = Array.from({length: n}, rollD6); Table.post({kind: 'pick', fixedId: id, who, text: label, dice, cvMod, loc: part, gmOnly: false, flow}); toast('ทอยแล้ว รอฝ่ายรับหรือ GM เลือก 2 ลูกในแชต'); return; }
      const rr = n > 2 ? await rollChoose(n, mode, `โจมตี ${t.name}: ทอย ${n}d6 เลือก 2 ลูก`, {kind: 'attack', cvMod, loc: part}) : roll2d6('normal');
      const av = attackVerdict(rr, {cvMod, loc: part});
      Table.post({kind: 'roll', fixedId: id, who, text: label, roll: {dice: rr.dice, kept: rr.kept, keptIdx: rr.keptIdx, sum: rr.sum, crit: null, double: rr.double, mode, chosen: !!rr.chosen}, mod: cvMod, pm: 0, total: av.cv, judge: {cls: av.cls, text: av.text}, atk: {sum: av.sum, cv: av.cv, part: av.part || null, precise: av.precise, cvMod, pick: n > 2 ? 'atk' : null}, gmOnly: false, flow});
    };
    Table.guardedRoll(who, async ()=>{ this.closeComposer(); const notes = pre(); await run();
      // ไฟล์แกน: Hidden และ Invisible สิ้นสุดเมื่อตัวละครทำการโจมตี (ไม่ว่าผู้เล่นจะติ๊กเหตุของ Advantage ไว้หรือไม่) · หมากที่ GM กดซ่อนไว้ถูกเปิดเผยเมื่อนับเป็นการโจมตีจากการซ่อนตัว
      for (const idc of ['Hidden', 'Invisible']){ const hc = (a.conds || []).find(x=>x.id === idc); if (hc) removeCond(a, r, hc, 'ลงมือโจมตีแล้ว'); }
      if (reasons.some(x=>x.on && x.key === 'ahid') && a.hidden){ a.hidden = false; Table.post({kind: 'sys', who: '', text: `${a.name} ปรากฏตัวที่ (${a.x},${a.y}) หลังลงมือโจมตีจากการซ่อนตัว`}); }
      Table.save(); for (const nt of notes) toast(nt);
    }, label);
  },

  /* ---------- 5. ฝ่ายรับ ---------- */
  isAttack(m){ return !!(m && m.kind === 'roll' && m.flow && m.flow.type === 'attack' && m.roll && m.flow.t && m.flow.a); },
  resolved(m){ return Table.chat.some(x=>x.kind === 'clash' && x.of === m.id); },
  canRespond(m){ const t = this.tok(m.flow.t.id); return !!t && this.controls(t); },
  ownerHere(t){ return !!(t && t.ownerId && !t.gmRun && (Table.peers || []).some(p=>p && p.who === t.ownerId)); },
  /* ฉันเป็นคนแรกที่ควรตอบไหม: เจ้าของหมากตอบเอง · GM ตอบแทนเมื่อเป็น NPC หรือเจ้าของไม่อยู่ในห้อง */
  primary(m){ const t = this.tok(m.flow.t.id); if (!t) return false; if (Table.localMode) return true; if (ownsTok(t)) return true; return Table.isGM() && !this.ownerHere(t); },
  pending(){ const now = Date.now(); return Table.chat.filter(m=>this.isAttack(m) && now - (m.ts || 0) < CB_PENDING_MS && !this.resolved(m)).sort((x, y)=>(x.ts || 0) - (y.ts || 0)); },
  /* เรียกทุกครั้งที่แชตของห้องเปลี่ยน: เล่นเอฟเฟกต์ของข้อความใหม่ และเด้งหน้าต่างป้องกันให้คนที่ต้องตอบ */
  onChat(){
    if (!Table.room) return; const now = Date.now(); const gm = Table.isGM(); const first = !this.ready; this.ready = true;
    const fresh = Table.chat.filter(m=>m && m.id && !this.seen.has(m.id)).sort((x, y)=>(x.ts || 0) - (y.ts || 0));
    for (const m of fresh){ this.seen.add(m.id); if (first || now - (m.ts || 0) > 20000) continue; if (m.gmOnly && !gm && m.authorId !== Store.me) continue;
      if (m.kind === 'clash') DiceShow.enqueue(m);
      else if (m.kind === 'skill' && typeof SkillUse !== 'undefined') SkillUse.onMessage(m);
      else if (m.fx) setTimeout(()=>Fx.play(m.fx), m.kind === 'roll' ? ROLL_SHOW_MS : 0); }
    if (this.prompting){ const pm = Table.chat.find(x=>x.id === this.prompting); if (!pm || this.resolved(pm)){ this.prompting = null; modal(null); toast('การโจมตีนี้มีคนตัดสินผลไปแล้ว'); } }
    this.checkPrompts();
  },
  checkPrompts(){
    if (this.prompting || this.comp) return; const now = Date.now();
    const m = this.pending().find(x=>!this.snooze.has(x.id) && this.canRespond(x) && this.primary(x)); if (!m || this.timers[m.id]) return;
    const wait = Math.max(150, ROLL_SHOW_MS + 250 - (now - (m.ts || 0)));
    const open = ()=>{ delete this.timers[m.id]; if (this.prompting || this.comp || this.resolved(m) || !Table.room) return;
      if (DiceShow.cur || Table.rolling){ this.timers[m.id] = setTimeout(open, 500); return; } // รอให้ป๊อปอัปเต๋าบนจอจบก่อน
      const lone = this.tok(m.flow.t.id); if (lone && lone.kind === 'asset'){ this.autoHit(m); return; } this.openDefense(m); };
    this.timers[m.id] = setTimeout(open, wait);
  },
  /* สิ่งของไม่ป้องกัน: ตัดสินเป็นโดนทันที */
  autoHit(m){ Table.guardedRoll(m.flow.t.name, ()=>{ this.resolve(m, {kind: 'none', success: false, text: 'สิ่งของไม่ป้องกัน'}, {}); }, 'รับการโจมตี'); },
  defReasons(t, f, st, E, cv){
    const parry = [], evade = []; const unb = this.has(t, 'Unbalanced');
    if (unb){ parry.push({key: 'unbal', kind: 'dis', label: 'Unbalanced: การป้องกันทุกแบบติด Disadvantage'}); evade.push({key: 'unbal', kind: 'dis', label: 'Unbalanced: การป้องกันทุกแบบติด Disadvantage'}); }
    if (f.mode === 'melee' && !(E && E.evadeMeleeOk)) evade.push({key: 'evm', kind: 'dis', label: 'Evade การโจมตีระยะประชิด: Disadvantage'});
    if (f.mode !== 'melee' && st.meleeLv < 3) parry.push({key: 'prr', kind: 'dis', label: 'Parry การโจมตีระยะไกล: ต้องได้ Perfect Parry'});
    const gbCv = !!(f.w && !f.w.gb && f.w.gbAbove != null && cv != null && cv > cbInt(f.w.gbAbove));
    if (f.w && (f.w.gb || gbCv)) parry.push({key: 'gb', kind: 'gb', label: gbCv ? `Guard Break (อาวุธนี้ได้คุณสมบัตินี้เมื่อโจมตีด้วย CV สูงกว่า ${cbInt(f.w.gbAbove)} ครั้งนี้ CV ${cv}): Parry แบบ Advantage ไม่ได้ และไม่ได้ Parry Dice` : 'Guard Break: Parry แบบ Advantage ไม่ได้ และไม่ได้ Parry Dice'});
    return {parry, evade};
  },
  /* Reaction ของฝ่ายรับที่ระบบรู้จักและเข้าเงื่อนไขของการโจมตีครั้งนี้ (CB_REACT) */
  reactList(t, m, a){
    const c = this.charOf(t); let names = []; try { names = c && !(c.shareMode === 'min' && !Store.isMine(c)) ? allSkills(c) : []; } catch(e){ names = []; }
    const f = m.flow; const d = this.derived(c); const mod = (s)=>{ const v = (typeof suStatMod === 'function') ? suStatMod(s, c, d, t) : null; return v == null ? 0 : v; };
    const x = {t, a, f, m, mode: f.mode, dtype: f.w.dtype, physical: !!f.w.physical, adjacent: !!(a && cellDist(a, t) <= 1), mod}; const out = [];
    for (const n of names){ const sk = SKILL_BY_NAME[n]; if (!sk || !Object.prototype.hasOwnProperty.call(CB_REACT, sk.nameEn)) continue; const spec = CB_REACT[sk.nameEn]; if (spec.fit && !spec.fit(x)) continue; out.push({sk, spec, x, text: spec.text(x)}); }
    return out;
  },
  /* v1.29 หน้าต่างป้องกัน: Parry Dice ตายตัวตามอุปกรณ์และความสามารถ (GM ให้เพิ่มได้) · Parry ดูกลุ่มจากเลขที่ผู้โจมตีทอยได้แม้ถูกเล็ง
   * Reaction ที่เข้าเงื่อนไขขึ้นเป็นปุ่มกดครั้งเดียว เป้าหมายคือผู้โจมตีเสมอ · Trait ของฝ่ายรับเป็นตัวเลือกให้ติ๊ก */
  openDefense(m, o){
    const r = Table.room; if (!r || !this.isAttack(m)) return; if (this.resolved(m)){ toast('การโจมตีนี้ตัดสินผลไปแล้ว'); return; }
    const f = m.flow; const t = this.tok(f.t.id); if (!t){ toast('หมากเป้าหมายไม่อยู่บนบอร์ดแล้ว'); return; } if (!this.canRespond(m)){ toast('การป้องกันเป็นของเจ้าของหมากหรือ GM'); return; }
    const a = this.tok(f.a.id); const atk = m.atk || {}; const sum = m.roll.sum; const cv = atk.cv != null ? atk.cv : sum; const precise = !!atk.precise; const part = atk.part || hitPart(sum) || 'torso';
    const grp = hitPart(sum) || part; // กลุ่มเลขของ Parry มาจากเลขที่ผู้โจมตีทอยได้เสมอ (Non เคาะ 16 พ.ย. 2026)
    const base = this.defStats(t); const gm = Table.isGM() || Table.localMode; const enc = Act.on(r); const c = this.charOf(t);
    const pref = (this.isNpc(t) && ['parry','evade','both','none'].includes(t.defend)) ? t.defend : ''; // วิธีป้องกันที่สแตตบล็อกของ NPC ระบุ
    const st = {meleeLv: base.meleeLv, off: {}, feat: {}, advX: false, disX: false, weak: false, resist: 0, force: false, view: (o && o.view === 'skill') ? 'skill' : 'main', skill: null, pdGm: 0, flex: false, pre: [], rx: {reflex: 0, armor: 0, tempHp: 0, reduce: 0, immune: '', absorb: false, sanity: '', used: {}}};
    const box = h('div',{class:'defbox'}); const own = (o, k)=>Object.prototype.hasOwnProperty.call(o, k);
    const blocked = ()=> (this.has(t, 'Stunned') ? 'Stunned' : this.has(t, 'Incapacitated') ? 'Incapacitated' : null);
    const calc = ()=>{
      const fx = {r, t, a, f, mode: f.mode, dtype: f.w.dtype, physical: !!f.w.physical, allies: this.alliesNear(r, t).length}; const fb = Feats.build(t, FEAT_DEF, fx, st.feat);
      for (const al of this.alliesNear(r, t)) for (const ff of Feats.of(al).list){ if (!own(FEAT_DEF_ALLY, ff.id)) continue; let got = []; try { got = FEAT_DEF_ALLY[ff.id](fx, al) || []; } catch(e){ got = []; }
        for (const o of got){ const id = `${al.id}:${ff.id}:${o.key}`; fb.opts.push({id, f: ff, o, eff: o.eff || {}, label: `${ff.th}: ${o.label}`, on: own(st.feat, id) ? !!st.feat[id] : !!o.on, off: false, group: null, only: null}); } }
      const E = cbMergeEff(fb.opts.filter(p=>p.on)); const blaze = (enc && t.ablaze === r.enc.round) ? 2 : 0;
      return {fb, E, reflex: base.reflex + E.reflex + st.rx.reflex, pd: Math.max(0, base.pd + E.pd + Math.max(0, cbInt(t.pdx)) + st.pdGm), blaze}; };
    const plan = (kind, K)=>{ K = K || calc(); const rs = this.defReasons(t, f, st, K.E, cv)[kind].map(x=>Object.assign(x, {on: !st.off[kind + x.key]})); const gb = rs.some(x=>x.kind === 'gb' && x.on); const dis = rs.some(x=>x.kind === 'dis' && x.on) || st.disX; const adv = (st.advX || K.E.adv) && !(kind === 'parry' && gb);
      const mode = adv && dis ? 'normal' : adv ? 'adv' : dis ? 'dis' : 'normal'; const pd = (kind === 'parry' && !gb) ? K.pd : 0;
      const n = kind === 'parry' ? (mode === 'dis' ? 2 : parryDiceCount(pd, mode === 'adv')) : (mode === 'normal' ? 2 : 3);
      return {rs, gb, mode, pd, n, reflex: K.reflex}; };
    const used = !!(enc && t.pd && t.pd.round === r.enc.round);
    const lead = (kind)=> !pref || pref === 'both' || pref === kind; // ปุ่มที่ตรงกับสแตตบล็อกเป็นปุ่มเด่น
    const draw = ()=>{
      clear(box); const redraw = draw; const K = calc();
      box.append(...cbKids(h('h3',{class:'def-title',title:'ลากหัวข้อนี้เพื่อย้ายหน้าต่าง',text:`🛡 ${f.a.name} โจมตี ${t.name}`})));
      box.append(...cbKids(h('div',{class:'def-atk'}, h('div',{class:'row',style:'gap:8px;justify-content:center'}, renderDice({dice: m.roll.dice || [], keptIdx: m.roll.keptIdx || []}), h('b',{class:'num',text:`เต๋า ${sum}${cv !== sum ? ' → CV ' + cv : ''}`}), tag(partLabel(part) + (precise ? ' (เล็ง)' : ''), 'neg'), (m.roll.double || f.perfect) ? tag('Perfect Strike', 'prop') : null),
        h('div',{class:'dim',style:'font-size:12.5px;margin-top:4px',text:`${f.w.name} · ${f.mode === 'melee' ? 'ประชิด' : f.mode === 'thrown' ? 'ขว้าง' : 'ยิง'} ระยะ ${f.m} ม. · ถ้าโดน ${f.w.dmg}${f.w.stat ? ' ' + signed(f.w.stat) + ((m.roll.double || f.perfect) ? '×' + (cbInt(f.w.mul, 2)) : '') : ''}${f.w.bonus ? ' ' + signed(f.w.bonus) : ''} ${f.w.dtype}${f.w.ap ? ' · Armor Penetrate' : ''}${f.w.gb ? ' · Guard Break' : ''}${f.w.nonLethal ? ' · Non-Lethal' : ''}`}))));
      if (st.view === 'skill'){ this.defSkillView(box, m, t, st, redraw, plan, go, a); return; }
      const why = blocked(); const lock = !!why && !st.force;
      if (why) box.append(...cbKids(h('div',{class:'atkc-note bad',text:`${t.name} ติด ${why} จึงป้องกันไม่ได้`}), gm ? cbCheck('ให้ป้องกันได้ (GM ตัดสิน)', st.force, (v)=>{ st.force = v; redraw(); }, {class:'fld chk def-force'}) : null));
      if (used) box.append(...cbKids(h('div',{class:'atkc-note warn',text:'รอบนี้ใช้ Perfect Defense ไปแล้ว ทอยได้เลขเท่าผลโจมตีอีกจะไม่นับเป็น Perfect'})));
      if (base.npc) box.append(...cbKids(h('div',{class:'dim def-npc',style:'font-size:12.5px;text-align:center;margin-top:4px',text:`${t.name}: Reflex ${signed(K.reflex)} · Parry Dice ${K.pd} (คิดจากค่าพลังดัดแปลงและของที่สวม)` + (pref ? ` · สแตตบล็อกระบุ ${pref === 'parry' ? 'Parry' : pref === 'evade' ? 'Evade' : pref === 'both' ? 'Parry หรือ Evade' : 'ไม่ป้องกัน'}` : '') + (t.defendNote ? ` (${String(t.defendNote).slice(0, 120)})` : '')})));
      // Reaction ที่ระบบรู้จักและใช้กับการโจมตีนี้ได้: กดครั้งเดียว เป้าหมายคือผู้โจมตี ไม่ต้องเลือกเป้า
      const rxs = lock ? [] : this.reactList(t, m, a);
      if (rxs.length){ const rb = h('div',{class:'def-rx'}, h('div',{class:'kicker',text:'Reaction ที่ใช้กับการโจมตีนี้ได้ (เป้าหมายคือผู้โจมตี)'}));
        for (const x of rxs){ const id = x.sk.nameEn; const lim = suLimit(x.sk); const spent = !st.rx.used[id] && !!lim && typeof SkillUse !== 'undefined' && SkillUse.limitUsed(t, c, {limit: lim, sk: x.sk}); // ทักษะที่จำกัดจำนวนครั้งและใช้ครบแล้ว กดไม่ได้
          const done = !!st.rx.used[id] || spent; const armed = x.spec.arm === 'flex' && st.flex;
          const btn = x.spec.arm === 'flex' ? h('button',{class:'small def-rxuse' + (armed ? ' primary' : ''),dataset:{sk:id},onclick:()=>{ st.flex = !st.flex; redraw(); },text: armed ? 'เตรียมไว้แล้ว' : 'เตรียมใช้'}) : h('button',{class:'small primary def-rxuse',dataset:{sk:id},disabled: done,onclick:()=>this.useReact(m, t, a, st, x, {show: st.show, go, plan}),text: spent ? 'ใช้ครบแล้ว' : done ? 'ใช้แล้ว' : 'ใช้',title: spent ? `ใช้ได้ 1 ครั้ง${SkillUse.limitText(lim)} และใช้ไปแล้ว` : null});
          rb.append(...cbKids(h('div',{class:'def-sk'}, h('div',null, h('b',{text:'↺ ' + skTh(x.sk)}), x.sk.cost && !/^none$/i.test(x.sk.cost) ? h('span',{class:'skcost',text:' ' + x.sk.cost}) : h('span',{class:'dim',style:'font-size:11.5px',text:' ไม่เสียค่าร่าย'}), h('div',{class:'desc',style:'font-size:12px',text:x.text})), btn))); }
        box.append(...cbKids(rb)); }
      if (st.pre.length) box.append(...cbKids(h('div',{class:'def-rxnote',text:st.pre.join(' · ')})));
      if (K.blaze) box.append(...cbKids(h('div',{class:'def-rxnote',text:'เปลวเพลิงสัมบูรณ์ยังมีผลในรอบนี้: All Damage Reduction +2'})));
      const pp = plan('parry', K), ev = plan('evade', K);
      const nums = HIT_DEFEND[grp] || [];
      const aimNote = (precise && grp !== part) ? ` (ผู้โจมตีเล็ง${partLabel(part)} แต่ Parry ดูจากเลขที่ทอยได้ ${sum} = กลุ่ม${partLabel(grp)})` : '';
      const pText = (pp.mode === 'dis' ? `ทอย 2d6 ต้องได้ ${sum} พอดี (Perfect Parry)` : `ทอย ${pp.n}d6${pp.n > 2 ? ' เลือก 2 ลูก' : ''} กันได้เมื่อผลรวมเป็น ${nums.join(' หรือ ')}`) + aimNote;
      const eText = `ทอย ${ev.n}d6${ev.mode === 'dis' ? ' ใช้ 2 ลูกต่ำสุด' : ev.mode === 'adv' ? ' เลือก 2 ลูก' : ''} บวก Reflex ${signed(K.reflex)} ต้องถึง ${cv}`;
      const featBox = (p)=>{ const el = cbCheck(p.label, p.on, (v)=>{ st.feat[p.id] = v; redraw(); }, {class:'fld chk rs-feat' + (p.off ? ' off' : ''),dataset:{feat:p.id},title:String(p.f.text || '').slice(0, 500)}); if (p.off) el.querySelector('input').disabled = true; return el; };
      const col = (kind, pl, title, text, extra)=>h('div',{class:'def-col'}, h('button',{class:(lead(kind) ? 'primary ' : '') + 'def-' + kind,disabled: lock,onclick:()=>go(kind),text:title}), h('div',{class:'dim def-how',text:text}), extra || null, pl.rs.map(x=>cbCheck(x.label, x.on, (v)=>{ st.off[kind + x.key] = !v; redraw(); }, {class:'fld chk rs-' + x.kind})), K.fb.opts.filter(p=>p.only === kind).map(featBox));
      // Parry Dice ตายตัว: อุปกรณ์และความสามารถ บวกที่ GM ให้เพิ่ม (ผู้เล่นไม่ได้เลือกจำนวนเอง)
      const pdBits = [`อุปกรณ์และความสามารถ ${base.pd + K.E.pd}`]; if (cbInt(t.pdx) > 0) pdBits.push(`GM ให้ไว้ที่หมาก ${cbInt(t.pdx)}`); if (st.pdGm) pdBits.push(`GM ให้ครั้งนี้ ${st.pdGm}`);
      const pdRow = h('div',{class:'def-pdrow'}, h('span',{class:'dim',text:`Parry Dice ${pp.gb ? '0 (Guard Break)' : K.pd + ' ลูก'}${(cbInt(t.pdx) > 0 || st.pdGm) ? ' = ' + pdBits.join(' + ') : ''}`}),
        gm ? h('span',{class:'row def-pdgm',style:'gap:4px;display:inline-flex',title:'GM ให้ Parry Dice เพิ่มสำหรับการป้องกันครั้งนี้'}, h('button',{class:'small def-pdminus',disabled: st.pdGm <= 0,onclick:()=>{ st.pdGm = Math.max(0, st.pdGm - 1); redraw(); },text:'−'}), h('span',{class:'dim',text:'GM ให้เพิ่ม'}), h('button',{class:'small def-pdplus',disabled: st.pdGm >= 3,onclick:()=>{ st.pdGm = Math.min(3, st.pdGm + 1); redraw(); },text:'+'})) : null);
      box.append(...cbKids(h('div',{class:'def-cols'}, col('parry', pp, `🛡 Parry ${pp.n}d6`, pText, pdRow), col('evade', ev, `💨 Evade ${ev.n}d6${K.reflex ? ' ' + signed(K.reflex) : ''}`, eText, null))));
      const shared = K.fb.opts.filter(p=>!p.only); if (shared.length) box.append(...cbKids(h('div',{class:'def-feats'}, shared.map(featBox))));
      const more = Feats.remindBox(t, K.fb.list, FT_DEF_RX, FEAT_DEF, 'ความสามารถอื่นของตัวละครที่เกี่ยวกับการป้องกัน ระบบไม่ได้คิดให้'); if (more) box.append(...cbKids(more));
      box.append(...cbKids(h('div',{class:'row',style:'gap:10px;justify-content:center;margin-top:6px'}, cbCheck('Advantage (สกิลหรือสถานการณ์)', st.advX, (v)=>{ st.advX = v; redraw(); }, {class:'fld chk def-advx'}), cbCheck('Disadvantage เพิ่ม', st.disX, (v)=>{ st.disX = v; redraw(); }, {class:'fld chk def-disx'}))));
      const adj = h('details',{class:'def-adj'}, h('summary',{text:'ตัวปรับความเสียหายของฝ่ายรับ (แพ้ทาง ความต้านทาน)'}), h('div',{class:'row',style:'gap:10px;margin-top:6px'}, cbCheck('แพ้ทาง ความเสียหาย ×2', st.weak, (v)=>{ st.weak = v; }, {class:'fld chk def-weak'}), h('label',{class:'fld'}, h('span',{text:'ลดเพิ่ม (Resistance หรือเกราะที่จดเอง)'}), cbNum(st.resist || '', (v)=>{ st.resist = Math.max(0, v || 0); }, {class:'def-resist',style:'width:58px',placeholder:'0',min:0}))),
        h('p',{class:'dim',style:'font-size:11.5px;margin:6px 0 0',text:'เกราะของส่วนที่โดนระบบหักให้เอง: โดนชนิดในวงเล็บหักเกราะหลักบวกเกราะรอง ชนิดอื่นหักเกราะหลัก ความเสียหายเวทหักเกราะหลักบวก Sorceries Resistance ของส่วนนั้น'}));
      if (st.weak || st.resist) adj.open = true; box.append(...cbKids(adj));
      box.append(...cbKids(h('div',{class:'row',style:'gap:8px;justify-content:center;margin-top:10px'}, h('button',{class:'def-skill',disabled: lock,title:'Reaction อื่น ทักษะอื่น หรือความสามารถของ NPC ที่ระบบยังไม่รู้จักผล',onclick:()=>{ st.view = 'skill'; redraw(); },text:'✨ ทักษะอื่น'}), h('button',{class:(pref === 'none' ? 'primary' : 'ghost') + ' def-none',onclick:()=>go('none'),text:'รับการโจมตี (ไม่ป้องกัน)'}), h('button',{class:'small ghost def-later',title:'ปิดหน้าต่างนี้ไว้ก่อน เปิดใหม่ได้จากปุ่มในแชต',onclick:()=>{ this.snooze.add(m.id); this.prompting = null; modal(null); setTimeout(()=>this.checkPrompts(), 120); },text:'ไว้ก่อน'}))));
    };
    /* ตัวเลือกที่ส่งให้ขั้นตัดสินผล: ตัวปรับความเสียหาย ผลของ Reaction และ Trait ที่ติ๊กไว้ */
    const optFor = (kind, K)=>{ const on = K.fb.opts.filter(p=>p.on && (!p.only || p.only === kind)); const onOk = on.filter(p=>p.o.use && p.eff.parryDmg); // จำนวนครั้งของผลที่เกิดเมื่อป้องกันสำเร็จ หักตอนผลนั้นเกิดจริง
      const now = on.filter(p=>p.o.use && !p.eff.tempHp && !p.eff.reduce && !p.eff.parryDmg), onHit = on.filter(p=>p.o.use && (p.eff.tempHp || p.eff.reduce)); const Ek = cbMergeEff(on);
      const adjL = []; if (st.advX) adjL.push('Advantage'); if (st.disX) adjL.push('Disadvantage'); if (st.weak) adjL.push('แพ้ทาง ×2'); if (st.resist) adjL.push(`ลดเพิ่ม ${st.resist}`); if (st.pdGm) adjL.push(`GM ให้ Parry Dice +${st.pdGm}`); if (st.force) adjL.push('GM ให้ป้องกันได้');
      return {weak: st.weak, resist: st.resist + K.E.reduce + st.rx.reduce + K.blaze, min1: K.E.min1, armorAdd: K.E.armor + st.rx.armor, tempHp: st.rx.tempHp, tempKeep: K.E.tempHp, immune: st.rx.immune, absorb: st.rx.absorb, sanity: st.rx.sanity, skill: st.skill, flex: !!st.flex && kind === 'evade', evadeBy5: K.E.evadeBy5,
        feats: on.map(p=>String(p.label).slice(0, 180)).slice(0, 8), adj: adjL, pre: st.pre.slice(0, 6), flags: {boto: K.E.set.some(x=>x.k === 'boto'), iflame: K.E.set.some(x=>x.k === 'iflame'), rhythmUp: Ek.set.some(x=>x.k === 'rhythmUp'), mwater: Ek.set.some(x=>x.k === 'mwater')},
        okTemp: Ek.okTemp, okNotes: Ek.notes.slice(0, 3), parryDmg: Ek.parryDmg,
        spendNow: ()=>{ for (const p of now) Feats.spend(t, K.fb.c, p.f, p.o); }, spendHit: ()=>{ for (const p of onHit) Feats.spend(t, K.fb.c, p.f, p.o); }, spendOk: ()=>{ for (const p of onOk) Feats.spend(t, K.fb.c, p.f, p.o); }}; };
    const go = (kind, forced)=>{
      if (this.resolved(m)){ this.prompting = null; modal(null); toast('การโจมตีนี้ตัดสินผลไปแล้ว'); return; }
      const K = calc(); const opt = optFor(kind, K);
      const label = kind === 'parry' ? 'Parry' : kind === 'evade' ? 'Evade' : 'รับการโจมตี';
      this.prompting = null; modal(null);
      Table.guardedRoll(t.name, async ()=>{
        if (this.resolved(m)){ toast('มีคนตัดสินการโจมตีนี้ไปก่อนแล้ว'); return; }
        if (forced && forced.def){ opt.spendNow(); this.resolve(m, forced.def, opt); return; }
        if (kind === 'none'){ this.resolve(m, {kind: 'none', success: false, text: 'ไม่ป้องกัน', skill: st.skill}, opt); return; }
        if (kind === 'block'){ opt.spendNow(); this.resolve(m, {kind: 'skill', success: true, text: `กันด้วย ${st.skill || 'ทักษะ'}`, skill: st.skill}, opt); return; }
        const pl = plan(kind, K); let rr, j, total, mod = 0, lab; opt.spendNow();
        if (kind === 'parry'){
          const pdis = pl.mode === 'dis';
          rr = pl.n > 2 ? await rollChoose(pl.n, pl.mode, `Parry: ทอย ${pl.n}d6 เลือก 2 ลูก`, {kind: 'parry', dc: sum, cv, loc: precise ? part : null}) : roll2d6('normal');
          total = rr.sum; j = judgeDefense(total, sum, 'parry', {sum: rr.sum, dis: pdis, cv, loc: precise ? part : null}); lab = pdis ? 'Parry (Disadvantage)' : 'Parry';
          if (used && rr.sum === sum) j = pdis ? {cls: 'res-fail', text: `Parry ไม่สำเร็จ (รอบนี้ใช้ Perfect Defense ไปแล้ว) โดน${partLabel(part)}`} : {cls: 'res-full', text: `Parry สำเร็จ (${rr.sum} เท่าผลโจมตี แต่รอบนี้ใช้ Perfect Defense ไปแล้ว)`};
        } else {
          mod = pl.reflex; rr = pl.mode === 'adv' ? await rollChoose(3, 'adv', 'Evade (Advantage): ทอย 3d6 เลือก 2 ลูก', {kind: 'evade', dc: sum, mod, cv, loc: precise ? part : null}) : roll2d6(pl.mode === 'dis' ? 'dis' : 'normal');
          total = rr.sum + mod; j = judgeDefense(total, sum, 'evade', {sum: rr.sum, cv, loc: precise ? part : null}); lab = pl.mode === 'dis' ? 'Evade (Disadvantage)' : pl.mode === 'adv' ? 'Evade (Advantage)' : 'Evade';
          if (used && rr.sum === sum) j = total >= cv ? {cls: 'res-full', text: `Evade สำเร็จ (${total} ถึง ${cv})`} : {cls: 'res-fail', text: `Evade ไม่สำเร็จ (${total} ต่ำกว่า ${cv} และรอบนี้ใช้ Perfect Defense ไปแล้ว) โดน${partLabel(part)}`};
        }
        const ok = /res-(full|crit)/.test(j.cls || ''); const perfect = j.cls === 'res-crit';
        this.resolve(m, {kind, success: ok, perfect, roll: cbRollOf(rr), mode: pl.mode, mod, total, text: j.text, cls: j.cls, label: lab, pd: pl.pd, skill: st.skill}, opt);
      }, label);
    };
    /* แสดงกรอบนี้ในหน้าต่าง: ปิดด้วยปุ่ม "ไว้ก่อน" เท่านั้น กันกดพลาดนอกกรอบ · เรียกซ้ำได้หลังหน้าต่างใช้ทักษะปิด · ลากหัวข้อเพื่อย้ายได้ */
    const show = ()=>{ if (this.resolved(m)){ this.prompting = null; return; } this.prompting = m.id; draw(); modal(box); const mEl = $('#modal'); if (!mEl) return; mEl.onclick = ()=>{}; const closeRow = mEl.querySelector('.box > .row:last-child'); if (closeRow && closeRow !== box) closeRow.remove(); cbDragBox(mEl.querySelector('.box'), '.def-title', this); };
    st.show = show; show();
  },
  /* ใช้ Reaction ที่ระบบรู้จัก: หักค่าร่ายและประกาศทันที แล้วใส่ผลให้การป้องกันครั้งนี้ */
  useReact(m, t, a, st, x, ui){
    const r = Table.room; if (!r || this.resolved(m)) return; const sk = x.sk; const spec = x.spec; const label = skLabel(sk);
    if (typeof SkillUse === 'undefined' || !SkillUse.instant(t, sk, {react: m.id, targets: a ? [a.id] : []})) return;
    st.rx.used[sk.nameEn] = true; st.skill = label;
    const cx = x.x; // บริบทของการโจมตีครั้งนี้ (ค่าพลังดัดแปลงของฝ่ายรับ ประเภทความเสียหาย ฯลฯ) ที่ reactList เตรียมไว้
    if (spec.apply){ const note = spec.apply(cx, st.rx, r); if (note) st.pre.push(`${skTh(sk)}: ${note}`); Table.save(); ui.show(); return; }
    if (spec.run === 'vault'){ // AGI ของฝ่ายรับ ปะทะ Sight ของผู้โจมตี ระบบทอยให้ทั้งสองฝ่ายในคราวเดียว ชนะหรือเท่ากัน = Evade ผ่าน (Clash: ผู้ท้าชนะเมื่อเท่ากัน)
      const pl = ui.plan('evade'); const dmod = cx.mod('AGI'); const amod = a ? this.atkStats(a).sight : 0; const mode = pl.rs.some(q=>q.key === 'unbal' && q.on) ? 'dis' : 'normal';
      const r1 = roll2d6(mode), r2 = roll2d6('normal'); const t1 = r1.sum + dmod, t2 = r2.sum + amod; const win = t1 >= t2;
      const text = `${skTh(sk)}: AGI ${r1.sum}${dmod ? ' ' + signed(dmod) : ''} = ${t1} ปะทะ Sight ของ ${m.flow.a.name} ${r2.sum}${amod ? ' ' + signed(amod) : ''} = ${t2} ${win ? (t1 === t2 ? 'เท่ากัน ผู้ท้าชนะ นับว่า Evade ผ่าน' : 'ชนะ นับว่า Evade ผ่าน') : 'แพ้ การโจมตีเข้าเป้า'}`;
      ui.go(win ? 'block' : 'none', {def: {kind: 'skill', asEvade: true, success: win, skill: label, roll: cbRollOf(r1), mode, mod: dmod, total: t1, label: 'AGI', text, cls: win ? 'res-full' : 'res-fail', foe: {roll: cbRollOf(r2), mod: amod, total: t2, label: 'Sight'},
        extra: win ? [`เคลื่อนที่ข้ามหัว ${m.flow.a.name} ได้ในระยะ 3 เมตร และได้สถานะ [ลอยตัว] จนจบเทิร์น (ย้ายหมากเอง)`] : []}}); return; }
    if (spec.run === 'umbral'){ // ผู้โจมตีทอย AGI Saving Throw ระบบทอยให้ ไม่ผ่าน = การโจมตีพลาดและติด Rooted จนถึงเทิร์นถัดไปของผู้ใช้
      const dc = 8 + cx.mod('Cautious'); const ca = a ? this.charOf(a) : null; const amod0 = a ? suStatMod('AGI', ca, this.derived(ca), a) : 0; const amod = amod0 == null ? 0 : amod0;
      const rr = roll2d6('normal'); const tot = rr.sum + amod; const j = judge(tot, rr, dc); const ok = /res-(full|crit)/.test(j.cls || '') && !/Failure|ล้มเหลว/.test(j.text || '');
      const text = `${skTh(sk)}: ${m.flow.a.name} ทอย AGI Saving Throw ${rr.sum}${amod ? ' ' + signed(amod) : ''} = ${tot} ต่อ DC ${dc} ${ok ? 'ผ่าน การโจมตีดำเนินต่อ' : 'ไม่ผ่าน การโจมตีพลาดเป้าและติด Rooted'}`;
      if (ok){ st.pre.push(text); ui.show(); return; }
      ui.go('block', {def: {kind: 'skill', success: true, skill: label, text, cls: 'res-full', foe: {roll: cbRollOf(rr), mod: amod, total: tot, label: 'AGI ST'}, rootFoe: true}}); return; }
    ui.show();
  },
  /* ทักษะอื่นของฝ่ายรับ (Reaction ที่ระบบยังไม่รู้จักผล ทักษะทั่วไป ความสามารถของ NPC): จ่ายค่าร่าย ประกาศในแชต เป้าหมายคือผู้โจมตี แล้วบอกว่าทักษะมีผลกับการโจมตีนี้อย่างไร */
  defSkillView(box, m, t, st, redraw, plan, go, a){
    const c = this.charOf(t); let names = []; try { names = c && !(c.shareMode === 'min' && !Store.isMine(c)) ? allSkills(c) : []; } catch(e){ names = []; }
    const sks = names.map(n=>SKILL_BY_NAME[n]).filter(Boolean); const known = (sk)=>Object.prototype.hasOwnProperty.call(CB_REACT, sk.nameEn) || Object.prototype.hasOwnProperty.call(CB_REACT_POST, sk.nameEn); // Reaction ที่ระบบรู้จักอยู่เป็นปุ่มในหน้าหลัก ส่วน Reaction ที่ใช้หลังป้องกันสำเร็จ (ประกายแสง ไอเหมันต์ ม้วนตัวหลบ) ขึ้นเป็นปุ่มในการ์ดผล
    const react = sks.filter(sk=>/Reaction/i.test(sk.type || '') && !known(sk)); const rest = sks.filter(sk=>!/Reaction|Passive|กระบวนท่า/i.test(sk.type || ''));
    box.append(...cbKids(h('p',{class:'desc',style:'margin:8px 0',text: st.skill ? `ใช้ ${st.skill} แล้ว เลือกว่าทักษะนี้มีผลกับการโจมตีอย่างไร` : 'เลือกทักษะที่จะใช้ตอบโต้การโจมตีนี้ ระบบหักค่าร่ายและประกาศในแชตให้ เป้าหมายคือผู้โจมตีโดยไม่ต้องเลือก แล้วให้คุณบอกผลของมันต่อการโจมตี'})));
    if (!st.skill){
      const pickRow = (sk)=>h('div',{class:'def-sk'}, h('div',null, h('b',{text:skLabel(sk)}), h('span',{class:'dim',style:'font-size:11.5px',text:` ${(sk.type || '').slice(0, 40)}${sk.cost ? ' · ' + sk.cost : ''}`}), h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect || ''))), h('button',{class:'small primary def-usesk',dataset:{sk:sk.nameEn},onclick:()=>{ const done = ()=>{ st.skill = skLabel(sk); st.show(); }; if (typeof SkillUse !== 'undefined') SkillUse.quick(t, sk, {react: m.id, targets: a ? [a.id] : []}, done, ()=>st.show()); else done(); },text:'ใช้'}));
      if (react.length) box.append(...cbKids(h('div',{class:'kicker',text:'ทักษะประเภท Reaction'}), react.map(pickRow)));
      const nre = (this.isNpc(t) && Array.isArray(t.reactions)) ? t.reactions.filter(x=>x && (x.name || x.text)).slice(0, 8) : [];
      if (nre.length) box.append(...cbKids(h('div',{class:'kicker',text:'Reaction ในสแตตบล็อก (ผู้เล่นเห็นเฉพาะชื่อ)'}), nre.map(x=>h('div',{class:'def-sk'}, h('div',null, h('b',{text:String(x.name || 'Reaction').slice(0, 80)}), h('div',{class:'desc',style:'font-size:12px'}, T(String(x.text || '').slice(0, 1200)))), h('button',{class:'small primary def-usenpc',onclick:()=>{ const nm = String(x.name || 'Reaction').slice(0, 60); st.skill = nm; Table.post({kind: 'sys', who: '', text: `${t.name} ใช้ ${nm} ตอบโต้การโจมตีของ ${m.flow.a.name}`}); redraw(); },text:'ใช้'})))));
      if (rest.length) box.append(...cbKids(h('details',{class:'def-more'}, h('summary',{text:`ทักษะอื่นของ ${t.name} (${rest.length})`}), rest.map(pickRow))));
      const free = h('input',{class:'def-skname',placeholder:'หรือพิมพ์ชื่อความสามารถ (NPC หรือความสามารถที่ไม่อยู่ในรายการ)',style:'flex:1;min-width:200px',maxlength:60});
      box.append(...cbKids(h('div',{class:'row',style:'gap:6px;margin-top:8px'}, free, h('button',{class:'small def-usefree',onclick:()=>{ const nm = free.value.trim().slice(0, 60); if (!nm){ toast('พิมพ์ชื่อความสามารถก่อน'); return; } st.skill = nm; Table.post({kind: 'sys', who: '', text: `${t.name} ใช้ ${nm} ตอบโต้การโจมตีของ ${m.flow.a.name}`}); redraw(); },text:'ใช้ชื่อนี้'}))));
      box.append(...cbKids(h('div',{class:'row',style:'justify-content:center;margin-top:10px'}, h('button',{class:'small ghost def-back',onclick:()=>{ st.view = 'main'; redraw(); },text:'← กลับไปเลือก Parry หรือ Evade'}))));
      return;
    }
    box.append(...cbKids(h('div',{class:'row',style:'gap:8px;justify-content:center;flex-wrap:wrap'}, h('button',{class:'primary def-block',onclick:()=>go('block'),text:'ทักษะนี้กันการโจมตีได้ทั้งหมด'}), h('button',{class:'def-parry2',onclick:()=>go('parry'),text:`ทอย Parry ต่อ (${plan('parry').n}d6)`}), h('button',{class:'def-evade2',onclick:()=>go('evade'),text:'ทอย Evade ต่อ'}), h('button',{class:'ghost def-none2',onclick:()=>go('none'),text:'ยังโดนตามปกติ'}))));
    box.append(...cbKids(h('div',{class:'row',style:'gap:10px;justify-content:center;margin-top:8px'}, cbCheck('Advantage จากทักษะนี้', st.advX, (v)=>{ st.advX = v; redraw(); }, {class:'fld chk def-advx'}), cbCheck('Disadvantage เพิ่ม', st.disX, (v)=>{ st.disX = v; redraw(); }, {class:'fld chk def-disx'}))));
  },

  /* ---------- 6. ตัดสินผลและลงความเสียหาย ---------- */
  toughInit(t, c, tmax){ const cur = (c && c.current && c.current[toughKeyOf(t)]) || {}; t.tough = t.tough || {}; for (const [k] of DATA.meta.bodyParts) if (t.tough[k] == null){ const v = cur[k] != null ? cur[k] : tmax; if (v != null) t.tough[k] = v; } },
  /* ลด Toughness ของหมาก n หน่วย คืนแถวบันทึก (PC แยกอวัยวะและทอยตารางบาดแผลเมื่อถึง 0 · NPC มีค่าเดียว) */
  toughHit(t, c, tmax, pk, n, why){
    if (!n) return null; const isPc = !!(t.charId && t.kind === 'pc');
    if (isPc){ this.toughInit(t, c, tmax); if (t.tough[pk] == null) return null;
      const before = t.tough[pk]; const after = Math.max(tmax != null ? toughFloor(tmax) : -99, before - n); t.tough[pk] = after; const row = {part: pk, n, before, after, why: why || ''};
      if (after <= 0 && before > 0){ const wr = rollWound(pk); const wrow = wr.row || {name: 'ไม่พบตาราง', text: ''}; const cur = (c && c.current) || {}; const list = Array.isArray(t.wounds) ? t.wounds : woundsOf(cur, bodyOf(t)).map(woundLite);
        t.wounds = [...list, {part: pk, die: wr.die, name: wrow.name, text: wrow.text, at: Date.now()}]; row.wound = {die: wr.die, name: wrow.name, text: String(wrow.text || '').slice(0, 300)}; }
      if (tmax != null && after <= -tmax && before > -tmax) row.lost = (pk === 'head' || pk === 'torso') ? 'mortal' : 'lost';
      return row; }
    if (t.tgh == null && t.tghMax == null) return null;
    const before = t.tgh != null ? t.tgh : t.tghMax; const after = Math.max(0, before - n); t.tgh = after; if (t.tghMax == null) t.tghMax = before;
    return {part: null, n, before, after, why: why || ''};
  },
  toughLine(row){ if (!row) return ''; const where = row.part ? partLabel(row.part) : ''; let s = `Toughness${where ? ' ' + where : ''} ${row.before} → ${row.after}${row.why ? ' (' + row.why + ')' : ''}`;
    if (row.wound) s += ` · บาดแผลฉกรรจ์ ทอย 1d6 ได้ ${row.wound.die}: ${row.wound.name}`; if (row.lost) s += row.lost === 'mortal' ? ' · ติดลบถึงค่าเต็ม ให้ผลเท่า Mortal Wound' : ' · ติดลบถึงค่าเต็ม ส่วนนี้ขาด'; if (!row.part && row.after === 0 && row.before > 0) s += ' · Toughness หมด ให้ GM ตัดสินบาดแผล'; return s; },
  /* Perfect Strike เข้าส่วนที่สวมเกราะ: เกราะเสีย Durability 1 (ไฟล์แกน บทเศรษฐศาสตร์ ข้อ 3) · หลายชั้นหักชิ้นนอกสุดที่ยังไม่พัง
   * แก้ได้เฉพาะชีทของเครื่องที่ตัดสินผล ชีทของคนอื่นและ NPC ได้เป็นข้อความเตือนแทน · เรียกหลังคิดความเสียหายของการโจมตีครั้งนั้นเสร็จแล้ว */
  perfectDur(t, c, part){
    if (typeof durArmorAt !== 'function') return '';
    if (!(t.charId && t.kind === 'pc')){ const worn = this.isNpc(t) && Array.isArray(t.equip) && t.equip.some(e=>e && (ARMOR_SLOT_PARTS[e.slot] || []).includes(part) && parseArmor(e.effect)); return worn ? `Perfect Strike เข้า${partLabel(part)}ที่สวมเกราะ: ตามกฎเกราะชิ้นนั้นเสีย Durability 1 (เว็บยังไม่เก็บ Durability ของ NPC ให้ GM จดเอง)` : ''; }
    if (!c || !c.equip || bodyOf(t) === 'B') return '';
    const live = durArmorAt(c, part).filter(([sl, e])=>!durBroken(e)); if (!live.length) return '';
    const e = live[0][1];
    if (!Store.isMine(c) || !Store.chars.includes(c)) return `Perfect Strike เข้า${partLabel(part)}ที่สวมเกราะ: ${e.name} ควรเสีย Durability 1 ให้เจ้าของกดปุ่ม ⚒ PS ที่กล่อง Toughness ในชีท`;
    const b4 = durState(e); durSet(e, b4.cur - 1); recalcParry(c); recalcArmor(c); Store.upsert(c); const af = durState(e);
    return `Perfect Strike เข้า${partLabel(part)}: ${e.name} เสีย Durability 1 (${af.broken ? 'พัง คุณสมบัติพิเศษหาย ประสิทธิภาพเหลือครึ่ง' : `เหลือ ${af.cur}/${af.max}`})` + (live.length > 1 ? ' · สวมหลายชั้น ระบบหักชิ้นนอกสุด แก้ได้ในถุงย่ามของชีท' : '');
  },
  /* ลงความเสียหายให้หมาก: หักเกราะ (ถ้ารู้ตำแหน่ง) Temporary HP แล้ว HP · ใช้ทั้งผลโจมตี ความเสียหายจากสกิล และความเสียหายจากสภาวะ
   * v1.29: ignoreArmor (เพิกเฉยเกราะ n) · armorAdd (เกราะที่ทักษะหรือพันธมิตรให้เพิ่มทุกส่วน) · min1 · tempHp (Temporary HP เฉพาะครั้งนี้) · adjust(fin, lines) · hpExtra (เต๋าที่เพิ่มเมื่อความเสียหายเข้า HP) */
  damage(t, o){
    const r = Table.room; const c = this.charOf(t); const d = this.derived(c); const isPc = !!(t.charId && t.kind === 'pc'); const lines = [];
    const physical = !!o.physical; const part = o.part || null; let arm = 0, armored = false, armNote = '';
    if (part && !o.noArmor){
      const text = isPc ? (c ? ((bodyOf(t) === 'B' ? c.armor2 : c.armor) || {})[part] : '') : ((this.isNpc(t) && typeof npcArmor === 'function') ? npcArmor(t.equip)[part] : '');
      const all = ((this.isNpc(t) && typeof npcAllArmor === 'function') ? Math.max(0, npcAllArmor(t)) : 0) + Math.max(0, cbInt(o.armorAdd)); // All Armor และโบนัสขนาดของ NPC รวมถึงเกราะที่ทักษะให้เพิ่ม นับเป็นเกราะหลักทุกส่วน
      const cut = cbArmorCut(text, o.dtype, physical, all); armored = cut.any; arm = cut.v;
      const where = partLabel(part); const via = o.viaTorso ? ' (ทักษะที่ไม่มีตำแหน่งที่โดน ใช้เกราะลำตัว)' : '';
      const how = (cut.sec ? ` (เกราะหลัก ${cut.main} บวกเกราะรองกัน${cut.key === 'Sorceries Resistance' ? 'เวท' : ' ' + cut.key} ${cut.sec})` : '') + (cbInt(o.armorAdd) > 0 ? ` (รวมเกราะที่ได้เพิ่มครั้งนี้ ${cbInt(o.armorAdd)})` : '');
      const ign = Math.max(0, Math.min(arm, cbInt(o.ignoreArmor)));
      if (arm && ign){ armNote = `เกราะ${where} ${arm}${how}${via} ถูกเพิกเฉย ${ign} เหลือ ${arm - ign}`; arm -= ign; }
      if (arm && o.ap){ const half = Math.floor(arm / 2); armNote = (armNote ? armNote + ' แล้ว' : `เกราะ${where} ${arm}${how}${via} `) + `เหลือ ${half} จาก Armor Penetrate`; arm = half; }
      else if (arm && !armNote) armNote = `เกราะ${where} ${arm}${how}${via}`; else if (!arm && !armNote && cut.known) armNote = `${where}ไม่มีเกราะ${via}`;
      if (!cut.known) armNote = (armNote ? armNote + ' · ' : '') + `ช่องเกราะของ${partLabel(part)}จดไว้นอกรูปแบบ A/B (ชนิด) ระบบจึงไม่ได้หักส่วนที่จดเอง`; }
    else if (o.noArmor) armNote = 'ความเสียหายนี้ไม่หักเกราะ';
    if (part && !o.noArmor && isPc && !c) armNote = 'ระบบอ่านชีทของเป้าไม่ได้ จึงไม่ได้หักเกราะให้ ใช้ช่อง ลดเพิ่ม แทนได้';
    const raw = Math.max(0, cbInt(o.raw)); const resist = Math.max(0, cbInt(o.resist)); let after = Math.max(0, raw - arm - resist); if (o.min1 && raw > 0 && resist > 0) after = Math.max(1, after);
    let fin = after * (o.weak ? 2 : 1);
    if (arm || resist || o.weak) lines.push(`${armNote || 'ไม่มีเกราะกัน'}${resist ? ` ลดเพิ่ม ${resist}` : ''}: ${raw} เหลือ ${after}${o.weak ? ` · แพ้ทาง ×2 = ${fin}` : ''}`);
    else if (armNote) lines.push(armNote);
    if (typeof o.adjust === 'function' && fin > 0) fin = Math.max(0, cbInt(o.adjust(fin, lines)));
    if (fin > 0) for (const ex of (Array.isArray(o.hpExtra) ? o.hpExtra : []).filter(cbExprOk).slice(0, 4)){ const x = cbRollExpr(ex); fin += Math.max(0, x.total); lines.push(`ความเสียหายเข้า HP จึงเพิ่ม ${ex} ได้ ${x.total}`); }
    let hpDmg = fin, temp = 0;
    // ไฟล์แกน: Temporary HP ไม่ Stack ซ้ำ ผู้ที่มี Temporary HP ในชีทอยู่แล้วไม่ได้รับของใหม่จากทักษะจนกว่าของเดิมจะหมด
    const sheetTemp = (isPc && c && c.current) ? cbInt(c.current.temp) : 0; let tmp1 = Math.max(0, cbInt(o.tempHp));
    if (tmp1 > 0 && sheetTemp > 0){ lines.push(`มี Temporary HP อยู่แล้ว ${sheetTemp} จึงไม่ได้รับ Temporary HP ${tmp1} จากทักษะเพิ่ม (Temporary HP ไม่ทบกัน)`); tmp1 = 0; }
    if (hpDmg > 0 && tmp1 > 0){ const use = Math.min(tmp1, hpDmg); hpDmg -= use; temp += use; lines.push(`Temporary HP จากทักษะรับไว้ ${use}`); }
    if (hpDmg > 0 && isPc && c && Store.isMine(c) && c.current && cbInt(c.current.temp) > 0){ const use = Math.min(cbInt(c.current.temp), hpDmg); c.current.temp = cbInt(c.current.temp) - use; hpDmg -= use; temp += use; Store.upsert(c); lines.push(`Temporary HP รับไว้ ${use}`); }
    else if (hpDmg > 0 && isPc && c && c.current && cbInt(c.current.temp) > 0) lines.push(`เป้ามี Temporary HP ${cbInt(c.current.temp)} ที่ระบบหักให้ไม่ได้ (ชีทเป็นของผู้เล่นอีกคน) ให้เจ้าของปรับเอง`);
    const hp0 = cbInt(t.hp); const hp1 = Math.max(0, hp0 - hpDmg); const tracked = t.kind !== 'asset' || t.hpMax > 0;
    if (hpDmg > 0 && tracked){ tokenVitals(t, 'hp', hp1); lines.push(`HP ${hp0} → ${hp1}${hp1 === 0 ? ' (หมด)' : ''}`); }
    else if (!temp) lines.push(fin > 0 ? 'ไม่เสีย HP' : 'ความเสียหายเหลือ 0 ไม่เสีย HP');
    // ผู้รอดชีวิตคนสุดท้าย (Nightkin): HP ลดต่ำกว่าครึ่งเป็นครั้งแรกในการต่อสู้ ได้ Basic Action เพิ่ม 1 ทุกเทิร์นตั้งแต่เทิร์นถัดไปจนจบการต่อสู้ (Action Track แจกให้ตอนเริ่มเทิร์น)
    if (hpDmg > 0 && tracked && r && r.enc && r.enc.active && cbInt(t.hpMax) > 0 && hp0 * 2 >= cbInt(t.hpMax) && hp1 * 2 < cbInt(t.hpMax) && typeof Feats !== 'undefined' && !((t.used || {})['sticky:sole']) && Feats.has(t, 'Sole Survivor')){
      t.used = (t.used && typeof t.used === 'object') ? t.used : {}; t.used['sticky:sole'] = {n: 1, k: r.enc.round + ':' + r.enc.turnIdx}; lines.push(`ผู้รอดชีวิตคนสุดท้าย: HP ต่ำกว่าครึ่งเป็นครั้งแรกในการต่อสู้นี้ ${t.name} ได้ Basic Action เพิ่ม 1 ทุกเทิร์นตั้งแต่เทิร์นถัดไปจนจบการต่อสู้`); }
    const zeroed = arm > 0 && raw > 0 && (raw - arm) <= 0; // เกราะมาก่อน: นับทั้งความเสียหายกายภาพและความเสียหายเวท (คำเคาะ 15 พ.ย. 2026)
    return {raw, arm, armored, after, fin, hpDmg: (hpDmg > 0 && tracked) ? hpDmg : 0, bleed: 0, temp, hp0, hp1: (hpDmg > 0 && tracked) ? hp1 : hp0, zeroed, lines, tmax: d ? d.toughness : null, c, isPc, tracked};
  },
  /* กติกา On-Hit ที่ส่งมากับการโจมตี: ตรวจชนิดและช่วงของทุกค่า (ข้อความจากห้องถือว่าไม่น่าไว้ใจ) */
  cleanRules(list){
    const names = cbCondNames(); const out = []; const num = (v, lo, hi)=> (v == null || !isFinite(+v)) ? null : Math.max(lo, Math.min(hi, Math.round(+v)));
    for (const x of (Array.isArray(list) ? list : []).slice(0, 10)){ if (!x || typeof x !== 'object' || !names.includes(x.id) || !CB_HIT_CONDS.has(x.id)) continue;
      const sv = (x.save && typeof x.save === 'object' && typeof suStatKnown === 'function' && suStatKnown(String(x.save.stat))) ? {stat: String(x.save.stat), dc: num(x.save.dc, 0, 40)} : null;
      const ends = (x.ends && (x.ends.on === 'start' || x.ends.on === 'end')) ? {on: x.ends.on, n: num(x.ends.n, 1, 9) || 1} : null;
      out.push({id: x.id, lv: num(x.lv, 1, 20), lvHp: !!x.lvHp, perfect: !!x.perfect, focus: !!x.focus, ask: !!x.ask, unarmored: !!x.unarmored, armored: !!x.armored, mode: ['melee', 'thrown', 'ranged'].includes(x.mode) ? x.mode : null, part: HIT_DEFEND[x.part] ? x.part : null, exceptPart: HIT_DEFEND[x.exceptPart] ? x.exceptPart : null,
        cvBelow: num(x.cvBelow, 0, 40), sumMin: num(x.sumMin, 2, 12), sumMax: num(x.sumMax, 2, 12), turns: num(x.turns, 1, 9), ends, save: (sv && sv.dc != null) ? sv : null}); }
    return out;
  },
  /* ใส่สภาวะจากผลโจมตี: สภาวะที่ไม่ซ้อนระดับและติดอยู่แล้วข้ามไป · อายุตั้งต้นตามไฟล์แกน (Stunned Unbalanced Deepwound ถึงจบเทิร์นถัดไปของผู้ติด) */
  applyHitCond(t, r, a, id, lv, rule){
    if (!t || !r) return false; rule = rule || {}; if (!COND_STACK.has(id) && this.has(t, id)) return false;
    const ends = rule.ends || ((typeof Act !== 'undefined' && !rule.turns) ? Act.defaultEnds(t, id) : null);
    return applyCond(t, r, id, {lv: lv || 1, by: a || undefined, turns: rule.turns || undefined, ends: ends || undefined, until: rule.until || undefined});
  },
  /* ข้อความในอุปกรณ์ของฝ่ายรับที่เอ่ยถึงผลของการ Parry สำเร็จ (โล่หนาม โล่บัคเลอร์ ดาบยาว ฯลฯ) ขึ้นเป็นบรรทัดเตือนในการ์ดผล */
  parryNotes(t, def){
    const out = []; const c = this.charOf(t); const items = [];
    if (c && c.equip && !(c.shareMode === 'min' && !Store.isMine(c))) for (const k of ['weapon1', 'weapon2', 'shield']){ const e = c.equip[k]; if (e && (e.name || '').trim() && !(typeof durBroken === 'function' && durBroken(e))) items.push(e); }
    if (this.isNpc(t)) for (const e of (Array.isArray(t.equip) ? t.equip : []).slice(0, 16)) if (e && (e.slot === 'weapon' || e.slot === 'shield') && (e.name || '').trim()) items.push(e);
    for (const e of items.slice(0, 4)){ const txt = String(e.effect || '').replace(/\\/g, ''); for (const cl of txt.split(/[.·]/)){ const s = cl.trim(); if (!/Parry/.test(s) || !/สำเร็จ|Perfect Parry/.test(s)) continue; if (/Perfect Parry/.test(s) && !def.perfect) continue; out.push(`${String(e.name).slice(0, 60)}: ${s.slice(0, 220)}`); } }
    return out.slice(0, 3);
  },
  resolve(m, def, o){
    o = o || {}; const r = Table.room; if (!r || !this.isAttack(m)) return false;
    if (this.resolved(m)){ toast('การโจมตีนี้ตัดสินผลไปแล้ว'); return false; }
    const f = m.flow; const t = this.tok(f.t.id); const a = this.tok(f.a.id); if (!t){ toast('หมากเป้าหมายไม่อยู่บนบอร์ดแล้ว'); return false; }
    const atk = m.atk || {}; const sum = m.roll.sum; const cv = atk.cv != null ? atk.cv : sum; const precise = !!atk.precise; const part = atk.part || hitPart(sum) || 'torso'; const w = f.w || {}; const enc = (typeof Act !== 'undefined') && Act.on(r);
    const hit = !def.success; const lines = []; const res = {lines, tough: [], conds: [], hp0: cbInt(t.hp), hp1: cbInt(t.hp), dmg: 0, bleed: 0, rip: null}; const after = []; let perfect = false, headline = ''; const sugg = []; const fol = {};
    const floats = []; let dm = null;
    for (const ln of (Array.isArray(o.pre) ? o.pre : []).slice(0, 6)) lines.push(String(ln).slice(0, 300));
    if (hit){
      perfect = !!m.roll.double || !!f.perfect || !!(w.headshot && part === 'head' && !precise) || this.has(t, 'Incapacitated') || (Array.isArray(w.perfectOn) && w.perfectOn.slice(0, 4).includes(sum));
      if (def.kind === 'skill' && def.text) lines.push(String(def.text).slice(0, 300));
      const noDmg = (w.noDmg && CB_HIT_CONDS.has(w.noDmg.id) && cbCondNames().includes(w.noDmg.id)) ? w.noDmg : null;
      if (o.immune){
        lines.push(`${String(o.immune).slice(0, 60)}: ${t.name} ไม่ได้รับความเสียหายจากการโจมตีครั้งนี้`);
        if (o.absorb){ const est = Math.max(0, Math.round(cbExprAvg(w.dmg) + cbInt(w.stat) * (perfect ? cbInt(w.mul, 2) : 1) + cbInt(w.bonus))); const half = Math.floor(est / 2); if (half > 0){ t.fabs = Math.min(99, half); lines.push(`ดูดกลืนไฟไว้ การโจมตีหรือเวทไฟครั้งถัดไปของ ${t.name} เพิ่ม ${half} Fire Damage (ครึ่งหนึ่งของ ${est})`); } }
        headline = 'ไม่ได้รับความเสียหาย'; floats.push({x: t.x, y: t.y, text: '0', cls: 'miss'});
      } else if (noDmg){
        lines.push(`ผู้โจมตีเลือกไม่ทำความเสียหาย: ${t.name} ติด ${noDmg.id} แทน`);
        after.push(()=>this.applyHitCond(t, r, a, noDmg.id, null, {ends: (noDmg.ends && (noDmg.ends.on === 'start' || noDmg.ends.on === 'end')) ? {on: noDmg.ends.on, n: Math.max(1, Math.min(9, cbInt(noDmg.ends.n, 1)))} : null}));
        headline = 'โดน' + partLabel(part) + ' · ' + noDmg.id; floats.push({x: t.x, y: t.y, text: noDmg.id, cls: 'dmg'});
      } else {
        const base = cbRollExpr(w.dmg); if (w.halve) base.total = Math.floor(base.total / 2); // อาวุธพังที่ความเสียหายเป็นเต๋า: ครึ่งหนึ่งของผลทอย ปัดลง
        const statN = cbInt(w.stat); const mul = perfect ? Math.max(2, Math.min(4, cbInt(w.mul, 2))) : 1; let raw = base.total + statN * mul + cbInt(w.bonus);
        const bits = [`${w.name} ${base.rolls.length ? base.text : base.total}${w.halve ? ` พังเหลือครึ่ง ${base.total}` : ''}`];
        if (statN) bits.push(`${w.statKind === 'sight' ? 'Sight' : 'Might'} ${statN}${perfect ? ` ×${mul} จาก Perfect Strike` : ''}`); if (cbInt(w.bonus)) bits.push(`โบนัส ${signed(cbInt(w.bonus))}`);
        for (const ex of (Array.isArray(w.dmgDice) ? w.dmgDice : []).filter(cbExprOk).slice(0, 4)){ const x = cbRollExpr(ex); raw += x.total; bits.push(`${ex} ได้ ${x.total}`); }
        if (perfect && cbInt(w.perfectDmg) > 0){ raw += Math.min(20, cbInt(w.perfectDmg)); bits.push(`Perfect Strike เพิ่ม ${Math.min(20, cbInt(w.perfectDmg))}`); }
        const impactNow = !!w.impact || (perfect && !!w.impactOnPerfect);
        if (w.impactX || (perfect && w.impactOnPerfect && f.mode === 'melee' && (this.has(t, 'Prone') || this.has(t, 'Stunned')))){ const x = cbRollExpr('1d3'); raw += x.total; bits.push(`Impact 1d3 ได้ ${x.total}`); }
        const dmul = Math.max(1, Math.min(4, cbInt(w.dmgMul, 1))); if (dmul > 1) raw *= dmul;
        raw = Math.max(0, Math.min(999, raw)); lines.push(`ความเสียหาย: ${bits.join(' + ')}${dmul > 1 ? ` คูณ ${dmul}` : ''} = ${raw} ${w.dtype || ''}`.trim());
        const flex = o.flex ? (fin, ls)=>{ const c2 = this.charOf(t); const mv = (typeof suStatMod === 'function') ? suStatMod('AGI', c2, this.derived(c2), t) : 0; const mod = mv == null ? 0 : mv; const rr = roll2d6('normal'); const tot = rr.sum + mod; const ok = tot >= fin; ls.push(`ความยืดหยุ่นในความเปราะบาง: AGI Saving Throw ${rr.sum}${mod ? ' ' + signed(mod) : ''} = ${tot} ต่อ DC ${fin} ${ok ? `ผ่าน รับครึ่งเดียว ${Math.floor(fin / 2)}` : 'ไม่ผ่าน รับเต็ม'}`); return ok ? Math.floor(fin / 2) : fin; } : null;
        if (cbInt(o.tempKeep) > 0){ const c2 = this.charOf(t); // Temporary HP ที่อยู่ต่อหลังการโจมตี (เช่น ศักยภาพคนนอก) ลงชีทของเจ้าของ · มีอยู่แล้วไม่ทบ (ไฟล์แกน)
          if (c2 && Store.isMine(c2) && Store.chars.includes(c2) && c2.current){ if (cbInt(c2.current.temp) > 0) lines.push(`${t.name} มี Temporary HP อยู่แล้ว ${cbInt(c2.current.temp)} จึงไม่ได้รับเพิ่ม (Temporary HP ไม่ทบกัน)`); else { c2.current.temp = cbInt(o.tempKeep); Store.upsert(c2); lines.push(`${t.name} ได้ Temporary HP ${cbInt(o.tempKeep)}`); } } else o.tempHp = cbInt(o.tempHp) + cbInt(o.tempKeep); }
        dm = this.damage(t, {raw, dtype: w.dtype, physical: !!w.physical, part, ap: !!w.ap, ignoreArmor: w.ignoreArmor, armorAdd: o.armorAdd, weak: !!o.weak, resist: o.resist, min1: !!o.min1, tempHp: o.tempHp, adjust: flex, hpExtra: w.hpDice});
        lines.push(...dm.lines); res.dmg = dm.hpDmg; res.hp0 = dm.hp0; res.hp1 = dm.hp1; if (typeof o.spendHit === 'function') o.spendHit();
        // Toughness: ลด 1 เว้นแต่เกราะหักความเสียหายจนเหลือ 0 · Toughness Damage ที่อาวุธหรือความสามารถระบุเพิ่มยังเข้าตามปกติ
        if (!w.nonLethal){
          let extra = cbInt(w.toughX) + (perfect ? cbInt(w.toughPerfect) : 0) + (dm.armored ? cbInt(w.toughArmored) : 0);
          for (const ex of (Array.isArray(w.toughDice) ? w.toughDice : []).filter(cbExprOk).slice(0, 2)){ const x = cbRollExpr(ex); extra += Math.max(0, x.total); }
          extra = Math.max(0, Math.min(12, extra)); const n1 = (dm.zeroed ? 0 : 1) + extra;
          if (dm.zeroed && !extra) lines.push(`เกราะรับความเสียหายไว้หมด Toughness ของ${partLabel(part)}ไม่ลด`);
          const row = this.toughHit(t, dm.c, dm.tmax, part, n1, extra ? `รวม Toughness Damage เพิ่ม ${extra}` : ''); if (row){ res.tough.push(row); lines.push(this.toughLine(row)); }
          else if (n1 && t.kind !== 'asset') lines.push(dm.isPc ? `ระบบอ่านค่า Toughness ของเป้าไม่ได้ ให้เจ้าของหรือ GM ลด Toughness ของ${partLabel(part)} ${n1} เอง` : `NPC ตัวนี้ยังไม่ได้ตั้งค่า Toughness (ตั้งได้ในหน้าต่างหมากที่เลือก) จึงไม่ได้ลด`);
          for (let i = 0; i < Math.min(6, cbInt(w.sharpnel)); i++){ const sr = roll2d6('normal'); const pk = hitPart(sr.sum) || 'torso'; const rw = this.toughHit(t, dm.c, dm.tmax, pk, 1, `Sharpnel ทอยได้ ${sr.sum}`); if (rw){ res.tough.push(rw); lines.push(this.toughLine(rw)); } }
          if (this.has(t, 'Sundered') && res.tough.length){ const sr = roll2d6('normal'); const pk = hitPart(sr.sum) || 'torso'; const rw = this.toughHit(t, dm.c, dm.tmax, pk, 1, `Sundered ทอยได้ ${sr.sum}`); if (rw){ res.tough.push(rw); lines.push(this.toughLine(rw)); } }
          // Rip: ระบบตรวจเองว่าส่วนที่โดนไม่มีเกราะและความเสียหายเข้า HP แล้วให้ผู้โจมตีเลือกเปลี่ยนเป็น Bleeding ในการ์ดผล
          if (w.rip && w.physical && !dm.armored && dm.hpDmg > 0 && dm.tracked){ res.rip = {n: dm.hpDmg}; lines.push(`Rip: ${partLabel(part)}ไม่มีเกราะ ผู้โจมตีเลือกเปลี่ยนความเสียหาย ${dm.hpDmg} ที่เข้า HP เป็น Bleeding ${dm.hpDmg} ได้`); }
          if (w.impale) after.push(()=>this.applyHitCond(t, r, a, 'Rooted', null, {turns: 1}));
        } else lines.push('Non-Lethal: เสียเฉพาะ HP ไม่ลด Toughness และไม่ติดสภาวะทางกาย');
        for (const rule of this.cleanRules(w.hits)){
          if (w.nonLethal && FT_PHYS.includes(rule.id)) continue;
          if (rule.perfect && !perfect) continue; if (rule.focus && !f.focus) continue; if (rule.mode === 'ranged' ? f.mode === 'melee' : (rule.mode && rule.mode !== f.mode)) continue;
          if (rule.part && rule.part !== part) continue; if (rule.exceptPart && rule.exceptPart === part) continue;
          if (rule.unarmored && dm.armored) continue; if (rule.armored && !dm.armored) continue;
          if (rule.cvBelow != null && !(cv < rule.cvBelow)) continue; if (rule.sumMin != null && sum < rule.sumMin) continue; if (rule.sumMax != null && sum > rule.sumMax) continue;
          const lv = rule.lvHp ? dm.hpDmg : rule.lv; if (rule.lvHp && !lv) continue;
          if (rule.id === 'Rooted' && w.impale && !w.nonLethal) continue;
          if (rule.save || rule.ask) sugg.push({id: rule.id, lv: lv || null, save: rule.save || null, ends: rule.ends || null, turns: rule.turns || null});
          else after.push(()=>this.applyHitCond(t, r, a, rule.id, lv, rule));
        }
        if (perfect && !w.nonLethal){ const dl = this.perfectDur(t, dm.c, part); if (dl) lines.push(dl); }
        const stun = (t.conds || []).find(c=>c.id === 'Stunned'); if (stun && dm.hp1 < dm.hp0) after.push(()=>removeCond(t, r, stun, 'ถูกโจมตีจนเสีย HP'));
        if (impactNow && !w.nonLethal) lines.push('Impact: ผู้โจมตีเลื่อนเป้าได้ 1 เมตร (ย้ายหมากเองถ้าต้องการ)');
        headline = (perfect ? 'Perfect Strike · ' : '') + 'โดน' + partLabel(part);
        floats.push({x: t.x, y: t.y, text: dm.hpDmg > 0 ? `−${dm.hpDmg}` : '0', cls: dm.hpDmg > 0 ? 'dmg' : 'miss'});
        // ผลต่อเนื่องของ Trait และทักษะติดตัว
        if (a && dm.hpDmg > 0 && a.grudge && a.grudge.id === t.id){ delete a.grudge; lines.push(`${f.a.name} ล้างแค้นสำเร็จ จิตอาฆาตสิ้นสุด`); }
        if (a && !t.grudge && Feats.has(t, 'Vengeful Spirit')){ t.grudge = {id: a.id, name: String(f.a.name).slice(0, 60)}; lines.push(`จิตอาฆาต: ${t.name} หมกมุ่นกับการล้างแค้น ${f.a.name} โจมตีเป้าอื่นติด Disadvantage จนกว่าจะทำความเสียหายใส่ผู้นั้นได้`); }
        if (o.flags && o.flags.iflame && w.dtype === 'Fire') t.iflame = 1;
        const hm = cbInt(t.hpMax); if (hm > 0 && dm.hp0 * 2 >= hm && dm.hp1 * 2 < hm){ const hint = this.textHints(t, /HP[^.]{0,40}ต่ำกว่าครึ่ง/); if (hint.length) lines.push(`HP ของ ${t.name} ต่ำกว่าครึ่ง เข้าเงื่อนไขของ ${hint.join(', ')}`); }
        if (dm.hp0 > 0 && dm.hp1 <= 0){ const hint = this.textHints(t, /HP[^.]{0,30}(?:เหลือ|ลดลงเหลือ)\s*0/); if (hint.length) lines.push(`HP ของ ${t.name} หมด เข้าเงื่อนไขของ ${hint.join(', ')}`); }
      }
      for (const ln of (Array.isArray(f.notes) ? f.notes : []).slice(0, 4)) lines.push(String(ln).slice(0, 200));
      t.vitalsAt = Date.now();
    } else {
      headline = def.kind === 'skill' ? `กันด้วย ${def.skill || 'ทักษะ'}` : def.perfect ? (def.kind === 'parry' ? 'Perfect Parry' : 'Perfect Evade') : (def.kind === 'parry' ? 'Parry สำเร็จ' : 'หลบพ้น');
      lines.push(def.text || headline);
      if (def.perfect){ lines.push(`${t.name} ได้ 1 Swift Action ทันที`); if (enc){ t.pd = {round: r.enc.round}; Act.grant(t, 's', 1); } }
      if (def.kind === 'parry'){ for (const ln of this.parryNotes(t, def)) lines.push(ln);
        if (a && ['Large','Huge','Colossal'].includes(a.size)) lines.push(`Parry การโจมตีจากศัตรูขนาด ${a.size}: GM ตัดสินว่ารุนแรงพอให้อาวุธที่ใช้ Parry เสีย Durability 1 ไหม`);
        if ((Feats.has(t, 'Blade Master') || Feats.has(t, 'Blade Master II')) && this.weaponsOf(t).some(x=>x.props && x.props.rip && x.src !== 'custom' && !x.broken)){ t.bmps = 1; lines.push(`Blade Master: Parry ด้วยอาวุธมีคมสำเร็จ การโจมตีประชิดครั้งถัดไปของ ${t.name} ได้ผลของ Proficiency นี้`); } }
      if (def.kind === 'evade' && o.evadeBy5 && def.total != null && def.total - cv >= 5 && enc){ Act.grant(t, 'b', 1); lines.push(`เมฆาไร้ลักษณ์: หลบได้สูงกว่า CV ${def.total - cv} แต้ม ${t.name} ได้ Basic Action 1 ทันที`); }
      if (o.flags && o.flags.boto && a){ t.boto = a.id; lines.push(`ระวังพวกรุ่นเก่า: การโจมตีครั้งถัดไปของ ${t.name} ใส่ ${f.a.name} ได้ Advantage และเป็น Perfect Strike`); }
      if (a && Feats.has(a, 'Tactical Sence')) a.missed = t.id;
      if (def.rootFoe && a) after.push(()=>this.applyHitCond(a, r, t, 'Rooted', null, {until: t.id}));
      // กระบวนท่าที่ให้ผลเมื่อป้องกันสำเร็จ (ติ๊กไว้ในหน้าต่างป้องกัน): จังหวะวัลลาไค ภูผาทรนง เพลงมวยบดศิลา วารีสะท้อนเงา ใบไม้ในสายลม
      const defended = def.kind === 'parry' || def.kind === 'evade' || !!def.asEvade;
      if (defended && o.flags && o.flags.rhythmUp){ t.rhythm = Math.min(3, cbInt(t.rhythm) + 1); lines.push(`จังหวะวัลลาไค: ${t.name} ได้ Rhythm Stack (ตอนนี้ ${t.rhythm} จากสูงสุด 3)`); }
      if (defended && cbInt(o.okTemp) > 0){ const n = Math.min(20, cbInt(o.okTemp)); const c2 = this.charOf(t);
        if (c2 && Store.isMine(c2) && Store.chars.includes(c2) && c2.current){ if (cbInt(c2.current.temp) > 0) lines.push(`ภูผาทรนง: มี Temporary HP อยู่แล้ว ${cbInt(c2.current.temp)} จึงไม่ได้รับเพิ่ม`); else { c2.current.temp = n; Store.upsert(c2); lines.push(`ภูผาทรนง: ${t.name} ได้ Temporary HP ${n}`); } }
        else lines.push(`ภูผาทรนง: ${t.name} ได้ Temporary HP ${n} (จดเองบนชีทของเจ้าของ)`); }
      if (def.kind === 'parry' && f.mode === 'melee' && a && o.parryDmg && cbExprOk(o.parryDmg)){ const x = cbRollExpr(o.parryDmg); const dr = this.damage(a, {raw: Math.max(0, x.total), dtype: 'Blunt', physical: true, noArmor: true}); a.vitalsAt = Date.now();
        lines.push(`เพลงมวยบดศิลา: แรงสะท้อนทำ ${x.total} Blunt Damage ใส่ ${f.a.name} ไม่สนเกราะ (${dr.lines.filter(l=>!/ไม่หักเกราะ/.test(l)).join(' · ')})`); if (typeof o.spendOk === 'function') o.spendOk(); }
      if (def.kind === 'parry' && def.perfect && o.flags && o.flags.mwater && a) fol.mw = true;
      if (defended) for (const ln of (Array.isArray(o.okNotes) ? o.okNotes : []).slice(0, 3)) lines.push(String(ln).slice(0, 220));
      for (const ln of (Array.isArray(def.extra) ? def.extra : []).slice(0, 3)) lines.push(String(ln).slice(0, 240));
      if (a && Feats.has(a, 'Born to Fight')) fol.btf = true;
      if (a && f.mode === 'melee' && cellDist(a, t) <= 1 && Feats.has(t, 'Muscle Memory')) fol.mm = true;
      floats.push({x: t.x, y: t.y, text: def.perfect ? 'Perfect!' : (def.kind === 'parry' ? 'Parry' : def.kind === 'evade' ? 'Evade' : 'Block'), cls: 'miss'});
    }
    if (o.sanity && cbExprOk(o.sanity)){ const x = cbRollExpr(o.sanity); const s0 = cbInt(t.san); const s1 = Math.max(0, s0 - Math.max(0, x.total)); if (t.sanMax) tokenVitals(t, 'san', s1); lines.push(`${String(o.immune || 'ทักษะ').slice(0, 60)}: ${t.name} เสีย Sanity ${x.rolls.length ? x.text : x.total}${t.sanMax ? ` (Sanity ${s0} → ${s1})` : ''}`); }
    if (Array.isArray(o.feats) && o.feats.length) lines.push('ฝ่ายรับใช้: ' + o.feats.map(x=>String(x).slice(0, 180)).join(' · ').slice(0, 500));
    if (Array.isArray(o.adj) && o.adj.length) lines.push('ฝ่ายรับปรับเอง: ' + o.adj.join(', ').slice(0, 200));
    const sg0 = hit && dm && !w.nonLethal ? (w.conds || []).filter(x=>x && x.id && cbCondNames().includes(x.id) && !(x.id === 'Rooted' && w.impale) && !sugg.some(k=>k.id === x.id)).slice(0, 5).map(x=>({id: x.id, lv: x.lv ? Math.max(1, Math.min(20, cbInt(x.lv, 1))) : null})) : [];
    const suggAll = [...sugg, ...sg0].slice(0, 6);
    Table.save();
    const from = a ? {x: a.x, y: a.y} : null;
    Table.post({kind: 'clash', fixedId: 'clash-' + m.id, of: m.id, who: f.a.name, text: `${f.a.name} โจมตี ${t.name}: ${headline}`, gmOnly: !!m.gmOnly, a: f.a, t: f.t, w: {name: w.name, dtype: w.dtype}, mode: f.mode,
      atkRoll: cbRollOf(m.roll), cv, part, perfect, hit, headline, def: {kind: def.kind, asEvade: !!def.asEvade, roll: def.roll || null, mod: def.mod || 0, total: def.total != null ? def.total : null, text: def.text || '', cls: def.cls || '', perfect: !!def.perfect, label: def.label || '', skill: def.skill || null, mode: def.mode || 'normal', foe: def.foe || null}, res, sugg: suggAll, fol,
      fx: (hit && !o.immune) ? {k: f.mode === 'melee' ? 'slash' : 'proj', from, to: {x: t.x, y: t.y}, hue: fxHueOfDamage(w.dtype), floats} : {k: 'shield', from, to: {x: t.x, y: t.y}, hue: 'qi', floats}});
    for (const fn of after){ try { fn(); } catch(e){ console.warn('combat after', e); } }
    return true;
  },
  /* ชื่อความสามารถและทักษะของหมากที่ข้อความตรงกับเงื่อนไข (ใช้เตือนตอน HP ต่ำกว่าครึ่งหรือหมด) */
  textHints(t, rx){ const out = []; const fo = Feats.of(t); for (const ft of fo.list) if (rx.test(ft.text)) out.push(ft.th); let names = []; try { names = fo.c ? allSkills(fo.c) : []; } catch(e){ names = []; }
    for (const n of names){ const sk = SKILL_BY_NAME[n]; if (sk && !/Passive|กระบวนท่า/.test(sk.type || '') && rx.test(String(sk.effect || ''))) out.push(skTh(sk)); } return [...new Set(out)].slice(0, 4); },
  /* Rip: ผู้โจมตีเลือกเปลี่ยนความเสียหายที่เข้า HP เป็น Bleeding เท่าจำนวนนั้น (ไฟล์ Item All) คืน HP แล้วใส่ Bleeding */
  ripConvert(m){
    const r = Table.room; if (!r || !m || m.kind !== 'clash' || !m.res || !m.res.rip) return; const key = 'rip|' + m.id;
    if (this.done.has(key) || Table.chat.some(x=>x && x.of === m.id && x.step === 'rip')){ toast('การโจมตีนี้เลือกไปแล้ว'); return; }
    const t = m.t ? this.tok(m.t.id) : null; const a = m.a ? this.tok(m.a.id) : null; if (!t){ toast('หมากเป้าหมายไม่อยู่บนบอร์ดแล้ว'); return; }
    if (!(Table.isGM() || Table.localMode || (a && this.controls(a)))){ toast('ผู้โจมตีหรือ GM เป็นคนเลือก'); return; }
    if (Date.now() - (m.ts || 0) >= CB_PENDING_MS){ toast('การโจมตีนี้ผ่านมานานแล้ว เลือกเปลี่ยนเป็น Bleeding ไม่ได้'); return; }
    const n = Math.max(0, Math.min(999, cbInt(m.res.rip.n))); if (!n) return; this.done.add(key);
    const hp0 = cbInt(t.hp); const mx = cbInt(t.hpMax); const hp1 = mx > 0 ? Math.min(mx, hp0 + n) : hp0 + n; tokenVitals(t, 'hp', hp1);
    Table.post({kind: 'sys', fixedId: 'rip-' + m.id, of: m.id, step: 'rip', who: '', text: `Rip: ${(m.a && m.a.name) || 'ผู้โจมตี'} เปลี่ยนความเสียหาย ${n} ที่เข้า${partLabel(m.part)}ของ ${t.name} เป็น Bleeding ${n} (HP ${hp0} → ${hp1})`});
    applyCond(t, r, 'Bleeding', {lv: n, by: a || undefined});
  },
  /* สภาวะที่ต้องทอย Saving Throw ก่อน (เช่น VIT Check DC 10 ไม่ผ่านติด Unbalanced): ฝ่ายรับกดทอย ไม่ผ่านระบบใส่สภาวะให้ */
  suggRoll(m, sg){
    const r = Table.room; const t = m.t ? this.tok(m.t.id) : null; const src = m.a ? this.tok(m.a.id) : null; if (!r || !t || !sg || !sg.save) return; const key = m.id + '|' + sg.id;
    if (this.done.has(key) || Table.chat.some(x=>x && x.of === m.id && x.step === 'sugg' && x.cond === sg.id)){ toast('ทอยรายการนี้ไปแล้ว'); return; }
    const text = `${sg.save.stat} Saving Throw · ต้าน ${sg.id}`;
    Table.guardedRoll(t.name, async ()=>{
      const c = this.charOf(t); let mod = suStatMod(sg.save.stat, c, this.derived(c), t);
      if (mod == null){ mod = await SkillUse.askMod(`${t.name}: ${text}`); if (mod == null) return; }
      if (this.done.has(key)) return; this.done.add(key);
      const rr = roll2d6('normal'); const total = rr.sum + mod; const j = judge(total, rr, sg.save.dc); const ok = /res-(full|crit)/.test(j.cls || '') && !/Failure|ล้มเหลว/.test(j.text || '');
      Table.post({kind: 'roll', fixedId: `sugg-${m.id}-${sg.id}`, who: t.hidden ? 'บางสิ่งที่มองไม่เห็น' : t.name, text, roll: {dice: rr.dice, kept: rr.kept, keptIdx: rr.keptIdx, sum: rr.sum, crit: rr.crit, double: rr.double, mode: 'normal'}, mod, pm: 0, total, judge: j, dc: sg.save.dc, gmOnly: false, of: m.id, step: 'sugg', cond: sg.id});
      if (!ok) this.applyHitCond(t, r, src, sg.id, sg.lv, sg);
    }, text);
  },

  /* ---------- 7. การ์ดในแชต ---------- */
  chatEl(m, time){
    if (m.kind === 'clash') return this.clashCard(m, time);
    if (m.kind === 'pick' && m.flow) return this.pickCard(m, time);
    if (m.kind === 'skill' && typeof SkillUse !== 'undefined') return SkillUse.card(m, time);
    return null;
  },
  /* แถวสถานะใต้ข้อความทอยโจมตีที่มาจากหน้าต่างโจมตี */
  flowRow(m){
    if (!this.isAttack(m)) return null; const f = m.flow; const done = this.resolved(m); const old = Date.now() - (m.ts || 0) > CB_PENDING_MS;
    const row = h('div',{class:'row flowrow',style:'gap:6px;margin-top:3px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:`เป้า: ${f.t.name} · ${f.w.name} · ${f.mode === 'melee' ? 'ประชิด' : f.mode === 'thrown' ? 'ขว้าง' : 'ยิง'} ${f.m} ม.`}));
    if (done) row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:'ตัดสินแล้ว'})));
    else if (old) row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:'ค้างนานเกินไป ไม่ได้ตัดสิน'})));
    else if (this.canRespond(m)) row.append(...cbKids(h('button',{class:'small primary flow-def',dataset:{of:m.id},onclick:()=>{ this.snooze.delete(m.id); const t = this.tok(f.t.id); if (t && t.kind === 'asset') this.autoHit(m); else this.openDefense(m); },text: this.primary(m) ? '🛡 เลือกวิธีป้องกัน' : '🛡 ป้องกันแทน'})));
    else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`รอ ${f.t.name} ป้องกัน`})));
    return row;
  },
  pickCard(m, time){
    const f = m.flow; const done = Table.pickDone(m); const dice = m.dice || []; const t = this.tok(f.t.id); const can = !done && (Table.localMode || Table.isGM() || (t && ownsTok(t)));
    return h('div',{class:'e pickmsg' + (done ? ' done' : '')}, h('div',{class:'row',style:'gap:6px'}, chatWho(m), h('b',{text:m.text || 'Attack Roll'}), tag('Disadvantage', 'neg'), h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
      h('div',{class:'row',style:'gap:8px;margin-top:2px;align-items:center'}, h('span',{class:'inline-roll'}, dice.map(v=>h('span',{class:'die',text:v}))), m.cvMod ? h('span',{class:'dim num',text:'ตัวปรับ CV ' + signed(m.cvMod)}) : null,
        done ? h('span',{class:'dim',text:'เลือกแล้ว ดูผลในข้อความถัดไป'}) : (can ? h('button',{class:'small primary pickbtn flow-pick',onclick:()=>Table.resolvePick(m),text:`เลือก 2 ลูกให้การโจมตีใส่ ${f.t.name}`}) : h('span',{class:'dim',text:`รอ ${f.t.name} หรือ GM เลือก 2 ลูก`}))));
  },
  clashCard(m, time){
    const def = m.def || {}; const res = m.res || {}; const a = m.atkRoll || {};
    const el = h('div',{class:'e clashmsg ' + (m.hit ? 'hit' : 'blocked')}, h('div',{class:'row',style:'gap:6px'}, h('b',{text:`⚔ ${(m.a && m.a.name) || ''} → ${(m.t && m.t.name) || ''}`}), h('span',{class:'dim',text:(m.w && m.w.name) || ''}), m.gmOnly ? h('span',{class:'gm',text:'ลับ'}) : null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
      h('div',{class:'row',style:'gap:8px;margin-top:2px;align-items:center'}, renderDice({dice: a.dice || [], keptIdx: a.keptIdx || []}), h('span',{class:'num dim',text:`${a.sum}${m.cv !== a.sum ? ' → CV ' + m.cv : ''} ${partLabel(m.part)}`}), h('span',{class:'dim',text:'ปะทะ'}),
        def.roll ? [renderDice({dice: def.roll.dice || [], keptIdx: def.roll.keptIdx || []}), h('span',{class:'num dim',text:`${String(def.label || '').slice(0, 40)} ${cbInt(def.total)}`})] : h('span',{class:'dim',text: def.kind === 'skill' ? String(def.skill || 'ทักษะ').slice(0, 80) : 'ไม่ป้องกัน'}),
        (def.foe && def.foe.roll) ? [h('span',{class:'dim',text:'ต่อ'}), renderDice({dice: def.foe.roll.dice || [], keptIdx: def.foe.roll.keptIdx || []}), h('span',{class:'num dim',text:`${String(def.foe.label || '').slice(0, 20)} ${cbInt(def.foe.total)}`})] : null,
        h('b',{class: m.hit ? 'res-fail' : (def.perfect ? 'res-crit' : 'res-full'),text:m.headline || ''})));
    const body = h('div',{class:'clash-lines'}); const rows = [];
    const resLines = Array.isArray(res.lines) ? res.lines : []; if (def.roll && def.text && !resLines.includes(def.text)) rows.push(h('div',{class:'dim',text:String(def.text).slice(0, 300)})); // ข้อความผลการป้องกันที่อยู่ในบรรทัดผลแล้วไม่แสดงซ้ำ
    for (const ln of (Array.isArray(res.lines) ? res.lines : []).slice(0, 18)) rows.push(h('div',{text:String(ln).slice(0, 500)}));
    for (const row of (Array.isArray(res.tough) ? res.tough : []).slice(0, 8)) if (row && row.wound && row.wound.text) rows.push(h('div',{class:'desc',style:'font-size:11.5px'}, T(`${row.part ? partLabel(row.part) : ''}: ${String(row.wound.text).slice(0, 300)}`)));
    body.append(...cbKids(rows.slice(0, 20)));
    el.append(...cbKids(body));
    const t = m.t ? this.tok(m.t.id) : null; const src = m.a ? this.tok(m.a.id) : null; const gm = Table.isGM() || Table.localMode; const fols = Table.chat.filter(x=>x && x.of === m.id);
    // Rip: ผู้โจมตี (หรือ GM) เลือกเปลี่ยนความเสียหายที่เข้า HP เป็น Bleeding
    const fresh = Date.now() - (m.ts || 0) < CB_PENDING_MS; // ตัวเลือกหลังรู้ผล (Rip โจมตีซ้ำ Reaction) เลือกได้ขณะการโจมตียังใหม่ การ์ดเก่าไม่เสนอแล้ว
    if (res.rip && cbInt(res.rip.n) > 0 && (fresh || fols.some(x=>x.step === 'rip'))){ const n = cbInt(res.rip.n); const done = fols.some(x=>x.step === 'rip') || this.done.has('rip|' + m.id); const can = gm || (src && this.controls(src));
      el.append(...cbKids(h('div',{class:'row sugg ripline',style:'gap:6px;margin-top:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text: done ? `Rip: เปลี่ยนเป็น Bleeding ${n} แล้ว` : `Rip: ส่วนที่โดนไม่มีเกราะ ${can ? 'เลือกได้' : 'รอผู้โจมตีเลือก'}`}), (!done && can) ? h('button',{class:'small primary rip-btn',onclick:()=>this.ripConvert(m),text:`🩸 เปลี่ยน ${n} ความเสียหายเป็น Bleeding ${n}`}) : null))); }
    if (t && Array.isArray(m.sugg) && m.sugg.length && this.controls(t)){
      const list = m.sugg.slice(0, 6).filter(sg=>sg && typeof sg.id === 'string' && cbCondNames().includes(sg.id));
      const row = h('div',{class:'row sugg',style:'gap:6px;margin-top:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text: list.some(sg=>sg.save) ? 'ผลต่อเนื่องของการโจมตี:' : 'เอฟเฟกต์ของอาวุธเอ่ยถึงสภาวะ ใส่ให้เมื่อเข้าเงื่อนไข:'}));
      for (const sg of list){ const key = m.id + '|' + sg.id; const lv = sg.lv ? Math.max(1, Math.min(20, cbInt(sg.lv, 1))) : null;
        if (sg.save && typeof sg.save === 'object' && suStatKnown(String(sg.save.stat)) && isFinite(+sg.save.dc)){ const sv = {stat: String(sg.save.stat), dc: Math.max(0, Math.min(40, Math.round(+sg.save.dc)))}; const rolled = fols.find(x=>x.step === 'sugg' && x.cond === sg.id);
          if (rolled){ const ok = /res-(full|crit)/.test((rolled.judge && rolled.judge.cls) || '') && !/Failure|ล้มเหลว/.test((rolled.judge && rolled.judge.text) || ''); row.append(...cbKids(tag(`${sv.stat} ST ${cbInt(rolled.total)}: ${ok ? 'ผ่าน ไม่ติด ' + sg.id : 'ไม่ผ่าน ติด ' + sg.id}`, ok ? 'ok' : 'neg'))); }
          else row.append(...cbKids(h('button',{class:'small primary sugg-save',dataset:{cond:sg.id},disabled: this.done.has(key),onclick:()=>this.suggRoll(m, {id: sg.id, lv, save: sv, ends: sg.ends || null, turns: sg.turns || null}),text:`🎲 ${sv.stat} Saving Throw (DC ${sv.dc}) ไม่ผ่านติด ${sg.id}${lv ? ' ' + lv : ''}`})));
          continue; }
        const b = h('button',{class:'small ghost sugg-btn',dataset:{cond:sg.id},disabled: this.done.has(key),onclick:()=>{ if (this.done.has(key)) return; this.done.add(key); b.disabled = true; if (!this.applyHitCond(t, Table.room, src, sg.id, lv, {ends: (sg.ends && (sg.ends.on === 'start' || sg.ends.on === 'end')) ? sg.ends : null, turns: sg.turns ? Math.max(1, Math.min(9, cbInt(sg.turns, 1))) : null})){ this.done.delete(key); b.disabled = false; toast('ติดสถานะนี้อยู่แล้ว'); } },text:`${condIcon(sg.id)} ${sg.id}${lv ? ' ' + lv : ''}`}); row.append(...cbKids(b)); }
      if (row.children.length > 1) el.append(...cbKids(row));
    }
    // การกระทำต่อเนื่องหลังรู้ผล: โจมตีซ้ำ โจมตีสวน และ Reaction ที่ใช้หลังป้องกันสำเร็จ
    const fol = (m.fol && typeof m.fol === 'object') ? m.fol : {}; const acts = [];
    if (fresh && !m.hit && fol.btf && src && t && this.controls(src) && Feats.has(src, 'Born to Fight')) acts.push(h('button',{class:'small fol-btn fol-btf',onclick:()=>this.openAttack(src.id, t.id, {again: 'btf', act: 'c', pick: (m.w && m.w.name) || ''}),text:'🔁 เกิดมาเพื่อรบ: โจมตีซ้ำ (Cast Action, Disadvantage)'}));
    if (fresh && !m.hit && fol.mm && src && t && this.controls(t) && Feats.has(t, 'Muscle Memory')) acts.push(h('button',{class:'small fol-btn fol-mm',onclick:()=>this.openAttack(t.id, src.id, {again: 'mm', act: 'free'}),text:'↺ ความจำกล้ามเนื้อ: โจมตีสวน (Reaction)'}));
    if (fresh && !m.hit && fol.mw && src && t && this.controls(t) && t.stance && t.stance.id === 'Mirroring Water Stance') acts.push(h('button',{class:'small fol-btn fol-mw',onclick:()=>this.openAttack(t.id, src.id, {again: 'mw', act: 'free'}),text:'🌊 วารีสะท้อนเงา: โจมตีฉวยโอกาส (ไม่เสีย Action)'}));
    if (fresh && t && this.controls(t) && typeof SkillUse !== 'undefined'){ const c = this.charOf(t); let names = []; try { names = c && !(c.shareMode === 'min' && !Store.isMine(c)) ? allSkills(c) : []; } catch(e){ names = []; }
      for (const n of names){ const sk = SKILL_BY_NAME[n]; if (!sk || !Object.prototype.hasOwnProperty.call(CB_REACT_POST, sk.nameEn)) continue; const spec = CB_REACT_POST[sk.nameEn]; if (!spec.fit(m)) continue; if (fols.some(x=>x.kind === 'skill' && x.sk === sk.nameEn)) continue;
        const tg = this.postReactTargets(m, t, spec);
        acts.push(h('button',{class:'small fol-btn fol-react',dataset:{sk:sk.nameEn},title:String(sk.effect || '').slice(0, 300),onclick:()=>SkillUse.use(t.id, sk.nameEn, null, {react: m.of || true, targets: tg, of: m.id}),text:`↺ ${skTh(sk)}${sk.cost && !/^none$/i.test(sk.cost) ? ' (' + sk.cost + ')' : ''}`})); } }
    if (acts.length) el.append(...cbKids(h('div',{class:'row sugg folrow',style:'gap:6px;margin-top:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'ทำต่อได้:'}), acts)));
    return el;
  },

  /* เป้าหมายของ Reaction ที่ใช้หลังรู้ผลการป้องกัน: ผู้โจมตี หมากในเขตปะทะของฝ่ายรับ หรือตัวฝ่ายรับเอง */
  postReactTargets(m, t, spec){ const src = m.a ? this.tok(m.a.id) : null; return spec.to === 'attacker' ? (src ? [src.id] : []) : spec.to === 'zone' ? this.visible(Table.room).filter(x=>x.id !== t.id && x.kind !== 'asset' && cellDist(x, t) <= 1).map(x=>x.id) : [t.id]; },
  /* การโจมตีที่ค้างอยู่ซึ่งเล็งมายังหมากนี้ (ล่าสุด) และผลการป้องกันล่าสุดของหมากนี้ที่ยังใช้ Reaction ต่อได้ */
  pendingOn(t){ const list = this.pending().filter(m=>m.flow.t.id === t.id && this.canRespond(m)); return list[list.length - 1] || null; },
  recentClashOn(t, fit){ const now = Date.now(); return Table.chat.find(m=>m && m.kind === 'clash' && m.t && m.t.id === t.id && now - (m.ts || 0) < CB_PENDING_MS && (!fit || fit(m))) || null; },

  /* ---------- 8. ส่วนที่ฝังในหน้าต่างหมากที่เลือก ---------- */
  /* ปุ่มโจมตีในหน้าต่างหมากที่เลือก (เรียกจาก tokBody ของ table.js) · ค่าต่อสู้ของ NPC ตั้งที่แผงหมากเดิม: ค่าพลังดัดแปลง Range อาวุธและชุดเกราะ สแตตบล็อก
   * v1.29: GM ให้ Parry Dice เพิ่มที่หมากได้ (t.pdx) จำนวน Parry Dice ที่เหลือมาจากอุปกรณ์และความสามารถ ผู้เล่นไม่ได้เลือกเอง */
  tokPanel(t, r, gm){
    const out = []; if (!t || t.inside) return out; const mine = this.myTokens(r);
    const row = h('div',{class:'row cb-row',style:'gap:6px;margin-top:8px'});
    if (t.kind !== 'asset' && this.controls(t)) row.append(...cbKids(h('button',{class:'small primary cb-attack',title:'เปิดหน้าต่างโจมตี เลือกเป้าหมาย อาวุธ และแบบการโจมตี',onclick:()=>this.openAttack(t.id, null),text:'⚔ โจมตี'})));
    const others = mine.filter(x=>x.id !== t.id);
    if (others.length && (t.kind !== 'asset' || t.hpMax > 0) && (!this.controls(t) || gm)) row.append(...cbKids(h('button',{class:'small cb-target',title:'ใช้หมากของคุณโจมตีหมากนี้',onclick:()=>{ const sel = others.find(x=>x.kind === 'pc' && ownsTok(x)) || others[0]; this.openAttack(sel.id, t.id); },text:'🎯 โจมตีหมากนี้'})));
    if (row.children.length) out.push(row);
    if (t.kind !== 'asset' && (gm || cbInt(t.pdx) > 0)){ const base = this.defStats(t).pd; const px = Math.max(0, Math.min(3, cbInt(t.pdx)));
      const set = (v)=>{ t.pdx = Math.max(0, Math.min(3, v)); if (!t.pdx) delete t.pdx; Table.save(); if (!t.hidden) Table.post({kind: 'sys', who: '', text: `GM ${v > px ? 'ให้' : 'ลด'} Parry Dice ของ ${t.name} (ที่ GM ให้เพิ่มตอนนี้ ${cbInt(t.pdx)})`}); };
      out.push(h('div',{class:'row cb-pdrow',style:'gap:6px;margin-top:6px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',title:'Parry Dice มาจากอุปกรณ์และความสามารถที่สวมหรือใช้อยู่ GM ให้เพิ่มได้',text:`🛡 Parry Dice ${base + px}${px ? ` (อุปกรณ์ ${base} + GM ให้ ${px})` : ' จากอุปกรณ์และความสามารถ'}`}),
        gm ? h('button',{class:'small cb-pdminus',disabled: px <= 0,title:'ลด Parry Dice ที่ GM ให้เพิ่ม',onclick:()=>set(px - 1),text:'−'}) : null, gm ? h('button',{class:'small cb-pdplus',disabled: px >= 3,title:'GM ให้ Parry Dice เพิ่ม 1 ลูก (อยู่กับหมากจนกว่า GM จะลด)',onclick:()=>set(px + 1),text:'+ ให้ Parry Dice'}) : null)); }
    return out;
  },
  /* เรียกหลังโต๊ะวาดเสร็จทุกครั้ง: ปรับหน้าต่างโจมตีตามตำแหน่งหมากล่าสุด และเริ่มนับข้อความในห้องที่ไม่มีการฟังฐานข้อมูล */
  afterRender(){
    if (!Table.room){ this.closeComposer(); return; }
    if (!this.ready && Table.localMode) this.onChat();
    if (this.comp){ if (!this.tok(this.comp.a)){ this.closeComposer(); } else { if (this.comp.t && !this.tok(this.comp.t)) this.comp.t = null; const ae = document.activeElement; const typing = !!(ae && ae.closest && ae.closest('#atkc') && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)); if (!typing) this.drawComposer(); else this.drawDyn(); } }
    if (typeof SkillUse !== 'undefined') SkillUse.afterRender();
  },
};
