/* ===== v1.28 (Non สั่ง 13 พ.ย. 2026 ต่อบนฐาน v1.27 เมื่อ 16 พ.ย. 2026): ระบบโจมตีแบบมีขั้นตอนในโต๊ะเล่น =====
 * ลำดับ: ผู้โจมตีเปิดหน้าต่างโจมตี เลือกเป้า (คลิกหมากบนแผนที่ได้) อาวุธ และแบบการโจมตี หน้าต่างบอกระยะ ว่าไกลเกินหรือโดนลด CV
 *        → ทอยโจมตี (ข้อความ kind 'roll' ที่มี flow) → ฝ่ายรับ (เจ้าของหมาก หรือ GM ถ้าเป็น NPC) เลือก Parry / Evade / ใช้ทักษะ / ไม่ป้องกัน
 *        → เต๋าชนกัน (ข้อความ kind 'clash') → เครื่องของฝ่ายรับคิดความเสียหาย หักเกราะ ลง HP และ Toughness ให้
 * กฎที่ใช้: ไฟล์แกน บท "ระบบการต่อสู้" ข้อ 2 ถึง 5 คุณสมบัติอาวุธในไฟล์ Item All และคำเคาะ 15 ถึง 16 พ.ย. 2026
 *   (ยิงเกินระยะแม่น -1 CV ต่อ 1 ม. · เกราะหลักบวกเกราะรองของชนิดในวงเล็บ · เกราะหลักหักเวทด้วย · ของพังเหลือครึ่ง · NPC ใช้กฎเดียวกับผู้เล่น)
 * ค่าของ NPC อ่านจากสิ่งที่หมากมีอยู่แล้ว: ค่าพลังดัดแปลง (t.mods) อาวุธและชุดเกราะ (t.equip) การโจมตีในสแตตบล็อก (t.attacks) วิธีป้องกัน (t.defend)
 * ข้อความเอฟเฟกต์ของอาวุธที่เป็นเงื่อนไขเฉพาะ ระบบอ่านเป็นตัวเลือกให้ผู้โจมตีติ๊กเอง ไม่เดาแทน */

/* ---------- 1. ตัวอ่านข้อความกฎ (ไม่แตะหน้าจอ) ---------- */
const CB_PHYS = ['Slashing','Piercing','Blunt','Physical'];
const CB_DTYPES = ['Slashing','Piercing','Blunt','Physical','Fire','Plasma','Electric','Frost','Necrotic','Sonic','Acid','Poison','Light'];
const CB_PENDING_MS = 15 * 60 * 1000;        // การโจมตีที่ค้างเกินนี้ไม่เด้งถามฝ่ายรับอีก
function cbInt(v, d){ const n = parseInt(v, 10); return isFinite(n) ? n : (d || 0); }
function cbNormType(t){
  const s = String(t || '').trim(); if (!s) return '';
  const k = s.toLowerCase();
  if (/^slash/.test(k)) return 'Slashing'; if (/^pierc/.test(k)) return 'Piercing'; if (/^(blunt|bludgeon)/.test(k)) return 'Blunt'; if (/^(phys|pdmg)/.test(k)) return 'Physical'; if (/^corrode/.test(k)) return 'Acid'; if (/^burn/.test(k)) return 'Fire';
  return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
}
function cbIsPhysical(t){ return CB_PHYS.includes(cbNormType(t)); }
/* ทอยนิพจน์ความเสียหาย: "2" · "1d6" · "2d6+1" · "1d3" (อย่างอื่นนับเป็น 0) */
const CB_DICE_RX = /^\s*(\d{1,2})\s*d\s*(\d{1,3})\s*(?:([+-])\s*(\d{1,3}))?\s*$/i;
function cbRollExpr(expr){
  const s = String(expr == null ? '' : expr).trim(); const m = CB_DICE_RX.exec(s);
  if (!m){ const n = parseInt(s, 10); const v = isFinite(n) ? n : 0; return {total: v, rolls: [], add: 0, text: String(v)}; }
  const cnt = Math.min(20, Math.max(1, +m[1])), sides = Math.min(100, Math.max(2, +m[2])); const add = m[3] ? (m[3] === '-' ? -1 : 1) * (+m[4]) : 0;
  const rolls = Array.from({length: cnt}, ()=>rollDie(sides)); const total = rolls.reduce((a, b)=>a + b, 0) + add;
  return {total, rolls, add, text: `${cnt}d${sides}${add ? signed(add) : ''} [${rolls.join(',')}]${add ? ' ' + signed(add) : ''} = ${total}`};
}
function cbExprOk(expr){ const s = String(expr == null ? '' : expr).trim(); return /^\d{1,3}$/.test(s) || CB_DICE_RX.test(s); }
function cbExprAvg(expr){ const s = String(expr == null ? '' : expr).trim(); const m = CB_DICE_RX.exec(s); if (!m) return cbInt(s); return (+m[1]) * ((+m[2]) + 1) / 2 + (m[3] ? (m[3] === '-' ? -1 : 1) * (+m[4]) : 0); }
/* สภาวะที่ข้อความเอ่ยถึง พร้อมระดับถ้าเขียนไว้ติดกัน ใช้เป็นปุ่มเสนอในการ์ดผล ไม่ใส่ให้เอง */
const CB_COND_ALIAS = {Burn:'Burning', Stun:'Stunned', Poison:'Poisoned', Bleed:'Bleeding', Root:'Rooted', Blind:'Blinded'};
/* สภาวะที่อาวุธใส่ให้เป้าได้ (ตัดสภาวะเชิงบวกและสภาวะจากสภาพแวดล้อมออกจากปุ่มเสนอของอาวุธ) */
const CB_HIT_CONDS = new Set(['Stunned','Unbalanced','Prone','Bleeding','Deepwound','Burning','Poisoned','Rooted','Grappled','Blinded','Deafened','Frightened','Confused','Silenced','Sundered','Marked','Incapacitated']);
function cbCondNames(){ if (!cbCondNames.list) cbCondNames.list = Object.entries(GLOSSARY).filter(([k, v])=>/Condition/.test((v && v.cat) || '')).map(([k])=>k); return cbCondNames.list; }
function cbFindConds(text){
  const out = []; const seen = new Set(); const s = String(text || '');
  const tryAdd = (id, word)=>{ if (!id || seen.has(id)) return;
    const rx = new RegExp('(?:(\\d+)\\s*)?["“”\']?\\b' + word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b["“”\']?(?:\\s*(\\d+)(?!\\s*(?:เมตร|รอบ|เทิร์น|นาที|ชั่วโมง|วินาที|ครั้ง|%|ม\\.)))?');
    const m = rx.exec(s); if (!m) return; seen.add(id);
    out.push({id, lv: (typeof COND_STACK !== 'undefined' && COND_STACK.has(id)) ? Math.max(1, Math.min(20, cbInt(m[1] || m[2], 1))) : null}); };
  for (const id of cbCondNames()) tryAdd(id, id);
  for (const [w, id] of Object.entries(CB_COND_ALIAS)) tryAdd(id, w);
  return out;
}
/* อ่านอาวุธจากชื่อและข้อความเอฟเฟกต์: ความเสียหายตั้งต้น ประเภท คุณสมบัติ (on = อยู่ในรายการคุณสมบัติหลัก ไม่มีเงื่อนไขนำหน้า) */
const CB_PROPS = [['rip',/\bRip\b/],['ap',/\bArmor Penetrate\b/],['gb',/\bGuard Break\b/],['impact',/\bImpact\b/],['headshot',/\bHead\s?[Ss]hot\b/],['impale',/\bImpale\b/],['cleave',/\bCleave\b/],['delay',/\bDelay\b/],['throwable',/\bThrowable\b/],['reach',/\bReach\b/],['reload',/\bReload\b/],['cone',/\bCone Attack\b/]];
const CB_PROP_LABEL = {rip:'Rip', ap:'Armor Penetrate', gb:'Guard Break', impact:'Impact', headshot:'Headshot', impale:'Impale', cleave:'Cleave', delay:'Delay', throwable:'Throwable', reach:'Reach', reload:'Reload', cone:'Cone Attack'};
const CB_COND_RX = /หาก|เมื่อ|สามารถ|เลือก|On-?[Hh]it|Perfect|มิฉะนั้น|ถ้า/;
function cbItemCat(name){ if (!cbItemCat.map){ cbItemCat.map = {}; for (const it of DATA.items || []) cbItemCat.map[it.name] = it.cat || ''; } return cbItemCat.map[String(name || '')] || ''; }
function cbParseWeapon(name, effect){
  const raw = String(effect || '').replace(/\\/g, '');
  const eff = (typeof weaponPropsText === 'function' ? weaponPropsText(raw) : raw).replace(/\(ต้องการ STR\s*\d+\)\s*/, '');
  const w = {name: String(name || '').trim() || 'อาวุธ', text: raw, dmg: '0', dtypes: ['Physical'], physical: true, props: {}, sharpnel: 0, toughX: 0, toughOpt: 0, toughPerfect: 0, ranged: false, bomb: false, statKind: 'might', conds: [], strNeed: 0, found: false};
  const dm = /(^|[^+\d])(\d+(?:d\d+)?)\s*(PDMG|Might|[A-Z][a-z]+ Damage)\s*(?:\(([^)]+)\)|(Slashing|Piercing|Blunt)\b)?/.exec(eff);
  let headFrom = 0, headTo = eff.length;
  if (dm && !/^(Tough|Toughness|Sanity)\b/.test(dm[3])){
    w.found = true; w.dmg = dm[2]; headFrom = dm.index;
    if (dm[3] === 'PDMG' || dm[3] === 'Might'){ const ts = (dm[4] || dm[5] || '').split(/[\/,]/).map(cbNormType).filter(t=>CB_DTYPES.includes(t)); w.dtypes = ts.length ? [...new Set(ts)] : ['Physical']; }
    else w.dtypes = [cbNormType(dm[3].replace(/ Damage$/, ''))];
    const after = dm.index + dm[0].length; const cm = CB_COND_RX.exec(eff.slice(after)); if (cm) headTo = after + cm.index;
  } else { const cm = CB_COND_RX.exec(eff); if (cm) headTo = cm.index; }
  w.physical = cbIsPhysical(w.dtypes[0]);
  const head = eff.slice(headFrom, headTo);
  for (const [k, rx] of CB_PROPS) if (rx.test(eff)) w.props[k] = {on: rx.test(head)};
  const sh = /(\d+)\s*Sharpnel\b|\bSharpnel\s*(\d+)/.exec(eff); if (sh) w.sharpnel = Math.min(6, cbInt(sh[1] || sh[2]));
  const tp = /Perfect Strike[^,.·]{0,24}?\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(eff); if (tp) w.toughPerfect = Math.min(6, cbInt(tp[1]));
  const th = /\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(head); if (th) w.toughX = Math.min(6, cbInt(th[1]));
  // "On-Hit ... +N Toughness Damage" ที่ไม่มีเงื่อนไขอื่นนำหน้าในประโยคเดียวกัน = เข้าทุกครั้งที่โดน (เช่น ขวานศึก)
  const oh = !th ? /(?:Attack\s+)?On-?[Hh]it[^.·]{0,40}?\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(eff) : null;
  if (oh){ const before = eff.slice(0, oh.index); const sent = before.slice(Math.max(before.lastIndexOf('.'), before.lastIndexOf('·')) + 1); if (!/หาก|เมื่อ|ถ้า|Perfect|เลือก/.test(sent)) w.toughX = Math.min(6, cbInt(oh[1])); }
  if (w.toughX){ /* มีค่าแน่นอนแล้ว */ } else { const to = /\+\s*(\d+)\s*Tough(?:ness)?\s*Damage/.exec(eff.replace(/Perfect Strike[^,.·]{0,24}?\+\s*\d+\s*Tough(?:ness)?\s*Damage/, '')); if (to) w.toughOpt = Math.min(6, cbInt(to[1])); }
  w.bomb = /ชนิด:[^·]*ระเบิด/.test(eff);
  w.ranged = !!w.props.reload || /ชนิด:[^·]*(ธนู|ปืน|หน้าไม้|อาวุธเป่า|อาวุธปา|ระเบิด)/.test(eff) || cbItemCat(w.name) === 'อาวุธระยะไกล';
  w.statKind = (w.props.reload || /ชนิด:[^·]*(ปืน|หน้าไม้)/.test(eff)) ? 'sight' : (w.bomb ? 'none' : 'might'); // ไฟล์แกน: หน้าไม้และปืนบวก Sight อาวุธที่ใช้แรง (รวมธนู) บวก Might
  w.strNeed = (typeof weaponStrNeed === 'function' ? weaponStrNeed(raw) : 0) || cbInt((/ต้องการ STR\s*(\d+)/.exec(raw) || [])[1]);
  w.conds = cbFindConds(eff).filter(x=>CB_HIT_CONDS.has(x.id));
  return w;
}
/* ของพัง (Durability 0): PDMG เหลือครึ่งปัดลง และคุณสมบัติพิเศษหาย (ไฟล์แกน บทเศรษฐศาสตร์ ข้อ 3 · คำเคาะ 15 พ.ย. 2026) */
function cbBrokenWeapon(w){
  w.broken = true; if (/^\d+$/.test(w.dmg)) w.dmg = String(Math.floor(+w.dmg / 2)); else w.halve = true;
  for (const k of Object.keys(w.props)) w.props[k] = {on: false, lost: true};
  w.sharpnel = 0; w.toughX = 0; w.toughOpt = 0; w.toughPerfect = 0; w.conds = []; return w;
}
function cbBaseName(name){ const m = /\(([^()]+)\)\s*$/.exec(String(name || '')); return (m ? m[1] : String(name || '')).trim().toLowerCase(); }
/* การโจมตีในสแตตบล็อกของ NPC (เอกสาร Fauna, Enemy & Companion) เช่น "CV Bonus +2, Damage 1d6 + Might Piercing (มีคุณสมบัติ Rip)"
 * อ่าน CV Bonus · Range Attack · สูตรความเสียหาย (ตัวเลข เต๋า หรือ N PDMG) · ค่าพลังที่บวก · ชนิด · คุณสมบัติอาวุธ
 * บรรทัดที่เขียน N PDMG โดยไม่บอกค่าพลัง ใช้กฎเดียวกับผู้เล่น: บวก Might ส่วนหน้าไม้และปืนบวก Sight
 * บรรทัดที่ให้ทอย Saving Throw โดยไม่มี CV Bonus คือความสามารถที่ไม่ได้ทอยโจมตี (save:true) ใช้ทางแถบสกิล */
const CB_NPC_TYPES = '(?:Slashing|Slash|Piercing|Blunt|Physical|Fire|Plasma|Electric|Frost|Necrotic|Sonic|Acid|Corrode|Poison|Light)';
const CB_NPC_DMG_RX = new RegExp('(?:Damage\\s*)?(\\d{1,2}d\\d{1,3}(?:\\s*[+-]\\s*\\d{1,2})?|[Xx]d\\d{1,3}|\\d{1,3})\\s*(?:\\+\\s*(Might|Sight)\\s*)?(?:(PDMG)\\s*|Damage\\s*)?\\(?\\s*(' + CB_NPC_TYPES + '(?:\\s*/\\s*' + CB_NPC_TYPES + ')*)');
function cbParseNpcAttack(name, text){
  const raw = String(text || '').replace(/\\/g, '').slice(0, 600);
  const w = cbParseWeapon(name, raw); w.src = 'npc'; w.text = raw;
  const cvb = /CV\s*Bonus\s*\+?\s*(-?\d{1,2})/i.exec(raw); w.cvBonus = cvb ? Math.max(-9, Math.min(9, +cvb[1])) : 0;
  w.save = /Saving Throw/i.test(raw) && !cvb;
  const m = CB_NPC_DMG_RX.exec(raw.replace(/CV\s*Bonus\s*\+?\s*-?\d{1,2}\s*,?/i, ' '));
  if (m){
    w.found = true; w.dmg = m[1].replace(/\s+/g, ''); const ts = [...new Set(m[4].split('/').map(cbNormType).filter(t=>CB_DTYPES.includes(t)))]; w.dtypes = ts.length ? ts : ['Physical'];
    w.physical = cbIsPhysical(w.dtypes[0]); const gun = !!w.props.reload || /หน้าไม้|Crossbow|ปืน|Musket|Gun\b/i.test(w.name);
    w.statKind = m[2] ? m[2].toLowerCase() : (m[3] ? (gun ? 'sight' : 'might') : 'none');
  } else { w.found = false; w.dmg = '0'; w.statKind = 'none'; }
  w.ranged = !!w.ranged || /Rang(?:e|ed)\s+(?:Sorcery\s+)?Attack/i.test(raw);
  w.bomb = /ระเบิด|Bomb\b/i.test(w.name); w.thrown = w.bomb || /ขว้าง|\bThrow/i.test(w.name);
  return w;
}
/* เกราะที่หักจริงของหนึ่งส่วน อ่านด้วยตัวอ่านเดียวกับชีท (armorHits) ตามคำเคาะ 15 พ.ย. 2026:
 * โดนชนิดที่อยู่ในวงเล็บหักเกราะหลักบวกเกราะรองของชนิดนั้น · ชนิดอื่นหักเกราะหลักอย่างเดียว · ความเสียหายเวทหักเกราะหลักบวก Sorceries Resistance ของส่วนนั้น
 * extra = เกราะที่มีทั้งตัว (All Armor ของ NPC) นับเป็นเกราะหลัก · ข้อความที่จดเองนอกรูปแบบคืน known:false (ไม่เดา)
 * ค่าอัตโนมัติรุ่นก่อน v1.25 เขียน A/B ไม่มีวงเล็บ หมายถึงเกราะรองกัน Blunt (ชีทจะแปลงเป็น A/B (Blunt) เมื่อเจ้าของเปิดอีกครั้ง) จึงอ่านแบบเดียวกัน */
function cbArmorCut(text, dtype, physical, extra){
  const add = Math.max(0, cbInt(extra)); const s = String(text || '').trim();
  let r = s ? ((typeof armorHits === 'function') ? armorHits(s) : null) : {main: 0, sec: {}};
  if (!r){ const old = /^(\d+)\s*\/\s*(\d+)$/.exec(s); if (old) r = {main: +old[1], sec: {Blunt: +old[2]}}; }
  if (!r) return {known: false, main: add, sec: 0, v: add, any: add > 0, key: ''};
  const key = physical ? cbNormType(dtype) : 'Sorceries Resistance'; const sec = r.sec[key] || 0; const main = r.main + add;
  return {known: true, main, sec, v: main + sec, any: main > 0 || Object.values(r.sec).some(v=>v > 0), key};
}
/* ระยะกับแบบการโจมตี: ประชิดต้องอยู่เขตปะทะ (Reach เอื้อมได้อีกหนึ่งช่อง) · ขว้างได้ถึงเขตใกล้เคียง · ยิงเกินระยะแม่นหัก 1 CV ต่อทุก 1 เมตรที่เกิน (rangePenalty ของ map.js) */
function cbRangeVerdict(o){
  const cells = Math.max(0, o.cells | 0); const m = cells * CELL_M; const band = rangeBand(cells);
  if (o.mode === 'melee'){ const max = o.reach ? 2 : 1; const ok = cells <= max;
    return {ok, cv: 0, m, band, cls: ok ? 'ok' : 'bad', text: ok ? (cells > 1 ? `เป้าห่าง ${m} ม. เอื้อมถึงด้วย Reach` : `เป้าอยู่ในเขตปะทะ (${m} ม.) โจมตีประชิดได้`) : `ไกลเกิน: เป้าห่าง ${m} ม. (${band.label}) ต้องเข้าเขตปะทะก่อน`}; }
  if (o.mode === 'thrown'){ const ok = band.id !== 'far';
    return {ok, cv: 0, m, band, cls: ok ? 'ok' : 'bad', text: ok ? `เป้าห่าง ${m} ม. (${band.label}) ขว้างถึง` : `ไกลเกิน: อาวุธขว้างไปได้ถึงเขตใกล้เคียง (${NEAR_MAX_M} ม.) เป้าห่าง ${m} ม.`}; }
  const acc = o.acc || rangeAccM(0); const over = Math.max(0, m - acc); const cv = -rangePenalty(m, acc);
  return {ok: true, cv, m, band, acc, cls: cv ? 'warn' : 'ok', text: cv ? `เป้าห่าง ${m} ม. เกินระยะแม่น ${acc} ม. ไป ${over} ม. โดนลด CV ${cv} (ลด 1 ต่อทุก 1 ม. ที่เกิน)` : `เป้าห่าง ${m} ม. อยู่ในระยะแม่น ${acc} ม. ไม่โดนลด CV`};
}

/* ---------- 2. ตัวช่วยสร้างช่องกรอก ---------- */
function cbSelect(opts, val, on, attrs){ const el = h('select', attrs || null, opts.map(([v, l, dis])=>{ const o = h('option',{value:String(v), text:l}); if (dis) o.disabled = true; return o; })); el.value = String(val == null ? '' : val); el.onchange = ()=>on(el.value); return el; }
function cbNum(val, on, attrs, live){ const el = h('input', Object.assign({type:'number'}, attrs || {})); el.value = (val == null || val === '') ? '' : String(val); const fire = ()=>on(el.value === '' ? null : +el.value); if (live) el.oninput = fire; else el.onchange = fire; return el; }
function cbCheck(label, checked, on, attrs){ const box = h('input',{type:'checkbox'}); box.checked = !!checked; box.onchange = ()=>on(box.checked); return h('label', Object.assign({class:'fld chk'}, attrs || {}), box, h('span',{text:label})); }
/* ลูกของ Element.append: แตกอาร์เรย์และข้ามค่าว่าง (append ของเบราว์เซอร์พิมพ์ null กับอาร์เรย์ออกมาเป็นข้อความ) */
function cbKids(...a){ return a.flat(4).filter(x=>x != null && x !== false && x !== ''); }
function cbRollOf(r){ return {dice: (r.dice || []).slice(), kept: (r.kept || []).slice(), keptIdx: (r.keptIdx || []).slice(), sum: r.sum, double: !!r.double}; }

/* ---------- 3. Combat: สถานะและกติกา ---------- */
const Combat = {
  comp: null, ready: false, seen: new Set(), snooze: new Set(), timers: {}, prompting: null, done: new Set(), inited: new Set(),
  reset(){ this.closeComposer(); this.ready = false; this.seen = new Set(); this.snooze = new Set(); this.prompting = null; this.done = new Set(); for (const k of Object.keys(this.timers)) clearTimeout(this.timers[k]); this.timers = {}; if (typeof SkillUse !== 'undefined') SkillUse.reset(); },
  tok(id){ const r = Table.room; return r ? ((r.tokens || []).find(t=>t.id === id) || null) : null; },
  controls(t){ return !!t && (Table.localMode || Table.isGM() || ownsTok(t)); },
  charOf(t){ const c = t && t.charId ? Store.get(t.charId) : null;
    // ชีทของฉันที่ยังไม่เคยเปิด (หมากที่วางไว้ตั้งแต่รุ่นก่อน): เตรียมค่าปัจจุบัน กระเป๋า และของสวมใส่ก่อนเหมือนตอนเปิดชีท แล้วส่งสำเนาเข้าห้อง
    if (c && c.done && Store.isMine(c) && Store.chars.includes(c) && (!c.current || !c.equip || !c.inventory) && !this.inited.has(c.id)){ this.inited.add(c.id); try { ensureSheetState(c, compute(c)); Store.upsert(c); } catch(e){ console.warn('sheet init', e); } }
    return c; },
  derived(c){ try { return c ? compute(c) : null; } catch(e){ return null; } },
  levels(c){ try { return c ? knowledgeLevels(c) : {}; } catch(e){ return {}; } },
  has(t, id){ return !!t && (t.conds || []).some(c=>c.id === id); },
  side(t){ return t && t.kind === 'pc' ? 'pc' : 'npc'; },
  alive(t){ return !!t && t.kind !== 'asset' && !t.inside && (t.hp == null || t.hp > 0); },
  visible(r){ const gm = Table.isGM(); const vis = gm ? null : computeVisibility(r, Store.me); return (r.tokens || []).filter(t=>(gm || !t.hidden || ownsTok(t)) && (!vis || ownsTok(t) || vis.has(t.x + ',' + t.y)) && !t.inside); },
  myTokens(r){ return (r.tokens || []).filter(t=>t.kind !== 'asset' && !t.inside && this.controls(t)); },
  /* ค่าของผู้โจมตีและฝ่ายรับ: ตัวละครที่มีชีทอ่านจากชีท · NPC คิดจากค่าพลังดัดแปลงบนหมากด้วยสูตรเดียวกับผู้เล่น (Non เคาะ 16 พ.ย. 2026 ไม่มีช่องแก้เอง) */
  isNpc(t){ return !!t && !t.charId && t.kind === 'npc'; },
  npcDer(t){ return (this.isNpc(t) && typeof npcDerived === 'function') ? npcDerived(t.mods) : null; },
  atkStats(t){ const c = this.charOf(t); const d = this.derived(c); const nd = d ? null : this.npcDer(t);
    return {might: d ? d.might : (nd ? nd.might : 0), sight: d ? d.sight : (nd ? nd.sight : 0), rangeLv: (typeof tokenRangeLv === 'function') ? tokenRangeLv(t) : 0, sheet: !!d, npc: !!nd}; },
  defStats(t){ const c = this.charOf(t); const d = this.derived(c); const nd = d ? null : this.npcDer(t); const lv = this.levels(c);
    return {reflex: d ? d.reflex : (nd ? nd.reflex : 0), pd: Math.max(0, d ? cbInt(d.parryDice) : ((nd && typeof npcParryDice === 'function') ? npcParryDice(t.equip) : 0)), meleeLv: d ? (lv.melee || 0) : 0, sheet: !!d, npc: !!nd}; },
  weaponsOf(t){
    const out = []; const c = this.charOf(t); const d = this.derived(c);
    if (c && c.equip && !(c.shareMode === 'min' && !Store.isMine(c))){
      const slots = [...new Set([...(typeof WEAPON_SLOTS !== 'undefined' ? WEAPON_SLOTS : ['weapon1','weapon2','shield']), ...Object.keys(c.equip)])];
      for (const k of slots){ const e = c.equip[k]; if (!e || !(e.name || '').trim()) continue; const w = cbParseWeapon(e.name, e.effect); if (!w.found) continue; w.src = k; w.strShort = !!(w.strNeed && d && d.raw && (d.raw.STR || 0) < w.strNeed);
        if (typeof durBroken === 'function' && durBroken(e)) cbBrokenWeapon(w); out.push(w); }
      try { if (typeof hasFleshforge === 'function' && hasFleshforge(c) && c.fleshforge && c.fleshforge.item){ const w = cbParseWeapon(c.fleshforge.item, c.fleshforge.effect); if (w.found){ w.src = 'fleshforge'; out.push(w); } } } catch(e){}
    }
    if (this.isNpc(t)){ // การโจมตีในสแตตบล็อกก่อน แล้วตามด้วยอาวุธที่สวมซึ่งยังไม่มีบรรทัดโจมตีชื่อเดียวกัน
      const seen = new Set();
      for (const a of (Array.isArray(t.attacks) ? t.attacks : []).slice(0, 12)){ if (!a || typeof a !== 'object') continue; const w = cbParseNpcAttack(String(a.name || 'การโจมตี').slice(0, 80), a.text); if (w.save) continue; seen.add(cbBaseName(w.name)); out.push(w); }
      for (const e of (Array.isArray(t.equip) ? t.equip : []).slice(0, 16)){ if (!e || (e.slot !== 'weapon' && e.slot !== 'shield') || !(e.name || '').trim()) continue; const w = cbParseWeapon(e.name, e.effect); if (!w.found || seen.has(cbBaseName(w.name))) continue; w.src = 'npceq'; seen.add(cbBaseName(w.name)); out.push(w); }
    }
    out.push(Object.assign(cbParseWeapon('มือเปล่า (Unarmed)', '0 PDMG (Blunt)'), {src:'unarmed'}));
    out.push(Object.assign(cbParseWeapon('กำหนดเอง', ''), {src:'custom', found: true, dmg: '1', dtypes: CB_DTYPES.slice()}));
    return out;
  },
  /* ศัตรู (คนละฝั่ง pc กับ npc) ที่ยืนติดหมากนี้ */
  foesNear(r, t){ return (r.tokens || []).filter(o=>o !== t && this.alive(o) && !o.hidden && this.side(o) !== this.side(t) && cellDist(o, t) <= 1); },
  alliesNear(r, t){ return (r.tokens || []).filter(o=>o !== t && this.alive(o) && !o.hidden && this.side(o) === this.side(t) && cellDist(o, t) <= 1); },
  /* เหตุที่ทำให้ได้ Advantage ติด Disadvantage นับเป็น Perfect Strike หรือได้บวก CV: อ่านจากสภาวะบนหมากและตำแหน่งบนแผนที่ ผู้โจมตีติ๊กออกได้ทุกข้อ */
  atkReasons(r, a, t, w, mode, impact){
    const out = []; const add = (key, kind, label)=>out.push({key, kind, label}); const melee = mode === 'melee';
    if (t){
      if (this.has(t, 'Stunned') && melee) add('stun', 'adv', 'เป้าติด Stunned: โจมตีประชิดได้ Advantage');
      if (this.has(t, 'Prone')) add('prone', melee ? 'adv' : 'dis', melee ? 'เป้าติด Prone: โจมตีประชิดได้ Advantage' : 'เป้าติด Prone: โจมตีระยะไกลติด Disadvantage');
      if (this.has(t, 'Blinded')) add('tblind', 'adv', 'เป้าติด Blinded: การโจมตีใส่เป้าได้ Advantage');
      if (this.has(t, 'Invisible')) add('tinvis', 'dis', 'เป้า Invisible: การโจมตีใส่เป้าติด Disadvantage');
      if (this.has(t, 'Cover') && !melee) add('cover', 'dis', 'เป้ามี Cover: โจมตีระยะไกลติด Disadvantage');
      if (this.has(t, 'Incapacitated')) add('incap', 'perfect', 'เป้า Incapacitated: นับเป็น Perfect Strike');
      if (this.has(t, 'Marked')) add('marked', 'cv', 'เป้าติด Marked: CV บวกตาม Sight ของผู้โจมตี');
      if (melee && cellDist(a, t) <= 1 && this.side(a) !== this.side(t)){ const foes = this.foesNear(r, t).length; if (foes >= 2 && !this.alliesNear(r, t).length) add('gang', 'adv', `รุม: ศัตรู ${foes} ตัวอยู่ในเขตปะทะของเป้า และเป้าไม่มีพันธมิตรติดตัว`); }
      if (impact && melee && (this.has(t, 'Prone') || this.has(t, 'Stunned'))) add('impactp', 'perfect', 'Impact ใส่เป้าที่ติด Prone หรือ Stunned: Perfect Strike และความเสียหาย +1d3');
    }
    if (this.has(a, 'Prone')) add('aprone', 'dis', 'ผู้โจมตีติด Prone: Attack ติด Disadvantage');
    if (this.has(a, 'Poisoned')) add('apois', 'dis', 'ผู้โจมตีติด Poisoned: Attack ติด Disadvantage');
    if (this.has(a, 'Frightened')) add('afear', 'dis', 'ผู้โจมตีติด Frightened: Attack ติด Disadvantage');
    if (this.has(a, 'Blinded')) add('ablind', 'dis', 'ผู้โจมตีติด Blinded: Attack ติด Disadvantage');
    const gr = (a.conds || []).find(c=>c.id === 'Grappled'); if (gr && t && gr.by && gr.by !== t.id) add('agrap', 'dis', 'ผู้โจมตีถูกจับอยู่: โจมตีเป้าอื่นติด Disadvantage');
    if (this.has(a, 'Invisible')) add('ainvis', 'adv', 'ผู้โจมตี Invisible: Attack ได้ Advantage');
    if (this.has(a, 'Hidden')){ add('ahid', 'adv', 'โจมตีจากการซ่อนตัว: Advantage'); add('ahidp', 'perfect', 'โจมตีจากการซ่อนตัว: นับเป็น Perfect Strike'); }
    if (mode === 'ranged' && this.foesNear(r, a).length) add('reng', 'dis', 'ใช้อาวุธระยะไกลขณะมีศัตรูอยู่ในเขตปะทะ: Disadvantage');
    if (w && w.strShort) add('str', 'dis', `STR ไม่ถึง ${w.strNeed}: โจมตีด้วยอาวุธนี้ติด Disadvantage`);
    else if (w && w.strNeed && w.src === 'npceq') add('strq', 'dis', `อาวุธนี้ต้องมี STR ${w.strNeed}: ติ๊กเมื่อ STR ของ NPC ไม่ถึง (Disadvantage)`);
    return out;
  },

  /* ---------- 4. หน้าต่างโจมตี ---------- */
  openAttack(aid, tid, preset){
    const r = Table.room; if (!r){ toast('เปิดห้องก่อนจึงจะโจมตีได้'); return; }
    const mine = this.myTokens(r); if (!mine.length){ toast('ไม่มีหมากที่คุณบังคับได้บนบอร์ด วางตัวละครลงบอร์ดก่อน'); return; }
    let a = mine.find(t=>t.id === aid) || null;
    if (!a){ const sel = mine.find(t=>t.id === Table.sel); a = sel || mine[0]; }
    this.comp = {a: a.id, t: (tid && tid !== a.id) ? tid : null, wi: 0, off: {}, advX: false, disX: false, perfectX: false, dice: 2, cvX: 0, aim: '', hideName: !!a.hidden, nonLethal: false, far: false, cname: '', remember: false, preset: preset || null};
    this.syncWeapon(true);
    if (preset && preset.pick){ const key = cbBaseName(preset.pick); const i = this.comp.list.findIndex(x=>cbBaseName(x.name) === key); if (i >= 0){ this.comp.wi = i; this.syncWeapon(); } }
    document.body.classList.add('cb-picking'); this.drawComposer();
  },
  closeComposer(){ const had = !!this.comp; this.comp = null; if (!(typeof SkillUse !== 'undefined' && SkillUse.pick)) document.body.classList.remove('cb-picking'); const el = document.getElementById('atkc'); if (el) el.remove(); if (had && Table.room) setTimeout(()=>this.checkPrompts(), 60); },
  /* คลิกหมากบนแผนที่ระหว่างเปิดหน้าต่างโจมตี = เลือกเป้า (คืน true เมื่อรับคลิกไว้) */
  onTokenClick(t){
    if (typeof SkillUse !== 'undefined' && SkillUse.onTokenClick(t)) return true;
    const s = this.comp; if (!s) return false; if (t.id === s.a) return false;
    if (t.kind === 'asset' && !(t.hpMax > 0)){ toast('สิ่งของนี้ไม่ได้ตั้งค่าความทนทาน จึงเลือกเป็นเป้าไม่ได้'); return true; }
    s.t = t.id; this.drawDyn(); return true;
  },
  syncWeapon(first){
    const s = this.comp; const a = this.tok(s.a); if (!a) return; const list = this.weaponsOf(a);
    if (first && s.preset && s.preset.weapon){ list.unshift(s.preset.weapon); s.wi = 0; }
    s.list = list; if (s.wi >= list.length) s.wi = 0; const w = list[s.wi]; const st = this.atkStats(a);
    s.dmg = w.dmg; s.dtype = w.src === 'custom' ? 'Physical' : w.dtypes[0]; s.statKind = w.statKind; s.bonus = 0; s.toughX = w.toughX || 0; s.off.strq = true; // STR ของ NPC ไม่มีค่าดิบให้เทียบ เหตุข้อนี้จึงเริ่มแบบไม่ติ๊ก
    s.props = {ap: !!(w.props.ap && w.props.ap.on), gb: !!(w.props.gb && w.props.gb.on), impact: !!(w.props.impact && w.props.impact.on), headshot: !!(w.props.headshot && w.props.headshot.on), impale: !!(w.props.impale && w.props.impale.on), rip: false, wall: false, sharpnel: w.sharpnel || 0};
    s.mode = (s.preset && s.preset.mode && first) ? s.preset.mode : ((w.bomb || w.thrown) ? 'thrown' : (w.ranged ? 'ranged' : 'melee'));
    s.cname = w.src === 'custom' ? (s.cname || '') : ''; s.stats = st;
  },
  current(){
    const s = this.comp; const r = Table.room; if (!s || !r) return null; const a = this.tok(s.a); if (!a) return null; const t = s.t ? this.tok(s.t) : null;
    const w = s.list[s.wi] || s.list[0]; const st = this.atkStats(a);
    const cells = t ? cellDist(a, t) : 0; const reach = !!(w.props.reach) && !w.broken;
    const range = t ? cbRangeVerdict({mode: s.mode, cells, reach, acc: rangeAccM(st.rangeLv)}) : null;
    const reasons = this.atkReasons(r, a, t, w, s.mode, !!s.props.impact).map(x=>Object.assign(x, {on: !s.off[x.key]}));
    const act = (k)=>reasons.some(x=>x.kind === k && x.on);
    const adv = act('adv') || s.advX, dis = act('dis') || s.disX; const mode = adv && dis ? 'normal' : adv ? 'adv' : dis ? 'dis' : 'normal';
    const perfect = act('perfect') || s.perfectX; const impactX = (reasons.some(x=>x.key === 'impactp' && x.on) || s.props.wall) && s.props.impact;
    const statVal = s.statKind === 'none' ? 0 : (s.statKind === 'sight' ? st.sight : st.might);
    const cvParts = []; if (w.cvBonus) cvParts.push({label: 'CV Bonus', n: w.cvBonus}); if (range && range.cv) cvParts.push({label: 'ระยะ', n: range.cv}); if (s.aim) cvParts.push({label: 'Focus (Precise) Sight', n: st.sight}); if (reasons.some(x=>x.key === 'marked' && x.on)) cvParts.push({label: 'Marked', n: st.sight}); if (s.cvX) cvParts.push({label: 'ตัวปรับ', n: s.cvX});
    const cvMod = cvParts.reduce((x, p)=>x + p.n, 0);
    const base = Math.max(2, Math.min(4, s.dice | 0)); const n = base + (mode === 'normal' ? 0 : 1);
    let block = null; const c = this.charOf(a);
    if (!t) block = 'เลือกเป้าหมายก่อน (คลิกหมากบนแผนที่ หรือเลือกจากรายการ)';
    else if (range && !range.ok && !s.far) block = range.text;
    else if (/^x\s*d/i.test(String(s.dmg || '').trim())) block = 'สูตรความเสียหายของการโจมตีนี้มี X ที่ต้องนับเอง ใส่จำนวนลูกเต๋าแทน X ในช่องความเสียหาย (เช่น 3d3)';
    else if (!cbExprOk(s.dmg)) block = 'ความเสียหายของอาวุธต้องเป็นตัวเลขหรือรูปแบบเต๋า เช่น 2 หรือ 1d6+1';
    else if (c && Table.attackBlocked && Table.attackBlocked(c)) block = Table.attackBlocked(c);
    const los = (t && s.mode !== 'melee') ? losClear(r.map, a, t) : true;
    return {s, r, a, t, w, st, cells, range, reasons, mode, perfect, impactX, statVal, cvParts, cvMod, n, block, los};
  },
  /* วาดหน้าต่างโจมตี: ส่วนคงที่ (ช่องกรอก) วาดใหม่เมื่อโครงเปลี่ยน ส่วนที่คำนวณ (ระยะ เหตุ Advantage สรุป ปุ่มทอย) วาดใหม่ทุกครั้งที่ค่าเปลี่ยน
   * ช่องพิมพ์อัปเดตด้วย input แล้ววาดเฉพาะส่วนคำนวณ ช่องที่กำลังพิมพ์จึงไม่ถูกทำลายกลางคัน */
  drawComposer(){
    if (this.drawing){ this.redrawAgain = true; return; }
    const cur = this.current(); if (!cur){ this.closeComposer(); return; }
    this.drawing = true;
    try {
      const {s, r, a, w, st, statVal} = cur;
      let root = document.getElementById('atkc'); if (!root){ root = h('div',{id:'atkc',class:'atkc',role:'dialog','aria-label':'หน้าต่างโจมตี'}); document.body.append(...cbKids(root)); }
      const keepScroll = root.scrollTop; clear(root); const redraw = ()=>this.drawComposer(); const dyn = ()=>this.drawDyn(); const gm = Table.isGM() || Table.localMode;
      root.append(...cbKids(h('div',{class:'atkc-head'}, h('b',{text:'⚔ โจมตี'}), h('span',{class:'dim',text:' คลิกหมากบนแผนที่เพื่อเลือกเป้า'}), h('button',{class:'small ghost atkc-x',title:'ปิดหน้าต่างโจมตี',onclick:()=>this.closeComposer(),text:'✕'}))));
      const mine = this.myTokens(r);
      const tgts = this.visible(r).filter(x=>x.id !== a.id && (x.kind !== 'asset' || x.hpMax > 0));
      const grid = h('div',{class:'atkc-grid'});
      grid.append(...cbKids(h('label',{text:'ผู้โจมตี'}), mine.length > 1 ? cbSelect(mine.map(x=>[x.id, x.name]), a.id, (v)=>{ s.a = v; if (s.t === v) s.t = null; s.wi = 0; s.hideName = !!(this.tok(v) || {}).hidden; this.syncWeapon(); redraw(); }, {class:'atkc-a'}) : h('b',{class:'atkc-a',text:a.name})));
      grid.append(...cbKids(h('label',{text:'เป้าหมาย'}), cbSelect([['', 'เลือกเป้า หรือคลิกหมากบนแผนที่'], ...tgts.map(x=>[x.id, `${x.name} (${cellDist(a, x) * CELL_M} ม.)`])], s.t || '', (v)=>{ s.t = v || null; dyn(); }, {class:'atkc-t'})));
      grid.append(...cbKids(h('label',{text:'อาวุธ'}), cbSelect(s.list.map((x, i)=>[i, x.name + (x.found && x.src !== 'custom' ? ` · ${x.dmg} ${x.dtypes.join('/')}` : '')]), s.wi, (v)=>{ s.wi = +v; this.syncWeapon(); redraw(); }, {class:'atkc-w'})));
      if (w.src === 'custom'){ const nm = h('input',{class:'atkc-cname',placeholder:'ชื่อการโจมตี เช่น กรงเล็บ',maxlength:60}); nm.value = s.cname || ''; nm.oninput = ()=>{ s.cname = nm.value.trim().slice(0, 60); }; grid.append(...cbKids(h('label',{text:'ชื่อ'}), nm)); }
      const dmgInp = h('input',{class:'atkc-dmg',title:'ความเสียหายตั้งต้นของอาวุธ ตัวเลขหรือรูปแบบเต๋า เช่น 2 หรือ 1d6+1',style:'width:74px'}); dmgInp.value = s.dmg; dmgInp.oninput = ()=>{ s.dmg = dmgInp.value.trim(); dyn(); };
      const types = (w.src === 'custom' || (w.src === 'npc' && !w.found)) ? CB_DTYPES : w.dtypes;
      grid.append(...cbKids(h('label',{text:'ความเสียหาย'}), h('div',{class:'row',style:'gap:6px'}, dmgInp, types.length > 1 ? cbSelect(types.map(x=>[x, x]), s.dtype, (v)=>{ s.dtype = v; dyn(); }, {class:'atkc-dtype',title:'ประเภทความเสียหายของการโจมตีครั้งนี้'}) : tag(s.dtype, 'prop'),
        cbSelect([['might', `+ Might ${signed(st.might)}`], ['sight', `+ Sight ${signed(st.sight)}`], ['none', 'ไม่บวกค่าพลัง']], s.statKind, (v)=>{ s.statKind = v; redraw(); }, {class:'atkc-stat',title:'อาวุธประชิดหรืออาวุธที่ใช้แรงบวก Might ส่วนหน้าไม้และปืน (Reload) บวก Sight' + (st.npc ? ' · ค่าของ NPC คิดจากค่าพลังดัดแปลงบนหมาก' : '')}),
        h('span',{class:'dim',text:'โบนัส'}), cbNum(s.bonus || '', (v)=>{ s.bonus = v || 0; dyn(); }, {class:'atkc-bonus',style:'width:56px',placeholder:'0',title:'ความเสียหายเพิ่มจากสกิล ท่ายืน หรือ Proficiency'}, true))));
      const modeBtn = (k, label, tip)=>h('button',{class:'small atkc-mode' + (s.mode === k ? ' primary' : ''),dataset:{mode:k},title:tip,onclick:()=>{ s.mode = k; redraw(); },text:label});
      grid.append(...cbKids(h('label',{text:'แบบการโจมตี'}), h('div',{class:'row',style:'gap:6px'}, modeBtn('melee', 'ประชิด', 'ต้องอยู่เขตปะทะ อาวุธ Reach เอื้อมได้อีกหนึ่งช่อง'), modeBtn('thrown', 'ขว้าง', 'ขว้างได้ถึงเขตใกล้เคียง ไม่ติด Disadvantage จากการมีศัตรูประชิด'), modeBtn('ranged', 'ยิง', 'เกินระยะแม่นหัก 1 CV ต่อทุก 1 เมตรที่เกิน มีศัตรูในเขตปะทะติด Disadvantage'))));
      root.append(...cbKids(grid, h('div',{class:'atkc-dyn1'})));
      // ตัวเลือกการทอย
      root.append(...cbKids(h('div',{class:'row atkc-opts',style:'gap:6px'}, cbSelect([[2, 'Combat Dice 2 ลูก'], [3, 'Combat Dice 3 ลูก'], [4, 'Combat Dice 4 ลูก']], s.dice, (v)=>{ s.dice = +v; dyn(); }, {class:'atkc-dice',title:'ปกติ 2 ลูก สกิลหรืออาวุธบางอย่างเพิ่มให้'}),
        cbNum(s.cvX || '', (v)=>{ s.cvX = v || 0; dyn(); }, {class:'atkc-cvx',style:'width:92px',placeholder:'ตัวปรับ CV',title:'ตัวปรับ CV อื่น เช่น ปืนที่ไม่ได้ Focus ก่อนยิง'}, true),
        cbSelect([['', 'ไม่เล็ง (ตำแหน่งตามเต๋า)'], ...DATA.meta.bodyParts.map(([k, l])=>[k, 'เล็ง' + l])], s.aim, (v)=>{ s.aim = v; dyn(); }, {class:'atkc-aim',title:'Focus (Precise): ได้บวก CV ตาม Sight และตำแหน่งไม่เปลี่ยนตามเต๋า'}))));
      // คุณสมบัติของการโจมตีครั้งนี้
      const pr = h('div',{class:'atkc-props'}); const propBox = (k, label, tip, full)=>cbCheck(label, s.props[k], (v)=>{ s.props[k] = v; if (full) redraw(); else dyn(); }, {class:'fld chk pp' + (w.props[k] ? '' : ' off'),title:tip,dataset:{prop:k}});
      pr.append(...cbKids(propBox('ap', 'Armor Penetrate', 'เกราะของจุดที่โดนเหลือครึ่งเดียว (ปัดลง)'), propBox('gb', 'Guard Break', 'ฝ่ายรับ Parry แบบ Advantage ไม่ได้ และไม่ได้ Parry Dice'), propBox('impact', 'Impact', 'โดนเป้าที่ติด Prone หรือ Stunned หรือผลักไปชนกำแพง = Perfect Strike และ +1d3', true), propBox('headshot', 'Headshot', 'เต๋าออกตำแหน่งศีรษะ (ไม่ได้เล็ง) = Perfect Strike'), propBox('impale', 'Impale', 'โดนแล้วเป้าติด Rooted')));
      if (s.props.impact) pr.append(...cbKids(cbCheck('ผลักไปชนกำแพง', s.props.wall, (v)=>{ s.props.wall = v; dyn(); }, {class:'fld chk pp',dataset:{prop:'wall'}})));
      if (w.props.rip || w.src === 'custom') pr.append(...cbKids(cbCheck('Rip: เปลี่ยนเป็น Bleeding ถ้าจุดที่โดนไม่มีเกราะ', s.props.rip, (v)=>{ s.props.rip = v; }, {class:'fld chk pp',dataset:{prop:'rip'},title:'เป้าติด Bleeding เท่ากับความเสียหายที่จะเข้า HP แทนการเสีย HP'})));
      pr.append(...cbKids(h('label',{class:'fld'}, h('span',{text:'Toughness Damage เพิ่ม'}), cbNum(s.toughX || '', (v)=>{ s.toughX = Math.max(0, Math.min(6, v || 0)); }, {class:'atkc-toughx',style:'width:52px',placeholder:'0',min:0,max:6}, true)), h('label',{class:'fld'}, h('span',{text:'Sharpnel'}), cbNum(s.props.sharpnel || '', (v)=>{ s.props.sharpnel = Math.max(0, Math.min(6, v || 0)); }, {class:'atkc-sharp',style:'width:52px',placeholder:'0',min:0,max:6}, true)),
        cbCheck('Non-Lethal', s.nonLethal, (v)=>{ s.nonLethal = v; }, {class:'fld chk pp',dataset:{prop:'nl'},title:'Focus (Non-Lethal): ทำความเสียหายกับ HP อย่างเดียว ไม่ลด Toughness ไม่ติดสภาวะทางกาย'})));
      if (w.toughOpt) pr.append(...cbKids(h('span',{class:'dim',style:'font-size:11.5px',text:`อาวุธนี้มี +${w.toughOpt} Toughness Damage แบบมีเงื่อนไข ใส่ตัวเลขเองเมื่อเข้าเงื่อนไข`})));
      root.append(...cbKids(pr));
      if (a.hidden) root.append(...cbKids(cbCheck('ปกปิดชื่อผู้โจมตีในแชต (หมากนี้ซ่อนอยู่)', s.hideName, (v)=>{ s.hideName = v; }, {class:'fld chk atkc-hide'})));
      if (gm && st.npc && w.src === 'custom') root.append(...cbKids(cbCheck('จำการโจมตีนี้ไว้ในสแตตบล็อกของหมาก', s.remember, (v)=>{ s.remember = v; }, {class:'fld chk atkc-rem',title:'เพิ่มเป็นบรรทัดการโจมตีของหมากตัวนี้ แก้หรือลบได้ที่แผงหมาก'})));
      if (w.text && w.src !== 'unarmed') root.append(...cbKids(h('details',{class:'atkc-eff'}, h('summary',{text:'ข้อความเอฟเฟกต์ของอาวุธ'}), h('div',{class:'desc',style:'font-size:12px'}, T(w.text)))));
      root.append(...cbKids(h('div',{class:'atkc-dyn2'})));
      root.scrollTop = keepScroll;
    } finally { this.drawing = false; }
    this.drawDyn();
    if (this.redrawAgain){ this.redrawAgain = false; this.drawComposer(); }
  },
  /* ส่วนที่คำนวณของหน้าต่างโจมตี: ระยะ คำเตือน เหตุของ Advantage และ Disadvantage สรุปการทอย และปุ่มทอย */
  drawDyn(){
    const root = document.getElementById('atkc'); if (!root) return; const d1 = root.querySelector('.atkc-dyn1'), d2 = root.querySelector('.atkc-dyn2'); if (!d1 || !d2) return;
    const cur = this.current(); if (!cur){ this.closeComposer(); return; }
    const {s, r, a, t, w, range, reasons, mode, perfect, statVal, cvParts, cvMod, n} = cur; const dyn = ()=>this.drawDyn(); const gm = Table.isGM() || Table.localMode;
    const tSel = root.querySelector('.atkc-t'); if (tSel && tSel.value !== (s.t || '')) tSel.value = s.t || '';
    clear(d1); clear(d2);
    if (s.mode === 'thrown' && !w.props.throwable && w.src !== 'custom' && !w.bomb) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'อาวุธนี้ไม่มีคุณสมบัติ Throwable ขว้างได้เมื่อมีความสามารถรองรับ (เช่น Trickster) หรือ GM อนุญาต'})));
    if (w.broken) d1.append(...cbKids(h('div',{class:'atkc-note warn atkc-broken',text:'อาวุธนี้พัง (Durability 0): PDMG เหลือครึ่งปัดลง และคุณสมบัติพิเศษหาย'})));
    if (w.src === 'npc' && !w.found) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'ระบบอ่านสูตรความเสียหายจากบรรทัดการโจมตีนี้ไม่ออก ใส่ความเสียหายและประเภทเองได้ในช่องด้านบน'})));
    if (range) d1.append(...cbKids(h('div',{class:'atkc-range ' + range.cls,text:range.text})));
    if (range && !range.ok && gm) d1.append(...cbKids(cbCheck('โจมตีทั้งที่ไกลเกิน (GM อนุญาต)', s.far, (v)=>{ s.far = v; dyn(); }, {class:'fld chk atkc-far'})));
    if (t && !cur.los) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'มีสิ่งกีดขวางบังแนวยิงระหว่างสองหมาก ให้ GM ตัดสินว่ายิงได้ไหม'})));
    if (w.props.delay && r.enc && r.enc.active && r.enc.order[r.enc.turnIdx] !== a.id && r.enc.order[r.enc.turnIdx] !== a.turnWith) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:'อาวุธนี้มี Delay ใช้โจมตีได้เฉพาะในเทิร์นของตัวเอง'})));
    if (a.hp != null && a.hp <= 0) d1.append(...cbKids(h('div',{class:'atkc-note warn',text:`${a.name} เหลือ HP 0 ให้ GM ตัดสินว่ายังลงมือได้ไหม`})));
    const rs = h('div',{class:'atkc-reasons'});
    for (const x of reasons) rs.append(...cbKids(cbCheck(x.label, x.on, (v)=>{ s.off[x.key] = !v; dyn(); }, {class:'fld chk rs-' + x.kind,dataset:{key:x.key}})));
    rs.append(...cbKids(h('div',{class:'row',style:'gap:10px'}, cbCheck('Advantage อื่น', s.advX, (v)=>{ s.advX = v; dyn(); }, {class:'fld chk atkc-advx'}), cbCheck('Disadvantage อื่น', s.disX, (v)=>{ s.disX = v; dyn(); }, {class:'fld chk atkc-disx'}), cbCheck('นับเป็น Perfect Strike', s.perfectX, (v)=>{ s.perfectX = v; dyn(); }, {class:'fld chk atkc-perfx',title:'สกิลหรือสถานการณ์ที่ให้ Perfect Strike โดยไม่ต้องทอยได้หน้าเหมือน'}))));
    d1.append(...cbKids(rs));
    const avg = cbExprAvg(s.dmg) + (s.statKind === 'none' ? 0 : statVal * (perfect ? 2 : 1)) + (s.bonus || 0);
    d2.append(...cbKids(h('div',{class:'atkc-sum'}, h('span',{text:`ทอย ${n}d6${mode === 'adv' ? ' Advantage ผู้โจมตีเลือก 2 ลูก' : mode === 'dis' ? ' Disadvantage ฝ่ายรับเลือก 2 ลูก' : (n > 2 ? ' ผู้โจมตีเลือก 2 ลูก' : '')}`}), cvMod ? h('span',{class:'num',text:` · CV ${signed(cvMod)} (${cvParts.map(p=>p.label + ' ' + signed(p.n)).join(', ')})`}) : null,
      h('span',{class:'num',text:` · ถ้าโดน ${s.dmg}${s.statKind !== 'none' && statVal ? ` ${signed(statVal)}${perfect ? '×2' : ''}` : ''}${s.bonus ? ' ' + signed(s.bonus) : ''}${/d/i.test(s.dmg) ? ` (เฉลี่ย ${Math.round(avg * 10) / 10})` : ` = ${avg}`} ${s.dtype}`}))));
    const go = h('button',{class:'primary atkc-go',onclick:()=>this.fire(),text:'🎲 ทอยโจมตี'}); if (cur.block){ go.disabled = true; d2.append(...cbKids(h('div',{class:'atkc-note bad atkc-block',text:cur.block}))); }
    d2.append(...cbKids(h('div',{class:'row',style:'justify-content:flex-end;gap:8px;margin-top:8px'}, h('button',{class:'small ghost',onclick:()=>this.closeComposer(),text:'ยกเลิก'}), go)));
    this.markTarget();
  },
  /* วงแดงรอบหมากที่ถูกเลือกเป็นเป้า */
  markTarget(){ for (const el of document.querySelectorAll('.gridmap .gtok.cb-tgt')) el.classList.remove('cb-tgt'); const id = this.comp && this.comp.t; if (!id) return; const el = document.querySelector('#v-table .gridmap .gtok[data-id="' + String(id).replace(/[^A-Za-z0-9_-]/g, '') + '"]'); if (el) el.classList.add('cb-tgt'); },
  /* ทอยโจมตีตามค่าที่ตั้งในหน้าต่าง แล้วโพสต์เป็นข้อความที่รอฝ่ายรับ */
  fire(){
    const cur = this.current(); if (!cur || cur.block){ if (cur && cur.block) toast(cur.block); return; }
    const {s, r, a, t, w, mode, perfect, impactX, statVal, cvParts, cvMod, n, cells, reasons} = cur;
    const wname = w.src === 'custom' ? (s.cname || 'การโจมตี') : w.name; const who = (a.hidden && s.hideName) ? 'บางสิ่งที่มองไม่เห็น' : a.name;
    const flow = {v: 1, type: 'attack', a: {id: a.id, name: who, kind: a.kind}, t: {id: t.id, name: t.name, kind: t.kind}, mode: s.mode, cells, m: cells * CELL_M,
      w: {name: wname, dmg: s.dmg, dtype: s.dtype, physical: cbIsPhysical(s.dtype), stat: s.statKind === 'none' ? 0 : statVal, statKind: s.statKind, bonus: s.bonus || 0, toughX: s.toughX || 0, toughPerfect: w.toughPerfect || 0, sharpnel: s.props.sharpnel || 0, ripBleed: !!s.props.rip, ap: !!s.props.ap, gb: !!s.props.gb, impact: !!s.props.impact, impactX: !!impactX, headshot: !!s.props.headshot, impale: !!s.props.impale, nonLethal: !!s.nonLethal, conds: (w.conds || []).slice(0, 6), halve: !!w.halve, broken: !!w.broken, skill: (s.preset && s.preset.skill) || null},
      perfect: !!perfect, reasons: reasons.filter(x=>x.on).map(x=>x.label).concat(s.advX ? ['Advantage อื่น'] : [], s.disX ? ['Disadvantage อื่น'] : []).slice(0, 10), cvParts};
    const aim = s.aim || null; const label = `โจมตี ${t.name} ด้วย ${wname}` + (aim ? ` · เล็ง${partLabel(aim)}` : '');
    const id = 'atk-' + uid(); const spent = reasons.filter(x=>x.on && (x.key === 'ahid' || x.key === 'ainvis')).map(x=>x.key === 'ahid' ? 'Hidden' : 'Invisible');
    if (s.remember && w.src === 'custom' && this.controls(a) && this.isNpc(a)){ // เก็บเป็นบรรทัดการโจมตีแบบเดียวกับสแตตบล็อก ตัวอ่านเดียวกันอ่านกลับได้
      const line = `${s.mode === 'melee' ? '' : 'Range Attack, '}CV Bonus +0, Damage ${s.dmg}${s.statKind === 'might' ? ' + Might' : s.statKind === 'sight' ? ' + Sight' : ''} ${s.dtype}`;
      a.attacks = [{name: wname, text: line}, ...(Array.isArray(a.attacks) ? a.attacks : []).filter(x=>x && x.name !== wname)].slice(0, 12); Table.save(); }
    const run = async ()=>{
      if (mode === 'dis'){ const dice = Array.from({length: n}, rollD6); Table.post({kind: 'pick', fixedId: id, who, text: label, dice, cvMod, loc: aim, gmOnly: false, flow}); toast('ทอยแล้ว รอฝ่ายรับหรือ GM เลือก 2 ลูกในแชต'); return; }
      const rr = n > 2 ? await rollChoose(n, mode, `โจมตี ${t.name}: ทอย ${n}d6 เลือก 2 ลูก`, {kind: 'attack', cvMod, loc: aim}) : roll2d6('normal');
      const av = attackVerdict(rr, {cvMod, loc: aim});
      Table.post({kind: 'roll', fixedId: id, who, text: label, roll: {dice: rr.dice, kept: rr.kept, keptIdx: rr.keptIdx, sum: rr.sum, crit: null, double: rr.double, mode, chosen: !!rr.chosen}, mod: cvMod, pm: 0, total: av.cv, judge: {cls: av.cls, text: av.text}, atk: {sum: av.sum, cv: av.cv, part: av.part || null, precise: av.precise, cvMod, pick: n > 2 ? 'atk' : null}, gmOnly: false, flow});
    };
    Table.guardedRoll(who, async ()=>{ this.closeComposer(); await run(); for (const idc of spent){ const ac = (a.conds || []).find(c=>c.id === idc); if (ac) removeCond(a, r, ac, 'ลงมือโจมตีแล้ว'); } }, label);
  },

  /* ---------- 5. ฝ่ายรับ ---------- */
  isAttack(m){ return !!(m && m.kind === 'roll' && m.flow && m.flow.type === 'attack' && m.roll && m.flow.t && m.flow.a); },
  resolved(m){ return Table.chat.some(x=>x.kind === 'clash' && x.of === m.id); },
  canRespond(m){ const t = this.tok(m.flow.t.id); return !!t && this.controls(t); },
  ownerHere(t){ return !!(t && t.ownerId && !t.gmRun && (Table.peers || []).some(p=>p && p.who === t.ownerId)); },
  /* ฉันเป็นคนแรกที่ควรตอบไหม: เจ้าของหมากตอบเอง · GM ตอบแทนเมื่อเป็น NPC หรือเจ้าของไม่อยู่ในห้อง */
  primary(m){ const t = this.tok(m.flow.t.id); if (!t) return false; if (Table.localMode) return true; if (ownsTok(t)) return true; return Table.isGM() && !this.ownerHere(t); },
  pending(){ const now = Date.now(); return Table.chat.filter(m=>this.isAttack(m) && now - (m.ts || 0) < CB_PENDING_MS && !this.resolved(m)).sort((x, y)=>(x.ts || 0) - (y.ts || 0)); },
  /* เรียกทุกครั้งที่แชตของห้องเปลี่ยน: เล่นเอฟเฟกต์ของข้อความใหม่ และเด้งหน้าต่างป้องกันให้คนที่ต้องตอบ */
  onChat(){
    if (!Table.room) return; const now = Date.now(); const gm = Table.isGM(); const first = !this.ready; this.ready = true;
    const fresh = Table.chat.filter(m=>m && m.id && !this.seen.has(m.id)).sort((x, y)=>(x.ts || 0) - (y.ts || 0));
    for (const m of fresh){ this.seen.add(m.id); if (first || now - (m.ts || 0) > 20000) continue; if (m.gmOnly && !gm && m.authorId !== Store.me) continue;
      if (m.kind === 'clash') DiceShow.enqueue(m);
      else if (m.kind === 'skill' && typeof SkillUse !== 'undefined') SkillUse.onMessage(m);
      else if (m.fx) setTimeout(()=>Fx.play(m.fx), m.kind === 'roll' ? ROLL_SHOW_MS : 0); }
    if (this.prompting){ const pm = Table.chat.find(x=>x.id === this.prompting); if (!pm || this.resolved(pm)){ this.prompting = null; modal(null); toast('การโจมตีนี้มีคนตัดสินผลไปแล้ว'); } }
    this.checkPrompts();
  },
  checkPrompts(){
    if (this.prompting || this.comp) return; const now = Date.now();
    const m = this.pending().find(x=>!this.snooze.has(x.id) && this.canRespond(x) && this.primary(x)); if (!m || this.timers[m.id]) return;
    const wait = Math.max(150, ROLL_SHOW_MS + 250 - (now - (m.ts || 0)));
    const open = ()=>{ delete this.timers[m.id]; if (this.prompting || this.comp || this.resolved(m) || !Table.room) return;
      if (DiceShow.cur || Table.rolling){ this.timers[m.id] = setTimeout(open, 500); return; } // รอให้ป๊อปอัปเต๋าบนจอจบก่อน
      const lone = this.tok(m.flow.t.id); if (lone && lone.kind === 'asset'){ this.autoHit(m); return; } this.openDefense(m); };
    this.timers[m.id] = setTimeout(open, wait);
  },
  /* สิ่งของไม่ป้องกัน: ตัดสินเป็นโดนทันที */
  autoHit(m){ Table.guardedRoll(m.flow.t.name, ()=>{ this.resolve(m, {kind: 'none', success: false, text: 'สิ่งของไม่ป้องกัน'}, {}); }, 'รับการโจมตี'); },
  defReasons(t, f, st){
    const parry = [], evade = []; const unb = this.has(t, 'Unbalanced');
    if (unb){ parry.push({key: 'unbal', kind: 'dis', label: 'Unbalanced: การป้องกันทุกแบบติด Disadvantage'}); evade.push({key: 'unbal', kind: 'dis', label: 'Unbalanced: การป้องกันทุกแบบติด Disadvantage'}); }
    if (f.mode === 'melee') evade.push({key: 'evm', kind: 'dis', label: 'Evade การโจมตีระยะประชิด: Disadvantage'});
    if (f.mode !== 'melee' && st.meleeLv < 3) parry.push({key: 'prr', kind: 'dis', label: 'Parry การโจมตีระยะไกล: ต้องได้ Perfect Parry'});
    if (f.w && f.w.gb) parry.push({key: 'gb', kind: 'gb', label: 'Guard Break: Parry แบบ Advantage ไม่ได้ และไม่ได้ Parry Dice'});
    return {parry, evade};
  },
  openDefense(m){
    const r = Table.room; if (!r || !this.isAttack(m)) return; if (this.resolved(m)){ toast('การโจมตีนี้ตัดสินผลไปแล้ว'); return; }
    const f = m.flow; const t = this.tok(f.t.id); if (!t){ toast('หมากเป้าหมายไม่อยู่บนบอร์ดแล้ว'); return; } if (!this.canRespond(m)){ toast('การป้องกันเป็นของเจ้าของหมากหรือ GM'); return; }
    const atk = m.atk || {}; const sum = m.roll.sum; const cv = atk.cv != null ? atk.cv : sum; const precise = !!atk.precise; const part = atk.part || hitPart(sum) || 'torso';
    const base = this.defStats(t); const gm = Table.isGM() || Table.localMode; const isPc = !!(t.charId && t.kind === 'pc');
    const pref = (this.isNpc(t) && ['parry','evade','both','none'].includes(t.defend)) ? t.defend : ''; // วิธีป้องกันที่สแตตบล็อกของ NPC ระบุ
    const st = {reflex: base.reflex, pd: base.pd, pdUse: base.pd, meleeLv: base.meleeLv, off: {}, advX: false, disX: false, weak: false, resist: 0, force: false, view: 'main', skill: null};
    const box = h('div',{class:'defbox'});
    const blocked = ()=> (this.has(t, 'Stunned') ? 'Stunned' : this.has(t, 'Incapacitated') ? 'Incapacitated' : null);
    const plan = (kind)=>{ const rs = this.defReasons(t, f, st)[kind].map(x=>Object.assign(x, {on: !st.off[kind + x.key]})); const gb = rs.some(x=>x.kind === 'gb' && x.on); const dis = rs.some(x=>x.kind === 'dis' && x.on) || st.disX; const adv = st.advX && !(kind === 'parry' && gb);
      const mode = adv && dis ? 'normal' : adv ? 'adv' : dis ? 'dis' : 'normal'; const pd = (kind === 'parry' && !gb) ? Math.max(0, Math.min(st.pd, st.pdUse)) : 0;
      const n = kind === 'parry' ? (mode === 'dis' ? 2 : parryDiceCount(pd, mode === 'adv')) : (mode === 'normal' ? 2 : 3);
      return {rs, gb, mode, pd, n}; };
    const used = !!(r.enc && r.enc.active && t.pd && t.pd.round === r.enc.round);
    const draw = ()=>{
      clear(box); const redraw = draw;
      box.append(...cbKids(h('h3',{text:`🛡 ${f.a.name} โจมตี ${t.name}`})));
      box.append(...cbKids(h('div',{class:'def-atk'}, h('div',{class:'row',style:'gap:8px;justify-content:center'}, renderDice({dice: m.roll.dice || [], keptIdx: m.roll.keptIdx || []}), h('b',{class:'num',text:`เต๋า ${sum}${cv !== sum ? ' → CV ' + cv : ''}`}), tag(partLabel(part) + (precise ? ' (เล็ง)' : ''), 'neg'), (m.roll.double || f.perfect) ? tag('Perfect Strike', 'prop') : null),
        h('div',{class:'dim',style:'font-size:12.5px;margin-top:4px',text:`${f.w.name} · ${f.mode === 'melee' ? 'ประชิด' : f.mode === 'thrown' ? 'ขว้าง' : 'ยิง'} ระยะ ${f.m} ม. · ถ้าโดน ${f.w.dmg}${f.w.stat ? ' ' + signed(f.w.stat) + ((m.roll.double || f.perfect) ? '×2' : '') : ''}${f.w.bonus ? ' ' + signed(f.w.bonus) : ''} ${f.w.dtype}${f.w.ap ? ' · Armor Penetrate' : ''}${f.w.gb ? ' · Guard Break' : ''}`}))));
      if (st.view === 'skill'){ this.defSkillView(box, m, t, st, redraw, plan, go); return; }
      const why = blocked(); const lock = !!why && !st.force;
      if (why) box.append(...cbKids(h('div',{class:'atkc-note bad',text:`${t.name} ติด ${why} จึงป้องกันไม่ได้`}), gm ? cbCheck('ให้ป้องกันได้ (GM ตัดสิน)', st.force, (v)=>{ st.force = v; redraw(); }, {class:'fld chk def-force'}) : null));
      if (used) box.append(...cbKids(h('div',{class:'atkc-note warn',text:'รอบนี้ใช้ Perfect Defense ไปแล้ว ทอยได้เลขเท่าผลโจมตีอีกจะไม่นับเป็น Perfect'})));
      if (base.npc) box.append(...cbKids(h('div',{class:'dim def-npc',style:'font-size:12.5px;text-align:center;margin-top:4px',text:`${t.name}: Reflex ${signed(st.reflex)} · Parry Dice ${st.pd} (คิดจากค่าพลังดัดแปลงและของที่สวม)` + (pref ? ` · สแตตบล็อกระบุ ${pref === 'parry' ? 'Parry' : pref === 'evade' ? 'Evade' : pref === 'both' ? 'Parry หรือ Evade' : 'ไม่ป้องกัน'}` : '') + (t.defendNote ? ` (${String(t.defendNote).slice(0, 120)})` : '')})));
      const pp = plan('parry'), ev = plan('evade');
      const nums = HIT_DEFEND[part] || [];
      const pText = pp.mode === 'dis' ? `ทอย 2d6 ต้องได้ ${sum} พอดี (Perfect Parry)` : `ทอย ${pp.n}d6${pp.n > 2 ? ' เลือก 2 ลูก' : ''} กันได้เมื่อผลรวมเป็น ${nums.join(' หรือ ')}`;
      const eText = `ทอย ${ev.n}d6${ev.mode === 'dis' ? ' ใช้ 2 ลูกต่ำสุด' : ev.mode === 'adv' ? ' เลือก 2 ลูก' : ''} บวก Reflex ${signed(st.reflex)} ต้องถึง ${cv}`;
      const lead = (kind)=> !pref || pref === 'both' || pref === kind; // ปุ่มที่ตรงกับสแตตบล็อกเป็นปุ่มเด่น
      const col = (kind, pl, title, text, extra)=>h('div',{class:'def-col'}, h('button',{class:(lead(kind) ? 'primary ' : '') + 'def-' + kind,disabled: lock,onclick:()=>go(kind),text:title}), h('div',{class:'dim def-how',text:text}), extra || null, pl.rs.map(x=>cbCheck(x.label, x.on, (v)=>{ st.off[kind + x.key] = !v; redraw(); }, {class:'fld chk rs-' + x.kind})));
      const pdSel = (st.pd > 0 && !pp.gb && pp.mode !== 'dis') ? h('label',{class:'fld def-pdsel'}, h('span',{text:'ใช้ Parry Dice'}), cbSelect(Array.from({length: st.pd + 1}, (_, i)=>[i, `${i} ลูก`]), Math.min(st.pd, st.pdUse), (v)=>{ st.pdUse = +v; redraw(); }, {class:'def-pduse'})) : null;
      box.append(...cbKids(h('div',{class:'def-cols'}, col('parry', pp, `🛡 Parry ${pp.n}d6`, pText, pdSel), col('evade', ev, `💨 Evade ${ev.n}d6${st.reflex ? ' ' + signed(st.reflex) : ''}`, eText, null))));
      box.append(...cbKids(h('div',{class:'row',style:'gap:10px;justify-content:center;margin-top:6px'}, cbCheck('Advantage (สกิลหรือสถานการณ์)', st.advX, (v)=>{ st.advX = v; redraw(); }, {class:'fld chk def-advx'}), cbCheck('Disadvantage เพิ่ม', st.disX, (v)=>{ st.disX = v; redraw(); }, {class:'fld chk def-disx'}))));
      const adj = h('details',{class:'def-adj'}, h('summary',{text:'ตัวปรับความเสียหายของฝ่ายรับ (แพ้ทาง ความต้านทาน)'}), h('div',{class:'row',style:'gap:10px;margin-top:6px'}, cbCheck('แพ้ทาง ความเสียหาย ×2', st.weak, (v)=>{ st.weak = v; }, {class:'fld chk def-weak'}), h('label',{class:'fld'}, h('span',{text:'ลดเพิ่ม (Resistance หรือเกราะที่จดเอง)'}), cbNum(st.resist || '', (v)=>{ st.resist = Math.max(0, v || 0); }, {class:'def-resist',style:'width:58px',placeholder:'0',min:0}))),
        h('p',{class:'dim',style:'font-size:11.5px;margin:6px 0 0',text:'เกราะของส่วนที่โดนระบบหักให้เอง: โดนชนิดในวงเล็บหักเกราะหลักบวกเกราะรอง ชนิดอื่นหักเกราะหลัก ความเสียหายเวทหักเกราะหลักบวก Sorceries Resistance ของส่วนนั้น'}));
      if (st.weak || st.resist) adj.open = true; box.append(...cbKids(adj));
      box.append(...cbKids(h('div',{class:'row',style:'gap:8px;justify-content:center;margin-top:10px'}, h('button',{class:'def-skill',disabled: lock,onclick:()=>{ st.view = 'skill'; redraw(); },text:'✨ ใช้ทักษะ'}), h('button',{class:(pref === 'none' ? 'primary' : 'ghost') + ' def-none',onclick:()=>go('none'),text:'รับการโจมตี (ไม่ป้องกัน)'}), h('button',{class:'small ghost def-later',title:'ปิดหน้าต่างนี้ไว้ก่อน เปิดใหม่ได้จากปุ่มในแชต',onclick:()=>{ this.snooze.add(m.id); this.prompting = null; modal(null); setTimeout(()=>this.checkPrompts(), 120); },text:'ไว้ก่อน'}))));
    };
    const go = (kind, forced)=>{
      if (this.resolved(m)){ this.prompting = null; modal(null); toast('การโจมตีนี้ตัดสินผลไปแล้ว'); return; }
      const opt = {weak: st.weak, resist: st.resist, skill: st.skill};
      const label = kind === 'parry' ? 'Parry' : kind === 'evade' ? 'Evade' : 'รับการโจมตี';
      this.prompting = null; modal(null);
      Table.guardedRoll(t.name, async ()=>{
        if (this.resolved(m)){ toast('มีคนตัดสินการโจมตีนี้ไปก่อนแล้ว'); return; }
        if (kind === 'none'){ this.resolve(m, {kind: 'none', success: false, text: 'ไม่ป้องกัน', skill: st.skill}, opt); return; }
        if (kind === 'block'){ this.resolve(m, {kind: 'skill', success: true, text: `กันด้วย ${st.skill || 'ทักษะ'}`, skill: st.skill}, opt); return; }
        const pl = plan(kind); let rr, j, total, mod = 0, lab;
        if (kind === 'parry'){
          const pdis = pl.mode === 'dis';
          rr = pl.n > 2 ? await rollChoose(pl.n, pl.mode, `Parry: ทอย ${pl.n}d6 เลือก 2 ลูก`, {kind: 'parry', dc: sum, cv, loc: precise ? part : null}) : roll2d6('normal');
          total = rr.sum; j = judgeDefense(total, sum, 'parry', {sum: rr.sum, dis: pdis, cv, loc: precise ? part : null}); lab = pdis ? 'Parry (Disadvantage)' : 'Parry';
          if (used && rr.sum === sum) j = pdis ? {cls: 'res-fail', text: `Parry ไม่สำเร็จ (รอบนี้ใช้ Perfect Defense ไปแล้ว) โดน${partLabel(part)}`} : {cls: 'res-full', text: `Parry สำเร็จ (${rr.sum} เท่าผลโจมตี แต่รอบนี้ใช้ Perfect Defense ไปแล้ว)`};
        } else {
          mod = st.reflex; rr = pl.mode === 'adv' ? await rollChoose(3, 'adv', 'Evade (Advantage): ทอย 3d6 เลือก 2 ลูก', {kind: 'evade', dc: sum, mod, cv, loc: precise ? part : null}) : roll2d6(pl.mode === 'dis' ? 'dis' : 'normal');
          total = rr.sum + mod; j = judgeDefense(total, sum, 'evade', {sum: rr.sum, cv, loc: precise ? part : null}); lab = pl.mode === 'dis' ? 'Evade (Disadvantage)' : pl.mode === 'adv' ? 'Evade (Advantage)' : 'Evade';
          if (used && rr.sum === sum) j = total >= cv ? {cls: 'res-full', text: `Evade สำเร็จ (${total} ถึง ${cv})`} : {cls: 'res-fail', text: `Evade ไม่สำเร็จ (${total} ต่ำกว่า ${cv} และรอบนี้ใช้ Perfect Defense ไปแล้ว) โดน${partLabel(part)}`};
        }
        const ok = /res-(full|crit)/.test(j.cls || ''); const perfect = j.cls === 'res-crit';
        this.resolve(m, {kind, success: ok, perfect, roll: cbRollOf(rr), mode: pl.mode, mod, total, text: j.text, cls: j.cls, label: lab, pd: pl.pd, skill: st.skill}, opt);
      }, label);
    };
    /* แสดงกรอบนี้ในหน้าต่าง: ปิดด้วยปุ่ม "ไว้ก่อน" เท่านั้น กันกดพลาดนอกกรอบ · เรียกซ้ำได้หลังหน้าต่างใช้ทักษะปิด */
    const show = ()=>{ if (this.resolved(m)){ this.prompting = null; return; } this.prompting = m.id; draw(); modal(box); const mEl = $('#modal'); if (!mEl) return; mEl.onclick = ()=>{}; const closeRow = mEl.querySelector('.box > .row:last-child'); if (closeRow && closeRow !== box) closeRow.remove(); };
    st.show = show; show();
  },
  /* ฝ่ายรับเลือกใช้ทักษะ: จ่ายค่าร่าย ประกาศในแชต แล้วบอกว่าทักษะมีผลกับการโจมตีนี้อย่างไร */
  defSkillView(box, m, t, st, redraw, plan, go){
    const c = this.charOf(t); let names = []; try { names = c && !(c.shareMode === 'min' && !Store.isMine(c)) ? allSkills(c) : []; } catch(e){ names = []; }
    const sks = names.map(n=>SKILL_BY_NAME[n]).filter(Boolean); const react = sks.filter(sk=>/Reaction/i.test(sk.type || '')); const rest = sks.filter(sk=>!/Reaction|Passive/i.test(sk.type || ''));
    box.append(...cbKids(h('p',{class:'desc',style:'margin:8px 0',text: st.skill ? `ใช้ ${st.skill} แล้ว เลือกว่าทักษะนี้มีผลกับการโจมตีอย่างไร` : 'เลือกทักษะที่จะใช้ตอบโต้การโจมตีนี้ ระบบหักค่าร่ายและประกาศในแชตให้ แล้วให้คุณบอกผลของมันต่อการโจมตี'})));
    if (!st.skill){
      const pickRow = (sk)=>h('div',{class:'def-sk'}, h('div',null, h('b',{text:skLabel(sk)}), h('span',{class:'dim',style:'font-size:11.5px',text:` ${(sk.type || '').slice(0, 40)}${sk.cost ? ' · ' + sk.cost : ''}`}), h('div',{class:'desc',style:'font-size:12px'}, T(sk.effect || ''))), h('button',{class:'small primary def-usesk',dataset:{sk:sk.nameEn},onclick:()=>{ const done = ()=>{ st.skill = skLabel(sk); st.show(); }; if (typeof SkillUse !== 'undefined') SkillUse.quick(t, sk, {react: m.id}, done, ()=>st.show()); else done(); },text:'ใช้'}));
      if (react.length) box.append(...cbKids(h('div',{class:'kicker',text:'ทักษะประเภท Reaction'}), react.map(pickRow)));
      const nre = (this.isNpc(t) && Array.isArray(t.reactions)) ? t.reactions.filter(x=>x && (x.name || x.text)).slice(0, 8) : [];
      if (nre.length) box.append(...cbKids(h('div',{class:'kicker',text:'Reaction ในสแตตบล็อก (ผู้เล่นเห็นเฉพาะชื่อ)'}), nre.map(x=>h('div',{class:'def-sk'}, h('div',null, h('b',{text:String(x.name || 'Reaction').slice(0, 80)}), h('div',{class:'desc',style:'font-size:12px'}, T(String(x.text || '').slice(0, 1200)))), h('button',{class:'small primary def-usenpc',onclick:()=>{ const nm = String(x.name || 'Reaction').slice(0, 60); st.skill = nm; Table.post({kind: 'sys', who: '', text: `${t.name} ใช้ ${nm} ตอบโต้การโจมตีของ ${m.flow.a.name}`}); redraw(); },text:'ใช้'})))));
      if (rest.length) box.append(...cbKids(h('details',{class:'def-more'}, h('summary',{text:`ทักษะอื่นของ ${t.name} (${rest.length})`}), rest.map(pickRow))));
      const free = h('input',{class:'def-skname',placeholder:'หรือพิมพ์ชื่อความสามารถ (NPC หรือความสามารถที่ไม่อยู่ในรายการ)',style:'flex:1;min-width:200px',maxlength:60});
      box.append(...cbKids(h('div',{class:'row',style:'gap:6px;margin-top:8px'}, free, h('button',{class:'small def-usefree',onclick:()=>{ const nm = free.value.trim().slice(0, 60); if (!nm){ toast('พิมพ์ชื่อความสามารถก่อน'); return; } st.skill = nm; Table.post({kind: 'sys', who: '', text: `${t.name} ใช้ ${nm} ตอบโต้การโจมตีของ ${m.flow.a.name}`}); redraw(); },text:'ใช้ชื่อนี้'}))));
      box.append(...cbKids(h('div',{class:'row',style:'justify-content:center;margin-top:10px'}, h('button',{class:'small ghost def-back',onclick:()=>{ st.view = 'main'; redraw(); },text:'← กลับไปเลือก Parry หรือ Evade'}))));
      return;
    }
    box.append(...cbKids(h('div',{class:'row',style:'gap:8px;justify-content:center;flex-wrap:wrap'}, h('button',{class:'primary def-block',onclick:()=>go('block'),text:'ทักษะนี้กันการโจมตีได้ทั้งหมด'}), h('button',{class:'def-parry2',onclick:()=>go('parry'),text:`ทอย Parry ต่อ (${plan('parry').n}d6)`}), h('button',{class:'def-evade2',onclick:()=>go('evade'),text:'ทอย Evade ต่อ'}), h('button',{class:'ghost def-none2',onclick:()=>go('none'),text:'ยังโดนตามปกติ'}))));
    box.append(...cbKids(h('div',{class:'row',style:'gap:10px;justify-content:center;margin-top:8px'}, cbCheck('Advantage จากทักษะนี้', st.advX, (v)=>{ st.advX = v; redraw(); }, {class:'fld chk def-advx'}), cbCheck('Disadvantage เพิ่ม', st.disX, (v)=>{ st.disX = v; redraw(); }, {class:'fld chk def-disx'}))));
  },

  /* ---------- 6. ตัดสินผลและลงความเสียหาย ---------- */
  toughInit(t, c, tmax){ const cur = (c && c.current && c.current[toughKeyOf(t)]) || {}; t.tough = t.tough || {}; for (const [k] of DATA.meta.bodyParts) if (t.tough[k] == null){ const v = cur[k] != null ? cur[k] : tmax; if (v != null) t.tough[k] = v; } },
  /* ลด Toughness ของหมาก n หน่วย คืนแถวบันทึก (PC แยกอวัยวะและทอยตารางบาดแผลเมื่อถึง 0 · NPC มีค่าเดียว) */
  toughHit(t, c, tmax, pk, n, why){
    if (!n) return null; const isPc = !!(t.charId && t.kind === 'pc');
    if (isPc){ this.toughInit(t, c, tmax); if (t.tough[pk] == null) return null;
      const before = t.tough[pk]; const after = Math.max(tmax != null ? toughFloor(tmax) : -99, before - n); t.tough[pk] = after; const row = {part: pk, n, before, after, why: why || ''};
      if (after <= 0 && before > 0){ const wr = rollWound(pk); const wrow = wr.row || {name: 'ไม่พบตาราง', text: ''}; const cur = (c && c.current) || {}; const list = Array.isArray(t.wounds) ? t.wounds : woundsOf(cur, bodyOf(t)).map(woundLite);
        t.wounds = [...list, {part: pk, die: wr.die, name: wrow.name, text: wrow.text, at: Date.now()}]; row.wound = {die: wr.die, name: wrow.name, text: String(wrow.text || '').slice(0, 300)}; }
      if (tmax != null && after <= -tmax && before > -tmax) row.lost = (pk === 'head' || pk === 'torso') ? 'mortal' : 'lost';
      return row; }
    if (t.tgh == null && t.tghMax == null) return null;
    const before = t.tgh != null ? t.tgh : t.tghMax; const after = Math.max(0, before - n); t.tgh = after; if (t.tghMax == null) t.tghMax = before;
    return {part: null, n, before, after, why: why || ''};
  },
  toughLine(row){ if (!row) return ''; const where = row.part ? partLabel(row.part) : ''; let s = `Toughness${where ? ' ' + where : ''} ${row.before} → ${row.after}${row.why ? ' (' + row.why + ')' : ''}`;
    if (row.wound) s += ` · บาดแผลฉกรรจ์ ทอย 1d6 ได้ ${row.wound.die}: ${row.wound.name}`; if (row.lost) s += row.lost === 'mortal' ? ' · ติดลบถึงค่าเต็ม ให้ผลเท่า Mortal Wound' : ' · ติดลบถึงค่าเต็ม ส่วนนี้ขาด'; if (!row.part && row.after === 0 && row.before > 0) s += ' · Toughness หมด ให้ GM ตัดสินบาดแผล'; return s; },
  /* Perfect Strike เข้าส่วนที่สวมเกราะ: เกราะเสีย Durability 1 (ไฟล์แกน บทเศรษฐศาสตร์ ข้อ 3) · หลายชั้นหักชิ้นนอกสุดที่ยังไม่พัง
   * แก้ได้เฉพาะชีทของเครื่องที่ตัดสินผล ชีทของคนอื่นและ NPC ได้เป็นข้อความเตือนแทน · เรียกหลังคิดความเสียหายของการโจมตีครั้งนั้นเสร็จแล้ว */
  perfectDur(t, c, part){
    if (typeof durArmorAt !== 'function') return '';
    if (!(t.charId && t.kind === 'pc')){ const worn = this.isNpc(t) && Array.isArray(t.equip) && t.equip.some(e=>e && (ARMOR_SLOT_PARTS[e.slot] || []).includes(part) && parseArmor(e.effect)); return worn ? `Perfect Strike เข้า${partLabel(part)}ที่สวมเกราะ: ตามกฎเกราะชิ้นนั้นเสีย Durability 1 (เว็บยังไม่เก็บ Durability ของ NPC ให้ GM จดเอง)` : ''; }
    if (!c || !c.equip || bodyOf(t) === 'B') return '';
    const live = durArmorAt(c, part).filter(([sl, e])=>!durBroken(e)); if (!live.length) return '';
    const e = live[0][1];
    if (!Store.isMine(c) || !Store.chars.includes(c)) return `Perfect Strike เข้า${partLabel(part)}ที่สวมเกราะ: ${e.name} ควรเสีย Durability 1 ให้เจ้าของกดปุ่ม ⚒ PS ที่กล่อง Toughness ในชีท`;
    const b4 = durState(e); durSet(e, b4.cur - 1); recalcParry(c); recalcArmor(c); Store.upsert(c); const af = durState(e);
    return `Perfect Strike เข้า${partLabel(part)}: ${e.name} เสีย Durability 1 (${af.broken ? 'พัง คุณสมบัติพิเศษหาย ประสิทธิภาพเหลือครึ่ง' : `เหลือ ${af.cur}/${af.max}`})` + (live.length > 1 ? ' · สวมหลายชั้น ระบบหักชิ้นนอกสุด แก้ได้ในถุงย่ามของชีท' : '');
  },
  /* ลงความเสียหายให้หมาก: หักเกราะ (ถ้ารู้ตำแหน่ง) Temporary HP แล้ว HP · ใช้ทั้งผลโจมตีและความเสียหายจากสกิล */
  damage(t, o){
    const r = Table.room; const c = this.charOf(t); const d = this.derived(c); const isPc = !!(t.charId && t.kind === 'pc'); const lines = [];
    const physical = !!o.physical; const part = o.part || null; let arm = 0, armored = false, armNote = '';
    if (part && !o.noArmor){
      const text = isPc ? (c ? ((bodyOf(t) === 'B' ? c.armor2 : c.armor) || {})[part] : '') : ((this.isNpc(t) && typeof npcArmor === 'function') ? npcArmor(t.equip)[part] : '');
      const all = (this.isNpc(t) && typeof npcAllArmor === 'function') ? Math.max(0, npcAllArmor(t)) : 0; // All Armor และโบนัสขนาดของ NPC นับเป็นเกราะหลักทุกส่วน
      const cut = cbArmorCut(text, o.dtype, physical, all); armored = cut.any; arm = cut.v;
      const where = partLabel(part) + (o.viaTorso ? ' (ไม่มีตำแหน่งที่โดน ใช้เกราะลำตัว)' : '');
      const how = cut.sec ? ` (เกราะหลัก ${cut.main} บวกเกราะรองกัน${cut.key === 'Sorceries Resistance' ? 'เวท' : ' ' + cut.key} ${cut.sec})` : '';
      if (arm && o.ap){ const half = Math.floor(arm / 2); armNote = `เกราะ${where} ${arm}${how} เหลือ ${half} จาก Armor Penetrate`; arm = half; }
      else if (arm) armNote = `เกราะ${where} ${arm}${how}`; else if (cut.known) armNote = `${where}ไม่มีเกราะ`;
      if (!cut.known) armNote = (armNote ? armNote + ' · ' : '') + `ช่องเกราะของ${partLabel(part)}จดไว้นอกรูปแบบ A/B (ชนิด) ระบบจึงไม่ได้หักส่วนที่จดเอง`; }
    else if (o.noArmor) armNote = 'ความเสียหายนี้ไม่หักเกราะ';
    if (part && !o.noArmor && isPc && !c) armNote = 'ระบบอ่านชีทของเป้าไม่ได้ จึงไม่ได้หักเกราะให้ ใช้ช่อง ลดเพิ่ม แทนได้';
    const raw = Math.max(0, cbInt(o.raw)); const resist = Math.max(0, cbInt(o.resist)); const after = Math.max(0, raw - arm - resist); const fin = after * (o.weak ? 2 : 1);
    if (arm || resist || o.weak) lines.push(`${armNote || 'ไม่มีเกราะกัน'}${resist ? ` ลดเพิ่ม ${resist}` : ''}: ${raw} เหลือ ${after}${o.weak ? ` · แพ้ทาง ×2 = ${fin}` : ''}`);
    else if (armNote) lines.push(armNote);
    let hpDmg = fin, bleed = 0, temp = 0;
    if (o.ripBleed && physical && !armored && fin > 0){ bleed = fin; hpDmg = 0; lines.push(`Rip: ${partLabel(part)}ไม่มีเกราะ เปลี่ยนความเสียหายเป็น Bleeding ${bleed}`); }
    if (hpDmg > 0 && isPc && c && Store.isMine(c) && c.current && cbInt(c.current.temp) > 0){ temp = Math.min(cbInt(c.current.temp), hpDmg); c.current.temp = cbInt(c.current.temp) - temp; hpDmg -= temp; Store.upsert(c); lines.push(`Temporary HP รับไว้ ${temp}`); }
    else if (hpDmg > 0 && isPc && c && c.current && cbInt(c.current.temp) > 0) lines.push(`เป้ามี Temporary HP ${cbInt(c.current.temp)} ที่ระบบหักให้ไม่ได้ (ชีทเป็นของผู้เล่นอีกคน) ให้เจ้าของปรับเอง`);
    const hp0 = cbInt(t.hp); const hp1 = Math.max(0, hp0 - hpDmg); const tracked = t.kind !== 'asset' || t.hpMax > 0;
    if (hpDmg > 0 && tracked){ tokenVitals(t, 'hp', hp1); lines.push(`HP ${hp0} → ${hp1}${hp1 === 0 ? ' (หมด)' : ''}`); }
    else if (!bleed && !temp) lines.push(fin > 0 ? 'ไม่เสีย HP' : 'ความเสียหายเหลือ 0 ไม่เสีย HP');
    const zeroed = arm > 0 && raw > 0 && (raw - arm) <= 0; // เกราะมาก่อน: นับทั้งความเสียหายกายภาพและความเสียหายเวท (คำเคาะ 15 พ.ย. 2026)
    return {raw, arm, armored, after, fin, hpDmg, bleed, temp, hp0, hp1: (hpDmg > 0 && tracked) ? hp1 : hp0, zeroed, lines, tmax: d ? d.toughness : null, c, isPc};
  },
  resolve(m, def, o){
    o = o || {}; const r = Table.room; if (!r || !this.isAttack(m)) return false;
    if (this.resolved(m)){ toast('การโจมตีนี้ตัดสินผลไปแล้ว'); return false; }
    const f = m.flow; const t = this.tok(f.t.id); const a = this.tok(f.a.id); if (!t){ toast('หมากเป้าหมายไม่อยู่บนบอร์ดแล้ว'); return false; }
    const atk = m.atk || {}; const sum = m.roll.sum; const precise = !!atk.precise; const part = atk.part || hitPart(sum) || 'torso'; const w = f.w || {};
    const hit = !def.success; const lines = []; const res = {lines, tough: [], conds: [], hp0: cbInt(t.hp), hp1: cbInt(t.hp), dmg: 0, bleed: 0}; const after = []; let perfect = false, headline = '';
    const floats = [];
    if (hit){
      perfect = !!m.roll.double || !!f.perfect || !!(w.headshot && part === 'head' && !precise) || this.has(t, 'Incapacitated');
      const base = cbRollExpr(w.dmg); const rolled = base.total; if (w.halve) base.total = Math.floor(base.total / 2); // อาวุธพังที่ความเสียหายเป็นเต๋า: ครึ่งหนึ่งของผลทอย ปัดลง
      const statN = cbInt(w.stat); let raw = base.total + statN * (perfect ? 2 : 1) + cbInt(w.bonus);
      const bits = [`${w.name} ${base.rolls.length ? base.text : base.total}${w.halve ? ` พังเหลือครึ่ง ${base.total}` : ''}`];
      if (statN) bits.push(`${w.statKind === 'sight' ? 'Sight' : 'Might'} ${statN}${perfect ? ' ×2 จาก Perfect Strike' : ''}`); if (cbInt(w.bonus)) bits.push(`โบนัส ${signed(cbInt(w.bonus))}`);
      if (w.impactX){ const x = cbRollExpr('1d3'); raw += x.total; bits.push(`Impact 1d3 ได้ ${x.total}`); }
      raw = Math.max(0, Math.min(999, raw)); lines.push(`ความเสียหาย: ${bits.join(' + ')} = ${raw} ${w.dtype || ''}`.trim());
      const dm = this.damage(t, {raw, dtype: w.dtype, physical: !!w.physical, part, ap: !!w.ap, ripBleed: !!w.ripBleed && !w.nonLethal, weak: !!o.weak, resist: o.resist});
      lines.push(...dm.lines); res.dmg = dm.hpDmg; res.bleed = dm.bleed; res.hp0 = dm.hp0; res.hp1 = dm.hp1;
      // Toughness: ลด 1 เว้นแต่เกราะหักความเสียหายกายภาพจนเหลือ 0 · Toughness Damage ที่อาวุธระบุเพิ่มยังเข้าตามปกติ
      if (!w.nonLethal){
        const extra = cbInt(w.toughX) + (perfect ? cbInt(w.toughPerfect) : 0); const n1 = (dm.zeroed ? 0 : 1) + extra;
        if (dm.zeroed && !extra) lines.push(`เกราะรับความเสียหายไว้หมด Toughness ของ${partLabel(part)}ไม่ลด`);
        const row = this.toughHit(t, dm.c, dm.tmax, part, n1, extra ? `รวม Toughness Damage เพิ่ม ${extra}` : ''); if (row){ res.tough.push(row); lines.push(this.toughLine(row)); }
        else if (n1 && t.kind !== 'asset') lines.push(dm.isPc ? `ระบบอ่านค่า Toughness ของเป้าไม่ได้ ให้เจ้าของหรือ GM ลด Toughness ของ${partLabel(part)} ${n1} เอง` : `NPC ตัวนี้ยังไม่ได้ตั้งค่า Toughness (ตั้งได้ในหน้าต่างหมากที่เลือก) จึงไม่ได้ลด`);
        for (let i = 0; i < Math.min(6, cbInt(w.sharpnel)); i++){ const sr = roll2d6('normal'); const pk = hitPart(sr.sum) || 'torso'; const rw = this.toughHit(t, dm.c, dm.tmax, pk, 1, `Sharpnel ทอยได้ ${sr.sum}`); if (rw){ res.tough.push(rw); lines.push(this.toughLine(rw)); } }
        if (this.has(t, 'Sundered') && res.tough.length){ const sr = roll2d6('normal'); const pk = hitPart(sr.sum) || 'torso'; const rw = this.toughHit(t, dm.c, dm.tmax, pk, 1, `Sundered ทอยได้ ${sr.sum}`); if (rw){ res.tough.push(rw); lines.push(this.toughLine(rw)); } }
        if (dm.bleed) after.push(()=>applyCond(t, r, 'Bleeding', {lv: dm.bleed, by: a || undefined}));
        if (w.impale) after.push(()=>{ if (!this.has(t, 'Rooted')) applyCond(t, r, 'Rooted', {by: a || undefined}); });
      } else lines.push('Non-Lethal: เสียเฉพาะ HP ไม่ลด Toughness และไม่ติดสภาวะทางกาย');
      if (perfect && !w.nonLethal){ const dl = this.perfectDur(t, dm.c, part); if (dl) lines.push(dl); }
      const stun = (t.conds || []).find(c=>c.id === 'Stunned'); if (stun && dm.hp1 < dm.hp0) after.push(()=>removeCond(t, r, stun, 'ถูกโจมตีจนเสีย HP'));
      if (w.impact && !w.nonLethal) lines.push('Impact: ผู้โจมตีเลื่อนเป้าได้ 1 เมตร (ย้ายหมากเองถ้าต้องการ)');
      t.vitalsAt = Date.now();
      headline = (perfect ? 'Perfect Strike · ' : '') + 'โดน' + partLabel(part);
      floats.push({x: t.x, y: t.y, text: dm.bleed ? `Bleeding ${dm.bleed}` : (dm.hpDmg > 0 ? `−${dm.hpDmg}` : '0'), cls: dm.hpDmg > 0 || dm.bleed ? 'dmg' : 'miss'});
    } else {
      headline = def.kind === 'skill' ? `กันด้วย ${def.skill || 'ทักษะ'}` : def.perfect ? (def.kind === 'parry' ? 'Perfect Parry' : 'Perfect Evade') : (def.kind === 'parry' ? 'Parry สำเร็จ' : 'หลบพ้น');
      lines.push(def.text || headline);
      if (def.perfect){ lines.push(`${t.name} ได้ 1 Swift Action ทันที`); if (r.enc && r.enc.active) t.pd = {round: r.enc.round}; }
      if (def.kind === 'parry' && a && ['Large','Huge'].includes(a.size)) lines.push(`Parry การโจมตีจากศัตรูขนาด ${a.size}: GM ตัดสินว่ารุนแรงพอให้อาวุธที่ใช้ Parry เสีย Durability 1 ไหม`);
      floats.push({x: t.x, y: t.y, text: def.perfect ? 'Perfect!' : (def.kind === 'parry' ? 'Parry' : def.kind === 'evade' ? 'Evade' : 'Block'), cls: 'miss'});
    }
    const sugg = hit && !w.nonLethal ? (w.conds || []).filter(x=>x && x.id && !(x.id === 'Bleeding' && res.bleed) && !(x.id === 'Rooted' && w.impale)).slice(0, 5) : [];
    Table.save();
    const from = a ? {x: a.x, y: a.y} : null;
    Table.post({kind: 'clash', fixedId: 'clash-' + m.id, of: m.id, who: f.a.name, text: `${f.a.name} โจมตี ${t.name}: ${headline}`, gmOnly: !!m.gmOnly, a: f.a, t: f.t, w: {name: w.name, dtype: w.dtype}, mode: f.mode,
      atkRoll: cbRollOf(m.roll), cv: atk.cv != null ? atk.cv : sum, part, perfect, hit, headline, def: {kind: def.kind, roll: def.roll || null, mod: def.mod || 0, total: def.total != null ? def.total : null, text: def.text || '', cls: def.cls || '', perfect: !!def.perfect, label: def.label || '', skill: def.skill || null, mode: def.mode || 'normal'}, res, sugg,
      fx: hit ? {k: f.mode === 'melee' ? 'slash' : 'proj', from, to: {x: t.x, y: t.y}, hue: fxHueOfDamage(w.dtype), floats} : {k: 'shield', from, to: {x: t.x, y: t.y}, hue: 'qi', floats}});
    for (const fn of after){ try { fn(); } catch(e){ console.warn('combat after', e); } }
    return true;
  },

  /* ---------- 7. การ์ดในแชต ---------- */
  chatEl(m, time){
    if (m.kind === 'clash') return this.clashCard(m, time);
    if (m.kind === 'pick' && m.flow) return this.pickCard(m, time);
    if (m.kind === 'skill' && typeof SkillUse !== 'undefined') return SkillUse.card(m, time);
    return null;
  },
  /* แถวสถานะใต้ข้อความทอยโจมตีที่มาจากหน้าต่างโจมตี */
  flowRow(m){
    if (!this.isAttack(m)) return null; const f = m.flow; const done = this.resolved(m); const old = Date.now() - (m.ts || 0) > CB_PENDING_MS;
    const row = h('div',{class:'row flowrow',style:'gap:6px;margin-top:3px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:`เป้า: ${f.t.name} · ${f.w.name} · ${f.mode === 'melee' ? 'ประชิด' : f.mode === 'thrown' ? 'ขว้าง' : 'ยิง'} ${f.m} ม.`}));
    if (done) row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:'ตัดสินแล้ว'})));
    else if (old) row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:'ค้างนานเกินไป ไม่ได้ตัดสิน'})));
    else if (this.canRespond(m)) row.append(...cbKids(h('button',{class:'small primary flow-def',dataset:{of:m.id},onclick:()=>{ this.snooze.delete(m.id); const t = this.tok(f.t.id); if (t && t.kind === 'asset') this.autoHit(m); else this.openDefense(m); },text: this.primary(m) ? '🛡 เลือกวิธีป้องกัน' : '🛡 ป้องกันแทน'})));
    else row.append(...cbKids(h('span',{class:'dim',style:'font-size:12px',text:`รอ ${f.t.name} ป้องกัน`})));
    return row;
  },
  pickCard(m, time){
    const f = m.flow; const done = Table.pickDone(m); const dice = m.dice || []; const t = this.tok(f.t.id); const can = !done && (Table.localMode || Table.isGM() || (t && ownsTok(t)));
    return h('div',{class:'e pickmsg' + (done ? ' done' : '')}, h('div',{class:'row',style:'gap:6px'}, chatWho(m), h('b',{text:m.text || 'Attack Roll'}), tag('Disadvantage', 'neg'), h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
      h('div',{class:'row',style:'gap:8px;margin-top:2px;align-items:center'}, h('span',{class:'inline-roll'}, dice.map(v=>h('span',{class:'die',text:v}))), m.cvMod ? h('span',{class:'dim num',text:'ตัวปรับ CV ' + signed(m.cvMod)}) : null,
        done ? h('span',{class:'dim',text:'เลือกแล้ว ดูผลในข้อความถัดไป'}) : (can ? h('button',{class:'small primary pickbtn flow-pick',onclick:()=>Table.resolvePick(m),text:`เลือก 2 ลูกให้การโจมตีใส่ ${f.t.name}`}) : h('span',{class:'dim',text:`รอ ${f.t.name} หรือ GM เลือก 2 ลูก`}))));
  },
  clashCard(m, time){
    const def = m.def || {}; const res = m.res || {}; const a = m.atkRoll || {};
    const el = h('div',{class:'e clashmsg ' + (m.hit ? 'hit' : 'blocked')}, h('div',{class:'row',style:'gap:6px'}, h('b',{text:`⚔ ${(m.a && m.a.name) || ''} → ${(m.t && m.t.name) || ''}`}), h('span',{class:'dim',text:(m.w && m.w.name) || ''}), m.gmOnly ? h('span',{class:'gm',text:'ลับ'}) : null, h('span',{class:'dim',style:'font-size:11px;margin-left:auto',text:time})),
      h('div',{class:'row',style:'gap:8px;margin-top:2px;align-items:center'}, renderDice({dice: a.dice || [], keptIdx: a.keptIdx || []}), h('span',{class:'num dim',text:`${a.sum}${m.cv !== a.sum ? ' → CV ' + m.cv : ''} ${partLabel(m.part)}`}), h('span',{class:'dim',text:'ปะทะ'}),
        def.roll ? [renderDice({dice: def.roll.dice || [], keptIdx: def.roll.keptIdx || []}), h('span',{class:'num dim',text:`${def.label || ''} ${def.total}`})] : h('span',{class:'dim',text: def.kind === 'skill' ? (def.skill || 'ทักษะ') : 'ไม่ป้องกัน'}),
        h('b',{class: m.hit ? 'res-fail' : (def.perfect ? 'res-crit' : 'res-full'),text:m.headline || ''})));
    const body = h('div',{class:'clash-lines'}); const rows = [];
    if (def.roll && def.text) rows.push(h('div',{class:'dim',text:String(def.text).slice(0, 300)})); for (const ln of (Array.isArray(res.lines) ? res.lines : []).slice(0, 14)) rows.push(h('div',{text:String(ln).slice(0, 400)}));
    for (const row of (Array.isArray(res.tough) ? res.tough : []).slice(0, 8)) if (row && row.wound && row.wound.text) rows.push(h('div',{class:'desc',style:'font-size:11.5px'}, T(`${row.part ? partLabel(row.part) : ''}: ${String(row.wound.text).slice(0, 300)}`)));
    body.append(...cbKids(rows.slice(0, 15)));
    el.append(...cbKids(body));
    const t = m.t ? this.tok(m.t.id) : null; const src = m.a ? this.tok(m.a.id) : null;
    if (t && Array.isArray(m.sugg) && m.sugg.length && this.controls(t)){
      const row = h('div',{class:'row sugg',style:'gap:6px;margin-top:4px;align-items:center'}, h('span',{class:'dim',style:'font-size:12px',text:'เอฟเฟกต์ของอาวุธเอ่ยถึงสภาวะ ใส่ให้เมื่อเข้าเงื่อนไข:'}));
      for (const sg of m.sugg.slice(0, 5)){ const key = m.id + '|' + sg.id; const b = h('button',{class:'small ghost sugg-btn',dataset:{cond:sg.id},disabled: this.done.has(key),onclick:()=>{ if (this.done.has(key)) return; this.done.add(key); b.disabled = true; if (!applyCond(t, Table.room, sg.id, {lv: sg.lv || 1, by: src || undefined})){ this.done.delete(key); b.disabled = false; } },text:`${condIcon(sg.id)} ${sg.id}${sg.lv ? ' ' + sg.lv : ''}`}); row.append(...cbKids(b)); }
      el.append(...cbKids(row));
    }
    return el;
  },

  /* ---------- 8. ส่วนที่ฝังในหน้าต่างหมากที่เลือก ---------- */
  /* ปุ่มโจมตีในหน้าต่างหมากที่เลือก (เรียกจาก tokBody ของ table.js) · ค่าต่อสู้ของ NPC ตั้งที่แผงหมากเดิม: ค่าพลังดัดแปลง Range อาวุธและชุดเกราะ สแตตบล็อก */
  tokPanel(t, r, gm){
    const out = []; if (!t || t.inside) return out; const mine = this.myTokens(r);
    const row = h('div',{class:'row cb-row',style:'gap:6px;margin-top:8px'});
    if (t.kind !== 'asset' && this.controls(t)) row.append(...cbKids(h('button',{class:'small primary cb-attack',title:'เปิดหน้าต่างโจมตี เลือกเป้าหมาย อาวุธ และแบบการโจมตี',onclick:()=>this.openAttack(t.id, null),text:'⚔ โจมตี'})));
    const others = mine.filter(x=>x.id !== t.id);
    if (others.length && (t.kind !== 'asset' || t.hpMax > 0) && (!this.controls(t) || gm)) row.append(...cbKids(h('button',{class:'small cb-target',title:'ใช้หมากของคุณโจมตีหมากนี้',onclick:()=>{ const sel = others.find(x=>x.kind === 'pc' && ownsTok(x)) || others[0]; this.openAttack(sel.id, t.id); },text:'🎯 โจมตีหมากนี้'})));
    if (row.children.length) out.push(row);
    return out;
  },
  /* เรียกหลังโต๊ะวาดเสร็จทุกครั้ง: ปรับหน้าต่างโจมตีตามตำแหน่งหมากล่าสุด และเริ่มนับข้อความในห้องที่ไม่มีการฟังฐานข้อมูล */
  afterRender(){
    if (!Table.room){ this.closeComposer(); return; }
    if (!this.ready && Table.localMode) this.onChat();
    if (this.comp){ if (!this.tok(this.comp.a)){ this.closeComposer(); } else { if (this.comp.t && !this.tok(this.comp.t)) this.comp.t = null; const ae = document.activeElement; const typing = !!(ae && ae.closest && ae.closest('#atkc') && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)); if (!typing) this.drawComposer(); else this.drawDyn(); } }
    if (typeof SkillUse !== 'undefined') SkillUse.afterRender();
  },
};
