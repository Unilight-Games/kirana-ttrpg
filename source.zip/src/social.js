/* ===== โปรไฟล์ผู้เล่น แชตกลางของหน้าโต๊ะเล่น และชื่อสีทองของผู้พัฒนา (v1.20 Non สั่ง 13 พ.ย. 2026) =====
 * เอกสารสองชนิดนี้อยู่ในคอลเลกชัน maps แยกด้วยฟิลด์ type เหมือนคลัง NPC / Asset กับสมุดรีวิว เพราะ Rules รุ่น v1.7 ให้ที่นี่ที่เดียว
 * ที่ทุกคนที่ล็อกอินอ่านได้ (published:true) และเจ้าของเท่านั้นเขียนได้ โดย ownerId ต้องเป็นบัญชีของคนเขียนและแก้ภายหลังไม่ได้
 *   โปรไฟล์   maps/prof-<uid>  = {id, type:'profile', published:true, ownerId, ownerName, name, bio, createdAt, updatedAt}
 *   แชตกลาง  maps/gchat-<uid> = {id, type:'gchat', published:true, ownerId, ownerName, day:'YYYY-MM-DD' (วันที่ตามเวลาไทย), msgs:[{t, x}], createdAt, updatedAt}
 * ตัวตนของคนเขียนดูจาก ownerId เท่านั้น ไม่ดูรหัสเอกสาร (รหัสตามแบบถูกคนอื่นสร้างทับไว้ก่อนได้ จึงมีรหัสสำรอง <รหัส>~<สุ่ม>)
 *   ชื่อสีทองของผู้พัฒนาในแชตกลางจึงปลอมไม่ได้: สีมาจากรหัสบัญชีที่อยู่ในรายชื่อผู้พัฒนาของเว็บ (config/site.devUids) ไม่ได้มาจากชื่อ
 * แชตกลาง: หนึ่งบัญชีมีเอกสารเดียว เก็บข้อความของ "วันนี้" ตามเวลาไทย พอข้ามเที่ยงคืนหน้าเว็บเปลี่ยนไปฟังวันใหม่ ข้อความของวันก่อนไม่ขึ้นอีก
 *   เอกสารของวันก่อนถูกเขียนทับเมื่อเจ้าของพิมพ์ครั้งถัดไป และถูกลบเมื่อเจ้าของหรือผู้พัฒนาเปิดหน้าโต๊ะเล่น (เว็บนี้ไม่มีเซิร์ฟเวอร์ตั้งเวลา)
 * ทุกอย่างที่อ่านจากฐานข้อมูลผ่าน socClean* ก่อนใช้ (Rules ไม่ตรวจชนิดข้อมูล) และแสดงด้วย textContent เท่านั้น */
const PROF_NAME_MAX = 40;   // ความยาวชื่อโปรไฟล์ (ตัวอักษร)
const PROF_BIO_MAX = 500;   // ความยาวคำอธิบายตัวเอง
const PROF_CACHE_MS = 60000;
const GC_TEXT_MAX = 300;    // ความยาวข้อความแชตกลาง
const GC_KEEP = 60;         // ข้อความต่อบัญชีต่อวันที่เก็บ (เกินแล้วข้อความเก่าสุดของบัญชีนั้นหลุด)
const GC_SHOW = 200;        // ข้อความล่าสุดที่แสดง
const GC_GAP_MS = 1500;     // ระยะห่างขั้นต่ำระหว่างสองข้อความของคนเดียวกัน
const TH_OFFSET_MS = 7 * 3600 * 1000; // เวลาไทย = UTC+7 ไม่มีเวลาออมแสง
function gcDay(now){ return new Date((now == null ? Date.now() : now) + TH_OFFSET_MS).toISOString().slice(0, 10); }
function gcMsToMidnight(now){ const n = (now == null ? Date.now() : now) + TH_OFFSET_MS; return 86400000 - (((n % 86400000) + 86400000) % 86400000); }
function socStr(v){ return typeof v === 'string' ? v : ''; }
function socTime(v){ const n = +v; return Number.isFinite(n) && n > 0 && n < 8.64e15 ? n : 0; }
function socCut(s, max){ const a = Array.from(s); return a.length > max ? a.slice(0, max).join('') : s; } // ตัดตามตัวอักษรจริง ไม่ผ่ากลางคู่ surrogate
/* ชื่อ: ตัดอักขระควบคุมกับอักขระล่องหน (ใช้ปลอมชื่อให้ดูเหมือนคนอื่น) ยุบวรรค บรรทัดเดียว */
function profCleanName(v){ return socCut(socStr(v).replace(/[\u0000-\u001f\u007f-\u009f\u00ad\u034f\u061c\u115f\u1160\u17b4\u17b5\u180e\u200b-\u200f\u2028-\u202f\u2060-\u206f\u3164\ufeff\uffa0]/g, ' ').replace(/\s+/g, ' ').trim(), PROF_NAME_MAX); }
function profCleanBio(v){ return socCut(socStr(v).replace(/\r\n?/g, '\n').replace(/[\u0000-\u0009\u000b-\u001f\u007f-\u009f\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g, '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim(), PROF_BIO_MAX); }
function gcCleanText(v){ return socCut(socStr(v).replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g, ' ').replace(/\s+/g, ' ').trim(), GC_TEXT_MAX); }
function socIsId(id, prefix, owner){ if (typeof id !== 'string' || typeof owner !== 'string' || !owner) return false; const base = prefix + owner; return id === base || (id.startsWith(base + '~') && /^[a-z0-9]{1,12}$/.test(id.slice(base.length + 1))); }
function socCleanProfile(d){
  if (!d || typeof d !== 'object' || d.type !== 'profile') return null;
  const owner = socStr(d.ownerId); if (!owner || owner.length > 128 || !socIsId(d.id, 'prof-', owner)) return null;
  return { id: d.id, ownerId: owner, name: profCleanName(d.name), bio: profCleanBio(d.bio), published: d.published === true, createdAt: socTime(d.createdAt), updatedAt: socTime(d.updatedAt) };
}
function socCleanChat(d){
  if (!d || typeof d !== 'object' || d.type !== 'gchat' || d.published !== true) return null;
  const owner = socStr(d.ownerId); if (!owner || owner.length > 128 || !socIsId(d.id, 'gchat-', owner)) return null;
  const day = socStr(d.day); if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return null;
  const msgs = []; const seen = new Set();
  if (Array.isArray(d.msgs)) for (const m of d.msgs.slice(-GC_KEEP)){ if (!m || typeof m !== 'object') continue; const t = socTime(m.t), x = gcCleanText(m.x); if (!t || !x || seen.has(t)) continue; seen.add(t); msgs.push({ t, x }); }
  return { id: d.id, ownerId: owner, ownerName: profCleanName(d.ownerName), day, msgs, updatedAt: socTime(d.updatedAt) };
}
function socPermDenied(e){ return /permission/i.test(String((e && (e.code || e.message)) || '')); }

/* ---- ชื่อสีทองของผู้พัฒนา: ดูจากรหัสบัญชีในรายชื่อผู้พัฒนาของเว็บ (ทุกคนอ่าน config/site ได้) ---- */
function uidIsDev(u){ return !!(u && typeof u === 'string' && Store.site && Array.isArray(Store.site.devUids) && Store.site.devUids.includes(u)); }
/* ป้ายชื่อผู้ใช้: ผู้พัฒนาเป็นสีทอง · o.click = กดแล้วเปิดโปรไฟล์ของคนนั้น · o.cls = คลาสเพิ่ม · o.suffix = ข้อความต่อท้ายชื่อ */
function nameEl(name, ownerUid, o){
  o = o || {}; const dev = uidIsDev(ownerUid);
  const el = h('span',{class:'uname' + (dev ? ' devname' : '') + (o.cls ? ' ' + o.cls : ''), title: dev ? 'ผู้พัฒนา' : null, text: (name || 'ผู้เล่น') + (o.suffix || '')});
  if (ownerUid) el.dataset.uid = ownerUid;
  if (o.click && ownerUid && ownerUid !== 'local'){ el.classList.add('ulink'); el.tabIndex = 0; el.setAttribute('role', 'button'); el.setAttribute('aria-label', 'ดูโปรไฟล์ของ ' + (name || 'ผู้เล่น'));
    const open = (e)=>{ e.stopPropagation(); openProfile(ownerUid, name); };
    el.addEventListener('click', open); el.addEventListener('keydown', (e)=>{ if (e.key === 'Enter' || e.key === ' '){ e.preventDefault(); open(e); } }); }
  return el;
}
/* ชื่อคนพูดในแชตของห้อง: ข้อความที่บัญชีผู้พัฒนาส่ง ชื่อเป็นสีทอง (ดูจาก authorId ของข้อความ)
 * Rules ของแชตในห้องยังไม่ผูก authorId กับบัญชีคนเขียน คนที่เขียนโปรแกรมยิงฐานข้อมูลตรง ๆ จึงยังปลอมสีทองในแชตของห้องได้ (ในแชตกลางปลอมไม่ได้) */
function chatWho(m, suffix){ const dev = uidIsDev(m && m.authorId); return h('span',{class:'who' + (dev ? ' devname' : ''), title: dev ? 'ผู้พัฒนา' : null, text: ((m && m.who) || '') + (suffix || '')}); }

/* ---- โปรไฟล์ ---- */
function myProfileName(){ try { return ProfileLib.mine && ProfileLib.mine.name ? ProfileLib.mine.name : ''; } catch(e){ return ''; } } // ใช้จากส่วนหัวของเว็บ (core.js) ซึ่งอาจถูกเรียกก่อนไฟล์นี้ทำงาน
const ProfileLib = {
  mine: null, loaded: false, p: null, cache: new Map(), localKey: 'kirana.profile.v1',
  meKey(){ return Store.me || 'local'; },
  readLocal(){ try { const o = JSON.parse(localStorage.getItem(this.localKey) || 'null'); return o && typeof o === 'object' ? o : null; } catch(e){ return null; } },
  writeLocal(p){ try { if (p) localStorage.setItem(this.localKey, JSON.stringify({ uid: this.meKey(), name: p.name, bio: p.bio })); else localStorage.removeItem(this.localKey); } catch(e){} },
  /* ชื่อที่เว็บใช้เรียกผู้ใช้: ชื่อโปรไฟล์ถ้าตั้งไว้ ไม่อย่างนั้นใช้ชื่อจากบัญชี (Store.baseName) */
  apply(){
    if (Store.baseName == null) Store.baseName = Store.displayName || '';
    const nm = this.mine && this.mine.name ? this.mine.name : Store.baseName;
    if (nm !== Store.displayName){ Store.displayName = nm; if (typeof Store.pushPresence === 'function') try { Store.pushPresence(); } catch(e){} }
    updateOnline();
  },
  /* เรียกครั้งเดียวหลังรู้ตัวผู้ใช้: ใช้สำเนาในเครื่องก่อน ชื่อจึงขึ้นถูกตั้งแต่วินาทีแรก แล้วอ่านของจริงจากฐานข้อมูลตาม */
  boot(){
    if (this.p) return this.p;
    this.p = (async ()=>{
      if (Store.baseName == null) Store.baseName = Store.displayName || '';
      const loc = this.readLocal(); const me = this.meKey();
      if (loc && loc.uid === me && profCleanName(loc.name)){ this.mine = { id: null, ownerId: me, name: profCleanName(loc.name), bio: profCleanBio(loc.bio), published: true, createdAt: 0, updatedAt: 0, local: true }; this.apply(); }
      if (Store.db && Store.me){
        try { const got = await this.fetchOwn(); if (got){ this.mine = got; this.writeLocal(got); } else if (this.mine && this.mine.local){ this.mine = null; this.writeLocal(null); } } // ในเครื่องมีแต่บนเว็บไม่มี (ลบจากเครื่องอื่น): เชื่อเว็บ
        catch(e){ console.warn('profile', e); }
      }
      this.loaded = true; this.apply(); return this.mine;
    })();
    return this.p;
  },
  async fetchOwn(){
    const me = Store.me; let docs;
    try { docs = snapDocs(await Store.db.collection('maps').where('ownerId','==',me).where('type','==','profile').get()); }
    catch(e){ docs = snapDocs(await Store.db.collection('maps').where('ownerId','==',me).get()); }
    return docs.map(socCleanProfile).filter(p => p && p.ownerId === me && p.name).sort((a, b) => b.updatedAt - a.updatedAt)[0] || null;
  },
  /* โปรไฟล์ของบัญชีใดก็ได้ (แคชหนึ่งนาที) · null = บัญชีนั้นยังไม่ได้ตั้งโปรไฟล์ */
  async get(u){
    if (!u) return null;
    if (u === Store.me && this.loaded) return this.mine;
    const c = this.cache.get(u); if (c && Date.now() - c.at < PROF_CACHE_MS) return c.p;
    if (!Store.db) return null;
    let docs;
    try { docs = snapDocs(await Store.db.collection('maps').where('published','==',true).where('type','==','profile').where('ownerId','==',u).get()); }
    catch(e){ try { docs = snapDocs(await Store.db.collection('maps').where('published','==',true).where('type','==','profile').limit(500).get()); } catch(e2){ console.warn('profile get', e2); return null; } }
    const p = docs.map(socCleanProfile).filter(x => x && x.ownerId === u && x.published && x.name).sort((a, b) => b.updatedAt - a.updatedAt)[0] || null;
    this.cache.set(u, { p, at: Date.now() }); return p;
  },
  blocker(){ if (Store.db && !Store.me) return 'ยังไม่ได้เข้าสู่ระบบ'; if (Store.db && Store.canWrite === false) return 'เปิดเว็บแบบอ่านอย่างเดียวอยู่ จึงแก้โปรไฟล์ไม่ได้'; return null; },
  /* บันทึกชื่อและคำอธิบาย · คืน {ok, msg?, renamed?, local?} */
  async save(name, bio){
    name = profCleanName(name); bio = profCleanBio(bio);
    if (!name) return { ok: false, msg: 'ใส่ชื่อโปรไฟล์อย่างน้อยหนึ่งตัวอักษร' };
    const b = this.blocker(); if (b) return { ok: false, msg: b };
    const now = Date.now(), me = this.meKey(), old = this.mine, prevName = Store.displayName;
    if (!Store.db){ this.mine = { id: null, ownerId: me, name, bio, published: true, createdAt: (old && old.createdAt) || now, updatedAt: now, local: true }; this.writeLocal(this.mine); this.loaded = true; this.apply(); return { ok: true, local: true }; }
    const mk = (id)=>({ id, type: 'profile', published: true, ownerId: me, ownerName: name, name, bio, createdAt: (old && old.createdAt) || now, updatedAt: now });
    let id = old && old.id ? old.id : 'prof-' + me;
    try { await Store.db.doc('maps/' + id).set(mk(id)); }
    catch(e){
      if (!(old && old.id) && socPermDenied(e)){ id = 'prof-' + me + '~' + uid().slice(0, 8); // รหัสตามแบบมีคนอื่นสร้างเอกสารทับไว้: ใช้รหัสสำรอง ตัวตนยังดูจาก ownerId
        try { await Store.db.doc('maps/' + id).set(mk(id)); } catch(e2){ console.warn('profile save', e2); return { ok: false, msg: 'บันทึกโปรไฟล์ไม่ได้ (สิทธิ์ไม่พอ?)' }; } }
      else { console.warn('profile save', e); return { ok: false, msg: 'บันทึกโปรไฟล์ไม่ได้ ลองใหม่อีกครั้ง' }; }
    }
    this.mine = socCleanProfile(mk(id)); this.writeLocal(this.mine); this.cache.delete(me); this.loaded = true; this.apply();
    const renamed = prevName !== name ? await this.syncOwnerName(name) : 0;
    return { ok: true, renamed };
  },
  /* ลบโปรไฟล์: กลับไปใช้ชื่อจากบัญชี */
  async remove(){
    const old = this.mine; const prevName = Store.displayName;
    if (Store.db && old && old.id){ try { await Store.db.doc('maps/' + old.id).delete(); } catch(e){ console.warn('profile delete', e); return { ok: false, msg: 'ลบโปรไฟล์ไม่ได้ ลองใหม่อีกครั้ง' }; } }
    this.mine = null; this.writeLocal(null); this.cache.delete(this.meKey()); this.apply();
    const renamed = Store.db && Store.me && prevName !== Store.displayName ? await this.syncOwnerName(Store.displayName) : 0;
    return { ok: true, renamed };
  },
  /* เปลี่ยนชื่อแล้ว: ผลงานที่เผยแพร่ สมุดรีวิว และข้อความแชตกลางของบัญชีนี้เก็บชื่อผู้สร้างไว้ในเอกสาร (ownerName) ตามแก้ให้ตรงชื่อใหม่ ไม่แตะเวลาแก้ล่าสุดของผลงาน */
  async syncOwnerName(name){
    let n = 0;
    try { const docs = snapDocs(await Store.db.collection('maps').where('ownerId','==',Store.me).get());
      for (const d of docs){ if (!d || typeof d.id !== 'string' || d.ownerId !== Store.me || d.type === 'profile' || d.ownerName === name) continue; if (n >= 200) break;
        try { await Store.db.doc('maps/' + d.id).update({ ownerName: name }); n++; } catch(e){ console.warn('rename', d.id, e); } } }
    catch(e){ console.warn('rename', e); }
    try { if (typeof MapLib !== 'undefined') for (const m of MapLib.mine) if (m && m.ownerId === Store.me) m.ownerName = name;
      if (typeof NpcLib !== 'undefined') for (const m of NpcLib.mine) if (m && m.ownerId === Store.me) m.ownerName = name;
      if (typeof ReviewLib !== 'undefined'){ for (const b of ReviewLib.books) if (b && b.ownerId === Store.me) b.ownerName = name; ReviewLib.index(); } } catch(e){}
    return n;
  },
};

/* หน้าโปรไฟล์ของฉัน (#profile) */
function renderProfile(){
  const root = clear($('#v-profile'));
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'โปรไฟล์ของฉัน'}),
    h('p',{text:'ชื่อโปรไฟล์คือชื่อที่คนอื่นเห็นในแชต รายชื่อคนออนไลน์ ชื่อ GM ของห้อง และชื่อผู้สร้างของผลงานที่เผยแพร่ ส่วนคำอธิบายตัวเองขึ้นเมื่อมีคนกดชื่อของคุณ'}))));
  if (!ProfileLib.loaded){ root.append(h('div',{class:'card dim pf-loading',text:'กำลังโหลดโปรไฟล์…'})); if (Store.ready) ProfileLib.boot().then(()=>{ if (location.hash === '#profile') renderProfile(); }); return; } // ก่อนรู้ผลการเชื่อมต่อ (Store.ready) ยังไม่รู้ว่าเป็นบัญชีไหน รอให้ main.js เรียก boot
  const mine = ProfileLib.mine; const base = Store.baseName || '';
  const u = Store.authUser; const anon = Store.backend === 'firebase' && !!u && !!u.isAnonymous;
  const acct = !Store.db ? 'โหมดออฟไลน์: โปรไฟล์เก็บในเบราว์เซอร์เครื่องนี้เท่านั้น คนอื่นไม่เห็น'
    : anon ? 'บัญชีนิรนาม: โปรไฟล์ผูกกับเบราว์เซอร์นี้ เข้าสู่ระบบด้วย Google แล้วโปรไฟล์จะตามบัญชีไปทุกเครื่อง'
    : `บัญชี Google${base ? ' · ชื่อจากบัญชี: ' + base : ''}`;
  const blk = ProfileLib.blocker();
  const nameInp = h('input',{class:'pf-name',maxlength: PROF_NAME_MAX,placeholder: base || 'ชื่อที่อยากให้คนอื่นเรียก','aria-label':'ชื่อโปรไฟล์',style:'width:100%'}); nameInp.value = mine ? mine.name : (Store.displayName || base || '');
  const bioInp = h('textarea',{class:'pf-bio',maxlength: PROF_BIO_MAX,placeholder:'เล่าสั้น ๆ ว่าคุณเป็นใคร ชอบเล่นแนวไหน เป็น GM หรือผู้เล่น ว่างเล่นวันไหน (ไม่บังคับ)','aria-label':'คำอธิบายตัวเอง',style:'width:100%;min-height:130px'}); bioInp.value = mine ? mine.bio : '';
  const nameCount = h('span',{class:'dim num pf-namecount',style:'font-size:12px'}), bioCount = h('span',{class:'dim num pf-biocount',style:'font-size:12px'});
  const status = h('div',{class:'dim pf-status',style:'font-size:12.5px;margin-top:6px','aria-live':'polite'});
  const prev = h('div',{class:'pf-preview'});
  const paint = ()=>{ const nm = profCleanName(nameInp.value), bio = profCleanBio(bioInp.value);
    nameCount.textContent = `${Array.from(nameInp.value).length}/${PROF_NAME_MAX}`; bioCount.textContent = `${Array.from(bioInp.value).length}/${PROF_BIO_MAX}`;
    clear(prev).append(h('div',{class:'kicker',text:'คนอื่นจะเห็นแบบนี้'}), h('div',{class:'pf-card'}, h('div',{class:'pf-cardname'}, nameEl(nm || base || 'ผู้เล่น', Store.me), uidIsDev(Store.me) ? tag('ผู้พัฒนา','prop') : null),
      bio ? h('p',{class:'pf-biotext',text: bio}) : h('p',{class:'dim',style:'margin:6px 0 0;font-size:13px',text:'ยังไม่ได้เขียนคำอธิบายตัวเอง'}))); };
  nameInp.oninput = paint; bioInp.oninput = paint;
  const saveBtn = h('button',{class:'primary pf-save',type:'button',text:'บันทึกโปรไฟล์'});
  saveBtn.onclick = async ()=>{ if (saveBtn.disabled) return; saveBtn.disabled = true; status.textContent = 'กำลังบันทึก…';
    const r = await ProfileLib.save(nameInp.value, bioInp.value); saveBtn.disabled = false;
    if (!r.ok){ status.textContent = r.msg || 'บันทึกไม่ได้'; toast(r.msg || 'บันทึกโปรไฟล์ไม่ได้'); return; }
    toast('บันทึกโปรไฟล์แล้ว' + (r.renamed ? ` และเปลี่ยนชื่อในผลงานกับข้อความของคุณ ${r.renamed} รายการ` : ''));
    if (location.hash === '#profile') renderProfile(); };
  let armed = false;
  const resetBtn = mine ? h('button',{class:'small ghost danger pf-reset',type:'button',text:'ลบโปรไฟล์'}) : null;
  if (resetBtn) resetBtn.onclick = async ()=>{ if (!armed){ armed = true; resetBtn.textContent = 'กดอีกครั้งเพื่อลบ (กลับไปใช้ชื่อจากบัญชี)'; setTimeout(()=>{ armed = false; if (resetBtn.isConnected) resetBtn.textContent = 'ลบโปรไฟล์'; }, 5000); return; }
    resetBtn.disabled = true; const r = await ProfileLib.remove(); if (!r.ok){ resetBtn.disabled = false; toast(r.msg || 'ลบโปรไฟล์ไม่ได้'); return; } toast('ลบโปรไฟล์แล้ว กลับไปใช้ชื่อจากบัญชี'); if (location.hash === '#profile') renderProfile(); };
  const form = h('div',{class:'card pf-form'},
    h('div',{class:'dim pf-acct',style:'font-size:12.5px;margin-bottom:10px',text: acct}),
    anon && Store.login ? h('div',{style:'margin:-4px 0 10px'}, h('button',{class:'small primary',type:'button',onclick:()=>Store.login(),text:'เข้าสู่ระบบ Google'})) : null,
    blk ? h('div',{class:'warnbox',style:'margin-bottom:10px',text: blk}) : null,
    h('label',{class:'pf-label'}, h('span',{class:'row',style:'justify-content:space-between'}, h('b',{text:'ชื่อโปรไฟล์'}), nameCount), nameInp),
    h('label',{class:'pf-label',style:'margin-top:12px'}, h('span',{class:'row',style:'justify-content:space-between'}, h('b',{text:'คำอธิบายตัวเอง'}), bioCount), bioInp),
    h('div',{class:'row',style:'margin-top:12px'}, saveBtn, resetBtn),
    status,
    h('div',{class:'dim',style:'font-size:12px;margin-top:8px',text: Store.db ? 'ทุกคนที่เข้าสู่ระบบเห็นชื่อและคำอธิบายนี้ แก้หรือลบได้ทุกเมื่อ อย่าใส่ข้อมูลส่วนตัวที่ไม่อยากให้คนแปลกหน้ารู้' : 'เชื่อมต่อกับเว็บแล้วบันทึกอีกครั้ง โปรไฟล์จึงจะขึ้นให้คนอื่นเห็น'}));
  if (blk){ nameInp.disabled = true; bioInp.disabled = true; saveBtn.disabled = true; if (resetBtn) resetBtn.disabled = true; }
  root.append(h('div',{class:'pf-wrap'}, form, h('div',{class:'card'}, prev)));
  paint();
}
/* หน้าต่างโปรไฟล์ของคนอื่น (กดชื่อในแชตกลางหรือรายชื่อคนออนไลน์) */
function openProfile(u, hint){
  const box = h('div',{class:'pfbox',dataset:{uid: u || ''}});
  const draw = (p, loading)=>{ clear(box); const nm = (p && p.name) || hint || 'ผู้เล่น';
    box.append(h('h3',{class:'pf-cardname'}, nameEl(nm, u), uidIsDev(u) ? tag('ผู้พัฒนา','prop') : null, u && u === Store.me ? tag('คุณ') : null),
      loading ? h('p',{class:'dim',text:'กำลังโหลดโปรไฟล์…'}) : p && p.bio ? h('p',{class:'pf-biotext',text: p.bio}) : h('p',{class:'dim',text: p ? 'ยังไม่ได้เขียนคำอธิบายตัวเอง' : 'คนนี้ยังไม่ได้ตั้งโปรไฟล์'}),
      u && u === Store.me ? h('div',{style:'margin-top:10px'}, h('button',{class:'small',type:'button',onclick:()=>{ modal(null); location.hash = '#profile'; },text:'แก้โปรไฟล์ของฉัน'})) : null); };
  draw(null, true); modal(box);
  ProfileLib.get(u).then(p=>{ const cur = $('#modal .pfbox'); if (cur === box && !$('#modal').classList.contains('hidden')) draw(p, false); });
}

/* ---- แชตกลางของหน้าโต๊ะเล่น ---- */
const GChat = {
  docs: [], day: null, unsub: null, timer: null, tick: null, mineId: null, lastSend: 0, loaded: false, failed: false, cleaned: false, cleanP: null, el: null, parts: null,
  isAnon(){ return Store.backend === 'firebase' && !!Store.authUser && !!Store.authUser.isAnonymous; },
  /* ใครพิมพ์ได้: ต้องออนไลน์และเป็นบัญชี Google (บัญชีนิรนามสร้างใหม่ได้ไม่จำกัด จึงให้อ่านอย่างเดียวเหมือนดาวและคอมเมนต์) */
  blocker(){
    if (!Store.db) return { code:'offline', text:'แชตกลางใช้ได้เมื่อเชื่อมต่อกับเว็บ' };
    if (!Store.me) return { code:'nouser', text:'ยังไม่ได้เข้าสู่ระบบ' };
    if (Store.canWrite === false) return { code:'readonly', text:'เปิดเว็บแบบอ่านอย่างเดียวอยู่ จึงพิมพ์ในแชตกลางไม่ได้' };
    if (this.isAnon()) return { code:'anon', text:'เข้าสู่ระบบด้วย Google ก่อน จึงจะพิมพ์ในแชตกลางได้ บัญชีนิรนามอ่านได้อย่างเดียว' };
    return null;
  },
  mounted(){ return !!this.el && this.el.isConnected && location.hash === '#table'; },
  /* ฟังข้อความของวันนี้ (เวลาไทย) · ข้ามเที่ยงคืนแล้วเปลี่ยนไปฟังวันใหม่เอง */
  start(){
    const today = gcDay();
    if (this.day === today && (this.unsub || !Store.db)){ this.paint(); return; }
    this.stop(); this.day = today; this.docs = []; this.loaded = false; this.failed = false;
    if (!Store.db){ this.loaded = true; this.paint(); return; }
    {
      try { this.unsub = Store.db.collection('maps').where('published','==',true).where('type','==','gchat').where('day','==',today)
          .onSnapshot(snap=>{ this.docs = snapDocs(snap).map(socCleanChat).filter(d => d && d.day === this.day); this.loaded = true; this.failed = false; this.paint(); },
            e=>{ console.warn('gchat', e); this.failed = true; this.loaded = true; this.paint(); }); }
      catch(e){ console.warn('gchat', e); this.failed = true; this.loaded = true; }
      if (!this.cleaned){ this.cleaned = true; this.cleanP = this.cleanup().catch(()=>0); }
    }
    this.timer = setTimeout(()=>{ this.timer = null; if (this.mounted()) this.start(); else this.stop(); }, gcMsToMidnight() + 1500);
    this.tick = setInterval(()=>{ if (this.mounted()) this.paintInfo(); else this.stop(); }, 30000);
    this.paint();
  },
  stop(){ if (typeof this.unsub === 'function') try { this.unsub(); } catch(e){} this.unsub = null; clearTimeout(this.timer); this.timer = null; clearInterval(this.tick); this.tick = null; this.day = null; },
  /* ข้อความของวันนี้ เรียงใหม่สุดขึ้นก่อน */
  messages(){ const out = []; for (const d of this.docs) for (const m of d.msgs) out.push({ uid: d.ownerId, name: d.ownerName || 'ผู้เล่น', t: m.t, x: m.x }); out.sort((a, b) => b.t - a.t || (a.uid < b.uid ? -1 : 1)); return out.slice(0, GC_SHOW); },
  myMsgs(){ return this.docs.filter(d => d.ownerId === Store.me).flatMap(d => d.msgs).sort((a, b) => a.t - b.t); },
  docBody(id, msgs, now){ return { id, type: 'gchat', published: true, ownerId: Store.me, ownerName: profCleanName(Store.displayName) || 'ผู้เล่น', day: gcDay(now), msgs, createdAt: now, updatedAt: now }; },
  async write(msgs, now){
    const mineDocs = this.docs.filter(d => d.ownerId === Store.me);
    let id = this.mineId || (mineDocs[0] && mineDocs[0].id) || 'gchat-' + Store.me;
    try { await Store.db.doc('maps/' + id).set(this.docBody(id, msgs, now)); }
    catch(e){
      if (socPermDenied(e) && !this.mineId && !mineDocs.length){ id = 'gchat-' + Store.me + '~' + uid().slice(0, 8); await Store.db.doc('maps/' + id).set(this.docBody(id, msgs, now)); } // รหัสตามแบบมีคนอื่นสร้างเอกสารทับไว้
      else throw e;
    }
    this.mineId = id;
    for (const d of mineDocs) if (d.id !== id) Store.db.doc('maps/' + d.id).delete().catch(()=>{}); // เหลือเอกสารเดียวต่อบัญชี
  },
  async send(text){
    const x = gcCleanText(text); if (!x) return { ok: false };
    const b = this.blocker(); if (b) return { ok: false, msg: b.text };
    const now = Date.now(); if (now - this.lastSend < GC_GAP_MS) return { ok: false, msg: 'พิมพ์เร็วเกินไป รอสักครู่แล้วส่งใหม่' };
    if (gcDay(now) !== this.day) this.start(); // ข้ามเที่ยงคืนระหว่างพิมพ์: เริ่มวันใหม่ก่อนส่ง
    this.lastSend = now;
    if (this.cleanP){ try { await this.cleanP; } catch(e){} this.cleanP = null; } // รอให้การล้างเอกสารของวันก่อนจบก่อน ไม่อย่างนั้นคำสั่งลบที่ค้างอยู่จะลบข้อความใหม่ไปด้วย
    const prev = this.myMsgs(); const t = Math.max(now, prev.length ? prev[prev.length - 1].t + 1 : 0);
    try { await this.write(prev.concat([{ t, x }]).slice(-GC_KEEP), now); }
    catch(e){ console.warn('gchat send', e); this.lastSend = 0; return { ok: false, msg: socPermDenied(e) ? 'ส่งข้อความไม่ได้ (สิทธิ์ไม่พอ)' : 'ส่งข้อความไม่ได้ ลองใหม่อีกครั้ง' }; }
    return { ok: true };
  },
  /* ลบข้อความ: ของตัวเองลบได้เสมอ · ผู้พัฒนาลบของใครก็ได้ (Rules ให้ผู้พัฒนาแก้เอกสารของคนอื่นได้) */
  async removeMsg(ownerUid, t){
    if (!Store.db || !Store.me) return false;
    try {
      if (ownerUid === Store.me){ const left = this.myMsgs().filter(m => m.t !== t); const mineDocs = this.docs.filter(d => d.ownerId === Store.me);
        if (left.length) await this.write(left, Date.now()); else for (const d of mineDocs) await Store.db.doc('maps/' + d.id).delete();
        return true; }
      if (!Store.isDevUid) return false;
      for (const d of this.docs.filter(d => d.ownerId === ownerUid)){ if (!d.msgs.some(m => m.t === t)) continue; const left = d.msgs.filter(m => m.t !== t);
        if (left.length) await Store.db.doc('maps/' + d.id).update({ msgs: left }); else await Store.db.doc('maps/' + d.id).delete(); }
      return true;
    } catch(e){ console.warn('gchat remove', e); toast('ลบข้อความไม่ได้'); return false; }
  },
  /* ล้างเอกสารของวันก่อน: ของตัวเองทุกครั้งที่เปิดหน้าโต๊ะเล่น · ผู้พัฒนาล้างของทุกบัญชี */
  async cleanup(){
    if (!Store.db || !Store.me) return 0; const today = gcDay(); let n = 0;
    try { let docs; try { docs = snapDocs(await Store.db.collection('maps').where('ownerId','==',Store.me).where('type','==','gchat').get()); } catch(e){ docs = snapDocs(await Store.db.collection('maps').where('ownerId','==',Store.me).get()); }
      for (const d of docs){ if (!d || d.type !== 'gchat' || d.ownerId !== Store.me || typeof d.id !== 'string') continue;
        if (d.day !== today){ try { await Store.db.doc('maps/' + d.id).delete(); n++; } catch(e){} } else if (!this.mineId) this.mineId = d.id; } }
    catch(e){ console.warn('gchat cleanup', e); }
    if (Store.isDevUid){
      try { const all = snapDocs(await Store.db.collection('maps').where('published','==',true).where('type','==','gchat').limit(500).get());
        for (const d of all){ if (!d || d.type !== 'gchat' || typeof d.id !== 'string' || d.day === today || d.ownerId === Store.me) continue; if (n >= 300) break;
          try { const cur = docData(await Store.db.doc('maps/' + d.id).get()); if (!cur || cur.type !== 'gchat' || cur.day === gcDay()) continue; // เจ้าของเพิ่งพิมพ์ข้อความของวันใหม่ทับไปแล้ว: ไม่ลบ
            await Store.db.doc('maps/' + d.id).delete(); n++; } catch(e){} } }
      catch(e){ console.warn('gchat purge', e); }
    }
    return n;
  },
  panel(){
    if (this.el) return this.el;
    const log = h('div',{class:'log gc-log',role:'log','aria-live':'polite','aria-label':'ข้อความแชตกลาง'});
    const info = h('span',{class:'dim gc-reset'});
    const blk = h('div',{class:'infobox gc-blk hidden'});
    const inp = h('input',{class:'gc-inp',maxlength: GC_TEXT_MAX,placeholder:'พิมพ์ถึงทุกคนในเว็บ เช่น หาโต๊ะเล่น หาผู้เล่น ถามกติกา','aria-label':'ข้อความแชตกลาง',style:'flex:1;min-width:160px'});
    const btn = h('button',{class:'primary small gc-send',type:'button',text:'ส่ง'});
    const row = h('div',{class:'row gc-row'}, inp, btn);
    const send = async ()=>{ if (btn.disabled || !gcCleanText(inp.value)) return; btn.disabled = true; const r = await this.send(inp.value); btn.disabled = false; if (r.ok) inp.value = ''; else if (r.msg) toast(r.msg); try { inp.focus({ preventScroll: true }); } catch(e){} };
    inp.addEventListener('keydown', (e)=>{ if (e.key === 'Enter' && !e.isComposing){ e.preventDefault(); send(); } });
    btn.addEventListener('click', send);
    this.el = h('div',{class:'card chat gchat'}, h('h3',{class:'row',style:'justify-content:space-between;align-items:baseline'}, h('span',{text:'แชตกลาง'}), info),
      h('div',{class:'dim',style:'font-size:12.5px;margin-top:-4px',text:'ห้องรวมของทุกคนในเว็บ ใช้หาโต๊ะ หาเพื่อนร่วมเล่น หรือถามกติกา ส่วนการเล่นในแต่ละโต๊ะคุยกันในแชตของห้อง'}), log, blk, row);
    this.parts = { log, info, blk, inp, btn, row };
    return this.el;
  },
  /* วางแผงแชตลงในหน้าโต๊ะเล่น (ใช้ element เดิมทุกครั้ง ข้อความที่พิมพ์ค้างไว้จึงไม่หาย) */
  mount(host){ const el = this.panel(); if (el.parentNode !== host) host.append(el); this.start(); },
  paintInfo(){ if (!this.parts) return; const ms = gcMsToMidnight(); const hh = Math.floor(ms / 3600000), mm = Math.floor((ms % 3600000) / 60000); this.parts.info.textContent = `ล้างทุกเที่ยงคืนเวลาไทย · อีก ${hh ? hh + ' ชม. ' : ''}${mm} นาที`; },
  paint(){
    if (!this.parts) return; const { log, blk, row } = this.parts; this.paintInfo();
    const b = this.blocker();
    clear(blk); blk.classList.toggle('hidden', !b || b.code === 'offline'); row.classList.toggle('hidden', !!b);
    if (b){ blk.dataset.code = b.code; blk.append(b.text, b.code === 'anon' && Store.login ? h('div',{style:'margin-top:6px'}, h('button',{class:'small primary',type:'button',onclick:()=>Store.login(),text:'เข้าสู่ระบบ Google'})) : null); }
    const top = log.scrollTop; clear(log);
    const items = this.messages();
    if (!Store.db) log.append(h('div',{class:'dim gc-empty',text:'โหมดออฟไลน์ไม่มีแชตกลาง'}));
    else if (!this.loaded) log.append(h('div',{class:'dim gc-empty',text:'กำลังโหลดแชตกลาง…'}));
    else if (this.failed) log.append(h('div',{class:'dim gc-empty',text:'โหลดแชตกลางไม่ได้ ลองเปิดหน้านี้ใหม่อีกครั้ง'}));
    else if (!items.length) log.append(h('div',{class:'dim gc-empty',text:'วันนี้ยังไม่มีใครพิมพ์ ทักทายเป็นคนแรกได้เลย'}));
    for (const m of items){
      const mine = m.uid === Store.me; const canDel = mine || (Store.isDevUid && !mine);
      log.append(h('div',{class:'e gc-msg' + (mine ? ' me' : ''),dataset:{uid: m.uid, t: String(m.t)}},
        nameEl(m.name, m.uid, { click: true, cls: 'who', suffix: ':' }), ' ', h('span',{class:'gc-text',text: m.x}),
        h('span',{class:'gc-meta'}, h('span',{class:'dim gc-time',text: new Date(m.t).toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'})}),
          canDel ? h('button',{class:'small ghost gc-del',type:'button',title: mine ? 'ลบข้อความของฉัน' : 'ลบข้อความนี้ในฐานะผู้พัฒนา','aria-label':'ลบข้อความ',onclick:async(e)=>{ e.stopPropagation(); e.currentTarget.disabled = true; await this.removeMsg(m.uid, m.t); },text:'ลบ'}) : null)));
    }
    log.scrollTop = top;
  },
};
