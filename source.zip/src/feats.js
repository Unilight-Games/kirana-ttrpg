/* ===== v1.29 (Non สั่ง 16 พ.ย. 2026): Trait Proficiency ทักษะติดตัว และกระบวนท่าที่มีผลกับการโจมตีและการป้องกัน =====
 * "ทำไมเอฟเฟคลีลาวาดอาวุธของ trait ถึงไม่เกิดผล ... ช่วยดู Trait อื่นๆให้หน่อยว่ามันมีปัญหาแบบเดียวกันไหม"
 * รุ่น v1.28 อ่านแค่อาวุธกับข้อความของสกิล Trait ทุกอันจึงไม่เคยเข้าหน้าต่างโจมตี ไฟล์นี้เป็นทะเบียนที่เขียนกติกาทีละความสามารถตามข้อความในข้อมูลของเว็บ
 *   FEAT_ATK[ชื่ออังกฤษ] = (x) => ตัวเลือกในหน้าต่างโจมตี · FEAT_DEF[ชื่ออังกฤษ] = (x) => ตัวเลือกในหน้าต่างป้องกัน
 *   ตัวเลือกหนึ่งอัน = {key, label, on (ติ๊กตั้งต้น), eff, use, group} · on = true เมื่อระบบตรวจเงื่อนไขได้เอง ไม่งั้นผู้เล่นเป็นคนติ๊ก
 *   eff ฝั่งโจมตี: adv dis perfect cv dice might sight dmg dmgDice hpDice mul perfectOn ignoreArmor tough toughDice hitCond perfectCond saveCond noDmgCond
 *                 free freeFocus focusAnytime impact impactOnPerfect rip ap noStr noDelay pickPart perfectDmg throwable thrownFar noCover sumCond note clear set act
 *   eff ฝั่งป้องกัน: adv evadeMeleeOk reflex pd armor reduce min1 tempHp note set evadeBy5
 * ความสามารถที่เกี่ยวกับการต่อสู้แต่ยังไม่มีกติกาในทะเบียน ขึ้นเป็นรายการเตือนในหน้าต่างเดียวกัน (Feats.remind) ผู้เล่นกับ GM ตัดสินเอง
 * จำนวนครั้งที่จำกัด: ต่อการพัก เก็บในชีท c.current.uses (รีเซ็ตตอนพัก) · ต่อการต่อสู้ ต่อรอบ ต่อเทิร์น เก็บบนหมาก t.used
 * ธงบนหมากที่ระบบตั้งให้เอง: rof (ถูกเล็งโจมตี) iflame missed (เป้าที่โจมตีพลาด) grudge still (ไม่ได้เคลื่อนที่ในเทิร์นก่อน) bmps boto tactic stance */
const FT_SIZE = ['Tiny', 'Small', 'Medium', 'Large', 'Huge', 'Colossal'];
const FT_PHYS = ['Stunned', 'Unbalanced', 'Prone', 'Bleeding', 'Deepwound', 'Burning', 'Poisoned', 'Rooted', 'Grappled', 'Incapacitated', 'Blinded', 'Deafened'];
function ftSize(t){ if (!t) return 'Medium'; if (t.charId){ const c = Combat.charOf(t); return (c && FT_SIZE.includes(c.size)) ? c.size : 'Medium'; } return FT_SIZE.includes(t.size) ? t.size : 'Medium'; }
function ftSizeAtLeast(t, min){ return FT_SIZE.indexOf(ftSize(t)) >= FT_SIZE.indexOf(min); }
function ftBigger(a, b){ return FT_SIZE.indexOf(ftSize(a)) > FT_SIZE.indexOf(ftSize(b)); }
function ftHas(t, id){ return !!t && (t.conds || []).some(c=>c && c.id === id); }
function ftWeaponKind(w){ const m = /ชนิด(?:อุปกรณ์)?:\s*([^·]*)/.exec(String((w && w.text) || '')); return m ? m[1] : ''; }
function ftIsBow(w){ return /ธนู/.test(ftWeaponKind(w)) || /\bBow\b|ธนู/i.test(String((w && w.name) || '')); }
function ftIsGun(w){ return !!(w && w.props && w.props.reload) || /ปืน|หน้าไม้/.test(ftWeaponKind(w)); }
function ftIsAxe(w){ return /ขวาน/.test(ftWeaponKind(w)) || /\bAxe\b|ขวาน/i.test(String((w && w.name) || '')); }
function ftIsNatural(w){ return !!w && w.src === 'natural'; }
function ftIsUnarmed(w){ return !!w && (w.src === 'unarmed' || /Unarmed|มือเปล่า/i.test(ftWeaponKind(w))); }
function ftOneHand(w){ return /มือเดียว/.test(ftWeaponKind(w)); }
function ftMod(x, stat){ return (x.d && x.d.mod && isFinite(x.d.mod[stat])) ? x.d.mod[stat] : 0; }
function ftPers(x, side){ try { const v = x.c ? persMod(x.c, side) : 0; return isFinite(v) ? v : 0; } catch(e){ return 0; } }
function ftPos(n){ return Math.max(0, n | 0); }
function ftOwns(x, id){ try { return !!x.c && Feats.list(x.c).some(f=>f.id === id); } catch(e){ return false; } }
function ftIsBeast(t){ return !!t && !t.charId && t.kind === 'npc' && t.nkind === 'fauna'; }

/* อาวุธตามธรรมชาติที่ Trait หรือทักษะติดตัวให้ (เข้ารายการอาวุธของหน้าต่างโจมตี) */
const FEAT_WEAPONS = {
  'Sharp Teeth': {name: 'เขี้ยวคม (Sharp Teeth)', effect: '1 PDMG (Piercing), Rip · ชนิด: อาวุธธรรมชาติ'},
  'Scythe Claw': {name: 'กรงเล็บเคียว (Scythe Claw)', effect: '1d3 PDMG (Slashing) · ชนิด: อาวุธ Unarmed', ignoreArmor: 1},
};

/* ---------- ทะเบียนฝั่งโจมตี ---------- */
const FEAT_ATK = {
  /* Lunaryn */
  'Flourish': (x)=> x.mode !== 'melee' ? [] : [
    {key: 'unb', label: 'ถ้าโดน ไม่ทำความเสียหาย แต่เป้าติด Unbalanced จนถึงเริ่มเทิร์นถัดไปของเป้า', on: false, eff: {noDmgCond: {id: 'Unbalanced', ends: {on: 'start', n: 1}}}},
    ftHas(x.t, 'Unbalanced') ? {key: 'd3', label: 'เป้าติด Unbalanced อยู่: ความเสียหาย +1d3' + (x.enc && !x.myTurn ? ' (ได้ผลเฉพาะในเทิร์นของตัวเอง)' : ''), on: !x.enc || x.myTurn, eff: {dmgDice: '1d3'}} : null],
  'Anatomical Insight': (x)=> [{key: 'x3', label: 'เป้าที่เคยรักษาหรือรู้กายวิภาค: Perfect Strike คูณ Might 3 เท่า', on: false, eff: {mul: 3}, use: {per: 'short', max: 1}}],
  'Sanctuary of Faith': (x)=> (cbInt(x.a.hp) * 2 < cbInt(x.a.hpMax) || x.sticky('sof')) ? [{key: 'sof', label: 'ปลดปล่อยพลัง (HP ต่ำกว่าครึ่ง): Might +2 และการโจมตีประชิดติด Bleeding 1 จนจบการต่อสู้', on: x.sticky('sof'), eff: {might: 2, hitCond: x.mode === 'melee' ? [{id: 'Bleeding', lv: 1}] : []}, use: {per: 'day', max: 1, sticky: 'sof'}}] : [],
  'Dirty Fighting': (x)=>{ const g1 = (x.a.conds || []).some(c=>c.id === 'Grappled' && x.t && c.by === x.t.id), g2 = x.t && (x.t.conds || []).some(c=>c.id === 'Grappled' && c.by === x.a.id);
    return (x.mode === 'melee' && (g1 || g2) && (!x.enc || x.myTurn)) ? [{key: 'free', label: 'โจมตีคู่ที่จับกันอยู่เป็น Free Action แต่ติด Disadvantage', on: false, eff: {free: true, dis: true}, use: {per: 'turn', max: 1}}] : []; },
  /* Solrin */
  'Ring of Fire': (x)=> (x.a.rof && x.w && x.w.physical) ? [
    {key: 'burn', label: 'ถูกเล็งโจมตีมาก่อน: ถ้าโดน เป้าติด Burning 2', on: true, eff: {hitCond: [{id: 'Burning', lv: 2}], clear: 'rof'}, group: 'rof'},
    {key: 'fire', label: 'หรือ: เมื่อความเสียหายเข้า HP เพิ่ม 1d3 Fire', on: false, eff: {hpDice: '1d3', clear: 'rof'}, group: 'rof'}] : [],
  'Born to Fight': (x)=> x.again === 'btf' ? [{key: 'again', label: 'โจมตีซ้ำหลังพลาด: ใช้ Cast Action และติด Disadvantage', on: true, eff: {dis: true, act: 'c'}, use: {per: 'turn', max: 1}}] : [],
  'Inner Flame': (x)=> (x.a.iflame && x.mode === 'melee') ? [{key: 'f2', label: 'ลดความเสียหายไฟมาก่อน: การโจมตีประชิดครั้งนี้ +2 Fire Damage', on: true, eff: {dmg: 2, clear: 'iflame'}}] : [],
  'Unholy Smite': (x)=> x.t ? [{key: 'm1', label: 'เป้าหมายไม่ใช่ Humanoid: Might +1', on: !x.t.charId && x.t.kind === 'npc' && x.t.nkind === 'fauna', eff: {might: 1}}] : [],
  "Bodyguard's Vigil": (x)=> (x.focus && (x.a.ow || (x.enc && !x.myTurn))) ? [{key: 'bv', label: 'ศัตรูเข้าเขตปะทะขณะ Overwatch: ได้ Focus กับการโจมตีนี้โดยไม่เสีย Swift Action', on: true, eff: {freeFocus: true, focusAnytime: true}}] : [],
  /* Nightkin */
  "Night's Blessing": (x)=> [{key: 'nb', label: 'กลางคืนหรือที่มืดสนิท: Might +2 และ Combat Dice +1', on: ['dark', 'abyss'].includes(x.r.light), eff: {might: 2, dice: 1}}],
  'Anatomy of a Kill': (x)=> x.hidden ? [{key: 'int', label: `โจมตีครั้งแรกจากการซ่อนตัว: ความเสียหาย +${ftPos(ftMod(x, 'INT'))} (INT Mod)`, on: true, eff: {dmg: ftPos(ftMod(x, 'INT'))}}] : [],
  /* Rimmen */
  'Unfamiliar Tactics': (x)=> [
    {key: 'off', label: 'ท่ารุก: Might +1 (ศัตรูได้ Advantage เมื่อโจมตีคุณ จนถึงเริ่มเทิร์นถัดไป)', on: x.a.tactic === 'off', eff: {might: 1, set: 'tactic', setVal: 'off'}, group: 'ut'},
    {key: 'def', label: 'ท่ารับ: ความเสียหาย −1 (ศัตรูติด Disadvantage เมื่อโจมตีคุณ จนถึงเริ่มเทิร์นถัดไป)', on: x.a.tactic === 'def', eff: {dmg: -1, set: 'tactic', setVal: 'def'}, group: 'ut'}],
  /* Norlan */
  'Giant Slayer': (x)=>{ const out = []; if (!x.t) return out; const sz = ftSize(x.t);
    if (sz === 'Huge' || sz === 'Colossal') out.push({key: 'big', label: `เป้าขนาด ${sz}: CV +2 และถ้าโดน ความเสียหาย +${ftPos(ftMod(x, 'STR'))} (STR Mod)`, on: true, eff: {cv: 2, dmg: ftPos(ftMod(x, 'STR'))}});
    if (x.mode === 'melee' && (sz === 'Medium' || sz === 'Small')) out.push({key: 'small', label: `เป้าตัวเล็กกว่า (${sz}): Toughness Damage เพิ่ม 1d3`, on: true, eff: {toughDice: '1d3'}});
    return out; },
  'Tide of Iron': (x)=> (x.mode === 'melee' && x.enc && x.myTurn && cbInt(x.flag('mv')) * CELL_M >= 3 && !cbInt(x.flag('atk'))) ? [{key: 'charge', label: `เคลื่อนที่มา ${cbInt(x.flag('mv')) * CELL_M} ม. ก่อนโจมตี: CV +2 และผลักเป้าถอย 2 เมตร`, on: true, eff: {cv: 2, note: 'คลื่นเหล็กกล้า: ผลักเป้าหมายถอยหลัง 2 เมตร (ย้ายหมากเอง)'}}] : [],
  /* Day Alves */
  'Precision as Truth': (x)=> x.focus ? [{key: 'ff', label: 'Focus ครั้งนี้ไม่เสีย Swift Action', on: true, eff: {freeFocus: true}, use: {per: 'short', max: ftPos(ftMod(x, 'PER')), round: 1}}] : [],
  'Death From Above': (x)=> (x.mode === 'melee' && x.hidden) ? [{key: 'dfa', label: 'เริ่มเทิร์นในการซ่อนตัวและอยู่เหนือเป้า: Perfect Strike และคูณ Might 3 เท่า', on: false, eff: {perfect: true, mul: 3}, use: {per: 'rest', max: 1}}] : [],
  'Paid by the Shot': (x)=> (x.mode === 'ranged' && ftIsBow(x.w)) ? [{key: 'pbs', label: 'ยิงด้วยธนู: เต๋ารวม 3 หรือ 11 นับเป็น Perfect Strike ด้วย', on: true, eff: {perfectOn: [3, 11]}}] : [],
  /* Night Alves */
  'Vengeful Spirit': (x)=> (x.a.grudge && x.t && x.a.grudge.id !== x.t.id) ? [{key: 'vs', label: `จิตอาฆาต: โจมตีเป้าอื่นที่ไม่ใช่ ${String(x.a.grudge.name || 'ผู้ที่ทำร้าย').slice(0, 40)} ติด Disadvantage`, on: true, eff: {dis: true}}] : [],
  'Patient Ambush': (x)=> (x.a.still && x.enc && x.myTurn && !cbInt(x.flag('atk'))) ? [{key: 'pa', label: 'ไม่ได้เคลื่อนที่ในเทิร์นก่อน: การโจมตีครั้งแรกของเทิร์นนี้ได้ Advantage', on: true, eff: {adv: true}}] : [],
  'Vengeful Resolve': (x)=> [{key: 'vr', label: 'เป้าอยู่ในกลุ่มที่เลือกไว้: Might +2', on: false, eff: {might: 2}}],
  'Lethal Strike': (x)=> [{key: 'ls', label: `ประกาศจู่โจมปลิดชีพ: เลือกตำแหน่งที่โดนเองโดยไม่ต้อง Focus และ Perfect Strike ทำความเสียหาย +${ftPos(ftPers(x, 'Ruthless'))} (Ruthless Mod)`, on: false, eff: {pickPart: true, perfectDmg: ftPos(ftPers(x, 'Ruthless'))}, use: {per: 'combat', max: 1}}],
  'Analyze Prey': (x)=> [{key: 'ap', label: `เป้าที่วิเคราะห์ไว้ (โจมตีครั้งแรก): Might +${ftPos(ftMod(x, 'PER'))} (PER Mod)`, on: false, eff: {might: ftPos(ftMod(x, 'PER'))}}],
  'Take the Blow': (x)=> [{key: 'tb', label: 'Parry แทนพันธมิตรสำเร็จมาก่อน: การโจมตีครั้งนี้เป็น Perfect Strike', on: false, eff: {perfect: true}}],
  'Under the Shell': (x)=> (x.mode === 'melee' && x.t && ftSizeAtLeast(x.t, 'Large')) ? [{key: 'us', label: `เป้าขนาด ${ftSize(x.t)}: เพิกเฉยเกราะ 1`, on: true, eff: {ignoreArmor: 1}}] : [],
  'Shadow Strike': (x)=> (x.hidden || ftHas(x.a, 'Invisible')) ? [{key: 'ss', label: `โจมตีจากการซ่อนตัวหรือล่องหน: ความเสียหาย +${ftPos(ftPers(x, 'Ruthless'))} (Ruthless Mod) · เป้าติด Disadvantage ใน PER Check ถึงจบเทิร์นถัดไป`, on: true, eff: {dmg: ftPos(ftPers(x, 'Ruthless'))}}] : [],
  'Shadow at Your Back': (x)=> [{key: 'sab', label: 'ผู้ที่คุ้มกันถูกทำร้าย: การโจมตีครั้งแรกของเทิร์นนี้ใส่ผู้ลงมือได้ Advantage', on: false, eff: {adv: true}}],
  /* Orcarim */
  'Coordinated Assault': (x)=> x.t ? [{key: 'ca', label: 'เป้าที่ชี้เป้าไว้ด้วย Coordinated Assault: CV +2', on: false, eff: {cv: 2}}] : [],
  'Spring Biceps': (x)=> [{key: 'sb', label: 'Perfect Strike ได้ Impact · ไม่สน STR ที่อาวุธต้องการ · ไม่มี Delay', on: true, eff: {impactOnPerfect: true, noStr: true, noDelay: true}}],
  'Brutal Path': (x)=> x.mode === 'melee' ? [{key: 'bp', label: 'Perfect Strike ประชิด: เป้าติด Bleeding 2', on: true, eff: {perfectCond: [{id: 'Bleeding', lv: 2}]}}] : [],
  'Final Instinct': (x)=> cbInt(x.a.hp) <= 0 ? [{key: 'fi', label: 'HP เหลือ 0: โจมตีผู้ที่ทำให้ล้มด้วย Reaction นับเป็น Perfect Strike', on: false, eff: {perfect: true, free: true}}] : [],
  'Improvised Opportunist': (x)=> [{key: 'io', label: 'อาวุธชั่วคราวที่เพิ่งหยิบ (โจมตีครั้งแรก): ถ้าโดน เป้าทอย VIT Saving Throw (DC 8) ไม่ผ่านติด Unbalanced', on: false, eff: {saveCond: {stat: 'VIT', dc: 8, id: 'Unbalanced'}}, use: {per: 'combat', max: 1}}],
  'Muscle Memory': (x)=> x.again === 'mm' ? [{key: 'mm', label: 'ศัตรูโจมตีประชิดพลาด: โจมตีสวนด้วย Reaction', on: true, eff: {free: true}, use: {per: 'short', max: 1}}] : [],
  /* Necrobug */
  'Non-Humanoid Limbs': (x)=> (!ftIsUnarmed(x.w) && !ftIsNatural(x.w) && x.w.src !== 'custom' && x.w.src !== 'skill') ? [{key: 'nhl', label: 'โจมตีด้วยอาวุธที่ไม่ใช่มือเปล่า: Disadvantage', on: true, eff: {dis: true}}] : [],
  'Beware the Old One': (x)=> (x.a.boto && x.t && x.a.boto === x.t.id) ? [{key: 'bo', label: 'Defend การโจมตีที่เคยเห็นสำเร็จมาก่อน: การโจมตีใส่ศัตรูตัวนี้ได้ Advantage และเป็น Perfect Strike', on: true, eff: {adv: true, perfect: true, clear: 'boto'}}] : [],
  'Seal the Breach': (x)=> (x.a.ow || (x.enc && !x.myTurn)) ? [{key: 'sb', label: 'Opportunity Attack ขณะ Overwatch: ถ้าโดน เป้าติด Rooted จนจบเทิร์นของมัน', on: false, eff: {hitCond: [{id: 'Rooted', ends: {on: 'end', n: 1}}]}, use: {per: 'round', max: 1}}] : [],
  /* Swalan */
  'Battle-Hardened': (x)=> [{key: 'bh', label: 'มีพันธมิตรอยู่ในเขตปะทะ: Sight +1', on: !!x.allies, eff: {sight: 1}}],
  /* Floran */
  'Natural Toxin': (x)=> x.mode === 'melee' ? [{key: 'nt', label: 'เคลือบพิษอาวุธไว้แล้ว (ใช้ Swift Action): ถ้าโดน เป้าทอย VIT Saving Throw (DC 10) ไม่ผ่านติด Poisoned 2', on: false, eff: {saveCond: {stat: 'VIT', dc: 10, id: 'Poisoned', lv: 2}}}] : [],
  'Deadly Allure': (x)=> x.mode === 'melee' ? [{key: 'da', label: 'เป้าที่ยั่วยวนสำเร็จ: การโจมตีประชิดครั้งนี้เป็น Perfect Strike', on: false, eff: {perfect: true}}] : [],
  /* Proficiency ของ Melee */
  'Blade Master': (x)=> (x.a.bmps && x.mode === 'melee') ? [{key: 'bm', label: 'Parry ด้วยอาวุธมีคมสำเร็จมาก่อน: การโจมตีประชิดครั้งนี้เป็น Perfect Strike', on: true, eff: {perfect: true, clear: 'bmps'}}] : [],
  'Blade Master II': (x)=> (x.a.bmps && x.mode === 'melee' && x.focus) ? [{key: 'bm2', label: 'Parry ด้วยอาวุธมีคมสำเร็จมาก่อน: Focus ครั้งนี้ไม่เสีย Swift Action', on: true, eff: {freeFocus: true, focusAnytime: true, clear: 'bmps'}}] : [],
  'Mauler': (x)=> (x.mode === 'melee' && x.dtype === 'Blunt') ? [{key: 'm', label: 'อาวุธทุบ (Blunt): Might +2', on: true, eff: {might: 2}}] : [],
  'Mauler II': (x)=> (x.mode === 'melee' && x.dtype === 'Blunt') ? [{key: 'm', label: 'อาวุธทุบ (Blunt): Might +1 · เลือกเต๋ารวม 8 ขึ้นไปแล้วโดน เป้าติด Unbalanced', on: true, eff: {might: 1, sumCond: {min: 8, id: 'Unbalanced'}}}] : [],
  'Mauler III': (x)=>{ const big = !!(x.t && ftBigger(x.t, x.a)); return (x.mode === 'melee' && x.dtype === 'Blunt') ? [{key: 'm', label: 'อาวุธทุบ (Blunt): Might +1' + (big ? ' · เป้าตัวใหญ่กว่า โดนแล้วติด Unbalanced' : ''), on: true, eff: {might: 1, hitCond: big ? [{id: 'Unbalanced'}] : []}}] : []; },
  'Overseer II': (x)=> (x.mode === 'melee' && (/โพลอาร์ม/.test(ftWeaponKind(x.w)) || x.shield)) ? [{key: 'o2', label: 'โพลอาร์มหรืออาวุธที่ถือคู่โล่: เลือกเต๋ารวมต่ำกว่า 6 แล้วโดน เป้าติด Unbalanced', on: true, eff: {sumCond: {max: 5, id: 'Unbalanced'}}}] : [],
  'Overseer III': (x)=> (x.mode === 'melee' && ftHas(x.t, 'Unbalanced') && (/โพลอาร์ม/.test(ftWeaponKind(x.w)) || x.shield)) ? [{key: 'o3', label: 'เป้าติด Unbalanced: ถ้าโดน เป้าทอย VIT Saving Throw (DC 10) ไม่ผ่านติด Stunned', on: true, eff: {saveCond: {stat: 'VIT', dc: 10, id: 'Stunned'}}}] : [],
  'Executioner': (x)=> (x.mode === 'melee' && ftIsAxe(x.w)) ? [{key: 'e', label: 'อาวุธขวาน: Toughness Damage +1', on: true, eff: {tough: 1}}] : [],
  'Executioner II': (x)=>{ if (!(x.mode === 'melee' && ftIsAxe(x.w))) return []; const bl = ((x.t && x.t.conds) || []).find(c=>c.id === 'Bleeding'); const six = !!(bl && cbInt(bl.lv, 1) >= 6);
    return [{key: 'e2', label: 'อาวุธขวานได้ Rip' + (six ? ' · เป้ามี Bleeding 6 ขึ้นไป: Toughness Damage +2' : ''), on: true, eff: {rip: true, tough: six ? 2 : 0}}]; },
  'Executioner III': (x)=> (x.mode === 'melee' && ftIsAxe(x.w) && x.focus === 'precise') ? [{key: 'e3', label: 'ขวานหลัง Precise Focus: นับเป็น Perfect Strike (และโจมตีแบบ Cleave ได้)', on: true, eff: {perfect: true}}] : [],
  'Fist Fighter': (x)=> ftIsUnarmed(x.w) ? [{key: 'ff', label: 'Unarmed Strike: Might +1', on: true, eff: {might: 1}}] : [],
  'Fist Fighter III': (x)=> (ftIsUnarmed(x.w) && x.focus) ? [{key: 'ff3', label: 'Focus แล้วโจมตีมือเปล่า: Might +1', on: true, eff: {might: 1}}] : [],
  /* Proficiency ของ Range */
  'Marksman': (x)=> (x.focus && ftIsGun(x.w)) ? [{key: 'cv', label: 'Focus ด้วยปืนหรือหน้าไม้: CV +2', on: true, eff: {cv: 2}, group: 'mk'}, {key: 'dmg', label: 'หรือ: ความเสียหาย +2', on: false, eff: {dmg: 2}, group: 'mk'}] : [],
  'Trickster': (x)=> x.mode === 'thrown' ? [{key: 't', label: 'ขว้างอาวุธ Throwable: PDMG +1' + (ftOneHand(x.w) ? ' (อาวุธมือเดียวนับว่ามี Throwable)' : ''), on: !!(x.w && ((x.w.props && x.w.props.throwable) || ftOneHand(x.w))), eff: {dmg: 1, throwable: ftOneHand(x.w)}}] : [],
  'Archer II': (x)=> (x.mode === 'ranged' && x.focus === 'tech' && ftIsBow(x.w) && ftHas(x.t, 'Cover')) ? [{key: 'a2', label: 'Ricochet Shot: เป้าไม่ได้ประโยชน์จากที่กำบัง', on: true, eff: {noCover: true}}] : [],
  'Archer III': (x)=> (x.mode === 'ranged' && x.focus && /ธนูสั้น/.test(ftWeaponKind(x.w))) ? [{key: 'a3', label: 'ธนูสั้นหลัง Focus: ได้ Armor Penetrate', on: true, eff: {ap: true}}] : [],
  /* ทักษะติดตัว */
  'Tactical Sence': (x)=> (x.mode === 'melee' && x.t && x.a.missed === x.t.id) ? [{key: 'ts', label: 'โจมตีเป้านี้พลาดมาก่อน: Melee Attack ครั้งนี้ได้ Advantage', on: true, eff: {adv: true, clear: 'missed'}}] : [],
  'Celestial Mandate - Chaelkai': (x)=> (x.mode === 'melee' || x.mode === 'thrown') ? [{key: 'cm', label: 'โจมตีประชิดหรือขว้างเข้า HP: Physical Damage +1d2', on: true, eff: {hpDice: '1d2'}}] : [],
  'Throwable Mastery': (x)=> x.mode === 'thrown' ? [{key: 'tm', label: 'อาวุธขว้างไปได้ถึงเขตไกล' + (x.t && x.cells <= 1 ? ' · ขว้างในเขตปะทะ Sight +1' : ''), on: true, eff: {thrownFar: true, sight: (x.t && x.cells <= 1) ? 1 : 0}}] : [],
  /* กระบวนท่า (มีผลเมื่อหมากตั้งท่านั้นอยู่) */
  'Wylkarn Executor Stance': (x)=> (x.mode === 'melee' && x.t && FT_PHYS.some(id=>ftHas(x.t, id))) ? [{key: 'we', label: 'เป้าติดสภาวะทางกายภาพ: CV +2', on: true, eff: {cv: 2}}] : [],
  'Way of the Beast Stance': (x)=> x.allies ? [{key: 'wb', label: 'มีพันธมิตรอยู่ในเขตปะทะ: Might +1', on: true, eff: {might: 1}}] : [],
  'Scorching Sun Stance': (x)=> x.mode === 'melee' ? [{key: 'ss', label: 'การโจมตีประชิด: Fire Damage +1', on: true, eff: {dmg: 1}}] : [],
  'Blooming Blossom Stance': (x)=> [{key: 'bb', label: 'ทุกการโจมตีได้คุณสมบัติ Impact', on: true, eff: {impact: true}}, {key: 'push', label: 'ประกาศ Disadvantage: ถ้าโดน ผลักเป้าได้สูงสุด 2 เมตร', on: false, eff: {dis: true, note: 'บุปผาผลิดอก: ผลักเป้าหมายได้สูงสุด 2 เมตร (ย้ายหมากเอง)'}}],
  'Bloodthirsty Beast Stance': (x)=> ftIsUnarmed(x.w) ? [{key: 'bt', label: 'Unarmed Strike ได้คุณสมบัติ Rip', on: true, eff: {rip: true}}] : [],
  'Way of the Sun Stance': (x)=> (x.a.still && x.enc && x.myTurn && !cbInt(x.flag('atk'))) ? [{key: 'ws', label: 'ไม่ได้เคลื่อนที่ในเทิร์นก่อน: การโจมตีครั้งแรกของเทิร์นนี้ได้ Advantage', on: true, eff: {adv: true}}] : [],
  'Vallakai Rhythm Stance': (x)=>{ const n = Math.max(0, Math.min(3, cbInt(x.a.rhythm))); return (n > 0 && (!x.enc || x.myTurn)) ? [{key: 'vr', label: `จ่าย Rhythm Stack ทั้งหมด (${n}): CV +${n} และ Might +${n}`, on: false, eff: {cv: n, might: n, clear: 'rhythm'}}] : []; },
  'Dead Dance Stance': (x)=> x.mode === 'melee' ? [{key: 'dd', label: 'โจมตีประชิดสำเร็จ: ใช้ Reaction เคลื่อนที่ได้ 3 เมตรโดยไม่ถูกโจมตีฉวยโอกาสจากเป้านี้', on: true, eff: {note: 'มรณะนาฏ: ใช้ Reaction เคลื่อนที่ได้ทันที 3 เมตร ไม่ถูกโจมตีฉวยโอกาสจากเป้าที่เพิ่งโจมตี และได้สถานะ [เริงระบำ] จนจบเทิร์น (ย้ายหมากเอง)'}}] : [],
  'Night Blinder Stance': (x)=> [], // ผลของท่านี้ตกกับศัตรูที่เริ่มเทิร์นในเขตปะทะ: ขึ้นเป็นเหตุ CV −2 ในหน้าต่างโจมตีของศัตรูตัวนั้น (atkReasons)
  /* Proficiency อื่น */
  'Beast Slayer': (x)=> x.t ? [{key: 'bs', label: 'เป้าหมายเป็น Monster หรือ Beast: Combat Dice +1', on: ftIsBeast(x.t), eff: {dice: 1}}] : [],
  'Fist Fighter II': (x)=> ftIsUnarmed(x.w) ? [{key: 'ff2', label: 'Unarmed Strike โดนแล้วทอย Melee Check (DC 8) ผ่าน = โจมตีอีกครั้ง', on: true, eff: {note: 'Fist Fighter II: Unarmed Strike สำเร็จ ทอย Melee Check (DC 8) ผ่านแล้วทำ Melee Attack ได้อีกครั้ง'}}] : [],
  'Marksman III': (x)=> (x.focus === 'tech' && ftIsGun(x.w) && /Mana|มานา/i.test(String((x.w && x.w.name) || ''))) ? [{key: 'oc', label: 'Focus เพื่อ Overcharge ปืนมานา: ไม่เสีย Swift Action ทำได้แม้ Maneuver ไปแล้ว ความเสียหาย +1d6 Plasma (หัก MP เท่า Weapon Damage เองบนชีท)', on: false, eff: {freeFocus: true, focusAnytime: true, dmgDice: '1d6', note: 'Overcharge: หัก MP เท่ากับ Weapon Damage ของปืนบนชีทด้วย'}}] : [],
};

/* ---------- ทะเบียนฝั่งป้องกัน ---------- */
const FEAT_DEF = {
  'Elven Agility': (x)=> x.mode === 'melee' ? [{key: 'ea', label: 'Evade การโจมตีระยะประชิดครั้งนี้โดยไม่ติด Disadvantage', on: false, eff: {evadeMeleeOk: true}, use: {per: 'short', max: ftPos(ftMod(x, 'AGI'))}, only: 'evade'}] : [],
  'Shield Wall': (x)=> x.allies ? [{key: 'sw', label: 'มีพันธมิตรอยู่ในเขตปะทะ: ทอย Defend ครั้งนี้ด้วย Advantage', on: false, eff: {adv: true}, use: {per: 'short', max: 1}}] : [],
  'Beware the Old One': (x)=> [{key: 'bo', label: 'ศัตรูใช้การโจมตีแบบที่เคยเห็นแล้วในการต่อสู้นี้: ทอย Defend ด้วย Advantage (สำเร็จแล้วการโจมตีสวนครั้งถัดไปได้ Advantage และ Perfect Strike)', on: false, eff: {adv: true, set: 'boto'}, use: {per: 'combat', max: 1}}],
  "Sun's Fury": (x)=> (cbInt(x.t.hpMax) > 0 && cbInt(x.t.hp) * 2 <= cbInt(x.t.hpMax)) ? [{key: 'sf', label: 'HP ไม่เกินครึ่ง: Physical Resistant +2' + (x.physical ? '' : ' (การโจมตีนี้ไม่ใช่กายภาพ)') + ' และไม่ติดสถานะผิดปกติ', on: !!x.physical, eff: {reduce: x.physical ? 2 : 0}}] : [],
  'Born of Ice': (x)=> x.dtype === 'Frost' ? [{key: 'bi', label: `Frost Damage ลดลง ${ftPos(ftMod(x, 'VIT'))} (VIT Mod) เหลืออย่างน้อย 1`, on: true, eff: {reduce: ftPos(ftMod(x, 'VIT')), min1: true}}] : [],
  'Inner Flame': (x)=> x.dtype === 'Fire' ? [{key: 'if', label: `ใช้ Reaction ลด Fire Damage ลง ${ftPos(ftMod(x, 'VIT'))} (VIT Mod) และการโจมตีประชิดครั้งถัดไป +2 Fire Damage`, on: false, eff: {reduce: ftPos(ftMod(x, 'VIT')), set: 'iflame'}}] : [],
  "Outsider's Potential": (x)=> [{key: 'op', label: `ได้รับความเสียหายครั้งแรกของการต่อสู้: Temporary HP ${Math.max(1, ftMod(x, 'VIT') + ftMod(x, 'INT'))} (VIT Mod + INT Mod)`, on: false, eff: {tempHp: Math.max(1, ftMod(x, 'VIT') + ftMod(x, 'INT'))}, use: {per: 'combat', max: 1}}],
  'Formless Cloud Stance': (x)=> [{key: 'fc', label: 'Reflex +1 · Evade สำเร็จโดยสูงกว่าอย่างน้อย 5 ได้ Basic Action 1 ทันที', on: true, eff: {reflex: 1, evadeBy5: true}}],
  'Way of the Sun Stance': (x)=> x.t.still ? [{key: 'ws', label: 'ไม่ได้เคลื่อนที่ในเทิร์นของตัวเอง: Parry Dice +1', on: true, eff: {pd: 1}}] : [],
  'Vallakai Rhythm Stance': (x)=> [{key: 'vr', label: `ป้องกันสำเร็จ: ได้ 1 Rhythm Stack (ตอนนี้ ${Math.max(0, Math.min(3, cbInt(x.t.rhythm)))} จากสูงสุด 3)`, on: true, eff: {set: 'rhythmUp'}}],
  'Unshakeable Mountain Stance': (x)=> [{key: 'um', label: `ป้องกันสำเร็จ: ได้ Temporary HP ${Math.max(1, Math.floor(ftMod(x, 'VIT') / 2))} (ครึ่งหนึ่งของ VIT Mod ขั้นต่ำ 1) · ถูกผลักหรือทำให้ล้มโดยไม่เต็มใจไม่ได้`, on: true, eff: {okTemp: Math.max(1, Math.floor(ftMod(x, 'VIT') / 2))}}],
  'Grinding Stone Stance': (x)=> x.mode === 'melee' ? [{key: 'gs', label: 'Parry การโจมตีประชิดสำเร็จ: ผู้โจมตีได้รับ 1d3 Blunt Damage ไม่สนเกราะ', on: true, eff: {parryDmg: '1d3'}, use: {per: 'round', max: 1}, only: 'parry'}] : [],
  'Mirroring Water Stance': (x)=> [{key: 'mw', label: 'Perfect Parry: โจมตีฉวยโอกาสใส่ผู้โจมตีได้ 1 ครั้งทันที (ปุ่มขึ้นในการ์ดผล)', on: true, eff: {set: 'mwater'}, only: 'parry'}],
  'Leaf in the Wind Stance': (x)=> [{key: 'lw', label: 'Evade สำเร็จ: ใช้ Reaction เคลื่อนที่ได้ 3 เมตรโดยไม่ถูกโจมตีฉวยโอกาส', on: true, eff: {note: 'ใบไม้ในสายลม: ใช้ Reaction เคลื่อนที่ได้ทันที 3 เมตร ไม่ถูกโจมตีฉวยโอกาส และได้สถานะ [ลอยตัว] จนจบเทิร์น (ย้ายหมากเอง)'}, only: 'evade'}],
  /* Trait Proficiency และทักษะติดตัวอื่น */
  'Layered Chitin': (x)=> [{key: 'lc', label: 'เกราะธรรมชาติ 1 ทุกส่วน (ติ๊กออกถ้าจดรวมไว้ในช่องเกราะของชีทแล้ว หรือมี Natural Armor ที่สูงกว่า)', on: !ftOwns(x, 'Steel Carapace'), eff: {armor: 1}}],
  'Steel Carapace': (x)=> [{key: 'sc', label: 'Natural Armor 2 ทุกส่วน (ติ๊กออกถ้าจดรวมไว้ในช่องเกราะของชีทแล้ว)', on: true, eff: {armor: 2}}, x.physical ? {key: 'sc2', label: `การโจมตีนี้เป็นชนิดที่เลือกไว้ตอนได้ทักษะ (${x.dtype}): Physical Armor อีก 2`, on: false, eff: {armor: 2}} : null],
  'United We Stand': (x)=> x.allies ? [{key: 'uw', label: 'เริ่มเทิร์นโดยมีพันธมิตรอยู่ในเขตปะทะ: Reflex +1', on: true, eff: {reflex: 1}}] : [],
  'Beast Slayer': (x)=> x.a ? [{key: 'bs', label: 'ผู้โจมตีเป็น Monster หรือ Beast: Parry Dice +1', on: ftIsBeast(x.a), eff: {pd: 1}, only: 'parry'}] : [],
};
/* ความสามารถของพันธมิตรที่ยืนติดกันซึ่งให้ผลกับฝ่ายรับ */
const FEAT_DEF_ALLY = {
  'Stand Behind Me': (x, ally)=> ally.still ? [{key: 'sbm', label: `${ally.name} ไม่ได้ Maneuver ในเทิร์นของตน: เกราะทุกส่วน +1`, on: true, eff: {armor: 1}}] : [],
};

const Feats = {
  /* ความสามารถทั้งหมดของตัวละคร: Trait ของวงศา Benefit Hindrance Trait พื้นหลัง Trait ที่ยืมจากวงศาอื่น Proficiency ทักษะติดตัว กระบวนท่า และที่เพิ่มเอง */
  list(c){
    const out = []; if (!c) return out; const kin = c.kin ? KIN[c.kin] : null; const seen = new Set();
    const add = (id, th, text, src, extra)=>{ id = String(id || '').trim(); if (!id || seen.has(id)) return; seen.add(id); out.push(Object.assign({id, th: String(th || id), text: String(text || ''), src}, extra || {})); };
    if (kin){
      for (const x of [...(kin.traits || []), ...(kin.benefits || [])]) add(x.nameEn, x.name, x.text, 'Trait');
      for (const x of kin.hindrances || []) add(x.nameEn, x.name, x.text, 'Hindrance');
      for (const code of [c.childhood, c.adulthood]){ const b = code ? findBg(kin, code) : null; if (b && bgHasTrait(b)) add(b.traitEn || b.nameEn, b.traitTh || b.name, b.text, 'Trait พื้นหลัง'); }
    }
    const ev = c.evolver; if (ev && ev.kin && KIN[ev.kin]){ const ek = KIN[ev.kin]; const pick = String(ev.pick || ''); if (pick.startsWith('T:')){ const tr = (ek.traits || []).find(t=>t.nameEn === pick.slice(2)); if (tr) add(tr.nameEn, tr.name, tr.text, 'Trait'); } if (ev.hindrance){ const hd = (ek.hindrances || []).find(k=>k.nameEn === ev.hindrance); if (hd) add(hd.nameEn, hd.name, hd.text, 'Hindrance'); } }
    for (const sl of Object.values(c.kslots || {})) if (sl && sl.id && sl.prof && !String(sl.prof).startsWith('(')){ const nm = (typeof profNow === 'function') ? profNow(sl.prof) : sl.prof; let txt = ''; try { txt = profTexts(sl.id, sl).text; } catch(e){} add(nm, nm, txt, 'Proficiency'); }
    let names = []; try { names = allSkills(c); } catch(e){ names = []; }
    for (const n of names){ const sk = SKILL_BY_NAME[n]; if (!sk) continue; const ty = String(sk.type || ''); if (/Passive/i.test(ty)) add(sk.nameEn, sk.nameTh, sk.effect, 'ทักษะติดตัว'); else if (/กระบวนท่า/.test(ty)) add(sk.nameEn, sk.nameTh, sk.effect, 'กระบวนท่า', {stance: true}); }
    for (const x of [...(c.customTraits || []), ...(c.customProfs || [])]) if (x && x.name) add(String(x.name).slice(0, 80), String(x.name).slice(0, 80), String(x.text || '').slice(0, 1200), 'เพิ่มเอง');
    return out;
  },
  of(t){ const c = (t && typeof Combat !== 'undefined') ? Combat.charOf(t) : null; if (!c || (c.shareMode === 'min' && !Store.isMine(c))) return {c: null, list: []}; return {c, list: this.list(c)}; },
  has(t, id){ return this.of(t).list.some(f=>f.id === id && (!f.stance || !!(t.stance && t.stance.id === id))); },
  weapons(c){ const out = []; for (const f of this.list(c)) if (Object.prototype.hasOwnProperty.call(FEAT_WEAPONS, f.id)) out.push(FEAT_WEAPONS[f.id]); return out; },
  /* ---- ตัวนับจำนวนครั้ง ---- */
  useKey(f, o){ return (f.id + ':' + o.key).slice(0, 80); },
  usedN(t, c, f, o){
    const u = o.use; if (!u) return 0; const key = this.useKey(f, o); const r = Table.room; const enc = r && r.enc; const x = (t.used || {})[key];
    if (u.per === 'combat') return x ? cbInt(x.n) : 0;
    if (u.per === 'turn') return (x && enc && x.k === enc.round + ':' + enc.turnIdx) ? cbInt(x.n) : 0;
    if (u.per === 'round') return (x && enc && x.k === 'r' + enc.round) ? cbInt(x.n) : 0;
    const y = (c && c.current && c.current.uses) ? c.current.uses[key] : null; return y ? cbInt(y.n) : 0;
  },
  usedRound(t, f, o){ const key = this.useKey(f, o) + '@r'; const r = Table.room; const enc = r && r.enc; const x = (t.used || {})[key]; return (x && enc && enc.active && x.r === enc.round) ? cbInt(x.n) : 0; },
  left(t, c, f, o){ const u = o.use; if (!u) return null; let left = Math.max(0, cbInt(u.max) - this.usedN(t, c, f, o)); if (u.round && this.usedRound(t, f, o) >= u.round) left = 0; return left; },
  /* หักหนึ่งครั้ง: ต่อการพักเขียนลงชีท (เฉพาะชีทของเครื่องนี้) · อย่างอื่นเขียนบนหมาก คืนข้อความเตือนถ้านับให้ไม่ได้ · คนเรียกบันทึกห้องเอง */
  spend(t, c, f, o){
    const u = o.use; if (!u) return ''; const key = this.useKey(f, o); const r = Table.room; const enc = r && r.enc; t.used = (t.used && typeof t.used === 'object') ? t.used : {};
    if (u.sticky) t.used['sticky:' + u.sticky] = {n: 1};
    if (u.round && enc && enc.active){ const k2 = key + '@r'; const x = t.used[k2]; t.used[k2] = {r: enc.round, n: (x && x.r === enc.round ? cbInt(x.n) : 0) + 1}; }
    if (u.per === 'combat'){ t.used[key] = {n: this.usedN(t, c, f, o) + 1}; return ''; }
    if (u.per === 'turn'){ t.used[key] = {k: enc ? enc.round + ':' + enc.turnIdx : '', n: this.usedN(t, c, f, o) + 1}; return ''; }
    if (u.per === 'round'){ t.used[key] = {k: enc ? 'r' + enc.round : '', n: this.usedN(t, c, f, o) + 1}; return ''; }
    if (!c || !Store.isMine(c) || !Store.chars.includes(c) || !c.current) return `${f.th}: จำนวนครั้งที่ใช้เก็บในชีทของเจ้าของ ระบบนับให้จากเครื่องนี้ไม่ได้`;
    c.current.uses = (c.current.uses && typeof c.current.uses === 'object') ? c.current.uses : {}; c.current.uses[key] = {n: this.usedN(t, c, f, o) + 1, per: u.per}; Store.upsert(c); return '';
  },
  /* การพักรีเซ็ตจำนวนครั้ง: พักสั้นคืนของที่นับต่อการพักสั้น · พักยาวคืนทั้งหมด (เรียกจากหน้าต่างพักในชีท) คืนจำนวนรายการที่รีเซ็ต */
  resetUses(c, kind){ const u = c && c.current && c.current.uses; if (!u || typeof u !== 'object') return 0; let n = 0; for (const k of Object.keys(u)){ const per = u[k] && u[k].per; if (kind === 'long' || per === 'short' || per === 'rest'){ delete u[k]; n++; } } return n; },
  perText(u){ return u.per === 'short' ? 'ต่อการพักสั้น' : u.per === 'rest' ? 'ต่อการพัก' : u.per === 'day' ? 'ต่อวัน' : u.per === 'long' ? 'ต่อการพักยาว' : u.per === 'combat' ? 'ต่อการต่อสู้' : u.per === 'round' ? 'ต่อรอบ' : 'ต่อเทิร์น'; },
  /* สร้างตัวเลือกจากทะเบียน: x = บริบท · reg = FEAT_ATK หรือ FEAT_DEF · st = {id: true|false} ที่ผู้ใช้ติ๊กทับค่าตั้งต้น */
  build(t, reg, x, st){
    const {c, list} = this.of(t); const opts = []; const done = new Set(); st = st || {};
    x.c = c; x.d = (c && typeof Combat !== 'undefined') ? Combat.derived(c) : null;
    x.sticky = (k)=>!!((t.used || {})['sticky:' + k]);
    x.flag = (k)=> (typeof Act !== 'undefined') ? Act.flag(t, k) : null;
    for (const f of list){ const fn = Object.prototype.hasOwnProperty.call(reg, f.id) ? reg[f.id] : null; if (!fn) continue;
      if (f.stance && !(t.stance && t.stance.id === f.id)) continue;
      let got = []; try { got = fn(x) || []; } catch(e){ console.warn('feat', f.id, e); got = []; }
      for (const o of got){ if (!o) continue; const id = f.id + ':' + o.key; if (done.has(id)) continue; done.add(id);
        const left = this.left(t, c, f, o); const off = left != null && left <= 0; const on = !off && (Object.prototype.hasOwnProperty.call(st, id) ? !!st[id] : !!o.on);
        opts.push({id, f, o, eff: o.eff || {}, label: `${f.th}: ${o.label}` + (o.use ? ` (${cbInt(o.use.max)} ครั้ง${this.perText(o.use)} เหลือ ${left})` : ''), on, off, group: o.group ? f.id + ':' + o.group : null, only: o.only || null}); } }
    // ตัวเลือกในกลุ่มเดียวกันเปิดได้ทีละอัน: อันที่ผู้ใช้ติ๊กเอง (อยู่ใน st) มาก่อนค่าตั้งต้น
    const seenG = new Set(); for (const p of [...opts.filter(q=>q.group && st[q.id] === true), ...opts.filter(q=>q.group && st[q.id] !== true)]){ if (!p.on) continue; if (seenG.has(p.group)) p.on = false; else seenG.add(p.group); }
    return {c, list, opts};
  },
  /* ความสามารถที่ข้อความเอ่ยถึงการต่อสู้แต่ไม่มีกติกาในทะเบียน: ขึ้นเป็นรายการเตือน */
  remind(t, list, rx, reg){ return list.filter(f=>!Object.prototype.hasOwnProperty.call(reg, f.id) && !Object.prototype.hasOwnProperty.call(FEAT_WEAPONS, f.id) && rx.test(f.text) && (!f.stance || !!(t.stance && t.stance.id === f.id))).slice(0, 14); },
  remindBox(t, list, rx, reg, title){
    const rest = this.remind(t, list, rx, reg); if (!rest.length) return null;
    return h('details',{class:'featmore'}, h('summary',{text:`${title} (${rest.length})`}), rest.map(f=>h('div',{class:'featrow'}, h('b',{text:f.th}), h('span',{class:'dim',text:` ${f.src}`}), h('div',{class:'desc',style:'font-size:12px'}, T(f.text.slice(0, 600))))));
  },
};
const FT_ATK_RX = /Attack|โจมตี|Damage|ความเสียหาย|\bCV\b|Might|Sight|Perfect|On-?Hit|Grab|Combat Dice|Focus/;
const FT_DEF_RX = /Defend|Parry|Evade|ถูกโจมตี|ถูกเป็นเป้า|Armor|เกราะ|Reflex|ได้รับความเสียหาย|Damage Reduction|Resistance|Immun|Temporary HP/;
