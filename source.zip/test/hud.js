// HUD: floating dock + windows (bag / book / pouch), drag, wear/unequip
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  await page.evaluate(() => { const K = window.__kirana; const c = { id: 'hud1', name: 'ทดสอบ HUD', kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: ['Mind Trick', 'Telepathy'], knowledge: {}, prof: {}, skills: [], talentPicks: {}, details: {}, starterSet: 'The Vanguard', done: true, createdAt: Date.now(), updatedAt: Date.now(), step: 8 }; K.Store.upsert(c); });
  await page.goto(url + '#sheet-hud1'); await page.waitForTimeout(500);
  console.log('dock:', !!(await page.$('.hud-dock')), 'btns', (await page.$$('.hud-btn')).length, 'badges', await page.$$eval('.hud-btn .badge', b => b.map(x => x.textContent)));
  await page.screenshot({ path: 'test/30-hud-dock.png' });
  // drag dock to the left
  const dock = await page.$('.hud-dock'); const bb = await dock.boundingBox();
  await page.mouse.move(bb.x + bb.width / 2, bb.y + 8); await page.mouse.down(); await page.mouse.move(bb.x - 600, bb.y + 100, { steps: 8 }); await page.mouse.up(); await page.waitForTimeout(100);
  const bb2 = await (await page.$('.hud-dock')).boundingBox(); console.log('dock moved:', Math.round(bb.x), '→', Math.round(bb2.x), 'saved:', await page.evaluate(() => JSON.parse(localStorage.getItem('kirana.hud')).pos));
  // open bag
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(250);
  console.log('bag win:', !!(await page.$('.hud-win.bag')), 'tiles', (await page.$$('.tile')).length);
  await page.click('.tile:not(.add)'); await page.waitForTimeout(200);
  console.log('detail:', !!(await page.$('.hud-detail')), 'wear btn:', await page.$eval('.hud-detail', e => (e.querySelector('button.primary') || {}).textContent || '-'));
  await page.screenshot({ path: 'test/31-hud-bag.png' });
  // drag window
  const win = await page.$('.hud-win'); const wb = await win.boundingBox(); const head = await page.$('.hud-head'); const hb = await head.boundingBox();
  await page.mouse.move(hb.x + 150, hb.y + hb.height / 2); await page.mouse.down(); await page.mouse.move(hb.x - 300, hb.y + 150, { steps: 8 }); await page.mouse.up(); await page.waitForTimeout(100);
  const wb2 = await (await page.$('.hud-win')).boundingBox(); console.log('win moved:', Math.round(wb.x), '→', Math.round(wb2.x), 'still open after move:', !!(await page.$('.hud-win.bag')));
  // pouch: select weapon1 → unequip
  await page.click('.hud-btn[title="ถุงย่าม"]'); await page.waitForTimeout(250);
  console.log('pouch win:', !!(await page.$('.hud-win.pouch')), 'slots', (await page.$$('.dslot')).length, 'filled', (await page.$$('.dslot.filled')).length);
  await page.screenshot({ path: 'test/32-hud-pouch.png' });
  await page.click('.dslot.filled'); await page.waitForTimeout(200);
  const before = await page.evaluate(() => window.__kirana.Store.get('hud1').inventory.length);
  await page.click('.hud-detail button:has-text("ถอดกลับกระเป๋า")'); await page.waitForTimeout(250);
  const after = await page.evaluate(() => { const c = window.__kirana.Store.get('hud1'); return { bag: c.inventory.length, filled: Object.values(c.equip).filter(e => e && e.name).length }; });
  console.log('unequip: bag', before, '→', after.bag, 'filled', after.filled, 'window still pouch:', !!(await page.$('.hud-win.pouch')));
  // empty slot → wear candidate
  await page.click('.dslot:not(.filled)'); await page.waitForTimeout(200);
  const cand = await page.$('.hud-detail button:has-text("สวม ")'); console.log('candidate for empty slot:', cand ? await cand.textContent() : 'none');
  if (cand) { await cand.click(); await page.waitForTimeout(200); console.log('after wear filled:', (await page.$$('.dslot.filled')).length); }
  // book
  await page.click('.hud-btn[title="คัมภีร์"]'); await page.waitForTimeout(250);
  console.log('book win:', !!(await page.$('.hud-win.book')), 'toc', (await page.$$('.toc-i')).length, 'detail h3:', await page.$eval('.book .detail h3', e => e.textContent));
  await page.screenshot({ path: 'test/33-hud-book.png' });
  const toc = await page.$$('.toc-i'); await toc[1].click(); await page.waitForTimeout(150); console.log('after toc click:', await page.$eval('.book .detail h3', e => e.textContent));
  // leaving sheet hides HUD
  await page.goto(url + '#chars'); await page.waitForTimeout(300); console.log('hud hidden on #chars:', (await page.$$('#hud *')).length === 0);
  // mobile
  await page.setViewportSize({ width: 400, height: 800 }); await page.goto(url + '#sheet-hud1'); await page.waitForTimeout(400);
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(250); await page.screenshot({ path: 'test/34-hud-mobile.png' });
  const mb = await (await page.$('.hud-win')).boundingBox(); console.log('mobile win within viewport:', mb.x >= 0 && mb.x + mb.width <= 400);
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
