const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const mk = async (name) => { const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } }); const page = await ctx.newPage(); page.on('pageerror', e => console.log(name, 'PAGEERROR', e.message)); page.on('console', m => { if (m.type() === 'error' || m.type()==='warning') console.log(name, m.type(), m.text().slice(0, 200)); }); return page; };
  const A = await mk('A'), B = await mk('B');
  const url = 'http://localhost:8765/index.html';
  await A.goto(url + '#table'); await B.goto(url + '#table');
  await A.waitForTimeout(6000);
  const onlineA = await A.$eval('#online', e => e.textContent); const onlineB = await B.$eval('#online', e => e.textContent);
  console.log('A:', onlineA, '| B:', onlineB);
  const meA = await A.evaluate(() => window.__kirana.Store.me); const meB = await B.evaluate(() => window.__kirana.Store.me);
  console.log('uids', meA, meB, meA !== meB ? '(distinct)' : '(SAME!)');
  // A creates room
  await A.fill('input[placeholder^="ชื่อห้อง"]', 'ทดสอบซิงก์ ' + Date.now());
  await A.click('button:has-text("สร้างห้อง")'); await A.waitForTimeout(3000);
  const hash = await A.evaluate(() => location.hash); console.log('room hash', hash);
  await B.goto(url + hash); await B.waitForTimeout(5000);
  console.log('B sees room title:', await B.$eval('#v-table h2', e => e.textContent).catch(() => 'NONE'));
  // A adds NPC + scene, B should see
  await A.click('button:has-text("+ NPC")'); await A.waitForTimeout(500);
  await A.fill('input[placeholder^="พิมพ์ข้อความ"]', 'สวัสดีจาก A'); await A.keyboard.press('Enter');
  await A.waitForTimeout(4000);
  const bChat = await B.$eval('#chatlog', e => e.textContent).catch(() => 'NONE');
  console.log('B chat contains A msg:', bChat.includes('สวัสดีจาก A'), '|', bChat.slice(0, 120));
  const bTokens = await B.$$eval('.tok', els => els.map(e => e.textContent));
  console.log('B tokens (NPC hidden so expect none):', bTokens);
  // B sends message, A sees
  await B.fill('input[placeholder^="พิมพ์ข้อความ"]', '/r 2d6+1 ทอยจาก B'); await B.keyboard.press('Enter'); await B.waitForTimeout(4000);
  const aChat = await A.$eval('#chatlog', e => e.textContent);
  console.log('A sees B roll:', aChat.includes('ทอยจาก B'));
  // GM flags
  console.log('A isGM', await A.evaluate(() => window.__kirana ? document.body.textContent.includes('คุณเป็น GM') : null), 'B isGM', await B.evaluate(() => document.body.textContent.includes('คุณเป็น GM')));
  console.log('peers A:', await A.$eval('#peers', e => e.textContent).catch(()=>'-'), 'peers B:', await B.$eval('#peers', e => e.textContent).catch(()=>'-'));
  await A.screenshot({ path: '/home/claude/kirana-web/test/20-sync-A.png' }); await B.screenshot({ path: '/home/claude/kirana-web/test/21-sync-B.png' });
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
