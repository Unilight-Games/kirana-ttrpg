// v1.18 (12 พ.ย. 2026):
// 1) คำพูดของเนเมสไซอาร์ตามชีทที่ผู้ใช้แก้ (87 ข้อความ 7 สีหน้า) · สีหน้าของบรรทัดบุคลิกภาพ +3 และเรื่องเล่าของวงศาแยกรายบรรทัดได้
// 2) ตัวเลือกภาษาของตัวละคร: รายการภาษาจากไฟล์แกน สิทธิ์ของวงศาจากไฟล์วงศา วิซาร์ดบังคับเลือก ชีทแสดงเป็นป้ายและแก้ได้
// 3) พื้นที่จด (Memo) เติมช่องว่างท้ายคอลัมน์ของชีท ทุกคอลัมน์จบที่เส้นเดียวกัน
// 4) คลัง NPC และ Asset: หน้า #npcs ตัวแก้ไข เผยแพร่ ค้นหา เก็บสำเนา วางลงบอร์ดจากในห้อง หมากชนิด Asset เก็บหมากกลับเข้าคลัง แผนที่เก็บ Asset ไปด้วย
// 5) ไอคอนหมากจาก ttrpg-icons.js (4,085 แบบ โหลดเมื่อเปิดหน้าต่างเลือก) เลือกใช้กับ NPC และ Asset ปรับสีไอคอนกับสีพื้น ติดไปกับหมาก แผนที่ และการเผยแพร่
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const iconReqs = []; page.on('request', r => { if (/ttrpg-icons\.js/.test(r.url())) iconReqs.push(r.url()); });
  let promptText = 'ค่ายโจร'; page.on('dialog', d => d.type() === 'prompt' ? d.accept(promptText) : d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const shot = async (name, full) => { await page.evaluate(() => { if (typeof DiceShow !== 'undefined') DiceShow.clear(); }); await page.waitForTimeout(150); await page.screenshot({ path: path.resolve(__dirname, name), fullPage: !!full }); };
  const reload = async (hash) => { await page.goto(url + (hash || '')); await page.reload(); await page.waitForTimeout(900); };
  await page.goto(url); await page.waitForTimeout(400);

  // ================= A) ข้อมูลภาษา =================
  const data = await page.evaluate(() => ({ n: LANGS.length, groups: ['common', 'culture', 'restricted'].map(g => LANGS.filter(l => l.group === g).map(l => l.id).join(',')), common: LANG.common, kins: DATA.kins.map(k => k.id + ':' + k.lang.fixed.join('+') + (k.lang.choose ? '?' + (Array.isArray(k.lang.choose) ? k.lang.choose.join('/') : k.lang.choose) : '')),
    open: langOptions(KIN.lunaryn), rim: langOptions(KIN.rimmen), na: langOptions(KIN['night-alves']), none: langOptions(KIN.norlan), label: langLabel('gromdul'), unknown: langLabel('zzz'), fromPick: DATA.kins.flatMap(k => [...k.childhood, ...k.adulthood].filter(b => b.langFromPick).map(b => k.id + '/' + b.code)), necroNote: KIN.necrobug.lang.notes.common, texts: LANGS.every(l => l.th && l.en && l.text) }));
  ok('17 languages in three groups', data.n === 17 && data.groups[0] === 'common,elaraic,gromdul,sign' && data.groups[1] === 'orcish,az-zillinar,swalanim,old-nord,bestial,reo-moana,celestian,langkasian' && data.groups[2] === 'nightkin,sylvian,telepathy,sign-aura,brood' && data.texts, data.groups);
  ok('language text comes from the core file', data.common.th === 'อัลธาลานี/ภาษากลาง' && data.common.en === 'Althalani/Common Greatland' && /^เป็นภาษากลางที่ใช้กันอย่างแพร่หลาย/.test(data.common.text), data.common);
  ok('kin language specs', JSON.stringify(data.kins) === JSON.stringify(['lunaryn:common?open', 'solrin:common?open', 'nightkin:common+nightkin', 'rimmen:common?celestian/langkasian', 'norlan:common+old-nord', 'day-alves:common+elaraic', 'night-alves:common?nightkin/elaraic', 'handerlaw-dwarves:common+gromdul', 'swalan:common+sign-aura', 'floran:common+sylvian', 'orcarim:common+orcish', 'necrobug:common+sign+brood']), data.kins);
  ok('open choice excludes Common and the restricted group', data.open.join(',') === 'elaraic,gromdul,sign,orcish,az-zillinar,swalanim,old-nord,bestial,reo-moana,celestian,langkasian' && data.rim.join(',') === 'celestian,langkasian' && data.na.join(',') === 'nightkin,elaraic' && data.none.length === 0, [data.open, data.rim, data.na]);
  const lk = await page.evaluate(() => ({ text: LANG.langkasian.text, note: LANG.langkasian.note || null, th: LANG.langkasian.th, group: LANG.langkasian.group }));
  ok('langkasian has a rough description for players', lk.th === 'ภาษาแลงกาเซีย' && lk.group === 'culture' && lk.note === null && /^ภาษากลางของผู้คนจากแลงกาเซีย ทวีปที่ใหญ่และหลากวัฒนธรรมที่สุดของคีรันนา/.test(lk.text) && /ใช้คุยกันข้ามถิ่น/.test(lk.text) && /Ikiyin และ Kyokan/.test(lk.text) && /คล้ายกลุ่มภาษาเอเชียตะวันออกและอุษาคเนย์ของโลกเรา/.test(lk.text) && lk.text.length < 280 && !/ไฟล์แกน|ไฟล์วงศา/.test(lk.text), lk);
  ok('labels and trait language source', data.label === 'ภาษาคนแคระ (Gromdûl)' && data.unknown === 'zzz' && data.fromPick.join() === 'day-alves/C5' && /พูดออกเสียงไม่ได้/.test(data.necroNote), [data.label, data.fromPick]);

  // ================= B) วิซาร์ด: เลือกภาษา =================
  await page.evaluate(() => { location.hash = '#wizard'; }); await page.waitForTimeout(300);
  await page.evaluate(() => { startWizard(null); selectKin(W.char, 'lunaryn'); }); await page.waitForTimeout(300);
  const w1 = await page.evaluate(() => ({ blocker: stepBlocker(0), done: stepDone(0), opts: [...document.querySelectorAll('.langopt')].map(e => e.dataset.lang), grp: [...document.querySelectorAll('.langgrp')].map(e => e.textContent), side: [...document.querySelectorAll('.side .tag.lang')].map(e => e.textContent + (e.classList.contains('warn') ? '!' : '')), fixed: [...document.querySelectorAll('.langbox > .langs .tag.lang')].map(e => e.textContent), evoBoxes: [...document.querySelectorAll('#v-create .infobox')].filter(b => /Descendants of Evolver/.test(b.textContent) && !b.classList.contains('profile')).length, hint: /เลือกตรงนี้ไม่ได้/.test(document.querySelector('.langbox').textContent) }));
  ok('lunaryn must pick one more language', /เลือกภาษาที่ตัวละครพูดได้อีก 1 ภาษา/.test(w1.blocker) && w1.done === false && w1.opts.length === 11 && w1.grp.join('|') === 'ภาษากลาง|ภาษาตามเผ่าพันธุ์และวัฒนธรรม' && w1.hint, w1);
  ok('side panel shows languages with a missing mark', w1.side.length === 2 && w1.side[0] === 'อัลธาลานี/ภาษากลาง (Althalani/Common Greatland)' && w1.side[1] === 'ยังไม่ได้เลือกภาษา!' && w1.fixed.length === 1, w1.side);
  ok('evolver has a single box', w1.evoBoxes === 1, w1.evoBoxes);
  await page.evaluate(() => document.querySelector('.langbox').scrollIntoView({ block: 'start' })); await shot('170-lang-wizard-v118.png');
  // ปุ่มขั้นต่อไปถูกกันไว้จนกว่าจะเลือก
  await page.click('text=ขั้นต่อไป →'); await page.waitForTimeout(200);
  ok('next is blocked without a language', await page.evaluate(() => W.step) === 0);
  await page.click('.langopt[data-lang="az-zillinar"]'); await page.waitForTimeout(300);
  const w2 = await page.evaluate(() => ({ blocker: stepBlocker(0), done: stepDone(0), pick: W.char.langPick, sel: [...document.querySelectorAll('.langopt.sel')].map(e => e.dataset.lang), side: [...document.querySelectorAll('.side .tag.lang')].map(e => e.textContent), langs: charLanguages(W.char).map(x => x.src + ':' + x.id) }));
  ok('picking a language clears the blocker', w2.blocker === null && w2.done === true && w2.pick === 'az-zillinar' && w2.sel.join() === 'az-zillinar' && w2.side[1] === 'อัซ-ซิลลินาร์ (Az-Zillinar)' && w2.langs.join() === 'kin:common,pick:az-zillinar', w2);
  await page.focus('.langopt[data-lang="old-nord"]'); await page.keyboard.press('Enter'); await page.waitForTimeout(250);
  ok('keyboard picks a language', await page.evaluate(() => W.char.langPick) === 'old-nord');
  const kinsW = {};
  for (const kin of ['rimmen', 'night-alves', 'necrobug', 'day-alves', 'solrin']) { await page.evaluate((k) => { selectKin(W.char, k); }, kin); await page.waitForTimeout(200); kinsW[kin] = await page.evaluate(() => ({ pick: W.char.langPick, blocker: stepBlocker(0), opts: [...document.querySelectorAll('.langopt')].map(e => e.dataset.lang), ask: (document.querySelector('.langask') || {}).textContent || '', side: [...document.querySelectorAll('.side .tag.lang')].map(e => e.textContent) })); }
  ok('changing kin resets the pick', Object.values(kinsW).every(v => v.pick === null), Object.values(kinsW).map(v => v.pick));
  ok('rimmen picks a home language', kinsW.rimmen.opts.join() === 'celestian,langkasian' && kinsW.rimmen.ask === 'เลือกภาษาบ้านเกิด 1 ภาษา' && /เลือกภาษาบ้านเกิดของตัวละคร 1 ภาษา/.test(kinsW.rimmen.blocker), kinsW.rimmen);
  ok('night alves pick between two', kinsW['night-alves'].opts.join() === 'nightkin,elaraic' && !!kinsW['night-alves'].blocker, kinsW['night-alves']);
  ok('necrobug has fixed languages and the mute note', kinsW.necrobug.opts.length === 0 && kinsW.necrobug.blocker === null && kinsW.necrobug.side.length === 3 && /พูดออกเสียงไม่ได้/.test(kinsW.necrobug.side[0]) && kinsW.necrobug.side[2] === 'สัญญาณรัง (Brood Signal)', kinsW.necrobug);
  ok('day alves fixed languages', kinsW['day-alves'].opts.length === 0 && kinsW['day-alves'].side.join('|') === 'อัลธาลานี/ภาษากลาง (Althalani/Common Greatland)|ภาษาเอลฟ์ (Elaraic)', kinsW['day-alves']);
  ok('solrin has the open choice too', kinsW.solrin.opts.length === 11 && !!kinsW.solrin.blocker, kinsW.solrin.opts.length);
  // เสร็จสิ้นวิซาร์ดโดยยังไม่เลือกภาษา → เด้งกลับขั้นแรก
  const fin = await page.evaluate(() => { W.step = 7; finishWizard(); return { step: W.step, toast: document.querySelector('#toast').textContent }; });
  ok('finish is sent back to the kin step', fin.step === 0 && /เลือกภาษา/.test(fin.toast), fin);

  // ================= C) ชีท: ป้ายภาษา หน้าต่างแก้ภาษา และการย้ายข้อความเดิม =================
  await page.evaluate(() => { const K = window.__kirana; const mk = (id, name, kinId, over) => { const kin = DATA.kins.find(k => k.id === kinId); K.Store.upsert(Object.assign(newChar(), { id, name, kin: kinId, size: kin.sizes[0], childhood: kin.childhood[0].code, adulthood: kin.adulthood[0].code, extra: {}, step: 7 }, over || {})); };
    mk('t18a', 'ลูน่าทดสอบ', 'lunaryn', { extraText: { languages: KIN.lunaryn.languages } });               // ข้อความตั้งต้นของวงศาเดียวกัน
    mk('t18b', 'เอลฟ์ทูต', 'day-alves', { childhood: 'C5', traitPicks: { 'bg:C5': 'คนแคระ' }, extraText: { languages: 'พูดสำเนียงชาวเขาได้นิดหน่อย' } });
    mk('t18c', 'นอร์ทเก่า', 'norlan', { extraText: { languages: KIN.lunaryn.languages } });                    // ข้อความตั้งต้นค้างจากวงศาเดิม
    mk('t18d', 'ด้วงเงียบ', 'necrobug', {});
    mk('t18e', 'เอลฟ์ไม่ระบุ', 'day-alves', { childhood: 'C5' }); });
  await reload('#sheet-t18a');
  const s1 = await page.evaluate(() => ({ chips: [...document.querySelectorAll('#v-sheet .sheetlangs .tag.lang')].map(e => e.textContent + (e.classList.contains('warn') ? '!' : '')), note: !!document.querySelector('.langnote-view'), stored: window.__kirana.Store.get('t18a').extraText.languages, btn: !!document.querySelector('.langedit'), oldInput: document.querySelectorAll('#v-sheet .idgrid input').length }));
  ok('sheet shows language chips and clears the default sentence', s1.chips.join('|') === 'อัลธาลานี/ภาษากลาง (Althalani/Common Greatland)|ยังไม่ได้เลือกภาษา!' && s1.stored === '' && !s1.note && s1.btn, s1);
  await page.click('.langedit'); await page.waitForTimeout(300);
  ok('modal opens with the picker when the choice is missing', await page.evaluate(() => document.querySelectorAll('#modal .langopt').length) === 11);
  await page.click('#modal .langopt[data-lang="old-nord"]'); await page.waitForTimeout(300);
  ok('picker folds after picking', await page.evaluate(() => ({ opts: document.querySelectorAll('#modal .langopt').length, line: (document.querySelector('#modal .langpicked') || {}).textContent || '' })).then(v => v.opts === 0 && /ภาษานอร์ทโบราณ \(Old Nord\)/.test(v.line)));
  await page.selectOption('#modal .langadd', 'sign'); await page.click('#modal .langaddbtn'); await page.waitForTimeout(250);
  await page.fill('#modal .langfree', 'ภาษาถิ่นหุบเขา'); await page.keyboard.press('Enter'); await page.waitForTimeout(250);
  await page.fill('#modal .langfree', 'ภาษาถิ่นหุบเขา'); await page.click('#modal .langaddbtn'); await page.waitForTimeout(250); // ซ้ำ: ไม่เพิ่ม
  await page.fill('#modal .langnote', 'พูดติดสำเนียงจันทร์โลหิต'); await page.evaluate(() => document.querySelector('#modal .langnote').blur()); await page.waitForTimeout(250);
  const s2 = await page.evaluate(() => { const c = window.__kirana.Store.get('t18a'); return { pick: c.langPick, extra: c.langExtra, note: c.extraText.languages, sheet: [...document.querySelectorAll('#v-sheet .sheetlangs .tag.lang')].map(e => e.textContent), noteView: (document.querySelector('.langnote-view') || {}).textContent, addOpts: [...document.querySelectorAll('#modal .langadd option')].map(o => o.value).filter(Boolean) }; });
  ok('modal saves pick, extras and note', s2.pick === 'old-nord' && JSON.stringify(s2.extra) === JSON.stringify(['sign', 'ภาษาถิ่นหุบเขา']) && s2.note === 'พูดติดสำเนียงจันทร์โลหิต' && s2.sheet.join('|') === 'อัลธาลานี/ภาษากลาง (Althalani/Common Greatland)|ภาษานอร์ทโบราณ (Old Nord)|ภาษามือสากล (Common Sign Languages)|ภาษาถิ่นหุบเขา' && s2.noteView === 'พูดติดสำเนียงจันทร์โลหิต', s2);
  ok('languages already known are not offered again', !s2.addOpts.includes('common') && !s2.addOpts.includes('old-nord') && !s2.addOpts.includes('sign') && s2.addOpts.includes('telepathy'), s2.addOpts);
  await shot('171-lang-modal-v118.png');
  await page.click('#modal .chipx'); await page.waitForTimeout(250);
  await page.click('#modal .langchange'); await page.waitForTimeout(250); await page.click('#modal .langopt[data-lang="celestian"]'); await page.waitForTimeout(250);
  const s3 = await page.evaluate(() => { const c = window.__kirana.Store.get('t18a'); return { pick: c.langPick, extra: c.langExtra }; });
  ok('remove an extra and change the pick', s3.pick === 'celestian' && JSON.stringify(s3.extra) === JSON.stringify(['ภาษาถิ่นหุบเขา']), s3);
  await page.evaluate(() => modal(null));
  await reload('#sheet-t18a');
  ok('language data survives a reload', await page.evaluate(() => [...document.querySelectorAll('#v-sheet .sheetlangs .tag.lang')].map(e => e.textContent).join('|')) === 'อัลธาลานี/ภาษากลาง (Althalani/Common Greatland)|ภาษาซีเลสเทียน (Celestian)|ภาษาถิ่นหุบเขา');
  await reload('#sheet-t18b');
  const s4 = await page.evaluate(() => ({ chips: [...document.querySelectorAll('#v-sheet .sheetlangs .tag.lang')].map(e => e.textContent + '~' + e.title), note: (document.querySelector('.langnote-view') || {}).textContent }));
  ok('cosmopolitan pick shows as a language and a typed note is kept', s4.chips.length === 3 && /^ภาษาของคนแคระ~พูดและอ่านได้ จากพื้นหลัง นักการทูตแห่งวงศา$/.test(s4.chips[2]) && s4.note === 'พูดสำเนียงชาวเขาได้นิดหน่อย', s4);
  await page.evaluate(() => document.querySelector('.sheetlangs').scrollIntoView({ block: 'center' })); await shot('172-lang-sheet-v118.png');
  await reload('#sheet-t18c');
  ok('a stale default sentence from another kin is cleared', await page.evaluate(() => ({ t: window.__kirana.Store.get('t18c').extraText.languages, chips: [...document.querySelectorAll('#v-sheet .sheetlangs .tag.lang')].map(e => e.textContent).join('|'), note: !!document.querySelector('.langnote-view') })).then(v => v.t === '' && v.chips === 'อัลธาลานี/ภาษากลาง (Althalani/Common Greatland)|ภาษานอร์ทโบราณ (Old Nord)' && !v.note));
  await page.click('.langedit'); await page.waitForTimeout(250);
  ok('modal for a kin without a choice has no picker', await page.evaluate(() => ({ opts: document.querySelectorAll('#modal .langopt').length, picked: !!document.querySelector('#modal .langpicked'), add: !!document.querySelector('#modal .langadd') })).then(v => v.opts === 0 && !v.picked && v.add));
  await page.evaluate(() => modal(null));
  await reload('#sheet-t18e');
  ok('unnamed cosmopolitan pick is flagged', await page.evaluate(() => [...document.querySelectorAll('#v-sheet .sheetlangs .tag.lang')].map(e => e.textContent + (e.classList.contains('warn') ? '!' : ''))).then(v => v[2] === 'ภาษาของเผ่าพันธมิตร 1 เผ่า!'));

  // ================= D) พื้นที่จด (Memo) =================
  const cols = () => page.evaluate(() => { const z = uiZoom(); const cs = document.querySelector('#v-sheet .cs'); const top = cs.getBoundingClientRect().top; const cc = [...cs.querySelectorAll(':scope > .cscol')];
    return { n: cc.length, free: cs.classList.contains('free'), cols: cc.map(col => ({ keys: [...col.children].map(b => b.dataset.k), bottom: Math.round(([...col.children].pop().getBoundingClientRect().bottom - top) / z) })), pads: [...cs.querySelectorAll('.box.memo')].map(b => ({ k: b.dataset.k, h: Math.round(b.getBoundingClientRect().height / z), v: b.querySelector('textarea').value, dis: b.querySelector('textarea').disabled })) }; });
  await reload('#sheet-t18c');
  const m1 = await cols();
  const bottoms = m1.cols.map(c => c.bottom);
  ok('three columns end on the same line', m1.n === 3 && Math.max(...bottoms) - Math.min(...bottoms) <= 1, bottoms);
  ok('short columns get memo pads, the tallest does not', m1.pads.length === 2 && m1.cols[0].keys.slice(-1)[0] === 'memo0' && m1.cols[1].keys.slice(-1)[0] === 'memo1' && !m1.cols[2].keys.includes('memo2') && m1.pads.every(p => p.h >= 118 && p.v === ''), m1);
  await page.fill('.memo-ta[data-pad="0"]', 'พบเฒ่าเบรันที่ท่าเรือ\nติดหนี้ร้านเหล้า 3 เกรฟ\nนัดคืนเดือนดับที่หอระฆัง'); await page.evaluate(() => document.querySelector('.memo-ta[data-pad="0"]').blur()); await page.waitForTimeout(250);
  ok('memo text is saved per column', await page.evaluate(() => window.__kirana.Store.get('t18c').extraText.pad0) === 'พบเฒ่าเบรันที่ท่าเรือ\nติดหนี้ร้านเหล้า 3 เกรฟ\nนัดคืนเดือนดับที่หอระฆัง');
  const ruled = await page.evaluate(() => { const ta = document.querySelector('.memo-ta'); const cs = getComputedStyle(ta); return { bg: cs.backgroundImage.slice(0, 25), lh: cs.lineHeight, resize: cs.resize, border: cs.borderTopWidth }; });
  ok('memo is ruled paper', /repeating-linear-gradient/.test(ruled.bg) && ruled.lh === '27px' && ruled.resize === 'none' && ruled.border === '0px', ruled);
  await page.evaluate(() => document.querySelector('.box.memo').scrollIntoView({ block: 'start' })); await shot('173-memo-v118.png');
  await page.setViewportSize({ width: 1000, height: 900 }); await page.reload(); await page.waitForTimeout(900);
  const m2 = await cols(); const b2 = m2.cols.map(c => c.bottom);
  ok('two columns: the pad with text stays and bottoms align', m2.n === 2 && Math.max(...b2) - Math.min(...b2) <= 1 && m2.pads.some(p => p.k === 'memo0' && /เฒ่าเบรัน/.test(p.v)), m2);
  await page.setViewportSize({ width: 600, height: 900 }); await page.reload(); await page.waitForTimeout(900);
  const m3 = await cols();
  ok('one column: only the pad that has text', m3.n === 1 && m3.pads.length === 1 && m3.pads[0].k === 'memo0', m3.pads);
  await page.evaluate(() => { const c = window.__kirana.Store.get('t18c'); c.extraText.pad2 = 'ข้อความของคอลัมน์ขวา'; window.__kirana.Store.upsert(c); });
  await page.setViewportSize({ width: 1000, height: 900 }); await page.reload(); await page.waitForTimeout(900);
  const m4 = await cols();
  ok('a pad whose column is gone moves to another column', m4.n === 2 && m4.pads.some(p => p.k === 'memo2' && p.v === 'ข้อความของคอลัมน์ขวา') && m4.pads.some(p => p.k === 'memo0'), m4.pads);
  await page.setViewportSize({ width: 1400, height: 1000 }); await page.reload(); await page.waitForTimeout(900);
  const m5 = await cols(); const b5 = m5.cols.map(c => c.bottom);
  ok('three columns with a pad in the tallest column still align', m5.pads.length === 3 && m5.cols[2].keys.slice(-1)[0] === 'memo2' && Math.max(...b5) - Math.min(...b5) <= 1, [m5.pads.map(p => p.k), b5]);
  // โหมดมืด
  await page.evaluate(() => { UI.theme = 'dark'; UI.persist(); UI.apply(); }); await page.waitForTimeout(200);
  ok('memo is ruled in the dark theme too', await page.evaluate(() => /repeating-linear-gradient/.test(getComputedStyle(document.querySelector('.memo-ta')).backgroundImage)));
  await page.evaluate(() => document.querySelector('.box.memo').scrollIntoView({ block: 'start' })); await shot('174-memo-dark-v118.png');
  await page.evaluate(() => { UI.theme = 'paper'; UI.persist(); UI.apply(); });
  // โหมดจัดวางกรอบเอง
  await page.evaluate(() => { saveLayout({ free: true, boxes: {} }); }); await page.reload(); await page.waitForTimeout(900);
  const fr = await page.evaluate(() => { const cs = document.querySelector('#v-sheet .cs'); return { free: cs.classList.contains('free'), memos: [...cs.querySelectorAll('.box.memo')].map(b => ({ k: b.dataset.k, y: parseInt(b.style.top), h: parseInt(b.style.height), grip: !!b.querySelector('.box-grip') })) }; });
  ok('free layout keeps the pads as movable boxes', fr.free && fr.memos.length === 3 && fr.memos.every(m => m.grip && m.h >= 60), fr);
  await page.evaluate(() => { saveLayout({ free: true, boxes: { id: { x: 0, y: 0, w: 400, h: 500 }, notes: { x: 420, y: 3000, w: 400, h: 300 } } }); }); await page.reload(); await page.waitForTimeout(900);
  const fr2 = await page.evaluate(() => [...document.querySelectorAll('#v-sheet .cs .box[data-k]')].map(b => ({ k: b.dataset.k, y: parseInt(b.style.top), h: parseInt(b.style.height) })).filter(b => /memo|notes/.test(b.k)));
  const notesBottom = fr2.find(b => b.k === 'notes').y + fr2.find(b => b.k === 'notes').h;
  ok('with a saved layout new pads go below everything', fr2.filter(b => /memo/.test(b.k)).every(b => b.y >= notesBottom) && new Set(fr2.map(b => b.y)).size === fr2.length, fr2);
  await page.evaluate(() => { saveLayout({ free: false, boxes: {} }); });

  // ================= E) คำพูดของเนเมสไซอาร์ตามชีทที่ผู้ใช้แก้ =================
  await reload('#home');
  const nem = await page.evaluate(() => { const srcs = [JSON.stringify(COACH_KIN), JSON.stringify(COACH_PERS3)].join('\n'); const lessons = JSON.stringify(LESSONS);
    return { pers: Object.values(COACH_PERS3).every(v => Array.isArray(v) && v.length === 2 && v.every(o => o && typeof o.text === 'string' && o.text.length > 10 && typeof o.mood === 'string')), logicR: COACH_PERS3.logic[1].mood, othersL: COACH_PERS3.others[0].mood, compL: COACH_PERS3.compassion[0].mood, logicText: COACH_PERS3.logic[1].text.slice(0, 40),
      norlan: COACH_KIN.norlan.storyMood, norlanFn: K_storyMood(KIN.norlan), lunFn: K_storyMood(KIN.lunaryn), swalan: COACH_KIN.swalan.mood, orc: COACH_KIN.orcarim.mood, swJoke: COACH_KIN.swalan.joke.slice(0, 60),
      oldSpelling: /สวาลัน/.test(srcs), wizardWord: /วิซาร์ด/.test(srcs + lessons), modDot: (srcs.match(/Mod\. /g) || []).length, modBare: (srcs.match(/Mod [+−\-{$]/g) || []).length,
      statsTitle: (LESSONS.find(l => l.id === 'stats') || {}).title, home: document.querySelector('#v-home').textContent }; });
  ok('personality lines carry their own mood', nem.pers && nem.logicR === 'mad' && nem.othersL === 'surprise' && nem.compL === 'mad' && /^สัญชาตญาณ \+3 ลงมือก่อนคิดเสมอ/.test(nem.logicText), [nem.logicR, nem.othersL, nem.compL, nem.logicText]);
  ok('kin story mood', nem.norlan === 'smirk' && nem.norlanFn === 'smirk' && nem.lunFn === null && nem.swalan === 'guilty' && nem.orc === 'guilty', [nem.norlan, nem.lunFn, nem.swalan, nem.orc]);
  ok('edited wording is in', /^สวาลาน เราไม่รู้จักเจ้าเท่าไร แต่แคสเซทแอบกระซิบ/.test(nem.swJoke) && !nem.oldSpelling && !nem.wizardWord && nem.modDot > 10 && nem.statsTitle === 'ค่าพลังหกค่า และ Mod. ที่ซ่อนอยู่ข้างใต้', [nem.swJoke, nem.oldSpelling, nem.wizardWord, nem.modDot, nem.statsTitle]);
  ok('home greeting is the edited one', /ยินดีต้อนรับ ลูกรัก เราชื่อเนเมสไซอาร์ คนที่จะนั่งข้างเจ้าบนโต๊ะนี้/.test(nem.home) && /เกมนี้มีแนวคิดง่าย ๆ ว่าเจ้ายอมเสียอะไร เพื่อให้ได้สิ่งที่ต้องการ/.test(nem.home), nem.home.slice(0, 120));
  // โค้ชพูดบรรทัดบุคลิกภาพ +3 ด้วยสีหน้าของบรรทัดนั้น
  const coachSay = await page.evaluate(() => { const c = Object.assign(newChar(), { kin: 'norlan', size: 'Medium' }); c.personality = { logic: { side: 'right', value: 3 } }; W.char = c; W.step = 2; const d = compute(c); const out = coachCompute(c, d, 2); return out.mood + '|' + out.lines.some(l => /^สัญชาตญาณ \+3 ลงมือก่อนคิดเสมอ/.test(l)); });
  ok('coach shows the +3 line with its own mood', coachSay === 'mad|true', coachSay);

  // ================= F) คลัง NPC และ Asset (โหมดออฟไลน์) =================
  await page.goto(url + '#npcs'); await page.waitForTimeout(500);
  const p0 = await page.evaluate(() => ({ title: document.querySelector('#v-npcs h2').textContent, nav: [...document.querySelectorAll('#nav a.active')].map(a => a.textContent).join(), empty: document.querySelector('#v-npcs .card.dim').textContent, warn: !!document.querySelector('#v-npcs .warnbox'), homeLink: !!document.querySelector('#v-home a[href="#npcs"]') }));
  ok('library page', p0.title === 'สร้างและค้นหา NPC กับ Asset' && p0.nav === 'NPC / Asset' && /คลังยังว่าง/.test(p0.empty) && p0.warn && p0.homeLink, p0);
  await page.click('.newnpc'); await page.waitForTimeout(400);
  ok('new NPC opens the editor', await page.evaluate(() => /^#npcedit-[a-z0-9]+$/.test(location.hash) && document.querySelector('#v-npcs h2').textContent === 'แก้ไข NPC' && document.querySelector('#nav a.active').textContent === 'NPC / Asset'));
  await page.fill('input[data-f="name"]', 'โจรดักปล้นริมทาง'); await page.fill('input[data-f="hp"]', '14'); await page.fill('input[data-f="init"]', '2'); await page.fill('input[data-f="tgh"]', '3');
  await page.check('input[data-f="nv"]'); await page.fill('textarea[data-f="desc"]', 'ชายร่างผอมคลุมผ้าสีฝุ่น มือขวาซ่อนไว้ใต้เสื้อคลุม'); await page.fill('textarea[data-f="note"]', 'Might +1 มีดสั้น 1 PDMG หนีเมื่อ HP ต่ำกว่า 5');
  ok('editor marks unsaved changes', await page.textContent('.libsave') === 'บันทึก •');
  const png = await page.evaluate(() => { const cv = document.createElement('canvas'); cv.width = 300; cv.height = 200; const ctx = cv.getContext('2d'); ctx.fillStyle = '#7a1f1f'; ctx.fillRect(0, 0, 300, 200); ctx.fillStyle = '#fff'; ctx.font = '90px sans-serif'; ctx.fillText('โจ', 90, 130); return cv.toDataURL('image/png').split(',')[1]; });
  await page.setInputFiles('.libimgfile', { name: 'bandit.png', mimeType: 'image/png', buffer: Buffer.from(png, 'base64') }); await page.waitForTimeout(700);
  const e1 = await page.evaluate(() => { const it = NpcLib.mine[0]; const img = new Image(); return new Promise(res => { img.onload = () => res({ name: it.name, hp: it.hp, init: it.init, tgh: it.tgh, nv: it.nv, w: img.naturalWidth, h: img.naturalHeight, kb: Math.round(it.image.data.length / 1024), head: it.image.data.slice(0, 15), stored: JSON.parse(localStorage.getItem('kirana.npcs.v1'))[0].name, preview: !!document.querySelector('#v-npcs .libav img') }); img.src = it.image.data; }); });
  ok('token image is a small 160px square and the upload saves the item', e1.w === 160 && e1.h === 160 && e1.kb < 40 && /^data:image\/(webp|png)/.test(e1.head) && e1.stored === 'โจรดักปล้นริมทาง' && e1.hp === 14 && e1.init === 2 && e1.tgh === 3 && e1.nv === true && e1.preview, e1);
  await shot('175-npc-editor-v118.png');
  await page.click('button:has-text("← คลัง NPC / Asset")'); await page.waitForTimeout(400);
  await page.click('.newasset'); await page.waitForTimeout(400);
  ok('asset editor', await page.evaluate(() => document.querySelector('#v-npcs h2').textContent === 'แก้ไข Asset' && document.querySelectorAll('.iconpick button').length === ASSET_ICONS.length && !document.querySelector('input[data-f="init"]') && !document.querySelector('input[data-f="nv"]')));
  await page.fill('input[data-f="name"]', 'กองไฟกลางค่าย'); await page.click('.iconpick button:has-text("🔥")'); await page.check('input[data-f="torch"]'); await page.fill('textarea[data-f="desc"]', 'กองไฟที่ยังอุ่น มีหม้อเหล็กแขวนอยู่'); await page.click('.libsave'); await page.waitForTimeout(300);
  await page.click('button:has-text("← คลัง NPC / Asset")'); await page.waitForTimeout(400);
  await page.click('.newasset'); await page.waitForTimeout(400);
  await page.fill('input[data-f="name"]', 'หีบเหล็กสนิมเกาะ'); await page.fill('input[data-f="hp"]', '8'); await page.fill('textarea[data-f="note"]', 'ข้างในมี 12 เกรฟ กับดักเข็มพิษ DC 10'); await page.click('.libsave'); await page.waitForTimeout(300);
  await page.click('button:has-text("← คลัง NPC / Asset")'); await page.waitForTimeout(500);
  const cards = await page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.dataset.type + ':' + c.querySelector('h3').textContent + ' [' + [...c.querySelectorAll('.tag')].map(t => t.textContent).join('|') + ']'));
  ok('library cards', cards.length === 3 && cards.includes('asset:หีบเหล็กสนิมเกาะ [Asset|HP 8|ส่วนตัว]') && cards.includes('asset:กองไฟกลางค่าย [Asset|🔥 แหล่งแสง|ส่วนตัว]') && cards.includes('npc:โจรดักปล้นริมทาง [NPC|HP 14|Init +2|Toughness 3|👁 Dark Vision|ส่วนตัว|🖼 มีภาพหมาก (เฉพาะเจ้าของ)]'), cards);
  await shot('176-npc-library-v118.png');
  await page.click('.typef[data-type="asset"]'); await page.waitForTimeout(200);
  ok('type filter', await page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.dataset.type).join()) === 'asset,asset');
  await page.click('.typef[data-type="all"]'); await page.fill('#v-npcs .tabs input', 'โจร'); await page.waitForTimeout(200);
  ok('search', await page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard h3')].map(c => c.textContent).join()) === 'โจรดักปล้นริมทาง');
  await page.fill('#v-npcs .tabs input', ''); await page.waitForTimeout(100);
  await page.click('#v-npcs .npccard[data-type="npc"] button:has-text("ดู")'); await page.waitForTimeout(250);
  ok('preview shows the secret note to the owner', await page.evaluate(() => /บันทึก GM \(ลับ\)/.test(document.querySelector('#modal').textContent) && /Might \+1 มีดสั้น/.test(document.querySelector('#modal').textContent)));
  await page.evaluate(() => modal(null));
  await page.click('#v-npcs .npccard[data-type="npc"] button:has-text("เผยแพร่")'); await page.waitForTimeout(300);
  await page.click('#v-npcs button:has-text("ค้นหาที่เผยแพร่")'); await page.waitForTimeout(400);
  const pub = await page.evaluate(() => ({ list: [...document.querySelectorAll('#v-npcs .npccard h3')].map(c => c.textContent), local: JSON.parse(localStorage.getItem('kirana.npcs.v1')).map(x => x.type + ':' + x.name + (x.published ? '*' : '')), maps: localStorage.getItem('kirana.maps.v1') }));
  ok('publish and the published tab', pub.list.join() === 'โจรดักปล้นริมทาง' && pub.local.includes('npc:โจรดักปล้นริมทาง*') && pub.maps === null, pub);
  await page.click('#v-npcs button:has-text("คลังของฉัน")'); await page.waitForTimeout(200);
  await page.click('#v-npcs .npccard[data-type="npc"] button:has-text("ทำสำเนา")'); await page.waitForTimeout(500);
  const cp = await page.evaluate(() => NpcLib.mine.map(x => x.name + (x.image && x.image.data ? '+img' : '') + (x.published ? '*' : '')));
  ok('own copy keeps the image and is private', cp.includes('โจรดักปล้นริมทาง+img*') && cp.includes('โจรดักปล้นริมทาง (สำเนา)+img'), cp);
  await page.evaluate(() => { const c = NpcLib.mine.find(x => x.name === 'โจรดักปล้นริมทาง (สำเนา)'); return NpcLib.remove(c.id); }); await page.waitForTimeout(200);
  ok('remove', await page.evaluate(() => NpcLib.mine.length === 3 && JSON.parse(localStorage.getItem('kirana.npcs.v1')).length === 3));

  // ---- ห้อง: วางจากคลัง ----
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องทดสอบคลัง'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(500);
  await page.click('.libopen'); await page.waitForTimeout(400);
  ok('picker lists my library', await page.evaluate(() => [...document.querySelectorAll('#modal .gift b')].map(b => b.textContent).sort().join()) === ['โจรดักปล้นริมทาง', 'หีบเหล็กสนิมเกาะ', 'กองไฟกลางค่าย'].sort().join());
  await shot('177-npc-picker-v118.png');
  await page.click('#modal .libpicker button[data-type="asset"]'); await page.waitForTimeout(200);
  ok('picker type filter', await page.evaluate(() => document.querySelectorAll('#modal .gift').length) === 2);
  await page.click('#modal .libpicker button[data-type="all"]'); await page.waitForTimeout(200);
  const idOf = (name) => page.evaluate((n) => NpcLib.mine.find(x => x.name === n).id, name);
  await page.fill('#modal input[type=number]', '3');
  await page.click(`#modal .gift[data-id="${await idOf('โจรดักปล้นริมทาง')}"] .libplace`); await page.waitForTimeout(700);
  await page.fill('#modal input[type=number]', '1'); await page.uncheck('#modal input[type=checkbox]');
  await page.click(`#modal .gift[data-id="${await idOf('กองไฟกลางค่าย')}"] .libplace`); await page.waitForTimeout(400);
  await page.click(`#modal .gift[data-id="${await idOf('หีบเหล็กสนิมเกาะ')}"] .libplace`); await page.waitForTimeout(400);
  ok('picker stays open for more placements', await page.evaluate(() => !document.querySelector('#modal').classList.contains('hidden') && !!document.querySelector('#modal .liblist')));
  await page.evaluate(() => modal(null)); await page.waitForTimeout(200);
  const tk = await page.evaluate(() => Table.room.tokens.map(t => `${t.kind}:${t.name}:hp${t.hp}/${t.hpMax}:init${t.init}:tgh${t.tgh ?? '-'}/${t.tghMax ?? '-'}:${t.hidden ? 'hid' : 'vis'}:${t.torch ? 'torch' : ''}:${t.thumb ? 'thumb' : (t.icon || '')}:${t.nv ? 'nv' : ''}:${t.libId ? 'lib' : ''}`));
  ok('placed tokens carry the library values', JSON.stringify(tk) === JSON.stringify(['npc:โจรดักปล้นริมทาง 1:hp14/14:init2:tgh3/3:hid::thumb:nv:lib', 'npc:โจรดักปล้นริมทาง 2:hp14/14:init2:tgh3/3:hid::thumb:nv:lib', 'npc:โจรดักปล้นริมทาง 3:hp14/14:init2:tgh3/3:hid::thumb:nv:lib', 'asset:กองไฟกลางค่าย:hp0/0:init0:tgh-/-:vis:torch:🔥::lib', 'asset:หีบเหล็กสนิมเกาะ:hp8/8:init0:tgh-/-:vis::📦::lib']), tk);
  const pos = await page.evaluate(() => { const r = Table.room; return { npcRows: r.tokens.filter(t => t.kind === 'npc').every(t => t.y <= 3), assetRows: r.tokens.filter(t => t.kind === 'asset').every(t => t.y >= 8 && t.y <= 11), unique: new Set(r.tokens.map(t => t.x + ',' + t.y)).size === r.tokens.length, standable: r.tokens.every(t => cellStandable(r.map, t.x, t.y)), thumb: r.tokens[0].thumb.length }; });
  ok('placement rows and free cells', pos.npcRows && pos.assetRows && pos.unique && pos.standable && pos.thumb < 6000, pos);
  const board = await page.evaluate(() => ({ npc: document.querySelectorAll('.gridmap .gtok.npc').length, asset: document.querySelectorAll('.gridmap .gtok.asset').length, assetBars: document.querySelectorAll('.gridmap .gtok.asset .hpbar').length, down: document.querySelectorAll('.gridmap .gtok.down').length, imgs: document.querySelectorAll('.gridmap .gtok.npc img').length, icons: [...document.querySelectorAll('.gridmap .gtok.asset .ini')].map(e => e.textContent).sort().join(''), radius: getComputedStyle(document.querySelector('.gridmap .gtok.asset')).borderTopLeftRadius, torch: document.querySelectorAll('.gridmap .gtok.asset.torch').length, title: document.querySelector('.gridmap .gtok.asset.torch').title }));
  ok('asset tokens on the board', board.npc === 3 && board.asset === 2 && board.assetBars === 1 && board.down === 0 && board.imgs === 3 && board.icons === ['📦', '🔥'].sort().join('') && board.radius !== '50%' && board.torch === 1 && !/HP/.test(board.title), board);
  const chat = await page.evaluate(() => Table.chat.slice(0, 3).map(m => (m.gmOnly ? '[ลับ] ' : '') + m.text));
  ok('placement is logged, hidden ones secretly', chat[2] === '[ลับ] วาง โจรดักปล้นริมทาง ×3 จากคลังลงบอร์ด (ซ่อนไว้ก่อน)' && chat[1] === 'วาง กองไฟกลางค่าย จากคลังลงบอร์ด', chat);
  ok('quantity is capped', await page.evaluate(async () => { const r = Table.room; const before = r.tokens.length; const n = await placeFromLibrary(r, NpcLib.mine.find(x => x.type === 'npc'), 99, true); const added = r.tokens.length - before; r.tokens.splice(before); Table.save(); return n === LIB_PLACE_MAX && added === LIB_PLACE_MAX; }));
  // แสง: กองไฟเป็นแหล่งแสง
  ok('a lit asset is a light source', await page.evaluate(() => { const r = Table.room; const f = r.tokens.find(t => t.name === 'กองไฟกลางค่าย'); return lightSources(r).some(s => s.x === f.x && s.y === f.y); }));
  // Initiative ไม่รวม Asset
  await page.click('button:has-text("เริ่มการต่อสู้")'); await page.waitForTimeout(400);
  const ord = await page.evaluate(() => { const r = Table.room; return { order: r.enc.order.map(id => r.tokens.find(t => t.id === id).kind).join(), assetInit: r.tokens.filter(t => t.kind === 'asset').map(t => t.initRoll ?? null), list: [...document.querySelectorAll('.toklist .tok')].map(e => (e.classList.contains('asset') ? 'asset' : 'npc') + ':' + e.querySelector('.ord').textContent), mini: [...document.querySelectorAll('.toklist .tok.asset .mini')].map(e => e.textContent) }; });
  ok('assets stay out of initiative and sit last', ord.order === 'npc,npc,npc' && ord.assetInit.every(v => v === null) && ord.list.join() === 'npc:1,npc:2,npc:3,asset:·,asset:·' && ord.mini.every(t => /^Asset/.test(t) && !/Init/.test(t)) && ord.mini.some(t => /HP 8\/8/.test(t)), ord);
  await shot('178-npc-room-v118.png', true);
  await page.click('button:has-text("จบการต่อสู้")'); await page.waitForTimeout(300);
  // แผงหมากของ Asset
  await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'กองไฟกลางค่าย'); Table.sel = t.id; renderTable(); }); await page.waitForTimeout(300);
  const ap = await page.evaluate(() => { const b = document.querySelector('.twin-tok'); return { tags: [...b.querySelectorAll('.mini .tag')].map(t => t.textContent), vitals: [...b.querySelectorAll('.vital .vl')].map(v => v.textContent), btns: [...b.querySelectorAll('button')].map(x => x.textContent).filter(x => x.length > 1), sight: !!b.querySelector('.sightrow') }; });
  ok('asset panel', ap.tags.includes('Asset') && ap.tags.includes('🔥 แหล่งแสง') && ap.vitals.join() === 'HP สูงสุด' && ap.btns.join() === '+ สถานะ,🔥 แสง,🎨 ไอคอน,💾 เก็บเข้าคลัง,🙈 ซ่อน,✕ เอาออก' && !ap.sight, ap);
  await page.fill('.twin-tok .vital input[type=number]', '6'); await page.evaluate(() => document.querySelector('.twin-tok .vital input[type=number]').dispatchEvent(new Event('change'))); await page.waitForTimeout(300);
  ok('GM can give an asset HP on the table', await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'กองไฟกลางค่าย'); return t.hpMax === 6 && t.hp === 6 && [...document.querySelectorAll('.twin-tok .vital .vl')].map(v => v.textContent).join() === 'HP,HP สูงสุด'; }));
  // เก็บหมากกลับเข้าคลัง: อัปเดตรายการเดิม ชื่อไม่ติดเลขลำดับ
  await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'โจรดักปล้นริมทาง 1'); t.note = 'แก้บนโต๊ะแล้ว'; t.hpMax = 20; t.hp = 20; Table.sel = t.id; renderTable(); }); await page.waitForTimeout(300);
  ok('npc panel has the save button', await page.evaluate(() => [...document.querySelectorAll('.twin-tok button')].map(x => x.textContent).includes('💾 เก็บเข้าคลัง') && [...document.querySelectorAll('.twin-tok .mini .tag')].some(t => t.textContent === 'NPC')));
  await page.click('.libsavetok'); await page.waitForTimeout(600);
  const sb = await page.evaluate(() => NpcLib.mine.map(x => `${x.type}:${x.name}:hp${x.hp}:${x.note || ''}`));
  ok('save-back updates the same item and keeps its name', sb.length === 3 && sb.includes('npc:โจรดักปล้นริมทาง:hp20:แก้บนโต๊ะแล้ว'), sb);
  // หมากที่สร้างบนโต๊ะ (ไม่มี libId) เก็บเป็นรายการใหม่
  await page.fill('input[placeholder="ชื่อ NPC/ศัตรู"]', 'หมาป่าหิมะ'); await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(300);
  await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'หมาป่าหิมะ'); t.tghMax = 2; t.tgh = 2; Table.sel = t.id; renderTable(); }); await page.waitForTimeout(300);
  await page.click('.libsavetok'); await page.waitForTimeout(600);
  const sb2 = await page.evaluate(() => { const it = NpcLib.mine.find(x => x.name === 'หมาป่าหิมะ'); const t = Table.room.tokens.find(x => x.name === 'หมาป่าหิมะ'); return { n: NpcLib.mine.length, it: it && `${it.type}:hp${it.hp}:tgh${it.tgh}`, linked: !!(it && t.libId === it.id) }; });
  ok('a table-made NPC becomes a new library item', sb2.n === 4 && sb2.it === 'npc:hp10:tgh2' && sb2.linked, sb2);
  // เก็บแผนที่เข้าคลัง + โหลดกลับ
  await page.evaluate(() => { const r = Table.room; r.tokens = r.tokens.filter(t => t.name !== 'หมาป่าหิมะ'); r.tokens.find(t => t.name === 'หีบเหล็กสนิมเกาะ').hidden = true; Table.sel = null; Table.save(); }); await page.waitForTimeout(300);
  await page.click('button:has-text("💾 เก็บเข้าคลัง")'); await page.waitForTimeout(600);
  const ms = await page.evaluate(() => MapLib.mine.map(m => m.name + ':' + (m.npcs || []).map(n => (n.kind || 'npc') + '/' + n.name + (n.libId ? '#' : '') + (n.tgh ? 't' + n.tgh : '') + (n.torch ? 'T' : '') + (n.hidden ? 'h' : 'v') + (n.thumb ? 'IMG' : '')).join(',')));
  ok('saving the room map keeps assets without images', ms.length === 1 && ms[0] === 'ค่ายโจร:npc/โจรดักปล้นริมทาง 1#t3h,npc/โจรดักปล้นริมทาง 2#t3h,npc/โจรดักปล้นริมทาง 3#t3h,asset/กองไฟกลางค่าย#Tv,asset/หีบเหล็กสนิมเกาะ#h', ms);
  await page.click('button:has-text("ล้างหมาก")'); await page.waitForTimeout(300);
  await page.click('button:has-text("📚 คลังแผนที่")'); await page.waitForTimeout(400);
  ok('map picker tags split NPC and Asset', await page.evaluate(() => [...document.querySelectorAll('#modal .gift .tag')].map(t => t.textContent)).then(v => v.includes('3 NPC') && v.includes('2 Asset')));
  await page.click('#modal .gift button:has-text("โหลด")'); await page.waitForTimeout(1000);
  const ml = await page.evaluate(() => ({ toks: Table.room.tokens.map(t => `${t.kind}:${t.name}:${t.thumb ? 'thumb' : (t.icon || 'noimg')}:${t.hidden ? 'hid' : 'vis'}:tgh${t.tghMax ?? '-'}:${t.torch ? 'T' : ''}:hp${t.hpMax}`), chat: Table.chat.slice(0, 2).map(m => m.text) }));
  ok('loading the map brings NPC images, Toughness and assets back', JSON.stringify(ml.toks) === JSON.stringify(['npc:โจรดักปล้นริมทาง 1:thumb:hid:tgh3::hp20', 'npc:โจรดักปล้นริมทาง 2:thumb:hid:tgh3::hp14', 'npc:โจรดักปล้นริมทาง 3:thumb:hid:tgh3::hp14', 'asset:กองไฟกลางค่าย:🔥:vis:tgh-:T:hp6', 'asset:หีบเหล็กสนิมเกาะ:📦:hid:tgh-::hp8']) && ml.chat[0] === 'เพิ่ม NPC 3 ตัว (ซ่อนไว้ก่อน) Asset 2 ชิ้น' && /พร้อม NPC และ Asset ที่เตรียมไว้$/.test(ml.chat[1]), ml);
  // สุ่มแผนที่ใหม่: หมากทุกตัวยังยืนบนช่องที่ยืนได้
  await page.click('button:has-text("สุ่มแผนที่ใหม่")'); await page.waitForTimeout(400);
  ok('reseat after a new map', await page.evaluate(() => { const r = Table.room; return r.tokens.every(t => cellStandable(r.map, t.x, t.y)) && new Set(r.tokens.map(t => t.x + ',' + t.y)).size === r.tokens.length && r.tokens.filter(t => t.kind === 'asset').every(t => t.y >= 8 && t.y <= 11); }));
  // ตัวแก้ไขแผนที่แสดง Asset
  await page.evaluate(() => { location.hash = '#mapedit-' + MapLib.mine[0].id; }); await page.waitForTimeout(600);
  const med = await page.evaluate(() => ({ head: [...document.querySelectorAll('#v-maps h3')].map(x => x.textContent).find(t => /เตรียมไว้/.test(t)), assetToks: document.querySelectorAll('#v-maps .gridmap .gtok.asset').length, npcToks: document.querySelectorAll('#v-maps .gridmap .gtok.npc').length, tags: [...document.querySelectorAll('#v-maps .card .tag')].map(t => t.textContent).filter(t => t === 'Asset').length }));
  ok('map editor lists assets', med.head === 'NPC และ Asset ที่เตรียมไว้ (5)' && med.assetToks === 2 && med.npcToks === 3 && med.tags === 2, med);

  // ================= F2) ไอคอนหมากจากคลังไอคอน =================
  await page.goto(url + '#npcs'); await page.reload(); await page.waitForTimeout(600);
  ok('icon file is not loaded until the picker opens', iconReqs.length === 0 && await page.evaluate(() => typeof window.FED_ICONS === 'undefined' && IconLib.data === null));
  await page.click('.newnpc'); await page.waitForTimeout(400);
  await page.fill('input[data-f="name"]', 'หมาป่าเงา');
  ok('editor has the icon card without colours before a pick', await page.evaluate(() => !!document.querySelector('.libicocard') && document.querySelector('.icopick').textContent === 'เลือกไอคอน' && document.querySelectorAll('.icocolor').length === 0 && document.querySelectorAll('.libicocard .icocredit a').length === 2));
  await page.click('.icopick'); await page.waitForSelector('#modal .icocell', { timeout: 30000 });
  const pk = await page.evaluate(() => ({ n: IconLib.data.list.length, cats: IconLib.data.cats.length, cells: document.querySelectorAll('#modal .icocell').length, cat: document.querySelector('#modal .icocat').selectedOptions[0].textContent, count: document.querySelector('#modal .iconcount').textContent, links: [...document.querySelectorAll('#modal .icocredit a')].map(a => a.href + '|' + a.target + '|' + a.rel).join(' '), credit: /Lorc, Delapouite/.test(document.querySelector('#modal .icocredit').textContent) && /CC BY 3\.0/.test(document.querySelector('#modal .icocredit').textContent) }));
  ok('picker loads 4085 icons in 25 categories and opens on people for an NPC', pk.n === 4085 && pk.cats === 25 && iconReqs.length === 1 && /^คนและร่างกาย \(236\)$/.test(pk.cat) && pk.cells === 236 && pk.count === 'แสดง 236 จาก 236 แบบ', pk);
  ok('picker shows the CC BY credit with links', pk.credit && pk.links === 'https://game-icons.net/|_blank|noopener noreferrer https://creativecommons.org/licenses/by/3.0/|_blank|noopener noreferrer', pk.links);
  await shot('179-icon-picker-v118.png');
  await page.selectOption('#modal .icocat', '-1'); await page.waitForTimeout(250);
  const pg = await page.evaluate(() => ({ cells: document.querySelectorAll('#modal .icocell').length, count: document.querySelector('#modal .iconcount').textContent, more: (document.querySelector('#modal .icomore') || {}).textContent }));
  await page.click('#modal .icomore'); await page.waitForTimeout(250);
  ok('all categories are paged', pg.cells === 240 && pg.count === 'แสดง 240 จาก 4085 แบบ' && pg.more === 'แสดงเพิ่มอีก 240' && await page.evaluate(() => document.querySelectorAll('#modal .icocell').length) === 480, pg);
  await page.selectOption('#modal .icocat', { index: 13 }); await page.fill('#modal .icoq', 'wolf'); await page.waitForTimeout(250);
  const sr = await page.evaluate(() => ({ hits: [...document.querySelectorAll('#modal .icocell')].map(c => c.dataset.n).join(), count: document.querySelector('#modal .iconcount').textContent }));
  ok('search spans every category', sr.hits === 'direwolf,werewolf,wolf-head,wolf-howl,wolf-trap' && /ค้นจากทุกหมวด/.test(sr.count), sr);
  await page.fill('#modal .icoq', 'zzzz'); await page.waitForTimeout(200);
  ok('empty search explains itself', await page.evaluate(() => document.querySelectorAll('#modal .icocell').length === 0 && /ชื่อไอคอนเป็นภาษาอังกฤษ/.test(document.querySelector('#modal .icogrid').textContent)));
  await page.fill('#modal .icoq', 'wolf head'); await page.waitForTimeout(200);
  await page.click('#modal .icocell[data-n="wolf-head"]'); await page.waitForTimeout(300);
  const ed = () => page.evaluate(() => { const it = NpcLib.get(location.hash.replace('#npcedit-', '')); return { modalHidden: document.querySelector('#modal').classList.contains('hidden'), ico: it.ico ? [it.ico.n, it.ico.c, it.ico.b, it.ico.d.length > 100].join('|') : null, name: (document.querySelector('.iconame') || {}).textContent, pvFill: (document.querySelector('.icopv path') || { getAttribute(){ return null; } }).getAttribute('fill'), pvBg: document.querySelector('.icopv').style.background, prevFill: (document.querySelector('#v-npcs .table-wrap > div:last-child .libav path') || { getAttribute(){ return null; } }).getAttribute('fill'), dirty: document.querySelector('.libsave').textContent, sw: document.querySelectorAll('.icosw').length, btn: document.querySelector('.icopick').textContent }; });
  const ic0 = await ed();
  ok('picking sets the icon with NPC default colours', ic0.modalHidden && ic0.ico === 'wolf-head|#f2e9d8|#5a1414|true' && ic0.name === 'wolf-head' && ic0.pvFill === '#f2e9d8' && ic0.prevFill === '#f2e9d8' && ic0.dirty === 'บันทึก •' && ic0.sw === 16 && ic0.btn === 'เปลี่ยนไอคอน', ic0);
  await page.click('.icorow .icosw[data-c="#58b7ff"]'); await page.waitForTimeout(200);
  await page.click('.icorow .icosw[data-c="#14283c"]'); await page.waitForTimeout(200);
  const ic1 = await ed();
  ok('swatches change icon and background colours', ic1.ico === 'wolf-head|#58b7ff|#14283c|true' && ic1.pvFill === '#58b7ff' && ic1.pvBg === 'rgb(20, 40, 60)' && ic1.prevFill === '#58b7ff', ic1);
  await page.evaluate(() => { const i = document.querySelector('.icocolor[data-k="c"]'); i.value = '#ffcc00'; i.dispatchEvent(new Event('input', { bubbles: true })); }); await page.waitForTimeout(150);
  const ic2 = await ed();
  ok('the colour input updates live', ic2.ico === 'wolf-head|#ffcc00|#14283c|true' && ic2.pvFill === '#ffcc00' && ic2.prevFill === '#ffcc00', ic2);
  await page.evaluate(() => { document.querySelector('.icocolor[data-k="c"]').dispatchEvent(new Event('change', { bubbles: true })); }); await page.waitForTimeout(150);
  await page.click('.libsave'); await page.waitForTimeout(300);
  await shot('180-icon-editor-v118.png');
  ok('the icon is stored with the item', await page.evaluate(() => { const l = JSON.parse(localStorage.getItem('kirana.npcs.v1')).find(x => x.name === 'หมาป่าเงา'); return !!l && l.ico.n === 'wolf-head' && l.ico.c === '#ffcc00' && l.ico.b === '#14283c' && /^M/.test(l.ico.d); }));
  await page.click('button:has-text("← คลัง NPC / Asset")'); await page.waitForTimeout(400);
  await page.click('.newasset'); await page.waitForTimeout(400);
  await page.fill('input[data-f="name"]', 'หีบสมบัติ'); await page.click('.icopick'); await page.waitForSelector('#modal .icocell');
  ok('an asset opens the picker on objects', await page.evaluate(() => /^สิ่งของเครื่องใช้ \(384\)$/.test(document.querySelector('#modal .icocat').selectedOptions[0].textContent)));
  await page.fill('#modal .icoq', 'locked chest'); await page.waitForTimeout(250); await page.click('#modal .icocell[data-n="locked-chest"]'); await page.waitForTimeout(300);
  ok('asset default colours', await page.evaluate(() => { const it = NpcLib.get(location.hash.replace('#npcedit-', '')); return it.ico.n === 'locked-chest' && it.ico.c === '#d4a84a' && it.ico.b === '#1c2026' && document.querySelector('.icopv').classList.contains('asset'); }));
  await page.click('.libsave'); await page.waitForTimeout(300);
  await page.click('.icoclear'); await page.waitForTimeout(200);
  ok('the icon can be removed', await page.evaluate(() => { const it = NpcLib.get(location.hash.replace('#npcedit-', '')); return !it.ico && document.querySelector('.icopick').textContent === 'เลือกไอคอน' && document.querySelectorAll('.icocolor').length === 0; }));
  await page.click('.icopick'); await page.waitForSelector('#modal .icocell'); await page.click('#modal .icocell[data-n="locked-chest"]'); await page.waitForTimeout(300); await page.click('.libsave'); await page.waitForTimeout(300);
  await page.click('button:has-text("← คลัง NPC / Asset")'); await page.waitForTimeout(500);
  const lc = await page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.querySelector('h3').textContent + ':' + (c.querySelector('.libav svg.ico') ? c.querySelector('.libav path').getAttribute('fill') + ' on ' + c.querySelector('.libav').style.background : 'none')));
  ok('library cards draw the icons', lc.includes('หีบสมบัติ:#d4a84a on rgb(28, 32, 38)') && lc.includes('หมาป่าเงา:#ffcc00 on rgb(20, 40, 60)'), lc);
  // ข้อมูลไอคอนที่ไม่น่าไว้ใจ
  const cl = await page.evaluate(() => ({ bad: [icoClean(null), icoClean({}), icoClean({ d: 'M0 0<script>alert(1)</script>' }), icoClean({ d: 'M1 1' }), icoClean({ d: 'url(javascript:1)z'.repeat(3) })].map(x => x === null).join(), fix: JSON.stringify(icoClean({ n: 'Bad Name!', d: 'M10 10l5 5-5 5z', c: 'red', b: '#ABCDEF' })), item: JSON.stringify(libClean({ id: 'q', type: 'npc', name: 'x', ico: { n: 'a', d: '<svg onload=1>', c: '#fff' } }).ico || null) }));
  ok('icon data is validated', cl.bad === 'true,true,true,true,true' && cl.fix === '{"n":"icon","d":"M10 10l5 5-5 5z","c":"#f2e9d8","b":"#abcdef"}' && cl.item === 'null', cl);
  // ห้อง: หมากมีไอคอน
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องไอคอน'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(500);
  await page.click('.libopen'); await page.waitForTimeout(400); await page.uncheck('#modal input[type=checkbox]');
  for (const name of ['หมาป่าเงา', 'หีบสมบัติ']) { const id = await page.evaluate((n) => NpcLib.mine.find(x => x.name === n).id, name); await page.click(`#modal .gift[data-id="${id}"] .libplace`); await page.waitForTimeout(400); }
  ok('picker rows draw icons too', await page.evaluate(() => document.querySelectorAll('#modal .gift .libav svg.ico').length) === 2);
  await page.evaluate(() => modal(null)); await page.waitForTimeout(200);
  const bt = await page.evaluate(() => ({ toks: Table.room.tokens.map(t => t.kind + ':' + t.name + ':' + (t.ico ? [t.ico.n, t.ico.c, t.ico.b].join('/') : 'noico')), board: [...document.querySelectorAll('.gridmap .gtok')].map(g => (g.classList.contains('asset') ? 'asset' : 'npc') + ':' + (g.querySelector('.face.hasico svg.ico') ? g.querySelector('path').getAttribute('fill') + ' on ' + g.querySelector('.face').style.background : 'none') + ':' + !!g.querySelector('.ini')), size: Math.round(document.querySelector('.gridmap .gtok svg').getBoundingClientRect().width), av: [...document.querySelectorAll('.toklist .tok .av')].map(a => a.classList.contains('hasico') && !!a.querySelector('svg')).join() }));
  ok('tokens carry the icon and the board draws it in colour', JSON.stringify(bt.toks) === JSON.stringify(['npc:หมาป่าเงา:wolf-head/#ffcc00/#14283c', 'asset:หีบสมบัติ:locked-chest/#d4a84a/#1c2026']) && JSON.stringify(bt.board) === JSON.stringify(['npc:#ffcc00 on rgb(20, 40, 60):false', 'asset:#d4a84a on rgb(28, 32, 38):false']) && bt.size >= 18 && bt.av === 'true,true', bt);
  // GM ตั้งไอคอนให้หมากที่สร้างบนโต๊ะ
  await page.fill('input[placeholder="ชื่อ NPC/ศัตรู"]', 'โจรป่า'); await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(300);
  await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'โจรป่า'); t.hidden = false; Table.sel = t.id; renderTable(); }); await page.waitForTimeout(300);
  await page.click('.tokicobtn'); await page.waitForTimeout(300);
  ok('token icon window', await page.evaluate(() => document.querySelector('#modal h3').textContent === 'ไอคอนของ โจรป่า' && document.querySelector('#modal .icopick').textContent === 'เลือกไอคอน'));
  await page.click('#modal .icopick'); await page.waitForSelector('#modal .icocell');
  ok('token picker has a back button', await page.evaluate(() => [...document.querySelectorAll('#modal button')].some(b => b.textContent === '← กลับ')));
  await page.fill('#modal .icoq', 'bandit'); await page.waitForTimeout(250); await page.click('#modal .icocell[data-n="bandit"]'); await page.waitForTimeout(400);
  await page.click('#modal .icorow .icosw[data-c="#5bb97a"]'); await page.waitForTimeout(300);
  const tm = await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'โจรป่า'); return { ico: t.ico && [t.ico.n, t.ico.c, t.ico.b].join('/'), back: !document.querySelector('#modal').classList.contains('hidden') && !!document.querySelector('#modal .tokico'), board: (document.querySelector('.gridmap .gtok.sel path') || { getAttribute(){ return null; } }).getAttribute('fill'), btnOn: document.querySelector('.tokicobtn').classList.contains('on') }; });
  ok('GM sets and recolours a token icon on the table', tm.ico === 'bandit/#5bb97a/#5a1414' && tm.back && tm.board === '#5bb97a' && tm.btnOn, tm);
  await shot('181-icon-token-v118.png');
  await page.evaluate(() => modal(null)); await page.waitForTimeout(200);
  await shot('182-icon-room-v118.png');
  // เก็บหมากเข้าคลัง + แผนที่ ไอคอนตามไป
  await page.click('.libsavetok'); await page.waitForTimeout(600);
  ok('saving a token to the library keeps its icon', await page.evaluate(() => { const it = NpcLib.mine.find(x => x.name === 'โจรป่า'); return !!it && it.ico && it.ico.n === 'bandit' && it.ico.c === '#5bb97a'; }));
  promptText = 'ด่านไอคอน';
  await page.evaluate(() => { Table.sel = null; renderTable(); }); await page.waitForTimeout(200);
  await page.click('button:has-text("💾 เก็บเข้าคลัง")'); await page.waitForTimeout(600);
  await page.click('button:has-text("ล้างหมาก")'); await page.waitForTimeout(300);
  await page.evaluate(async () => { const m = MapLib.mine.find(x => x.name === 'ด่านไอคอน'); await applyLibraryMap(Table.room, m, true); }); await page.waitForTimeout(500);
  const mi = await page.evaluate(() => ({ saved: MapLib.mine.find(x => x.name === 'ด่านไอคอน').npcs.map(n => (n.kind || 'npc') + ':' + (n.ico ? n.ico.n + '/' + n.ico.c : 'noico')).join(), loaded: Table.room.tokens.map(t => t.kind + ':' + (t.ico ? t.ico.n + '/' + t.ico.c : 'noico')).join() }));
  ok('icons survive the map round trip', mi.saved === 'npc:wolf-head/#ffcc00,asset:locked-chest/#d4a84a,npc:bandit/#5bb97a' && mi.loaded === mi.saved, mi);
  await page.evaluate(() => { location.hash = '#mapedit-' + MapLib.mine.find(x => x.name === 'ด่านไอคอน').id; }); await page.waitForTimeout(600);
  ok('map editor draws the icons', await page.evaluate(() => document.querySelectorAll('#v-maps .gridmap .gtok .face.hasico svg.ico').length) === 3);

  // ================= G) โหมดออนไลน์ (ฐานข้อมูลจำลอง): รูปเอกสาร การกรองคลังแผนที่ การค้นหาที่เผยแพร่ การเก็บสำเนา =================
  await page.goto(url + '#home'); await page.reload(); await page.waitForTimeout(600);
  const on = await page.evaluate(async () => {
    const mem = { maps: {}, mapimages: {} }; const subs = [];
    const match = (d, filters) => filters.every(([f, v]) => d[f] === v);
    const fire = (col) => { for (const s of subs) if (s.col === col) s.cb({ docs: Object.values(mem[col]).filter(d => match(d, s.filters)).map(d => ({ data: () => JSON.parse(JSON.stringify(d)) })) }); };
    const queries = [];
    const mkQ = (col, filters) => ({ where(f, op, v){ return mkQ(col, [...filters, [f, v]]); }, limit(){ return this; }, orderBy(){ return this; },
      async get(){ queries.push(col + ':' + filters.map(x => x.join('=')).join('&')); return { docs: Object.values(mem[col] || {}).filter(d => match(d, filters)).map(d => ({ data: () => JSON.parse(JSON.stringify(d)) })) }; },
      onSnapshot(cb){ const s = { col, filters, cb }; subs.push(s); setTimeout(() => fire(col), 0); return () => {}; } });
    Store.db = { collection: (col) => { mem[col] = mem[col] || {}; return mkQ(col, []); },
      doc: (p) => { const [col, id] = p.split('/'); mem[col] = mem[col] || {}; return { async set(d){ mem[col][id] = JSON.parse(JSON.stringify(d)); fire(col); }, async get(){ const d = mem[col][id]; if (col === 'mapimages' && d && d.ownerId !== Store.me) throw new Error('permission-denied'); return { exists: !!d, data: () => d }; }, async delete(){ delete mem[col][id]; fire(col); } }; } };
    Store.me = 'u1'; Store.displayName = 'GM ทดสอบ';
    const g = generateMap('field', 's');
    mem.maps.m1 = { id: 'm1', ownerId: 'u1', name: 'แผนที่ของฉัน', cells: g.cells, kind: 'field', npcs: [], published: false, updatedAt: 5 };
    mem.maps.m9 = { id: 'm9', ownerId: 'u2', ownerName: 'คนอื่น', name: 'แผนที่เผยแพร่', cells: g.cells, kind: 'field', npcs: [], published: true, updatedAt: 6 };
    mem.maps.n9 = { id: 'n9', type: 'npc', ownerId: 'u2', ownerName: 'คนอื่น', name: 'อัศวินเสื้อคลุมน้ำเงิน', hp: 22, init: 1, tgh: 4, note: 'ลับของ GM', desc: 'เกราะขัดเงา', image: { has: true }, published: true, updatedAt: 7 };
    mem.maps.a9 = { id: 'a9', type: 'asset', ownerId: 'u2', ownerName: 'คนอื่น', name: 'ประตูเหล็ก', icon: '🚪', hp: 30, published: true, updatedAt: 8, ico: { n: 'door', d: 'M100 100l200 0 0 300-200 0z', c: '#d4a84a', b: '#14283c' } };
    mem.maps.n8 = { id: 'n8', type: 'npc', ownerId: 'u2', name: 'ของส่วนตัวคนอื่น', hp: 5, published: false, updatedAt: 9 };
    mem.mapimages.n9 = { id: 'n9', ownerId: 'u2', data: 'data:image/png;base64,AAAA' };
    // เอกสารผิดรูปจากผู้ใช้คนอื่น (Rules ไม่ตรวจชนิดข้อมูล): ต้องไม่ทำให้หน้าค้นหาพัง และต้องไม่โหลดภาพจากที่อื่น
    mem.maps.bad1 = { id: 'bad1', type: 'npc', ownerId: 'u2', name: 123, desc: { a: 1 }, note: null, hp: 'x', init: 9999, tgh: -5, nv: 'yes', published: true, image: { data: 'https://evil.example/x.png' }, updatedAt: 1 };
    mem.maps.bad2 = { id: 'bad2', type: 'asset', ownerId: 'u2', name: 'ก'.repeat(500), icon: 'ยาวมากเกินไปสำหรับไอคอน', hp: 1e9, published: true, updatedAt: 2 };
    mem.maps.bad3 = { type: 'npc', ownerId: 'u2', name: 'ไม่มีรหัส', published: true };
    mem.maps.bad1.ico = { n: 'x', d: 'M0 0"/><script>alert(1)</script>', c: '#fff', b: 'javascript:1' };
    MapLib.unsub = []; MapLib.loaded = false; MapLib.mine = []; NpcLib.unsub = []; NpcLib.loaded = false; NpcLib.mine = []; NpcLib.pub = []; NpcLib.images = {};
    const wait = (ms) => new Promise(r => setTimeout(r, ms));
    MapLib.subscribe(() => {}); NpcLib.subscribe(() => {}); await wait(50);
    const out = { mapMine: MapLib.mine.map(m => m.id).join(), libMine0: NpcLib.mine.map(m => m.id).join() };
    await MapLib.loadPublished(); await NpcLib.loadPublished();
    out.mapPub = MapLib.pub.map(m => m.id).join(); out.libPub = NpcLib.pub.filter(m => !/^bad/.test(m.id)).map(m => m.id).join(); out.pubQueries = queries.slice();
    const b1 = NpcLib.pub.find(m => m.id === 'bad1'), b2 = NpcLib.pub.find(m => m.id === 'bad2');
    out.bad = [NpcLib.pub.filter(m => /^bad/.test(m.id)).length, b1 && typeof b1.name + ':' + b1.name, b1 && typeof b1.desc, b1 && b1.note, b1 && b1.hp, b1 && b1.init, b1 && b1.tgh, b1 && b1.nv, b1 && JSON.stringify(b1.image), b2 && b2.name.length, b2 && Array.from(b2.icon).length, b2 && b2.hp].join('|');
    out.clean = [libClean(null), libClean({ type: 'map', id: 'x' }), libClean({ type: 'npc' })].map(x => x === null).join() + '|' + [libImageOk('data:image/webp;base64,AAAA'), libImageOk('https://x/y.png'), libImageOk('data:text/html;base64,AAAA'), libImageOk('javascript:alert(1)')].join();
    // สร้าง + ภาพ
    const it = NpcLib.newItem('npc'); it.name = 'ยามประตู'; it.note = 'ลับ'; await NpcLib.save(it); await NpcLib.saveImage(it, 'data:image/png;base64,BBBB'); await NpcLib.save(it); await wait(30);
    out.doc = JSON.stringify(mem.maps[it.id].image) + '|' + mem.maps[it.id].type + '|' + mem.maps[it.id].ownerId + '|' + mem.maps[it.id].ownerName; out.img = mem.mapimages[it.id] && mem.mapimages[it.id].ownerId + ':' + mem.mapimages[it.id].data.slice(-4);
    out.libMine1 = NpcLib.mine.map(m => m.name).join(); out.mapMine1 = MapLib.mine.map(m => m.id).join();
    // เก็บสำเนาของคนอื่น: ไม่ได้ภาพ จำผู้สร้างเดิม เป็นส่วนตัว บันทึกลับติดมาด้วย
    const c1 = await NpcLib.copyToMine(mem.maps.n9); await wait(30);
    out.foreign = c1 && [c1.ownerId, c1.fromId, c1.fromName, c1.published, !!c1.image, c1.note, !!mem.mapimages[c1.id], c1.tgh].join('|');
    out.foreignImg = await NpcLib.loadImage(NpcLib.pub.find(x => x.id === 'n9')); // ไม่ใช่เจ้าของ อ่านภาพไม่ได้
    // สำเนาของตัวเอง: ภาพตามไป
    const c2 = await NpcLib.copyToMine(NpcLib.mine.find(x => x.name === 'ยามประตู'), 'ยามประตู (สำเนา)'); await wait(30);
    out.own = c2 && [c2.name, !!c2.image, mem.mapimages[c2.id] && mem.mapimages[c2.id].data.slice(-4), mem.maps[c2.id].published].join('|');
    const c3 = await NpcLib.copyToMine(NpcLib.pub.find(x => x.id === 'a9')); await wait(30);
    out.icoCopy = c3 && JSON.stringify(mem.maps[c3.id].ico) + '|' + (NpcLib.pub.find(x => x.id === 'bad1').ico === undefined); await NpcLib.remove(c3.id); await wait(20);
    out.thumbById = !!(await NpcLib.loadImageById(it.id)); out.thumbForeign = await NpcLib.loadImageById('n9');
    await NpcLib.remove(c2.id); await wait(30); out.removed = !mem.maps[c2.id] && !mem.mapimages[c2.id];
    out.isMapDoc = [isMapDoc({}), isMapDoc({ type: 'map' }), isMapDoc({ type: 'npc' }), isMapDoc({ type: 'asset' }), isMapDoc(null)].join(); out.isItem = [NpcLib.isItem({ type: 'npc' }), NpcLib.isItem({ type: 'asset' }), NpcLib.isItem({}), NpcLib.isItem({ type: 'map' })].join();
    return out; });
  ok('map library ignores library items in the shared collection', on.mapMine === 'm1' && on.mapMine1 === 'm1' && on.mapPub === 'm9' && on.isMapDoc === 'true,true,false,false,false', [on.mapMine, on.mapPub, on.isMapDoc]);
  ok('npc library takes only typed docs', on.libMine0 === '' && on.libPub === 'a9,n9' && on.isItem === 'true,true,false,false' && on.pubQueries.includes('maps:published=true&type=npc') && on.pubQueries.includes('maps:published=true&type=asset'), [on.libMine0, on.libPub, on.pubQueries]);
  ok('saved doc keeps the image out of the public document', on.doc === '{"has":true}|npc|u1|GM ทดสอบ' && on.img === 'u1:BBBB' && on.libMine1 === 'ยามประตู', [on.doc, on.img]);
  ok('copy of someone else: private, credited, no image, GM note included', on.foreign === 'u1|n9|คนอื่น|false|false|ลับของ GM|false|4' && on.foreignImg === null && on.thumbForeign === null, [on.foreign, on.foreignImg]);
  ok('a published icon travels with the copy and a forged one is dropped', on.icoCopy === '{"n":"door","d":"M100 100l200 0 0 300-200 0z","c":"#d4a84a","b":"#14283c"}|true', on.icoCopy);
  ok('copy of my own keeps the image and removal deletes both docs', on.own === 'ยามประตู (สำเนา)|true|BBBB|false' && on.thumbById && on.removed, [on.own, on.removed]);
  await page.evaluate(() => { location.hash = '#npcs'; }); await page.waitForTimeout(400);
  await page.click('#v-npcs button:has-text("ค้นหาที่เผยแพร่")'); await page.waitForTimeout(500);
  const og = await page.evaluate(() => ({ warn: !!document.querySelector('#v-npcs .warnbox'), cards: [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.querySelector('h3').textContent + ':' + [...c.querySelectorAll('button:not(.rvchip)')].map(b => b.textContent).join('/')) })); // v1.19: ป้ายดาวบนการ์ดเป็นปุ่มด้วย ชุดนี้ดูเฉพาะปุ่มของคลัง
  ok('published tab offers "keep a copy" for other people\'s items', !og.warn && og.cards.slice(0, 2).join('|') === 'ประตูเหล็ก:ดู/เก็บเข้าคลัง|อัศวินเสื้อคลุมน้ำเงิน:ดู/เก็บเข้าคลัง' && og.cards.length === 4, og);
  ok('malformed published docs are coerced, not trusted', on.bad === '2|string:123|string||1|20|0|false|{"has":true}|80|3|999' && on.clean === 'true,true,true|true,false,false,false', [on.bad, on.clean]);
  ok('published cards show icons but never images', await page.evaluate(() => document.querySelectorAll('#v-npcs .npccard[data-id="a9"] .libav svg.ico').length === 1 && document.querySelectorAll('#v-npcs .npccard[data-id="bad1"] .libav svg').length === 0));
  ok('no image is ever loaded from a foreign document', await page.evaluate(() => document.querySelectorAll('#v-npcs .npccard img').length === 0 && [...document.querySelectorAll('img')].every(i => !/evil\.example/.test(i.src))));
  await page.click('#v-npcs .npccard[data-id="n9"] button:has-text("ดู")'); await page.waitForTimeout(250);
  ok('preview hides the GM note from non-owners', await page.evaluate(() => { const t = document.querySelector('#modal').textContent; return !/ลับของ GM/.test(t) && /จะเห็นเมื่อเก็บสำเนา/.test(t) && /เกราะขัดเงา/.test(t); }));
  await page.evaluate(() => modal(null));

  // ================= H) นโยบายและทางเข้า =================
  await page.goto(url + '#policy'); await page.reload(); await page.waitForTimeout(500);
  const pol = await page.evaluate(() => document.querySelector('#v-policy').textContent);
  ok('policy credits the icon authors', /game-icons\.net โดย Lorc, Delapouite และผู้ร่วมสร้าง/.test(pol) && /CC BY 3\.0/.test(pol));
  ok('policy mentions the new library', /ปรับปรุงล่าสุด \d+ พฤศจิกายน 2026/.test(pol) && /คลัง NPC และ Asset: รายการที่คุณสร้าง/.test(pol) && /ภาพหมากไม่ติดไปกับการเผยแพร่/.test(pol) && /ลบ NPC และ Asset ได้ในคลัง NPC \/ Asset/.test(pol));
  ok('nav has the new page', await page.evaluate(() => [...document.querySelectorAll('#nav a')].map(a => a.getAttribute('href')).join()) === '#home,#create,#chars,#table,#maps,#npcs,#rules,#dev');

  console.log(`checks: ${pass} passed, ${fail} failed`);
  console.log('errors', errors);
  await browser.close();
  if (fail || errors.length) process.exit(1);
})();
