// v1.21 (13 พ.ย. 2026) Non สั่งให้ใช้รูปเนเมสไซอาร์ในโฟลเดอร์ assets/Nemessiah (ต้นฉบับ PNG 2546×2458) แทนรูปเดิม
// ตรวจ: ไฟล์ -2x ทุกสีหน้าเป็น 1080×1296 ไฟล์เล็ก 360×432 · หน้าสอนเล่น หน้าแรก และโค้ชในวิซาร์ดโหลดไฟล์ -2x
// · จอ 150% กับขนาด UI 115% (เครื่องของ Non) ไม่ต้องยืดรูปเลย ส่วนไฟล์ 864 px รุ่นก่อนต้องยืด · ขนาดที่วาดบนจอยังเป็นสัดส่วน 5:6 เท่าเดิม
// · บันทึกบทพูดใช้ไฟล์เล็ก · หน้าเว็บไม่อ้างไฟล์ต้นฉบับ PNG (ต้นฉบับไม่ได้ขึ้น GitHub)
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 1000 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  const html = fs.readFileSync(path.resolve(__dirname, '../dist/index.html'), 'utf8');
  const MOODS = ['ask', 'explain', 'guilty', 'mad', 'panic', 'shush', 'smile', 'smirk', 'surprise', 'think'];
  // รอให้รูปโหลดเสร็จ แล้วคืนขนาดไฟล์ ขนาดที่วาด และค่าที่ใช้คำนวณพิกเซลจริงบนจอ
  const probe = (sel) => page.evaluate(async (sel) => {
    const img = document.querySelector(sel); if (!img) return null;
    for (let i = 0; i < 40 && !(img.complete && img.naturalWidth); i++) await new Promise(r => setTimeout(r, 100));
    const r = img.getBoundingClientRect();
    return { src: img.getAttribute('src'), nw: img.naturalWidth, nh: img.naturalHeight, w: r.width, h: r.height, dpr: devicePixelRatio, zoom: uiZoom() };
  }, sel);

  // ================= A) ขนาดไฟล์ทั้ง 20 ไฟล์ =================
  await page.goto(url + '#home'); await page.reload(); await wait(600);
  const dims = await page.evaluate(async (moods) => {
    const load = (src) => new Promise(res => { const i = new Image(); i.onload = () => res([i.naturalWidth, i.naturalHeight]); i.onerror = () => res(null); i.src = src; });
    const out = {}; for (const m of moods) out[m] = { hd: await load('assets/nem-' + m + '-2x.webp'), sm: await load('assets/nem-' + m + '.webp') };
    return out; }, MOODS);
  ok('all ten -2x files are 1080×1296', MOODS.every(m => dims[m].hd && dims[m].hd[0] === 1080 && dims[m].hd[1] === 1296), dims);
  ok('all ten small files are 360×432', MOODS.every(m => dims[m].sm && dims[m].sm[0] === 360 && dims[m].sm[1] === 432), dims);
  ok('the page never points at the PNG originals', !/['"`]assets\/Nemessiah/.test(html) && !/Nemessiah\/nem-[a-z]+\.png['"`]/.test(html));

  // ================= B) หน้าแรก =================
  const home = await probe('.home-nem img');
  ok('home portrait loads the 1080×1296 file', !!home && home.src === 'assets/nem-smile-2x.webp' && home.nh === 1296, home);
  ok('home portrait keeps its CSS height and 5:6 shape', !!home && Math.abs(home.h - 350 * home.zoom) < 1.5 && Math.abs(home.w / home.h - 5 / 6) < 0.01, home);

  // ================= C) หน้าสอนเล่น =================
  await page.evaluate(() => { location.hash = '#create'; }); await wait(800);
  const vn = await probe('.vn-sprite img');
  const dev = vn ? vn.h * vn.dpr : 0;
  ok('tutorial sprite loads a -2x file of 1296 px', !!vn && /^assets\/nem-[a-z]+-2x\.webp$/.test(vn.src) && vn.nh === 1296, vn);
  ok('tutorial sprite at 150% screen and 115% UI needs no upscaling (the 864 px file did)', dev > 864 && dev <= 1296, { dev, vn });
  ok('tutorial sprite keeps the 5:6 shape', !!vn && Math.abs(vn.w / vn.h - 5 / 6) < 0.01, vn);
  const sw = await page.evaluate(async (moods) => { const img = document.querySelector('.vn-sprite img'); const out = {};
    for (const m of moods) { nemSet(img, m); for (let i = 0; i < 40 && !(img.complete && img.naturalWidth); i++) await new Promise(r => setTimeout(r, 50)); out[m] = [img.getAttribute('src'), img.naturalHeight, img.dataset.fb || '']; }
    return out; }, MOODS);
  ok('every mood switches to its own 1296 px file without falling back', MOODS.every(m => sw[m][0] === 'assets/nem-' + m + '-2x.webp' && sw[m][1] === 1296 && sw[m][2] === ''), sw);
  await page.click('.vn button:has-text("อ่านทั้งบท")'); await wait(200);
  const logs = await page.evaluate(() => [...document.querySelectorAll('.vn-logline img')].map(i => i.getAttribute('src')));
  ok('dialogue log thumbnails use the small files', logs.length > 0 && logs.every(s => /^assets\/nem-[a-z]+\.webp$/.test(s)), logs.slice(0, 3));
  await page.screenshot({ path: path.resolve(__dirname, 'v121_tutor.png') });

  // ================= D) โค้ชข้างวิซาร์ด =================
  await page.evaluate(() => { try { localStorage.setItem('kirana.coach', 'on'); } catch (e) {} location.hash = '#wizard'; }); await wait(600);
  await page.click('#v-create button.primary'); await wait(400);
  const coach = await probe('.coach-portrait img');
  ok('coach portrait loads a -2x file', !!coach && /^assets\/nem-[a-z]+-2x\.webp$/.test(coach.src) && coach.nh === 1296, coach);
  ok('coach portrait keeps its 150 px CSS height', !!coach && Math.abs(coach.h - 150 * coach.zoom) < 1.5, coach);
  await page.screenshot({ path: path.resolve(__dirname, 'v121_coach.png') });

  ok('no page errors', errors.length === 0, errors);
  console.log(`v121: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
