// v1.10: คำสั่งทอยอิสระ /r 2d6+3 · /r 3d6 dis · /r 1d20 · kh/kl · dc · /gm r (ลับ) · ช่องคำสั่งในหน้าต่างทอยเต๋า · /help
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  // ---- parser ----
  const parsed = await page.evaluate(() => ['2d6+3', '3d6 dis', '2d6 dis', '3d6', '1d20', '4d6kh3 -1', '2d20kl1 adv', '2d6 dc 10 ปีนกำแพง', '2d6 dc10', '+2', '3', 'd8 ตีกลอง', '2d6 + 3'].map(t => { const p = parseRollCommand(t); return [t, p.n+'d'+p.sides, p.keep ? p.keep.type+p.keep.count : '-', p.mod, p.mode, p.dc, p.label, p.kirana ? 'K' : 'g', p.expr].join(' | '); }));
  console.log('parse:'); for (const l of parsed) console.log('  ' + l);
  // ---- generic roller statistics ----
  const stats = await page.evaluate(() => { const out = {}; let ok = true; for (let i=0;i<300;i++){ const r = rollDiceExpr(parseRollCommand('1d20')); if (r.dice.length!==1 || r.dice[0]<1 || r.dice[0]>20) ok=false; } out.d20Range = ok;
    let okk = true; for (let i=0;i<300;i++){ const r = rollDiceExpr(parseRollCommand('4d6kh3')); const sorted = [...r.dice].sort((a,b)=>b-a); if (r.kept.length!==3 || r.sum !== sorted[0]+sorted[1]+sorted[2] || r.keptIdx.length!==3) okk=false; } out.kh3 = okk;
    let okd = true; for (let i=0;i<300;i++){ const r = rollDiceExpr(parseRollCommand('2d20 dis')); if (r.kept.length!==1 || r.kept[0] !== Math.min(...r.dice)) okd=false; } out.dis2d20 = okd; return out; });
  console.log('roller:', JSON.stringify(stats));
  // ---- local room + chat commands ----
  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert({ id:'rc', name:'นักทอย', kin:'lunaryn', size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' }); });
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องคำสั่ง'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  const say = async (t) => { await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', t); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter'); await page.waitForTimeout(250); await page.evaluate(() => { Table.rolling = false; Table.rollLock = null; updateRollLockUI(); }); };
  await say('/r 3d6 dis'); await say('/r 2d6+3 ฟันดาบ'); await say('/r 1d20'); await say('/r 4d6kh3'); await say('/gm r 2d6 dc 10 ซ่อนตัว'); await say('/dis r 2d6+1'); await say('สวัสดี');
  const chat = await page.evaluate(() => Table.chat.slice().reverse().map(m => m.kind==='roll' ? `${m.text} | dice ${m.roll.dice.length} kept ${m.roll.kept.length} mode ${m.roll.mode} sides ${m.roll.sides||6} mod ${m.mod} total ${m.total} judge "${(m.judge||{}).text||''}" gm ${!!m.gmOnly}` : `${m.kind}: ${m.text}`));
  console.log('chat:'); for (const l of chat) console.log('  ' + l);
  const log = await page.$$eval('#chatlog .e', es => es.map(e => e.textContent.replace(/\s+/g,' ').trim().slice(0,80)));
  console.log('log lines:', log.length, 'd20 tag:', log.some(l => /d20/.test(l)), 'secret tag:', log.some(l => /ลับ/.test(l)));
  // ---- help modal ----
  await say('/help'); console.log('help modal rows:', (await page.$$('.modal table tr')).length); await page.evaluate(() => modal(null));
  // ---- dice window command input (GM: secret checkbox) ----
  await page.click('#twins .rdock .hud-btn'); await page.waitForTimeout(300);
  const cmdSel = '#twins .twin-dice .dicecmd input[placeholder^="คำสั่งทอย"]';
  console.log('cmd input:', !!(await page.$(cmdSel)), 'secret box:', !!(await page.$('#twins .twin-dice .dicecmd input[type=checkbox]')));
  await page.check('#twins .twin-dice .dicecmd input[type=checkbox]');
  await page.fill(cmdSel, '3d6 dis สายตา'); await page.press(cmdSel, 'Enter'); await page.waitForTimeout(300);
  const last = await page.evaluate(() => { const m = Table.chat[0]; return {text: m.text, dice: m.roll.dice.length, mode: m.roll.mode, gm: !!m.gmOnly, badge: (document.querySelector('#twins .rdock .badge')||{}).textContent}; });
  console.log('dice window cmd:', JSON.stringify(last));
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
