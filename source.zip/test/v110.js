// v1.10: คำสั่งทอยอิสระ /r 2d6+3 · /r 3d6 dis · /r 1d20 · kh/kl · dc · /gm r (ลับ) · ช่องคำสั่งในหน้าต่างทอยเต๋า · /help
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  // ---- parser ----
  const parsed = await page.evaluate(() => ['2d6+3', '3d6 dis', '2d6 dis', '3d6', '1d20', '4d6kh3 -1', '2d20kl1 adv', '2d6 dc 10 ปีนกำแพง', '2d6 dc10', '+2', '3', 'd8 ตีกลอง', '2d6 + 3'].map(t => { const p = parseRollCommand(t); return [t, p.n+'d'+p.sides, p.keep ? p.keep.type+p.keep.count : '-', p.mod, p.mode, p.dc, p.label, p.kirana ? 'K' : 'g', p.expr].join(' | '); }));
  console.log('parse:'); for (const l of parsed) console.log('  ' + l);
  // ---- generic roller statistics ----
  const stats = await page.evaluate(() => { const out = {}; let ok = true; for (let i=0;i<300;i++){ const r = rollDiceExpr(parseRollCommand('1d20')); if (r.dice.length!==1 || r.dice[0]<1 || r.dice[0]>20) ok=false; } out.d20Range = ok;
    let okk = true; for (let i=0;i<300;i++){ const r = rollDiceExpr(parseRollCommand('4d6kh3')); const sorted = [...r.dice].sort((a,b)=>b-a); if (r.kept.length!==3 || r.sum !== sorted[0]+sorted[1]+sorted[2] || r.keptIdx.length!==3) okk=false; } out.kh3 = okk;
    let okd = true; for (let i=0;i<300;i++){ const r = rollDiceExpr(parseRollCommand('2d20 dis')); if (r.kept.length!==1 || r.kept[0] !== Math.min(...r.dice)) okd=false; } out.dis2d20 = okd; return out; });
  console.log('roller:', JSON.stringify(stats));
  // ---- local room + chat commands ----
  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert({ id:'rc', name:'นักทอย', kin:'lunaryn', size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' }); });
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องคำสั่ง'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  const say = async (t) => { await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', t); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter'); await page.waitForTimeout(250); await page.evaluate(() => { Table.rolling = false; Table.rollLock = null; updateRollLockUI(); }); };
  await say('/r 3d6 dis'); await say('/r 2d6+3 ฟันดาบ'); await say('/r 1d20'); await say('/r 4d6kh3'); await say('/gm r 2d6 dc 10 ซ่อนตัว'); await say('/dis r 2d6+1'); await say('สวัสดี');
  const chat = await page.evaluate(() => Table.chat.slice().reverse().map(m => m.kind==='roll' ? `${m.text} | dice ${m.roll.dice.length} kept ${m.roll.kept.length} mode ${m.roll.mode} sides ${m.roll.sides||6} mod ${m.mod} total ${m.total} judge "${(m.judge||{}).text||''}" gm ${!!m.gmOnly}` : `${m.kind}: ${m.text}`));
  console.log('chat:'); for (const l of chat) console.log('  ' + l);
  const log = await page.$$eval('#chatlog .e', es => es.map(e => e.textContent.replace(/\s+/g,' ').trim().slice(0,80)));
  console.log('log lines:', log.length, 'd20 tag:', log.some(l => /d20/.test(l)), 'secret tag:', log.some(l => /ลับ/.test(l)));
  // ---- help modal ----
  await say('/help'); console.log('help modal rows:', (await page.$$('.modal table tr')).length); await page.evaluate(() => modal(null));
  // ---- dice window command input (GM: secret checkbox) ----
  await page.click('#twins .rdock .hud-btn'); await page.waitForTimeout(300);
  const cmdSel = '#twins .twin-dice .dicecmd input[placeholder^="คำสั่งทอย"]';
  console.log('cmd input:', !!(await page.$(cmdSel)), 'secret box:', !!(await page.$('#twins .twin-dice .dicecmd input[type=checkbox]')));
  await page.check('#twins .twin-dice .dicecmd input[type=checkbox]');
  await page.fill(cmdSel, '3d6 dis สายตา'); await page.press(cmdSel, 'Enter'); await page.waitForTimeout(300);
  const last = await page.evaluate(() => { const m = Table.chat[0]; return {text: m.text, dice: m.roll.dice.length, mode: m.roll.mode, gm: !!m.gmOnly, badge: (document.querySelector('#twins .rdock .badge')||{}).textContent}; });
  console.log('dice window cmd:', JSON.stringify(last));
  // ---- Parry / Evade หลายลูก (v1.11) ----
  await page.evaluate(() => { modal(null); Table.rolling = false; Table.rollLock = null; updateRollLockUI(); });
  await page.selectOption('#chat-who', 'rc'); await page.waitForTimeout(100);
  const pick2 = async () => { await page.waitForSelector('.pickbox .pickdie', {timeout: 5000}); const dies = await page.$$('.pickbox .pickdie'); await dies[0].click(); await dies[dies.length-1].click(); await page.click('.pickbox button:has-text("ใช้ 2 ลูกนี้")'); await page.waitForTimeout(250); await page.evaluate(() => { Table.rolling = false; Table.rollLock = null; updateRollLockUI(); }); };
  await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', '/r parry 4 dc 9'); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter');
  await page.waitForSelector('.pickbox h3', {timeout: 5000}); console.log('chooser title:', await page.$eval('.pickbox h3', e => e.textContent)); await pick2();
  const m1 = await page.evaluate(() => { const m = Table.chat[0]; return {text: m.text, dice: m.roll.dice.length, kept: m.roll.kept.length, chosen: !!m.roll.chosen, dc: m.dc, judge: (m.judge||{}).text}; });
  console.log('parry 4 dc 9:', JSON.stringify(m1));
  await say('/r parry'); // ตัวละครไม่มีโล่ → 2d6 เปล่า ไม่มีตัวเลือก
  console.log('parry plain:', await page.evaluate(() => { const m = Table.chat[0]; return {text: m.text, dice: m.roll.dice.length, modalOpen: !document.getElementById('modal').classList.contains('hidden')}; }));
  await say('/r evade dc 8');
  console.log('evade:', await page.evaluate(() => { const m = Table.chat[0]; const d = compute(window.__kirana.Store.get('rc')); return {text: m.text, mod: m.mod, reflex: d.reflex, judge: (m.judge||{}).text}; }));
  await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', '/gm r evade adv 3 ขุนพล'); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter'); await pick2();
  console.log('gm evade adv (secret):', await page.evaluate(() => { const m = Table.chat[0]; return {text: m.text, dice: m.roll.dice.length, gm: !!m.gmOnly, chosen: !!m.roll.chosen}; }));
  await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', '/parry 3'); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter'); await pick2();
  console.log('/parry shortcut:', await page.evaluate(() => { const m = Table.chat[0]; return {text: m.text, dice: m.roll.dice.length}; }));
  console.log('log tag:', await page.$$eval('#chatlog .e', es => es.map(e=>e.textContent).filter(t=>/โจมตีมา 9/.test(t)).length));
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
