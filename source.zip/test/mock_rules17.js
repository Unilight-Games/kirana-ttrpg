// ฐานข้อมูลจำลองสำหรับชุดทดสอบ v1.20 ขึ้นไป: เลียน Rules รุ่น v1.7 ของคอลเลกชัน maps (firestore.rules ที่เผยแพร่ 13 พ.ย. 2026)
//   อ่าน      ล็อกอินแล้ว และ (ผู้พัฒนา หรือ published == true หรือเป็นเจ้าของ) · เปิดเอกสารที่ไม่มีอยู่ไม่ได้ (เว้นผู้พัฒนา)
//   คำค้น     ต้องมีเงื่อนไขที่รับประกันสิทธิ์ (published == true หรือ ownerId == ฉัน) เว้นผู้พัฒนา
//   สร้าง     ownerId ต้องเป็นบัญชีของคนเขียน · สมุดรีวิว (type 'reviews') ต้องใช้รหัส rvbook-<uid>[~สุ่ม] และไม่ใช่บัญชีนิรนาม · ชนิดอื่นห้ามใช้รหัสที่ขึ้นต้นด้วย rvbook-
//   แก้       ต้องเป็นเจ้าของ · ownerId กับ type ต้องไม่เปลี่ยน · สมุดรีวิวแก้ได้เฉพาะบัญชีที่ไม่ใช่นิรนาม
//   ลบ        เจ้าของหรือผู้พัฒนา
// คอลเลกชันอื่นไม่จำกัดสิทธิ์ (ชุดทดสอบนี้ไม่ได้ใช้) · onSnapshot คืนฟังก์ชันเลิกฟังจริง
module.exports = `
window.installMockDb = function(){
  const mem = { maps: {}, mapimages: {} }; const subs = []; const log = { queries: [], writes: [], denied: [] };
  const dev = () => !!Store.isDevUid;
  const anon = () => !!(Store.authUser && Store.authUser.isAnonymous);
  const guarded = (col) => col === 'maps' || col === 'mapimages';
  const canRead = (col, d) => dev() || (col === 'maps' && d.published === true) || d.ownerId === Store.me;
  const deny = (what) => { log.denied.push(what); const e = new Error('Missing or insufficient permissions.'); e.code = 'permission-denied'; return e; };
  const match = (d, filters) => filters.every(([f, v]) => d[f] === v);
  const queryAllowed = (col, filters) => !guarded(col) || dev() || filters.some(([f, v]) => (col === 'maps' && f === 'published' && v === true) || (f === 'ownerId' && v === Store.me));
  const snap = (col, filters, lim) => { let list = Object.values(mem[col] || {}).filter(d => match(d, filters)); if (lim) list = list.slice(0, lim); return { docs: list.map(d => ({ id: d.id, data: () => JSON.parse(JSON.stringify(d)) })) }; };
  const fire = (col) => { for (const s of subs.slice()) if (s.col === col && queryAllowed(col, s.filters)) s.cb(snap(col, s.filters, s.lim)); };
  const state = { failQueries: false, failWrites: false };
  const isBook = (d) => (d.type || '') === 'reviews';
  const ownBookId = (id) => new RegExp('^rvbook-' + Store.me + '(~[a-z0-9]{1,12})?$').test(id);
  const mayCreate = (col, id, nd) => { if (!Store.me) return false; if (dev()) return true; if (nd.ownerId !== Store.me) return false; if (col !== 'maps') return true; return isBook(nd) ? (ownBookId(id) && !anon()) : !/^rvbook-/.test(id); };
  const mayUpdate = (col, cur, nd) => { if (!Store.me) return false; if (dev()) return true; if (cur.ownerId !== Store.me) return false; if (col !== 'maps') return true; return nd.ownerId === cur.ownerId && (nd.type || '') === (cur.type || '') && (!isBook(nd) || !anon()); };
  const mkQ = (col, filters, lim) => ({ where(f, op, v){ return mkQ(col, [...filters, [f, v]], lim); }, limit(n){ return mkQ(col, filters, n); }, orderBy(){ return this; },
    async get(){ log.queries.push(col + ':' + filters.map(x => x.join('=')).join('&')); if (state.failQueries) throw new Error('unavailable'); if (!queryAllowed(col, filters)) throw deny('query ' + col); return snap(col, filters, lim); },
    onSnapshot(cb, err){ const s = { col, filters, cb, lim }; if (!queryAllowed(col, filters)){ setTimeout(() => { if (err) err(deny('listen ' + col)); }, 0); return () => {}; } subs.push(s); setTimeout(() => { if (subs.includes(s)) s.cb(snap(col, filters, lim)); }, 0); return () => { const i = subs.indexOf(s); if (i >= 0) subs.splice(i, 1); }; } });
  Store.db = { collection: (col) => { mem[col] = mem[col] || {}; return mkQ(col, [], 0); },
    doc: (p) => { const [col, id] = p.split('/'); mem[col] = mem[col] || {}; return {
      async set(d){ if (state.failWrites) throw new Error('unavailable'); const cur = mem[col][id]; const nd = JSON.parse(JSON.stringify(d));
        if (guarded(col) && !(cur ? mayUpdate(col, cur, nd) : mayCreate(col, id, nd))) throw deny('set ' + p);
        mem[col][id] = nd; log.writes.push('set ' + p); fire(col); },
      async update(d){ if (state.failWrites) throw new Error('unavailable'); const cur = mem[col][id]; if (!cur){ const e = new Error('No document to update'); e.code = 'not-found'; throw e; }
        const nd = Object.assign({}, cur, JSON.parse(JSON.stringify(d)));
        if (guarded(col) && !mayUpdate(col, cur, nd)) throw deny('update ' + p);
        mem[col][id] = nd; log.writes.push('update ' + p); fire(col); },
      async get(){ const d = mem[col][id]; if (guarded(col) && !dev() && (!d || !canRead(col, d))) throw deny('get ' + p); return { exists: !!d, id, data: () => d && JSON.parse(JSON.stringify(d)) }; },
      async delete(){ if (state.failWrites) throw new Error('unavailable'); const cur = mem[col][id]; if (guarded(col) && !dev() && (!cur || cur.ownerId !== Store.me)) throw deny('delete ' + p); delete mem[col][id]; log.writes.push('delete ' + p); fire(col); } }; } };
  Store.backend = 'firebase'; Store.online = true; Store.onlineUsers = []; Store.canWrite = true;
  Store.site = { devUids: ['dev1'], requireLogin: true };
  return { mem, log, subs, state, fire };
};
/* เปลี่ยนบัญชี: ล้างสถานะของคลังและของโมดูลสังคมให้เหมือนเปิดเว็บใหม่ด้วยบัญชีนั้น */
window.asUser = function(uid, name, o){ o = o || {}; Store.me = uid; Store.displayName = name; Store.baseName = name; Store.isDevUid = !!o.dev || (Store.site && (Store.site.devUids || []).includes(uid)); Store.authUser = { uid, isAnonymous: !!o.anon };
  MapLib.unsub = []; MapLib.loaded = false; MapLib.mine = []; MapLib.pub = []; MapLib.sort = 'new'; MapLib.q = ''; NpcLib.unsub = []; NpcLib.loaded = false; NpcLib.mine = []; NpcLib.pub = []; NpcLib.images = {}; NpcLib.sort = 'new'; NpcLib.q = ''; NpcLib.type = 'all';
  ReviewLib.books = []; ReviewLib.byTarget = new Map(); ReviewLib.loaded = false; ReviewLib.failed = false; ReviewLib.at = 0; ReviewLib.p = null;
  ProfileLib.mine = null; ProfileLib.loaded = false; ProfileLib.p = null; ProfileLib.cache = new Map(); try { localStorage.removeItem(ProfileLib.localKey); } catch(e){}
  GChat.stop(); GChat.docs = []; GChat.mineId = null; GChat.lastSend = 0; GChat.loaded = false; GChat.failed = false; GChat.cleaned = false; GChat.cleanP = null;
  if (window.__mock){ __mock.log.queries.length = 0; __mock.log.writes.length = 0; __mock.log.denied.length = 0; __mock.subs.length = 0; }
  Store.ready = true;
  try { updateOnline(); } catch(e){} };
`;
