const { chromium } = require('playwright'); const path=require('path');
(async()=>{ const b=await chromium.launch(); const page=await b.newPage({viewport:{width:1280,height:900}});
page.on('pageerror',e=>console.log('PAGEERROR',e.message)); page.on('console',m=>{ if(m.type()==='error') console.log('CONSOLE',m.text()); });
await page.goto('file://'+path.resolve('dist/index.html')+'#table'); await page.waitForTimeout(300);
await page.fill('input[placeholder^="ชื่อห้อง"]','ทดสอบ'); await page.click('text=สร้างห้อง'); await page.waitForTimeout(500);
console.log(await page.evaluate(()=>location.hash));
console.log((await page.textContent('#v-table')).slice(0,400));
await page.screenshot({path:'test/dbg.png'}); await b.close(); })();
