// v1.13 + v1.14: Fleshforge (Swalan) ต้องเลือกไอเทมที่ผูกหนึ่งชิ้น ถาวรทั้งเกม: วิซาร์ดบังคับเลือก ชีทแสดง HUD ติดป้าย 🧬 ห้องแสดงแท็ก ล็อกเมื่ออยู่ในแคมเปญ
// v1.14: เลือกจากคลังไอเทมของเกม (ค้นหา) หรือเขียนชื่อและเอฟเฟกต์เอง · ห้ามวัตถุดิบ อาหาร วัสดุสร้างไอเทม
// v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026): ห้ามกระสุน ลูกศร อุปกรณ์เวท และของราคาเกิน 30 เกรฟเพิ่ม (ชุดทดสอบละเอียดอยู่ใน test/v115.js)
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  // Swalan VIT 8 + extra 7 = 15 → ได้ Fleshforge เป็น starter skill
  const info = await page.evaluate(() => { const K = window.__kirana; const sw = DATA.kins.find(k=>k.id==='swalan'); const ch = sw.childhood[0].code, ad = sw.adulthood[0].code;
    const c = { id:'ff1', name:'สวาลานทดสอบ', kin:'swalan', size:'Medium', childhood:ch, adulthood:ad, extra:{VIT:7}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:false, step:7, starterSet:'The Vanguard', talent: DATA.talents[0].nameEn||DATA.talents[0].name };
    K.Store.upsert(c); const d = compute(c); return {vit: d.raw.VIT, skills: allSkills(c), hasFF: hasFleshforge(c), extraLeft: d.extraLeft}; });
  console.log('fixture:', JSON.stringify(info));
  // ข้อความสกิลใหม่ในข้อมูล
  console.log('skill text:', await page.evaluate(() => { const s = DATA.skills.find(x=>x.nameEn==='Fleshforge'); return {pick: s.extra[0].slice(0,60), rule: /ต้องไม่ใช่ไอเทมวัตถุดิบ อาหาร วัสดุสร้างไอเทม กระสุน ลูกศร อุปกรณ์เวท หรือของที่มีราคามากกว่า 30 เกรฟ/.test(s.extra[0]), own: /กำหนดชื่อและเอฟเฟคของไอเทมขึ้นเอง/.test(s.extra[0]), eff: /ผูกไว้ตอนสร้างตัวละคร/.test(s.effect), durability: s.extra.some(e=>/Durability/.test(e)) && !s.extra.some(e=>/Dubility/.test(e))}; }));
  // คลังที่ผูกได้: ตัดวัตถุดิบ อาหาร เครื่องดื่ม แร่ธาตุ เสบียงออก · ไอเทมหมวดเอว เท้า ผ้าคลุม (แก้ตัวอ่าน v1.14) อยู่ครบ
  console.log('catalog:', await page.evaluate(() => { const all = itemCatalog(), ok = fleshforgeCatalog(); const cats = new Set(ok.map(i=>i.cat)); const has = (n)=>ok.some(i=>i.name.includes(n));
    return {all: all.length, allowed: ok.length, blockedCats: ['วัตถุดิบอาหาร','วัตถุดิบเล่นแร่แปรธาตุ','เสบียงและเครื่องดื่ม'].filter(c=>cats.has(c)), geode: has('Herculium Geode'), ration: ok.some(i=>/Ration|เสบียง/.test(i.name)), tuber: has('Stone Shell Tuber'), belt: has('Chain Belt'), boots: has('Steel Sabatons'), cloak: has('Batwing Cloak'), junk: all.filter(i=>['Waist (เอว)','Feet (เท้า)','Cape'].includes(i.name)).length, sword: has('Arming Sword'), mask: has('Plague Doctor Mask') || has('หน้ากาก')}; }));
  // วิซาร์ดขั้น 8: มีกล่อง Fleshforge และบล็อกการเสร็จสิ้นจนกว่าจะเลือก
  await page.evaluate(() => { startWizard(window.__kirana.Store.get('ff1')); W.step = 7; }); await page.goto(url + '#wizard'); await page.waitForTimeout(500);
  console.log('picker in wizard:', !!(await page.$('#v-create .ffbox .ffpick')), 'custom btn:', !!(await page.$('#v-create .ffbox .ffcustom')), 'old select gone:', !(await page.$('#v-create .ffbox select')), 'blocker:', await page.evaluate(() => stepBlocker(7)));
  // ค้นจากคลัง: พิมพ์ค้น "หน้ากาก" แล้วผูกชิ้นแรก
  await page.click('#v-create .ffbox .ffpick'); await page.waitForTimeout(300);
  const before = (await page.$$('.ffmodal .fflist .gift')).length;
  await page.fill('.ffmodal .ffsearch', 'หน้ากาก'); await page.waitForTimeout(200);
  const hits = await page.$$eval('.ffmodal .fflist .gift b', es => es.map(e=>e.textContent));
  console.log('catalog modal rows:', before, 'search "หน้ากาก":', hits.length, hits.slice(0,3));
  await page.fill('.ffmodal .ffsearch', 'เสบียง'); await page.waitForTimeout(200);
  console.log('search food (ต้องไม่เจอของกิน):', await page.$$eval('.ffmodal .fflist .gift b', es => es.map(e=>e.textContent)));
  await page.fill('.ffmodal .ffsearch', 'หน้ากาก'); await page.waitForTimeout(200);
  await page.click('.ffmodal .fflist .gift button'); await page.waitForTimeout(400);
  const picked = await page.evaluate(() => ({item: W.char.fleshforge.item, effect: (W.char.fleshforge.effect||'').slice(0,50), custom: W.char.fleshforge.custom, cat: W.char.fleshforge.cat, blocker: stepBlocker(7), modalClosed: document.getElementById('modal').classList.contains('hidden')})); console.log('picked:', JSON.stringify(picked));
  console.log('box shows effect:', await page.$eval('#v-create .ffbox .ffcur', e => e.textContent.replace(/\s+/g,' ').slice(0,90)));
  // เขียนเอง: ชื่อ + เอฟเฟกต์
  await page.click('#v-create .ffbox .ffcustom'); await page.waitForTimeout(300);
  await page.fill('.ffmodal .ffname', 'หน้ากากกระดูกวาฬ'); await page.fill('.ffmodal .ffeffect', 'Armor 1/1 (Blunt) · เห็นในความมืดได้ 4 เมตร'); await page.click('.ffmodal .ffsave'); await page.waitForTimeout(400);
  console.log('custom:', await page.evaluate(() => JSON.stringify(Object.assign({}, W.char.fleshforge, {at: !!W.char.fleshforge.at}))));
  console.log('blocker after custom:', await page.evaluate(() => stepBlocker(7)));
  // เขียนเองด้วยชื่อของวัตถุดิบในคลัง → ถูกปฏิเสธ ค่าเดิมคงอยู่
  const rawName = await page.evaluate(() => itemCatalog().find(i=>i.cat==='วัตถุดิบอาหาร').name);
  await page.click('#v-create .ffbox .ffcustom'); await page.waitForTimeout(300);
  await page.fill('.ffmodal .ffname', rawName); await page.click('.ffmodal .ffsave'); await page.waitForTimeout(300);
  console.log('raw material refused:', rawName, '→ still', await page.evaluate(() => W.char.fleshforge.item), 'toast:', await page.$eval('#toast', e => e.textContent.slice(0,70)));
  await page.evaluate(() => modal(null));
  await page.evaluate(() => { const c = W.char; const d = compute(c); c.current = c.current || {hp:d.hp, mp:d.mp, sanity:d.sanity, tough:Object.fromEntries(DATA.meta.bodyParts.map(([k])=>[k,d.toughness])), ap:3, ip:0, money:15}; c.done = true; window.__kirana.Store.upsert(c); location.hash = '#sheet-ff1'; }); await page.waitForTimeout(600);
  console.log('after finish:', await page.evaluate(() => ({hash: location.hash, done: window.__kirana.Store.get('ff1').done, item: window.__kirana.Store.get('ff1').fleshforge.item})));
  // ชีท: แถว Fleshforge ใน Trait (มีเอฟเฟกต์ของไอเทม) + ไม่มีกล่องเลือกซ้ำ
  await page.waitForTimeout(300);
  console.log('sheet trait line:', await page.$$eval('#v-sheet .box[data-k="trait"] .tag', es => es.map(e=>e.textContent).filter(t=>/Fleshforge/.test(t))), 'effect on sheet:', await page.$$eval('#v-sheet .box[data-k="trait"] .titem', es => es.map(e=>e.textContent).filter(t=>/Fleshforge/.test(t)).map(t=>/หน้ากากกระดูกวาฬ/.test(t) && /Armor 1\/1 \(Blunt\)/.test(t))), 'picker on sheet:', !!(await page.$('#v-sheet .ffbox')));
  // HUD: ติดป้าย 🧬 บนไอเทมที่ชื่อตรง (เปลี่ยนไอเทมผูกเป็นของในกระเป๋าเพื่อทดสอบ)
  await page.evaluate(() => { const c = window.__kirana.Store.get('ff1'); c.fleshforge = {item: c.inventory[0].name, effect:'', custom:false, at: Date.now()}; window.__kirana.Store.upsert(c); renderSheet('ff1'); }); await page.waitForTimeout(300);
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(300);
  console.log('bag badge:', (await page.$$('.hud-win .tile .ffbadge')).length);
  // ล็อกเมื่ออยู่ในแคมเปญ (จำลอง roomIds) → วิซาร์ดโชว์ 🔒 ไม่มีปุ่มเปลี่ยน
  await page.evaluate(() => { const c = window.__kirana.Store.get('ff1'); c.roomIds = ['r1']; window.__kirana.Store.upsert(c); startWizard(c); W.step = 7; }); await page.goto(url + '#wizard'); await page.waitForTimeout(400);
  console.log('locked in campaign:', await page.$$eval('#v-create .ffbox .tag', es => es.map(e=>e.textContent)), 'buttons present:', !!(await page.$('#v-create .ffbox .ffpick')) || !!(await page.$('#v-create .ffbox .ffcustom')));
  // ตัวละครที่ไม่มี Fleshforge ไม่เห็นกล่อง
  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert({ id:'nf', name:'ธรรมดา', kin:'lunaryn', size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:false, step:7, starterSet:'The Vanguard' }); startWizard(K.Store.get('nf')); W.step = 7; }); await page.goto(url + '#wizard'); await page.waitForTimeout(400);
  console.log('no-FF picker:', !!(await page.$('#v-create .ffbox')), 'blocker:', await page.evaluate(() => stepBlocker(7)));
  // ชีทที่ได้ Fleshforge ทีหลังแต่ยังไม่เลือก → มีกล่องเลือกในชีท (ถามยืนยันก่อนผูก) เลือกแล้วกล่องหาย
  await page.evaluate(() => { const c = window.__kirana.Store.get('ff1'); c.roomIds = []; delete c.fleshforge; window.__kirana.Store.upsert(c); }); await page.goto(url + '#sheet-ff1'); await page.waitForTimeout(500);
  console.log('sheet picker when unbound:', !!(await page.$('#v-sheet .ffbox .ffpick')), 'in middle column:', await page.evaluate(() => { const cols = [...document.querySelectorAll('#v-sheet .cs .cscol')]; const b = document.querySelector('#v-sheet .ffbox'); return cols.findIndex(c=>c.contains(b)); }));
  await page.click('#v-sheet .ffbox .ffpick'); await page.waitForTimeout(300);
  await page.fill('.ffmodal .ffsearch', 'โล่'); await page.waitForTimeout(200);
  await page.click('.ffmodal .fflist .gift button'); await page.waitForTimeout(500);
  console.log('bound from sheet:', await page.evaluate(() => { const f = window.__kirana.Store.get('ff1').fleshforge; return {item: f.item, hasEffect: !!f.effect, custom: f.custom}; }), 'picker gone:', !(await page.$('#v-sheet .ffbox')));
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
