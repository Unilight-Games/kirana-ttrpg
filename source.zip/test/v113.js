// v1.13: Fleshforge (Swalan) ต้องเลือกไอเทมที่ผูกหนึ่งชิ้น ชนิดใดก็ได้ ถาวรทั้งเกม: วิซาร์ดบังคับเลือก ชีทแสดง HUD ติดป้าย 🧬 ห้องแสดงแท็ก ล็อกเมื่ออยู่ในแคมเปญ
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  // Swalan VIT 8 + extra 7 = 15 → ได้ Fleshforge เป็น starter skill
  const info = await page.evaluate(() => { const K = window.__kirana; const sw = DATA.kins.find(k=>k.id==='swalan'); const ch = sw.childhood[0].code, ad = sw.adulthood[0].code;
    const c = { id:'ff1', name:'สวาลานทดสอบ', kin:'swalan', size:'Medium', childhood:ch, adulthood:ad, extra:{VIT:7}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:false, step:7, starterSet:'The Vanguard', talent: DATA.talents[0].nameEn||DATA.talents[0].name };
    K.Store.upsert(c); const d = compute(c); return {vit: d.raw.VIT, skills: allSkills(c), hasFF: hasFleshforge(c), cands: fleshforgeCandidates(c).slice(0,6), extraLeft: d.extraLeft}; });
  console.log('fixture:', JSON.stringify(info));
  // ข้อความสกิลใหม่ในข้อมูล
  console.log('skill text:', await page.evaluate(() => { const s = DATA.skills.find(x=>x.nameEn==='Fleshforge'); return {pick: s.extra[0].slice(0,60), eff: /ผูกไว้ตอนสร้างตัวละคร/.test(s.effect), durability: s.extra.some(e=>/Durability/.test(e)) && !s.extra.some(e=>/Dubility/.test(e))}; }));
  // วิซาร์ดขั้น 8: มีกล่อง Fleshforge และบล็อกการเสร็จสิ้นจนกว่าจะเลือก
  await page.evaluate(() => { startWizard(window.__kirana.Store.get('ff1')); W.step = 7; }); await page.goto(url + '#wizard'); await page.waitForTimeout(500);
  console.log('picker in wizard:', !!(await page.$('#v-create .ffbox select')), 'blocker:', await page.evaluate(() => stepBlocker(7)));
  await page.selectOption('#v-create .ffbox select', {index: 1}); await page.waitForTimeout(300);
  const picked = await page.evaluate(() => ({item: W.char.fleshforge.item, blocker: stepBlocker(7)})); console.log('picked:', JSON.stringify(picked));
  // ระบุเอง
  await page.selectOption('#v-create .ffbox select', '__custom'); await page.waitForTimeout(200);
  await page.fill('#v-create .ffbox input', 'หน้ากากกระดูกวาฬ'); await page.waitForTimeout(100);
  console.log('custom:', await page.evaluate(() => JSON.stringify(W.char.fleshforge)));
  console.log('blocker after custom:', await page.evaluate(() => stepBlocker(7)));
  await page.evaluate(() => { const c = W.char; const d = compute(c); c.current = c.current || {hp:d.hp, mp:d.mp, sanity:d.sanity, tough:Object.fromEntries(DATA.meta.bodyParts.map(([k])=>[k,d.toughness])), ap:3, ip:0, money:15}; c.done = true; window.__kirana.Store.upsert(c); location.hash = '#sheet-ff1'; }); await page.waitForTimeout(600);
  console.log('after finish:', await page.evaluate(() => ({hash: location.hash, done: window.__kirana.Store.get('ff1').done, item: window.__kirana.Store.get('ff1').fleshforge.item})));
  // ชีท: แถว Fleshforge ใน Trait + ไม่มีกล่องเลือกซ้ำ
  await page.waitForTimeout(300);
  console.log('sheet trait line:', await page.$$eval('#v-sheet .box[data-k="trait"] .tag', es => es.map(e=>e.textContent).filter(t=>/Fleshforge/.test(t))), 'picker on sheet:', !!(await page.$('#v-sheet .ffbox')));
  // HUD: ติดป้าย 🧬 บนไอเทมที่ชื่อตรง (เปลี่ยนไอเทมผูกเป็นของในกระเป๋าเพื่อทดสอบ)
  await page.evaluate(() => { const c = window.__kirana.Store.get('ff1'); c.fleshforge = {item: c.inventory[0].name, custom:false, at: Date.now()}; window.__kirana.Store.upsert(c); renderSheet('ff1'); }); await page.waitForTimeout(300);
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(300);
  console.log('bag badge:', (await page.$$('.hud-win .tile .ffbadge')).length);
  // ล็อกเมื่ออยู่ในแคมเปญ (จำลอง roomIds) → วิซาร์ดโชว์ 🔒
  await page.evaluate(() => { const c = window.__kirana.Store.get('ff1'); c.roomIds = ['r1']; window.__kirana.Store.upsert(c); startWizard(c); W.step = 7; }); await page.goto(url + '#wizard'); await page.waitForTimeout(400);
  console.log('locked in campaign:', await page.$$eval('#v-create .ffbox .tag', es => es.map(e=>e.textContent)), 'select present:', !!(await page.$('#v-create .ffbox select')));
  // ตัวละครที่ไม่มี Fleshforge ไม่เห็นกล่อง
  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert({ id:'nf', name:'ธรรมดา', kin:'lunaryn', size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:false, step:7, starterSet:'The Vanguard' }); startWizard(K.Store.get('nf')); W.step = 7; }); await page.goto(url + '#wizard'); await page.waitForTimeout(400);
  console.log('no-FF picker:', !!(await page.$('#v-create .ffbox')), 'blocker:', await page.evaluate(() => stepBlocker(7)));
  // ชีทที่ได้ Fleshforge ทีหลังแต่ยังไม่เลือก → มีกล่องเลือกในชีท
  await page.evaluate(() => { const c = window.__kirana.Store.get('ff1'); c.roomIds = []; delete c.fleshforge; window.__kirana.Store.upsert(c); }); await page.goto(url + '#sheet-ff1'); await page.waitForTimeout(500);
  console.log('sheet picker when unbound:', !!(await page.$('#v-sheet .ffbox select')));
  await page.selectOption('#v-sheet .ffbox select', {index: 1}); await page.waitForTimeout(400);
  console.log('bound from sheet:', await page.evaluate(() => window.__kirana.Store.get('ff1').fleshforge.item), 'picker gone:', !(await page.$('#v-sheet .ffbox')));
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
