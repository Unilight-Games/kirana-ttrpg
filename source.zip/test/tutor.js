// v1.0: home, VN tutorial, coach, routing, dev nav
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('console', m => { if (m.type()==='error') errors.push('CONSOLE ' + m.text()); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(600);
  console.log('home: h1', await page.$eval('#v-home h1', e => e.textContent), '| nem img', await page.$eval('.home-nem img', e => e.naturalWidth), '| body', await page.$eval('body', b => b.className));
  await page.screenshot({ path: 'test/40-home.png' });
  console.log('nav dev hidden:', await page.$eval('#nav-dev', e => e.classList.contains('hidden')));
  // tutorial
  await page.goto(url + '#create'); await page.waitForTimeout(500);
  console.log('tutor active:', await page.$eval('#v-tutor', e => e.classList.contains('active')), 'wizard hidden:', !(await page.$eval('#v-create', e => e.classList.contains('active'))), 'nav active:', await page.$eval('#nav a.active', e => e.textContent));
  console.log('vn:', !!(await page.$('.vn')), 'sprite', await page.$eval('.vn-sprite img', e => e.getAttribute('src')), 'typing', !!(await page.$('.vn-text.typing')));
  await page.waitForTimeout(2500); await page.screenshot({ path: 'test/41-tutor-line1.png' });
  const t1 = await page.$eval('.vn-text', e => e.textContent); console.log('line1:', t1.slice(0, 40), '| next shown:', await page.$eval('.vn-next', e => e.classList.contains('show')));
  await page.click('.vn-box'); await page.waitForTimeout(300); await page.click('.vn-box'); // click during typing completes
  await page.waitForTimeout(200);
  console.log('line2:', (await page.$eval('.vn-text', e => e.textContent)).slice(0, 40), 'count', await page.$eval('.vn-count', e => e.textContent), 'saved', await page.evaluate(() => localStorage.getItem('kirana.tutor')));
  await page.keyboard.press('Space'); await page.waitForTimeout(100); await page.keyboard.press('Space'); await page.waitForTimeout(200);
  console.log('after space count', await page.$eval('.vn-count', e => e.textContent), 'mood', await page.$eval('.vn', e => e.className));
  // skip to end of chapter → choices
  await page.click('.vn-tools button:has-text("ข้ามบท")'); await page.waitForTimeout(200);
  console.log('choices:', await page.$$eval('.vn-choices button', b => b.map(x => x.textContent)));
  await page.screenshot({ path: 'test/42-tutor-end.png' });
  // log
  await page.click('.vn-tools button:has-text("อ่านทั้งบท")'); await page.waitForTimeout(150); console.log('log lines', (await page.$$('.vn-logline')).length);
  await page.click('.vn-log button'); await page.waitForTimeout(100);
  // menu → chapter 7 (combat, scene map)
  await page.click('.vn-tools button:has-text("สารบัญ")'); await page.waitForTimeout(200); const items = await page.$$('.vn-menu .toc-i'); console.log('menu items', items.length); await items[6].click(); await page.waitForTimeout(400);
  console.log('ch7 scene:', await page.$eval('.vn', e => e.className), 'title', await page.$eval('.vn-title h2', e => e.textContent));
  await page.waitForTimeout(2200); await page.screenshot({ path: 'test/43-tutor-map.png' });
  // next chapter via choices
  await page.click('.vn-tools button:has-text("ข้ามบท")'); await page.waitForTimeout(150); await page.click('.vn-choices button.primary'); await page.waitForTimeout(300);
  console.log('after next: ', await page.$eval('.vn-title .kicker', e => e.textContent));
  // ลองทำ → wizard
  await page.click('.vn-tools button:has-text("ข้ามบท")'); await page.waitForTimeout(150);
  await page.goto(url + '#wizard'); await page.waitForTimeout(400);
  console.log('wizard view active:', await page.$eval('#v-create', e => e.classList.contains('active')), 'body', await page.$eval('body', b => b.className));
  await page.click('#v-create button.primary'); await page.waitForTimeout(300); // เริ่มสร้างตัวละคร
  console.log('coach present:', !!(await page.$('.coach')), 'text:', (await page.$eval('.coach-bubble', e => e.textContent)).slice(0, 60));
  await page.screenshot({ path: 'test/44-coach-kin0.png' });
  // pick a kin
  await page.evaluate(() => { const k = window.__kirana; }); 
  const cards = await page.$$('#v-create .card.pick'); await cards[4].click(); await page.waitForTimeout(300); // norlan
  console.log('coach after kin:', await page.$eval('.coach', e => e.className), (await page.$eval('.coach-bubble', e => e.textContent)).slice(0, 80));
  await page.screenshot({ path: 'test/45-coach-kin.png' });
  // go to bg step
  await page.click('.navbtns button.primary'); await page.waitForTimeout(300);
  console.log('bg step coach:', (await page.$eval('.coach-bubble', e => e.textContent)).slice(0, 80));
  const bg = await page.$$('#v-create .card.pick'); await bg[0].click(); await page.waitForTimeout(200); const bg2 = await page.$$('#v-create .card.pick'); await bg2[bg2.length-1].click(); await page.waitForTimeout(300);
  console.log('bg both coach:', (await page.$eval('.coach-bubble', e => e.textContent)).slice(0, 160));
  await page.screenshot({ path: 'test/46-coach-bg.png' });
  // hide/show coach
  await page.click('.coach-x'); await page.waitForTimeout(200); console.log('coach off:', await page.$eval('.coach', e => e.classList.contains('off')));
  await page.click('.coach button'); await page.waitForTimeout(200); console.log('coach back:', !(await page.$eval('.coach', e => e.classList.contains('off'))));
  // chars page bg-map
  await page.goto(url + '#chars'); await page.waitForTimeout(300); console.log('chars body:', await page.$eval('body', b => b.className));
  await page.screenshot({ path: 'test/47-chars-bg.png' });
  // dev direct hash → should redirect home (offline allowed? backend != firebase → allowed)
  await page.goto(url + '#dev'); await page.waitForTimeout(300); console.log('dev hash offline →', location = await page.evaluate(() => location.hash));
  // mobile tutor
  await page.setViewportSize({ width: 400, height: 800 }); await page.goto(url + '#create'); await page.waitForTimeout(2500); await page.screenshot({ path: 'test/48-tutor-mobile.png' });
  await page.goto(url + '#home'); await page.waitForTimeout(400); await page.screenshot({ path: 'test/49-home-mobile.png', fullPage: true });
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
