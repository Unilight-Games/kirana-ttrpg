// v1.8: ขนาด UI (CSS zoom + แก้พิกัดลาก/ป๊อปอัป), ชีทกระดาษหม่นลง, สลับโหมดมืด/สว่างของชีทที่ ⚙
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  console.log('zoom:', await page.evaluate(() => ({style: document.body.style.zoom, cur: document.body.currentCSSZoom, ui: typeof uiZoom==='function' ? uiZoom() : null, vw: vw()})));
  await page.evaluate(() => { const K = window.__kirana; const cv = document.createElement('canvas'); cv.width = cv.height = 60; const ctx = cv.getContext('2d'); ctx.fillStyle = '#a63'; ctx.fillRect(0,0,60,60); const thumb = cv.toDataURL();
    const mk = (id, name, kin) => ({ id, name, kin, size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{lore:2}, prof:{}, skills:['Yantra Master'], details:{}, done:true, step:7, portrait: thumb, starterSet:'The Vanguard' });
    K.Store.upsert(mk('s18', 'อัศวินกระดาษ', 'lunaryn')); });
  await page.goto(url + '#sheet-s18'); await page.waitForTimeout(600);
  await page.screenshot({ path: 'test/110-sheet-paper-dim.png' });
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/111-hud-bag-dim.png' });
  await page.click('#ui-settings'); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/112-settings.png' });
  await page.click('.uiset button:has-text("มืด")'); await page.waitForTimeout(300);
  console.log('theme dark:', await page.evaluate(() => ({paper: document.body.classList.contains('paper'), saved: localStorage.getItem('kirana.ui')})));
  await page.click(".modal .box > .row > button:has-text(\"ปิด\")"); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/113-sheet-dark.png' });
  await page.click('#ui-settings'); await page.click('.uiset button:has-text("130%")'); await page.waitForTimeout(200);
  console.log('zoom 130:', await page.evaluate(() => ({style: document.body.style.zoom, ui: uiZoom(), vw: Math.round(vw())})));
  await page.click('.uiset button:has-text("กระดาษ")'); await page.click(".modal .box > .row > button:has-text(\"ปิด\")"); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/114-sheet-130.png' });
  // room at 130%: dock and window positions sane, drag works
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้อง zoom'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(300);
  await page.click('#twins .rdock .hud-btn'); await page.waitForTimeout(300);
  const hb = await page.$('#twins .twin-dice .hud-head b'); const bb = await hb.boundingBox();
  const r1 = await page.$eval('#twins .twin-dice', e => { const r = e.getBoundingClientRect(); return {l: Math.round(r.left), t: Math.round(r.top)}; });
  await page.mouse.move(bb.x+10, bb.y+5); await page.mouse.down(); await page.mouse.move(bb.x+10-400, bb.y+5-100, {steps:8}); await page.mouse.up(); await page.waitForTimeout(200); // v1.15: แผงทอยสูงขึ้น (แถวตัวเลือกโจมตี/ป้องกัน) หน้าต่างเลยเริ่มสูงกว่าเดิม ลากขึ้น 100 พอ ไม่งั้นชนขอบบนที่กันไว้ 4px
  const r2 = await page.$eval('#twins .twin-dice', e => { const r = e.getBoundingClientRect(); return {l: Math.round(r.left), t: Math.round(r.top)}; });
  console.log('dice window dragged by (-400,-100): from', r1, '→', r2, 'expected', {l: r1.l-400, t: r1.t-100}, (Math.abs(r2.l-(r1.l-400))<=2 && Math.abs(r2.t-(r1.t-100))<=2) ? 'OK' : 'OFF');
  await page.screenshot({ path: 'test/115-room-130.png' });
  // term popup position at zoom
  await page.goto(url + '#rules'); await page.waitForTimeout(400);
  const term = await page.$('.term:visible'); if (term){ const tb = await term.boundingBox(); await term.click(); await page.waitForTimeout(200); const pr = await page.$eval('.pop', e => { const r = e.getBoundingClientRect(); return {l: Math.round(r.left), t: Math.round(r.top)}; }); console.log('term at', Math.round(tb.x), Math.round(tb.y+tb.height), 'pop at', pr); }
  await page.screenshot({ path: 'test/116-rules-pop.png' });
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
