// v1.9: ลบตัวละครได้จริงทุกเครื่อง: ปุ่มลบในชีท, ถอนหมากออกจากห้องเมื่อลบ, snapshot จากเซิร์ฟเวอร์ตัดตัวละครที่ถูกลบจากเครื่องอื่น (จำลอง), ถังขยะ, นำเข้า JSON ของคนอื่นได้ id ใหม่
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  await page.evaluate(() => { const K = window.__kirana;
    const mk = (id, name) => ({ id, name, kin:'lunaryn', size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' });
    K.Store.upsert(mk('d1', 'ผู้ถูกลบ')); K.Store.upsert(mk('d2', 'ผู้อยู่ต่อ')); });
  // ---- local room: place d1, then delete from the sheet → token gone, enc order cleaned ----
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องลบ'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.selectOption('#v-table select', 'd1'); await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(300);
  await page.click('button:has-text("เริ่มการต่อสู้")'); await page.waitForTimeout(300);
  const before = await page.evaluate(() => ({tokens: Table.room.tokens.length, order: Table.room.enc.order.length, roomIds: window.__kirana.Store.get('d1').roomIds}));
  await page.goto(url + '#sheet-d1'); await page.waitForTimeout(500);
  console.log('sheet delete button:', !!(await page.$('#v-sheet button:has-text("ลบตัวละคร")')));
  await page.click('#v-sheet button:has-text("ลบตัวละคร")'); await page.waitForTimeout(400);
  const after = await page.evaluate(() => { const rooms = JSON.parse(localStorage.getItem('kirana.rooms.v1')||'[]'); const r = rooms[0]; return {hash: location.hash, hasD1: !!window.__kirana.Store.get('d1'), tokens: r.tokens.length, order: r.enc.order.length, trash: JSON.parse(localStorage.getItem('kirana.chars.trash')||'[]').map(t=>t.char.id)}; });
  console.log('before:', JSON.stringify(before), 'after delete:', JSON.stringify(after));
  // ---- chars page delete button still there for a normal (non-dev) user ----
  await page.goto(url + '#chars'); await page.waitForTimeout(400);
  console.log('chars page delete buttons:', (await page.$$('#v-chars .charcard button:has-text("ลบ")')).length, 'isDev:', await page.evaluate(() => window.__kirana.Store.isDevUid));
  // ---- simulate server snapshots (what happens on another device of the same player) ----
  const sim = await page.evaluate(() => { const S = window.__kirana.Store; S.me = 'uidA'; S.isDevUid = false; const mkc = (id, name, owner) => ({ id, name, ownerId: owner, kin:'lunaryn', done:true, updatedAt: 1 });
    S.chars = [mkc('a1','ของฉัน-ยังอยู่','uidA'), mkc('a2','ของฉัน-ถูกลบที่เครื่องอื่น','uidA'), Object.assign(mkc('a3','ร่างออฟไลน์',null), {ownerId: null})];
    const out = {};
    // snapshot จากแคช (ยังไม่ยืนยันกับเซิร์ฟเวอร์) ต้องไม่ตัดอะไร
    applyCharsSnapshot({docs:[{id:'a1', data:()=>mkc('a1','ของฉัน-ยังอยู่','uidA')}], fromCache:true}); out.afterCache = S.chars.map(c=>c.id);
    // snapshot จากเซิร์ฟเวอร์: a2 หายไป → ตัดออก, a3 ไม่มี ownerId → เก็บไว้
    applyCharsSnapshot({docs:[{id:'a1', data:()=>mkc('a1','ของฉัน-ยังอยู่','uidA')}], fromCache:false}); out.afterServer = S.chars.map(c=>c.id); out.synced = S.chars.map(c=>!!c.synced);
    out.trashHasA2 = JSON.parse(localStorage.getItem('kirana.chars.trash')||'[]').some(t=>t.char.id==='a2');
    // เอกสารใหม่จากเซิร์ฟเวอร์ถูกเพิ่ม และของที่ใหม่กว่าทับของเก่า
    applyCharsSnapshot({docs:[{id:'a1', data:()=>Object.assign(mkc('a1','ของฉัน-เปลี่ยนชื่อ','uidA'),{updatedAt:5})},{id:'a4', data:()=>mkc('a4','ใหม่จากเครื่องอื่น','uidA')}], fromCache:false}); out.afterAdd = S.chars.map(c=>c.id+':'+c.name);
    // ผู้พัฒนา: ตัวละครของคนอื่นที่หายจากเซิร์ฟเวอร์ก็ถูกตัดเช่นกัน
    S.isDevUid = true; S.chars.push(mkc('o1','ของคนอื่น-ถูกเจ้าของลบ','uidB'));
    applyCharsSnapshot({docs:[{id:'a1', data:()=>mkc('a1','ของฉัน-ยังอยู่','uidA')},{id:'a4', data:()=>mkc('a4','ใหม่จากเครื่องอื่น','uidA')}], fromCache:false}); out.devAfter = S.chars.map(c=>c.id);
    S.isDevUid = false; S.me = null; return out; });
  console.log('snapshot sim:', JSON.stringify(sim));
  // ---- import JSON of someone else's character gets a new id; my own export keeps id ----
  const imp = await page.evaluate(() => { const S = window.__kirana.Store; S.me = 'uidA'; S.chars = []; return {me: S.me}; });
  await page.goto(url + '#chars'); await page.waitForTimeout(300);
  await page.click('button:has-text("นำเข้า JSON")'); await page.waitForTimeout(200);
  await page.fill('.modal textarea', JSON.stringify({id:'zz-other', name:'ของเพื่อน', kin:'lunaryn', ownerId:'uidB', done:true, roomIds:['room-x']}));
  await page.click('.modal button:has-text("นำเข้า")'); await page.waitForTimeout(300);
  await page.click('button:has-text("นำเข้า JSON")'); await page.waitForTimeout(200);
  await page.fill('.modal textarea', JSON.stringify({id:'zz-mine', name:'ของฉันที่ส่งออกไว้', kin:'lunaryn', ownerId:'uidA', done:true, roomIds:['room-y']}));
  await page.click('.modal button:has-text("นำเข้า")'); await page.waitForTimeout(300);
  console.log('import:', await page.evaluate(() => window.__kirana.Store.chars.map(c=>({id: c.id==='zz-mine' ? 'kept' : (c.id==='zz-other' ? 'KEPT-BAD' : 'new'), owner: c.ownerId, rooms: (c.roomIds||[]).length}))));
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
