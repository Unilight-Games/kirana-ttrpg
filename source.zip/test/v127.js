// v1.27 (ร่าง ยังไม่ขึ้นเว็บ · Non สั่ง 16 พ.ย. 2026)
//  "แบ่ง NPC ออกเป็นสองประเภทคือสัตว์ (Fauna) และผู้คน (Humanoid) แล้วทำให้ตอนสร้าง NPC สามารถ insert item และพฤติกรรม ใส่ให้ได้ด้วย เหมือนในเอกสาร Fauna, Enemy & Companion"
//  A) ข้อมูลแม่แบบ 47 ตัวจากเอกสาร และตัวช่วยตรวจข้อมูล
//  B) คลังและตัวแก้: ประเภท ขนาด การโจมตี Reaction พฤติกรรม ของดรอป แม่แบบ ตัวกรอง
//  C) บนโต๊ะ: แผงหมาก ทอยของดรอป มอบของ เก็บกลับเข้าคลัง แผนที่ที่เก็บ NPC ไว้ เพดานขนาดห้อง
//  D) จอมือถือ  E) ข้อความบนหน้าจอไม่มีขีดเชื่อมประโยค
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  const shot = (n) => path.resolve(__dirname, n);
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail).slice(0, 1500) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  await page.goto(url); await wait(400);

  // ================= A) ข้อมูลแม่แบบ =================
  const A1 = await page.evaluate(() => { const B = npcBestiary(); const E = B.entries;
    return { n: E.length, fauna: E.filter(e => e.type === 'fauna').length, hum: E.filter(e => e.type === 'humanoid').length, groups: B.groups.map(g => g.key + ':' + g.scaling.length),
      noHp: E.filter(e => !(e.hp > 0) || e.tgh == null || e.ap == null).map(e => e.en), noAtk: E.filter(e => !(e.attacks || []).length).map(e => e.en),
      sizes: [...new Set(E.filter(e => e.type === 'fauna').map(e => e.size))], badT: E.flatMap(e => e.drops).filter(d => !['g', 'c', 'u', 'x', 'e'].includes(d.t)).length,
      warns: E.map(e => [e.en, npcDropWarn(npcDropsClean(e.drops))]).filter(x => x[1]), banditEq: E.filter(e => e.group === 'Bandit').map(e => (e.equip || []).length) }; });
  ok('A: 47 templates, 29 fauna and 18 humanoid in 3 groups', A1.n === 47 && A1.fauna === 29 && A1.hum === 18 && A1.groups.length === 3 && A1.groups.every(g => +g.split(':')[1] >= 3), A1);
  ok('A: every template has HP, Toughness, AP and an attack', A1.noHp.length === 0 && A1.noAtk.length === 0 && A1.sizes.length === 5 && A1.badT === 0, A1);
  ok('A: every ranged drop table covers 1 to 6', A1.warns.length === 0, A1.warns);
  ok('A: bandit equipment is read from the bold equipment heading', A1.banditEq.join(',') === '2,3,2', A1.banditEq);
  const A2 = await page.evaluate(() => { const E = npcBestiary().entries; const by = (en) => E.find(e => e.en === en); const mk = (en) => libClean(JSON.parse(JSON.stringify(npcFromTemplate(by(en)))));
    const wolf = mk('Dire Wolf'), mage = mk('Imperial Battlemage'), knight = mk('Chainmail Knight'), rabbit = mk('Killer Rabbit Swarm'), raider = mk('Raider'), vandel = mk('Vandel'), dunk = mk('Dunkator');
    const all = E.map(e => mk(e.en)); const lost = all.filter((it, i) => it.nkind !== E[i].type || (it.attacks || []).length !== E[i].attacks.length || (it.behaviors || []).length !== E[i].abilities.length || (it.reactions || []).length !== E[i].reactions.length || (it.drops || []).length !== E[i].drops.length).map(it => it.name);
    const brute = mk('Brute Ravager'), cons = mk('Militia Conscript'), slayer = mk('The Creature Slayer');
    return { wolf: { k: wolf.nkind, size: wolf.size, der: wolf.der, aa: npcAllArmor(wolf), tgh: wolf.tgh, tough: npcTough(wolf), init: wolf.init, d: npcDerived(wolf.mods), tpl: wolf.tpl, note: /แนวคิด|ที่มา/.test(wolf.note) },
      brute: { tough: npcTough(brute), eq: (brute.equip || []).map(e => e.slot + ':' + itemNameSplit(e.name)[0] + ':' + !!e.effect), atk: brute.attacks[0].name, extra: brute.extra || '' }, cons: (cons.equip || []).map(e => itemNameSplit(e.name)[0] + ':' + e.slot), slayer: { init: slayer.init, per: slayer.mods.PER }, mage: { mp: mage.mp, eq: (mage.equip || []).map(e => e.slot + ':' + !!e.effect), def: mage.defend },
      knight: { aa: knight.armorAll, all: npcAllArmor(knight), armor: npcArmor(knight.equip).torso, eq: (knight.equip || []).map(e => e.slot), groupNote: /ปรับระดับความท้าทาย \(Imperial\)/.test(knight.note) }, rabbit: { extra: rabbit.extra, der: rabbit.der, tgh: rabbit.tgh, tough: npcTough(rabbit), qty: rabbit.drops[0].qty },
      raider: { eq: (raider.equip || []).map(e => e.name + '|' + e.slot), e: raider.drops.filter(d => d.t === 'e').map(d => d.r + ' ' + d.name + ' ' + d.note) }, nv: vandel.nv, aq: dunk.aquatic, lost }; });
  ok('A: template keeps kind, size and source; derived stats follow the PC rule', A2.wolf.k === 'fauna' && A2.wolf.size === 'Large' && A2.wolf.der === undefined && A2.wolf.d.might === 2 && A2.wolf.init === 2 && A2.wolf.aa === 1 && A2.wolf.tpl === 'fauna:Dire Wolf' && A2.wolf.note, A2.wolf);
  ok('A: Toughness keeps a base and adds the size bonus', A2.wolf.tgh === 3 && A2.wolf.tough === 4 && A2.rabbit.tgh === 4 && A2.rabbit.tough === 3 && A2.brute.tough === 5 && !/Toughness/.test(A2.brute.extra), { w: A2.wolf, r: A2.rabbit, b: A2.brute });
  ok('A: brute uses the battle axe and hide armour, conscript wears rough-woven clothes', A2.brute.atk === 'ขวานศึก (Battle Axe)' && A2.brute.eq.join('|') === 'weapon:ขวานศึก:true|chestIn:เกราะหนังฟอก:true' && A2.cons.includes('เสื้อทูนิคผ้าทอหยาบ:shirt') && A2.cons.includes('กางเกงผ้าทอหยาบ:legs') && A2.slayer.init === 3 && A2.slayer.per === 3, { b: A2.brute, c: A2.cons, s: A2.slayer });
  ok('A: caster MP and humanoid equipment match the item catalog', A2.mage.mp === 14 && A2.mage.eq.length === 2 && A2.mage.eq.every(x => /true$/.test(x)) && A2.mage.def === 'parry', A2.mage);
  ok('A: worn armour replaces the doc All Armor, scaling and swarm notes carry over', A2.knight.aa === undefined && A2.knight.all === 0 && /2\/2/.test(A2.knight.armor) && A2.knight.eq.length === 3 && A2.knight.groupNote && /ฝูงเต็ม 3 ตัว/.test(A2.rabbit.extra) && A2.rabbit.der === undefined && A2.rabbit.qty === 'X', { k: A2.knight, r: A2.rabbit });
  ok('A: raider equipment ranges come out of the name', A2.raider.eq.length === 2 && A2.raider.e.join('|') === '1-3 กระบองไม้ (Wood Club) |4-6 เกราะหนังสัตว์ (Leather Armor) (1d3 Durability)', A2.raider);
  ok('A: dark vision and water creatures are detected from the doc', A2.nv === true && A2.aq === true, A2);
  ok('A: every template survives the database round trip', A2.lost.length === 0, A2.lost);
  const A3 = await page.evaluate(() => { const o = npcStatClean({ nkind: 'robot', size: 'Gigantic', speed: 'x'.repeat(500), ap: 99, armorAll: -20, extra: 5, der: { might: 99 }, attacks: [...Array(20)].map((_, i) => ({ name: 'a' + i, text: 'y'.repeat(900) })).concat([{ name: '', text: '' }, null]),
      defend: 'dodge', reactions: 'nope', behaviors: [{ name: ' x ', text: ' t ' }, { name: '', text: '' }], drops: [{ t: 'z', r: '1-3', name: 'ของ', qty: '1d3', note: 'n' }, { t: 'c', r: 'abc', name: 'ของสอง' }, { t: 'c', r: '1-3', name: '   ' }], tpl: 7 }, {});
    return { o, keys: Object.keys(o).sort().join(','), atk: o.attacks.length, atkLen: o.attacks[0].text.length }; });
  ok('A: untrusted stat fields are typed and capped', !A3.o.nkind && !A3.o.size && A3.o.speed.length === 160 && A3.o.ap === 9 && A3.o.armorAll === -5 && A3.o.extra === '5' && A3.o.der === undefined && A3.atk === 12 && A3.atkLen === 600
    && !A3.o.defend && !A3.o.reactions && A3.o.behaviors.length === 1 && A3.o.behaviors[0].name === 'x' && A3.o.drops.length === 2 && A3.o.drops[0].t === 'g' && A3.o.drops[0].r === '' && A3.o.drops[1].r === '' && A3.o.tpl === '7', A3);
  const A4 = await page.evaluate(() => { const real = Math.random; const seq = [0.99]; Math.random = () => seq[0];
    const drops = [{ t: 'g', name: 'เงิน', qty: '1d6' }, { t: 'c', r: '1-3', name: 'ผ้า', qty: '1' }, { t: 'c', r: '4-6', name: 'ขวด', qty: '2' }, { t: 'u', r: '6', name: 'เชือก', qty: '' }, { t: 'u', r: '5-6', name: 'ยา', qty: 'X' }, { t: 'x', r: '10', name: 'ตา', qty: '1' }, { t: 'e', r: '1-3', name: 'กระบอง' }, { t: 'e', r: '4-6', name: 'เกราะ' }];
    const hi = npcRollDrops(drops); seq[0] = 0; const lo = npcRollDrops(drops); Math.random = real;
    return { hi: hi.items.map(x => x.name + ':' + x.q.txt), hiRolls: hi.rolls.map(r => r.t + r.v), lo: lo.items.map(x => x.name + ':' + x.q.txt), qty: [npcRollQty('').n, npcRollQty('X').n, npcRollQty('15').n, npcRollQty('abc').txt] }; });
  ok('A: drop roll picks rows by range, one roll per tier', A4.hi.join('|') === 'เงิน:6 (1d6: 6)|ขวด:2|เชือก:1|ยา:X|ตา:1|เกราะ:1' && A4.hiRolls.join(',') === 'c6,u6,x10,e6' && A4.lo.join('|') === 'เงิน:1 (1d6: 1)|ผ้า:1|กระบอง:1', A4);
  ok('A: quantity text handles dice, X and plain numbers', A4.qty[0] === 1 && A4.qty[1] === null && A4.qty[2] === 15 && A4.qty[3] === 'abc', A4.qty);
  const A5 = await page.evaluate(() => { const L = npcBehaviorList(); const keys = L.map(b => b.kind + b.name + b.text); const tags = npcDerivedTags({ STR: 4 }).map(t => [t.textContent, t.title]); const r1 = npcInitRule({ init: 2 }), r2 = npcInitRule({ init: 3, mods: { PER: 1 } }), r3 = libClean({ id: 'x', type: 'npc', name: 'เก่า', hp: 9, init: 2 });
    return { n: L.length, dup: keys.length - new Set(keys).size, pack: L.filter(b => /Pack Tactics/.test(b.name)).length, re: L.filter(b => b.kind === 'reaction').length, tags, d: npcDerived({ STR: 4, AGI: 3 }, { reflex: 9 }), r1, r2, r3: { init: r3.init, mods: r3.mods } }; });
  ok('A: behaviour list flattens the doc without duplicates', A5.n > 100 && A5.dup === 0 && A5.pack >= 1 && A5.re >= 30, A5);
  ok('A: derived stats have no own values', A5.tags[0][0] === 'Might +3' && !A5.tags[0][1] && A5.tags[3][0] === 'Reflex +1' && A5.d.reflex === 2 && A5.d.might === 3, A5);
  ok('A: Initiative follows PER Mod and old items move their Initiative into PER Mod', A5.r1.init === 2 && A5.r1.mods.PER === 2 && A5.r2.init === 1 && A5.r3.init === 2 && A5.r3.mods.PER === 2, A5);

  // ================= B) คลังและตัวแก้ =================
  await page.goto(url + '#npcs'); await wait(400);
  const B1 = await page.evaluate(() => ({ btn: [...document.querySelectorAll('#v-npcs .stephead button')].map(b => b.textContent), chips: [...document.querySelectorAll('#v-npcs .typef')].map(b => b.dataset.type) }));
  ok('B: library offers people, animals, assets and templates', B1.btn.join('|') === '+ สร้าง NPC ผู้คน|+ สร้าง NPC สัตว์|+ สร้าง Asset|📖 จากแม่แบบในเอกสาร (47)' && B1.chips.join(',') === 'all,humanoid,fauna,asset', B1);
  await page.click('.newfauna'); await wait(500);
  const B2 = await page.evaluate(() => { const id = location.hash.slice(9); const it = NpcLib.get(id);
    return { id, k: it.nkind, name: it.name, on: (document.querySelector('.npckindbtn.on') || {}).dataset, fold: !!document.querySelector('details.npceqfold'), foldOpen: (document.querySelector('details.npceqfold') || {}).open, eqcard: !!document.querySelector('.npceqcard'), fromeq: !!document.querySelector('.npcdrop-fromeq'),
      cards: [...document.querySelectorAll('.npcstatcard h3')].map(x => x.textContent), block: !!document.querySelector('.npcblock') }; });
  ok('B: new animal opens with the animal kind and folded equipment', B2.k === 'fauna' && B2.name === 'สัตว์ใหม่' && B2.on && B2.on.kind === 'fauna' && B2.fold && !B2.foldOpen && !B2.eqcard && !B2.fromeq, B2);
  ok('B: editor shows the stat block cards in doc order', B2.cards.join('|') === 'การโจมตี|การป้องกันและ Reaction|พฤติกรรมและความสามารถพิเศษ|ไอเทมที่ดรอป' && B2.block, B2.cards);
  const fid = B2.id;
  await page.fill('input[data-f="name"]', 'หมาป่าหิมะ');
  await page.selectOption('select[data-f="size"]', 'Large'); await page.fill('input[data-f="speed"]', 'เดิน 2 ม./วินาที, วิ่ง 12 ม./วินาที');
  await page.fill('input[data-f="ap"]', '2'); await page.fill('input[data-f="mp"]', '0'); await page.fill('input[data-f="armorAll"]', '1'); await page.fill('input[data-f="tgh"]', '3'); await page.fill('input[data-f="mod-PER"]', '2'); await wait(100);
  const B3 = await page.evaluate((id) => ({ hint: document.querySelector('.npcaa-hint').textContent, tg: document.querySelector('.npctg-hint').textContent, init: document.querySelector('.npcinit').textContent, itInit: NpcLib.get(id).init, block: document.querySelector('.npcblock').textContent, tags: [...document.querySelectorAll('.card .tag')].map(t => t.textContent) }), fid);
  ok('B: size adds its armour on top of All Armor', /รวมจากขนาด \+1 = \+2/.test(B3.hint) && B3.tags.includes('All Armor +2') && B3.tags.includes('ขนาดใหญ่ (Large)') && B3.tags.includes('AP 2'), B3);
  ok('B: size adds Toughness on top of the base, Initiative follows PER Mod', /รวมจากขนาด \+1 = 4/.test(B3.tg) && B3.tags.includes('Toughness 4') && /Toughness 4 \(3 \+ 1 จากขนาด\)/.test(B3.block) && B3.init === '+2' && B3.itInit === 2 && /Initiative \+2/.test(B3.block), B3);
  // พฤติกรรมจากเอกสาร
  await page.click('.npcbehv .npcnl-pick'); await wait(300);
  const B4a = await page.evaluate(() => ({ title: document.querySelector('.npcbehpick h3').textContent, on: [...document.querySelectorAll('.npcbehpick button.on')].map(b => b.textContent), rows: document.querySelectorAll('.npcbehpick .npcbeh').length }));
  await page.fill('.npcbehpick input[type=search]', 'Pack Tactics'); await wait(150);
  const packRows = await page.evaluate(() => document.querySelectorAll('.npcbehpick .npcbeh').length);
  await page.click('.npcbehpick .npcbeh >> nth=0 >> button'); await wait(100);
  await page.fill('.npcbehpick input[type=search]', 'หวาดกลัวแสงไฟ'); await wait(150);
  await page.click('.npcbehpick .npcbeh >> nth=0 >> button'); await wait(100);
  const B4b = await page.evaluate(() => document.querySelector('.npcbehpick .npcbeh-added').textContent);
  await page.screenshot({ path: shot('272-npc-behavior-picker-v127.png') });
  await page.evaluate(() => modal(null)); await wait(150);
  const B4 = await page.evaluate((id) => ({ beh: (NpcLib.get(id).behaviors || []).map(b => b.name), rows: document.querySelectorAll('.npcbehv .npcnl-row').length, save: document.querySelector('.libsave').textContent }), fid);
  ok('B: behaviour picker opens on animal abilities', /ใส่พฤติกรรมจากเอกสาร/.test(B4a.title) && B4a.on.some(x => /ความสามารถพิเศษ/.test(x)) && B4a.on.includes('สัตว์') && B4a.rows > 20, B4a);
  ok('B: picking stays open and inserts each behaviour', packRows >= 1 && /เลือกต่อได้เลย/.test(B4b) && B4.beh.length === 2 && /Pack Tactics/.test(B4.beh[0]) && /Fear of Fire/.test(B4.beh[1]) && B4.rows === 2 && /•/.test(B4.save), B4);
  await page.click('.npcbehv .npcnl-row >> nth=1 >> button[title="เลื่อนขึ้น"]'); await wait(100);
  await page.click('.npcbehv .npcnl-add'); await wait(100);
  await page.fill('.npcbehv .npcnl-row >> nth=2 >> .npcnl-name', 'ล่าเป็นคู่'); await page.fill('.npcbehv .npcnl-row >> nth=2 >> .npcnl-text', 'ได้ Advantage เมื่อมีหมาป่าตัวอื่นอยู่ติดเป้าหมาย');
  const B5 = await page.evaluate((id) => (NpcLib.get(id).behaviors || []).map(b => b.name), fid);
  ok('B: behaviours reorder and accept own text', B5.length === 3 && /Fear of Fire/.test(B5[0]) && /Pack Tactics/.test(B5[1]) && B5[2] === 'ล่าเป็นคู่', B5);
  // Reaction และการโจมตี
  await page.selectOption('select[data-f="defend"]', 'parry');
  await page.click('.npcreact .npcnl-pick'); await wait(250);
  const B6a = await page.evaluate(() => [...document.querySelectorAll('.npcbehpick button.on')].map(b => b.textContent));
  await page.click('.npcbehpick .npcbeh >> nth=0 >> button'); await wait(100);
  await page.evaluate(() => modal(null)); await wait(100);
  await page.click('.npcatk .npcnl-add'); await wait(100);
  await page.fill('.npcatk .npcnl-name', 'กัด (Bite)'); await page.fill('.npcatk .npcnl-text', 'CV Bonus +2, Damage 1d6 + Might Piercing'); await wait(100);
  const B6 = await page.evaluate((id) => { const it = NpcLib.get(id); return { re: (it.reactions || []).length, def: it.defend, atk: it.attacks, block: document.querySelector('.npcblock').textContent }; }, fid);
  ok('B: reaction picker starts on reactions, attacks are typed in', B6a.some(x => /Reaction/.test(x)) && B6.re === 1 && B6.def === 'parry' && B6.atk.length === 1 && B6.atk[0].name === 'กัด (Bite)', { B6a, B6 });
  ok('B: the stat block preview follows the edits', /กัด \(Bite\) CV Bonus \+2/.test(B6.block) && /ป้องกัน: Parry/.test(B6.block) && /All Armor \+2 \(รวมขนาด\)/.test(B6.block) && /ความเร็ว: เดิน 2/.test(B6.block), B6.block);
  // ของดรอป
  await page.click('.npcdrop-pick'); await wait(250);
  await page.fill('.npcdroppick input[type=search]', 'เนื้อ'); await wait(150);
  const meat = await page.evaluate(() => document.querySelector('.npcdroppick .gift b').textContent);
  await page.click('.npcdroppick .gift >> nth=0 >> button'); await wait(100);
  await page.evaluate(() => modal(null)); await wait(150);
  await page.selectOption('.npcdrop-row >> nth=0 >> select', 'c'); await wait(100);
  const B7a = await page.evaluate(() => ({ r: document.querySelector('.npcdrop-row .npcdrop-r').value, warn: (document.querySelector('.npcdrop-warn') || {}).textContent }));
  await page.click('.npcdrop-add'); await wait(100);
  await page.selectOption('.npcdrop-row[data-t="g"] select', 'c'); await wait(100);
  await page.fill('.npcdrop-row >> nth=1 >> .npcdrop-r', '4-6'); await page.fill('.npcdrop-row >> nth=1 >> .npcdrop-name', 'หนังหมาป่า (Wolf Pelt)'); await page.fill('.npcdrop-row >> nth=1 >> .npcdrop-qty', '1d2'); await page.fill('.npcdrop-row >> nth=1 >> .npcdrop-note', 'ผืน');
  await page.click('.npcdrop-add'); await wait(100);
  await page.selectOption('.npcdrop-row[data-t="g"] select', 'x'); await wait(100);
  await page.click('.npcbehv .npcnl-del >> nth=2'); await wait(50);
  await page.evaluate(() => { const d = document.querySelector('.npcdrop'); d.refresh(); }); await wait(100);
  const B7 = await page.evaluate((id) => ({ drops: NpcLib.get(id).drops, warn: (document.querySelector('.npcdrop-warn') || {}).textContent || '', heads: [...document.querySelectorAll('.npcdrop-head b')].map(b => b.textContent) }), fid);
  ok('B: catalog drop starts guaranteed, tier change gives a default range and a warning', meat && B7a.r === '1-3' && /ยังไม่มีแถวของแต้ม 4 5 6/.test(B7a.warn), B7a);
  ok('B: drop rows group by tier and the warning clears when 1 to 6 is covered', B7.drops.length === 3 && B7.drops[1].r === '4-6' && B7.drops[2].t === 'x' && B7.drops[2].r === '10' && B7.warn === '' && B7.heads.join('|') === 'ของดรอปทั่วไป|ของดรอปหายากมาก', B7);
  await page.screenshot({ path: shot('273-npc-editor-fauna-v127.png'), fullPage: true });
  await page.click('.libsave'); await wait(300);
  const B8 = await page.evaluate((id) => { const raw = (JSON.parse(localStorage.getItem('kirana.npcs.v1') || '[]').find(x => x.id === id)) || {}; const back = libClean(raw); return { beh: (back.behaviors || []).map(b => b.name), atk: (back.attacks || []).length, drops: (back.drops || []).length, k: back.nkind, size: back.size, aa: back.armorAll, ap: back.ap, mp: back.mp, def: back.defend, re: (back.reactions || []).length }; }, fid);
  ok('B: saving keeps everything through the library clean step', B8.beh.length === 2 && B8.atk === 1 && B8.drops === 3 && B8.k === 'fauna' && B8.size === 'Large' && B8.aa === 1 && B8.ap === 2 && B8.mp === undefined && B8.def === 'parry' && B8.re === 1, B8);
  // เปลี่ยนเป็นผู้คน: การ์ดอาวุธกางออก และปุ่มทำแถวยุทโธปกรณ์ขึ้น
  await page.click('.npckindbtn[data-kind="humanoid"]'); await wait(150);
  const B9 = await page.evaluate((id) => ({ k: NpcLib.get(id).nkind, eqcard: !!document.querySelector('.npceqcard .npceq-add'), fold: !!document.querySelector('details.npceqfold'), fromeq: !!document.querySelector('.npcdrop-fromeq') }), fid);
  ok('B: switching to people unfolds equipment and offers equipment drops', B9.k === 'humanoid' && B9.eqcard && !B9.fold && B9.fromeq, B9);
  await page.click('.npckindbtn[data-kind="fauna"]'); await wait(100); await page.click('.libsave'); await wait(200);
  // แม่แบบ: สัตว์ และผู้คน
  await page.goto(url + '#npcs'); await wait(300);
  await page.click('.newtpl'); await wait(300);
  const B10a = await page.evaluate(() => ({ fauna: document.querySelectorAll('.npctplpick .npctpl').length, heads: [...document.querySelectorAll('.npctplpick .kicker')].map(k => k.textContent) }));
  await page.screenshot({ path: shot('271-npc-template-picker-v127.png') });
  await page.click('.npctplpick button[data-kind="humanoid"]'); await wait(150);
  const B10b = await page.evaluate(() => ({ hum: document.querySelectorAll('.npctplpick .npctpl').length, heads: [...document.querySelectorAll('.npctplpick .kicker')].map(k => k.textContent.split(' ·')[0]) }));
  await page.fill('.npctplpick input[type=search]', 'Battlemage'); await wait(150);
  const B10c = await page.evaluate(() => [...document.querySelectorAll('.npctplpick .npctpl')].map(x => x.dataset.en));
  ok('B: template picker splits animals by size and people by group', B10a.fauna === 29 && B10a.heads.length === 5 && B10b.hum === 18 && B10b.heads.join('|') === 'Imperial|Bandit|Freelance (Ranger)' && B10c.join() === 'Imperial Battlemage', { B10a, B10b, B10c });
  await page.click('.npctplpick .npctpl-use'); await wait(600);
  const B11 = await page.evaluate(() => { const it = NpcLib.get(location.hash.slice(9)); return { id: it.id, name: it.name, k: it.nkind, mp: it.mp, eq: (it.equip || []).length, eqRows: document.querySelectorAll('.npceqcard .npceq-row').length, w: [...document.querySelectorAll('.npceqcard .npceq-w')].map(x => x.textContent),
    beh: document.querySelectorAll('.npcbehv .npcnl-row').length, re: document.querySelectorAll('.npcreact .npcnl-row').length, drop: document.querySelectorAll('.npcdrop-row').length, eRows: document.querySelectorAll('.npcdrop-row[data-t="e"]').length, mpIn: document.querySelector('input[data-f="mp"]').value,
    noDer: !document.querySelector('details.npcder'), init: document.querySelector('.npcinit').textContent, sightTag: [...document.querySelectorAll('.npcderived .tag')].map(t => t.textContent).find(x => /^Sight/.test(x)), note: it.note }; });
  ok('B: humanoid template fills equipment, MP and the four drop tiers', B11.name === 'นักรบเวทจักรวรรดิ' && B11.k === 'humanoid' && B11.mp === 14 && B11.mpIn === '14' && B11.eq === 2 && B11.eqRows === 2 && B11.beh === 2 && B11.re === 1 && B11.drop === 7 && B11.eRows >= 1, B11);
  ok('B: template derived stats and Initiative come from the mods', B11.noDer && B11.init === '+1' && B11.sightTag === 'Sight +1' && /แนวคิด:/.test(B11.note) && /Imperial/.test(B11.note), B11);
  await page.screenshot({ path: shot('274-npc-editor-humanoid-v127.png'), fullPage: true });
  const mageId = B11.id;
  await page.click('.npcdrop-fromeq'); await wait(150);
  const B12 = await page.evaluate((id) => (NpcLib.get(id).drops || []).filter(d => d.t === 'e').map(d => d.r + ' ' + d.name.split(' (')[0]), mageId);
  ok('B: equipment drop rows rebuild from what the NPC wears', B12.length === 2 && B12[0].startsWith('1-3 ') && B12[1].startsWith('4-6 '), B12);
  await page.click('.libsave'); await wait(200);
  // ตัวกรองและค้นหาในคลัง · รายการเก่าที่ไม่มีประเภทนับเป็นผู้คน
  await page.evaluate(async () => { const old = NpcLib.newItem('npc'); delete old.nkind; old.name = 'พ่อค้าเร่รุ่นเก่า'; await NpcLib.save(old); const a = NpcLib.newItem('asset'); a.name = 'หีบไม้'; await NpcLib.save(a); });
  await page.goto(url + '#npcs'); await wait(300);
  const cards = async () => page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.dataset.kind + ':' + c.querySelector('h3').textContent));
  await page.click('.typef[data-type="fauna"]'); await wait(150); const fF = await cards();
  await page.click('.typef[data-type="humanoid"]'); await wait(150); const fH = await cards();
  await page.click('.typef[data-type="asset"]'); await wait(150); const fA = await cards();
  await page.click('.typef[data-type="all"]'); await wait(150);
  await page.fill('#v-npcs .tabs input', 'Pack Tactics'); await wait(150); const fQ = await cards();
  await page.fill('#v-npcs .tabs input', 'สัตว์'); await wait(150); const fQ2 = await cards();
  await page.fill('#v-npcs .tabs input', ''); await wait(150);
  const oldTag = await page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard')].filter(c => /พ่อค้าเร่รุ่นเก่า/.test(c.textContent)).map(c => c.querySelector('.npckindtag').textContent)[0]);
  ok('B: kind filters split people, animals and assets', fF.length === 1 && fF[0] === 'fauna:หมาป่าหิมะ' && fH.length === 2 && fH.every(x => x.startsWith('humanoid:')) && fA.length === 1 && fA[0] === 'asset:หีบไม้', { fF, fH, fA });
  ok('B: search matches behaviour names and kind words; old items count as people', fQ.length === 1 && fQ[0] === 'fauna:หมาป่าหิมะ' && fQ2.length === 1 && oldTag === '🧑 NPC ผู้คน', { fQ, fQ2, oldTag });
  await page.screenshot({ path: shot('270-npc-library-v127.png') });
  await page.click(`#v-npcs .npccard[data-id="${fid}"] button:has-text("ดู")`); await wait(200);
  const B13 = await page.evaluate(() => ({ block: !!document.querySelector('#modal .npcblock'), txt: (document.querySelector('#modal .npcblock') || {}).textContent || '' }));
  ok('B: preview window shows the stat block', B13.block && /พฤติกรรมและความสามารถพิเศษ/.test(B13.txt) && /ของที่อาจได้รับ/.test(B13.txt), B13.txt.slice(0, 300));
  await page.evaluate(() => modal(null));

  // ================= C) บนโต๊ะ =================
  await page.goto(url + '#table'); await wait(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องทดสอบ v1.27'); await page.click('button:has-text("สร้างห้อง")'); await wait(500);
  const tid = await page.evaluate(async (id) => { const r = Table.room; r.map.cells = '.'.repeat(400); await placeFromLibrary(r, NpcLib.get(id), 1, false); const t = r.tokens[r.tokens.length - 1]; Table.sel = t.id; renderTable(); return t.id; }, mageId);
  await wait(300);
  const C1 = await page.evaluate((tid) => { const t = Table.room.tokens.find(x => x.id === tid); const sec = document.querySelector('.npcstat-tok');
    return { k: t.nkind, mp: t.mp + '/' + t.mpMax, atk: (t.attacks || []).length, beh: (t.behaviors || []).length, drops: (t.drops || []).length, der: t.der, init: t.init, sec: !!sec, mpVital: [...document.querySelectorAll('.vital')].some(v => /^MP/.test(v.textContent) && /14 \/ 14/.test(v.textContent)),
      kindSel: sec && sec.querySelector('.npckindsel').value, head: document.querySelector('.twin-tok .mini .npckindtag').textContent, derTag: [...document.querySelectorAll('.npcderived .tag')].map(x => x.textContent), roll: !!document.querySelector('.npcdroproll-btn') }; }, tid);
  ok('C: token carries the stat block and MP from the library', C1.k === 'humanoid' && C1.mp === '14/14' && C1.atk >= 1 && C1.beh === 2 && C1.drops === 7 && C1.der === undefined && C1.init === 1, C1);
  ok('C: GM panel shows kind, MP, behaviours and the drop roll', C1.sec && C1.mpVital && C1.kindSel === 'humanoid' && C1.head === '🧑 NPC ผู้คน' && C1.derTag.includes('Sight +1') && C1.roll, C1);
  await page.click('.npcstat-addbeh'); await wait(250);
  const C2a = await page.evaluate(() => [...document.querySelectorAll('.npcbehpick button.on')].map(b => b.textContent));
  await page.fill('.npcbehpick input[type=search]', 'ระเบียบวินัย'); await wait(150);
  const disc = await page.evaluate(() => document.querySelectorAll('.npcbehpick .npcbeh').length);
  await page.click('.npcbehpick .npcbeh >> nth=0 >> button'); await wait(200);
  await page.evaluate(() => modal(null)); await wait(150);
  const C2 = await page.evaluate((tid) => ({ beh: (Table.room.tokens.find(x => x.id === tid).behaviors || []).length, open: (document.querySelector('.npcstat-beh') || {}).open, lines: document.querySelectorAll('.npcstat-beh .npcstat-line').length }), tid);
  ok('C: GM adds a behaviour to one token and the list stays open', C2a.includes('ผู้คน') && disc >= 1 && C2.beh === 3 && C2.open && C2.lines === 3, { C2a, disc, C2 });
  await page.selectOption('.npckindsel', 'fauna'); await wait(200);
  const C3 = await page.evaluate((tid) => ({ k: Table.room.tokens.find(x => x.id === tid).nkind, head: document.querySelector('.twin-tok .mini .npckindtag').textContent }), tid);
  ok('C: kind switch on the table updates the token', C3.k === 'fauna' && C3.head === '🐾 NPC สัตว์', C3);
  await page.selectOption('.npckindsel', 'humanoid'); await wait(150);
  // + NPC แบบเร็ว: ช่อง Initiative คือ PER Mod · แก้ค่าพลังดัดแปลงของหมากแล้ว Initiative ตาม
  await page.fill('input[placeholder="ชื่อ NPC/ศัตรู"]', 'โจรเร็ว'); await page.fill('label:has-text("Initiative (PER Mod)") input', '2'); await page.click('button:has-text("+ NPC (ซ่อนไว้ก่อน)")'); await wait(250);
  const C3b = await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'โจรเร็ว'); const r = { init: t.init, per: (t.mods || {}).PER }; Table.sel = t.id; renderTable(); return r; }); await wait(150);
  await page.click('.npcmodedit'); await wait(150);
  await page.fill('#modal input[data-st="PER"]', '3'); await page.click('#modal button.primary'); await wait(200);
  const C3c = await page.evaluate(() => { const t = Table.room.tokens.find(x => x.name === 'โจรเร็ว'); return { init: t.init, per: t.mods.PER }; });
  ok('C: quick NPC Initiative is its PER Mod, and editing mods moves Initiative', C3b.init === 2 && C3b.per === 2 && C3c.init === 3 && C3c.per === 3, { C3b, C3c });
  await page.evaluate((tid) => { Table.sel = tid; renderTable(); }, tid); await wait(150);
  // ทอยของดรอปแล้วมอบให้ตัวละคร
  await page.evaluate(() => { const r = Table.room; Store.upsert(Object.assign(newChar(), { id: 'cdrop', name: 'ผู้กล้า', kin: 'solrin', size: 'Medium', done: true, step: 7, starterSet: 'The Sailor' })); r.tokens.push({ id: 'pc1', name: 'ผู้กล้า', kind: 'pc', charId: 'cdrop', x: 5, y: 15, hp: 5, hpMax: 5, san: 0, sanMax: 0, init: 0, conds: [] }); Table.save(); window.__rnd = Math.random; Math.random = () => 0.99; });
  await page.click('.npcdroproll-btn'); await wait(300);
  const C4 = await page.evaluate((tid) => { const t = Table.room.tokens.find(x => x.id === tid); const exp = npcRollDrops(t.drops); return { rows: [...document.querySelectorAll('.npcdropmodal .gift b')].map(b => b.textContent), exp: exp.items.map(x => x.name), sum: document.querySelector('.npcdropmodal p').textContent,
    chat: (Table.chat || []).filter(m => /ของดรอปจาก/.test(m.text || '')).map(m => [m.text, m.gmOnly]), looted: !!t.looted, to: [...document.querySelectorAll('.npcdropmodal select option')].map(o => o.textContent) }; }, tid);
  ok('C: drop roll lists what the table gives, logged for the GM only', C4.rows.length === C4.exp.length && C4.rows.join('|') === C4.exp.join('|') && /1d6 = 6/.test(C4.sum) && C4.chat.length === 1 && C4.chat[0][1] === true && C4.looted && C4.to.includes('ผู้กล้า'), C4);
  await page.screenshot({ path: shot('276-npc-drop-roll-v127.png') });
  const money0 = await page.evaluate(() => { const c = Store.get('cdrop'); return c.current ? +c.current.money || 0 : null; });
  const moneyRow = await page.evaluate(() => [...document.querySelectorAll('.npcdropmodal .gift')].findIndex(g => /เข้าช่องเกรฟ/.test(g.textContent)));
  const itemRow = await page.evaluate(() => [...document.querySelectorAll('.npcdropmodal .gift')].findIndex(g => !/เข้าช่องเกรฟ/.test(g.textContent)));
  const giveQty = await page.evaluate((i) => +document.querySelectorAll('.npcdropmodal .gift')[i].querySelector('input').value, moneyRow);
  await page.click(`.npcdropmodal .gift >> nth=${moneyRow} >> button.primary`); await wait(250);
  const itemName = await page.evaluate((i) => document.querySelectorAll('.npcdropmodal .gift')[i].querySelector('b').textContent, itemRow);
  await page.click(`.npcdropmodal .gift >> nth=${itemRow} >> button.primary`); await wait(250);
  const C5 = await page.evaluate(() => { const c = Store.get('cdrop'); return { btn: [...document.querySelectorAll('.npcdropmodal .gift button.primary')].map(b => b.textContent), chat: (Table.chat || []).filter(m => /GM มอบ/.test(m.text || '')).map(m => m.text), money: +c.current.money, bag: (c.inventory || []).map(x => x.name), coinsInBag: (c.inventory || []).some(x => /Coins|เกรฟ/.test(x.name)) }; });
  ok('C: coins go to the sheet money field, items go to the bag', moneyRow >= 0 && itemRow >= 0 && C5.money === (money0 == null ? 15 : money0) + giveQty && !C5.coinsInBag && C5.bag.includes(itemName) && C5.btn.filter(x => x === 'มอบแล้ว').length === 2, { money0, giveQty, itemName, C5 });
  ok('C: giving posts to the table', C5.chat.length === 2 && C5.chat.some(x => new RegExp('GM มอบเงิน ' + giveQty + ' เกรฟ ให้ ผู้กล้า').test(x)), C5.chat);
  await page.evaluate(() => { Math.random = window.__rnd; modal(null); }); await wait(150);
  const C6 = await page.evaluate(() => document.querySelector('.npcdroproll-btn').textContent);
  ok('C: the roll button remembers the token was looted', C6 === '🎲 ทอยของดรอปอีกครั้ง', C6);
  await page.screenshot({ path: shot('275-npc-token-panel-v127.png') });
  // เก็บหมากกลับเข้าคลัง
  await page.evaluate(async (tid) => { const t = Table.room.tokens.find(x => x.id === tid); t.mpMax = 20; t.mp = 3; await saveTokenToLibrary(t); }, tid); await wait(200);
  const C7 = await page.evaluate((id) => { const it = NpcLib.get(id); return { beh: (it.behaviors || []).length, mp: it.mp, k: it.nkind, tpl: it.tpl }; }, mageId);
  ok('C: saving the token back keeps behaviours, kind and MP', C7.beh === 3 && C7.mp === 20 && C7.k === 'humanoid' && C7.tpl === 'humanoid:Imperial Battlemage', C7);
  // แผนที่ที่เก็บ NPC: ดึงสแตตบล็อกจากคลังของ GM
  const C8 = await page.evaluate(async (id) => { const r = Table.room; const before = r.tokens.length;
    const m = { id: 'mtest', kind: 'field', cells: '.'.repeat(400), light: 'low', name: 'แผนที่ทดสอบ', npcs: [{ id: 'n1', name: 'นักรบเวทในแผนที่', hp: 13, init: 0, x: 3, y: 3, nv: false, aquatic: false, hidden: true, libId: id }, { id: 'n2', name: 'ศัตรูไม่มีคลัง', hp: 9, init: 0, x: 4, y: 3, hidden: true }] };
    await applyLibraryMap(r, m, true); const added = r.tokens.slice(-2); return { n: r.tokens.length - before, a: { atk: (added[0].attacks || []).length, beh: (added[0].behaviors || []).length, eq: (added[0].equip || []).length, mp: added[0].mpMax, mods: !!added[0].mods }, b: { atk: added[1].attacks, k: added[1].nkind } }; }, mageId);
  ok('C: map NPCs pick up mods, equipment and stat block from the GM library', C8.n === 2 && C8.a.atk >= 1 && C8.a.beh === 3 && C8.a.eq === 2 && C8.a.mp === 20 && C8.a.mods && C8.b.atk === undefined && C8.b.k === undefined, C8);
  // เพดานขนาดเอกสารห้อง
  const C9 = await page.evaluate(async (id) => { const r = Table.room; const n0 = r.tokens.length; const realBytes = roomBytes(r); const lm = Table.localMode, sv = Table.save, rb = window.roomBytes;
    Table.localMode = false; Table.save = () => {}; window.roomBytes = () => 2e6; let got; try { got = await placeFromLibrary(r, NpcLib.get(id), 3, true); } finally { Table.localMode = lm; Table.save = sv; window.roomBytes = rb; }
    return { got, same: r.tokens.length === n0, realBytes }; }, mageId);
  ok('C: placing refuses when the room would pass the database size limit', C9.got === 0 && C9.same && C9.realBytes > 1000 && C9.realBytes < 900000, C9);
  const C10 = await page.evaluate(() => { const r = Table.room; Table.sel = 'pc1'; renderTable(); const pc = !!document.querySelector('.npcstat-tok'); const as = { id: 'as1', name: 'หีบ', kind: 'asset', icon: '📦', x: 9, y: 9, hp: 0, hpMax: 0, san: 0, sanMax: 0, init: 0 }; r.tokens.push(as); Table.sel = 'as1'; renderTable(); const asset = !!document.querySelector('.npcstat-tok'); return { pc, asset }; });
  ok('C: players and assets do not get the NPC stat panel', !C10.pc && !C10.asset, C10);

  // ================= D) จอมือถือ =================
  const m = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true });
  m.on('pageerror', e => errors.push('MOBILE ' + e.message)); m.on('dialog', d => d.accept());
  await m.goto(url + '#npcs'); await m.waitForTimeout(300);
  await m.evaluate(async () => { const e = npcBestiary().entries.find(x => x.en === 'Bushwhacker'); const it = npcFromTemplate(e); await NpcLib.save(it); location.hash = '#npcedit-' + it.id; }); await m.waitForTimeout(500);
  const D1 = await m.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, wide: [...document.querySelectorAll('#v-npcs *')].filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.right > document.documentElement.clientWidth + 2; }).map(e => e.className).slice(0, 5) }));
  ok('D: mobile editor has no horizontal overflow', D1.sw <= D1.cw + 1 && D1.wide.length === 0, D1);
  await m.screenshot({ path: shot('277-npc-editor-mobile-v127.png'), fullPage: false });
  await m.goto(url + '#npcs'); await m.waitForTimeout(300); await m.click('.newtpl'); await m.waitForTimeout(300);
  const D2 = await m.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, modalW: document.querySelector('#modal > *') ? document.querySelector('#modal > *').getBoundingClientRect().right : 0 }));
  ok('D: mobile template picker fits the screen', D2.sw <= D2.cw + 1 && D2.modalW <= D2.cw + 1, D2);
  await m.close();

  // ================= E) ข้อความบนหน้าจอ =================
  const src = fs.readFileSync(path.resolve(__dirname, '../src/bestiary.js'), 'utf8');
  const strs = [...src.matchAll(/'([^'\\\n]*[฀-๿][^'\\\n]*)'|`([^`\\\n]*[฀-๿][^`\\\n]*)`/g)].map(x => x[1] || x[2]);
  const dash = strs.filter(s => /\s[—–-]\s|—|–|--/.test(s));
  const anti = strs.filter(s => /ไม่ใช่.*แต่|ไม่ได้.*แต่|เหมือน.*แต่จริง/.test(s));
  ok('E: Thai UI strings use no dash joints or not-X-but-Y frames', strs.length > 80 && dash.length === 0 && anti.length === 0, { n: strs.length, dash, anti });

  ok('no page errors', errors.length === 0, errors);
  console.log(`v1.27: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
