const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(300);
  await page.evaluate(() => { const K = window.__kirana; for (const [id, set] of [['cv', 'The Convict'], ['vg', 'The Vanguard'], ['cf', 'The Craftsman']]) K.Store.upsert({ id, name: set, kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {}, skills: [], talentPicks: {}, details: {}, starterSet: set, done: true, createdAt: Date.now(), updatedAt: Date.now(), step: 8 }); });
  for (const id of ['cv', 'vg', 'cf']) { await page.goto(url + '#sheet-' + id); await page.waitForTimeout(300); console.log(id, 'armor:', JSON.stringify(await page.evaluate(i => window.__kirana.Store.get(i).armor, id))); }
  console.log('hudhint removed:', (await page.$$('.hudhint')).length === 0);
  // unequip helm → head armor cleared
  await page.goto(url + '#sheet-vg'); await page.waitForTimeout(300);
  await page.evaluate(() => { const c = window.__kirana.Store.get('vg'); unequip(c, 'head'); window.__kirana.Store.upsert(c); });
  console.log('after unequip helm head armor:', await page.evaluate(() => window.__kirana.Store.get('vg').armor.head), '(expect empty)');
  // free layout
  await page.goto(url + '#sheet-vg'); await page.waitForTimeout(300);
  await page.click('button:has-text("จัดวางกรอบเอง")'); await page.waitForTimeout(400);
  console.log('free mode:', !!(await page.$('.cs.free')), 'boxes:', (await page.$$('.cs.free .box[data-k]')).length, 'grips:', (await page.$$('.box-grip')).length);
  const box = await page.$('.box[data-k="status"]'); const before = await box.boundingBox();
  const grip = await box.$('.box-grip'); const gb = await grip.boundingBox();
  await page.mouse.move(gb.x + 40, gb.y + gb.height / 2); await page.mouse.down(); await page.mouse.move(gb.x - 500, gb.y + 300, { steps: 10 }); await page.mouse.up(); await page.waitForTimeout(200);
  const after = await (await page.$('.box[data-k="status"]')).boundingBox();
  console.log('status box moved:', Math.round(before.x), Math.round(before.y), '→', Math.round(after.x), Math.round(after.y));
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('kirana.sheetLayout')));
  console.log('saved layout keys:', Object.keys(saved.boxes).length, 'status:', JSON.stringify(saved.boxes.status));
  await page.goto(url + '#sheet-cv'); await page.waitForTimeout(400);
  const after2 = await (await page.$('.box[data-k="status"]')).boundingBox();
  console.log('persists on other sheet:', Math.round(after2.x) === Math.round(after.x) && Math.round(after2.y) === Math.round(after.y));
  await page.screenshot({ path: 'test/50-layout.png', fullPage: false });
  await page.click('button:has-text("กลับเป็นแบบตาราง")'); await page.waitForTimeout(300);
  console.log('back to grid:', !(await page.$('.cs.free')));
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
