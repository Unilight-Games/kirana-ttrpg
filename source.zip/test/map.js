// Grid map: generators, placement, movement, brush, thumbs (local room)
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  const gen = await page.evaluate(() => { const out = {}; for (const [k] of MAP_KINDS){ const m = generateMap(k, 'seed1'); let pass = 0; for (let y=0;y<20;y++) for (let x=0;x<20;x++) if (cellPassable(m,x,y)) pass++; out[k] = { len: m.cells.length, pass, bad: [...m.cells].filter(ch=>!TILE[ch]).length }; } return out; });
  const bad = Object.entries(gen).filter(([k,v]) => v.len !== 400 || v.pass < 60 || v.bad);
  console.log('generators:', Object.keys(gen).length, 'bad:', JSON.stringify(bad));
  console.log('passable per kind:', Object.entries(gen).map(([k,v]) => k + ':' + v.pass).join(' '));
  // portrait char
  await page.evaluate(() => { const K = window.__kirana; const cv = document.createElement('canvas'); cv.width = cv.height = 120; const ctx = cv.getContext('2d'); ctx.fillStyle = '#c0392b'; ctx.fillRect(0,0,120,120); ctx.fillStyle = '#fff'; ctx.font = '60px sans-serif'; ctx.fillText('K', 35, 85);
    const c = { id: 'mapc', name: 'นักรบแผนที่', kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {}, skills: [], talentPicks: {}, details: {}, starterSet: 'The Vanguard', done: true, portrait: cv.toDataURL('image/jpeg', .8), createdAt: Date.now(), updatedAt: Date.now(), step: 8 }; K.Store.upsert(c); });
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องแผนที่'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  console.log('cells:', (await page.$$('.gridmap .cell')).length, 'kind select:', !!(await page.$('.mapctl select')));
  await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(500);
  const tok = await page.evaluate(() => { const t = Table.room.tokens[0]; return { x: t.x, y: t.y, thumb: !!t.thumb && t.thumb.length, roomIds: window.__kirana.Store.get('mapc').roomIds }; });
  console.log('token placed:', JSON.stringify(tok), 'img on grid:', (await page.$$('.gtok img')).length);
  // select token (click) → range rings + sight · move by drag and drop
  await page.click('.gtok'); await page.waitForTimeout(200);
  console.log('selected:', (await page.$$('.gtok.sel')).length, 'eng cells:', (await page.$$('.cell.rng-eng')).length, 'nosight cells:', (await page.$$('.cell.nosight')).length);
  const target = await page.evaluate(() => { const r = Table.room; const t = r.tokens[0]; for (let y=0;y<20;y++) for (let x=0;x<20;x++) if (cellStandable(r.map,x,y) && !r.tokens.some(o=>o.x===x&&o.y===y) && Math.max(Math.abs(x-t.x),Math.abs(y-t.y))>2) return {x,y}; return null; });
  const tb = await (await page.$('.gtok')).boundingBox(); const cb = await (await page.$(`.cell[data-x="${target.x}"][data-y="${target.y}"]`)).boundingBox();
  await page.mouse.move(tb.x+tb.width/2, tb.y+tb.height/2); await page.mouse.down(); await page.mouse.move(tb.x+tb.width/2+20, tb.y+tb.height/2+20, {steps:4}); await page.mouse.move(cb.x+cb.width/2, cb.y+cb.height/2, {steps:8});
  console.log('drop highlight while dragging:', (await page.$$('.cell.drop')).length, 'ghost:', (await page.$$('.gtok.ghost')).length);
  await page.mouse.up(); await page.waitForTimeout(250);
  const tx = target.x, ty = target.y;
  console.log('dragged to', tx, ty, '→', await page.evaluate(() => { const t = Table.room.tokens[0]; return t.x + ',' + t.y; }), 'chat:', await page.evaluate(() => Table.chat[0].text));
  // blocked cell
  const blocked = await page.evaluate(() => { const m = Table.room.map; for (let y=0;y<20;y++) for (let x=0;x<20;x++) if (!cellPassable(m,x,y)) return {x,y}; return null; });
  if (blocked) { const tb2 = await (await page.$('.gtok')).boundingBox(); const bb = await (await page.$(`.cell[data-x="${blocked.x}"][data-y="${blocked.y}"]`)).boundingBox(); await page.mouse.move(tb2.x+tb2.width/2, tb2.y+tb2.height/2); await page.mouse.down(); await page.mouse.move(tb2.x+40, tb2.y+40, {steps:3}); await page.mouse.move(bb.x+bb.width/2, bb.y+bb.height/2, {steps:6}); await page.mouse.up(); await page.waitForTimeout(150); console.log('blocked toast:', await page.$eval('#toast', e => e.textContent)); }
  // NPC + regenerate + brush
  await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(200);
  const sel = await page.$('.mapctl select'); await sel.selectOption('dungeon'); await page.click('button:has-text("สุ่มแผนที่ใหม่")'); await page.waitForTimeout(300);
  console.log('kind now:', await page.evaluate(() => Table.room.map.kind), 'tokens on passable:', await page.evaluate(() => Table.room.tokens.every(t => cellPassable(Table.room.map, t.x, t.y))));
  const brush = (await page.$$('.mapctl select'))[1]; await brush.selectOption('L'); await page.waitForTimeout(150);
  await page.click('.cell[data-x="0"][data-y="0"]'); await page.waitForTimeout(150);
  console.log('painted:', await page.evaluate(() => mapCell(Table.room.map, 0, 0)));
  await (await page.$$('.mapctl select'))[1].selectOption(''); await page.waitForTimeout(150);
  await page.click('button:has-text("เริ่มการต่อสู้")'); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/40-map.png', fullPage: false });
  // sheet from token (own) keeps room open
  await page.click('#v-table button:has-text("📜 ชีท")'); await page.waitForTimeout(400);
  console.log('sheet opened:', location = await page.evaluate(() => location.hash), 'room still open:', await page.evaluate(() => !!Table.roomId));
  // all kinds screenshot grid
  await page.goto(url + '#room-' + await page.evaluate(() => Table.roomId)); await page.waitForTimeout(300);
  for (const k of ['forest','river','city','cave','ship','cliff','island','temple']) { await page.evaluate(k => { Table.room.map = generateMap(k, 'shot'); renderTable(); }, k); await page.waitForTimeout(100); const g = await page.$('.gridmap'); await g.screenshot({ path: `test/41-map-${k}.png` }); }
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
