// Offline test: auto-equip + inventory layout, dice overlay + roll lock (local room mode)
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE ' + m.text()); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  // make a finished character with The Convict set
  const id = await page.evaluate(() => {
    const K = window.__kirana; const c = { id: 'tconv', name: 'ทดสอบนักโทษ', kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {}, skills: [], talentPicks: {}, details: {}, starterSet: 'The Convict', done: true, createdAt: Date.now(), updatedAt: Date.now(), step: 8 };
    K.Store.upsert(c); return c.id; });
  await page.goto(url + '#sheet-' + id); await page.waitForTimeout(500);
  const equip = await page.evaluate(() => { const c = window.__kirana.Store.get('tconv'); return { equip: Object.fromEntries(Object.entries(c.equip).map(([k,e])=>[k, e.name+' ('+e.weight+')'])), bag: c.inventory.map(r=>r.name+' x'+r.qty), parry: c.current.parryBonus, cap: window.__kirana.compute(c).capacity }; });
  console.log('EQUIP', JSON.stringify(equip, null, 1));
  console.log('drawer closed → no invitem:', (await page.$$('.invitem')).length === 0, 'tabs:', await page.$$eval('.drawertab', b => b.map(x => x.textContent)), 'weight:', await page.$eval('.drawerbar .weight', e => e.textContent));
  await page.click('.drawertab:has-text("กระเป๋า")'); await page.waitForTimeout(200);
  const ta = await page.$$eval('.invitem textarea', els => els.map(e => ({ h: e.offsetHeight, sh: e.scrollHeight, clipped: e.scrollHeight > e.offsetHeight + 2 })));
  console.log('bag open: items', ta.length, 'clipped:', ta.filter(x => x.clipped).length);
  await page.screenshot({ path: 'test/20-sheet-inv.png', fullPage: true });
  await page.click('.drawertab:has-text("ของสวมใส่")'); await page.waitForTimeout(200);
  console.log('equip slots filled:', (await page.$$('.eqslot.filled')).length);
  // unequip weapon1 → back to bag
  await page.click('.eqslot.filled button:has-text("ถอด")'); await page.waitForTimeout(200);
  console.log('after unequip:', await page.evaluate(() => { const c = window.__kirana.Store.get('tconv'); return { w1: c.equip.weapon1, bagN: c.inventory.length }; }));
  await page.screenshot({ path: 'test/23-equip.png', fullPage: true });
  // glossary trimmed: identity grid has no .term
  console.log('terms in idgrid:', await page.$$eval('.idgrid .term', e => e.length), 'terms in sheet total:', await page.$$eval('#v-sheet .term', e => e.length));
  // Parry with parry dice → dice chooser (give a shield)
  await page.evaluate(() => { const c = window.__kirana.Store.get('tconv'); c.current.parryBonus = 1; window.__kirana.Store.upsert(c); });
  await page.goto(url + '#sheet-tconv'); await page.waitForTimeout(300);
  await page.click('#v-sheet .rollbtn:has-text("Parry")'); await page.waitForTimeout(300);
  const pick = await page.$$('.pickdie'); console.log('parry chooser dice:', pick.length, '(expect 3)');
  await pick[0].click(); await pick[2].click(); await page.click('.pickbox button.primary'); await page.waitForTimeout(200);
  console.log('parry entry:', await page.$eval('#v-sheet .log .e', e => e.textContent.slice(0, 120)));
  // Evade adv → chooser; Parry dis → plain 2d6
  await page.click('#v-sheet .dicepanel button:has-text("Advantage")'); await page.click('#v-sheet .rollbtn:has-text("Evade")'); await page.waitForTimeout(200);
  console.log('evade adv chooser:', (await page.$$('.pickdie')).length, '(expect 3)'); const pk = await page.$$('.pickdie'); await pk[1].click(); await pk[2].click(); await page.click('.pickbox button.primary'); await page.waitForTimeout(150);
  await page.click('#v-sheet .dicepanel button:has-text("Disadvantage")'); await page.click('#v-sheet .rollbtn:has-text("Parry")'); await page.waitForTimeout(200);
  console.log('parry dis chooser (expect 0):', (await page.$$('.pickdie')).length, '| entry:', await page.$eval('#v-sheet .log .e', e => e.textContent.slice(0, 110)));
  console.log('ST buttons:', await page.$$eval('#v-sheet .rollbtn', b => b.map(x => x.textContent).filter(t => /ST|Fortitude|Will/.test(t))));
  // IP shop
  await page.evaluate(() => { const c = window.__kirana.Store.get('tconv'); c.current.ip = 9; window.__kirana.Store.upsert(c); });
  await page.goto(url + '#sheet-tconv'); await page.waitForTimeout(300);
  await page.click('button:has-text("ใช้ IP")'); await page.waitForTimeout(300);
  console.log('ip cards:', (await page.$$('.ipcard')).length, await page.$$eval('.ipcard', cs => cs.map(c => c.querySelector('.ribbon').textContent + ':' + c.querySelector('h4').textContent + ' ' + c.querySelector('.cost').textContent)));
  await page.screenshot({ path: 'test/24-ipshop.png' });
  await page.click('.ipcard.stat button.primary'); await page.waitForTimeout(300);
  console.log('after stat buy:', await page.evaluate(() => { const c = window.__kirana.Store.get('tconv'); return { ip: c.current.ip, ipStats: c.ipStats, log: c.ipLog.length }; }));
  await page.click('button:has-text("ดูตัวเลือกทั้งหมด")'); await page.waitForTimeout(200);
  console.log('all cards:', (await page.$$('.ipcard')).length);
  await page.click('.ipcard.knowledge button.primary:not([disabled])'); await page.waitForTimeout(300);
  const profCards = await page.$$('.ipcard.knowledge button.primary'); console.log('prof choice cards:', profCards.length);
  if (profCards.length) { await profCards[0].click(); await page.waitForTimeout(300); }
  console.log('after knowledge buy:', await page.evaluate(() => { const c = window.__kirana.Store.get('tconv'); return { ip: c.current.ip, kslots: Object.values(c.kslots), kl: window.__kirana.knowledgeLevels(c) }; }));
  await page.keyboard.press('Escape'); await page.evaluate(() => modal(null));
  // Gunslinger / Vanguard check
  const eq2 = await page.evaluate(() => { const K = window.__kirana; const out = {}; for (const set of ['The Vanguard', 'The Reaver', 'The Mage', 'The Merchant']) { const c = { id: 'x' + set.replace(/\W/g,'').toLowerCase(), name: set, kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, knowledge: {}, prof: {}, grants: [], skills: [], talentPicks: {}, details: {}, starterSet: set, done: true }; K.Store.upsert(c); } return 1; });
  for (const set of ['The Vanguard', 'The Reaver', 'The Mage', 'The Merchant']) { const sid = 'x' + set.replace(/\W/g,'').toLowerCase(); await page.goto(url + '#sheet-' + sid); await page.waitForTimeout(250); console.log(set, JSON.stringify(await page.evaluate(s => window.__kirana.Store.get(s).equip, sid))); }
  // local room: roll → overlay + lock
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องเต๋า');
  await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.selectOption('#chat-who', 'tconv'); await page.waitForTimeout(200);
  console.log('dice panel in room:', !!(await page.$('.dicepanel')), 'rollbtns', (await page.$$('#v-table .rollbtn')).length);
  await page.click('#v-table .rollbtn:text-is("2d6")'); await page.waitForTimeout(300);
  console.log('overlay visible:', await page.$eval('#dice-overlay', e => !e.classList.contains('hidden')), 'locked:', await page.evaluate(() => document.body.classList.contains('roll-locked')));
  // try to roll again while locked
  const before = await page.evaluate(() => window.__kirana.Store && document.querySelectorAll('#chatlog .e').length);
  await page.evaluate(() => { const b = [...document.querySelectorAll('#v-table .rollbtn')].find(x => x.textContent.includes('Luck')); b.click(); });
  await page.waitForTimeout(300);
  const after = await page.evaluate(() => document.querySelectorAll('#chatlog .e').length);
  console.log('chat entries before/after second click while locked:', before, after, after === before ? 'BLOCKED OK' : 'NOT BLOCKED');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: 'test/21-dice-overlay.png' });
  await page.waitForTimeout(3000);
  console.log('after show: overlay hidden:', await page.$eval('#dice-overlay', e => e.classList.contains('hidden')), 'unlocked:', !(await page.evaluate(() => document.body.classList.contains('roll-locked'))));
  await page.click('#v-table .rollbtn:text-is("Luck")'); await page.waitForTimeout(200);
  console.log('roll after unlock → entries', await page.evaluate(() => document.querySelectorAll('#chatlog .e').length));
  await page.waitForTimeout(4500);
  await page.screenshot({ path: 'test/22-room.png', fullPage: true });
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
