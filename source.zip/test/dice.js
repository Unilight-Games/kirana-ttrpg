// Offline test: auto-equip + inventory layout, dice overlay + roll lock (local room mode)
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE ' + m.text()); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  // make a finished character with The Convict set
  const id = await page.evaluate(() => {
    const K = window.__kirana; const c = { id: 'tconv', name: 'ทดสอบนักโทษ', kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {}, skills: [], talentPicks: {}, details: {}, starterSet: 'The Convict', done: true, createdAt: Date.now(), updatedAt: Date.now(), step: 8 };
    K.Store.upsert(c); return c.id; });
  await page.goto(url + '#sheet-' + id); await page.waitForTimeout(500);
  const equip = await page.evaluate(() => { const c = window.__kirana.Store.get('tconv'); return { equip: c.equip, worn: c.inventory.filter(r => r.worn).map(r => r.name) }; });
  console.log('EQUIP', JSON.stringify(equip, null, 1));
  const ta = await page.$$eval('.invitem textarea', els => els.map(e => ({ h: e.offsetHeight, sh: e.scrollHeight, clipped: e.scrollHeight > e.offsetHeight + 2 })));
  console.log('inventory textareas', ta.length, 'clipped:', ta.filter(x => x.clipped).length);
  await page.screenshot({ path: 'test/20-sheet-inv.png', fullPage: true });
  // Gunslinger / Vanguard check
  const eq2 = await page.evaluate(() => { const K = window.__kirana; const out = {}; for (const set of ['The Vanguard', 'The Reaver', 'The Mage', 'The Merchant']) { const c = { id: 'x' + set.replace(/\W/g,'').toLowerCase(), name: set, kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, knowledge: {}, prof: {}, grants: [], skills: [], talentPicks: {}, details: {}, starterSet: set, done: true }; K.Store.upsert(c); } return 1; });
  for (const set of ['The Vanguard', 'The Reaver', 'The Mage', 'The Merchant']) { const sid = 'x' + set.replace(/\W/g,'').toLowerCase(); await page.goto(url + '#sheet-' + sid); await page.waitForTimeout(250); console.log(set, JSON.stringify(await page.evaluate(s => window.__kirana.Store.get(s).equip, sid))); }
  // local room: roll → overlay + lock
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องเต๋า');
  await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.selectOption('#chat-who', 'tconv'); await page.waitForTimeout(200);
  console.log('dice panel in room:', !!(await page.$('.dicepanel')), 'rollbtns', (await page.$$('#v-table .rollbtn')).length);
  await page.click('#v-table .rollbtn:text-is("2d6")'); await page.waitForTimeout(300);
  console.log('overlay visible:', await page.$eval('#dice-overlay', e => !e.classList.contains('hidden')), 'locked:', await page.evaluate(() => document.body.classList.contains('roll-locked')));
  // try to roll again while locked
  const before = await page.evaluate(() => window.__kirana.Store && document.querySelectorAll('#chatlog .e').length);
  await page.evaluate(() => { const b = [...document.querySelectorAll('#v-table .rollbtn')].find(x => x.textContent.includes('Luck')); b.click(); });
  await page.waitForTimeout(300);
  const after = await page.evaluate(() => document.querySelectorAll('#chatlog .e').length);
  console.log('chat entries before/after second click while locked:', before, after, after === before ? 'BLOCKED OK' : 'NOT BLOCKED');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: 'test/21-dice-overlay.png' });
  await page.waitForTimeout(3000);
  console.log('after show: overlay hidden:', await page.$eval('#dice-overlay', e => e.classList.contains('hidden')), 'unlocked:', !(await page.evaluate(() => document.body.classList.contains('roll-locked'))));
  await page.click('#v-table .rollbtn:text-is("Luck")'); await page.waitForTimeout(200);
  console.log('roll after unlock → entries', await page.evaluate(() => document.querySelectorAll('#chatlog .e').length));
  await page.waitForTimeout(4500);
  await page.screenshot({ path: 'test/22-room.png', fullPage: true });
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
