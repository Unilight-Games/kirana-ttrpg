// v1.23 (13 พ.ย. 2026) Non สั่ง: "ทำระบบตั้งชื่อตัวละครจากภาษาในคีรันนาพร้อมความหมาย (เมื่อนำคำมาประกอบกันจะได้ความหมายของชื่อใหม่)"
//  A) DATA.names: 11 ภาษา คลังคำจากไฟล์ภาษาแห่งคีรันนา วิถีตั้งชื่อ แม่แบบอ่านได้ทุกอัน ไม่มีคำหยาบ
//  B) ตัวอย่างชื่อในไฟล์ลอร์ประกอบออกมาตรงตามไฟล์ (รูปชื่อ และความหมายในตัวอย่างที่ไฟล์ให้ไว้)
//  C) สุ่มทุกภาษา × ทุกวิถี ได้ชื่อ คำอ่าน และความหมายครบ
//  D) วิซาร์ด: ปุ่มตั้งชื่อเปิดหน้าต่าง ภาษาตั้งต้นตามวงศา ค้นคลังคำ เลือกคำ ใช้ชื่อ แล้วชื่อกับความหมายลงตัวละคร · เปิดซ้ำได้ชื่อเดิม
//  E) ชีท: แสดงคำอ่านกับความหมายใต้ชื่อ แก้ความหมายได้ · ผู้ชมชีทของคนอื่นเห็นแต่แก้ไม่ได้
//  F) จอมือถือ: หน้าต่างตั้งชื่อไม่ล้นจอด้านข้าง
// ใช้: node test/v123.js
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  await page.goto(url); await wait(400);

  // ================= A) ข้อมูล =================
  const A = await page.evaluate(() => {
    const N = DATA.names; const r = { langs: N.langs.map(l => l.id), words: Object.values(N.words).reduce((s, a) => s + a.length, 0) };
    r.perLang = Object.fromEntries(N.langs.map(l => [l.id, nmLex(l.id).length]));
    r.badTpl = []; r.badList = []; r.badKeys = [];
    for (const L of N.langs) for (const w of L.ways){
      for (const t of [w.name, w.mean, w.flip].filter(Boolean)){ try { const ks = nmSlotNodes(nmTpl(t)).map(n => n.k); ks.forEach(k => { if (!w.slots.some(s => s.k === k)) r.badKeys.push(L.id + '/' + w.id + '/' + k); }); } catch (e){ r.badTpl.push(L.id + '/' + w.id); } }
      for (const s of w.slots) if (s.t === 'fixed' && !(N.lists[s.list] || []).length) r.badList.push(L.id + '/' + w.id + '/' + s.list);
      if (!w.note || !w.ex) r.badList.push('note:' + L.id + '/' + w.id);
    }
    const all = JSON.stringify(N.words);
    r.crude = /อวัยวะเพศ|ร่วมเพศ/.test(all);
    r.gone = [['althalani', 'urnzir'], ['althalani', 'ithryn'], ['althalani', 'Raüthes'], ['elaraic', 'xon']].filter(([l, w]) => N.words[l].some(x => x[0] === w)).map(x => x.join(':'));
    r.xonAlth = (N.words.althalani.find(x => x[0] === 'xon') || [])[2];   // อัลธาลานี xon = สีนวล แสง (คนละคำกับ xon- ของเอลาราอิค)
    r.kin = DATA.kins.map(k => [k.id, nmDefaultLang({ kin: k.id })]);
    r.kinOk = r.kin.every(([, l]) => !!nmLang(l));
    r.rimCel = nmDefaultLang({ kin: 'rimmen', langPick: 'celestian' });
    r.rimLang = nmDefaultLang({ kin: 'rimmen', langPick: 'langkasian' });
    r.lunBase = nmLex('lunaryn').some(e => e.w === 'gor') && nmLex('lunaryn').some(e => e.w === 'Rhem');
    r.orcBase = nmLex('orcish').filter(e => e.src === 'orcish').map(e => e.w);
    r.celDraft = !!nmLang('celestian').draft;
    r.tiaki = (nmLex('reo-moana').find(e => e.w === 'tiaki') || {}).m;
    r.lin = (nmLex('elaraic').find(e => e.w === 'lin') || {}).p;
    return r;
  });
  ok('11 naming languages', A.langs.join(',') === 'althalani,lunaryn,az-zillinar,elaraic,nome-elara,old-nord,gromdul,swalanim,celestian,orcish,reo-moana', A.langs);
  ok('lexicon has 1,300+ words from the language file', A.words >= 1300, A.words);
  ok('every language has words to pick (base language included)', Object.values(A.perLang).every(n => n >= 40), A.perLang);
  ok('every template parses and names only its own slots', A.badTpl.length === 0 && A.badKeys.length === 0, [A.badTpl, A.badKeys]);
  ok('every fixed slot has its list, every way has a note and an example', A.badList.length === 0, A.badList);
  ok('no crude words in the lexicon (Elaraic xon- out, Althalani xon = light stays)', !A.crude && A.gone.length === 0 && A.xonAlth && A.xonAlth[0] === 'สีนวล', [A.gone, A.xonAlth]);
  ok('every kin maps to a naming language', A.kinOk, A.kin);
  ok('rimmen with Celestian as home tongue names in Celestian, otherwise Althalani', A.rimCel === 'celestian' && A.rimLang === 'althalani', [A.rimCel, A.rimLang]);
  ok('Lunaryn keeps Althalani roots plus its own; Orcish has Zuk and Nar over Althalani', A.lunBase && A.orcBase.join(',') === 'Zuk,Nar', A.orcBase);
  ok('Celestian ways are marked as a draft', A.celDraft);
  ok('Reo words from section 6 (tiaki) are in; Thai verbs are tagged (lin = ร้องเพลง)', A.tiaki && A.tiaki[0] === 'พิทักษ์' && /^v/.test(A.lin), [A.tiaki, A.lin]);

  // ================= B) ตัวอย่างในไฟล์ลอร์ =================
  const B = await page.evaluate(() => {
    const W = (lang, w, m, extra) => { const e = nmLex(lang).find(x => x.w.toLowerCase() === w.toLowerCase() && (!m || x.m.includes(m))); if (!e) return { miss: w }; const si = m ? e.m.indexOf(m) : 0; return Object.assign({ id: e.id, w: e.w, r: e.r, m: e.m[si], p: e.p[si] || e.p[0], f: e.f, si }, extra || {}); };
    const F = (list, w) => ({ i: DATA.names.lists[list].findIndex(x => x.w === w) });
    const run = (lang, way, v, extra) => { const r = nmCompose(Object.assign({ lang, way, v, frame: {}, flip: false, shift: true }, extra || {})); return { n: r.name, r: r.reading, m: r.meaning, miss: r.missing }; };
    return {
      gorsyl: run('althalani', 'compound', { A: W('althalani', 'gor', 'หิน'), B: W('althalani', 'syl', 'หัวใจ') }),
      gorsylFlip: run('althalani', 'compound', { A: W('althalani', 'gor', 'หิน'), B: W('althalani', 'syl', 'หัวใจ'), I: F('infix', 'gri'), E: F('ending', 'a') }, { flip: true }),
      naran: run('althalani', 'aspire', { A: W('althalani', 'nar', 'รู้') }),
      solan: run('althalani', 'aspire', { A: W('althalani', 'sola', 'ดวงอาทิตย์') }),
      ansola: run('althalani', 'phenom', { P: F('prefix', 'an'), A: W('althalani', 'sola', 'ดวงอาทิตย์') }),
      alth: run('althalani', 'phenom', { A: W('althalani', 'alth', 'ขาว') }),
      abed: run('az-zillinar', 'theo', { T: F('theo', 'Abed'), A: W('az-zillinar', 'Nuhur') }),
      hibat: run('az-zillinar', 'theo', { T: F('theo', 'Hibat'), A: W('az-zillinar', 'Zulmah') }),
      ibn: run('az-zillinar', 'theo', { T: F('theo', 'Ibn'), A: W('az-zillinar', 'Hikmah') }),
      ruh: run('az-zillinar', 'comp', { A: W('az-zillinar', 'Ruh', 'ดวงวิญญาณ'), B: W('az-zillinar', 'Nahar', 'ตะวัน') }),
      lisan: run('az-zillinar', 'idafa', { A: W('az-zillinar', 'Lisan', 'เสียงกระซิบ'), B: W('az-zillinar', 'Ard', 'แผ่นดิน') }),
      nahir: run('az-zillinar', 'desc', { A: W('az-zillinar', 'Nahir') }),
      aerlin: run('elaraic', 'cont', { A: W('elaraic', 'aer', 'ลม'), B: W('elaraic', 'lin', 'ร้องเพลง') }),
      thaelis: run('elaraic', 'becoming', { A: W('elaraic', 'thae', 'ต้นไม้'), S: F('singular', 'is') }),
      khira: run('elaraic', 'becoming', { A: W('elaraic', 'hira', 'ความรัก'), S: F('singular', "'is") }),
      elhira: run('elaraic', 'action', { P: F('aspect', 'el'), A: W('elaraic', 'hira', 'ความรัก') }),
      kasira: run('elaraic', 'action', { P: F('aspect', 'ka'), A: W('elaraic', 'sir', 'รู้') }),
      anlina: run('elaraic', 'action', { P: F('aspect', 'an'), A: W('elaraic', 'lin', 'ร้องเพลง') }),
      shift: [nmNome('Thaelim', 'ธาเอลิม'), nmNome('Khira', 'คิรา'), nmNome('hira', 'ฮิรา'), nmNome('hath', 'ฮัธ')],
      lhasat: run('nome-elara', 'tool', { A: W('nome-elara', 'lhas'), B: W('nome-elara', 'hath', 'ซ่อน') }),
      gaesha: run('nome-elara', 'scar', { A: W('nome-elara', 'gae', 'ความกลัว'), B: W('nome-elara', 'sha', 'สันติ') }),
      nirtal: run('nome-elara', 'scar', { A: W('nome-elara', 'Nirtal', 'โพรงหิน') }),
      noShift: run('nome-elara', 'shadow', { A: W('nome-elara', 'thae', 'ต้นไม้') }, { shift: false }),
      shifted: run('nome-elara', 'shadow', { A: W('nome-elara', 'thae', 'ต้นไม้') }),
      bjornbani: run('old-nord', 'hunt', { A: W('old-nord', 'Björn'), D: F('deed', 'bani') }),
      dreki: run('old-nord', 'hunt', { A: W('old-nord', 'Dreki'), D: F('deed', 'finnr') }),
      snaer: run('old-nord', 'hunt', { A: W('old-nord', 'Snær'), D: F('deed', 'líf') }),
      isdalr: run('old-nord', 'hearth', { A: W('old-nord', 'Ís'), H: F('hearth', 'dalr') }),
      jokull: run('old-nord', 'hearth', { A: W('old-nord', 'Jökull'), H: F('hearth', 'ætt') }),
      sten: run('old-nord', 'ancestor', { G: W('old-nord', 'Sten'), P: W('old-nord', 'Björn'), S: F('nordchild', 'son') }),
      solveig: run('old-nord', 'ancestor', { G: W('old-nord', 'Sólveig'), P: W('old-nord', 'Björn'), S: F('nordchild', 'dóttir') }),
      ulfr: run('old-nord', 'ancestor', { G: W('old-nord', 'Björn'), P: W('old-nord', 'Úlfr'), S: F('nordchild', 'son') }),
      azgrund: run('gromdul', 'comp', { A: W('gromdul', 'Azgar', 'เกียรติยศ', { clip: true }), B: W('gromdul', 'Grund', 'ค้อน') }),
      gromkar: run('gromdul', 'comp', { A: W('gromdul', 'Grom', 'ภูเขา'), B: W('gromdul', 'Karak', 'ศิลา', { clip: true }) }),
      gromril: run('gromdul', 'comp', { A: W('gromdul', 'Grom', 'ภูเขา'), B: W('gromdul', 'Ril', 'สายน้ำ') }),
      grak: run('gromdul', 'full', { G: W('gromdul', 'Grak'), P: W('gromdul', 'Durin'), S: F('dwchild', 'in'), C: W('gromdul', 'Grak'), D: W('gromdul', 'Drok') }),
      thrazil: run('gromdul', 'full', { G: W('gromdul', 'Grak'), P: W('gromdul', 'Thraza'), S: F('dwchild', 'il'), C: W('gromdul', 'Grak'), D: W('gromdul', 'Drok') }),
      brak: run('gromdul', 'epithet', { G: W('gromdul', 'Brak', 'เอล'), A: W('gromdul', 'Thag'), B: W('gromdul', 'Grak') }),
      neyan: run('swalanim', 'neyan', { A: W('swalanim', 'Neyan', 'ความทรงจำ'), B: W('swalanim', 'Chant', 'เสียง') }),
      morvym: run('swalanim', 'neyan', { A: W('swalanim', 'Morvym', 'ม่านหมอก'), B: W('swalanim', 'Soufl', 'ลมหายใจ') }),
      kiara: run('swalanim', 'paume', { G: { text: 'Kiara' }, A: W('swalanim', 'Veyir', 'มองเห็น') }),
      lucien: run('swalanim', 'racine', { G: { text: 'lucien' }, D: F('swde', 'de la'), A: W('swalanim', 'Roche', 'ศิลา') }),
      zuknar: run('orcish', 'given', { A: W('orcish', 'Zuk'), B: W('orcish', 'Nar') }),
      orcFull: run('orcish', 'full', { G: W('orcish', 'Zuk'), S: F('orcchild', 'Uruk'), P: W('orcish', 'gor', 'หิน'), T: W('orcish', 'zorn'), U: W('orcish', 'Nar') }),
      niho: run('reo-moana', 'epithet', { A: W('reo-moana', 'niho'), B: W('reo-moana', 'mako') }),
      toka: run('reo-moana', 'epithet', { A: W('reo-moana', 'toka', 'พืดปะการัง'), B: W('reo-moana', 'rama', 'แสงเรือง') }),
      kaitiaki: run('reo-moana', 'agent', { A: W('reo-moana', 'tiaki') }),
      kairuku: run('reo-moana', 'agent', { A: W('reo-moana', 'ruku') }),
      celes: run('celestian', 'comp', { A: W('celestian', 'Pyro'), B: W('celestian', 'Alto'), E: F('celgender', 'a') }),
      rhem: run('lunaryn', 'compound', { A: W('lunaryn', 'Rhem', 'เลือด'), B: W('lunaryn', 'Vorda', 'วงศ์ตระกูล') }),
      missing: run('althalani', 'compound', { A: W('althalani', 'gor', 'หิน') }),
      oElle: run('althalani', 'phenom', { A: W('althalani', 'o', 'ไม่มี'), E: F('ending', 'elle') }),
      carrare: run('celestian', 'root', { A: W('celestian', 'Carrare', 'เดินทาง'), E: F('celgender', 'a') }),
    };
  });
  const eq = (k, n, m, r) => ok(`lore example ${k}: ${n}`, B[k].n === n && (m === undefined || B[k].m === m) && (r === undefined || B[k].r === r), B[k]);
  eq('gorsyl', 'Gorsyl', 'หัวใจแห่งหิน', 'กอร์ซิล');
  eq('gorsylFlip', 'Gorgrisyla', 'หินแห่งหัวใจ (อย่างดุดัน)');
  eq('naran', 'Naran', 'ผู้รู้', 'นารัน');
  eq('solan', 'Solan', 'ผู้แห่งดวงอาทิตย์', 'โซลัน');
  eq('ansola', 'Ansola', 'ดวงอาทิตย์แรกเริ่ม', 'อันโซลา');
  eq('alth', 'Alth', 'ขาว');
  eq('abed', 'Abed an-Nuhur', 'ผู้รับใช้แห่งแสงสว่าง', 'อาเบด อัน-นูฮูร');
  eq('hibat', 'Hibat az-Zulmah', 'ของขวัญจากความมืดมิด');
  eq('ibn', 'Ibn al-Hikmah', 'บุตรแห่งปัญญา');
  eq('ruh', 'Ruh-Nahar', 'ดวงวิญญาณแห่งตะวัน');
  eq('lisan', 'Lisan al-Ard', 'เสียงกระซิบแห่งแผ่นดิน');
  eq('nahir', 'Nahir', 'ผู้เจิดจรัส');
  eq('aerlin', 'Aerlin', 'การร้องเพลงแห่งลม');
  eq('thaelis', 'Thaelis', 'ต้นไม้หนึ่งเดียว', 'ธาเอลิส');
  eq('khira', "Hira'is", 'ความรักหนึ่งเดียว');
  eq('elhira', 'Elhira', 'ความรักที่เบ่งบานเต็มที่');
  eq('kasira', 'Kasira', 'ผู้ได้รู้แล้ว');
  eq('anlina', 'Anlina', 'การเริ่มต้นแห่งการร้องเพลง');
  ok('Nóme sound shift follows the file: Thaelim → Taelim, Khira → Kira, hira → \'ira, hath → \'at', JSON.stringify(B.shift) === JSON.stringify([['Taelim', 'ตาเอลิม'], ['Kira', 'กิรา'], ["'ira", 'อิรา'], ["'at", 'อัต']]), B.shift);
  eq('lhasat', "Lhas'at");
  eq('gaesha', "Gae'sha", 'สันติแห่งความกลัว');
  eq('nirtal', 'Nirtal', 'โพรงหิน');
  ok('Nóme shift can be turned off (Thae) and is on by default (Tae)', B.noShift.n === 'Thae' && B.shifted.n === 'Tae', [B.noShift, B.shifted]);
  eq('bjornbani', 'Björnbani', 'ผู้สังหารหมี');
  eq('dreki', 'Dreki-finnr', 'ผู้ค้นพบมังกร');
  eq('snaer', 'Snær-líf', 'ผู้รอดจากหิมะ');
  eq('isdalr', 'Ís-dalr', 'หุบเขาน้ำแข็ง');
  eq('jokull', 'Jökull-ætt', 'ตระกูลธารน้ำแข็ง');
  eq('sten', 'Sten Björnsson', 'สเตน บุตรชายของบยอร์น');
  eq('solveig', 'Sólveig Björnsdóttir', 'โซลเวก ธิดาของบยอร์น');
  eq('ulfr', 'Björn Úlfsson', 'บยอร์น (หมี) บุตรชายของอู๊ลฟ์');
  eq('azgrund', 'Azgrund', 'ค้อนแห่งเกียรติยศ');
  eq('gromkar', 'Gromkar', 'ศิลาแห่งภูเขา');
  eq('gromril', 'Gromril', 'สายน้ำแห่งภูเขา');
  eq('grak', 'Grak Durinin Grakdrok', 'กรัค (เหล็ก) บุตรแห่งดูริน แห่งตระกูลโล่แห่งเหล็ก', 'กรัค ดูรินิน กรัคดร็อก');
  eq('thrazil', 'Grak Thrazil Grakdrok', 'กรัค (เหล็ก) ธิดาแห่งธราซา แห่งตระกูลโล่แห่งเหล็ก', 'กรัค ธราซิล กรัคดร็อก');
  eq('brak', 'Brak Thaggrak', 'บรัค (เอล) เคราเหล็ก');
  eq('neyan', 'Neyanchant', 'เสียงแห่งความทรงจำ');
  eq('morvym', 'Morvymsoufl', 'ลมหายใจแห่งม่านหมอก');
  eq('kiara', 'Kiara Veyir', 'Kiara ผู้มองเห็น', 'Kiara เวยีร์');
  eq('lucien', 'Lucien de la Roche', 'Lucien แห่งศิลา');
  eq('zuknar', "Zuk'nar", 'หัวใจแห่งความแข็งแกร่ง');
  ok('Orcish full name: given, Uruk-father, tribe', /^Zuk Uruk-Gor [A-Z][a-z]+nar$/.test(B.orcFull.n) && /^ซุก \(หัวใจ\) บุตรแห่งกอร์ แห่งเผ่า/.test(B.orcFull.m), B.orcFull);
  eq('niho', 'Niho-Mako', 'เขี้ยวฉลาม');
  eq('toka', 'Toka-Rama', 'พืดปะการังแสงเรือง');
  eq('kaitiaki', 'Kaitiaki', 'ผู้พิทักษ์');
  eq('kairuku', 'Kairuku');
  eq('celes', 'Pyroalta', 'ไฟแห่งความสูงส่ง', 'ไพโรอัลตา');
  eq('rhem', 'Rhemvorda', 'วงศ์ตระกูลแห่งเลือด');
  eq('oElle', 'Oelle', 'ไม่มี');
  eq('carrare', 'Carrara', 'เดินทาง', 'คาร์รารา');
  ok('a required slot left empty blocks the name', B.missing.miss.join() === 'B' && B.missing.m === '', B.missing);

  // ================= C) สุ่มทุกภาษา × ทุกวิถี =================
  const C = await page.evaluate(() => {
    const bad = []; let n = 0;
    for (const L of DATA.names.langs) for (const w of L.ways) for (let i = 0; i < 25; i++){
      const st = { lang: L.id, way: w.id, v: {}, frame: {}, flip: i % 2 === 1, shift: true }; nmRandomAll(st); st.flip = i % 2 === 1;
      const r = nmCompose(st); n++;
      const txt = r.name + '|' + r.meaning + '|' + r.reading;
      if (r.missing.length || !r.name || !r.meaning || !r.reading || /undefined|null|NaN|[{}\[\]]|\s\s|^\s|\s$/.test(txt) || /^[^A-ZÀ-ÞĀ-ſ']/.test(r.name)) bad.push([L.id, w.id, txt, r.missing]);
    }
    return { n, bad: bad.slice(0, 8), badN: bad.length };
  });
  ok(`random names in every language and way come out whole (${C.n} tries)`, C.badN === 0, C.bad);

  // ================= D) วิซาร์ด =================
  await page.evaluate(() => { startWizard(null); selectKin(W.char, 'handerlaw-dwarves'); W.step = STEP_DEFS.findIndex(s => s.key === 'details'); renderWizard(); });
  await page.goto(url + '#wizard'); await wait(500);
  ok('details step has the naming button and the meaning field', await page.evaluate(() => !!document.querySelector('.nm-open') && !!document.querySelector('input.nm-meaning')));
  await page.click('.nm-open'); await wait(300);
  const D1 = await page.evaluate(() => ({ open: !!document.querySelector('#modal:not(.hidden) .nmb'), wide: !!document.querySelector('#modal .box.wide'), lang: document.querySelector('.nm-lang').value,
    label: document.querySelector('.nm-lang').selectedOptions[0].textContent, ways: [...document.querySelectorAll('.nm-way')].map(b => b.textContent), name: document.querySelector('.nm-name') && document.querySelector('.nm-name').textContent }));
  ok('builder opens in Gromdûl for a Handerlaw dwarf, the language the kin speaks (✓)', D1.open && D1.wide && D1.lang === 'gromdul' && /✓/.test(D1.label) && /ตามวงศา/.test(D1.label), D1);
  ok('Gromdûl shows its four naming ways and a random name to start', D1.ways.length === 4 && !!D1.name, D1);
  // วิถีชื่อตัวแบบผสมคำ ค้น "ค้อน" แล้วเลือก Grund
  await page.click('.nm-way:has-text("ชื่อตัวแบบผสมคำ")'); await wait(200);
  await page.click('.nm-slot[data-k="B"] .nm-find'); await wait(200);
  await page.fill('.nm-slot[data-k="B"] .nm-q', 'ค้อน'); await wait(200);
  const hits = await page.evaluate(() => [...document.querySelectorAll('.nm-slot[data-k="B"] .nm-hit')].slice(0, 3).map(b => b.textContent));
  ok('searching the lexicon by Thai meaning finds Grund (ค้อน) first', /^Grund/.test(hits[0] || ''), hits);
  await page.click('.nm-slot[data-k="B"] .nm-hit >> nth=0'); await wait(200);
  await page.click('.nm-slot[data-k="A"] .nm-find'); await wait(200);
  await page.fill('.nm-slot[data-k="A"] .nm-q', 'Azgar'); await wait(200);
  await page.click('.nm-slot[data-k="A"] .nm-hit >> nth=0'); await wait(200);
  await page.click('.nm-slot[data-k="A"] .nm-clip input'); await wait(200);
  const D2 = await page.evaluate(() => ({ name: document.querySelector('.nm-name').textContent, mean: document.querySelector('.nm-mn').value, rd: document.querySelector('.nm-rd').value,
    brk: document.querySelector('.nm-break').textContent, senses: [...document.querySelectorAll('.nm-slot[data-k="A"] .nm-sense')].map(b => b.textContent) }));
  ok('picking Azgar (clipped) + Grund builds Azgrund, ค้อนแห่งเกียรติยศ', D2.name === 'Azgrund' && D2.mean === 'ค้อนแห่งเกียรติยศ' && D2.rd === 'อัซกรุนด์' && /Az \(อัซ\) = เกียรติยศ \+ Grund/.test(D2.brk), D2);
  // เปลี่ยนความหมายของคำแรก แล้วสลับลำดับ
  await page.click('.nm-slot[data-k="A"] .nm-sense:has-text("ศักดิ์ศรี")'); await wait(150);
  const m2 = await page.evaluate(() => document.querySelector('.nm-mn').value);
  await page.click('.nm-flip'); await wait(150);
  const m3 = await page.evaluate(() => document.querySelector('.nm-mn').value);
  ok('sense chips change the meaning, flip swaps head and modifier', m2 === 'ค้อนแห่งศักดิ์ศรี' && m3 === 'ศักดิ์ศรีแห่งค้อน', [m2, m3]);
  await page.click('.nm-flip'); await wait(150);
  // แก้ความหมายเองก่อนกดใช้
  await page.fill('.nm-mn', 'ค้อนแห่งศักดิ์ศรีของบรรพชน'); await page.click('.nm-use'); await wait(400);
  const D3 = await page.evaluate(() => ({ closed: document.querySelector('#modal').classList.contains('hidden'), name: W.char.name, nm: W.char.nameMeaning,
    input: document.querySelector('#v-create input[placeholder^="ชื่อตัวละคร"]').value, mean: document.querySelector('input.nm-meaning').value, read: (document.querySelector('.nm-read') || {}).textContent }));
  ok('use: the wizard name and meaning fields fill in', D3.closed && D3.name === 'Azgrund' && D3.input === 'Azgrund' && D3.mean === 'ค้อนแห่งศักดิ์ศรีของบรรพชน' && D3.read === 'อ่านว่า อัซกรุนด์', D3);
  ok('character keeps the meaning, reading, language, way and parts', D3.nm && D3.nm.text === 'ค้อนแห่งศักดิ์ศรีของบรรพชน' && D3.nm.lang === 'gromdul' && D3.nm.way === 'comp' && D3.nm.parts.length === 2 && D3.nm.parts[0].w === 'Az' && D3.nm.state && D3.nm.state.v.A.clip === true, D3.nm);
  // เปิดซ้ำได้ชื่อเดิม
  await page.click('.nm-open'); await wait(300);
  const D4 = await page.evaluate(() => ({ name: document.querySelector('.nm-name').textContent, way: (document.querySelector('.nm-way.sel') || {}).textContent }));
  ok('reopening the builder restores the last name', D4.name === 'Azgrund' && D4.way === 'ชื่อตัวแบบผสมคำ', D4);
  // สุ่มทั้งชื่อ แล้วเปลี่ยนภาษา
  await page.click('.nm-rand'); await wait(150);
  await page.selectOption('.nm-lang', 'reo-moana'); await wait(200);
  await page.click('.nm-way:has-text("นามผู้กระทำ")'); await wait(150);
  const D5 = await page.evaluate(() => ({ name: document.querySelector('.nm-name').textContent, mean: document.querySelector('.nm-mn').value }));
  ok('switching to Reo Moana agent way gives a Kai- name meaning ผู้…', /^Kai[a-zāēīōū']+$/.test(D5.name) && /^ผู้/.test(D5.mean), D5);
  await page.evaluate(() => modal(null)); await wait(100);
  // พิมพ์ชื่อเองแล้วคำอ่านเก่าหายไป แต่ความหมายยังอยู่
  await page.fill('#v-create input[placeholder^="ชื่อตัวละคร"]', 'Azgrund the Bold'); await page.evaluate(() => renderWizard()); await wait(200);
  const D6 = await page.evaluate(() => ({ read: !!document.querySelector('.nm-read'), mean: document.querySelector('input.nm-meaning').value }));
  ok('typing a different name hides the stale reading, keeps the meaning', !D6.read && D6.mean === 'ค้อนแห่งศักดิ์ศรีของบรรพชน', D6);

  // ================= E) ชีท =================
  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert(Object.assign(newChar(), { id: 'nm1', name: 'Gorsyl', kin: 'lunaryn', size: 'Medium', done: true, step: 7, starterSet: 'The Wanderer',
    nameMeaning: { text: 'หัวใจแห่งหิน', name: 'Gorsyl', reading: 'กอร์ซิล', lang: 'althalani', langTh: 'อัลธาลานี (ภาษากลาง)', way: 'compound', wayTh: 'ชื่อแบบผสมคำ', parts: [{ k: 'A', w: 'gor', r: 'กอร์', m: 'หิน' }, { k: 'B', w: 'syl', r: 'ซิล', m: 'หัวใจ' }] } })); });
  await page.goto(url + '#sheet-nm1'); await wait(600);
  const E1 = await page.evaluate(() => { const e = document.querySelector('.idb, [data-k="id"]'); const l = document.querySelector('.namemean'); return { txt: l && l.textContent, title: l && l.title, h2: e && e.querySelector('h2').textContent }; });
  ok('sheet shows reading and meaning under the name', E1.h2 === 'Gorsyl' && /อ่านว่า กอร์ซิล/.test(E1.txt) && /ความหมาย: หัวใจแห่งหิน/.test(E1.txt), E1);
  ok('hover shows language, way and the word parts', /อัลธาลานี \(ภาษากลาง\) · ชื่อแบบผสมคำ/.test(E1.title || '') && /gor \(กอร์\) = หิน \+ syl \(ซิล\) = หัวใจ/.test(E1.title || ''), E1.title);
  await page.click('.namemean .nm-edit'); await wait(200);
  await page.fill('.nm-ta', 'หัวใจที่แกร่งดั่งหิน'); await page.click('.nm-save'); await wait(400);
  const E2 = await page.evaluate(() => ({ txt: (document.querySelector('.namemean') || {}).textContent, saved: window.__kirana.Store.get('nm1').nameMeaning.text, reading: window.__kirana.Store.get('nm1').nameMeaning.reading }));
  ok('owner edits the meaning on the sheet and it saves', /ความหมาย: หัวใจที่แกร่งดั่งหิน/.test(E2.txt || '') && E2.saved === 'หัวใจที่แกร่งดั่งหิน' && E2.reading === 'กอร์ซิล', E2);
  // ตัวละครเก่าที่ไม่มีความหมาย: ชีทไม่พัง และเจ้าของเห็นปุ่มจดความหมาย
  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert(Object.assign(newChar(), { id: 'nm2', name: 'เก่า', kin: 'solrin', size: 'Medium', done: true, step: 7, starterSet: 'The Wanderer' })); });
  await page.goto(url + '#sheet-nm2'); await wait(500);
  const E3 = await page.evaluate(() => ({ btn: (document.querySelector('.namemean .nm-edit') || {}).textContent, h2: document.querySelector('[data-k="id"] h2').textContent }));
  ok('old character without a meaning: sheet renders, owner sees a button to add one', E3.h2 === 'เก่า' && E3.btn === 'ความหมายของชื่อ', E3);
  const E4 = await page.evaluate(() => { const c = window.__kirana.Store.get('nm1'); const a = nameMeaningLine(c, true, () => {}); const b = nameMeaningLine(window.__kirana.Store.get('nm2'), true, () => {}); return { a: a && a.textContent, edit: !!(a && a.querySelector('.nm-edit')), b }; });
  ok('read-only view shows the meaning without an edit button, and nothing for a name without one', /ความหมาย: หัวใจที่แกร่งดั่งหิน/.test(E4.a || '') && !E4.edit && E4.b === null, E4);

  // ================= F) จอมือถือ =================
  await page.setViewportSize({ width: 390, height: 844 }); await wait(200);
  await page.evaluate(() => { openNameBuilder(Object.assign(newChar(), { kin: 'swalan' }), () => {}); }); await wait(300);
  const F1 = await page.evaluate(() => { const b = document.querySelector('#modal .box'); return { sw: b.scrollWidth, cw: b.clientWidth, lang: document.querySelector('.nm-lang').value }; });
  ok('builder fits a phone screen without sideways scroll (Swalan for a Swalan)', F1.sw <= F1.cw + 1 && F1.lang === 'swalanim', F1);
  await page.evaluate(() => modal(null));

  ok('no page errors', errors.length === 0, errors);
  console.log(`v1.23: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
