// v1.31 (Non เคาะ 17 พ.ย. 2026 ข้อ 8 ถึง 12): ข้อมูลเผ่าให้ตรงกันทุกไฟล์
//  8 "ยึดตาม Astral Sea ครับ" · 9 "สวาลานสูง 1.64 ถึง 1.8 ครับ พวกเขาไม่แก่ แต่ถ้าขาดพลังงานชีวิตตัวจะแก่เร็วมากจนตายได้ครับ (หากได้รับพลังงานชีวิตจะกลับมาหนุ่มสาวดังเดิม)"
//  10 "สี่ขาครับ ผมเขียนผิด" · 11 "กินทั้งเผ่าทรงปัญญาอื่นและพวกเดียวกันครับ" · 12 "เป็นนักโทษประหารและอาชญากรอุกฉกรรจ์ครับ"
//  A) ข้อมูลวงศา  B) ส่วนสูงในหน้าต่างวงศาตรงกับบทความเผ่าทุกวงศา  C) บทความเผ่า  D) หน้าต่างวงศาในตัวช่วยสร้างตัวละคร  E) หน้าบทความ
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail).slice(0, 1500) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  await page.goto(url); await wait(500);

  // ================= A) ข้อมูลวงศา =================
  const A = await page.evaluate(() => ({ nk: KIN.nightkin.size, na: KIN['night-alves'].size, sw: KIN.swalan.size, age: KIN.swalan.age }));
  ok('A: Nightkin 1.56 to 1.68 m (Astral)', A.nk.includes('1.56 ถึง 1.68 เมตร') && !A.nk.includes('1.65 ถึง 1.8'), A.nk);
  ok('A: Night Alves 1.67 to 1.8 m (Astral)', A.na.includes('1.67 ถึง 1.8 เมตร') && !A.na.includes('1.56'), A.na);
  ok('A: Swalan 1.64 to 1.80 m', A.sw.includes('1.64 ถึง 1.80 เมตร') && !A.sw.includes('1.74'), A.sw);
  ok('A: Swalan do not age with time, age fast to death without life force, and regain youth when fed',
    A.age.startsWith('สวาลานไม่แก่ชราจากกาลเวลา') && A.age.includes('แก่ลงอย่างรวดเร็วจนถึงแก่ความตาย') && A.age.includes('ก็ต่อเมื่อขาดพลังชีวิต') && A.age.includes('หนุ่มสาวดังเดิม') && !A.age.includes('ไม่สามารถตายจากความชรา'), A.age);

  // ================= B) ส่วนสูงตรงกันทุกวงศา =================
  const B = await page.evaluate(() => {
    const nums = (s) => (String(s).match(/\d+(?:\.\d+)?/g) || []).slice(0, 2).map(Number);
    const out = [];
    for (const k of Object.keys(KIN)){ const id = KIN_LORE[k]; const a = id && LORE[id]; if (!a) continue;
      const row = (a.box || []).find(r => r[0] === 'ส่วนสูง'); const kin = nums(KIN[k].size);
      if (!row || kin.length < 2) { out.push([k, 'skip']); continue; }
      const art = nums(row[1]); out.push([k, art.join('-'), kin.join('-'), art[0] === kin[0] && art[1] === kin[1]]); }
    return out; });
  const checked = B.filter(r => r[1] !== 'skip');
  ok('B: every playable kin shows the same height range as its race article', checked.length >= 10 && checked.every(r => r[3] === true), B);

  // ================= C) บทความเผ่า =================
  const C = await page.evaluate(() => { const t = (id) => JSON.stringify([LORE[id].lead, LORE[id].box, LORE[id].body]);
    return { sw: t('swalan'), nb: t('necrobug'), cn: t('childofnight'), magic: JSON.stringify(LORE.magicrev ? LORE.magicrev.body : []) }; });
  ok('C: Swalan first test subjects were death-row prisoners and serious criminals', C.sw.includes('ผู้ทดลองกลุ่มแรกคือนักโทษประหารและอาชญากรอุกฉกรรจ์') && !C.sw.includes('อาสาสมัคร'), null);
  ok('C: Swalan aging follows the ruling', C.sw.includes('ผู้ทดลองเลิกแก่ไปตามกาลเวลา') && C.sw.includes('หนุ่มสาวดังเดิม') && !C.sw.includes('ตายไปตามปกติ'), null);
  ok('C: Necrobug has six limbs and walks on four legs', C.nb.includes('หกรยางค์') && C.nb.includes('อีกสี่ขารับน้ำหนัก') && !C.nb.includes('ขาหกขา') && !C.nb.includes('สี่คู่'), null);
  ok('C: Children of Night eat both other sentient races and their own kind', C.cn.includes('กินเนื้อทั้งเผ่าทรงปัญญาอื่นและพวกเดียวกันเอง'), null);
  ok('C: the Magic Revolution article still names the prisoners and the ageless Swalan', C.magic.includes('นักโทษประหารและอาชญากรอุกฉกรรจ์') && C.magic.includes('ไร้อายุขัย'), null);
  const dash = await page.evaluate(() => (JSON.stringify(['swalan','necrobug','childofnight'].map(id => LORE[id].body)).match(/[—–]| - | -- /g) || []).length);
  ok('C: no dash joints in the edited articles', dash === 0, dash);

  // ================= D) หน้าต่างวงศา =================
  const D = await page.evaluate(() => { const read = (id) => { kinDetailModal(KIN[id], { kin: null }); const s = document.querySelector('#modal').textContent; modal(null); return s; };
    return { sw: read('swalan'), nk: read('nightkin'), na: read('night-alves') }; });
  ok('D: the Swalan kin window shows the new age and height', D.sw.includes('หนุ่มสาวดังเดิม') && D.sw.includes('1.64 ถึง 1.80 เมตร'), null);
  ok('D: the Nightkin and Night Alves windows show the Astral heights', D.nk.includes('1.56 ถึง 1.68 เมตร') && D.na.includes('1.67 ถึง 1.8 เมตร'), null);

  // ================= E) หน้าบทความ =================
  await page.goto(url + '#lore-swalan'); await wait(400);
  const E1 = await page.evaluate(() => document.querySelector('#v-lore').textContent);
  ok('E: the Swalan page reads the new aging and test subjects', E1.includes('ผู้ทดลองเลิกแก่ไปตามกาลเวลา') && E1.includes('ผู้ทดลองกลุ่มแรกคือนักโทษประหาร'), null);
  await page.goto(url + '#lore-necrobug'); await wait(400);
  const E2 = await page.evaluate(() => document.querySelector('#v-lore').textContent);
  ok('E: the Necrobug page reads six limbs and four legs', E2.includes('หกรยางค์') && E2.includes('อีกสี่ขา'), null);

  ok('no page errors', errors.length === 0, errors);
  console.log(`v131: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
