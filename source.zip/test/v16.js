// v1.6: drag/LOS, vitals sync, deep water, dashboards (docked/floating), GM notes, initiative order, map image, knowledge rule, hue, scroll keep
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type()==='error' && !/Failed to load resource/.test(m.text())) errors.push('CONSOLE ' + m.text()); });
  page.on('dialog', d => d.accept(d.type()==='prompt' ? 'แผนที่มีภาพ' : undefined));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  await page.evaluate(() => { const K = window.__kirana; const cv = document.createElement('canvas'); cv.width = cv.height = 60; const ctx = cv.getContext('2d'); ctx.fillStyle = '#a63'; ctx.fillRect(0,0,60,60);
    const mk = (id, name, kin) => ({ id, name, kin, size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{lore:2}, prof:{}, skills:['Yantra Master'], details:{}, done:true, step:7, portrait: cv.toDataURL(), starterSet:'The Vanguard' });
    K.Store.upsert(mk('v16', 'อัศวิน', 'lunaryn')); });
  // ---- knowledge rule + perfect text + hue ----
  const rule = await page.evaluate(() => { const c = window.__kirana.Store.get('v16'); const d = compute(c); const k = DATA.knowledge.find(x=>x.id==='lore') || DATA.knowledge[0]; const kb = knowledgeBonus(c, d, k); return { total: kb.total, lv: kb.lv, mod: kb.mod, perfect: judgeDefense(9, 9, 'parry').text, hueEvade: rollHue('หลบ Evade'), hueSave: rollHue('ได้ Advantage ในการทอย Saving Throw ป้องกันพิษ'), hueNone: rollHue('ทำอาหาร') }; });
  console.log('knowledge/perfect/hue:', JSON.stringify(rule));
  // ---- sheet: HP change pushes to token later; scroll keep ----
  await page.goto(url + '#sheet-v16'); await page.waitForTimeout(500);
  await page.evaluate(() => window.scrollTo(0, 400)); await page.waitForTimeout(100);
  const y0 = await page.evaluate(() => window.scrollY);
  await page.click('.resbar button:has-text("−")'); await page.waitForTimeout(250);
  const y1 = await page.evaluate(() => window.scrollY);
  console.log('scroll before/after HP−:', y0, y1, 'hp now:', await page.evaluate(() => window.__kirana.Store.get('v16').current.hp), 'at set:', await page.evaluate(() => !!window.__kirana.Store.get('v16').current.at));
  // ---- room ----
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้อง v1.6'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(400);
  console.log('labels:', await page.$$eval('#v-table .fld span', es => es.map(e=>e.textContent).join('|')));
  await page.fill('input[placeholder="ชื่อ NPC/ศัตรู"]', 'จระเข้'); await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(300);
  const t0 = await page.evaluate(() => { const t = Table.room.tokens[0]; const c = window.__kirana.Store.get('v16'); return { tokHp: t.hp, sheetHp: c.current.hp, vitalsAt: !!t.vitalsAt }; });
  console.log('token hp equals sheet after place:', JSON.stringify(t0));
  // docked dashboards present
  console.log('docked panels:', (await page.$$('.twin-card')).length, 'order rows:', (await page.$$('.toklist.compact .tok')).length, 'float btn:', !!(await page.$('.twin-card button:has-text("ลอย")')));
  // select pc → tok panel with vitals + combat panel
  await page.click('.toklist.compact .tok.pc'); await page.waitForTimeout(250);
  console.log('tok panel:', !!(await page.$('.twin-tok')), 'vitals:', (await page.$$('.twin-tok .vital')).length, 'combat panel:', !!(await page.$('.twin-tok .combat-panel')), 'weapons:', (await page.$$('.twin-tok .cp-w')).length, 'tough rows:', (await page.$$('.twin-tok .cp-t tr')).length, 'skill details:', (await page.$$('.twin-tok .cp-d')).length);
  // SAN −1 on token → sheet follows
  await page.click('.twin-tok .vital:has(.vl.san) button[title$="−1"]'); await page.waitForTimeout(300);
  const san = await page.evaluate(() => { const t = Table.room.tokens[0]; const c = window.__kirana.Store.get('v16'); return { tok: t.san, sheet: c.current.sanity, max: t.sanMax }; });
  console.log('sanity token→sheet:', JSON.stringify(san));
  // sheet → token (while in room): change via sheet page then back
  await page.click('#v-table button:has-text("📜 ชีท")'); await page.waitForTimeout(400);
  await page.click('.resbar button:has-text("เต็ม")'); await page.waitForTimeout(250);
  await page.click('.roombar button'); await page.waitForTimeout(400);
  const back = await page.evaluate(() => { const t = Table.room.tokens[0]; const c = window.__kirana.Store.get('v16'); return { tok: [t.hp, t.san], sheet: [c.current.hp, c.current.sanity] }; });
  console.log('after sheet full → token:', JSON.stringify(back));
  // GM desc/note
  await page.evaluate(() => { Table.sel = Table.room.tokens.find(t=>t.kind==='npc').id; renderTable(); }); await page.waitForTimeout(200);
  await page.fill('.twin-tok textarea[placeholder^="คำอธิบายหมากนี้"]', 'ตัวใหญ่ หางแกว่ง'); await page.click('#v-table h2'); await page.waitForTimeout(250);
  await page.fill('.twin-tok textarea[placeholder^="บันทึกลับของ GM"]', 'จุดอ่อนท้อง'); await page.click('#v-table h2'); await page.waitForTimeout(250);
  console.log('npc desc/note saved:', await page.evaluate(() => { const t = Table.room.tokens.find(t=>t.kind==='npc'); return t.desc + ' / ' + t.note; }));
  // aquatic toggle + deep water
  await page.click('.twin-tok button:has-text("สัตว์น้ำ")'); await page.waitForTimeout(200);
  const water = await page.evaluate(() => { const r = Table.room; const pc = r.tokens.find(t=>t.kind==='pc'), npc = r.tokens.find(t=>t.kind==='npc'); setMapCell(r.map, 10, 10, 'W'); setMapCell(r.map, 11, 10, 'W'); pc.x = 9; pc.y = 10; npc.x = 12; npc.y = 10; const c = window.__kirana.Store.get('v16');
    const ok1 = tryMoveToken(r, pc, 10, 10, true, false); const blocked = Table.attackBlocked(c); const ok2 = tryMoveToken(r, npc, 11, 10, true, false); return { moved: ok1, inWater: pc.inWater, blocked, npcAquaticInWater: npc.inWater && npc.aquatic, chat: Table.chat[0].text, standableW: cellStandable(r.map, 10, 10), passableW: cellPassable(r.map, 10, 10) }; });
  console.log('deep water:', JSON.stringify(water));
  await page.waitForTimeout(200);
  console.log('water class on grid:', (await page.$$('.gtok.water')).length);
  // LOS: wall between
  const los = await page.evaluate(() => { const r = Table.room; r.map.cells = '.'.repeat(400); setMapCell(r.map, 5, 5, '#'); const a = {x:3,y:5}, b = {x:8,y:5}; const t = {x:3,y:5,nv:false}; r.light = 'low'; const s = tokenSight(r, t); return { blocked: !losClear(r.map, a, b), clearDiag: losClear(r.map, a, {x:8,y:8}), sightHasBehind: s.has('8,5'), sightHasWall: s.has('5,5'), sightSize: s.size }; });
  console.log('line of sight:', JSON.stringify(los));
  // initiative ordering
  await page.evaluate(() => { const r = Table.room; r.light='low'; renderTable(); }); await page.waitForTimeout(100);
  await page.click('button:has-text("เริ่มการต่อสู้")'); await page.waitForTimeout(300);
  const ord = await page.evaluate(() => ({ order: Table.room.enc.order.length, rows: [...document.querySelectorAll('.toklist.compact .tok .ord')].map(e=>e.textContent), badges: document.querySelectorAll('.gtok .initbadge').length }));
  console.log('initiative order:', JSON.stringify(ord));
  // float toggle
  await page.click('.twin-card button:has-text("⇱ ลอย")'); await page.waitForTimeout(250);
  console.log('floating windows:', (await page.$$('#twins .hud-win')).length, 'docked stub:', !!(await page.$('.twin-card p.dim')));
  const win = await page.$('#twins .hud-win .hud-head'); const wb = await win.boundingBox();
  await page.mouse.move(wb.x+40, wb.y+10); await page.mouse.down(); await page.mouse.move(wb.x-200, wb.y+120, {steps:6}); await page.mouse.up(); await page.waitForTimeout(200);
  const wb2 = await (await page.$('#twins .hud-win')).boundingBox();
  console.log('window dragged:', Math.round(wb.x), '→', Math.round(wb2.x), 'persisted:', await page.evaluate(() => !!JSON.parse(localStorage.getItem('kirana.twin')).pos.order));
  await page.click('#twins .hud-win button[title^="เก็บกลับ"]'); await page.waitForTimeout(200);
  console.log('after dock back:', (await page.$$('#twins .hud-win')).length);
  // ---- map image in editor ----
  await page.goto(url + '#maps'); await page.waitForTimeout(300);
  await page.click('button:has-text("+ สร้างแผนที่ใหม่")'); await page.waitForTimeout(400);
  const imgRes = await page.evaluate(async () => { const cv = document.createElement('canvas'); cv.width = 1600; cv.height = 1200; const ctx = cv.getContext('2d'); for (let i=0;i<60;i++){ ctx.fillStyle = `hsl(${i*6},60%,${30+i%5*8}%)`; ctx.fillRect((i*53)%1600, (i*97)%1200, 300, 200); } const blob = await new Promise(r=>cv.toBlob(r, 'image/png')); const file = new File([blob], 'map.png', {type:'image/png'}); const res = await shrinkMapImage(file); return { kb: Math.round(res.bytes/1024), webp: res.data.startsWith('data:image/webp'), ratio: res.ratio }; });
  console.log('shrink image:', JSON.stringify(imgRes));
  await page.evaluate(async () => { const id = location.hash.slice(9); const m = MapLib.get(id); const cv = document.createElement('canvas'); cv.width = 400; cv.height = 300; cv.getContext('2d').fillStyle='#39c'; cv.getContext('2d').fillRect(0,0,400,300); m.image = {x:0,y:0,w:20,h:15,opacity:.9,has:true}; await MapLib.saveImage(m, cv.toDataURL('image/png')); await MapLib.save(m); MapEd.imgMode = true; renderMapEditor(id); });
  await page.waitForTimeout(300);
  console.log('editor overlay:', !!(await page.$('#v-maps .gridwrap.imgmode .mapimg.editable')), 'handle:', !!(await page.$('.mapimg-handle')), 'imgbar:', await page.$$eval('.imgbar button', es => es.map(e=>e.textContent).join('|')));
  const ov = await (await page.$('#v-maps .mapimg')).boundingBox();
  await page.mouse.move(ov.x+60, ov.y+60); await page.mouse.down(); await page.mouse.move(ov.x+160, ov.y+120, {steps:5}); await page.mouse.up(); await page.waitForTimeout(150);
  console.log('image moved:', await page.evaluate(() => { const m = MapLib.get(location.hash.slice(9)); return m.image.x + ',' + m.image.y; }));
  await page.fill('#v-maps input[placeholder^="ชื่อแผนที่"]', 'แผนที่มีภาพ'); await page.click('#v-maps button:has-text("บันทึก")'); await page.waitForTimeout(200);
  await page.click('#v-maps button:has-text("เผยแพร่")'); await page.waitForTimeout(300);
  const pubState = await page.evaluate(() => { const m = MapLib.get(location.hash.slice(9)); return { published: m.published, hasImage: !!m.image, localHasData: !!(MapLib.loadLocal().find(x=>x.id===m.id).image||{}).data }; });
  console.log('published with image (confirm accepted):', JSON.stringify(pubState));
  // foreign copy strips image
  const copy = await page.evaluate(async () => { const m = MapLib.get(location.hash.slice(9)); const fake = JSON.parse(JSON.stringify(m)); fake.ownerId = 'someone-else'; fake.id = 'foreign1'; const c = await MapLib.copyToMine(fake); return { copied: !!c, image: !!(c && c.image), from: c && c.fromId }; });
  console.log('copy of foreign map strips image:', JSON.stringify(copy));
  // load into room → overlay in room
  const rid = await page.evaluate(() => loadLocalRooms()[0].id);
  await page.goto(url + '#room-' + rid); await page.waitForTimeout(400);
  await page.click('button:has-text("คลังแผนที่")'); await page.waitForTimeout(300);
  await page.click('#modal .gift:has-text("มีภาพประกอบ") button:has-text("โหลด")'); await page.waitForTimeout(500);
  console.log('room overlay:', !!(await page.$('#v-table .gridwrap .mapimg')), 'image in room map:', await page.evaluate(() => !!(Table.room.map.image && Table.room.map.image.data)), 'toggle btn:', !!(await page.$('button:has-text("🖼 ภาพ")')));
  await page.screenshot({ path: path.resolve(__dirname, '90-room-v16.png') });
  console.log('errors', errors);
  await browser.close();
})();
