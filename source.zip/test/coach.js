const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url + '#wizard'); await page.waitForTimeout(400);
  await page.click('#v-create button.primary'); await page.waitForTimeout(200);
  const say = async (label) => { const cls = await page.$eval('.coach', e => e.className); const lines = await page.$$eval('.coach-bubble p', ps => ps.map(p => '  · ' + p.textContent)); console.log('\n[' + label + '] ' + cls + '\n' + lines.join('\n')); };
  const kins = ['day-alves','floran','orcarim'];
  for (const kid of kins){
    await page.evaluate((kid) => { const W = window.__kirana; }, kid);
    // select via card title
    const names = { 'day-alves':'Alves / Day Alves', 'floran':'Floran', 'orcarim':'Orcarim' };
    await page.click(`#v-create .card.pick:has(h3:has-text("${names[kid]}"))`); await page.waitForTimeout(150);
    await say('kin ' + kid);
  }
  // floran path: bg
  await page.click('#v-create .card.pick:has(h3:has-text("Floran"))'); await page.waitForTimeout(150);
  await page.click('.navbtns button.primary'); await page.waitForTimeout(150);
  let cards = await page.$$('#v-create .card.pick'); await cards[0].click(); await page.waitForTimeout(100); await say('bg childhood only');
  cards = await page.$$('#v-create .card.pick'); await cards[cards.length-1].click(); await page.waitForTimeout(100); await say('bg both');
  await page.click('.navbtns button.primary'); await page.waitForTimeout(150); await say('pers empty');
  // set personality: Logic 3, Avoid 2, Cautious 2, Others 1, Compassionate 1, Order 0
  const axes = await page.$$('.axis');
  const pick = async (i, side, v) => { const ax = (await page.$$('.axis'))[i]; if (v===0){ await (await ax.$('.ctl button.small')).click(); } else { const pole = await ax.$(side==='left' ? '.pole.warm' : '.pole.cool'); await (await pole.$(`.lvl button:has-text("${v}")`)).click(); } await page.waitForTimeout(80); };
  await pick(0,'left',3); await say('pers logic3');
  await pick(1,'right',2); await pick(2,'right',2); await pick(3,'left',1); await pick(4,'left',1); await pick(5,'left',0); await say('pers complete');
  await page.click('.navbtns button.primary'); await page.waitForTimeout(150); await say('extra empty');
  await page.click('#v-create button.small.primary'); await page.waitForTimeout(150); await say('extra autofill');
  await page.click('.navbtns button.primary'); await page.waitForTimeout(150); await say('talent none');
  const tal = await page.$$('#v-create .card.pick'); await tal[0].click(); await page.waitForTimeout(150); await say('talent picked');
  await page.evaluate(() => { /* jump to calc */ }); 
  await page.click('.steps button:nth-child(6)'); await page.waitForTimeout(150); await say('calc');
  await page.click('.steps button:nth-child(7)'); await page.waitForTimeout(150); await say('details empty');
  await page.fill('input[placeholder^="ชื่อตัวละคร"]', 'อิรีเน'); await page.waitForTimeout(700); await say('details named');
  await page.click('.steps button:nth-child(8)'); await page.waitForTimeout(150); await say('set none');
  const sets = await page.$$('#v-create .card.pick'); await sets[6].click(); await page.waitForTimeout(150); await say('set vanguard (heavy)');
  await page.click('#v-create .card.pick:has(h3:has-text("The Minstrel"))'); await page.waitForTimeout(150); await say('set minstrel');
  await page.screenshot({ path: 'test/50-coach-set.png' });
  console.log('errors', errors); await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
