// v1.17 (12 พ.ย. 2026):
// 1) ป้าย Comp ของเวทมนตร์: ชี้เมาส์ โฟกัส หรือแตะ แล้วขึ้นคำอธิบายวิธีการร่ายของตัวอักษรที่สกิลนั้นใช้ (ข้อความจาก Skill & Sorceries.md)
// 2) กล่อง Personal Traits ของชีท: ช่องเขียนสิบช่องเป็นหลายบรรทัด กว้างเต็มกล่อง ยืดตามข้อความ
// 3) ข้อ 5 ของรายงาน v1.16 ที่ผู้ใช้ให้แก้ตามเห็นสมควร: ชื่ออังกฤษของ Proficiency สี่ชื่อแก้ตัวสะกดและย้ายคีย์ในตัวละคร
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const shot = async (name) => { await page.evaluate(() => { if (typeof DiceShow !== 'undefined') DiceShow.clear(); }); await page.waitForTimeout(150); await page.screenshot({ path: path.resolve(__dirname, name) }); };
  const pop = () => page.evaluate(() => { const e = document.querySelector('.comppop'); if (!e) return null; return { head: e.querySelector('.pop-h b').textContent, letters: [...e.querySelectorAll('.comp-row')].map(r => r.dataset.comp).join(''), names: [...e.querySelectorAll('.comp-n')].map(x => x.textContent).join('|'), waived: [...e.querySelectorAll('.comp-row.waived')].map(r => r.dataset.comp).join(''), pinned: e.classList.contains('pinned'), close: !!e.querySelector('button'), foot: (e.querySelector('.pop-c') || {}).textContent || '', n: document.querySelectorAll('.comppop').length, inView: (() => { const r = e.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth + 1 && r.top >= 0; })() }; });
  await page.goto(url); await page.waitForTimeout(400);

  // ================= A) ข้อมูล =================
  const data = await page.evaluate(() => { const C = DATA.meta.components || {}; const profs = DATA.knowledge.flatMap(k => Object.values(k.levels).flatMap(L => (L.proficiencies || []).map(p => p.name)));
    return { keys: Object.keys(C).join(''), names: Object.values(C).map(v => v.th + '/' + v.en).join('|'), u: C.U, g: C.G, f: C.F, waiver: JSON.stringify(DATA.meta.componentWaiver), ren: DATA.meta.profRenames,
      newProfs: ['Illusionist', 'Silent Steps', 'Believer of the Divine', 'Silk Weaver'].map(n => profs.includes(n)), oldProfs: ['Ilutionist', 'Silence Foots', 'Beliver of Divine', 'Slik Weaver'].filter(n => profs.includes(n)),
      letters: [compLetters('U G F').join(''), compLetters('G  F').join(''), compLetters('F').join(''), compLetters('').join(''), compLetters('X').join('')],
      comps: [...new Set(DATA.skills.map(s => s.components).filter(Boolean))].every(c => compLetters(c).length === c.split(/\s+/).filter(Boolean).length), nComp: DATA.skills.filter(s => s.components).length,
      kn: [KNOW.alchemy.nameTh, KNOW.melee.nameTh] }; });
  ok('component data', data.keys === 'UGF' && data.names === 'เสียงร่าย/Utterance|ท่วงท่า/Gesture|จิตเพ่ง/Focus', [data.keys, data.names]);
  ok('component text comes from the rule file', /^เวทมนตร์ที่ต้องใช้การเปล่งเสียง/.test(data.u.desc) && /ถูกปิดปาก/.test(data.u.limit) && /มือว่างอย่างน้อยหนึ่งข้าง/.test(data.g.desc) && /ถูกมัด/.test(data.g.limit) && /มองเห็นเป้าหมาย/.test(data.f.desc) && /Confront Saving Throw \(10 DC\)/.test(data.f.limit), [data.u, data.g, data.f]);
  ok('waiver levels', data.waiver === '{"U":2,"G":3}', data.waiver);
  ok('every skill component string is understood', data.comps && data.nComp === 149, [data.comps, data.nComp]);
  ok('compLetters', JSON.stringify(data.letters) === JSON.stringify(['UGF', 'GF', 'F', '', '']), data.letters);
  ok('proficiency names respelled', data.newProfs.every(Boolean) && data.oldProfs.length === 0 && Object.keys(data.ren).length === 4, [data.newProfs, data.oldProfs, data.ren]);
  ok('knowledge Thai names', data.kn[0] === 'การแปรธาตุ' && data.kn[1] === 'ต่อสู้ระยะใกล้', data.kn);

  // ================= B) ย้ายคีย์ Proficiency =================
  const mig = await page.evaluate(() => { const c = { kslots: { a: {id:'aesthetics', prof:'Ilutionist'}, b: {id:'burglary', prof:'Silence Foots'}, c: {id:'lore', prof:'Beliver of Divine', faith:'(Yantra - นอกรีต)'}, d: {id:'scavenging', prof:'Slik Weaver'}, e: {id:'aesthetics', prof:'Painter'}, f: {id:'medical', prof:null}, g: null } };
    const old = { label: profLabel(c.kslots.a), text: profTexts('aesthetics', c.kslots.a).text.slice(0, 20), group: !!profGroupOf('lore', 'Beliver of Divine'), faith: profTexts('lore', c.kslots.c).faithText.slice(0, 12), inc: slotIncomplete(c.kslots.c) };
    const first = migrateNames(c); const second = migrateNames(c);
    return { old, first, second, profs: Object.values(c.kslots).map(s => s && s.prof), faith: c.kslots.c.faith, now: [profNow('Ilutionist'), profNow('Painter'), profNow(null)] }; });
  ok('old proficiency keys still resolve', mig.old.label === 'Illusionist' && /^สามารถเล่นมายากล/.test(mig.old.text) && mig.old.group && mig.old.faith.length > 0 && mig.old.inc === false, mig.old);
  ok('migrateNames moves proficiency keys once', mig.first === true && mig.second === false && JSON.stringify(mig.profs) === JSON.stringify(['Illusionist', 'Silent Steps', 'Believer of the Divine', 'Silk Weaver', 'Painter', null, null]) && mig.faith === '(Yantra - นอกรีต)', mig);
  ok('profNow', mig.now[0] === 'Illusionist' && mig.now[1] === 'Painter' && mig.now[2] === null, mig.now);

  // ================= C) ชีท: Personal Traits =================
  await page.evaluate(() => { const K = window.__kirana; const kin = DATA.kins.find(k => k.id === 'lunaryn');
    K.Store.upsert({ id:'t17', name:'จอมเวททดสอบ', kin:'lunaryn', size:'Medium', childhood:kin.childhood[0].code, adulthood:kin.adulthood[0].code, extra:{INT:5}, personality:{}, choiceStats:[], kslots:{ k1:{id:'aesthetics', prof:'Ilutionist'}, k2:{id:'sorceries', prof:'Attunement'}, k3:{id:'sorceries', prof:'Recaller'} }, skillSlots:{}, grants:['Thunder Judgement','Telepathy','Teleport','Pocket Sand'], knowledge:{}, prof:{}, skills:[], done:true, step:7, starterSet:'The Mage',
      details:{ likes:'ชาร้อนยามเช้า กลิ่นฝนบนดินแห้ง เสียงระฆังของวิหาร หนังสือเก่า แมวจรที่ตามมาถึงหน้าประตู และการเดินตลาดกลางคืนกับเพื่อนร่วมทางที่ไว้ใจได้', dislikes:'คนผิดคำสัญญา', fears:'', want:'อยากเป็นจอมเวทประจำราชสำนัก', need:'', manifest:'', motivation:'ตามหาน้องสาวที่หายไป' } }); });
  await page.goto(url + '#sheet-t17'); await page.waitForTimeout(900);
  const pt = await page.evaluate(() => { const box = document.querySelector('#v-sheet .box[data-k="traits"]'); const z = uiZoom(); const tas = [...box.querySelectorAll('textarea')];
    const m = (ta) => ({ f: ta.dataset.f, w: Math.round(ta.getBoundingClientRect().width / z), h: Math.round(ta.getBoundingClientRect().height / z), clipped: ta.scrollHeight > ta.clientHeight + 2, label: ta.closest('label').firstChild.textContent });
    const next = box.nextElementSibling; const col = box.parentElement;
    return { n: tas.length, inputs: box.querySelectorAll('input').length, boxW: Math.round(box.getBoundingClientRect().width / z), list: tas.map(m), lastInCol: col.lastElementChild === box, overlap: next ? next.getBoundingClientRect().top < box.getBoundingClientRect().bottom - 1 : false, sheetProf: [...document.querySelectorAll('#v-sheet .box[data-k="prof"] .tag')].map(x => x.textContent).join('|') }; });
  const by = Object.fromEntries(pt.list.map(x => [x.f, x]));
  ok('ten trait fields, all multi-line', pt.n === 10 && pt.inputs === 0 && pt.list.map(x => x.f).join(',') === 'likes,dislikes,fears,want,need,manifest,motivation,appearance,backstory,signature', pt.list.map(x => x.f));
  ok('trait fields are wide', pt.list.every(x => x.w >= 300) && by.likes.w >= pt.boxW - 40, [pt.boxW, pt.list.map(x => x.w)]);
  ok('short fields start at two lines, long ones at three', by.fears.h >= 52 && by.fears.h <= 60 && by.appearance.h >= 74 && by.appearance.h <= 82, [by.fears.h, by.appearance.h]);
  ok('a long entry grows instead of clipping', by.likes.h > by.fears.h + 15 && !pt.list.some(x => x.clipped), [by.likes, by.fears]);
  ok('labels sit above their field', by.likes.label === 'Likes ชอบ' && by.manifest.label === 'Manifest' && by.signature.label === 'Signature Look', [by.likes.label, by.manifest.label]);
  ok('layout accounts for the grown box', pt.overlap === false, pt);
  ok('sheet shows the respelled proficiency', /Illusionist/.test(pt.sheetProf) && !/Ilutionist/.test(pt.sheetProf), pt.sheetProf);
  // พิมพ์เพิ่มแล้วช่องยืดทันที และค่าถูกเก็บลงตัวละคร
  await page.fill('#v-sheet .box[data-k="traits"] textarea[data-f="fears"]', 'ความมืดสนิทใต้ดิน\nการถูกทิ้งไว้ข้างหลัง\nเสียงโซ่ลากพื้น\nและกระจกที่ไม่สะท้อนเงา');
  await page.evaluate(() => document.querySelector('#v-sheet .box[data-k="traits"] textarea[data-f="fears"]').blur()); await page.waitForTimeout(250);
  const grow = await page.evaluate(() => { const ta = document.querySelector('#v-sheet .box[data-k="traits"] textarea[data-f="fears"]'); const c = window.__kirana.Store.get('t17'); return { h: Math.round(ta.getBoundingClientRect().height / uiZoom()), clipped: ta.scrollHeight > ta.clientHeight + 2, saved: c.details.fears, kslot: c.kslots.k1.prof }; });
  ok('typing grows the field and saves line breaks', grow.h >= 90 && !grow.clipped && grow.saved.split('\n').length === 4, grow);
  ok('sheet open migrated the proficiency key', grow.kslot === 'Illusionist', grow.kslot);
  await page.evaluate(() => document.querySelector('#v-sheet .box[data-k="traits"]').scrollIntoView({ block: 'start' })); await page.waitForTimeout(200);
  await shot('160-personal-traits-v117.png');
  await page.evaluate(() => window.scrollTo(0, 0)); await page.waitForTimeout(150);

  // ================= D) คัมภีร์: ป้าย Comp ชี้แล้วอธิบาย =================
  await page.click('.hud-btn[title="คัมภีร์"]'); await page.waitForTimeout(300);
  const pick = async (en) => { await page.evaluate((en) => { const b = [...document.querySelectorAll('.book .toc-i')].find(x => x.textContent.includes(en)); b.click(); }, en); await page.waitForTimeout(250); };
  await pick('Thunder Judgement');
  const tagTxt = await page.$eval('.book .detail .comptag', e => e.textContent + '|' + e.tabIndex + '|' + e.getAttribute('role'));
  ok('book shows a focusable Comp tag', tagTxt === 'Comp G F|0|button', tagTxt);
  ok('no popup before pointing', (await pop()) === null);
  await page.hover('.book .detail .comptag'); await page.waitForTimeout(250);
  const h1 = await pop();
  ok('hover opens the explanation for this skill only', h1 && h1.head === 'Comp G F' && h1.letters === 'GF' && h1.names === 'ท่วงท่า (Gesture)|จิตเพ่ง (Focus)' && !h1.pinned && !h1.close && h1.n === 1 && h1.inView, h1);
  ok('character with Sorceries level 2 still needs G', h1 && h1.waived === '' && /ระดับ 3 ขึ้นไป ร่ายได้โดยไม่ต้องใช้ G/.test(h1.foot), h1);
  await shot('161-comp-hover-v117.png');
  await page.mouse.move(40, 700); await page.waitForTimeout(250);
  ok('moving away closes it', (await pop()) === null);
  // คลิก = ปักไว้ มีปุ่มปิด กดที่อื่นแล้วหาย
  await page.click('.book .detail .comptag'); await page.waitForTimeout(250);
  const p1 = await pop();
  ok('click pins the explanation', p1 && p1.pinned && p1.close && p1.letters === 'GF', p1);
  await page.mouse.move(40, 700); await page.waitForTimeout(250);
  ok('pinned stays when the mouse leaves', !!(await pop()));
  await page.mouse.click(40, 700); await page.waitForTimeout(250);
  ok('click elsewhere closes the pinned one', (await pop()) === null);
  // แป้นพิมพ์: โฟกัสเปิด Escape ปิด
  await page.focus('.book .detail .comptag'); await page.waitForTimeout(200);
  ok('keyboard focus opens it', !!(await pop()));
  await page.keyboard.press('Escape'); await page.waitForTimeout(150);
  ok('Escape closes it', (await pop()) === null);
  // สกิลที่มี F ตัวเดียว และสกิลที่ไม่มี Comp
  await pick('Telepathy'); await page.hover('.book .detail .comptag'); await page.waitForTimeout(250);
  const h2 = await pop();
  ok('single component skill', h2 && h2.head === 'Comp F' && h2.letters === 'F' && h2.foot === '', h2);
  await page.mouse.move(40, 700); await page.waitForTimeout(200);
  await pick('Pocket Sand');
  ok('skills without components have no Comp tag', (await page.$('.book .detail .comptag')) === null);
  // ป้ายหายเพราะหน้าวาดใหม่ ป๊อปอัปต้องหายตาม
  await pick('Teleport'); await page.hover('.book .detail .comptag'); await page.waitForTimeout(200);
  await pick('Pocket Sand'); await page.waitForTimeout(450);
  ok('popup disappears with its tag', (await pop()) === null);
  await page.click('.hud-btn[title="คัมภีร์"]'); await page.waitForTimeout(150);

  // ระดับ Sorceries 2 ขึ้นไป: U ไม่ต้องใช้แล้ว · ระดับ 3: G ด้วย
  const wv = await page.evaluate(() => { const mk = (lv) => { const el = compTag('U G F', lv); document.body.append(el); showComp('U G F', el, { lv }); const e = document.querySelector('.comppop'); const out = { waived: [...e.querySelectorAll('.comp-row.waived')].map(r => r.dataset.comp).join(''), tags: [...e.querySelectorAll('.comp-row .tag')].map(t => t.textContent), foot: e.querySelector('.pop-c').textContent }; hideComp(); el.remove(); return out; }; return { l0: mk(0), l2: mk(2), l3: mk(3), none: mk(null), lvChar: sorceryLv(window.__kirana.Store.get('t17')) }; });
  ok('waiver by Sorceries level', wv.l0.waived === '' && wv.l2.waived === 'U' && wv.l3.waived === 'UG' && wv.none.waived === '' && wv.lvChar === 2 && /ไม่ต้องใช้แล้ว \(Sorceries ระดับ 2\)/.test(wv.l2.tags[0] || ''), wv);
  ok('footer lists both waivers', /ระดับ 2 ขึ้นไป ร่ายได้โดยไม่ต้องใช้ U · .*ระดับ 3 ขึ้นไป ร่ายได้โดยไม่ต้องใช้ G/.test(wv.l0.foot), wv.l0.foot);

  // ================= E) การ์ดสกิลในวิซาร์ด ร้าน IP และแผงหมาก =================
  const card = await page.evaluate(() => { let toggled = 0; const el = skillCard(SKILL_BY_NAME['Thunder Judgement'], false, () => { toggled++; }, false); document.body.append(el); const t = el.querySelector('.comptag'); t.click(); const pinned = !!document.querySelector('.comppop.pinned'); hideComp(); el.click(); const r = { has: !!t, text: t.textContent, pinned, toggledByTag: toggled - 1, toggledByCard: toggled }; el.remove(); return r; });
  ok('wizard card: Comp tag opens the popup without selecting the card', card.has && card.text === 'Comp G F' && card.pinned && card.toggledByTag === 0 && card.toggledByCard === 1, card);
  await page.evaluate(() => { const c = window.__kirana.Store.get('t17'); c.current.ip = 40; IpUI.tab = 'skill'; IpUI.q = 'Thornbound'; openIpShop(c, () => {}); }); await page.waitForTimeout(350);
  await page.hover('.iplist .iprow .comptag'); await page.waitForTimeout(250);
  const ipPop = await pop();
  ok('ip shop row has the Comp tag with the explanation', ipPop && ipPop.letters === 'GF' && ipPop.inView, ipPop);
  await shot('162-comp-ipshop-v117.png');
  await page.mouse.move(40, 40); await page.waitForTimeout(150);
  await page.evaluate(() => modal(null)); await page.waitForTimeout(150);
  // จอสัมผัส: แตะที่ป้ายแล้วปักไว้ (ไม่มีการชี้)
  const tap = await page.evaluate(() => { const el = compTag('U G', 0); document.body.append(el); el.dispatchEvent(new MouseEvent('click', { bubbles: true })); const e = document.querySelector('.comppop'); const r = { open: !!e, pinned: !!(e && e.classList.contains('pinned')), letters: e ? [...e.querySelectorAll('.comp-row')].map(x => x.dataset.comp).join('') : '' }; el.dispatchEvent(new MouseEvent('click', { bubbles: true })); r.closedBySecondTap = !document.querySelector('.comppop'); el.remove(); return r; });
  ok('tap pins, second tap closes', tap.open && tap.pinned && tap.letters === 'UG' && tap.closedBySecondTap, tap);
  // ภาพสอน cost ขึ้นชื่อไทยก่อน
  const fig = await page.evaluate(() => { const el = FIGS.cost(); return { b: el.querySelector('.fig-card b').textContent, dim: el.querySelector('.fig-card .dim').textContent }; });
  ok('tutorial cost figure Thai-first', /^[฀-๿]/.test(fig.b) && /^[A-Za-z]/.test(fig.dim), fig);

  // ================= F) วิซาร์ด: ช่องนิสัยส่วนตัวเป็นหลายบรรทัด =================
  await page.evaluate(() => { const c = window.__kirana.Store.get('t17'); startWizard(c); W.step = STEP_DEFS.findIndex(s => s.key === 'details'); }); await page.goto(url + '#wizard'); await page.waitForTimeout(600);
  const wz = await page.evaluate(() => { const card = [...document.querySelectorAll('#v-create .card')].find(x => /Personal Traits/.test((x.querySelector('h4') || {}).textContent || '')); if (!card) return null; return { tas: card.querySelectorAll('textarea').length, short: card.querySelectorAll('textarea.short').length, inputs: card.querySelectorAll('input').length, fears: [...card.querySelectorAll('textarea')].map(t => t.value).find(v => /โซ่ลากพื้น/.test(v)) || '' }; });
  ok('wizard personal traits are text areas that keep line breaks', wz && wz.tas === 7 && wz.short === 6 && wz.inputs === 0 && wz.fears.split('\n').length === 4, wz);

  console.log(`checks: ${pass} passed, ${fail} failed`);
  console.log('errors', errors);
  await browser.close();
  if (fail || errors.length) process.exit(1);
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
