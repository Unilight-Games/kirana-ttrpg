// v1.27 ส่วนที่สอง (ร่าง · Non สั่ง 16 พ.ย. 2026): "ทำให้ผมสามารถแก้ข้อมูลไอเทม และทักษะได้ตั้งแต่ในหน้าคลังเลย"
//  A) รหัสรายการและการใช้ผล  B) คลังไอเทม: แก้ คืนต้นฉบับ เพิ่ม ลบ  C) คลังทักษะ: แก้ เพิ่ม  D) หน้าผู้พัฒนา ส่งออก นำเข้า
//  E) ตัวกรองข้อมูลจากฐานข้อมูล  F) คนที่ไม่ใช่ผู้พัฒนาไม่เห็นปุ่ม  G) จอมือถือ  H) ข้อความบนหน้า  I) เงื่อนไข STR สามแบบจอ
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  const shot = (n) => path.resolve(__dirname, n);
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail).slice(0, 1500) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  await page.goto(url); await wait(500);

  // ================= A) รหัสและการใช้ผล =================
  const A1 = await page.evaluate(() => ({ ik: CE.items.keys.length, in: DATA.items.length, iu: new Set(CE.items.keys).size, sk: CE.skills.keys.length, sn: DATA.skills.length, su: new Set(CE.skills.keys).size,
    can: CatalogEdit.canEdit(), wild: CE.skills.keys.filter(k => /Wild Sense/.test(k)), key0: ceKeyOf(DATA.items[0]), json: JSON.stringify(DATA.items[0]).includes('__ceKey') }));
  ok('A: every item and skill gets a unique key that never leaks into JSON', A1.ik === A1.in && A1.iu === A1.ik && A1.sk === A1.sn && A1.su === A1.sk && A1.wild.length === 2 && A1.key0 && !A1.json, A1);
  ok('A: the file opened on this computer can edit', A1.can === true, A1);

  // ================= B) คลังไอเทม =================
  await page.goto(url + '#items'); await wait(400);
  const B0 = await page.evaluate(() => ({ bar: !!document.querySelector('#v-items .cedit-bar'), cards: document.querySelectorAll('#v-items .cx-it').length, btns: document.querySelectorAll('#v-items .cx-it .cedit-btn').length }));
  ok('B: items page shows the back-office bar and an edit button on every card', B0.bar && B0.cards > 50 && B0.btns === B0.cards, B0);
  await page.fill('#v-items input[type=search]', 'Battle Axe'); await wait(250);
  await page.click('#v-items .cx-it:has-text("ขวานศึก") .cedit-btn'); await wait(250);
  const B1 = await page.evaluate(() => ({ title: document.querySelector('#modal .cedit h3').textContent, name: document.querySelector('[data-ce="name"]').value, cat: document.querySelector('[data-ce="cat"]').value, tier: document.querySelector('[data-ce="tier"]').value, tierLabel: document.querySelector('[data-ce="tier"]').options[0].textContent, eff: document.querySelector('[data-ce="effect"]').value, prev: !!document.querySelector('#modal .cedit-preview .cx-it'), modalOpen: !document.querySelector('#modal').classList.contains('hidden') }));
  ok('B: the edit button opens the item form, not the details window', B1.modalOpen && /แก้ไอเทม ขวานศึก/.test(B1.title) && B1.name === 'ขวานศึก (Battle Axe)' && B1.cat === 'อาวุธประชิด' && B1.tier === '' && /Tier 3/.test(B1.tierLabel) && /3 PDMG/.test(B1.eff) && B1.prev, B1);
  await page.fill('[data-ce="effect"]', '(ต้องการ STR 14) 4 PDMG (Slashing), Guard Break, Cleave · ชนิด: อาวุธขวานสองมือ'); await page.fill('[data-ce="price"]', '24 เกรฟ'); await wait(150);
  const B2a = await page.evaluate(() => [...document.querySelectorAll('#modal .cedit-preview .tag')].map(t => t.textContent));
  await page.screenshot({ path: shot('280-item-editor-v127.png') });
  await page.click('#modal .cedit-save'); await wait(400);
  const B2 = await page.evaluate(() => { const it = DATA.items.find(x => x.name === 'ขวานศึก (Battle Axe)'); const cat = itemCatalog().find(x => x.name === 'ขวานศึก (Battle Axe)'); const st = JSON.parse(localStorage.getItem('kirana.codex.items.v1') || '{}');
    return { eff: it.effect, price: it.price, cat: cat && cat.effect, n: (st.entries || []).length, op: st.entries && JSON.parse(st.entries[0]).op, closed: document.querySelector('#modal').classList.contains('hidden'), mark: [...document.querySelectorAll('#v-items .cx-it')].filter(c => /ขวานศึก/.test(c.textContent)).map(c => (c.querySelector('.cedit-tag') || {}).textContent)[0], log: (st.log || [])[0] }; });
  ok('B: preview tags follow the typed effect', B2a.includes('4 PDMG') && B2a.includes('Tier 3') && B2a.includes('24 เกรฟ'), B2a);
  ok('B: saving updates the catalog everywhere and marks the card', /4 PDMG/.test(B2.eff) && B2.price === '24 เกรฟ' && /4 PDMG/.test(B2.cat) && B2.n === 1 && B2.op === 'edit' && B2.closed && B2.mark === 'แก้จากหลังบ้าน' && /แก้ไอเทม ขวานศึก/.test(B2.log.what), B2);
  // หน้าต่างรายละเอียดมีปุ่มแก้ · เปลี่ยนชื่อไอเทมที่ชุดเริ่มต้นอ้างอยู่ขึ้นคำเตือน
  await page.click('#v-items .cx-it:has-text("ขวานศึก")'); await wait(200);
  const B3 = await page.evaluate(() => !!document.querySelector('#modal .cedit-open'));
  await page.evaluate(() => modal(null));
  const setItem = await page.evaluate(() => { const n = cleanAltName(DATA.sets.sets[0].items[0].name).replace(/\s*×\s*\d+/, '').trim(); return DATA.items.some(x => x.name === n) ? n : null; });
  await page.evaluate((n) => ceItemEditor(DATA.items.find(x => x.name === n)), setItem); await wait(200);
  await page.fill('[data-ce="name"]', 'ชื่อใหม่ทดสอบ (Renamed)'); await wait(350);
  const B4 = await page.evaluate(() => document.querySelector('#modal .le-warn') ? document.querySelector('#modal .le-warn').textContent : '');
  await page.evaluate(() => { const b = [...document.querySelectorAll('#modal .box > .row button')].pop(); b.click(); }); await wait(200);
  const B4b = await page.evaluate(() => ({ closed: document.querySelector('#modal').classList.contains('hidden'), n: CatalogEdit.effective('items').entries.length }));
  ok('B: item details window offers the edit button to the developer', B3, B3);
  ok('B: renaming an item the starter sets use warns before saving, closing asks and keeps data', !!setItem && /ชุดเริ่มต้น/.test(B4) && B4b.closed && B4b.n === 1, { setItem, B4, B4b });
  // คืนต้นฉบับ
  await page.evaluate(() => ceItemEditor(DATA.items.find(x => x.name === 'ขวานศึก (Battle Axe)'))); await wait(200);
  await page.click('#modal .cedit-revert'); await wait(400);
  const B5 = await page.evaluate(() => ({ eff: DATA.items.find(x => x.name === 'ขวานศึก (Battle Axe)').effect, n: (CatalogEdit.effective('items') || {entries: []}).entries.length }));
  ok('B: revert brings back the Item All text', /3 PDMG/.test(B5.eff) && !/Cleave/.test(B5.eff) && B5.n === 0, B5);
  // เพิ่มและลบ
  await page.fill('#v-items input[type=search]', ''); await wait(150);
  await page.click('#v-items .cx-tab[data-fam="weapon"]'); await wait(300);
  await page.click('#v-items .cedit-add'); await wait(200);
  const B6a = await page.evaluate(() => document.querySelector('[data-ce="cat"]').value);
  await page.fill('[data-ce="name"]', 'ขวานทดสอบ (Test Axe)'); await page.selectOption('[data-ce="tier"]', '2'); await page.fill('[data-ce="effect"]', '2 PDMG (Slashing), Guard Break'); await page.fill('[data-ce="weight"]', '1.5'); await page.fill('[data-ce="price"]', '9 เกรฟ');
  await page.click('#modal .cedit-save'); await wait(400);
  const B6 = await page.evaluate(() => { const it = DATA.items.find(x => x.name === 'ขวานทดสอบ (Test Axe)'); const sec = [...document.querySelectorAll('#v-items .cx-group')].find(s => s.dataset.cat === 'อาวุธประชิด');
    return { key: ceKeyOf(it), tier: it.tier, w: it.weight, src: it.src, inCat: !!itemCatalog().find(x => x.name === 'ขวานทดสอบ (Test Axe)'), npc: !!npcCatalogFind('ขวานทดสอบ (Test Axe)'), card: !!(sec && [...sec.querySelectorAll('.cx-it')].find(c => /ขวานทดสอบ/.test(c.textContent) && /เพิ่มจากหลังบ้าน/.test(c.textContent))) }; });
  ok('B: new item starts in the open family and shows up in its Tier group', B6a === 'อาวุธประชิด' && /^new:/.test(B6.key) && B6.tier === 2 && B6.w === 1.5 && B6.src === 'หลังบ้าน' && B6.inCat && B6.npc && B6.card, { B6a, B6 });
  await page.click('#v-items .cedit-add'); await wait(200);
  await page.fill('[data-ce="name"]', 'ขวานศึก (Battle Axe)'); await page.click('#modal .cedit-save'); await wait(300);
  const B7 = await page.evaluate(() => ({ open: !document.querySelector('#modal').classList.contains('hidden'), n: DATA.items.filter(x => x.name === 'ขวานศึก (Battle Axe)').length }));
  ok('B: a duplicate item name is refused', B7.open && B7.n === 1, B7);
  await page.evaluate(() => modal(null));
  await page.evaluate(() => ceItemEditor(DATA.items.find(x => x.name === 'ขวานทดสอบ (Test Axe)'))); await wait(200);
  await page.click('#modal .cedit-del'); await wait(400);
  ok('B: deleting an added item removes it', await page.evaluate(() => !DATA.items.some(x => x.name === 'ขวานทดสอบ (Test Axe)') && !itemCatalog().some(x => x.name === 'ขวานทดสอบ (Test Axe)')));

  // ================= C) คลังทักษะ =================
  await page.goto(url + '#skills-sorcery'); await wait(400);
  const C0 = await page.evaluate(() => ({ bar: !!document.querySelector('#v-skills .cedit-bar'), cards: document.querySelectorAll('#v-skills .cx-sk').length, btns: document.querySelectorAll('#v-skills .cx-sk .cedit-btn').length, ref: SKILL_BY_NAME['Mind Trick'] === DATA.skills.find(s => s.nameEn === 'Mind Trick') }));
  ok('C: skills page shows the bar and an edit button on every card', C0.bar && C0.cards > 50 && C0.btns === C0.cards && C0.ref, C0);
  await page.click('#v-skills .cx-sk[data-name="Mind Trick"] .cedit-btn'); await wait(250);
  const C1 = await page.evaluate(() => ({ en: document.querySelector('[data-ce="nameEn"]').disabled, th: document.querySelector('[data-ce="nameTh"]').value, cost: document.querySelector('[data-ce="cost"]').value, ip: document.querySelector('[data-ce="ipCost"]').value }));
  await page.fill('[data-ce="effect"]', 'คุณทำการทอย INT Clash PER กับเป้าหมาย หากสำเร็จ เป้าหมายติด Disadvantage ในการทอย PER Check ครั้งถัดไป'); await page.fill('[data-ce="cost"]', '3 MP'); await page.fill('[data-ce="ipCost"]', '2'); await wait(150);
  await page.screenshot({ path: shot('281-skill-editor-v127.png') });
  await page.click('#modal .cedit-save'); await wait(400);
  const C2 = await page.evaluate(() => { const sk = SKILL_BY_NAME['Mind Trick']; return { same: sk === DATA.skills.find(s => s.nameEn === 'Mind Trick'), cost: sk.cost, ip: sk.ipCost + '|' + sk.ip, eff: sk.effect, card: (document.querySelector('#v-skills .cx-sk[data-name="Mind Trick"]') || {}).textContent || '' }; });
  ok('C: base skill keeps its English name, and saving updates the sheet lookup in place', C1.en && C1.th === 'มายาจิดลวง' && C1.cost === '2 MP' && C1.ip === '1' && C2.same && C2.cost === '3 MP' && C2.ip === '2|2 IP' && /ครั้งถัดไป$/.test(C2.eff) && /แก้จากหลังบ้าน/.test(C2.card) && /3 MP/.test(C2.card), { C1, C2 });
  await page.goto(url + '#skills-martial'); await wait(300);
  await page.click('#v-skills .cedit-add'); await wait(200);
  const C3a = await page.evaluate(() => ({ cat: document.querySelector('[data-ce="category"]').value, en: document.querySelector('[data-ce="nameEn"]').disabled }));
  await page.fill('[data-ce="nameEn"]', 'Test Stance'); await page.fill('[data-ce="nameTh"]', 'ท่าทดสอบ'); await page.fill('[data-ce="subcategory"]', 'Stance'); await page.fill('[data-ce="type"]', 'Swift Action'); await page.fill('[data-ce="ipCost"]', '3'); await page.fill('[data-ce="effect"]', 'เมื่อตั้งท่า ได้รับ +1 Parry Dice จนจบเทิร์น');
  await page.click('#modal .cedit-save'); await wait(400);
  const C3 = await page.evaluate(() => { const sk = SKILL_BY_NAME['Test Stance']; return { ok: !!sk, key: ceKeyOf(sk), tags: sk && sk.tags, lc: SKILL_LC['test stance'], card: !!document.querySelector('#v-skills .cx-sk[data-name="Test Stance"]'), shop: DATA.skills.filter(s => s.ipCost != null).some(s => s.nameEn === 'Test Stance') }; });
  ok('C: a new skill lands in its category, the sheet lookup and the IP shop list', C3a.cat === 'Martial' && !C3a.en && C3.ok && /^new:/.test(C3.key) && C3.tags.includes('Stance') && C3.lc === 'Test Stance' && C3.card && C3.shop, { C3a, C3 });

  // ================= D) หน้าผู้พัฒนา =================
  await page.goto(url + '#dev'); await wait(400);
  const D1 = await page.evaluate(() => ({ card: !!document.querySelector('.cedit-dev'), heads: [...document.querySelectorAll('.cedit-dev h3')].map(x => x.textContent), items: [...document.querySelectorAll('.cedit-list[data-kind="skills"] li')].map(x => x.textContent) }));
  ok('D: developer page lists edited and added entries for both catalogs', D1.card && D1.heads.includes('ไอเทมที่แก้ 0 · เพิ่ม 0') && D1.heads.includes('ทักษะที่แก้ 1 · เพิ่ม 1') && D1.items.some(x => /มายาจิดลวง/.test(x)) && D1.items.some(x => /ท่าทดสอบ/.test(x) && /เพิ่มใหม่/.test(x)), D1);
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('.cedit-export')]);
  const exp = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
  ok('D: export holds both catalogs', dl.suggestedFilename() === 'kirana-items-skills-edits.json' && exp.skills.entries.length === 2 && exp.items.entries.length === 0, { name: dl.suggestedFilename(), n: exp.skills.entries.length });
  const imp = { items: { entries: [JSON.stringify({ key: 'ขวานศึก (Battle Axe)', op: 'edit', data: Object.assign({}, await page.evaluate(() => CE.items.base[CE.items.keys.indexOf('ขวานศึก (Battle Axe)')]), { price: '30 เกรฟ' }) })] }, skills: exp.skills };
  const tmp = path.resolve(__dirname, 'tmp-import-v127b.json'); fs.writeFileSync(tmp, JSON.stringify(imp));
  await page.setInputFiles('.cedit-dev input[type=file]', tmp); await wait(600); fs.unlinkSync(tmp);
  const D2 = await page.evaluate(() => ({ price: DATA.items.find(x => x.name === 'ขวานศึก (Battle Axe)').price, sk: !!SKILL_BY_NAME['Test Stance'] }));
  ok('D: import replaces the edits from a file', D2.price === '30 เกรฟ' && D2.sk, D2);
  await page.screenshot({ path: shot('282-catalog-dev-card-v127.png'), fullPage: false });

  // ================= E) ตัวกรองข้อมูล =================
  const E1 = await page.evaluate(() => { const base = CE.items.base[0];
    const d = ceSanitize('items', { entries: [JSON.stringify({ key: base.name, op: 'edit', data: Object.assign({}, base, { cat: 'ปลอม', effect: 'x'.repeat(9000), weight: -5, tier: 9 }) }), JSON.stringify({ key: 'ไม่มีจริง', op: 'edit', data: base }), JSON.stringify({ key: 'new:BAD KEY', op: 'add', data: base }), { key: 'new:abcd1234', op: 'add', data: { name: '', cat: 'โล่' } }, 'not json', JSON.stringify({ key: base.name, op: 'edit', data: base })], log: 'x' });
    const s = ceSanitize('skills', { entries: [JSON.stringify({ key: CE.skills.keys[0], op: 'edit', data: Object.assign({}, CE.skills.base[0], { nameEn: 'Hacked', ipCost: 500, tier: 'God', extra: ['a', 5, null] }) })] });
    return { cats: CE_ITEM_CATS, n: d.entries.length, e0: d.entries[0] && { cat: d.entries[0].data.cat, len: d.entries[0].data.effect.length, w: d.entries[0].data.weight, tier: d.entries[0].data.tier }, orphan: d.entries[1] && d.entries[1].orphan, s: s.entries[0].data }; });
  ok('E: untrusted entries are typed and capped, bad keys dropped, unknown originals flagged', E1.n === 2 && E1.e0.cat === E1.cats[0] && E1.e0.len === 4000 && E1.e0.tier === undefined && E1.orphan === true && E1.s.nameEn !== 'Hacked' && E1.s.ipCost === undefined && E1.s.tier === undefined && E1.s.extra.join() === 'a,5', E1);

  // ================= F) คนที่ไม่ใช่ผู้พัฒนา =================
  const F1 = await page.evaluate(() => { const keep = { b: Store.backend, d: Store.isDevUid }; Store.backend = 'firebase'; Store.isDevUid = false; location.hash = '#items';
    return new Promise(res => setTimeout(() => { const r = { can: CatalogEdit.canEdit(), btn: document.querySelectorAll('#v-items .cedit-btn').length, bar: !!document.querySelector('#v-items .cedit-bar'), price: DATA.items.find(x => x.name === 'ขวานศึก (Battle Axe)').price };
      Store.backend = keep.b; Store.isDevUid = keep.d; res(r); }, 400)); });
  ok('F: other visitors see no edit buttons and get the base data when no web copy exists', !F1.can && F1.btn === 0 && !F1.bar, F1);

  // ================= G) จอมือถือ =================
  const m = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true });
  m.on('pageerror', e => errors.push('MOBILE ' + e.message)); m.on('dialog', d => d.accept());
  await m.goto(url + '#skills-sorcery'); await m.waitForTimeout(500);
  await m.evaluate(() => ceSkillEditor(SKILL_BY_NAME['Mind Trick'])); await m.waitForTimeout(300);
  const G1 = await m.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, box: Math.round(document.querySelector('#modal .box').getBoundingClientRect().right) }));
  ok('G: the editor fits a phone screen', G1.sw <= G1.cw + 1 && G1.box <= G1.cw + 1, G1);
  await m.screenshot({ path: shot('283-skill-editor-mobile-v127.png') });
  await m.close();

  // ================= H) ข้อความบนหน้าจอ =================
  const src = fs.readFileSync(path.resolve(__dirname, '../src/catalogedit.js'), 'utf8');
  const strs = [...src.matchAll(/'([^'\\\n]*[฀-๿][^'\\\n]*)'|`([^`\\\n]*[฀-๿][^`\\\n]*)`/g)].map(x => x[1] || x[2]);
  const dash = strs.filter(s => /\s[—–-]\s|—|–|--/.test(s)); const anti = strs.filter(s => /ไม่ใช่.*แต่|ไม่ได้.*แต่|เหมือน.*แต่จริง/.test(s));
  ok('H: Thai UI strings use no dash joints or not-X-but-Y frames', strs.length > 40 && dash.length === 0 && anti.length === 0, { n: strs.length, dash, anti });

  // ================= I) เงื่อนไข STR สามแบบ (Non: "แก้ไขตามเห็นสมควรแล้วอัปขึ้นได้เลยครับ") =================
  const I1 = await page.evaluate(() => {
    const axe = DATA.items.find(x => /Battle Axe/.test(x.name));
    const set = (DATA.sets.sets || []).find(s => (s.items || []).some(i => /Arming Sword/.test(i.name)));
    const fromSet = set ? chosenSetItems({ starterPicks: {} }, set).find(i => /Arming Sword/.test(i.name)) : null;
    const board = weaponBoard({ equip: { weapon1: fromSet } }, { raw: { STR: 6 } });
    const tagTexts = itemStatTags(axe).filter(Boolean).map(t => t.textContent);
    return {
      a: weaponStrNeed('(STR 12: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage) 2 PDMG'),
      b: weaponStrNeed('(ต้องการ STR 14) 3 PDMG (Slashing), Guard Break'),
      c: weaponStrNeed('2 PDMG (Slashing/Piercing), Rip · ใช้คู่โล่ · ต้องการ STR 8'),
      d: weaponStrNeed('ทักษะนี้ต้องการ STR 12 ขึ้นไป'),
      e: weaponStrNeed('2 PDMG · ต้องการ STR 8 ครั้งแรก'),
      p1: weaponPropsText('(ต้องการ STR 14) 3 PDMG (Slashing), Guard Break'),
      p2: weaponPropsText('2 PDMG (Piercing), Reach · ต้องการ STR 12'),
      p3: weaponPropsText('2 PDMG · ต้องการ STR 8 · Rip'),
      s1: weaponStrShort('(ต้องการ STR 14) 3 PDMG', { raw: { STR: 13 } }), s2: weaponStrShort('(ต้องการ STR 14) 3 PDMG', { raw: { STR: 14 } }),
      axeTag: tagTexts.includes('STR 14'),
      n17: DATA.items.filter(x => /\(ต้องการ STR/.test(x.effect || '') && weaponStrNeed(x.effect) > 0).length,
      nAll: DATA.items.filter(x => weaponStrNeed(x.effect) > 0).length,
      setEff: fromSet && fromSet.effect, setNeed: fromSet ? weaponStrNeed(fromSet.effect) : -1,
      badge: (board.querySelector('.strreq.short') || {}).textContent || '',
    };
  });
  ok('I: STR condition reads all three formats and nothing else', I1.a === 12 && I1.b === 14 && I1.c === 8 && I1.d === 0 && I1.e === 0 && I1.p1 === '3 PDMG (Slashing), Guard Break' && I1.p2 === '2 PDMG (Piercing), Reach' && I1.p3 === '2 PDMG · Rip' && I1.s1 === true && I1.s2 === false && I1.axeTag && I1.n17 === 17 && I1.nAll === 36, I1);
  ok('I: a starter-set weapon shows the STR warning on the weapon belt', I1.setNeed === 8 && /STR 8 ไม่ถึง/.test(I1.badge), I1);

  ok('no page errors', errors.length === 0, errors);
  console.log(`v1.27b: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
