// v1.25 (15 พ.ย. 2026) Non สั่งสี่ข้อ + หนึ่งข้อระหว่างทำ
//  A) Durability ของอาวุธ โล่ และเครื่องสวมใส่ (3/6/9 · พัง = Armor PDMG Parry Dice ครึ่งหนึ่งปัดลง · ซ่อมของพังได้ 1/1 ถาวร)
//  B) สภาวะของตัวละครขึ้นในปุ่มลอยข้างจอของชีท อ่านจากหมากบนโต๊ะ GM คุม
//  C) NPC ใส่ค่าพลังดัดแปลง (Modified) ได้ และคิด Might Sight Passive PER Reflex ด้วยสูตรเดียวกับผู้เล่น
//  D) ยิงเกินระยะแม่น −1 CV ต่อทุก 1 ม.
//  E) เกราะรองขึ้นชนิดที่กันเสมอ หลายชั้นรวมเกราะรองแยกตามชนิด (ไม่รวมกับ A)
//     v1.25.2: Non เคาะ โดนชนิดในวงเล็บหักเกราะหลักบวกเกราะรอง ชนิดอื่นหักเกราะหลักอย่างเดียว (บรรทัดยอดที่หักจริง)
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  let dialogs = []; page.on('dialog', d => { dialogs.push(d.message()); d.accept(); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  const SHOTS = process.argv[2] || '';
  await page.goto(url); await wait(400);

  // ================= E) ชนิดของเกราะรอง =================
  const E = await page.evaluate(() => {
    const t = (layers, belt) => armorText(layers.map(parseArmor), belt || 0);
    return {
      gamb: t(['Armor 1/2 (Blunt)']), chainGamb: t(['Armor 3/4 (Slashing)', 'Armor 1/2 (Blunt)']), plate: t(['Armor 3/1 (Piercing/Blunt)']),
      bracer: t(['Armor 1 / 0']), silk: t(['Armor 0/1 (Sorceries Resistance)']), slash: t(['Armor 2/3 (Slash)']), untyped: t(['Armor 2/3']),
      note: t(['Armor 1 / 0 (ป้องกันเฉพาะส่วนหลังและไหล่)']), belt: t(['Armor 1/2 (Blunt)'], 3), none: t([])
    }; });
  ok('E: single layer shows its type, Blunt included', E.gamb === '1/2 (Blunt)', E);
  ok('E: mixed layers count each type separately', E.chainGamb === '4/4 (Slashing) · 2 (Blunt)', E.chainGamb);
  ok('E: weakness types grouped', E.plate === '3/1 (Piercing/Blunt)', E.plate);
  ok('E: no secondary armor shows A only', E.bracer === '1' && E.note === '1', E);
  ok('E: sorcery resistance and abbreviations', E.silk === '0/1 (Sorceries Resistance)' && E.slash === '2/3 (Slashing)' && E.untyped === '2/3 (Blunt)', E);
  ok('E: chain belt and empty part', E.belt === '3/2 (Blunt)' && E.none === '', E);
  // ชีทเก่าที่ช่องเกราะเป็นค่าอัตโนมัติรูปแบบเดิม ได้ชนิดครบตอนเปิด ส่วนที่ผู้เล่นจดเองไม่ถูกแตะ
  await page.evaluate(() => { const mk = (id, armor) => Object.assign(newChar(), { id, name: id, kin: 'solrin', size: 'Medium', done: true, step: 7, starterSet: 'The Sailor', armorAuto: true, armor,
      equip: { chestIn: { name: 'เสื้อบุเกราะแกมเบสัน (Field Gambeson)', effect: 'ชั้นใน Armor 1/2 (Blunt)', weight: 3.5 }, chestOut: { name: 'เกราะโซ่ถัก (Chain Hauberk)', effect: 'Armor 3/4 (Slashing)', weight: 9 } }, inventory: [] });
    Store.upsert(mk('armold', { torso: '4/6 (Slashing)' })); Store.upsert(mk('armman', { torso: '9/9 จดเอง' })); });
  await page.goto(url + '#sheet-armold'); await wait(500);
  const Em = await page.evaluate(() => ({ old: Store.get('armold').armor.torso, input: [...document.querySelectorAll('.box[data-k="tough"] input')].map(i => i.value).filter(Boolean) }));
  const torsoIdx = await page.evaluate(() => DATA.meta.bodyParts.findIndex(p => p[0] === 'torso'));
  const Eh = await page.evaluate((ti) => { const hs = [...document.querySelectorAll('.box[data-k="tough"] .armcell .armhit')]; return { n: hs.length, torso: hs[ti].textContent, shown: hs.filter(x => !x.hidden).length }; }, torsoIdx);
  await page.fill(`.box[data-k="tough"] .armcell >> nth=${torsoIdx} >> input`, '2/1 (Piercing)');
  const Eh2 = await page.evaluate((ti) => { const x = [...document.querySelectorAll('.box[data-k="tough"] .armhit')][ti]; return { t: x.textContent, hidden: x.hidden }; }, torsoIdx);
  await page.fill(`.box[data-k="tough"] .armcell >> nth=${torsoIdx} >> input`, '9/9 จดเอง');
  const Eh3 = await page.evaluate((ti) => [...document.querySelectorAll('.box[data-k="tough"] .armhit')][ti].hidden, torsoIdx);
  await page.goto(url + '#sheet-armman'); await wait(400);
  const Em2 = await page.evaluate(() => Store.get('armman').armor.torso);
  ok('E: old automatic armor recomputed with types', Em.old === '4/4 (Slashing) · 2 (Blunt)' && Em.input.includes('4/4 (Slashing) · 2 (Blunt)'), Em);
  ok('E: hand-written armor kept', Em2 === '9/9 จดเอง', Em2);
  // v1.25.2 (Non เคาะ 15 พ.ย. 2026): โดนชนิดในวงเล็บหักเกราะหลักบวกเกราะรอง ชนิดอื่นหักเกราะหลักอย่างเดียว
  const H = await page.evaluate(() => ({
    real: armorHitText(armorText(['ชั้นใน Armor 1 / 2 (Blunt)', 'Armor 2 / 2 (Slashing)'].map(parseArmor), 0)),
    mixed: armorHitText('4/4 (Slashing) · 2 (Blunt)'), hits: armorHits('3/2 (Slashing/Blunt)'),
    sr: armorHitText('0/1 (Sorceries Resistance)'), srMix: armorHitText('2/1 (Piercing) · 2 (Sorceries Resistance)'),
    plain: armorHitText('2'), note: armorHitText('9/9 จดเอง'), empty: armorHitText(''), gloss: DATA.glossary.Armor.text }));
  ok('E: a bracketed damage type takes main plus secondary armor', H.real === 'หัก Slashing/Blunt 5 · อื่น ๆ 3' && H.mixed === 'หัก Slashing 8 · Blunt 6 · อื่น ๆ 4' && JSON.stringify(H.hits) === JSON.stringify({ main: 3, sec: { Slashing: 2, Blunt: 2 } }), H);
  ok('E: no totals for sorcery resistance, plain armour or hand notes', H.sr === '' && H.srMix === 'หัก Piercing 3 · อื่น ๆ 2' && H.plain === '' && H.note === '' && H.empty === '', H);
  ok('E: glossary carries the ruling', /เมื่อโดนความเสียหายชนิดที่อยู่ในวงเล็บให้หักทั้งเกราะหลักและเกราะรอง/.test(H.gloss) && /ให้หักเกราะหลักเพียงอย่างเดียว/.test(H.gloss), H.gloss.slice(-160));
  ok('E: sheet shows what the torso armour takes off', Eh.n === 6 && Eh.shown === 1 && Eh.torso === 'หัก Slashing 8 · Blunt 6 · อื่น ๆ 4', Eh);
  ok('E: the line follows typing and hides for free notes', Eh2.t === 'หัก Piercing 3 · อื่น ๆ 2' && !Eh2.hidden && Eh3 === true, [Eh2, Eh3]);

  // ================= A) Durability =================
  const A = await page.evaluate(() => {
    const r = {};
    r.knife = durDefaultMax({ name: 'มีดออบซิเดียน', effect: '1 PDMG (Slashing/Piercing), Rip. เปราะ: มี 3 Durability และเสีย Durability 1 หน่วย' });
    r.inf = durState({ name: 'โล่เขี้ยวมังกร', effect: 'Indestructible: โล่นี้ไม่มีวันพัง' });
    r.plain = durState({ name: 'ดาบ', effect: '2 PDMG (Slashing)' });
    const e = { name: 'หมวก', effect: 'Armor 2/1 (Blunt)' }; durSet(e, 4); r.set4 = [e.dur, e.durMax]; durSet(e, 6); r.full = [e.dur, e.durMax]; durSet(e, 2, 9); r.tier = [e.dur, e.durMax];
    const c = Object.assign(newChar(), { id: 'durc', name: 'ทดสอบทนทาน', kin: 'solrin', size: 'Medium', done: true, step: 7, starterSet: 'The Sailor',
      equip: { chestOut: { name: 'เกราะหนัง (Leather Armor)', effect: 'Armor 4/2 (Blunt)', weight: 5 }, shield: { name: 'โล่ไม้ (Wooden Shield)', effect: '+2 Parry Dice', weight: 3 }, weapon1: { name: 'ดาบยาว (Longsword)', effect: '3 PDMG (Slashing)', weight: 1.5 } },
      inventory: [{ name: 'เกราะหนัง (Leather Armor)', effect: 'Armor 4/2 (Blunt)', qty: 1, weight: 5 }] });
    recalcParry(c); recalcArmor(c); r.before = [c.armor.torso, c.current.parryBonus];
    durSet(c.equip.chestOut, 0); durSet(c.equip.shield, 0); recalcParry(c); recalcArmor(c); r.broken = [c.armor.torso, c.current.parryBonus, durBroken(c.equip.chestOut)];
    // ถอดของพังกลับกระเป๋า ไม่รวมกองกับเกราะหนังสภาพดี แล้วสวมกลับยังพังอยู่
    unequip(c, 'chestOut'); r.bag = c.inventory.map(x => [x.name.slice(0, 8), x.qty, x.dur]);
    const bi = c.inventory.findIndex(x => x.dur === 0); wearItem(c, bi, 'chestOut'); r.rewear = [c.equip.chestOut.dur, c.armor.torso];
    Store.upsert(c); return r; });
  ok('A: defaults 3 / ∞ / 6 from the item text', A.knife === 3 && A.inf.inf === true && A.plain.max === 6 && A.plain.cur === 6, A);
  ok('A: only differences from the default are stored', JSON.stringify(A.set4) === '[4,null]' && JSON.stringify(A.full) === '[null,null]' && JSON.stringify(A.tier) === '[2,9]', [A.set4, A.full, A.tier]);
  ok('A: broken armor and shield halve Armor and Parry Dice', A.before[0] === '4/2 (Blunt)' && A.before[1] === 2 && A.broken[0] === '2/1 (Blunt)' && A.broken[1] === 1 && A.broken[2], [A.before, A.broken]);
  ok('A: damaged item keeps its state in the bag', A.bag.length === 2 && A.bag.some(x => x[2] === 0) && A.bag.some(x => x[2] == null), A.bag);
  ok('A: wearing it again keeps it broken', A.rewear[0] === 0 && A.rewear[1] === '2/1 (Blunt)', A.rewear);
  // UI: ถุงย่าม ปุ่ม − + เพดาน ซ่อมของพัง และป้าย
  await page.goto(url + '#sheet-durc'); await wait(600);
  await page.evaluate(() => { HUD.open = 'pouch'; HUD.sel.pouch = 'weapon1'; HUD.persist(); }); await page.goto(url + '#home'); await wait(150); await page.goto(url + '#sheet-durc'); await wait(600);
  const U0 = await page.evaluate(() => ({ editor: !!document.querySelector('#hud .durbox'), num: (document.querySelector('#hud .durbox .durnum') || {}).textContent, pips: [...document.querySelectorAll('#hud .durpip')].map(p => p.textContent) }));
  ok('A: pouch shows the durability editor and pips', U0.editor && U0.num === '6/6' && U0.pips.includes('พัง'), U0);
  await page.click('#hud .durbox .durminus'); await wait(200);
  ok('A: minus button costs 1 durability', await page.evaluate(() => Store.get('durc').equip.weapon1.dur) === 5);
  await page.evaluate(() => { const c = Store.get('durc'); durSet(c.equip.weapon1, 0); Store.upsert(c); renderHUD(c, compute(c), hudCtx); }); await wait(200);
  const U1 = await page.evaluate(() => ({ pd: [...document.querySelectorAll('#hud .wslot .ef b')].map(b => b.textContent), fix: !!document.querySelector('#hud .durbox .durfix'), plusOff: document.querySelector('#hud .durbox .durplus').disabled }));
  ok('A: broken weapon shows half PDMG and only the broken-repair path', U1.pd.includes('1 PDMG (พัง)') && U1.fix && U1.plusOff, U1);
  await page.click('#hud .durbox .durfix'); await wait(200);
  const U2 = await page.evaluate(() => { const e = Store.get('durc').equip.weapon1; return [e.dur, e.durMax, durState(e).cur, durState(e).max]; });
  ok('A: repairing a broken item gives 1/1 for good', JSON.stringify(U2) === '[null,1,1,1]', U2);
  // Perfect Strike ที่ลำตัว: สองชั้นให้เลือก ชั้นเดียวลดเลย
  await page.evaluate(() => { const c = Store.get('durc'); c.equip.chestIn = { name: 'แกมเบสัน', effect: 'ชั้นใน Armor 1/2 (Blunt)', weight: 3.5 }; durSet(c.equip.chestOut, 6); recalcArmor(c); Store.upsert(c); });
  await page.goto(url + '#home'); await wait(100); await page.goto(url + '#sheet-durc'); await wait(500);
  const ps = await page.$('.box[data-k="tough"] .psbtn[data-part="torso"]');
  ok('A: Perfect Strike button on armoured parts only', !!ps && !(await page.$('.box[data-k="tough"] .psbtn[data-part="legL"]')));
  await ps.click(); await wait(200);
  const P1 = await page.evaluate(() => [...document.querySelectorAll('#modal .psmodal button')].map(b => b.textContent));
  ok('A: two layers ask which piece takes it, outer first', P1.length === 2 && /^เกราะหนัง/.test(P1[0]), P1);
  await page.click('#modal .psmodal button >> nth=0'); await wait(250);
  ok('A: chosen piece loses 1', await page.evaluate(() => Store.get('durc').equip.chestOut.dur) === 5);

  // v1.25.1: ของใหม่จาก GM และการย้ายข้ามกระเป๋าของแฝดไม่รวมกองกับชิ้นที่สึกหรือพัง
  const G = await page.evaluate(() => {
    const kin = DATA.kins.find(k => k.id === 'lunaryn'); const tw = kin.specialChildhood.find(x => x.nameEn === 'Twinborn');
    const sword = { name: 'ดาบยาว (Longsword)', effect: '3 PDMG (Slashing)', weight: 1.5 };
    const c = Object.assign(newChar(), { id: 'durg', name: 'ทดสอบของขวัญ', kin: 'lunaryn', size: 'Medium', childhood: tw.code, adulthood: kin.adulthood[0].code, done: true, step: 7, starterSet: 'The Vanguard', equipAuto: true,
      inventory: [Object.assign({}, sword, { qty: 1, dur: 0 })], inventory2: [Object.assign({}, sword, { qty: 1 })] });
    Store.upsert(c);
    applyGift('local', { id: 'g-dur-1', toCharId: 'durg', from: 'GM', item: Object.assign({}, sword, { qty: 1 }) }, true);
    const c2 = Store.get('durg'); return { twin: isTwinborn(c2), bag: c2.inventory.map(x => [x.qty, x.dur == null ? null : x.dur]) };
  });
  ok('A: a fresh item from the GM does not stack onto a broken one', G.twin && G.bag.length === 2 && G.bag[0][0] === 1 && G.bag[0][1] === 0 && G.bag[1][0] === 1 && G.bag[1][1] === null, G);
  await page.goto(url + '#sheet-durg'); await wait(700);
  await page.click('.hud-btn[title="กระเป๋า"]'); await wait(300);
  await page.click('.hud-win .tile:not(.add) >> nth=0'); await wait(200);
  await page.click('.hud-win .movebtn'); await wait(300);
  const G2 = await page.evaluate(() => { const c = Store.get('durg'); return { a: c.inventory.map(x => [x.qty, x.dur == null ? null : x.dur]), b: c.inventory2.map(x => [x.qty, x.dur == null ? null : x.dur]) }; });
  ok('A: moving a broken item to the other twin keeps it apart', G2.a.length === 1 && G2.a[0][1] === null && G2.b.length === 2 && G2.b.some(x => x[0] === 1 && x[1] === null) && G2.b.some(x => x[0] === 1 && x[1] === 0), G2);
  await page.click('.hud-x'); await wait(150);

  // ================= D) โทษระยะยิง =================
  const D = await page.evaluate(() => {
    const k = DATA.knowledge.find(x => x.id === 'range');
    return { p: [rangePenalty(10, 10), rangePenalty(12, 10), rangePenalty(14, 10), rangePenalty(30, 20), rangePenalty(8, 10)], tiers: [rangePenaltyTier(2), rangePenaltyTier(6), rangePenaltyTier(12)],
      lv: Object.values(k.levels).every(l => /-1 CV ต่อทุก 1 เมตรที่เกิน/.test(l.text) && !/10 เมตรที่เริ่มนับ/.test(l.text)), far: GLOSSARY['Far Zone'].text,
      text: rangeShotText(14, 10) }; });
  ok('D: −1 CV for every metre past accurate range', JSON.stringify(D.p) === '[0,2,4,10,0]' && JSON.stringify(D.tiers) === '[1,2,3]', D);
  ok('D: rule texts in the web data updated', D.lv && /ลด 1 CV ต่อทุก 1 เมตรที่เกินระยะแม่น/.test(D.far) && D.text === 'ยิง −4 CV (เกินระยะแม่น 10 ม. มา 4 ม.)', D);

  // ================= B) สภาวะในชีท =================
  await page.goto(url + '#table'); await wait(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องสภาวะ'); await page.click('button:has-text("สร้างห้อง")'); await wait(400);
  const rid = await page.evaluate(() => { const r = Table.room; r.map.cells = '.'.repeat(400); const c = Store.get('durc');
    r.tokens.push({ id: 'tk1', name: c.name, kind: 'pc', charId: c.id, ownerId: Store.me || 'local', x: 3, y: 3, hp: 10, hpMax: 10, conds: [], hidden: false });
    r.tokens.push({ id: 'en1', name: 'โจร', kind: 'npc', x: 6, y: 3, hp: 8, hpMax: 8, conds: [], hidden: false, mods: { STR: 3, AGI: -1, PER: 2 } });
    Table.save(); applyCond(r.tokens[0], r, 'Prone', {}); applyCond(r.tokens[0], r, 'Bleeding', { lv: 2, by: r.tokens[1] }); return r.id; });
  await page.evaluate(() => { HUD.open = 'cond'; HUD.persist(); location.hash = '#sheet-durc'; }); await wait(600);
  const B0 = await page.evaluate(() => ({ badge: (([...document.querySelectorAll('#hud .hud-btn')].find(b => b.title === 'สภาวะ') || {}).querySelector || (() => null)).call([...document.querySelectorAll('#hud .hud-btn')].find(b => b.title === 'สภาวะ'), '.badge'), items: [...document.querySelectorAll('#hud .conditem')].map(i => i.textContent.slice(0, 40)), gmAdd: !!document.querySelector('#hud .hud-win.cond button') }));
  const badge = await page.evaluate(() => { const b = [...document.querySelectorAll('#hud .hud-btn')].find(x => x.title === 'สภาวะ'); const bd = b && b.querySelector('.badge'); return bd ? bd.textContent : null; });
  ok('B: dock has a conditions button with a count', badge === '2', badge);
  ok('B: window lists the token conditions with effects', B0.items.length === 2 && B0.items.some(t => /Prone/.test(t)) && B0.items.some(t => /Bleeding 2/.test(t) && /โจร/.test(t)), B0.items);
  ok('B: GM can add from the sheet window', B0.gmAdd);
  await page.evaluate(() => { const r = Table.room; applyCond(r.tokens[0], r, 'Stunned', { turns: 1 }); }); await wait(300);
  const B1 = await page.evaluate(() => [...document.querySelectorAll('#hud .conditem')].length);
  ok('B: window follows the table live', B1 === 3, B1);
  await page.click('#hud .conditem:has-text("Prone") button:has-text("เอาออก")'); await wait(300);
  ok('B: GM removes a condition from the sheet', await page.evaluate(() => !Table.room.tokens[0].conds.some(c => c.id === 'Prone') && document.querySelectorAll('#hud .conditem').length === 2));
  await page.evaluate(() => { HUD.open = null; HUD.persist(); });

  // ================= C) NPC: ค่าพลังดัดแปลงและค่าพลังรอง =================
  const C = await page.evaluate(() => ({ d: npcDerived({ STR: 3, AGI: -1, PER: 2 }), d0: npcDerived({}), neg: npcDerived({ STR: -3 }), clean: npcModsClean({ STR: 3, AGI: 0, INT: 99 }), txt: npcModsText({ STR: 3, AGI: -1 }) }));
  ok('C: derived stats use the player formulas', JSON.stringify(C.d) === JSON.stringify({ might: 2, sight: 2, passivePer: 9, reflex: 0 }) && JSON.stringify(C.d0) === JSON.stringify({ might: 1, sight: 1, passivePer: 7, reflex: 1 }) && C.neg.might === -1, C);
  ok('C: modifiers cleaned and summarised', JSON.stringify(C.clean) === JSON.stringify({ STR: 3, INT: 10 }) && C.txt === 'STR +3 · AGI -1', C);
  await page.evaluate((id) => { location.hash = '#room-' + id; }, rid); await wait(500);
  await page.click('.cell[data-x="6"][data-y="3"] .gtok'); await wait(250);
  const C1 = await page.evaluate(() => ({ btns: [...document.querySelectorAll('.npcmodrow .npcmod')].map(b => b.textContent), der: [...document.querySelectorAll('.npcderived .tag')].map(t => t.textContent) }));
  const Ct = await page.evaluate(() => { Table.sel = 'tk1'; Table.measure = null; renderTable(); const out = [...document.querySelectorAll('.cp-sec .armhit')].filter(x => !x.hidden).map(x => x.textContent); Table.sel = 'en1'; renderTable(); return out; });
  ok('E: table panel shows what the armour takes off', Ct.includes('หัก Blunt 9 · อื่น ๆ 5'), Ct);
  ok('C: token panel shows six modifier rolls and the derived stats', C1.btns.length === 6 && C1.btns[0] === 'STR +3' && C1.der.includes('Might +2') && C1.der.includes('Passive PER 9') && C1.der.includes('Reflex 0'), C1);
  await page.click('.npcmodrow .npcmod[data-st="STR"]'); await wait(400);
  const C2 = await page.evaluate(() => { const m = Table.chat.find(x => x.kind === 'roll'); return m ? { who: m.who, text: m.text, mod: m.mod, gm: m.gmOnly } : null; });
  ok('C: modifier roll posts as the NPC', C2 && C2.who === 'โจร' && C2.text === 'STR Check' && C2.mod === 3 && C2.gm === false, C2);
  await page.evaluate(() => { const t = Table.room.tokens.find(x => x.id === 'en1'); t.hidden = true; renderTable(); }); await wait(200);
  await page.click('.npcmodrow .npcmod[data-st="PER"]'); await wait(1500);
  const C3 = await page.evaluate(() => { const m = Table.chat.find(x => x.kind === 'roll'); return m ? { text: m.text, gm: m.gmOnly, mod: m.mod } : null; });
  ok('C: hidden NPC rolls secretly', C3 && C3.text === 'PER Check' && C3.gm === true && C3.mod === 2, C3);
  // คลัง NPC: ค่าที่ใส่ติดไปกับรายการและหมาก
  const C4 = await page.evaluate(async () => { const it = NpcLib.newItem('npc'); it.name = 'ทหารรับจ้าง'; it.mods = { STR: 2, VIT: 1 }; await NpcLib.save(it); const back = libClean(JSON.parse(JSON.stringify(it))); const tk = libToken(Table.room, back, { x: 9, y: 9 }, null, false); return { lib: back.mods, tok: tk.mods, id: it.id }; });
  ok('C: library keeps the modifiers and tokens copy them', JSON.stringify(C4.lib) === JSON.stringify({ STR: 2, VIT: 1 }) && JSON.stringify(C4.tok) === JSON.stringify({ STR: 2, VIT: 1 }), C4);
  await page.goto(url + '#npcedit-' + C4.id); await wait(500);
  await page.fill('input[data-f="mod-AGI"]', '4'); await wait(150);
  const C5 = await page.evaluate(() => ({ mods: NpcLib.get(location.hash.slice(9)).mods, der: [...document.querySelectorAll('.npcderived .tag')].map(t => t.textContent) }));
  ok('C: editor fields write modifiers and update derived stats live', C5.mods.AGI === 4 && C5.der.includes('Reflex +3'), C5);
  if (SHOTS){ const el = await page.$('.npcform'); if (el) await el.screenshot({ path: path.join(SHOTS, 'v125_npc.png') }); }

  ok('no page errors', errors.length === 0, errors);
  console.log(`v125: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
