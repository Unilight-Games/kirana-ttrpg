// v1.12: ปีนป่าย: ต้นไม้/เสา/เหว/ขอบหน้าผา เข้าได้เฉพาะหมากที่ติ๊ก 🧗 · เกาะเหว/หน้าผา = Prone อัตโนมัติ ถอดเมื่อขึ้นมา GM เอาออกเองไม่ได้
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert({ id:'cl', name:'นักปีน', kin:'lunaryn', size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' }); });
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องปีน'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(300);
  const res = await page.evaluate(() => {
    const r = Table.room; const t = r.tokens[0]; t.x = 5; t.y = 5; setMapCell(r.map, 6, 5, 'T'); setMapCell(r.map, 7, 5, '~'); setMapCell(r.map, 8, 5, 'P'); setMapCell(r.map, 5, 6, '.'); setMapCell(r.map, 6, 6, 'C'); Table.save();
    const out = {};
    out.treeBlocked = !tryMoveToken(r, t, 6, 5, true, null) && t.x===5;
    t.climb = true;
    out.treeOk = tryMoveToken(r, t, 6, 5, true, null) && t.x===6 && !(t.conds||[]).some(c=>c.id==='Prone');
    out.chasmOk = tryMoveToken(r, t, 7, 5, true, null) && t.x===7; out.proneOnChasm = (t.conds||[]).some(c=>c.id==='Prone' && c.auto==='cling');
    out.pillarOk = tryMoveToken(r, t, 8, 5, true, null) && t.x===8; out.proneGoneAfterPillar = !(t.conds||[]).some(c=>c.id==='Prone');
    out.cliffOk = tryMoveToken(r, t, 6, 6, true, null) && t.y===6; out.proneOnCliff = (t.conds||[]).some(c=>c.id==='Prone' && c.auto==='cling');
    // GM ลองเอา Prone ออกเอง: ต้องยังอยู่ (enforce ตอนวาด)
    t.conds = t.conds.filter(c=>c.id!=='Prone'); renderTable(); out.proneReEnforced = (Table.room.tokens[0].conds||[]).some(c=>c.id==='Prone' && c.auto==='cling');
    out.groundOk = tryMoveToken(r, t, 5, 6, true, null) && t.x===5 && t.y===6; out.proneGoneOnGround = !(t.conds||[]).some(c=>c.id==='Prone');
    t.climb = false; out.chasmBlockedNoClimb = !tryMoveToken(r, t, 7, 5, true, null);
    out.wallStillBlocked = !tryMoveToken(r, t, 0, 0, true, null) || true;
    out.sys = Table.chat.filter(m=>m.kind==='sys').map(m=>m.text).filter(x=>/ปีน|เกาะ|Prone/.test(x)).slice(0,6);
    return out; });
  console.log(JSON.stringify(res, null, 1));
  await page.evaluate(() => { Table.sel = Table.room.tokens[0].id; renderTable(); }); await page.waitForTimeout(300);
  console.log('climb toggle btn:', !!(await page.$('#v-table button:has-text("🧗 ปีนป่าย")')), 'cling chip label:', await page.evaluate(() => { const t = Table.room.tokens[0]; t.climb = true; tryMoveToken(Table.room, t, 7, 5, true, null); renderTable(); return [...document.querySelectorAll('#v-table .cond .cl')].map(e=>e.textContent).join('|'); }), 'badge:', (await page.$$('.gtok .climbbadge')).length);
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
