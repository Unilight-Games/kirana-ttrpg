// v1.20 (13 พ.ย. 2026) เก้าข้อจากข้อความของ Non
// 2) PDMG ทุกจุดมีประเภทความเสียหายในวงเล็บ โล่ฮีตเตอร์ 1 PDMG (Blunt) และชีทเก่าที่เก็บข้อความรุ่นเก่าของไอเทมถูกย้ายเป็นข้อความปัจจุบัน
// 3) คำพูดของเนเมสไซอาร์เรื่องเลือกนิสัยตามวงศา   4) รูปเนเมสไซอาร์ใช้ไฟล์ขยาย 2 เท่า ถอยไปไฟล์เดิมได้
// 5) แชตกลางในหน้าโต๊ะเล่น ล้างทุกเที่ยงคืนเวลาไทย   6) คำสั่งทอยทุกจุดเป็นรูป X Check (DC N)   7) หน้าโปรไฟล์ของฉัน
// 8) ไม่มีปุ่มแก้ไขในวิซาร์ด   9) ชื่อผู้พัฒนาเป็นสีทองในแชต
// ฐานข้อมูลจำลอง (mock_rules17.js) เลียน Rules v1.7 ของคอลเลกชัน maps
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const MOCK = require('./mock_rules17.js');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const dialogs = []; page.on('dialog', d => { dialogs.push(d.type() + ':' + d.message()); d.accept(); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const shot = async (name, full) => { await page.evaluate(() => { if (typeof DiceShow !== 'undefined') DiceShow.clear(); }); await page.waitForTimeout(150); await page.screenshot({ path: path.resolve(__dirname, name), fullPage: !!full }); };
  const wait = (ms) => page.waitForTimeout(ms);
  const boot = async (hash) => { await page.goto(url + (hash || '#home')); await page.reload(); await wait(600); await page.evaluate(MOCK); await page.evaluate(() => { window.__mock = installMockDb(); }); };
  const html = fs.readFileSync(path.resolve(__dirname, '../dist/index.html'), 'utf8');

  // ================= A) ข้อมูลกฎ: รูปมาตรฐานของคำสั่งทอย และประเภทความเสียหายของ PDMG =================
  await page.goto(url + '#home'); await page.reload(); await wait(500);
  const data = await page.evaluate(() => {
    const strings = []; const walk = (o, p) => { if (typeof o === 'string') strings.push([p, o]); else if (Array.isArray(o)) o.forEach((v, i) => walk(v, p + '[' + i + ']')); else if (o && typeof o === 'object') for (const k of Object.keys(o)) walk(o[k], p + '.' + k); };
    for (const k of ['skills', 'kins', 'knowledge', 'items', 'sets', 'glossary', 'talents']) walk(DATA[k], k);
    const STAT = "[A-Z][A-Za-z]*(?:\\s+&\\s+[A-Z][A-Za-z]*)?";
    const bad = [new RegExp("(?<![+\\-−\\d.])\\d+[ \\t]+(?:DC[ \\t]+)?" + STAT + "[ \\t]+(?:Saving[ \\t]+)?(?:Check|Saving Throw)"), /\(\s*\d+(?:\s*\+\s*\d*d\d+)?\s*DC\s*\)/, /(?:Check|Saving Throw)[ \t]+DC[ \t]+\d+(?![ \t]*(?:ถึง|-|\d))/, /Saving Check/, /Fortitude/, /Will Saving/];
    const left = []; for (const [p, s] of strings) for (const rx of bad){ const m = rx.exec(s); if (m) left.push(p + ': ' + m[0]); }
    const std = strings.filter(([p, s]) => /(?:Check|Saving Throw) \(DC \d+\)/.test(s)).length, formula = strings.filter(([p, s]) => /Saving Throw \(DC = /.test(s)).length;
    const TYPE = '(?:Slashing|Piercing|Blunt)'; const typed = new RegExp('^ \\(' + TYPE + '(?:/' + TYPE + ')*\\)');
    const eff = [...DATA.items.map(i => [i.name, i.effect || '']), ...DATA.sets.sets.flatMap(s => s.items.map(i => [s.nameEn + ' / ' + i.name, i.effect || ''])), ...DATA.sets.common.items.map(i => [i.name, i.effect || ''])];
    const untyped = []; let nTyped = 0;
    for (const [n, e] of eff){ const rx = /(\+\s*)?(\d+(?:d\d+)?) PDMG/g; let m; while ((m = rx.exec(e))){ const rest = e.slice(m.index + m[0].length); if (typed.test(rest)){ nTyped++; continue; } if (m[1]) continue; untyped.push(n + ': ' + e.slice(Math.max(0, m.index - 10), m.index + 40)); } }
    const get = (n) => (DATA.items.find(i => i.name.includes(n)) || {}).effect || '';
    const van = DATA.sets.sets.find(s => s.nameEn === 'The Vanguard');
    const rit = DATA.skills.find(s => s.nameEn === 'Ritual of the Lotus Flame');
    return { n: strings.length, left, std, formula, untyped, nTyped,
      steel: get('(Steel Club)'), umozo: get('(Umozo'), chain: get('(Chain Blade)'), trinaga: get('(Trinaga Blade)'), javelin: get('(Windfury Javelin)'), scythe: get('(Scarlet Scythe)'), messer: get('(Messer)'), buckler: get('(Buckler)'), heater: get('(Heater Shield)'),
      vanHeater: van.items.find(i => i.name.includes('Heater')).effect, vanSword: van.items.find(i => i.name.includes('Arming')).effect, vanSpear: van.items.find(i => i.name.includes('Steel Spear')).effect,
      knife: DATA.sets.sets.flatMap(s => s.items).filter(i => i.name.includes('Hunting Knife') && /PDMG/.test(i.effect)).map(i => i.effect.split(' · ')[0]).join('|'),
      flint: DATA.sets.common.items.find(i => i.name.includes('Flint')).effect, ritDc: rit.dc, odachi: get('(Ōdachi)').includes('VIT Check (DC 10)'), mask: DATA.sets.sets.flatMap(s => s.items).find(i => i.name.includes('Plague Doctor Mask')).effect,
      rooted: DATA.glossary.Rooted.text.includes('STR Saving Throw (DC 10)'), bleeding: DATA.glossary.Bleeding.text.includes('Medical Check (DC 8)'),
      nimble: DATA.skills.find(s => s.nameEn === 'Nimble Grace').effect.includes('(DC 8)'), interceptor: DATA.skills.find(s => s.nameEn === 'Interceptor').effect.includes('AGI Check (DC 10)'),
      connection: DATA.knowledge.find(k => k.id === 'connection').levels[0].text };
  });
  ok('no roll command is left in a number-first or bare form anywhere in the rule data', data.left.length === 0 && data.n > 3000, [data.n, data.left.slice(0, 8)]);
  ok('the standard form is what the data carries', data.std >= 120 && data.formula >= 55, [data.std, data.formula]);
  ok('samples: Check (DC N) in items, skills, knowledge, glossary', data.odachi && data.rooted && data.bleeding && data.nimble && data.interceptor && /Connection Check \(DC 8\)$/.test(data.connection) && data.ritDc === 'Order Check (DC 8)' && /Nature & Survival Check \(DC 8\)/.test(data.flint), [data.connection, data.ritDc, data.flint]);
  ok('Fortitude wording follows the locked ruling', data.mask === 'Advantage ใน VIT Saving Throw กันการติดหรือแพร่เชื้อโรค', data.mask);
  ok('every weapon PDMG carries a damage type in brackets', data.untyped.length === 0 && data.nTyped >= 85, [data.nTyped, data.untyped.slice(0, 8)]);
  ok('the six weapons that had no type', /2 PDMG \(Blunt\) Guard Break/.test(data.steel) && /3 PDMG \(Slashing\) Rip/.test(data.umozo) && /2 PDMG \(Slashing\) Rip , Focus/.test(data.chain) && /^3 PDMG \(Slashing\/Piercing\) Rip\./.test(data.trinaga) && /2 PDMG \(Piercing\), Throwable/.test(data.javelin) && /2 PDMG \(Slashing\) Rip Guard Break/.test(data.scythe), [data.steel.slice(0, 80), data.umozo.slice(0, 80), data.chain.slice(0, 80), data.trinaga.slice(0, 50), data.javelin.slice(0, 50), data.scythe.slice(0, 60)]);
  ok('type order and bare types fixed', /2 PDMG \(Slashing\/Piercing\) Rip/.test(data.messer) && /1 PDMG \(Blunt\) ใส่ผู้โจมตี/.test(data.buckler), [data.messer.slice(0, 90), data.buckler]);
  ok('Heater Shield: 1 PDMG (Blunt) paid with a Swift Action, in the catalog and in the starter set', /1 Swift Action เพื่อโจมตีด้วยโล่ 1 PDMG \(Blunt\), Impact/.test(data.heater) && data.vanHeater === '+1 Parry Dice · ใช้ 1 Swift Action กระแทกโล่ 1 PDMG (Blunt), Impact โดนแล้วติด Unbalanced', [data.heater, data.vanHeater]);
  ok('starter set rows filled from the catalog' /* v1.22: The Marksman ถือมีดพรานด้วย จึงมีมากกว่า 3 แถว */, /^2 PDMG \(Slashing\/Piercing\), Rip/.test(data.vanSword) && /^2 PDMG \(Piercing\), Rip, Reach, Throwable/.test(data.vanSpear) && data.knife.split('|').length >= 3 && data.knife.split('|').every(x => x === '1 PDMG (Piercing/Slashing), Rip, Throwable'), [data.vanSword, data.vanSpear, data.knife]);

  // ================= B) ชีทเก่า: ข้อความรุ่นเก่าของไอเทมถูกย้ายเป็นข้อความปัจจุบัน =================
  const mig = await page.evaluate(() => {
    const F = DATA.meta.itemTextFix; const out = { names: Object.keys(F.map).length, texts: F.texts.length };
    out.shape = Object.values(F.map).every(m => Object.entries(m).every(([k, i]) => /^[0-9a-z]+\.[0-9a-z]+$/.test(k) && Number.isInteger(i) && typeof F.texts[i] === 'string'));
    // ข้อความปลายทางทุกข้อความต้องเป็นข้อความปัจจุบันของไอเทมชื่อนั้นจริง
    const cur = {}; const add = (n, e) => { (cur[n] = cur[n] || new Set()).add(e); };
    for (const i of DATA.items) add(cleanAltName(i.name).replace(/\(เสนอ\)\s*/, '').replace(/\s*×\s*\d+/, '').trim(), i.effect || '');
    for (const s of DATA.sets.sets) for (const i of s.items){ const req = itemRequirement(i.name); add(cleanAltName(i.name).replace(/\(เสนอ\)\s*/, '').replace(/\s*×\s*\d+/, '').trim(), (i.effect || '') + (req ? ' · ต้องการ ' + req.label : '')); }
    for (const i of DATA.sets.common.items) add(cleanAltName(i.name).replace(/\(เสนอ\)\s*/, '').replace(/\s*×\s*\d+/, '').trim(), i.effect || '');
    out.targets = Object.entries(F.map).every(([n, m]) => Object.values(m).every(i => cur[n] && cur[n].has(F.texts[i])));
    out.key = [txtKey(''), txtKey('abc'), txtKey('+1 Parry Dice · จ่าย 1 AP กระแทกโล่ 2 PDMG Blunt, Impact โดนแล้วติด Unbalanced')].join();
    const oldHeater = '+1 Parry Dice · จ่าย 1 AP กระแทกโล่ 2 PDMG Blunt, Impact โดนแล้วติด Unbalanced';
    const oldClub = '(STR 15:-1 CV Per less) 2 PDMG Guard Break , Perfect Strike On-Hit ทำให้เป้าหมายติดสถานะ "Stun" เป็นเวลา 1 รอบการเล่น · ชนิด: อาวุธทุบสองมือ';
    const oldSword = '2 PDMG, Rip · ใช้คู่โล่แล้วทอย Parry ได้หน้าเหมือน ได้ Parry Dice เพิ่ม 1 ลูก · ต้องการ STR 8';
    const c = { inventory: [ { name: 'โล่ฮีตเตอร์ (Heater Shield)', effect: oldHeater, qty: 1, weight: 3 }, { name: 'กระบองเหล็ก (Steel Club)', effect: oldClub, qty: 1, weight: 2.2 },
        { name: 'โล่ฮีตเตอร์ (Heater Shield)', effect: 'โล่ที่ผมแก้เอง 2 PDMG', qty: 1, weight: 3 }, { name: 'ดาบของปู่', effect: oldHeater, qty: 1, weight: 1 }, { name: 'กระบองเหล็ก (Steel Club)', effect: '', qty: 1, weight: 1 }, null, 'x', { name: 5, effect: 7 } ],
      inventory2: [ { name: 'ดาบสั้น (Arming Sword)', effect: oldSword, qty: 1, weight: 1.3 } ],
      equip: { shield: { name: 'โล่ฮีตเตอร์ (Heater Shield)', effect: oldHeater, weight: 3 }, weapon1: { name: 'ดาบสั้น (Arming Sword)', effect: oldSword, weight: 1.3 }, head: null, chestIn: 'ข้อความเก่า' },
      fleshforge: { item: 'กระบองเหล็ก (Steel Club)', effect: oldClub, custom: false }, current: { parryBonus: 9 }, armorAuto: false, armor: { head: 'x' } };
    out.changed = migrateItemText(c);
    out.heater = c.inventory[0].effect; out.club = c.inventory[1].effect; out.custom = c.inventory[2].effect; out.other = c.inventory[3].effect === oldHeater; out.empty = c.inventory[4].effect;
    out.sword2 = c.inventory2[0].effect; out.eqShield = c.equip.shield.effect; out.eqSword = c.equip.weapon1.effect; out.ff = c.fleshforge.effect; out.parry = c.current.parryBonus; out.armorKept = c.armor.head === 'x';
    out.again = migrateItemText(c);
    const c2 = { inventory: [{ name: 'กระบองเหล็ก (Steel Club)', effect: oldClub }], fleshforge: { item: 'กระบองเหล็ก (Steel Club)', effect: oldClub, custom: true } }; migrateItemText(c2); out.ffCustom = c2.fleshforge.effect === oldClub;
    out.nothing = [migrateItemText(null), migrateItemText({}), migrateItemText({ inventory: 'x', equip: 5 })].join();
    return out; });
  ok('fix table is well formed and points at current texts only', mig.shape && mig.targets && mig.names >= 45 && mig.texts >= 50, [mig.names, mig.texts, mig.shape, mig.targets]);
  ok('text key matches the build tool (FNV-1a over UTF-16 plus length)', mig.key === 'ztntfp.0,7aigaz.3,qswq9l.26', mig.key);
  ok('a pre-v1.6 Vanguard shield now reads 1 PDMG (Blunt) with a Swift Action', mig.changed === true && mig.heater === data.vanHeater && mig.eqShield === data.vanHeater, [mig.heater, mig.eqShield]);
  ok('old catalog and starter texts are refreshed in bag, second bag, slots and Fleshforge', mig.club === data.steel && mig.ff === data.steel && mig.sword2 === data.vanSword + ' · ต้องการ STR 8' && mig.eqSword === mig.sword2, [mig.club.slice(0, 60), mig.sword2]);
  ok('texts a player wrote are left alone', mig.custom === 'โล่ที่ผมแก้เอง 2 PDMG' && mig.other && mig.empty === '' && mig.ffCustom, mig);
  ok('values read from the text are recomputed, manual armor is kept', mig.parry === 1 && mig.armorKept, [mig.parry, mig.armorKept]);
  ok('running it twice changes nothing, odd input is ignored', mig.again === false && mig.nothing === 'false,false,false', [mig.again, mig.nothing]);
  // ผ่านชีทจริง: ตัวละครชุด The Vanguard ที่เก็บข้อความเก่าไว้ เปิดชีทแล้วช่องโล่เป็นข้อความปัจจุบัน
  const sheet = await page.evaluate(async () => { const K = window.__kirana; const kin = DATA.kins.find(k => k.id === 'lunaryn');
    K.Store.upsert({ id: 'old20', name: 'ทหารเก่า', kin: 'lunaryn', size: 'Medium', childhood: kin.childhood[0].code, adulthood: kin.adulthood[0].code, extra: { STR: 3, VIT: 3, PER: 4 }, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {}, skills: [], details: {}, done: true, step: 7, starterSet: 'The Vanguard',
      inventory: [{ name: 'เสบียง (Ration)', effect: 'กินก่อนพักได้ 5 ครั้ง (ข้อเคาะที่ 1)', qty: 5, weight: 2 }], equipAuto: true,
      equip: { shield: { name: 'โล่ฮีตเตอร์ (Heater Shield)', effect: '+1 Parry Dice · จ่าย 1 AP กระแทกโล่ 2 PDMG Blunt, Impact โดนแล้วติด Unbalanced', weight: 3 } } });
    location.hash = '#sheet-old20'; await new Promise(r => setTimeout(r, 700));
    const c = K.Store.get('old20'); return { eff: c.equip.shield.effect, txt: document.querySelector('#v-sheet').textContent.includes('2 PDMG Blunt'), wiz: [...document.querySelectorAll('#v-sheet button')].some(b => /วิซาร์ด/.test(b.textContent)), btns: [...document.querySelectorAll('#v-sheet .box[data-k="id"] button')].map(b => b.textContent.trim()) }; });
  ok('opening an old sheet refreshes the stored shield text', sheet.eff === data.vanHeater && !sheet.txt, sheet);

  // ================= C) ข้อ 8: ไม่มีปุ่มแก้ไขในวิซาร์ด =================
  ok('sheet header has no wizard button', !sheet.wiz && sheet.btns.includes('ส่งออก JSON'), sheet.btns);
  const chars = await page.evaluate(async () => { const K = window.__kirana; const kin = DATA.kins.find(k => k.id === 'lunaryn');
    K.Store.upsert({ id: 'draft20', name: 'ร่างยังไม่เสร็จ', kin: 'lunaryn', size: 'Medium', childhood: kin.childhood[0].code, adulthood: kin.adulthood[0].code, extra: {}, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {}, skills: [], details: {}, done: false, step: 3 });
    const c = K.Store.get('old20'); c.roomIds = ['r1']; K.Store.upsert(c);
    location.hash = '#chars'; await new Promise(r => setTimeout(r, 400));
    const cards = [...document.querySelectorAll('#v-chars .charcard')].map(el => ({ name: el.querySelector('h3').firstChild.textContent, btns: [...el.querySelectorAll('button')].map(b => b.textContent.trim()), tags: [...el.querySelectorAll('.tag')].map(t => t.textContent) }));
    location.hash = '#sheet-old20'; await new Promise(r => setTimeout(r, 500));
    const lock = [...document.querySelectorAll('#v-sheet .box[data-k="id"] .tag')].map(t => t.textContent);
    c.roomIds = []; K.Store.upsert(c);
    return { cards, lock, all: document.body.textContent.includes('แก้ไขในวิซาร์ด') }; });
  const done = chars.cards.find(c => c.name === 'ทหารเก่า'), draft = chars.cards.find(c => c.name === 'ร่างยังไม่เสร็จ');
  ok('finished character: open sheet, export, delete and nothing that leads back to the wizard', !!done && done.btns.join() === 'เปิดชีท,ส่งออก JSON,ลบ' && done.tags.includes('อยู่ในแคมเปญ'), done);
  ok('unfinished draft keeps its continue button', !!draft && draft.btns.join() === 'ทำต่อ,ส่งออก JSON,ลบ', draft);
  ok('in-campaign mark stays on the sheet, the wizard label is gone from the app', chars.lock.includes('🔒 อยู่ในแคมเปญ') && !chars.all && !html.includes('แก้ไขในวิซาร์ด'), chars.lock);

  // ================= D) ข้อ 3 และ 4: คำพูดกับรูปของเนเมสไซอาร์ · ช่อง DC Check ของพิธีกรรม =================
  ok('Nemessiah line replaced', html.includes("'อย่าเลือกนิสัยตามวงศา มันจะสนุกกว่าถ้าเจ้าเป็นคนเลือกเอง'") && !html.includes('นอร์ลันที่ระแวดระวังหรือฟลอรันที่เลือดเย็น'));
  const nem = await page.evaluate(async () => { location.hash = '#create'; await new Promise(r => setTimeout(r, 500));
    const sp = document.querySelector('.vn-sprite img'); const first = sp ? sp.getAttribute('src') : null;
    const img = nemImg('think'); const src1 = img.getAttribute('src'); img.dispatchEvent(new Event('error')); const src2 = img.getAttribute('src'); img.dispatchEvent(new Event('error')); const hid = img.style.visibility;
    nemSet(img, 'mad'); return { first, src1, src2, hid, src3: img.getAttribute('src'), vis: img.style.visibility, bad: nemSrcHd('nope'), small: nemSrc('ask') }; });
  ok('portraits use the 2x file and fall back to the original, then hide', /assets\/nem-[a-z]+-2x\.webp$/.test(nem.first || '') && nem.src1 === 'assets/nem-think-2x.webp' && nem.src2 === 'assets/nem-think.webp' && nem.hid === 'hidden' && nem.src3 === 'assets/nem-mad-2x.webp' && nem.vis === '' && nem.bad === 'assets/nem-smile-2x.webp' && nem.small === 'assets/nem-ask.webp', nem);
  const hd = ['ask', 'explain', 'guilty', 'mad', 'panic', 'shush', 'smile', 'smirk', 'surprise', 'think'].map(m => { const p = path.resolve(__dirname, '../dist/assets/nem-' + m + '-2x.webp'); return fs.existsSync(p) ? fs.statSync(p).size : 0; });
  ok('ten 2x portrait files exist next to the originals', hd.every(s => s > 30000), hd);
  const rit = await page.evaluate(async () => { const sk = DATA.skills.find(s => s.nameEn === 'Ritual of the Lotus Flame'); const lines = skillRollLines(sk, 'eff'); const none = skillRollLines(DATA.skills.find(s => !s.dc && !s.onFail), 'eff');
    const card = skillCard(sk, false, () => {}, false); return { n: lines.length, a: lines[0].textContent, b: lines[1].textContent.slice(0, 40), none: none.length, card: card.textContent.includes('DC Check Order Check (DC 8)') && card.textContent.includes('หากล้มเหลว'), all: DATA.skills.filter(s => s.dc).length }; });
  ok('ritual sorceries show their DC Check and failure text', rit.n === 2 && rit.a === 'DC Check Order Check (DC 8)' && /^หากล้มเหลว พลังงาน/.test(rit.b) && rit.none === 0 && rit.card && rit.all === 13, rit);

  // ================= E) ข้อ 7: โปรไฟล์ (ออฟไลน์) =================
  await page.goto(url + '#home'); await page.evaluate(() => { try { localStorage.removeItem('kirana.profile.v1'); } catch (e) {} }); await page.reload(); await wait(600);
  const offp = await page.evaluate(async () => { location.hash = '#profile'; await new Promise(r => setTimeout(r, 400));
    const out = { form: !!document.querySelector('.pf-form'), acct: document.querySelector('.pf-acct').textContent, link: (document.querySelector('#online a.acct') || {}).getAttribute ? document.querySelector('#online a.acct').getAttribute('href') : null, reset: !!document.querySelector('.pf-reset') };
    const n = document.querySelector('.pf-name'), b = document.querySelector('.pf-bio'); n.value = '  นักเล่า' + String.fromCharCode(0x200b) + 'เรื่อง   ออฟไลน์ '; b.value = 'บรรทัดหนึ่ง\n\n\n\nบรรทัดสอง'; n.dispatchEvent(new Event('input'));
    out.prev = document.querySelector('.pf-preview .uname').textContent; out.count = document.querySelector('.pf-namecount').textContent;
    document.querySelector('.pf-save').click(); await new Promise(r => setTimeout(r, 300));
    out.name = Store.displayName; out.local = JSON.parse(localStorage.getItem('kirana.profile.v1')); out.head = document.querySelector('#online').textContent; out.reset2 = !!document.querySelector('.pf-reset'); out.val = document.querySelector('.pf-name').value;
    const e = await ProfileLib.save('   ', 'x'); out.empty = e.ok === false && /อย่างน้อยหนึ่งตัวอักษร/.test(e.msg);
    return out; });
  ok('offline: the profile page works and says it stays on this device', offp.form && /โหมดออฟไลน์/.test(offp.acct) && offp.link === '#profile' && !offp.reset, offp);
  ok('offline: name is cleaned, saved locally and used at once', offp.prev === 'นักเล่า เรื่อง ออฟไลน์' && offp.name === 'นักเล่า เรื่อง ออฟไลน์' && offp.local.uid === 'local' && offp.local.bio === 'บรรทัดหนึ่ง\n\nบรรทัดสอง' && offp.head.includes('นักเล่า เรื่อง ออฟไลน์') && offp.reset2 && offp.val === 'นักเล่า เรื่อง ออฟไลน์' && offp.empty, offp);
  await page.reload(); await wait(700);
  const offp2 = await page.evaluate(async () => { const out = { name: Store.displayName, loaded: ProfileLib.loaded }; location.hash = '#profile'; await new Promise(r => setTimeout(r, 300));
    const btn = document.querySelector('.pf-reset'); btn.click(); out.armed = btn.textContent; out.still = Store.displayName; btn.click(); await new Promise(r => setTimeout(r, 300));
    out.after = Store.displayName; out.ls = localStorage.getItem('kirana.profile.v1'); out.reset = !!document.querySelector('.pf-reset'); return out; });
  ok('offline: the name survives a reload, deleting takes two clicks and restores the account name', offp2.name === 'นักเล่า เรื่อง ออฟไลน์' && offp2.loaded && /กดอีกครั้ง/.test(offp2.armed) && offp2.still === 'นักเล่า เรื่อง ออฟไลน์' && offp2.after === '' && offp2.ls === null && !offp2.reset, offp2);
  const pure = await page.evaluate(() => { const z = String.fromCharCode; const out = {};
    out.day = [gcDay(Date.UTC(2026, 10, 12, 16, 59, 59)), gcDay(Date.UTC(2026, 10, 12, 17, 0, 0)), gcDay(Date.UTC(2026, 11, 31, 17, 0, 0)), gcDay(Date.UTC(2026, 10, 13, 0, 0, 0))].join();
    out.ms = [gcMsToMidnight(Date.UTC(2026, 10, 12, 16, 59, 59)), gcMsToMidnight(Date.UTC(2026, 10, 12, 17, 0, 0)), gcMsToMidnight(Date.UTC(2026, 10, 12, 5, 0, 0))].join();
    out.name = [profCleanName('  a ' + z(0x202e) + ' b\n\tc  '), profCleanName(z(0x3164) + z(0x115f) + z(0xfeff)), profCleanName('ก'.repeat(60)).length, Array.from(profCleanName(z(0xd83d) + z(0xde00) + 'x'.repeat(60))).length, profCleanName(5), profCleanName(null)].join('|');
    out.bio = JSON.stringify([profCleanBio('a\r\nb\r\rc' + z(0x200d) + z(7) + '  \n d'), profCleanBio('x'.repeat(700)).length, profCleanBio({})]);
    out.text = JSON.stringify([gcCleanText('  สวัสดี\n\nครับ' + z(0x200b) + '  '), gcCleanText('y'.repeat(400)).length, gcCleanText(undefined)]);
    const P = { id: 'prof-u9', type: 'profile', published: true, ownerId: 'u9', ownerName: 'x', name: '  ชื่อ  ', bio: ' ข้อความ ', createdAt: 3, updatedAt: 9 };
    out.prof = JSON.stringify(socCleanProfile(P));
    out.profBad = [null, 'x', {}, { ...P, type: 'gchat' }, { ...P, id: 'prof-zz' }, { ...P, ownerId: '' }, { ...P, ownerId: 5 }, { ...P, id: 'prof-u9~TOOLONG' }, { ...P, id: 5 }].map(x => socCleanProfile(x) === null).join();
    out.profFb = socCleanProfile({ ...P, id: 'prof-u9~ab12cd34', name: { a: 1 }, bio: 5, published: 'yes', updatedAt: 'x' });
    const C = { id: 'gchat-u9', type: 'gchat', published: true, ownerId: 'u9', ownerName: ' คนคุย ', day: '2026-11-13', msgs: [{ t: 5, x: ' หนึ่ง ' }, { t: 5, x: 'ซ้ำเวลา' }, { t: 0, x: 'ไม่มีเวลา' }, { t: 7, x: '   ' }, null, 'x', { t: 8, x: { a: 1 } }, { t: 9, x: 'สอง' }], updatedAt: 4 };
    out.chat = JSON.stringify(socCleanChat(C));
    out.chatBad = [null, {}, { ...C, type: 'profile' }, { ...C, published: false }, { ...C, id: 'gchat-zz' }, { ...C, day: '13-11-2026' }, { ...C, day: 5 }, { ...C, ownerId: '' }].map(x => socCleanChat(x) === null).join();
    const many = []; for (let i = 1; i <= 90; i++) many.push({ t: i, x: 'm' + i }); const cc = socCleanChat({ ...C, msgs: many }); out.cap = [cc.msgs.length, cc.msgs[0].x, cc.msgs[59].x].join(); out.noArr = socCleanChat({ ...C, msgs: { a: 1 } }).msgs.length;
    out.consts = [PROF_NAME_MAX, PROF_BIO_MAX, GC_TEXT_MAX, GC_KEEP, GC_SHOW].join();
    return out; });
  ok('Thai day boundary: 23:59:59 is still today, 00:00:00 starts the next day', pure.day === '2026-11-12,2026-11-13,2027-01-01,2026-11-13' && pure.ms === '1000,86400000,43200000', [pure.day, pure.ms]);
  ok('names: control and invisible characters removed, spaces folded, 40 characters without splitting a pair', pure.name === 'a b c||40|40||', pure.name);
  ok('bio and chat text are cleaned and capped', pure.bio === '["a\\nb\\n\\nc\\n d",500,""]' && pure.text === '["สวัสดี ครับ",300,""]', [pure.bio, pure.text]);
  ok('profile documents: well-formed kept, wrong type owner or id rejected', pure.prof === '{"id":"prof-u9","ownerId":"u9","name":"ชื่อ","bio":"ข้อความ","published":true,"createdAt":3,"updatedAt":9}' && pure.profBad === Array(9).fill('true').join() && pure.profFb && pure.profFb.name === '' && pure.profFb.bio === '' && pure.profFb.published === false && pure.profFb.updatedAt === 0, [pure.prof, pure.profBad, pure.profFb]);
  ok('chat documents: malformed messages dropped, 60 kept, wrong shape rejected', pure.chat === '{"id":"gchat-u9","ownerId":"u9","ownerName":"คนคุย","day":"2026-11-13","msgs":[{"t":5,"x":"หนึ่ง"},{"t":9,"x":"สอง"}],"updatedAt":4}' && pure.chatBad === Array(8).fill('true').join() && pure.cap === '60,m31,m90' && pure.noArr === 0, [pure.chat, pure.chatBad, pure.cap]);
  ok('limits', pure.consts === '40,500,300,60,200', pure.consts);

  // ================= F) ข้อ 7: โปรไฟล์ (ออนไลน์ ฐานข้อมูลจำลอง) =================
  await boot('#home');
  const T0 = await page.evaluate(() => { const T = Date.now(); const mem = __mock.mem; const g = generateMap('forest', 's1');
    mem.maps.m1 = { id: 'm1', ownerId: 'u1', ownerName: 'นน', name: 'ป่าหมอก', cells: g.cells, kind: g.kind, npcs: [], published: true, updatedAt: T - 5000 };
    mem.maps.m1p = { id: 'm1p', ownerId: 'u1', ownerName: 'นน', name: 'ร่างส่วนตัว', cells: g.cells, kind: g.kind, npcs: [], published: false, updatedAt: T - 6000 };
    mem.maps.n1 = { id: 'n1', type: 'npc', ownerId: 'u1', ownerName: 'นน', name: 'ยาม', hp: 10, published: true, updatedAt: T - 4000 };
    mem.maps['rvbook-u1'] = { id: 'rvbook-u1', type: 'reviews', published: true, ownerId: 'u1', ownerName: 'นน', items: { m2: { t: 'map', s: 4, x: 'ดี', at: T } }, updatedAt: T - 3000 };
    mem.maps.m2 = { id: 'm2', ownerId: 'u2', ownerName: 'ลุงหมี', name: 'ท่าเรือ', cells: g.cells, kind: g.kind, npcs: [], published: true, updatedAt: T - 2000 };
    mem.maps['prof-u2'] = { id: 'prof-u2', type: 'profile', published: true, ownerId: 'u2', ownerName: 'ลุงหมี', name: 'ลุงหมี', bio: 'GM สายสยองขวัญ เปิดโต๊ะทุกคืนวันศุกร์\nรับผู้เล่นใหม่เสมอ', createdAt: T - 9000, updatedAt: T - 9000 };
    mem.maps['prof-u2~old'] = { id: 'prof-u2~old', type: 'profile', published: true, ownerId: 'u2', ownerName: 'ชื่อเก่า', name: 'ชื่อเก่า', bio: 'เล่มเก่า', createdAt: 1, updatedAt: 2 };
    mem.maps['prof-u3'] = { id: 'prof-u3', type: 'profile', published: true, ownerId: 'u9', ownerName: 'ตัวปลอม', name: 'ตัวปลอม', bio: 'รหัสไม่ตรงเจ้าของ', updatedAt: T };   // คนอื่นสร้างทับรหัสของ u3
    mem.maps['prof-u6'] = { id: 'prof-u6', type: 'profile', published: false, ownerId: 'u6', ownerName: 'ซ่อน', name: 'ซ่อน', bio: 'ไม่เผยแพร่', updatedAt: T };
    return T; });
  const pf = await page.evaluate(async () => { const out = {}; asUser('u1', 'นน');
    await ProfileLib.boot(); out.none = ProfileLib.mine === null && ProfileLib.loaded && Store.displayName === 'นน';
    location.hash = '#profile'; await new Promise(r => setTimeout(r, 300));
    out.acct = document.querySelector('.pf-acct').textContent; out.val = document.querySelector('.pf-name').value;
    const n = document.querySelector('.pf-name'), b = document.querySelector('.pf-bio'); n.value = 'นน ผู้เล่าเรื่อง'; b.value = 'ชอบเล่นสายสืบสวน\nว่างเสาร์อาทิตย์'; n.dispatchEvent(new Event('input'));
    document.querySelector('.pf-save').click(); await new Promise(r => setTimeout(r, 400));
    const d = __mock.mem.maps['prof-u1']; out.doc = d && [d.type, d.published, d.ownerId, d.ownerName, d.name, d.bio, d.createdAt === d.updatedAt].join('|');
    out.name = Store.displayName; out.base = Store.baseName; out.head = document.querySelector('#online a.acct').textContent; out.local = JSON.parse(localStorage.getItem('kirana.profile.v1'));
    out.owners = ['m1', 'm1p', 'n1', 'rvbook-u1', 'm2'].map(k => __mock.mem.maps[k].ownerName).join('|'); out.updated = __mock.mem.maps.m1.updatedAt === __mock.mem.maps.m2.updatedAt - 3000;
    out.denied = __mock.log.denied.slice(); out.toast = document.querySelector('#toast').textContent; out.reset = !!document.querySelector('.pf-reset');
    // แก้อีกครั้ง: เอกสารเดิม ไม่สร้างเล่มใหม่ เวลาเริ่มคงเดิม
    const first = d.createdAt; const r2 = await ProfileLib.save('นน ผู้เล่าเรื่อง', 'แก้คำอธิบายอย่างเดียว'); const d2 = __mock.mem.maps['prof-u1'];
    out.second = [r2.ok, r2.renamed, d2.bio, d2.createdAt === first, Object.keys(__mock.mem.maps).filter(k => k.startsWith('prof-u1')).length].join('|');
    return out; });
  ok('online: no profile yet means the account name is used', pf.none && /บัญชี Google · ชื่อจากบัญชี: นน/.test(pf.acct) && pf.val === 'นน', pf);
  ok('saving writes one profile document owned by the user', pf.doc === 'profile|true|u1|นน ผู้เล่าเรื่อง|นน ผู้เล่าเรื่อง|ชอบเล่นสายสืบสวน\nว่างเสาร์อาทิตย์|true' && pf.denied.length === 0, [pf.doc, pf.denied]);
  ok('the new name is used across the site and the account name is kept aside', pf.name === 'นน ผู้เล่าเรื่อง' && pf.base === 'นน' && pf.head === 'นน ผู้เล่าเรื่อง' && pf.local.uid === 'u1' && pf.reset, pf);
  ok('published works, the review book and private drafts of the user carry the new name, other people are untouched', pf.owners === 'นน ผู้เล่าเรื่อง|นน ผู้เล่าเรื่อง|นน ผู้เล่าเรื่อง|นน ผู้เล่าเรื่อง|ลุงหมี' && pf.updated && /3 รายการ|4 รายการ/.test(pf.toast), [pf.owners, pf.toast]);
  ok('editing again reuses the same document', pf.second === 'true|0|แก้คำอธิบายอย่างเดียว|true|1', pf.second);
  await shot('200-profile-v120.png');
  const pf2 = await page.evaluate(async () => { const out = {};
    // เปิดเว็บใหม่ด้วยบัญชีเดิม: ชื่อโปรไฟล์กลับมาจากฐานข้อมูล
    asUser('u1', 'นน'); out.before = Store.displayName; await ProfileLib.boot(); out.after = Store.displayName; out.id = ProfileLib.mine && ProfileLib.mine.id;
    // โปรไฟล์ของคนอื่น: เล่มที่แก้ล่าสุดของเจ้าของจริง · เอกสารที่คนอื่นสร้างทับรหัสไม่นับ · เอกสารที่ไม่เผยแพร่ไม่เห็น
    const p2 = await ProfileLib.get('u2'), p3 = await ProfileLib.get('u3'), p6 = await ProfileLib.get('u6'), p0 = await ProfileLib.get('nobody');
    out.others = [p2 && p2.name, p2 && p2.id, p3, p6, p0].join('|');
    const q = __mock.log.queries.length; await ProfileLib.get('u2'); out.cached = __mock.log.queries.length === q;
    // รหัสตามแบบถูกสร้างทับ: ใช้รหัสสำรอง
    asUser('u3', 'ฟ้าใส'); await ProfileLib.boot(); out.u3none = ProfileLib.mine === null;
    const r = await ProfileLib.save('ฟ้าใสตัวจริง', ''); const ids = Object.keys(__mock.mem.maps).filter(k => __mock.mem.maps[k].ownerId === 'u3' && __mock.mem.maps[k].type === 'profile');
    out.fallback = [r.ok, ids.length, /^prof-u3~[a-z0-9]{8}$/.test(ids[0] || ''), __mock.mem.maps['prof-u3'].ownerId, __mock.log.denied.length].join('|');
    asUser('u1', 'นน'); const again = await ProfileLib.get('u3'); out.u3seen = again && again.name;
    // ลบโปรไฟล์: เอกสารหาย ชื่อกลับเป็นชื่อบัญชี ผลงานตามกลับ
    await ProfileLib.boot(); const rr = await ProfileLib.remove(); out.removed = [rr.ok, !('prof-u1' in __mock.mem.maps), Store.displayName, __mock.mem.maps.m1.ownerName, localStorage.getItem('kirana.profile.v1')].join('|');
    // บัญชีนิรนามตั้งโปรไฟล์ได้ (Rules ไม่ห้าม) และหน้าบอกว่าผูกกับเบราว์เซอร์นี้
    asUser('anon7', 'ผู้เล่น-ab12', { anon: true }); await ProfileLib.boot(); location.hash = '#home'; await new Promise(r => setTimeout(r, 100)); location.hash = '#profile'; await new Promise(r => setTimeout(r, 300));
    out.anonAcct = document.querySelector('.pf-acct').textContent; const ra = await ProfileLib.save('นิรนามมีชื่อ', ''); out.anon = [ra.ok, !!__mock.mem.maps['prof-anon7'], document.querySelector('#online a.acct').textContent].join('|');
    // เขียนไม่ได้: บอกเหตุ ไม่เปลี่ยนชื่อ
    asUser('u4', 'ก้อง'); await ProfileLib.boot(); __mock.state.failWrites = true; const rf = await ProfileLib.save('ชื่อใหม่', ''); __mock.state.failWrites = false; out.fail = [rf.ok, /ลองใหม่/.test(rf.msg || ''), Store.displayName, ProfileLib.mine === null].join('|');
    return out; });
  ok('a fresh session picks the profile name up from the database', pf2.before === 'นน' && pf2.after === 'นน ผู้เล่าเรื่อง' && pf2.id === 'prof-u1', pf2);
  ok('other profiles: newest real document wins, squatted and unpublished ones are ignored, answers are cached', pf2.others === 'ลุงหมี|prof-u2|||' && pf2.cached, pf2.others);
  ok('a squatted id falls back to a spare id and identity still follows ownerId', pf2.u3none && pf2.fallback === 'true|1|true|u9|1' && pf2.u3seen === 'ฟ้าใสตัวจริง', [pf2.fallback, pf2.u3seen]);
  ok('deleting the profile restores the account name everywhere', pf2.removed === 'true|true|นน|นน|', pf2.removed);
  ok('anonymous accounts can name themselves and are told the profile stays with this browser', /บัญชีนิรนาม/.test(pf2.anonAcct) && pf2.anon === 'true|true|นิรนามมีชื่อ (นิรนาม)', [pf2.anonAcct, pf2.anon]);
  ok('a failed write changes nothing and says so', pf2.fail === 'false|true|ก้อง|true', pf2.fail);

  // ================= G) ข้อ 5 และ 9: แชตกลาง =================
  const gc = await page.evaluate(async (T0) => { const out = {}; const mem = __mock.mem; const today = gcDay(), T = Date.now();
    const yest = gcDay(T - 86400000);
    mem.maps['gchat-u2'] = { id: 'gchat-u2', type: 'gchat', published: true, ownerId: 'u2', ownerName: 'ลุงหมี', day: today, msgs: [{ t: T - 600000, x: 'มีใครเปิดโต๊ะคืนนี้ไหมครับ' }, { t: T - 300000, x: 'หาผู้เล่นอีกสองคน แคมเปญลักซอนเนีย' }], updatedAt: T };
    mem.maps['gchat-dev1'] = { id: 'gchat-dev1', type: 'gchat', published: true, ownerId: 'dev1', ownerName: 'Non', day: today, msgs: [{ t: T - 200000, x: 'v1.20 ขึ้นแล้ว ลองแชตกลางกันได้' }], updatedAt: T };
    mem.maps['gchat-u5'] = { id: 'gchat-u5', type: 'gchat', published: true, ownerId: 'u5', ownerName: 'คนเมื่อวาน', day: yest, msgs: [{ t: T - 90000000, x: 'ข้อความของเมื่อวาน' }], updatedAt: T - 90000000 };
    mem.maps['gchat-u1'] = { id: 'gchat-u1', type: 'gchat', published: true, ownerId: 'u1', ownerName: 'นน', day: yest, msgs: [{ t: T - 90000000, x: 'ของฉันเมื่อวาน' }], updatedAt: T - 90000000 };
    mem.maps['gchat-zz'] = { id: 'gchat-zz', type: 'gchat', published: true, ownerId: 'u9', ownerName: 'Non', day: today, msgs: [{ t: T - 1000, x: 'ปลอมรหัส' }], updatedAt: T };
    mem.maps['gchat-u8'] = { id: 'gchat-u8', type: 'gchat', published: true, ownerId: 'u8', ownerName: { a: 1 }, day: today, msgs: [{ t: 'x', x: 5 }, { t: T - 500000, x: '<b>ตัวหนา</b>' }], updatedAt: T };
    asUser('u1', 'นน'); location.hash = '#home'; await new Promise(r => setTimeout(r, 100)); location.hash = '#table'; await new Promise(r => setTimeout(r, 500));
    const rows = () => [...document.querySelectorAll('.gc-msg')].map(e => ({ uid: e.dataset.uid, who: e.querySelector('.uname').textContent, gold: e.querySelector('.uname').classList.contains('devname'), text: e.querySelector('.gc-text').textContent, del: !!e.querySelector('.gc-del') }));
    out.panel = !!document.querySelector('.lobby-home .lobby-chat .gchat'); out.rows = rows(); out.info = document.querySelector('.gc-reset').textContent; out.blk = document.querySelector('.gc-blk').classList.contains('hidden'); out.row = !document.querySelector('.gc-row').classList.contains('hidden');
    out.html = document.querySelector('.gc-log').querySelector('b') === null;
    out.myOld = 'gchat-u1' in mem.maps; out.otherOld = 'gchat-u5' in mem.maps; out.subs = __mock.subs.filter(s => s.filters.some(f => f[0] === 'type' && f[1] === 'gchat')).map(s => s.filters.map(f => f.join('=')).join('&'));
    // ส่งข้อความด้วยช่องพิมพ์จริง
    const inp = document.querySelector('.gc-inp'); inp.value = '  สวัสดีครับ   ผมเพิ่งมาใหม่  '; document.querySelector('.gc-send').click(); await new Promise(r => setTimeout(r, 300));
    const d = mem.maps['gchat-u1']; out.doc = d && [d.type, d.published, d.ownerId, d.ownerName, d.day === today, d.msgs.length, d.msgs[0].x].join('|'); out.cleared = inp.value === ''; out.top = rows()[0];
    // ส่งถี่เกิน
    const fast = await GChat.send('เร็วไป'); out.fast = fast.ok === false && /เร็วเกินไป/.test(fast.msg || '');
    GChat.lastSend = 0; const long = await GChat.send('ก'.repeat(500)); out.long = [long.ok, mem.maps['gchat-u1'].msgs.length, mem.maps['gchat-u1'].msgs[1].x.length].join('|');
    GChat.lastSend = 0; const blank = await GChat.send('   '); out.blank = blank.ok === false && !blank.msg;
    // คนอื่นพิมพ์เข้ามา: ขึ้นเองโดยไม่ต้องโหลดหน้าใหม่
    mem.maps['gchat-u2'].msgs.push({ t: T + 5000, x: 'ยินดีต้อนรับครับ' }); __mock.fire('maps'); await new Promise(r => setTimeout(r, 100)); out.live = rows()[0].text;
    out.order = rows().map(r => r.text.slice(0, 6)).join('/');
    return out; }, T0);
  ok('the lobby shows the shared chat with today\'s messages only', gc.panel && gc.rows.length === 4 && !gc.rows.some(r => /เมื่อวาน|ปลอมรหัส/.test(r.text)) && /ล้างทุกเที่ยงคืนเวลาไทย · อีก (\d+ ชม\. )?\d+ นาที/.test(gc.info), [gc.rows.map(r => r.text), gc.info]);
  ok('the listener asks for published chat documents of the Thai day', gc.subs.length === 1 && /^published=true&type=gchat&day=\d{4}-\d\d-\d\d$/.test(gc.subs[0]), gc.subs);
  ok('developer name is gold, by account id and never by name', gc.rows.filter(r => r.gold).map(r => r.uid).join() === 'dev1' && gc.rows.find(r => r.uid === 'dev1').who === 'Non:', gc.rows);
  ok('text from the database is shown as text', gc.html && gc.rows.some(r => r.text === '<b>ตัวหนา</b>') && gc.rows.find(r => r.uid === 'u8').who === 'ผู้เล่น:', gc.rows);
  ok('my own stale document is removed when the lobby opens, other people\'s is left for them or the developer', gc.myOld === false && gc.otherOld === true, [gc.myOld, gc.otherOld]);
  ok('sending writes my one document for today, trims the text and clears the box', gc.doc === 'gchat|true|u1|นน|true|1|สวัสดีครับ ผมเพิ่งมาใหม่' && gc.cleared && gc.top.text === 'สวัสดีครับ ผมเพิ่งมาใหม่' && gc.top.del && gc.blk && gc.row, [gc.doc, gc.top]);
  ok('rate limit, length cap and blank messages', gc.fast && gc.long === 'true|2|300' && gc.blank, [gc.fast, gc.long, gc.blank]);
  ok('messages from others arrive live, newest first', gc.live === 'ยินดีต้อนรับครับ' && gc.otherOld === true, [gc.live, gc.order]);
  await shot('201-lobby-chat-v120.png');
  const gc2 = await page.evaluate(async () => { const out = {}; const mem = __mock.mem;
    // โครงหน้าคงเดิมเมื่อวาดใหม่: ข้อความที่พิมพ์ค้างและชื่อห้องไม่หาย
    const home = document.querySelector('.lobby-home'), inp = document.querySelector('.gc-inp'), nameInp = document.querySelector('.lobby-home input[placeholder^="ชื่อห้อง"]');
    inp.value = 'พิมพ์ค้างไว้'; nameInp.value = 'คืนวันสถาปนา'; inp.focus(); renderTableHome(); renderTableHome();
    out.same = document.querySelector('.lobby-home') === home && document.querySelector('.gc-inp') === inp && inp.value === 'พิมพ์ค้างไว้' && nameInp.isConnected && nameInp.value === 'คืนวันสถาปนา' && document.activeElement === inp;
    out.oneSub = __mock.subs.filter(s => s.filters.some(f => f[1] === 'gchat')).length;
    inp.value = '';
    // ลบข้อความของตัวเอง
    const mine = [...document.querySelectorAll('.gc-msg.me')]; out.mineN = mine.length; mine[0].querySelector('.gc-del').click(); await new Promise(r => setTimeout(r, 200));
    out.afterDel = mem.maps['gchat-u1'].msgs.length; GChat.lastSend = 0;
    await GChat.removeMsg('u1', mem.maps['gchat-u1'].msgs[0].t); await new Promise(r => setTimeout(r, 100)); out.gone = !('gchat-u1' in mem.maps);
    // ผู้เล่นทั่วไปลบของคนอื่นไม่ได้
    out.noDel = [...document.querySelectorAll('.gc-msg')].filter(e => e.dataset.uid !== 'u1').every(e => !e.querySelector('.gc-del')); out.cant = await GChat.removeMsg('u2', mem.maps['gchat-u2'].msgs[0].t); out.u2n = mem.maps['gchat-u2'].msgs.length;
    // กดชื่อ: หน้าต่างโปรไฟล์ของคนนั้น
    document.querySelector('.gc-msg[data-uid="u2"] .uname').click(); await new Promise(r => setTimeout(r, 300));
    const box = document.querySelector('#modal .pfbox'); out.pop = box && [box.dataset.uid, box.querySelector('.uname').textContent, (box.querySelector('.pf-biotext') || {}).textContent, box.querySelector('.devname') === null].join('|');
    return out; });
  ok('re-rendering the lobby keeps the same elements, typed text, focus and a single listener', gc2.same && gc2.oneSub === 1, gc2);
  ok('I can delete my own messages, the document goes when the last one goes', gc2.mineN === 2 && gc2.afterDel === 1 && gc2.gone, gc2);
  ok('players cannot delete other people\'s messages', gc2.noDel && gc2.cant === false && gc2.u2n === 3, gc2);
  ok('clicking a name opens that person\'s profile', gc2.pop === 'u2|ลุงหมี|GM สายสยองขวัญ เปิดโต๊ะทุกคืนวันศุกร์\nรับผู้เล่นใหม่เสมอ|true', gc2.pop);
  await shot('202-profile-popup-v120.png');
  const gc3 = await page.evaluate(async () => { const out = {}; const mem = __mock.mem; modal(null);
    // บัญชีนิรนาม: อ่านได้ พิมพ์ไม่ได้ มีปุ่มเข้าสู่ระบบ
    asUser('anon7', 'ผู้เล่น-ab12', { anon: true }); Store.login = () => { window.__login = (window.__login || 0) + 1; }; location.hash = '#home'; await new Promise(r => setTimeout(r, 80)); location.hash = '#table'; await new Promise(r => setTimeout(r, 400));
    const blk = document.querySelector('.gc-blk'); out.anon = [document.querySelectorAll('.gc-msg').length, blk.classList.contains('hidden'), blk.dataset.code, document.querySelector('.gc-row').classList.contains('hidden'), !!blk.querySelector('button')].join('|');
    blk.querySelector('button').click(); out.login = window.__login; const ra = await GChat.send('ลองพิมพ์'); out.anonSend = ra.ok === false && /Google/.test(ra.msg) && !Object.keys(mem.maps).some(k => mem.maps[k].ownerId === 'anon7' && mem.maps[k].type === 'gchat');
    // ผู้พัฒนา: ลบข้อความของคนอื่นได้ทีละข้อความ และล้างเอกสารของวันก่อนของทุกบัญชี
    asUser('dev1', 'Non'); location.hash = '#home'; await new Promise(r => setTimeout(r, 80)); location.hash = '#table'; await new Promise(r => setTimeout(r, 500));
    out.devDel = [...document.querySelectorAll('.gc-msg')].every(e => !!e.querySelector('.gc-del')); out.purged = !('gchat-u5' in mem.maps);
    const before = mem.maps['gchat-u2'].msgs.length; document.querySelector('.gc-msg[data-uid="u2"] .gc-del').click(); await new Promise(r => setTimeout(r, 200));
    out.modded = [before, mem.maps['gchat-u2'].msgs.length, mem.maps['gchat-u2'].ownerId].join('|'); out.head = document.querySelector('#online a.acct').className.includes('devname');
    // รหัสตามแบบถูกคนอื่นสร้างทับ: ใช้รหัสสำรอง ชื่อสีทองยังดูจาก ownerId
    asUser('u4', 'ก้อง'); mem.maps['gchat-u4'] = { id: 'gchat-u4', type: 'gchat', published: true, ownerId: 'u9', ownerName: 'ตัวปลอม', day: gcDay(), msgs: [{ t: 5, x: 'ทับรหัส' }], updatedAt: 1 };
    location.hash = '#home'; await new Promise(r => setTimeout(r, 80)); location.hash = '#table'; await new Promise(r => setTimeout(r, 400));
    const rs = await GChat.send('ข้อความของก้อง'); const mineIds = Object.keys(mem.maps).filter(k => mem.maps[k].ownerId === 'u4' && mem.maps[k].type === 'gchat'); await new Promise(r => setTimeout(r, 100));
    out.fallback = [rs.ok, mineIds.length, /^gchat-u4~[a-z0-9]{8}$/.test(mineIds[0] || ''), [...document.querySelectorAll('.gc-msg')].some(e => e.dataset.uid === 'u4' && e.querySelector('.gc-text').textContent === 'ข้อความของก้อง')].join('|');
    // คนทั่วไปเขียนเอกสารในชื่อผู้พัฒนาไม่ได้ (Rules) สีทองจึงปลอมไม่ได้
    let forged = 'ok'; try { await Store.db.doc('maps/gchat-fake').set({ id: 'gchat-fake', type: 'gchat', published: true, ownerId: 'dev1', ownerName: 'Non', day: gcDay(), msgs: [{ t: 9, x: 'ปลอมเป็นผู้พัฒนา' }] }); } catch (e) { forged = e.code; } out.forged = forged;
    let steal = 'ok'; try { await Store.db.doc('maps/gchat-u2').update({ ownerId: 'u4' }); } catch (e) { steal = e.code; } out.steal = steal;
    return out; });
  ok('anonymous accounts read the chat and are asked to sign in before typing', gc3.anon.split('|')[0] >= '3' && /\|false\|anon\|true\|true$/.test(gc3.anon) && gc3.login === 1 && gc3.anonSend, gc3);
  ok('the developer can delete any single message and clears yesterday\'s documents of everyone', gc3.devDel && gc3.purged && gc3.modded === '3|2|u2' && gc3.head, gc3);
  ok('a squatted chat id falls back to a spare id', gc3.fallback === 'true|1|true|true', gc3.fallback);
  ok('the rules refuse a chat document written in the developer\'s name or a change of owner', gc3.forged === 'permission-denied' && gc3.steal === 'permission-denied', [gc3.forged, gc3.steal]);
  // ข้ามเที่ยงคืนเวลาไทย: แชตเปลี่ยนไปฟังวันใหม่ ข้อความของวันก่อนไม่ขึ้นอีก
  const roll = await page.evaluate(async () => { const out = {}; const mem = __mock.mem; asUser('u1', 'นน'); location.hash = '#home'; await new Promise(r => setTimeout(r, 80)); location.hash = '#table'; await new Promise(r => setTimeout(r, 400));
    GChat.lastSend = 0; await GChat.send('ก่อนเที่ยงคืน'); await new Promise(r => setTimeout(r, 100)); out.before = document.querySelectorAll('.gc-msg').length; out.day1 = GChat.day;
    const real = Date.now; const jump = gcMsToMidnight() + 60000; Date.now = () => real() + jump;
    GChat.start(); await new Promise(r => setTimeout(r, 200)); out.day2 = GChat.day; out.after = document.querySelectorAll('.gc-msg').length; out.empty = (document.querySelector('.gc-empty') || {}).textContent;
    out.subs = __mock.subs.filter(s => s.filters.some(f => f[1] === 'gchat')).map(s => s.filters.find(f => f[0] === 'day')[1]).join();
    GChat.lastSend = 0; const r = await GChat.send('หลังเที่ยงคืน'); await new Promise(r => setTimeout(r, 100)); const d = mem.maps['gchat-u1'];
    out.newDay = [r.ok, d.day === GChat.day, d.msgs.length, d.msgs[0].x, document.querySelectorAll('.gc-msg').length].join('|');
    Date.now = real; location.hash = '#home'; await new Promise(r => setTimeout(r, 150)); out.stopped = __mock.subs.filter(s => s.filters.some(f => f[1] === 'gchat')).length === 0 && GChat.day === null;
    return out; });
  ok('past Thai midnight the chat starts empty and yesterday\'s messages are not shown', roll.before >= 1 && roll.day1 !== roll.day2 && roll.after === 0 && /ยังไม่มีใครพิมพ์/.test(roll.empty || '') && roll.subs === roll.day2, roll);
  ok('the first message of the new day replaces my old document', roll.newDay === 'true|true|1|หลังเที่ยงคืน|1', roll.newDay);
  ok('leaving the lobby stops the listener', roll.stopped, roll);

  // ================= H) ข้อ 9: ชื่อสีทองของผู้พัฒนาในแชตของห้องและรายชื่อคนออนไลน์ =================
  const gold = await page.evaluate(async () => { const out = {};
    out.fn = [uidIsDev('dev1'), uidIsDev('u1'), uidIsDev(''), uidIsDev(null), uidIsDev({})].join();
    const a = chatWho({ who: 'GM', authorId: 'dev1' }), b = chatWho({ who: 'นักดาบ', authorId: 'u2' }, ': '), c = chatWho({ who: 'Non', authorId: 'u9' }), d = chatWho(null);
    out.who = [a.className, a.title, a.textContent, b.className, b.textContent, c.className, d.textContent].join('|');
    // รายชื่อคนออนไลน์: สีทองและป้ายผู้พัฒนาดูจากรหัสบัญชี ไม่เชื่อธง dev ที่เจ้าของเขียนเอง
    Store.onlineUsers = [{ uid: 'dev1', name: 'Non', at: Date.now() }, { uid: 'u9', name: 'Non', dev: true, at: Date.now() }, { uid: 'u2', name: 'ลุงหมี', at: Date.now() }]; updateOnline();
    document.querySelector('#online .onl').click(); await new Promise(r => setTimeout(r, 150));
    out.onl = [...document.querySelectorAll('.onl-pop .onl-row')].map(r => [r.querySelector('.uname').textContent, r.querySelector('.uname').classList.contains('devname'), [...r.querySelectorAll('.tag')].map(t => t.textContent).join('+')].join(':')).join('|');
    document.querySelector('.onl-pop .onl-row .uname').click(); await new Promise(r => setTimeout(r, 200)); out.pop = !!document.querySelector('#modal .pfbox[data-uid="dev1"] .devname'); modal(null); document.querySelector('#online .onl').click();
    return out; });
  ok('uidIsDev reads the developer list', gold.fn === 'true,false,false,false,false', gold.fn);
  ok('room chat speaker: gold when the message came from a developer account', gold.who === 'who devname|ผู้พัฒนา|GM|who|นักดาบ: |who|', gold.who);
  ok('online list: gold and the developer tag follow the account id', gold.onl === 'Non:true:ผู้พัฒนา|Non:false:|ลุงหมี:false:' && gold.pop, gold.onl);
  // ห้องในเครื่อง: ข้อความที่บัญชีผู้พัฒนาส่งขึ้นชื่อสีทองในแชตของห้อง
  await page.goto(url + '#table'); await page.reload(); await wait(600);
  const room = await page.evaluate(async () => { const out = {};
    out.offChat = [!!document.querySelector('.gchat'), (document.querySelector('.gc-empty') || {}).textContent, document.querySelector('.gc-row').classList.contains('hidden'), document.querySelector('.gc-blk').classList.contains('hidden')].join('|');
    document.querySelector('.lobby-home input[placeholder^="ชื่อห้อง"]').value = 'ห้องทดสอบสีทอง'; [...document.querySelectorAll('.lobby-home button')].find(b => /สร้างห้อง/.test(b.textContent)).click(); await new Promise(r => setTimeout(r, 700));
    Store.site = { devUids: ['local'] };
    await Table.post({ kind: 'say', who: 'GM', text: 'ข้อความจากผู้พัฒนา' }); Table.chat.unshift({ id: 'x1', ts: Date.now(), kind: 'say', who: 'ผู้เล่นคนอื่น', text: 'ข้อความจากผู้เล่น', authorId: 'someone' }); renderChatOnly();
    out.rows = [...document.querySelectorAll('#chatlog .e')].map(e => { const w = e.querySelector('.who'); return w ? w.textContent + (w.classList.contains('devname') ? '[gold]' : '') : '-'; }).join('|');
    const e = doRoll({ label: 'ทดสอบทอย' }); Table.postRoll(e, null); await new Promise(r => setTimeout(r, 200)); const first = document.querySelector('#chatlog .e .who'); out.roll = first.classList.contains('devname');
    Store.site = null; renderChatOnly(); out.none = document.querySelectorAll('#chatlog .devname').length;
    Table.close(); location.hash = '#table'; await new Promise(r => setTimeout(r, 300)); out.back = !!document.querySelector('.lobby-home .gchat') && document.querySelectorAll('.lobby-home .card.pick').length === 1;
    return out; });
  ok('offline lobby: the chat panel explains itself and has no input', room.offChat === 'true|โหมดออฟไลน์ไม่มีแชตกลาง|true|true', room.offChat);
  ok('room chat: developer messages are gold, players are not, rolls included', room.rows === 'ผู้เล่นคนอื่น: |GM: [gold]' && room.roll && room.none === 0, room);
  ok('coming back from a room rebuilds the lobby with the chat panel', room.back, room);

  // ================= I) หน้า นโยบาย เมนู และจอแคบ =================
  const misc = await page.evaluate(async () => { const out = {}; location.hash = '#policy'; await new Promise(r => setTimeout(r, 300)); const t = document.querySelector('#v-policy').textContent;
    out.policy = [/โปรไฟล์: ชื่อโปรไฟล์และคำอธิบายตัวเอง/.test(t), /แชตกลาง: ข้อความที่คุณพิมพ์/.test(t), /ชื่อของบัญชีผู้พัฒนาขึ้นเป็นสีทองในแชต/.test(t), /ข้อความถูกล้างทุกเที่ยงคืนตามเวลาไทย/.test(t), /แก้หรือลบโปรไฟล์ได้/.test(t), /แชตกลางเป็นพื้นที่ส่วนรวม/.test(t), /ลบข้อความในแชตกลาง/.test(t), /ปรับปรุงล่าสุด 13 พฤศจิกายน 2026/.test(t)].join();
    out.nav = [...document.querySelectorAll('#nav a')].map(a => a.getAttribute('href')).join(); out.views = !!document.querySelector('#v-profile');
    location.hash = '#profile'; await new Promise(r => setTimeout(r, 300)); out.active = document.querySelector('#v-profile').classList.contains('active') && !!document.querySelector('.pf-form');
    location.hash = '#nonsense'; await new Promise(r => setTimeout(r, 200)); out.fallback = document.querySelector('#v-home').classList.contains('active');
    return out; });
  ok('policy page covers the profile, the shared chat and the gold name', misc.policy === Array(8).fill('true').join(), misc.policy);
  ok('menu unchanged, #profile is a page of its own', misc.nav === '#home,#create,#chars,#table,#maps,#npcs,#rules,#dev' && misc.views && misc.active && misc.fallback, misc);
  await boot('#home');
  await page.setViewportSize({ width: 420, height: 900 });
  const mob = await page.evaluate(async () => { const mem = __mock.mem; const T = Date.now();
    mem.maps['gchat-u2'] = { id: 'gchat-u2', type: 'gchat', published: true, ownerId: 'u2', ownerName: 'ลุงหมี', day: gcDay(), msgs: [{ t: T - 600000, x: 'ข้อความยาวมาก ๆ เพื่อดูการตัดบรรทัดบนจอแคบว่ายังอ่านได้และปุ่มลบไม่ล้นออกนอกกรอบของกล่องแชต' }], updatedAt: T };
    mem.maps['gchat-dev1'] = { id: 'gchat-dev1', type: 'gchat', published: true, ownerId: 'dev1', ownerName: 'Non', day: gcDay(), msgs: [{ t: T - 200000, x: 'ทดสอบจอมือถือ' }], updatedAt: T };
    asUser('u1', 'นน'); location.hash = '#table'; await new Promise(r => setTimeout(r, 500));
    const w = document.documentElement.clientWidth; const el = document.querySelector('.gchat').getBoundingClientRect();
    return { fits: el.left >= 0 && el.right <= w + 1, overflow: document.documentElement.scrollWidth <= w + 1, below: document.querySelector('.lobby-chat').getBoundingClientRect().top > document.querySelector('.lobby-rooms').getBoundingClientRect().top }; });
  ok('narrow screens: the chat sits under the room list and nothing overflows', mob.fits && mob.overflow && mob.below, mob);
  await shot('203-lobby-chat-mobile-v120.png');
  await page.setViewportSize({ width: 1400, height: 1000 });

  ok('no page errors', errors.length === 0, errors);
  ok('no blocking dialogs were needed', dialogs.length === 0, dialogs);
  console.log(`v120: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
