// v1.7: ชื่อเว็บอ่านง่าย ชีทกระดาษ หน้าต่าง HUD ห้อง (แชตใต้แผนที่ แท็บทอยลอย หน้าปัดไม่เด้ง/ปิดไม่ได้ Toughness บนโต๊ะ)
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  await page.screenshot({ path: 'test/100-home.png', clip: {x:0,y:0,width:1400,height:420} });
  console.log('brand:', await page.$eval('.brand', e => e.textContent.trim().replace(/\s+/g,' ')), 'font:', await page.$eval('.brand', e => getComputedStyle(e).fontFamily.split(',')[0]));
  await page.evaluate(() => { const K = window.__kirana; const cv = document.createElement('canvas'); cv.width = cv.height = 60; const ctx = cv.getContext('2d'); ctx.fillStyle = '#a63'; ctx.fillRect(0,0,60,60); const thumb = cv.toDataURL();
    const mk = (id, name, kin) => ({ id, name, kin, size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{lore:2}, prof:{}, skills:['Yantra Master'], details:{}, done:true, step:7, portrait: thumb, starterSet:'The Vanguard' });
    K.Store.upsert(mk('s17', 'อัศวินกระดาษ', 'lunaryn')); });
  await page.goto(url + '#sheet-s17'); await page.waitForTimeout(600);
  await page.screenshot({ path: 'test/101-sheet-paper.png', fullPage: true });
  console.log('paper sheet:', await page.evaluate(() => { const v = document.querySelector('#v-sheet'); const cs = getComputedStyle(v); const card = getComputedStyle(v.querySelector('.box, .card')); return {text: cs.color, ink: cs.getPropertyValue('--ink').trim(), cardBg: card.backgroundColor, scheme: cs.colorScheme, bodyText: getComputedStyle(document.body).color}; }));
  // HUD windows
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/102-hud-bag.png' });
  await page.click('.hud-btn[title="ถุงย่าม"]'); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/103-hud-pouch.png' });
  await page.click('.hud-btn[title="คัมภีร์"]'); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/104-hud-book.png' });
  await page.click('.hud-btn[title="ทอยเต๋า"]'); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/105-hud-dice.png' });
  // room
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้อง v1.7'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(400);
  await page.fill('input[placeholder="ชื่อ NPC/ศัตรู"]', 'โทรลล์'); await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(300);
  await page.evaluate(() => { Table.sel = Table.room.tokens[0].id; renderTable(); }); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/106-room.png', fullPage: true });
  // tough − via table
  const t0 = await page.evaluate(() => JSON.stringify({tok: Table.room.tokens[0].tough, sheet: window.__kirana.Store.get('s17').current.tough}));
  await page.click('#v-table .cp-t .tadj[title$="−1"]'); await page.waitForTimeout(300);
  const t1 = await page.evaluate(() => JSON.stringify({tok: Table.room.tokens[0].tough, sheet: window.__kirana.Store.get('s17').current.tough}));
  console.log('tough before:', t0); console.log('tough after −:', t1);
  // npc tough
  await page.evaluate(() => { Table.sel = Table.room.tokens[1].id; renderTable(); }); await page.waitForTimeout(300);
  await page.fill('#v-table .vital input[placeholder="สูงสุด"]', '3'); await page.press('#v-table .vital input[placeholder="สูงสุด"]', 'Tab'); await page.waitForTimeout(200);
  await page.click('#v-table .vital button[title="Toughness −1"]'); await page.waitForTimeout(200);
  console.log('npc tough:', await page.evaluate(() => JSON.stringify({tgh: Table.room.tokens[1].tgh, max: Table.room.tokens[1].tghMax})));
  // float dashboards + dice window
  await page.evaluate(() => { TWin.float.order = true; TWin.float.tok = true; TWin.dice = true; TWin.persist(); renderTable(); }); await page.waitForTimeout(400);
  await page.screenshot({ path: 'test/107-room-float.png' });
  // แผงทอยจำโหมดที่เลือกไว้แม้ห้องวาดใหม่ (ห้องอัปเดตจากคนอื่น)
  await page.click('#twins .twin-dice .dicepanel button:has-text("Advantage")'); await page.waitForTimeout(100);
  await page.evaluate(() => renderTable()); await page.waitForTimeout(150);
  console.log('dice mode kept after re-render:', await page.$eval('#twins .twin-dice .dicepanel button.primary', e => e.textContent));
  // re-render many times: positions must not jump
  const p0 = await page.$eval('#twins .twin-order', e => e.getBoundingClientRect().left + ',' + e.getBoundingClientRect().top);
  for (let i=0;i<5;i++){ await page.evaluate(() => renderTable()); await page.waitForTimeout(80); }
  const p1 = await page.$eval('#twins .twin-order', e => e.getBoundingClientRect().left + ',' + e.getBoundingClientRect().top);
  console.log('order win pos stable:', p0, '→', p1, p0===p1 ? 'OK' : 'JUMPED');
  // drag order window to a spot, re-render, check persisted
  const hb = await page.$('#twins .twin-order .hud-head b'); const bb = await hb.boundingBox();
  await page.mouse.move(bb.x+10, bb.y+5); await page.mouse.down(); await page.mouse.move(bb.x-500, bb.y+300, {steps:8}); await page.mouse.up(); await page.waitForTimeout(200);
  const p2 = await page.$eval('#twins .twin-order', e => Math.round(e.getBoundingClientRect().left) + ',' + Math.round(e.getBoundingClientRect().top));
  for (let i=0;i<3;i++){ await page.evaluate(() => renderTable()); await page.waitForTimeout(80); }
  const p3 = await page.$eval('#twins .twin-order', e => Math.round(e.getBoundingClientRect().left) + ',' + Math.round(e.getBoundingClientRect().top));
  console.log('after drag:', p2, 'after re-render:', p3, p2===p3 ? 'OK' : 'JUMPED', 'stored:', await page.evaluate(() => JSON.stringify(JSON.parse(localStorage.getItem('kirana.twin')).pos.order)));
  // reload page: window should come back at the same spot
  await page.reload(); await page.waitForTimeout(800);
  const p4 = await page.$eval('#twins .twin-order', e => Math.round(e.getBoundingClientRect().left) + ',' + Math.round(e.getBoundingClientRect().top));
  console.log('after reload:', p4, p4===p3 ? 'OK' : 'MOVED');
  console.log('close buttons on order/tok:', await page.$$eval('#twins .twin-order .hud-x, #twins .twin-tok .hud-x', es => es.map(e=>e.title)));
  await page.screenshot({ path: 'test/108-room-float2.png' });
  // HUD ในชีท: ตำแหน่งเสีย (0,0 ขนาด 0) ที่ค้างจากรุ่นก่อนต้องถูกทิ้งตอนโหลด
  await page.evaluate(() => { localStorage.setItem('kirana.hud', JSON.stringify({open:'bag', winPos:{bag:{x:0,y:0,w:0,h:0}}})); localStorage.setItem('kirana.twin', JSON.stringify({float:{order:true,tok:false}, pos:{order:{x:0,y:0,w:0,h:0}}})); });
  await page.reload(); await page.waitForTimeout(600);
  console.log('bad pos dropped:', await page.evaluate(() => ({hud: HUD.winPos.bag===undefined, twin: TWin.pos.order===undefined})), 'order win at:', await page.$eval('#twins .twin-order', e => { const r = e.getBoundingClientRect(); return Math.round(r.left)+','+Math.round(r.top); }));
  // narrow screen
  await page.setViewportSize({ width: 420, height: 860 }); await page.waitForTimeout(400);
  await page.screenshot({ path: 'test/109-room-mobile.png' });
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
