// v1.26c (ร่าง ยังไม่ขึ้นเว็บ · Non สั่ง 16 พ.ย. 2026): แก้ข้อความตำนานจากในเว็บ เฉพาะหลังบ้าน + แผนผังระบบพลัง
//  E) แผนผังระบบพลัง 4 ภาพอยู่ในบทความของมัน ข้อความไม่ล้นกรอบ
//  F) ตัวแปลงข้อความ: เนื้อบทความทุกบทแปลงไปกลับได้ตรงทุกตัวอักษร ตัวกรองไม่แตะต้นฉบับ
//  G) โหมดไฟล์ในเครื่อง: แถบหลังบ้าน หน้าแก้ ตัวอย่างสด บันทึก รีโหลดแล้วยังอยู่ คืนต้นฉบับ บันทึกโดยไม่แก้ไม่เกิดฉบับแก้
//  H) เพิ่มบทความใหม่ใต้เหตุการณ์ แล้วลบ · แก้คำนำและคำโปรยมหายุค · ส่งออกและนำเข้า JSON
//  I) คนที่ไม่ใช่ผู้พัฒนาไม่เห็นหลังบ้านเลย (เว็บตั้ง Firebase แต่เชื่อมไม่ติด และบัญชีทั่วไปบน Firebase)
//  J) Firestore จำลอง: เขียนไม่ผ่านเก็บเป็นร่าง ส่งร่างขึ้นได้ รูปแบบที่ส่งไม่มีอาร์เรย์ซ้อน อ่านล่าสุดก่อนเขียน
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail).slice(0, 900) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  const toastText = () => page.evaluate(() => document.getElementById('toast').textContent);
  const esc = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const fieldIn = (scope, lab, tag) => page.locator(scope + ' .le-field').filter({ has: page.locator('.le-lab', { hasText: new RegExp('^' + esc(lab) + '$') }) }).locator(tag).first();
  const fld = (lab, tag) => fieldIn('.le-form', lab, tag);
  await page.goto(url + '#lore'); await wait(600);
  await page.evaluate(() => localStorage.removeItem('kirana.codex.lore.v1'));
  const LORE_ERA0 = await page.evaluate(() => LORE_ERAS[0].id);

  // ================= E) แผนผังระบบพลัง =================
  for (const [aid, fid] of [['reset', 'resetcycle'], ['manaenclosure', 'twostate'], ['manaveil', 'veil'], ['gods', 'gods']]) {
    await page.goto(url + '#lore-' + aid); await wait(300);
    const E = await page.evaluate((fid) => { const fig = document.querySelector('.lore-art figure.lfig'); if (!fig) return null; const svg = fig.querySelector('svg'); const vb = svg.viewBox.baseVal;
      const over = [...svg.querySelectorAll('text')].map(t => { const b = t.getBBox(); return { t: t.textContent, x: b.x, y: b.y, r: b.x + b.width, b: b.y + b.height }; }).filter(b => b.x < -1 || b.y < -1 || b.r > vb.width + 1 || b.b > vb.height + 1);
      return { title: fig.querySelector('figcaption b').textContent, want: LORE_FIGS[fid].title, texts: svg.querySelectorAll('text').length, over, w: vb.width }; }, fid);
    ok('E: figure ' + fid + ' renders in ' + aid, E && E.title === E.want && E.texts >= 6 && E.over.length === 0 && E.w === 760, E);
  }

  // ================= F) ตัวแปลงข้อความ =================
  const F0 = await page.evaluate(() => { const bad = [], san = [];
    for (const [id, a] of Object.entries(LORE_BASE.articles)) {
      if (JSON.stringify(loreTextToBody(loreBodyToText(a.body))) !== JSON.stringify(a.body)) bad.push(id);
      if (JSON.stringify(loreTextToBox(loreBoxToText(a.box))) !== JSON.stringify(a.box || [])) bad.push(id + ':box');
      const s = loreSanitizeArticle(JSON.parse(JSON.stringify(a)), id);
      for (const k of ['kind', 'title', 'en', 'lead', 'era', 'parent', 'body', 'branches', 'game']) if (JSON.stringify(s[k]) !== JSON.stringify(a[k])) san.push(id + ':' + k);
      if (JSON.stringify(s.box) !== JSON.stringify(a.box || [])) san.push(id + ':box'); if (s.sub !== (a.sub || '')) san.push(id + ':sub'); }
    const tricky = [['p', '## ไม่ใช่หัวข้อ'], ['p', '- ไม่ใช่รายการ'], ['p', '> ไม่ใช่คำพูด'], ['p', '::fig veil'], ['p', '\\ทับขวา'], ['ul', ['ก', 'ข']], ['ul', ['ค']], ['q', 'คำพูดยาว', 'ผู้พูด'], ['q', 'ไม่มีผู้พูด'], ['fig', 'veil'], ['h', 'หัวข้อ'], ['p', 'ย่อหน้า [[syntyr|ซินไทร์]] ต่อ']];
    return { n: Object.keys(LORE_BASE.articles).length, bad, san, tricky: JSON.stringify(loreTextToBody(loreBodyToText(tricky))) === JSON.stringify(tricky),
      joined: JSON.stringify(loreTextToBody('บรรทัดแรก\nบรรทัดสอง\n\n- ก\n- ข\n> คำ\n>> ผู้พูด')) }; });
  ok('F: every article body and infobox round-trips through the editor text', F0.n === 50 && F0.bad.length === 0, F0);
  ok('F: sanitiser leaves every original article untouched', F0.san.length === 0, F0.san);
  ok('F: escaped markers and mixed blocks round-trip', F0.tricky && F0.joined === JSON.stringify([['p', 'บรรทัดแรก บรรทัดสอง'], ['ul', ['ก', 'ข']], ['q', 'คำ', 'ผู้พูด']]), F0.joined);

  // ================= G) โหมดไฟล์ในเครื่อง =================
  await page.goto(url + '#lore-syntyr'); await wait(400);
  const base = await page.evaluate(() => ({ lead: LORE_BASE.articles.syntyr.lead, title: LORE_BASE.articles.syntyr.title }));
  const G0 = await page.evaluate(() => ({ bar: (document.querySelector('.lore-devbar') || {}).textContent, can: LoreEdit.canEdit(), backend: Store.backend }));
  ok('G: local file shows the back-office bar to its owner', G0.can && G0.backend === null && /หลังบ้าน/.test(G0.bar || '') && /ต้นฉบับในโค้ด/.test(G0.bar), G0);
  await page.click('.lore-devbar button'); await wait(500);
  const G1 = await page.evaluate(() => ({ hash: location.hash, title: document.querySelector('.le-form input:not([disabled])') && [...document.querySelectorAll('.le-form .le-field')].find(f => f.querySelector('.le-lab').textContent === 'ชื่อ').querySelector('input').value,
    body: document.querySelector('.le-form textarea.le-body').value, pvTitle: (document.querySelector('.le-preview .lore-title') || {}).textContent, pvBar: !!document.querySelector('.le-preview .lore-devbar'), pvNav: !!document.querySelector('.le-preview .lore-nav'), idLocked: document.querySelector('.le-form input').disabled }));
  ok('G: editor opens with the article loaded and a live preview', G1.hash === '#loreedit-syntyr' && G1.title === base.title && /^## /m.test(G1.body) && G1.pvTitle === base.title && !G1.pvBar && !G1.pvNav && G1.idLocked, G1);
  await fld('บทนำ', 'textarea').fill('บทนำทดสอบจากหลังบ้าน [[nemessiah]] และ [[nosuch]]'); await wait(450);
  const G2 = await page.evaluate(() => ({ pv: document.querySelector('.le-preview .lore-lead').textContent, link: !!document.querySelector('.le-preview .lore-lead a.lorelink[href="#lore-nemessiah"]'), warn: document.querySelector('.le-warn').textContent }));
  ok('G: preview follows typing and warns on a broken link', /บทนำทดสอบจากหลังบ้าน/.test(G2.pv) && G2.link && /nosuch/.test(G2.warn), G2);
  await page.click('.le-actions button.primary'); await wait(500);
  const G3 = await page.evaluate(() => ({ hash: location.hash, lead: document.querySelector('.lore-lead').textContent, bar: document.querySelector('.lore-devbar').textContent, ls: JSON.parse(localStorage.getItem('kirana.codex.lore.v1') || 'null') }));
  const t3 = await toastText();
  ok('G: save lands on the article, stored in this browser', G3.hash === '#lore-syntyr' && /บทนำทดสอบจากหลังบ้าน/.test(G3.lead) && /ฉบับแก้จากหลังบ้าน/.test(G3.bar) && G3.ls && G3.ls.articles.syntyr && /บันทึกในเครื่องนี้แล้ว/.test(t3), { G3: { ...G3, ls: !!G3.ls }, t3 });
  await page.reload(); await wait(700);
  const G4 = await page.evaluate(() => document.querySelector('.lore-lead').textContent);
  ok('G: edit survives a reload', /บทนำทดสอบจากหลังบ้าน/.test(G4), G4);
  await page.goto(url + '#dev'); await wait(500);
  const G5 = await page.evaluate(() => ({ card: !!document.querySelector('.le-dev'), edited: [...document.querySelectorAll('.le-dev .le-list a')].map(a => a.getAttribute('href')), log: [...document.querySelectorAll('.le-dev .le-list.dim li')].map(li => li.textContent), status: document.querySelector('.le-dev p.dim').textContent }));
  ok('G: back office lists the edited article and its history', G5.card && G5.edited.includes('#lore-syntyr') && G5.log.some(t => /แก้บทความ/.test(t)) && /เบราว์เซอร์นี้/.test(G5.status), G5);
  await page.goto(url + '#loreedit-syntyr'); await wait(400);
  await page.click('.le-actions button:has-text("คืนต้นฉบับ")'); await wait(500);
  const G6 = await page.evaluate(() => ({ hash: location.hash, lead: LORE.syntyr.lead === LORE_BASE.articles.syntyr.lead, edited: LoreEdit.edited('syntyr'), ls: Object.keys((JSON.parse(localStorage.getItem('kirana.codex.lore.v1') || '{}').articles) || {}) }));
  ok('G: revert restores the original text', G6.hash === '#lore-syntyr' && G6.lead && !G6.edited && G6.ls.length === 0, G6);
  await page.goto(url + '#loreedit-vox'); await wait(400);
  await page.click('.le-actions button.primary'); await wait(400);
  const G7 = await page.evaluate(() => ({ edited: LoreEdit.edited('vox'), same: JSON.stringify(LORE.vox) === JSON.stringify(LORE_BASE.articles.vox) }));
  ok('G: saving without changes keeps the code original', !G7.edited && G7.same, G7);

  // ================= H) บทความใหม่ คำนำ คำโปรย ส่งออก นำเข้า =================
  await page.goto(url + '#loreedit-new'); await wait(400);
  await fld('รหัสบทความ', 'input').fill('testlantern');
  await fld('ชนิด', 'select').selectOption('place');
  await fld('สังกัดเหตุการณ์', 'select').selectOption('collapse');
  await fld('ชื่อ', 'input').fill('ตะเกียงทดสอบ');
  await fld('ชื่ออังกฤษ', 'input').fill('Test Lantern');
  await fld('บทนำ', 'textarea').fill('สถานที่สมมุติไว้ทดสอบหลังบ้าน');
  await fld('กล่องข้อมูล', 'textarea').fill('ที่ตั้ง = [[luxonia]]\nบรรทัดผิดรูป');
  await fld('เนื้อบทความ', 'textarea').fill('## ที่มา\n\nย่อหน้าแรกอ้าง [[collapse]]\n\n- ข้อหนึ่ง\n- ข้อสอง\n\n> คำพูดทดสอบ\n>> ผู้เฝ้าตะเกียง\n\n::fig veil');
  await fld('ในเกม: วงศา (รหัส)', 'input').fill('lunaryn, nosuchkin');
  await wait(450);
  const H0 = await page.evaluate(() => ({ pvTitle: document.querySelector('.le-preview .lore-title').textContent, pvFig: !!document.querySelector('.le-preview .lfig svg'), warn: document.querySelector('.le-warn').textContent }));
  ok('H: new article preview renders figure and flags unknown kin', H0.pvTitle === 'ตะเกียงทดสอบ' && H0.pvFig && /nosuchkin/.test(H0.warn), H0);
  await page.click('.le-actions button.primary'); await wait(500);
  const H1 = await page.evaluate(() => ({ hash: location.hash, title: document.querySelector('.lore-title').textContent, crumbs: document.querySelector('.lore-crumbs').textContent, fig: !!document.querySelector('.lore-art .lfig'), q: document.querySelectorAll('.lore-quote').length,
    ul: document.querySelectorAll('.lore-ul li').length, box: document.querySelectorAll('.lore-ibt tr').length, kins: [...document.querySelectorAll('.lore-game .gchip')].map(b => b.textContent), nav: document.querySelector('.lore-navbtn.prev').getAttribute('href'), bar: document.querySelector('.lore-devbar').textContent }));
  ok('H: new article page under its parent event', H1.hash === '#lore-testlantern' && H1.title === 'ตะเกียงทดสอบ' && /›.*›/.test(H1.crumbs) && H1.fig && H1.q === 1 && H1.ul === 2 && H1.box === 1 && H1.kins.length === 1 && H1.nav === '#lore-collapse' && /เพิ่มจากหลังบ้าน/.test(H1.bar), H1);
  await page.goto(url + '#lore'); await wait(400);
  const H2 = await page.evaluate(() => ({ branch: !!document.querySelector('.tl-ev[data-id="collapse"] .tl-branches a[href="#lore-testlantern"]'), aside: !!document.querySelector('.lore-kind a[href="#lore-testlantern"]') }));
  await page.goto(url + '#lore-collapse'); await wait(300);
  const H3 = await page.evaluate(() => !!document.querySelector('.lore-bcard[href="#lore-testlantern"]'));
  ok('H: new article branches from its event on the timeline and the event page', H2.branch && H2.aside && H3, { H2, H3 });
  await page.goto(url + '#loreedit-testlantern'); await wait(400);
  await page.click('.le-actions button:has-text("ลบบทความนี้")'); await wait(500);
  const H4 = await page.evaluate(() => ({ gone: !LORE.testlantern, hash: location.hash, left: Object.keys(LoreEdit.effective().articles) }));
  ok('H: added article can be deleted', H4.gone && H4.hash === '#lore' && H4.left.length === 0, H4);
  // คำนำและคำโปรยมหายุค
  await page.goto(url + '#dev'); await wait(500);
  await fieldIn('.le-dev', 'คำนำหน้าแรก', 'textarea').fill('คำนำทดสอบจากหลังบ้าน');
  await page.locator('.le-dev .le-grid').first().locator('textarea').fill('คำโปรยยุคแรกทดสอบ');
  await page.click('.le-dev button:has-text("บันทึกคำนำและคำโปรย")'); await wait(500);
  await page.goto(url + '#lore'); await wait(400);
  const H5 = await page.evaluate(() => ({ lede: document.querySelector('.lore-hero .lede').textContent, blurb: document.querySelector('.tl-era .desc').textContent, eras: LoreEdit.effective().eras, intro: LoreEdit.effective().intro }));
  ok('H: intro and era blurb editable from the back office', H5.lede === 'คำนำทดสอบจากหลังบ้าน' && H5.blurb === 'คำโปรยยุคแรกทดสอบ' && Object.keys(H5.eras).length === 1, H5);
  // ส่งออก แล้วนำเข้าคืน
  await page.goto(url + '#dev'); await wait(500);
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('.le-dev button:has-text("ส่งออกข้อความที่แก้")')]);
  const dlPath = await dl.path(); const exported = JSON.parse(fs.readFileSync(dlPath, 'utf8'));
  ok('H: export downloads the edits as JSON', dl.suggestedFilename() === 'kirana-lore-edits.json' && exported.intro === 'คำนำทดสอบจากหลังบ้าน' && exported.v === 1, { name: dl.suggestedFilename(), intro: exported.intro });
  await fieldIn('.le-dev', 'คำนำหน้าแรก', 'textarea').fill(await page.evaluate(() => LORE_BASE.intro));
  await page.locator('.le-dev .le-grid').first().locator('textarea').fill(await page.evaluate(() => LORE_BASE.eras[0].blurb));
  await page.click('.le-dev button:has-text("บันทึกคำนำและคำโปรย")'); await wait(500);
  const H6 = await page.evaluate(() => ({ intro: LoreEdit.effective().intro, eras: Object.keys(LoreEdit.effective().eras).length, lede: LORE_INTRO === LORE_BASE.intro }));
  ok('H: putting the original text back clears the override', H6.intro === null && H6.eras === 0 && H6.lede, H6);
  const imp = path.join(path.dirname(dlPath), 'import-test.json');
  fs.writeFileSync(imp, JSON.stringify({ v: 1, articles: { vox: JSON.stringify({ kind: 'person', title: 'ว็อกซ์ (นำเข้า)', en: 'Vox', lead: 'บทนำนำเข้า', body: [['p', 'ย่อหน้านำเข้า']] }), evil: { kind: 'event', title: 'แทรกเหตุการณ์ไม่ได้' } }, eras: {}, intro: null }));
  await page.setInputFiles('.le-dev input[type=file]', imp); await wait(600);
  const H7 = await page.evaluate(() => ({ vox: LORE.vox.title, kind: LORE.vox.kind, evil: !!LORE.evil, n: Object.keys(LoreEdit.effective().articles) }));
  ok('H: import applies valid articles and refuses a new event', H7.vox === 'ว็อกซ์ (นำเข้า)' && H7.kind === 'person' && !H7.evil && H7.n.join() === 'vox', H7);
  await page.evaluate(() => { LoreEdit.dropDraft(); });

  // ================= I) คนที่ไม่ใช่ผู้พัฒนา =================
  const ctx2 = await browser.newContext({ viewport: { width: 1200, height: 900 } });
  const p2 = await ctx2.newPage(); p2.on('pageerror', e => errors.push('PAGEERROR(p2) ' + e.message));
  await ctx2.route('https://www.gstatic.com/**', r => r.abort());
  await p2.addInitScript(() => { window.KIRANA_FIREBASE = { projectId: 'kirana-test', apiKey: 'x', authDomain: 'x', appId: 'x' };
    try { localStorage.setItem('kirana.codex.lore.v1', JSON.stringify({ v: 1, articles: { syntyr: { kind: 'topic', title: 'ร่างที่ไม่ควรเห็น', lead: 'x', body: [] } }, eras: {}, intro: null })); } catch (e) {} });
  await p2.goto(url + '#lore-syntyr'); await p2.waitForTimeout(1200);
  const I0 = await p2.evaluate(() => ({ ready: Store.ready, backend: Store.backend, can: LoreEdit.canEdit(), bar: !!document.querySelector('.lore-devbar'), title: document.querySelector('.lore-title').textContent }));
  await p2.goto(url + '#loreedit-syntyr'); await p2.waitForTimeout(500);
  const I1 = await p2.evaluate(() => ({ hash: location.hash, form: !!document.querySelector('.le-form') }));
  await p2.goto(url + '#dev'); await p2.waitForTimeout(500);
  const I2 = await p2.evaluate(() => !!document.querySelector('.le-dev'));
  ok('I: site configured for Firebase but offline shows no back office and ignores local drafts', I0.ready && I0.backend === null && !I0.can && !I0.bar && I0.title !== 'ร่างที่ไม่ควรเห็น' && I1.hash === '#lore-syntyr' && !I1.form && !I2, { I0, I1, I2 });
  await ctx2.close();
  // บัญชีทั่วไปบน Firebase (จำลอง): เห็นข้อความที่ผู้พัฒนาแก้ แต่ไม่เห็นปุ่ม และข้อความจากฐานข้อมูลแสดงเป็นข้อความล้วน
  await page.evaluate(async () => {
    const remote = { v: 1, at: 1, by: 'dev', byName: 'Non', eras: { [LORE_ERAS[0].id]: { blurb: 'โปรยจากเว็บ' }, nosuchera: { blurb: 'ไม่ควรเข้า' } }, intro: null, log: [],
      articles: { syntyr: JSON.stringify({ ...LORE_BASE.articles.syntyr, lead: '<img src=x onerror="window.__x=1">ข้อความจากเว็บ', body: [['p', '<b>ไม่ใช่ตัวหนา</b>'], ['script', 'alert(1)'], ['fig', 'nosuch'], ['h', 'หัวข้อเดียว']] }), broken: '{not json', 'Bad-Id': JSON.stringify({ kind: 'topic', title: 'x' }) } };
    Store.backend = 'firebase'; Store.isDevUid = false;
    Store.db = { doc: () => ({ get: async () => ({ exists: true, data: () => JSON.parse(JSON.stringify(remote)) }), set: async () => { throw { code: 'permission-denied' }; } }) };
    await LoreEdit.boot(); location.hash = '#lore-syntyr'; });
  await wait(400);
  const I3 = await page.evaluate(() => ({ lead: document.querySelector('.lore-lead').textContent, img: !!document.querySelector('.lore-art img'), x: window.__x, bold: !!document.querySelector('.lore-art p b'), heads: document.querySelectorAll('.lore-art h2.lore-h[id^="lh-"]').length,
    fig: !!document.querySelector('.lore-art .lfig'), bar: !!document.querySelector('.lore-devbar'), keys: Object.keys(LoreEdit.remote.articles), eraBlurb: LORE_ERAS[0].blurb, eraKeys: Object.keys(LoreEdit.remote.eras).join() }));
  ok('I: players see web edits as plain text, never markup', /<img src=x/.test(I3.lead) && !I3.img && I3.x === undefined && !I3.bold && I3.heads === 1 && !I3.fig && !I3.bar && I3.keys.join() === 'syntyr' && I3.eraBlurb === 'โปรยจากเว็บ' && I3.eraKeys === LORE_ERA0, I3);

  // ================= J) ผู้พัฒนาบน Firestore จำลอง =================
  await page.evaluate(async () => { localStorage.removeItem('kirana.codex.lore.v1'); window.__wrote = null; Store.isDevUid = true; Store.me = 'dev-uid'; Store.displayName = 'Non';
    Store.db = { doc: (p) => ({ get: async () => ({ exists: false }), set: async () => { throw { code: 'permission-denied' }; } }) };
    await LoreEdit.boot(); location.hash = '#loreedit-syntyr'; });
  await wait(500);
  await fld('บทนำ', 'textarea').fill('แก้ตอนกฎยังไม่ขึ้น'); await page.click('.le-actions button.primary'); await wait(500);
  const J0 = await page.evaluate(() => ({ local: !!LoreEdit.local, ls: !!localStorage.getItem('kirana.codex.lore.v1'), lead: LORE.syntyr.lead, status: LoreEdit.status }));
  const tJ0 = await toastText();
  ok('J: write refused by rules keeps a local draft and says why', J0.local && J0.ls && J0.lead === 'แก้ตอนกฎยังไม่ขึ้น' && J0.status === 'draft' && /permission-denied/.test(tJ0) && /firestore\.rules/.test(tJ0), { J0, tJ0 });
  await page.evaluate(() => { location.hash = '#dev'; }); await wait(300);
  await page.evaluate(async () => { Store.db = { doc: (p) => ({ get: async () => ({ exists: !!window.__wrote, data: () => JSON.parse(JSON.stringify(window.__wrote)) }), set: async (d) => { window.__wrote = { path: p, ...JSON.parse(JSON.stringify(d)) }; } }) };
    clear($('#v-dev')).append(loreDevCard()); });
  const J1a = await page.evaluate(() => document.querySelector('.le-dev').textContent);
  await page.click('.le-dev button:has-text("ส่งร่างขึ้นเว็บอีกครั้ง")'); await wait(400);
  const J1 = await page.evaluate(() => { const w = window.__wrote; const nested = (x) => Array.isArray(x) ? x.some(y => Array.isArray(y) || nested(y)) : (x && typeof x === 'object') ? Object.values(x).some(nested) : false;
    return { path: w && w.path, str: w && typeof w.articles.syntyr, nested: nested({ ...w, path: undefined }), keys: Object.keys(w).filter(k => k !== 'path').sort().join(), local: LoreEdit.local, ls: localStorage.getItem('kirana.codex.lore.v1') }; });
  ok('J: back office warns about the draft, then pushes it once rules allow', /ร่างในเครื่องนี้/.test(J1a) && J1.path === 'codex/lore' && J1.str === 'string' && !J1.nested && J1.keys === 'articles,at,by,byName,eras,intro,log,v' && J1.local === null && J1.ls === null, { J1, J1a: J1a.slice(0, 200) });
  // อีกเครื่องแก้ vox ขึ้นเว็บไปแล้ว เครื่องนี้แก้ nemessiah ต่อ ต้องไม่ทับของอีกเครื่อง
  await page.evaluate(() => { window.__wrote.articles.vox = JSON.stringify({ ...LORE_BASE.articles.vox, lead: 'แก้โดยอีกเครื่อง' }); location.hash = '#loreedit-nemessiah'; });
  await wait(500);
  await fld('บทนำ', 'textarea').fill('แก้โดยเครื่องนี้'); await page.click('.le-actions button.primary'); await wait(500);
  const J2 = await page.evaluate(() => ({ keys: Object.keys(window.__wrote.articles).sort().join(), vox: LORE.vox.lead, nem: LORE.nemessiah.lead, by: window.__wrote.byName, log: window.__wrote.log.map(x => x.what) }));
  const tJ2 = await toastText();
  ok('J: save re-reads the web copy first so two editors do not overwrite each other', J2.keys === 'nemessiah,syntyr,vox' && J2.vox === 'แก้โดยอีกเครื่อง' && J2.nem === 'แก้โดยเครื่องนี้' && J2.by === 'Non' && /บันทึกขึ้นเว็บแล้ว/.test(tJ2), { J2, tJ2 });
  await page.evaluate(() => { const big = 'ก'.repeat(7900); const a = { ...LORE_BASE.articles.hundredyears }; a.body = Array.from({ length: 200 }, () => ['p', big]); window.__big = a; });
  const J3 = await page.evaluate(async () => { const r = await LoreEdit.save('ทดสอบขนาด', d => { for (let i = 0; i < 3; i++) d.articles['big' + i] = { ...window.__big, kind: 'topic' }; }); return r; });
  ok('J: oversize save is refused before it reaches the database', J3.where === 'toolarge' && J3.bytes > 1000000, J3);
  await page.evaluate(() => { Store.isDevUid = false; });
  const J4 = await page.evaluate(async () => (await LoreEdit.save('ห้าม', d => { d.intro = 'x'; })).where);
  ok('J: a non-developer cannot save even by calling the code', J4 === 'denied', J4);

  // ================= K) คลังทักษะหลังคำตัดสินชิ้นที่ 2 =================
  await page.evaluate(() => { Store.backend = null; Store.db = null; location.hash = '#skills-kins'; }); await wait(400);
  const K0 = await page.evaluate(() => [...document.querySelectorAll('#v-skills .cx-group')].map(g => ({ sub: g.dataset.sub, h: g.querySelector('h3').textContent })));
  ok('K: every kin skill group carries a Thai heading', K0.length === 12 && K0.every(g => /[\u0E00-\u0E7F]/.test(g.h)), K0);
  await page.evaluate(() => { location.hash = '#skills-sorcery'; }); await wait(400);
  const K1 = await page.evaluate(() => { const g = document.querySelector('#v-skills .cx-group[data-sub^="Blood Sorcery"]'); return g ? { h: g.querySelector('h3').textContent, n: g.querySelectorAll('.cx-sk').length, tiers: [...g.querySelectorAll('.cx-tierhead .tag')].map(t => t.textContent), lore: !!g.querySelector('a.lchip[href="#lore-sevenlunars"]'), data: DATA.skills.filter(x => skSubBase(x.subcategory) === 'Blood Sorcery').length } : null; });
  ok('K: blood sorcery stands as its own school with lore link', K1 && K1.n === 13 && K1.data === 13 && K1.tiers.join() === 'Novice,Expert,Master' && K1.lore && /เวทโลหิต/.test(K1.h), K1);
  ok('no page errors', errors.length === 0, errors);
  console.log(`v126b: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
