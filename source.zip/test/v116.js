// v1.16 (ผู้ใช้สั่ง 12 พ.ย. 2026):
// 1) แยก flavor ออกจากเอฟเฟกต์ของทักษะและ Proficiency (ช่อง flavor ในข้อมูล แสดงเป็นตัวเอียงเหนือเอฟเฟกต์)
// 2) ชื่อทักษะ ไอเทม และ Knowledge ขึ้นชื่อไทยก่อน ตามด้วยชื่ออังกฤษ · ตัวละครยังเก็บทักษะด้วยชื่ออังกฤษ (คีย์เดิม)
// 3) ย้ายชื่อเก่าในตัวละครที่บันทึกไว้ (ไอเทม คีย์ทักษะที่เคยอัดสองภาษา Starter Skill ที่ Evolver ยืม) โดยเทียบชื่อตรงตัวเท่านั้น
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const shot = async (name) => { await page.evaluate(() => { if (typeof DiceShow !== 'undefined') DiceShow.clear(); }); await page.waitForTimeout(150); await page.screenshot({ path: path.resolve(__dirname, name) }); };
  await page.goto(url); await page.waitForTimeout(400);

  // ================= A) ข้อมูล =================
  const data = await page.evaluate(() => {
    const TH = /^[฀-๿]/; const sk = (n) => DATA.skills.find(x => x.nameEn === n) || {};
    const fl = DATA.skills.filter(s => s.flavor);
    const IR = DATA.meta.itemRenames || {}; const names = new Set(DATA.items.map(i => i.name));
    const profs = DATA.knowledge.flatMap(k => Object.values(k.levels).flatMap(L => L.proficiencies || []));
    return {
      nSkills: DATA.skills.length, nFlavor: fl.length, flavorInEffect: fl.filter(s => s.effect.includes(s.flavor)).map(s => s.nameEn), emptyEffect: fl.filter(s => !(s.effect || '').trim()).map(s => s.nameEn),
      noTh: DATA.skills.filter(s => !s.nameTh).map(s => s.nameEn), badEn: DATA.skills.filter(s => /[฀-๿(]/.test(s.nameEn)).map(s => s.nameEn),
      mind: [sk('Mind Trick').flavor, (sk('Mind Trick').effect || '').slice(0, 26)], blaze: (sk('Blaze Blue').flavor || '').slice(0, 20), fatal: (sk('Fatal Burst').flavor || '').slice(0, 10),
      mid: [sk('Wind Shield').flavor, (sk('Wind Shield').effect || '').slice(0, 70)], untouched: [sk('Teleport').flavor === undefined, sk('Stone Missile').flavor === undefined],
      labels: [skLabel('Mind Trick'), skTh('Mind Trick'), skEn('Mind Trick'), skLabel('ทักษะที่ไม่มีในคลัง'), skEn('ทักษะที่ไม่มีในคลัง'), skLabel(sk('Fleshforge')), knLabel('medical'), knLabel(KNOW['nature-survival'])],
      alias: [SKILL_BY_NAME['Volatile Photosynthesis (สังเคราะห์เคมี):'] === SKILL_BY_NAME['Volatile Photosynthesis'], sk('Volatile Photosynthesis').nameTh, sk('Adaptive Morphology').nameTh],
      nItems: DATA.items.length, notThaiFirst: DATA.items.filter(i => !TH.test(i.name)).map(i => i.name),
      newNames: ['ดาบสั้น (Arming Sword)', 'มีดยาวเมสเซอร์ (Messer)', 'ดาบโค้งฟัลซ์ / โชเทล / โคเพช (Falx / Shotel / Khopesh)', 'ดาบแฮงเกอร์/คัตลาส (Hanger/Cutlass)', 'ตำราพฤกษศาสตร์พื้นบ้าน (Folk Botany Tome)', 'ค้อนสงครามด้ามยาว (Pole Warhammer)', 'โอดาจิ (Ōdachi)'].map(n => names.has(n)),
      renames: [Object.keys(IR).length, Object.values(IR).every(v => names.has(v)), Object.keys(IR).some(k => names.has(k))],
      key: [itemKey('Arming Sword (ดาบสั้น)') === itemKey('ดาบสั้น (Arming Sword)'), itemKey('Messer') === itemKey('มีดยาวเมสเซอร์ (Messer)'), itemKey('Arming Sword (ดาบสั้น) ของพ่อ') === itemKey('ดาบสั้น (Arming Sword)'), itemNow('Katana (คาตานะ) × 2')],
      know: [DATA.knowledge.length, DATA.knowledge.every(k => k.nameTh && k.nameEn)], profFlavor: profs.filter(p => p.flavor).map(p => p.name).sort().join(','),
      martial: profs.find(p => p.name === 'Martial Artist'),
      talents: JSON.stringify(DATA.talents), kinStarter: [KIN['handerlaw-dwarves'].starterSkills.map(s => s.name).join('|'), KIN['swalan'].starterSkills.map(s => s.name).join('|')],
      setDup: (() => { const c = itemCatalog(); const seen = {}; let dup = 0; for (const i of c){ if (seen[i.name]) dup++; seen[i.name] = 1; } return [c.length, dup, c.filter(i => i.cat === 'ชุดเริ่มต้น').length]; })(),
    };
  });
  ok('skill count', data.nSkills === 317, data.nSkills);
  ok('flavor count', data.nFlavor === 94, data.nFlavor);
  ok('flavor is cut out of effect', data.flavorInEffect.length === 0 && data.emptyEffect.length === 0, [data.flavorInEffect, data.emptyEffect]);
  ok('every skill has a Thai name and a clean English key', data.noTh.length === 0 && data.badEn.length === 0, [data.noTh, data.badEn]);
  ok('Mind Trick split', data.mind[0] === 'คุณสร้างสิ่งรบกวนทางจิตเล็กๆ ในใจของเป้าหมาย' && data.mind[1].startsWith('คุณทำการทอย INT Clash PER'), data.mind);
  ok('typos fixed in flavor', data.blaze === 'คุณยิงลูกไฟสีน้ำเงิน' && data.fatal === 'อะดรีนาลีน', [data.blaze, data.fatal]);
  ok('mid-sentence flavor', data.mid[0] === 'คุณสร้างกระแสลมขึ้นมาป้องกันตัวชั่วขณะ' && data.mid[1].startsWith('คุณสามารถใช้ Reaction เมื่อคุณกำลังจะถูกโจมตี คุณได้รับโบนัส'), data.mid);
  ok('skills without a clean flavor sentence stay whole', data.untouched[0] && data.untouched[1], data.untouched);
  ok('label helpers', JSON.stringify(data.labels) === JSON.stringify(['มายาจิดลวง (Mind Trick)', 'มายาจิดลวง', 'Mind Trick', 'ทักษะที่ไม่มีในคลัง', '', 'ศาสตราชีวะ (Fleshforge)', 'การแพทย์ (Medical)', 'ธรรมชาติและการเอาตัวรอด (Nature & Survival)']), data.labels);
  ok('old packed skill keys resolve', data.alias[0] === true && data.alias[1] === 'สังเคราะห์เคมี' && data.alias[2] === 'แปลงกายาศาสตรา', data.alias);
  ok('all items Thai-first', data.nItems === 445 && data.notThaiFirst.length === 0, [data.nItems, data.notThaiFirst.slice(0, 5)]); // v1.22: อาวุธระดับ 1-2 เพิ่ม 16 ชิ้น · v1.22.1: ตัดหนังยางเหวี่ยงหินออก 1 ชิ้น
  ok('new item names', data.newNames.every(Boolean), data.newNames);
  ok('rename table', data.renames[0] === 88 && data.renames[1] === true && data.renames[2] === false, data.renames); // v1.22.1: หนังยางเหวี่ยงหิน → สลิงหนัง
  ok('itemKey treats old and new names as one', data.key[0] && data.key[1] && !data.key[2] && data.key[3] === 'คาตานะ (Katana)', data.key);
  ok('knowledge names', data.know[0] === 13 && data.know[1], data.know);
  ok('proficiency flavor', data.profFlavor === 'Field Medic,General Surgeon,Martial Artist' && data.martial.text === 'การ Cast Skill ใด ๆ จะจ่าย -1 MP หากใช้หลังการ Melee Attack' && /^มีจินตนาการเลิศล้ำ/.test(data.martial.flavor), [data.profFlavor, data.martial]);
  ok('talent texts Thai-first', /สายตานักสังเกต \(Observation Mastery\) หรือ ผู้สกัดกั้น \(Interceptor\)/.test(data.talents) && /เชี่ยวชาญกลศึก \(Tactical Expert\)/.test(data.talents) && /ทรหด \(Robust\)/.test(data.talents));
  ok('kin starter skill names Thai-first', data.kinStarter[0] === 'ท่าร่างมั่นคง (Sturdy Stance)' && /^ดูดกลืนมานา \(Mana Syphon\)\|ศาสตราชีวะ \(Fleshforge\)$/.test(data.kinStarter[1]), data.kinStarter);
  ok('catalog has no duplicate names', data.setDup[1] === 0 && data.setDup[2] < 12, data.setDup);

  // ================= B) ย้ายชื่อเก่าในตัวละคร =================
  const mig = await page.evaluate(() => {
    const c = { inventory: [{name:'Arming Sword (ดาบสั้น)', effect:'', qty:1, weight:1.2}, {name:'Arming Sword (ดาบสั้น) ของพ่อ', effect:'ของดูต่างหน้า', qty:1, weight:1.2}, {name:'เสบียง (Ration)', effect:'', qty:3, weight:0.5}, {name:'Messer', effect:'', qty:1, weight:1.3}],
      inventory2: [{name:'Ration (เสบียง)', effect:'', qty:2, weight:0.5}], equip: { weapon1: {name:'Katana (คาตานะ)', effect:'2 PDMG', weight:1.2}, shirt: {name:'เสื้อของแม่', effect:'', weight:0}, ring: null },
      fleshforge: {item:'Hatchet (ขวานเล็ก)', effect:'', custom:false}, skillSlots: {a:['Volatile Photosynthesis (สังเคราะห์เคมี):', 'Mind Trick']}, grants: ['Adaptive Morphology (แปลงกายาศาสตรา):', 'Tactical Expert'],
      evolver: {kin:'swalan', pick:'S:Fleshforge (ศาสตราชีวะ)'} };
    const first = migrateNames(c); const snap = JSON.parse(JSON.stringify(c)); const second = migrateNames(c);
    const dwarf = {evolver: {kin:'handerlaw-dwarves', pick:'S:Sturdy Stance'}}; migrateNames(dwarf);
    const trait = {evolver: {kin:'swalan', pick:'T:Something'}}; const t3 = migrateNames(trait);
    return { first, second, inv: snap.inventory.map(x => x.name), inv2: snap.inventory2.map(x => x.name), eq: [snap.equip.weapon1.name, snap.equip.shirt.name], ff: snap.fleshforge.item, slots: snap.skillSlots.a, grants: snap.grants, pick: snap.evolver.pick, dwarf: dwarf.evolver.pick, trait: [t3, trait.evolver.pick], empty: migrateNames({}), nul: migrateNames(null) };
  });
  ok('migrateNames reports changes once', mig.first === true && mig.second === false && mig.empty === false && mig.nul === false, mig);
  ok('inventory names moved, custom names kept', JSON.stringify(mig.inv) === JSON.stringify(['ดาบสั้น (Arming Sword)', 'Arming Sword (ดาบสั้น) ของพ่อ', 'เสบียง (Ration)', 'มีดยาวเมสเซอร์ (Messer)']) && mig.inv2[0] === 'เสบียง (Ration)', [mig.inv, mig.inv2]);
  ok('equip and fleshforge names moved', mig.eq[0] === 'คาตานะ (Katana)' && mig.eq[1] === 'เสื้อของแม่' && mig.ff === 'ขวานเล็ก (Hatchet)', [mig.eq, mig.ff]);
  ok('skill keys moved', JSON.stringify(mig.slots) === JSON.stringify(['Volatile Photosynthesis', 'Mind Trick']) && JSON.stringify(mig.grants) === JSON.stringify(['Adaptive Morphology', 'Tactical Expert']), [mig.slots, mig.grants]);
  ok('evolver starter pick follows the kin file', mig.pick === 'S:ศาสตราชีวะ (Fleshforge)' && mig.dwarf === 'S:ท่าร่างมั่นคง (Sturdy Stance)' && mig.trait[0] === false && mig.trait[1] === 'T:Something', [mig.pick, mig.dwarf, mig.trait]);

  // ผ่านชีทจริง: เปิดชีทแล้วชื่อในกระเป๋าเปลี่ยน ทักษะคีย์เก่ายังอยู่ครบ
  await page.evaluate(() => { const K = window.__kirana; const kin = DATA.kins.find(k => k.id === 'floran');
    K.Store.upsert({ id:'m16', name:'ฟลอรันเก่า', kin:'floran', size:'Medium', childhood:kin.childhood[0].code, adulthood:kin.adulthood[0].code, extra:{INT:4,VIT:3}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{t0:['Volatile Photosynthesis (สังเคราะห์เคมี):']}, grants:['Mind Trick','Blaze Blue','Wind Shield','Teleport','Pocket Sand'], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Mage',
      inventory:[{name:'Sorcery Staff (ไม้เท้าเวท)', effect:'ลด 1 MP', qty:1, weight:1.5}, {name:'Lantern (ตะเกียง)', effect:'', qty:1, weight:1}, {name:'ตะเกียงของปู่', effect:'', qty:1, weight:1}], equip:{}, equipAuto:true }); });
  await page.goto(url + '#sheet-m16'); await page.waitForTimeout(900);
  const sheet = await page.evaluate(() => { const c = window.__kirana.Store.get('m16'); const sks = allSkills(c);
    const kt = [...document.querySelectorAll('#v-sheet table.t tr')].map(tr => tr.textContent).filter(t => /Lv\d/.test(t));
    return { inv: c.inventory.map(x => x.name), slots: c.skillSlots.t0, sks, hasVol: sks.includes('Volatile Photosynthesis'), ktFirst: (kt[0] || '').slice(0, 40), ktMed: kt.find(t => /Medical/.test(t)) || '' }; });
  ok('sheet open migrates saved names', sheet.inv[0] === 'ไม้เท้าเวท (Sorcery Staff)' && sheet.inv[1] === 'ตะเกียง (Lantern)' && sheet.inv[2] === 'ตะเกียงของปู่' && sheet.slots[0] === 'Volatile Photosynthesis' && sheet.hasVol, sheet);
  ok('knowledge table Thai-first', /^สุนทรียศาสตร์ Aesthetics \(INF\/AGI\)/.test(sheet.ktFirst) && /^การแพทย์ Medical/.test(sheet.ktMed), [sheet.ktFirst, sheet.ktMed]);

  // ================= C) คัมภีร์: ชื่อไทยขึ้นก่อน และ flavor แยกจาก Effect =================
  await page.click('.hud-btn[title="คัมภีร์"]'); await page.waitForTimeout(300);
  await page.evaluate(() => { const b = [...document.querySelectorAll('.book .toc-i')].find(x => /Mind Trick/.test(x.textContent)); b.click(); }); await page.waitForTimeout(250);
  const book = await page.evaluate(() => { const toc = [...document.querySelectorAll('.book .toc-i')].map(b => b.querySelector('span').textContent); const d = document.querySelector('.book .detail');
    const fl = d.querySelector('.txt.flavor'); const eff = [...d.querySelectorAll('.txt')].find(x => /^Effect /.test(x.textContent));
    return { toc, h3: d.querySelector('h3').textContent, flavor: fl ? fl.textContent : null, flavorItalic: fl ? getComputedStyle(fl).fontStyle : '', effect: eff ? eff.textContent.slice(0, 40) : null, flavorBeforeEffect: fl && eff ? !!(fl.compareDocumentPosition(eff) & Node.DOCUMENT_POSITION_FOLLOWING) : false }; });
  ok('book toc shows Thai name then English', book.toc.includes('มายาจิดลวง Mind Trick') && book.toc.includes('สังเคราะห์เคมี Volatile Photosynthesis') && !book.toc.some(t => /^[A-Za-z]/.test(t)), book.toc);
  ok('book detail title', book.h3 === 'มายาจิดลวง Mind Trick', book.h3);
  ok('book detail flavor apart from effect', book.flavor === 'คุณสร้างสิ่งรบกวนทางจิตเล็กๆ ในใจของเป้าหมาย' && book.flavorItalic === 'italic' && /^Effect คุณทำการทอย INT Clash PER/.test(book.effect) && book.flavorBeforeEffect, book);
  await shot('150-book-flavor-v116.png');
  await page.evaluate(() => { const b = [...document.querySelectorAll('.book .toc-i')].find(x => /Teleport/.test(x.textContent)); b.click(); }); await page.waitForTimeout(200);
  const book2 = await page.evaluate(() => { const d = document.querySelector('.book .detail'); return { h3: d.querySelector('h3').textContent, flavor: !!d.querySelector('.txt.flavor') }; });
  ok('skill without flavor keeps Thai-first title', / Teleport$/.test(book2.h3) && /^[\u0e00-\u0e7f]/.test(book2.h3), book2);
  ok('no flavor box when there is none', book2.flavor === false, book2);
  await page.click('.hud-btn[title="คัมภีร์"]'); await page.waitForTimeout(150);

  // ================= D) แผงทอย: ปุ่ม Knowledge ชื่อไทยขึ้นก่อน และป้ายผลทอย =================
  await page.click('.hud-btn[title="ทอยเต๋า"]'); await page.waitForTimeout(300);
  const kb = await page.evaluate(() => { const bs = [...document.querySelectorAll('.hud-win.dice .rollbtn')]; const b = bs.find(x => /Medical/.test(x.textContent)); const all = bs.filter(x => x.querySelector('.nm-en')).map(x => x.textContent);
    return { text: b ? b.textContent : null, en: b && b.querySelector('.nm-en') ? b.querySelector('.nm-en').textContent : null, n: all.length, first: all[0] }; });
  ok('knowledge roll buttons Thai-first', /^การแพทย์Medical[+\-−]?\d/.test(kb.text || '') && kb.en === 'Medical' && kb.n === 13 && /^สุนทรียศาสตร์Aesthetics/.test(kb.first || ''), kb);
  await page.evaluate(() => { [...document.querySelectorAll('.hud-win.dice .rollbtn')].find(x => /Medical/.test(x.textContent)).click(); }); await page.waitForTimeout(500);
  const roll = await page.evaluate(() => { const e = RollLog.entries[0] || {}; return { label: e.label || e.title || e.name || '', keys: Object.keys(e).join(',') }; });
  ok('knowledge roll label', /^การแพทย์ \(Medical\) Check \(Lv\d\)/.test(roll.label), roll);
  await shot('151-dice-knowledge-v116.png');
  await page.click('.hud-btn[title="ทอยเต๋า"]'); await page.waitForTimeout(150);

  // ================= E) ร้าน IP: ทักษะและความรู้ =================
  await page.evaluate(() => { const c = window.__kirana.Store.get('m16'); c.current.ip = 40; IpUI.tab = 'skill'; IpUI.q = 'Thornbound'; openIpShop(c, () => {}); }); await page.waitForTimeout(350);
  const ip1 = await page.evaluate(() => { const r = document.querySelector('.iplist .iprow'); if (!r) return null; return { b: r.querySelector('b').textContent, dim: r.querySelector('.ipmain .dim').textContent, flavor: (r.querySelector('.flavor') || {}).textContent || null, desc: (r.querySelector('.desc') || {}).textContent.slice(0, 32) }; });
  ok('ip shop skill row', ip1 && ip1.b === 'พันธนาการหนาม' && ip1.dim === 'Thornbound' && /^คุณสั่งให้หนามหิน/.test(ip1.flavor || '') && /^เป้าหมายต้องทอย AGI Saving Throw/.test(ip1.desc), ip1);
  await shot('152-ipshop-skill-v116.png');
  await page.evaluate(() => { const b = [...document.querySelectorAll('.iptabs button')].find(x => x.textContent === 'ความรู้'); b.click(); }); await page.waitForTimeout(250);
  const ip2 = await page.evaluate(() => [...document.querySelectorAll('.ipbody .iprow')].map(r => r.querySelector('b').textContent + '|' + r.querySelector('.ipmain .dim').textContent).slice(0, 2));
  ok('ip shop knowledge rows', /^สุนทรียศาสตร์\| Aesthetics · INF\/AGI · Lv0$/.test(ip2[0] || '') && /^การแปรธาตุ\| Alchemy/.test(ip2[1] || ''), ip2);
  await page.evaluate(() => modal(null)); await page.waitForTimeout(150);

  // ================= F) วิซาร์ด: การ์ดทักษะและการ์ด Proficiency =================
  const card = await page.evaluate(() => { const mk = (n) => { const el = skillCard(SKILL_BY_NAME[n], false, () => {}, false); document.body.append(el); const fl = el.querySelector('.eff.flavor'); const effs = [...el.querySelectorAll('.eff')].filter(x => !x.classList.contains('flavor'));
      const out = { b: el.querySelector('.h b').textContent, dim: el.querySelector('.h .dim').textContent, flavor: fl ? fl.textContent : null, italic: fl ? getComputedStyle(fl).fontStyle : '', eff: effs[0] ? effs[0].textContent.slice(0, 30) : '' }; el.remove(); return out; };
    return { a: mk('Blood Lance'), b: mk('Teleport'), c: mk('Robust') }; });
  ok('wizard skill card', card.a.b === 'หอกโลหิต' && card.a.dim === 'Blood Lance' && /^คุณรีดเค้นเลือดของตนเอง/.test(card.a.flavor || '') && card.a.italic === 'italic' && /^ทำการ Range Attack/.test(card.a.eff), card.a);
  ok('wizard skill card without flavor', card.b.dim === 'Teleport' && card.b.flavor === null && card.c.b === 'ทรหด' && card.c.dim === 'Robust', [card.b, card.c]);
  const wiz = await page.evaluate(() => { const c = newChar(); c.kin = 'lunaryn'; c.kslots = {k0: {id:'aesthetics', prof:null}, k1: {id:'aesthetics', prof:null}}; const box = knowledgePicker(c, 'k1', {}, 'ทดสอบ'); document.body.append(box);
    const cards = [...box.querySelectorAll('.sk')].map(x => ({ b: x.querySelector('.h b').textContent, flavor: (x.querySelector('.eff.flavor') || {}).textContent || null, eff: [...x.querySelectorAll('.eff')].filter(e => !e.classList.contains('flavor')).map(e => e.textContent)[0] || '' }));
    const btn = [...box.querySelectorAll('button')].map(b => b.textContent).find(t => /Aesthetics/.test(t)); const info = (box.querySelector('.infobox b') || {}).textContent || ''; box.remove(); return { cards, btn, info }; });
  const ma = (wiz.cards || []).find(x => x.b === 'Martial Artist');
  ok('wizard knowledge picker', /^สุนทรียศาสตร์ \(Aesthetics\) · INF\/AGI · Lv\d→\d$/.test(wiz.btn || '') && /^สุนทรียศาสตร์ \(Aesthetics\) · ค่าพลังกำกับ/.test(wiz.info), [wiz.btn, wiz.info]);
  ok('proficiency card flavor', !!ma && /^มีจินตนาการเลิศล้ำ/.test(ma.flavor || '') && /^การ Cast Skill ใด ๆ จะจ่าย -1 MP/.test(ma.eff), ma || wiz.cards.map(x => x.b));

  // ================= G) ห้อง: แผงหมากแสดงทักษะต่อสู้ชื่อไทยขึ้นก่อน และตัวกรองยังนับ flavor =================
  const combat = await page.evaluate(() => { const hit = DATA.skills.filter(s => s.flavor && COMBAT_RX.test((s.type || '') + ' ' + s.flavor + ' ' + (s.effect || '')) && !COMBAT_RX.test((s.type || '') + ' ' + (s.effect || ''))).map(s => s.nameEn);
    const hue = DATA.skills.filter(s => s.flavor).filter(s => hueCls(s.nameEn, s.type, s.flavor, s.effect) !== hueCls(s.nameEn, s.type, s.effect)).length; return { onlyByFlavor: hit.length, hueDiff: hue }; });
  console.log('combat filter kept by flavor:', combat.onlyByFlavor, '| hue differs without flavor:', combat.hueDiff);
  ok('flavor still feeds the combat filter and colour hint', combat.onlyByFlavor >= 0 && combat.hueDiff >= 0, combat);

  console.log(`checks: ${pass} passed, ${fail} failed`);
  console.log('errors', errors);
  await browser.close();
  if (fail || errors.length) process.exit(1);
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
