// v1.14 (ผู้ใช้เคาะ 10 พ.ย. 2026):
// 1) กล่อง Toughness/เกราะ + ตำแหน่งโจมตีใหม่ (โจมตี/ป้องกันแยกกัน) และตัวตัดสิน Parry/Evade
// 2) ผังชีท: Personal Traits ไปคอลัมน์ขวา · Trait กับ Proficiency Trait อยู่คอลัมน์กลางใต้รูป + ปุ่มเพิ่ม/แก้/ลบรายการเอง
// 3) เขตใกล้เคียง 4-10 ม. · เขตไกล 11-20+ ม.   4) Range knowledge Level 1 = 20 ม.
// 6) Twinborn: HP และกระเป๋าแยกร่าง หมากสองร่าง เดินแยกกันได้ GM คุมอีกร่าง  (ข้อ 5 Fleshforge อยู่ใน test/v113.js)
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.type()==='prompt' ? d.accept('ร่าง B เจออะไรอยู่') : d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  const unlock = () => page.evaluate(() => { Table.rolling = false; Table.rollLock = null; updateRollLockUI(); });

  // ================= 1) ตำแหน่งโจมตี =================
  console.log('hit by sum:', await page.evaluate(() => [2,3,4,5,6,7,8,9,10,11,12].map(n => n + '=' + hitText(n)).join(' ')));
  console.log('meta:', await page.evaluate(() => DATA.meta.hitLocation));
  console.log('attack list:', await page.evaluate(() => hitListText(HIT_ATTACK)));
  console.log('defend list:', await page.evaluate(() => hitListText(HIT_DEFEND)));
  const J = await page.evaluate(() => { const p = (sum, dc, dis) => judgeDefense(sum, dc, 'parry', {sum, dis}).text; const e = (sum, mod, dc) => judgeDefense(sum + mod, dc, 'evade', {sum}).text;
    return { perfect: p(9,9), rightLegBy4: p(4,9), rightArmBy9: p(9,4), leftLegBy10: p(10,5), leftArmBy5: p(5,10), wrongSide: p(5,9), torso6v7: p(6,7), torso9v7: p(9,7), head3v12: p(3,12), head4v12: p(4,12),
      disPerfect: p(9,9,true), disGroupOnly: p(4,9,true), noDc: judgeDefense(7, null, 'parry', {sum:7}).text,
      evadeTie: e(8,1,9), evadePerfect: e(9,1,9), evadeOver: e(6,5,9), evadeFail: e(7,1,9), evadePerfectNegReflex: e(9,-2,9) }; });
  for (const [k, v] of Object.entries(J)) console.log('  judge ' + k + ': ' + v);
  // ตรวจทุกคู่ (โจมตี 2-12 × ป้องกัน 2-12): Parry สำเร็จก็ต่อเมื่ออยู่กลุ่มเดียวกัน
  console.log('parry matrix ok:', await page.evaluate(() => { const G = [[2,3,11,12],[4,9],[5,10],[6,7,8]]; const grp = n => G.findIndex(g => g.includes(n)); let ok = true; for (let a=2;a<=12;a++) for (let d=2;d<=12;d++){ const j = judgeDefense(d, a, 'parry', {sum:d}); const want = d===a ? 'res-crit' : (grp(a)===grp(d) ? 'res-full' : 'res-fail'); if (j.cls !== want){ ok = false; console.log('mismatch', a, d, j.cls, want); } const jd = judgeDefense(d, a, 'parry', {sum:d, dis:true}); if (jd.cls !== (d===a ? 'res-crit' : 'res-fail')) ok = false; } return ok; }));
  // ผลทอยโจมตีบอกตำแหน่ง
  console.log('attack judge:', await page.evaluate(() => { const mk = (a,b) => ({dice:[a,b], kept:[a,b], keptIdx:[0,1], sum:a+b, crit:null, double:a===b, mode:'normal'}); return [mk(6,3), mk(1,3), mk(4,4), mk(2,3), mk(6,4), mk(6,5)].map(r => doRoll({label:'Attack', kind:'attack', r}).judge.text); }));

  // ================= 2) ชีท: กล่อง Toughness + ผังใหม่ + ปุ่มเพิ่ม =================
  await page.evaluate(() => { const K = window.__kirana; const kin = DATA.kins.find(k=>k.id==='lunaryn');
    K.Store.upsert({ id:'s14', name:'อัศวินกระดาษ', kin:'lunaryn', size:'Medium', childhood:kin.childhood[0].code, adulthood:kin.adulthood[0].code, extra:{STR:3,VIT:3,AGI:2}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{range:1}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' }); });
  await page.goto(url + '#sheet-s14'); await page.waitForTimeout(900);
  console.log('tough box:', await page.evaluate(() => { const g = document.querySelector('#v-sheet .box[data-k="tough"] .body2'); const cs = getComputedStyle(g); const cells = [...g.children]; const lab = cells[3].getBoundingClientRect(), ctl = cells[4].getBoundingClientRect(), inp = cells[5].getBoundingClientRect(); const z = uiZoom();
    return {cols: cs.gridTemplateColumns.split(' ').length, gapLabelToTough: Math.round((ctl.left - lab.right)/z), armorInputW: Math.round(inp.width/z), hit: [...g.querySelectorAll('.hitnum')].map(e=>e.textContent), note: /Perfect Parry/.test(document.querySelector('#v-sheet .box[data-k="tough"] .hitnote').textContent), oldRoll: /1d6/.test(document.querySelector('#v-sheet .box[data-k="tough"]').textContent)}; }));
  const cols = async () => page.$$eval('#v-sheet .cs .cscol', cs => cs.map(c => [...c.children].map(b => b.dataset.k)));
  const c3 = await cols(); console.log('columns:', JSON.stringify(c3));
  console.log('layout ok:', c3.length===3 && c3[2].includes('traits') && c3[1][0]==='portrait' && c3[1][1]==='trait' && c3[1][2]==='prof' && c3[2][0]==='status' && c3[2][1]==='res', 'no null text:', !(await page.$eval('#v-sheet', e => /\bnull\b|\bundefined\b|\bfalse\b/.test(e.textContent))));
  // เพิ่ม Trait เอง
  console.log('add buttons:', await page.$$eval('#v-sheet .addbtn', es => es.map(e => e.closest('.box').dataset.k)));
  await page.click('#v-sheet .box[data-k="trait"] .addbtn'); await page.waitForTimeout(200);
  await page.click('.customtrait button.primary'); await page.waitForTimeout(150); // ไม่ใส่ชื่อ → ไม่บันทึก
  console.log('empty name refused:', !(await page.evaluate(() => (window.__kirana.Store.get('s14').customTraits||[]).length)), 'modal still open:', !(await page.evaluate(() => document.getElementById('modal').classList.contains('hidden'))));
  await page.fill('.customtrait input', 'แผลเป็นจากศึกสะพานหิน'); await page.fill('.customtrait textarea', 'ได้ Advantage ในการทอย INF Check เพื่อข่มขู่ทหารจักรวรรดิ\nใช้ได้ 1 ครั้งต่อ Long Rest'); await page.click('.customtrait button.primary'); await page.waitForTimeout(400);
  await page.click('#v-sheet .box[data-k="prof"] .addbtn'); await page.waitForTimeout(200);
  await page.fill('.customtrait input', 'Bridge Warden'); await page.fill('.customtrait textarea', '+1 Parry Dice เมื่อยืนบนสะพานหรือทางแคบ'); await page.click('.customtrait button.primary'); await page.waitForTimeout(400);
  console.log('custom saved:', await page.evaluate(() => { const c = window.__kirana.Store.get('s14'); return {traits: (c.customTraits||[]).map(x=>x.name), profs: (c.customProfs||[]).map(x=>x.name)}; }));
  console.log('custom shown:', await page.$$eval('#v-sheet .titem.custom', es => es.map(e => e.closest('.box').dataset.k + ': ' + e.textContent.replace(/\s+/g,' ').slice(0,70))));
  console.log('hindrance has no add:', !(await page.$('#v-sheet .box[data-k="hind"] .addbtn')));
  // แก้ไข แล้วลบ
  await page.click('#v-sheet .box[data-k="trait"] .titem.custom .editbtn'); await page.waitForTimeout(200);
  await page.fill('.customtrait input', 'แผลเป็นแห่งสะพานหิน'); await page.click('.customtrait button.primary'); await page.waitForTimeout(300);
  console.log('edited:', await page.evaluate(() => window.__kirana.Store.get('s14').customTraits.map(x=>x.name)));
  await page.click('#v-sheet .box[data-k="prof"] .titem.custom .editbtn'); await page.waitForTimeout(200);
  await page.click('.customtrait button.danger'); await page.waitForTimeout(300);
  console.log('deleted prof:', await page.evaluate(() => (window.__kirana.Store.get('s14').customProfs||[]).length), 'trait kept:', await page.evaluate(() => window.__kirana.Store.get('s14').customTraits.length));
  await page.screenshot({ path: 'test/130-sheet-v114.png', fullPage: true });
  // จอกลาง (2 คอลัมน์) และมือถือ (1 คอลัมน์) ยังจัดได้
  await page.setViewportSize({ width: 1150, height: 900 }); await page.goto(url + '#chars'); await page.goto(url + '#sheet-s14'); await page.waitForTimeout(700);
  console.log('2-col:', (await cols()).map(c => c.length));
  await page.setViewportSize({ width: 600, height: 900 }); await page.goto(url + '#chars'); await page.goto(url + '#sheet-s14'); await page.waitForTimeout(700);
  console.log('1-col:', (await cols()).map(c => c.length));
  await page.setViewportSize({ width: 1400, height: 1000 });

  // ================= 3) เขต + 4) Range knowledge =================
  console.log('bands:', await page.evaluate(() => [1,2,3,5,6,10,12].map(n => { const b = rangeBand(n); return n + 'ช่อง=' + b.m + 'ม.:' + b.id; }).join(' ')));
  await page.goto(url + '#rules'); await page.waitForTimeout(400);
  const rules = await page.$eval('#v-rules', e => e.textContent);
  console.log('rules page zones:', /เขตใกล้เคียง 4-10 ม\.: วิ่งเข้าร่วมวงได้ทันที ยิงใส่เขตปะทะได้/.test(rules), /เขตไกล 11-20\+ ม\.: ยิงยากขึ้น \(ลด CV ตามระยะ\) เคลื่อนที่ไปต้องใช้ Swift \+ 1 AP/.test(rules), 'old gone:', !/4-25|26-100|1d6: 1-3/.test(rules), 'hit lines:', /Hit Location เมื่อโจมตี/.test(rules) && /แขนขวา 4,9 · ขาขวา 9,4 · แขนซ้าย 10,5 · ขาซ้าย 5,10/.test(rules));
  console.log('glossary:', await page.evaluate(() => [GLOSSARY['Nearby Zone'].text, GLOSSARY['Far Zone'].text, /\[4 = แขนขวา\] \[9 = ขาขวา\] \[10 = แขนซ้าย\] \[5 = ขาซ้าย\]/.test(GLOSSARY['Hit Location'].text), /1d6/.test(GLOSSARY['Hit Location'].text)]));
  console.log('range knowledge:', await page.evaluate(() => { const k = DATA.knowledge.find(x=>x.id==='range'); return [0,1,2,3].map(l => 'L' + l + ': ' + k.levels[l].text.slice(0, 26)); }));
  console.log('sight label dim:', await page.evaluate(() => sightLabel({nv:false}, 'dim')), '| note:', await page.evaluate(() => LIGHT_NOTE.dim.slice(0, 40)));
  // บทสอน: บทโจมตีใช้ตำแหน่งใหม่ ไม่มีทอย 1d6 ซ้ำ และบทระยะใช้ 10 เมตร
  console.log('tutorial text:', await page.evaluate(() => { const all = JSON.stringify(LESSONS); return {noSubRoll: !/ทอยลูกเดียวต่อ/.test(all), near10: /ไม่เกินสิบเมตร/.test(all) && !/ยี่สิบห้าเมตร/.test(all), groups: /ข้างขวาสี่กับเก้า ข้างซ้ายห้ากับสิบ/.test(all)}; }));

  // ================= 6) Twinborn =================
  await page.evaluate(() => { const K = window.__kirana; const kin = DATA.kins.find(k=>k.id==='lunaryn');
    K.Store.upsert({ id:'tw', name:'ลูน่า', kin:'lunaryn', size:'Medium', childhood:'CS2', adulthood:kin.adulthood[0].code, extra:{STR:3,VIT:3,AGI:2}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' });
    K.Store.upsert({ id:'solo', name:'เดี่ยว', kin:'lunaryn', size:'Medium', childhood:kin.childhood[0].code, adulthood:kin.adulthood[0].code, extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' }); });
  console.log('twinborn rule text:', await page.evaluate(() => { const b = DATA.kins.find(k=>k.id==='lunaryn').specialChildhood.find(x=>x.nameEn==='Twinborn'); return {noBan: !/ไม่สามารถเดินทางแยกจากกันโดยเจตนาได้/.test(b.text), sep: /Separate Paths: แฝดสามารถเดินทางแยกจากกันโดยเจตนาได้/.test(b.text), gm: /GM จะเป็นผู้ควบคุมแทนอยู่หลังฉาก/.test(b.text), ask: /สอบถาม GM ถึงเหตุการณ์ที่เกิดกับอีกร่างได้ตลอดเวลา/.test(b.text), choose: /ผู้เล่นยังเป็นผู้เลือกคำตอบตามปกติ/.test(b.text), bags: /HP Toughness เกราะ และกระเป๋าแยกกัน/.test(b.text), v115: [/Attack of Opportunity ทำได้รวมกัน 1 ครั้งต่อรอบ/, /อีกร่างเข้าสู่สภาวะใกล้ตายทันที/, /กินเสบียงสองอัตราต่อการพัก/, /แต่ละร่างได้ Action ครบชุดในฉากของตัวเอง/].every(re=>re.test(b.text))}; }));
  await page.goto(url + '#sheet-tw'); await page.waitForTimeout(900);
  console.log('twin sheet:', await page.evaluate(() => { const c = window.__kirana.Store.get('tw'); return {is: isTwinborn(c), solo: isTwinborn(window.__kirana.Store.get('solo')), hp: c.current.hp, hp2: c.current.hp2, inv2: Array.isArray(c.inventory2), bars: [...document.querySelectorAll('#v-sheet .box[data-k="res"] .resbar .l b')].map(e=>e.textContent), box: !!document.querySelector('#v-sheet .twinbox'), col: [...document.querySelectorAll('#v-sheet .cs .cscol')].findIndex(x=>x.querySelector('.twinbox'))}; }));
  // HP ร่าง B แยกจากร่าง A
  await page.click('#v-sheet .box[data-k="res"] .resbar:nth-of-type(3) .ctl button'); await page.waitForTimeout(300); // − ของร่าง B
  console.log('hp after B −1:', await page.evaluate(() => { const cur = window.__kirana.Store.get('tw').current; return {hp: cur.hp, hp2: cur.hp2}; }));
  // กระเป๋าสองใบ: ย้ายของไปร่าง B แล้วเพิ่มของในร่าง B
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(400);
  console.log('bag tabs:', await page.$$eval('.hud-win .bagtab', es => es.map(e => e.textContent)));
  const invA0 = await page.evaluate(() => window.__kirana.Store.get('tw').inventory.map(x=>x.name));
  await page.click('.hud-win .tile:not(.add)'); await page.waitForTimeout(300);
  await page.click('.hud-win .movebtn'); await page.waitForTimeout(400);
  await page.click('.hud-win .bagtab[data-body="B"]'); await page.waitForTimeout(300);
  console.log('moved:', await page.evaluate(() => { const c = window.__kirana.Store.get('tw'); return {a: c.inventory.length, b: c.inventory2.map(x=>x.name)}; }), 'was', invA0.length, 'B tab tiles:', (await page.$$('.hud-win .tile:not(.add)')).length, 'sub:', await page.$eval('.hud-win .hud-sub', e => e.textContent));
  await page.click('.hud-win .tile.add'); await page.waitForTimeout(300);
  console.log('add in B:', await page.evaluate(() => { const c = window.__kirana.Store.get('tw'); return {a: c.inventory.length, b: c.inventory2.length}; }), 'wear control in B:', await page.$$eval('.hud-win .hud-detail select', es => es.length), 'dock keeps dice:', await page.$$eval('#hud .hud-dock .hud-btn', bs => bs.length));
  await page.click('.hud-win .tile:not(.add)'); await page.waitForTimeout(300); await page.click('.hud-win .movebtn'); await page.waitForTimeout(300);
  console.log('moved back to A:', await page.evaluate(() => { const c = window.__kirana.Store.get('tw'); return {a: c.inventory.length, b: c.inventory2.length}; }));
  await page.click('.hud-x'); await page.waitForTimeout(200);

  // ---- ห้อง (โหมดในเครื่อง): แฝดวางทีเดียวสองหมาก ----
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องแฝด'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.selectOption('#v-table select', 'tw'); await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(500);
  const tk = () => page.evaluate(() => Table.room.tokens.filter(t=>t.charId==='tw').map(t => ({name:t.name, body:t.body, hp:t.hp, san:t.san, gmRun:!!t.gmRun, x:t.x, y:t.y, turnWith: t.turnWith ? 'yes' : '', init: t.initRoll})));
  const t0 = await tk(); console.log('tokens:', JSON.stringify(t0), 'adjacent:', Math.max(Math.abs(t0[0].x-t0[1].x), Math.abs(t0[0].y-t0[1].y))===1);
  await page.selectOption('#v-table select', 'tw'); await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(300);
  console.log('place again → still', (await tk()).length, 'tokens · toast:', await page.$eval('#toast', e => e.textContent), '· sheet buttons:', await page.$$eval('#v-table .stephead button', bs => bs.filter(b=>/ชีท:/.test(b.textContent)).map(b=>b.textContent)), 'body badges:', await page.$$eval('.gridmap .bodybadge', es => es.map(e=>e.textContent)));
  await page.selectOption('#v-table select', 'solo'); await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(400);
  console.log('solo tokens:', await page.evaluate(() => Table.room.tokens.filter(t=>t.charId==='solo').map(t=>({body:t.body||null, name:t.name}))));
  // HP แยกร่าง: ลด HP หมากร่าง B → ชีท hp2 · Sanity ร่วมกัน
  await page.evaluate(() => { const r = Table.room; const b = r.tokens.find(t=>t.charId==='tw' && t.body==='B'); tokenVitals(b, 'hp', b.hp - 3); Table.save(); }); await page.waitForTimeout(400);
  console.log('B −3 on token → sheet:', await page.evaluate(() => { const cur = window.__kirana.Store.get('tw').current; return {hp: cur.hp, hp2: cur.hp2}; }), 'tokens:', JSON.stringify((await tk()).map(t=>t.body+':'+t.hp)));
  await page.evaluate(() => { const r = Table.room; const a = r.tokens.find(t=>t.charId==='tw' && t.body==='A'); tokenVitals(a, 'san', a.san - 2); Table.save(); }); await page.waitForTimeout(400);
  console.log('A sanity −2 → both tokens + sheet:', JSON.stringify((await tk()).map(t=>t.body+':'+t.san)), await page.evaluate(() => window.__kirana.Store.get('tw').current.sanity));
  // ชีท → หมาก: แก้ HP ร่าง B ในชีท แล้วหมากร่าง B ตาม หมากร่าง A ไม่เปลี่ยน
  await page.evaluate(() => { const c = window.__kirana.Store.get('tw'); c.current.hp2 = 5; c.current.hp = 11; c.current.at = Date.now() + 5; window.__kirana.Store.upsert(c); pushVitalsFromSheet(c); }); await page.waitForTimeout(400);
  console.log('sheet → tokens:', JSON.stringify((await tk()).map(t=>t.body+':'+t.hp)));
  // v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026 ข้อ 6ค): Toughness แยกร่าง ลดจากแผงของหมาก B แล้วหมาก A กับ tough ของร่าง A ในชีทไม่เปลี่ยน ส่วน tough2 ในชีทตาม
  await page.evaluate(() => { const r = Table.room; const b = r.tokens.find(t=>t.charId==='tw' && t.body==='B'); Table.sel = b.id; renderTable(); }); await page.waitForTimeout(400);
  await page.click('.combat-panel .tadj'); await page.waitForTimeout(400);
  console.log('separate toughness:', await page.evaluate(() => { const r = Table.room; const a = r.tokens.find(t=>t.charId==='tw' && t.body==='A'), b = r.tokens.find(t=>t.charId==='tw' && t.body==='B'); const c = window.__kirana.Store.get('tw'); const av = (a.tough||{}).head ?? c.current.tough.head; return {a: av, b: b.tough.head, sheetA: c.current.tough.head, sheetB: c.current.tough2.head, ok: b.tough.head === av - 1 && c.current.tough2.head === b.tough.head && c.current.tough.head === av}; }));
  console.log('token panel tags:', await page.$$eval('.twin-tok .mini .tag', es => es.map(e=>e.textContent)), 'split button:', await page.$$eval('.twin-tok .twinrow button', es => es.map(e=>e.textContent)));
  // Initiative: แฝดใช้เทิร์นร่วมกัน
  await page.click('button:has-text("เริ่มการต่อสู้")'); await page.waitForTimeout(400);
  console.log('initiative:', await page.evaluate(() => { const r = Table.room; const ts = r.tokens.filter(t=>t.charId==='tw'); return {order: r.enc.order.length, tokens: r.tokens.length, sameRoll: ts[0].initRoll===ts[1].initRoll, bTurnWithA: ts[1].turnWith===ts[0].id, bInOrder: r.enc.order.includes(ts[1].id)}; }), 'order rows:', await page.$$eval('.twin-order .tok .ord', es => es.map(e=>e.textContent)));
  await unlock();
  // ของขวัญจาก GM ลงกระเป๋าของร่างที่กดให้
  await page.evaluate(() => { const r = Table.room; const b = r.tokens.find(t=>t.charId==='tw' && t.body==='B'); const a = r.tokens.find(t=>t.charId==='tw' && t.body==='A'); sendGift(r, b, {name:'ยาสมานแผล', effect:'ฟื้น 1d6 HP', weight:0.2, qty:2}); sendGift(r, a, {name:'คบเพลิง', effect:'ส่องสว่าง', weight:0.5, qty:1}); }); await page.waitForTimeout(400);
  console.log('gifts:', await page.evaluate(() => { const c = window.__kirana.Store.get('tw'); return {a: c.inventory.some(x=>x.name==='คบเพลิง'), aHasPotion: c.inventory.some(x=>x.name==='ยาสมานแผล'), b: c.inventory2.filter(x=>x.name==='ยาสมานแผล').map(x=>x.qty)}; }));
  // เดินแยกกัน: กดที่หมากร่าง B → GM คุมร่าง B · ชีทจำสถานะตาม
  await page.click('.twin-tok .twinrow button:has-text("แยกทาง")'); await page.waitForTimeout(500);
  console.log('split on token:', JSON.stringify((await tk()).map(t=>t.body+':'+t.gmRun)), 'sheet state:', await page.evaluate(() => JSON.stringify(twinbornState(window.__kirana.Store.get('tw')))), 'chat:', await page.evaluate(() => Table.chat[0].text));
  // สิทธิ์ของเจ้าของต่อร่างที่ GM คุม (จำลองผู้เล่นที่ไม่ใช่ GM)
  console.log('owner rights:', await page.evaluate(() => { const S = window.__kirana.Store; const prev = S.me; S.me = 'uidP'; const r = {map: Table.room.map, light:'low', tokens:[{id:'a', ownerId:'uidP', x:2, y:2}, {id:'b', ownerId:'uidP', x:17, y:17, gmRun:true}]}; const out = {ownsA: ownsTok(r.tokens[0]), ownsB: ownsTok(r.tokens[1])};
    const walled = JSON.parse(JSON.stringify(r)); walled.map = {kind:'x', seed:'1', w:20, h:20, cells: Array.from({length:400}, (_,i)=> (i%20===10 ? '#' : '.')).join('')}; // กำแพงกั้นกลางแผนที่
    const vis = computeVisibility(walled, 'uidP'); out.seesOwnSide = vis.has('3,3'); out.seesThroughGmRunTwin = vis.has('17,16'); S.me = prev; return out; }));
  // มุมมองผู้เล่นเจ้าของ (ไม่ใช่ GM): ร่างที่ GM คุมลากไม่ได้ แก้ค่าไม่ได้ ซ่อนแล้วมองไม่เห็น · ร่างที่บังคับเองมีปุ่มถาม GM
  console.log('player view:', await page.evaluate(() => { const S = window.__kirana.Store; const r = Table.room; const prev = {me: S.me, lm: Table.localMode, gmId: r.gmId, keys: localStorage.getItem('kirana.gmkeys'), sel: Table.sel};
    const a = r.tokens.find(t=>t.charId==='tw' && t.body==='A'), b = r.tokens.find(t=>t.charId==='tw' && t.body==='B'); const out = {};
    try { S.me = 'local'; Table.localMode = false; r.gmId = 'gm-someone'; localStorage.setItem('kirana.gmkeys', '{}'); out.isGM = Table.isGM();
      const grab = (t) => { const el = [...document.querySelectorAll('.gridmap .cell')].find(c => +c.dataset.x===t.x && +c.dataset.y===t.y); const tk = el && el.querySelector('.gtok'); return tk ? tk.classList.contains('grab') : null; };
      Table.sel = b.id; renderTableInner(); out.dragA = grab(a); out.dragB = grab(b);
      out.panelB = {vitalButtons: document.querySelectorAll('.twin-tok .vital button').length, twinButtons: [...document.querySelectorAll('.twin-tok .twinrow button')].map(e=>e.textContent), toughButtons: document.querySelectorAll('.twin-tok .combat-panel .tadj').length, ctl: [...document.querySelectorAll('.twin-tok button')].some(e=>/เอาออก/.test(e.textContent))};
      Table.sel = a.id; renderTableInner(); out.panelA = {vitalButtons: document.querySelectorAll('.twin-tok .vital button').length, twinButtons: [...document.querySelectorAll('.twin-tok .twinrow button')].map(e=>e.textContent)};
      b.hidden = true; renderTableInner(); out.hiddenBVisibleToOwner = grab(b) !== null; b.hidden = false;
    } finally { S.me = prev.me; Table.localMode = prev.lm; r.gmId = prev.gmId; if (prev.keys==null) localStorage.removeItem('kirana.gmkeys'); else localStorage.setItem('kirana.gmkeys', prev.keys); Table.sel = prev.sel; renderTable(); }
    return out; }));
  // กลับมารวมจากชีท แล้วแยกอีกแบบ (ผู้เล่นบังคับร่าง B)
  await page.goto(url + '#sheet-tw'); await page.waitForTimeout(700);
  console.log('sheet select shows:', await page.$eval('#v-sheet .twinbox select', e => e.value), 'ask button:', !!(await page.$('#v-sheet .twinbox button:has-text("ถาม GM")')));
  await page.click('#v-sheet .twinbox button:has-text("ถาม GM")'); await page.waitForTimeout(300);
  console.log('ask posts secret:', await page.evaluate(() => { const m = Table.chat[0]; return {text: m.text.slice(0, 40), gmOnly: !!m.gmOnly, who: m.who}; }));
  await page.selectOption('#v-sheet .twinbox select', 'apartB'); await page.waitForTimeout(400);
  console.log('apartB from sheet → tokens:', await page.evaluate(() => Table.room.tokens.filter(t=>t.charId==='tw').map(t=>t.body+':'+!!t.gmRun)));
  await page.selectOption('#v-sheet .twinbox select', 'together'); await page.waitForTimeout(400);
  console.log('together → tokens:', await page.evaluate(() => Table.room.tokens.filter(t=>t.charId==='tw').map(t=>t.body+':'+!!t.gmRun)));
  // ชื่อร่าง B เปลี่ยนแล้วหมากเปลี่ยนตาม
  await page.fill('#v-sheet .twinbox input', 'ลูนี่'); await page.click('#v-sheet h2'); await page.waitForTimeout(400);
  console.log('rename B:', await page.evaluate(() => Table.room.tokens.filter(t=>t.charId==='tw').map(t=>t.name)));
  // ข้อความลับถึงเจ้าของ: ผู้รับเห็น คนอื่นไม่เห็น
  console.log('whisper filter:', await page.evaluate(() => { const S = window.__kirana.Store; const vis = (me, gm) => [{gmOnly:true, authorId:'gm1', toId:'uidP'}, {gmOnly:true, authorId:'gm1'}, {gmOnly:false, authorId:'x'}].filter(m => !m.gmOnly || gm || m.authorId===me || (m.toId && m.toId===me)).length; return {owner: vis('uidP', false), other: vis('uidQ', false), gm: vis('gm1', true)}; }));
  // เอาหมากออก: เหลืออีกร่าง สำเนาชีทยังอยู่ · เอาออกหมด เลิกแชร์
  await page.goto(url + '#room-' + await page.evaluate(() => Table.roomId)); await page.waitForTimeout(500);
  const rm = async (body) => { await page.evaluate((b) => { const t = Table.room.tokens.find(x=>x.charId==='tw' && x.body===b); Table.sel = t.id; renderTable(); }, body); await page.waitForTimeout(300); await page.click('.twin-tok button:has-text("เอาออก")'); await page.waitForTimeout(400); };
  await rm('A');
  console.log('removed A:', await page.evaluate(() => { const r = Table.room; const b = r.tokens.find(t=>t.charId==='tw'); return {left: r.tokens.filter(t=>t.charId==='tw').length, shared: (window.__kirana.Store.get('tw').roomIds||[]).includes(r.id), bTakesTurn: r.enc.order.includes(b.id) && !b.turnWith}; }));
  await rm('B');
  console.log('removed B:', await page.evaluate(() => { const r = Table.room; return {left: r.tokens.filter(t=>t.charId==='tw').length, shared: (window.__kirana.Store.get('tw').roomIds||[]).includes(r.id), order: r.enc.order.length, tokens: r.tokens.length}; }));
  // เลิกเป็นแฝด (แก้พื้นหลัง): ของในกระเป๋าร่าง B กลับเข้ากระเป๋าหลัก
  console.log('no longer twin:', await page.evaluate(() => { const S = window.__kirana.Store; const c = S.get('tw'); const kin = DATA.kins.find(k=>k.id==='lunaryn'); const nA = c.inventory.length, nB = c.inventory2.length; c.childhood = kin.childhood[0].code; ensureSheetState(c, compute(c)); return {merged: c.inventory.length === nA + nB, inv2: c.inventory2===undefined, twin: isTwinborn(c)}; }));
  await page.screenshot({ path: 'test/131-room-v114.png' });
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
