// v1.26 (ร่าง ยังไม่ขึ้นเว็บ · Non สั่ง 15 พ.ย. 2026)
//  A) หน้าตำนานแบบวิกิ: สารบัญเป็นเส้นเวลาที่แตกกิ่ง บทความ ลิงก์ข้ามบทความ ค้นหา ไม่มีปีศักราช
//  B) คลังทักษะ: แบ่งตามหมวดและประเภทของไฟล์ ระดับ Novice Expert Master ตัวกรอง และลิงก์จากหน้าวงศา
//  C) คลังไอเทม: แบ่งตามรูปแบบการใช้ Tier ของอาวุธ โล่ หมวกเกราะ และตัวอย่างระดับจากไฟล์แกน
//  D) NPC ใส่อาวุธและชุดเกราะได้ ทั้งในคลังและบนโต๊ะ เกราะต่อส่วนคิดด้วยกฎเดียวกับชีท
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  await page.goto(url); await wait(400);

  // ================= A) ตำนาน =================
  const A0 = await page.evaluate(() => {
    const ids = Object.keys(LORE); const all = JSON.stringify(LORE);
    const links = [...all.matchAll(/\[\[([a-z0-9]+)/g)].map(m => m[1]);
    const text = ids.map(id => loreHay(id)).join(' ') + LORE_ERAS.map(e => e.blurb).join(' ');
    return { n: ids.length, broken: [...new Set(links.filter(x => !LORE[x]))], events: LORE_ORDER.length, missingEvents: LORE_ORDER.filter(x => !LORE[x] || LORE[x].kind !== 'event'),
      badIds: ids.filter(id => !/^[a-z0-9]+$/.test(id)), badParents: ids.filter(id => LORE[id].parent && !LORE[LORE[id].parent]), badBranches: ids.filter(id => (LORE[id].branches || []).some(b => !LORE[b])),
      years: (text.match(/(?:ศักราช(?:ที่)?\s*|ปี\s*)\d{3,4}|\b1[0-9]{3}\b/g) || []), sunrise: /ดวงอาทิตย์(?:ที่)?(?:เริ่ม)?โผล่|ตะวันโผล่พ้น/.test(text),
      dashes: (text.match(/\s[—–]\s|\s-\s|--/g) || []).length };
  });
  ok('A: lore data links resolve', A0.broken.length === 0 && A0.badIds.length === 0 && A0.badParents.length === 0 && A0.badBranches.length === 0, A0);
  ok('A: timeline has 13 events across 3 eras', A0.events === 13 && A0.missingEvents.length === 0 && A0.n >= 45, A0);
  ok('A: no years and no visible sun disc', A0.years.length === 0 && !A0.sunrise, A0.years);
  ok('A: no dash clause joints', A0.dashes === 0, A0.dashes);
  await page.goto(url + '#lore'); await wait(500);
  const A1 = await page.evaluate(() => ({ eras: document.querySelectorAll('.tl-era').length, evs: document.querySelectorAll('.tl-ev').length, chips: document.querySelectorAll('.tl-branches .lchip').length,
    hyChips: [...document.querySelectorAll('.tl-ev[data-id="hundredyears"] .tl-branches .lchip')].map(a => a.getAttribute('href')),
    toc: document.querySelectorAll('.lore-toc .toc-evs li').length, kinds: document.querySelectorAll('.lore-kind').length, active: (document.querySelector('#nav a.active') || {}).dataset, bg: document.body.classList.contains('bg-study') }));
  ok('A: home timeline with branches and index', A1.eras === 3 && A1.evs === 13 && A1.chips > 30 && A1.toc === 13 && A1.kinds === 5 /* v1.30: กล่องเผ่าพันธุ์แยกจากฝ่าย */ && A1.bg, A1);
  ok('A: hundred years war branches to its people and factions', ['#lore-bloodmoon', '#lore-sevenlunars', '#lore-eclipse', '#lore-nemessiah', '#lore-syntyr'].every(x => A1.hyChips.includes(x)), A1.hyChips);
  ok('A: nav marks the library entry', A1.active && A1.active.v === 'lore', A1.active);
  await page.click('.tl-ev[data-id="hundredyears"] .tl-card'); await wait(400);
  const A2 = await page.evaluate(() => ({ hash: location.hash, title: (document.querySelector('.lore-title') || {}).textContent, heads: document.querySelectorAll('.lore-h').length, intoc: document.querySelectorAll('.lore-intoc li').length,
    quotes: document.querySelectorAll('.lore-quote').length, links: document.querySelectorAll('.lore-art a.lorelink').length, info: document.querySelectorAll('.lore-ibt tr').length, bcards: document.querySelectorAll('.lore-bcard').length,
    prev: (document.querySelector('.lore-navbtn.prev') || {}).getAttribute && document.querySelector('.lore-navbtn.prev').getAttribute('href'), next: document.querySelector('.lore-navbtn.next').getAttribute('href'),
    mini: (document.querySelector('.lore-mini li.cur') || {}).textContent, game: [...document.querySelectorAll('.lore-game .gchip')].map(b => b.textContent), crumbs: document.querySelector('.lore-crumbs').textContent, top: Math.round(window.scrollY) }));
  ok('A: article renders as a wiki page', A2.hash === '#lore-hundredyears' && A2.title === 'สงครามร้อยปี' && A2.heads >= 10 && A2.intoc === A2.heads - 1 && A2.quotes === 2 && A2.links > 10 && A2.info >= 5, A2);
  ok('A: article branches, prev/next, mini timeline, crumbs', A2.bcards === 7 && A2.prev === '#lore-rangers' && A2.next === '#lore-destiny' && A2.mini === 'สงครามร้อยปี' && /ยุคมืด/.test(A2.crumbs) && A2.top === 0, A2);
  ok('A: game box lists playable kins', A2.game.length === 3 && A2.game.some(x => /Lunaryn/.test(x)), A2.game);
  await page.click('.lore-art a.lorelink[href="#lore-nemessiah"]'); await wait(300);
  const A3 = await page.evaluate(() => ({ title: document.querySelector('.lore-title').textContent, back: [...document.querySelectorAll('.lore-back .lchip')].map(a => a.getAttribute('href')), hit: [...document.querySelectorAll('.lore-mini li.hit')].map(li => li.textContent) }));
  ok('A: cross links and backlinks', A3.title === 'เนเมสไซอาร์' && A3.back.includes('#lore-hundredyears') && A3.hit.includes('สงครามร้อยปี'), A3);
  await page.goto(url + '#lore-manaenclosure'); await wait(300);
  const A4 = await page.evaluate(() => ({ crumbs: document.querySelector('.lore-crumbs').textContent, prev: document.querySelector('.lore-navbtn.prev').getAttribute('href'), mini: [...document.querySelectorAll('.lore-mini li.hit')].map(li => li.textContent) }));
  ok('A: sub-topic points back to its event', /รุ่งอรุณแห่งสหพันธรัฐ/.test(A4.crumbs) && A4.prev === '#lore-federation' && A4.mini.includes('รุ่งอรุณแห่งสหพันธรัฐ'), A4);
  await page.evaluate(() => { Codex.loreQ = 'แร่รัตติกาล'; location.hash = '#lore'; }); await wait(300);
  const A5 = await page.evaluate(() => ({ hits: [...document.querySelectorAll('.lore-hit')].map(a => a.getAttribute('href')), marks: document.querySelectorAll('.lore-hit mark').length }));
  ok('A: search finds articles and highlights', A5.hits[0] === '#lore-umbralite' && A5.hits.includes('#lore-silence') && A5.marks === A5.hits.length, A5);
  await page.evaluate(() => { Codex.loreQ = ''; }); await page.goto(url + '#lore-silence'); await wait(300);
  await page.click('.lore-game .gchip:has-text("ใยอาคมอัมบราไลต์")'); await wait(200);
  const A6 = await page.evaluate(() => ({ h: document.querySelector('.itemmodal h3').textContent, tags: [...document.querySelectorAll('.itemmodal .tag')].map(t => t.textContent) }));
  ok('A: game box opens the item card', A6.h === 'ใยอาคมอัมบราไลต์' && A6.tags.includes('Armor 1/4 (Sorceries Resistance)'), A6);
  await page.click('.itemmodal button:has-text("เปิดในคลังไอเทม")'); await wait(400);
  const A7 = await page.evaluate(() => ({ hash: location.hash, q: document.querySelector('#v-items .cx-bar input').value, n: document.querySelectorAll('#v-items .cx-it').length }));
  ok('A: item card jumps into the item library', A7.hash === '#items' && A7.q === 'ใยอาคมอัมบราไลต์' && A7.n === 1, A7);
  await page.evaluate(() => { Codex.it.q = ''; });
  // เมนูคลังความรู้: เปิด กด แล้วปิดเอง
  await page.goto(url + '#home'); await wait(300);
  await page.click('#nav-codex > summary'); await wait(100);
  const N0 = await page.evaluate(() => document.getElementById('nav-codex').open);
  await page.click('#nav-codex a[data-v="skills"]'); await wait(400);
  const N1 = await page.evaluate(() => ({ open: document.getElementById('nav-codex').open, hash: location.hash, active: [...document.querySelectorAll('#nav a.active')].map(a => a.dataset.v), headerH: Math.round(document.querySelector('header.top').getBoundingClientRect().height) }));
  ok('A: library menu opens, navigates, closes', N0 === true && N1.open === false && N1.hash === '#skills' && N1.active.join() === 'skills', N1);
  ok('A: header stays on one row at 1400px', N1.headerH < 80, N1.headerH);

  // ================= B) คลังทักษะ =================
  const B0 = await page.evaluate(() => ({ tabs: [...document.querySelectorAll('#v-skills .cx-tab')].map(b => +b.querySelector('.n').textContent), groups: document.querySelectorAll('#v-skills .cx-group').length, cards: document.querySelectorAll('#v-skills .cx-sk').length,
    tierHeads: [...document.querySelectorAll('#v-skills .cx-group[data-sub="Chaos Sorcery"] .cx-tierhead .tag')].map(t => t.textContent), subTh: document.querySelector('#v-skills .cx-group[data-sub="Chaos Sorcery"] h3').textContent,
    blood: { lore: !!document.querySelector('#v-skills .cx-group[data-sub^="Blood Sorcery"] a.lchip[href="#lore-sevenlunars"]'), stale: [...document.querySelectorAll('#v-skills .cx-group[data-sub^="Blood Sorcery"] .tag.cx-branch')].length } }));
  ok('B: category tabs add up to all skills', B0.tabs.slice(0, 6).reduce((a, b) => a + b, 0) === B0.tabs[6] && B0.tabs[6] === 317, B0.tabs);
  ok('B: sorcery grouped by school then tier', B0.groups === 10 && B0.cards === 149 && B0.tierHeads.join() === 'Novice,Expert,Master' && /ศาสตร์เวทแห่งความโกลาหล/.test(B0.subTh), B0);
  ok('B: blood sorcery links to lore and hides the stale branch', B0.blood.lore && B0.blood.stale === 0, B0.blood);
  await page.click('#v-skills .cx-chip[data-tier="Master"]'); await wait(200);
  const B1 = await page.evaluate(() => ({ n: document.querySelectorAll('#v-skills .cx-sk').length, tiers: [...new Set([...document.querySelectorAll('#v-skills .cx-sk .tag.neg')].map(t => t.textContent))] }));
  ok('B: tier filter', B1.n === 20 && B1.tiers.join() === 'Master', B1);
  await page.click('#v-skills .cx-chip[data-tier=""]'); await page.click('#v-skills .cx-chip[data-act="reaction"]'); await wait(200);
  const B2 = await page.evaluate(() => [...document.querySelectorAll('#v-skills .cx-sk')].every(c => /Reaction/i.test(c.textContent)) && document.querySelectorAll('#v-skills .cx-sk').length > 0);
  ok('B: action filter', B2);
  await page.click('#v-skills .cx-tab[data-cat="martial"]'); await wait(300);
  const B3 = await page.evaluate(() => ({ hash: location.hash, tierRow: !!document.querySelector('#v-skills .cx-chip[data-tier]'), act: Codex.sk.act, n: document.querySelectorAll('#v-skills .cx-sk').length, ip: [...document.querySelectorAll('#v-skills .cx-group[data-sub="Qi"] .cx-sk')].map(c => +((c.textContent.match(/(\d+) IP/) || [])[1] || 99)) }));
  ok('B: martial has no tier row, sorted by IP, filters reset on tab change', B3.hash === '#skills-martial' && !B3.tierRow && B3.act === '' && B3.n === 69 && B3.ip.every((v, i, a) => !i || a[i - 1] <= v), B3);
  await page.fill('#v-skills .cx-bar input[type=search]', 'กระบวนท่า'); await wait(200);
  const B4 = await page.evaluate(() => document.querySelectorAll('#v-skills .cx-sk').length);
  ok('B: search narrows the list', B4 > 0 && B4 < 69, B4);
  await page.fill('#v-skills .cx-bar input[type=search]', ''); await wait(100);
  await page.goto(url + '#lore-solrin'); await wait(300);
  await page.click('.lore-game .gchip'); await wait(200); await page.click('.kinmodal button.primary'); await wait(700);
  const B5 = await page.evaluate(() => { const g = document.querySelector('#v-skills .cx-group[data-sub="Solrin"]'); return { hash: location.hash, top: g ? Math.round(g.getBoundingClientRect().top) : null, n: g ? g.querySelectorAll('#v-skills .cx-sk').length : 0 }; });
  ok('B: kin card jumps to that kin\'s skills', B5.hash === '#skills-kins' && B5.top !== null && B5.top < 200 && B5.n === 3, B5);

  // ================= C) คลังไอเทม =================
  await page.goto(url + '#items-weapon'); await wait(400);
  const C0 = await page.evaluate(() => ({ tabs: [...document.querySelectorAll('#v-items .cx-tab')].map(b => +b.querySelector('.n').textContent), melee: [...document.querySelectorAll('#v-items .cx-group[data-cat="อาวุธประชิด"] .cx-tierhead b')].map(b => b.textContent),
    count: document.querySelector('#v-items .cx-count').textContent, total: (DATA.items || []).length, coreS: [...document.querySelectorAll('#v-items .tag.tier-core')].length,
    tech: [...document.querySelectorAll('#v-items .cx-group[data-cat="อาวุธเทคโนโลยี"] .cx-tierhead b, #v-items .cx-group[data-cat="อาวุธเวทมนตร์"] .cx-tierhead b')].map(b => b.textContent) }));
  ok('C: family tabs cover every item', C0.tabs.slice(0, 5).reduce((a, b) => a + b, 0) === C0.total && C0.total === 445 && C0.tabs[5] === 31, C0.tabs);
  ok('C: melee weapons grouped by tier 1 to 4', C0.melee.join('|') === 'Tier 1 · ของสามัญ|Tier 2 · ของทหาร|Tier 3 · ของชั้นยอด|Tier 4 · ของในตำนาน' && C0.count === '93 ชิ้น', C0);
  // v1.26 Non เคาะ: อาวุธเทคโนโลยีและอาวุธเวทมนตร์เป็นอาวุธระดับพิเศษ ระดับมาจากไฟล์ (ไม่ต้องพึ่งตัวอย่างไฟล์แกนแล้ว)
  ok('C: tech and magic weapons sit in the special tier from the file', C0.coreS === 0 && C0.tech.length === 2 && C0.tech.every(t => t === 'Tier พิเศษ · ของเวทมนตร์และของพิเศษ'), C0);
  await page.click('#v-items .cx-chip[data-tier="4"]'); await wait(200);
  const C1 = await page.evaluate(() => ({ n: document.querySelectorAll('#v-items .cx-it').length, tags: [...document.querySelectorAll('#v-items .cx-it')].every(c => /Tier 4/.test(c.textContent)) }));
  ok('C: tier filter', C1.n === 8 && C1.tags, C1);
  await page.click('#v-items .cx-tab[data-fam="armor"]'); await wait(300);
  const C2 = await page.evaluate(() => ({ tier: Codex.it.tier, body: [...document.querySelectorAll('#v-items .cx-group[data-cat="เกราะลำตัว"] .cx-tierhead b')].map(b => b.textContent), core: [...document.querySelectorAll('#v-items .cx-group .tag.tier-core')].map(t => t.closest('#v-items .cx-it').querySelector('b').textContent + ':' + t.textContent),
    under: Object.fromEntries([...document.querySelectorAll('#v-items .cx-group[data-cat="เกราะลำตัว"] .cx-tierhead')].map(th => [th.querySelector('b').textContent.split(' · ')[0], [...th.nextElementSibling.querySelectorAll('.cx-it b')].map(b => b.textContent)])),
    partialNote: (document.querySelector('#v-items .cx-group[data-cat="เกราะส่วนย่อย"] .cx-note') || {}).textContent,
    helm: [...document.querySelectorAll('#v-items .cx-group[data-cat="หมวกเกราะ"] .cx-tierhead b')].map(b => b.textContent).length, shield: [...document.querySelectorAll('#v-items .cx-group[data-cat="โล่"] .cx-it')].length }));
  // v1.26 Non เคาะ: เกราะลำตัวจัดตาม Tier เหมือนอาวุธ ตัวอย่างในไฟล์แกนตกอยู่ใน Tier ของมันเอง
  ok('C: armour tab: body armour by tier with core examples in place', C2.tier === '' && C2.body.join() === 'Tier 1 · ของสามัญ,Tier 2 · ของทหาร,Tier 3 · ของชั้นยอด,Tier 4 · ของในตำนาน,Tier พิเศษ · ของเวทมนตร์และของพิเศษ' && C2.core.length === 0
    && C2.under['Tier 1'].includes('เกราะหนังฟอก') && C2.under['Tier 2'].includes('เกราะโซ่ถัก') && C2.under['Tier 3'].includes('เกราะแผ่นช่วงอก') && C2.under['Tier 4'].includes('เกราะแผ่นเต็มยศ') && /Tier ต่ำไปสูง/.test(C2.partialNote || ''), C2);
  ok('C: helmets and shields by tier', C2.helm === 4 && C2.shield === 10, C2);
  await page.click('#v-items .cx-group[data-cat="เกราะลำตัว"] .cx-it'); await wait(200);
  const C3 = await page.evaluate(() => ({ h: document.querySelector('.itemmodal h3').textContent, hit: [...document.querySelectorAll('.itemmodal p')].map(p => p.textContent).find(t => /หัก/.test(t)), inLib: [...document.querySelectorAll('.itemmodal button')].some(b => /เปิดในคลังไอเทม/.test(b.textContent)) })); /* v1.27: ผู้พัฒนามีปุ่ม ✎ แก้ไอเทมนี้ เพิ่มในหน้าต่าง */
  ok('C: item card opens details with armour hits', C3.h === 'เสื้อบุเกราะแกมเบสัน' && /หัก Blunt 3 · อื่น ๆ 1/.test(C3.hit) && !C3.inLib, C3);
  await page.evaluate(() => modal(null));
  await page.click('#v-items .cx-tab[data-fam="sets"]'); await wait(300);
  const C4 = await page.evaluate(() => ({ sets: document.querySelectorAll('#v-items .cx-set').length, items: document.querySelectorAll('#v-items .cx-set .cx-setit').length }));
  ok('C: starter sets tab', C4.sets === 31 && C4.items > 100, C4);
  await page.fill('#v-items .cx-bar input[type=search]', 'Sephine'); await wait(300);
  const C5 = await page.evaluate(() => ({ n: document.querySelectorAll('#v-items .cx-it').length, tabsOn: document.querySelectorAll('#v-items .cx-tab.on').length }));
  ok('C: search spans every family', C5.n === 3 && C5.tabsOn === 0, C5);
  await page.fill('#v-items .cx-bar input[type=search]', ''); await wait(100);

  // ================= D) NPC: อาวุธและชุดเกราะ =================
  const D0 = await page.evaluate(() => { const g = (n) => npcSlotGuess((DATA.items || []).find(it => it.name.startsWith(n)) || { name: n });
    return { sword: g('ดาบสั้น'), gamb: g('เสื้อบุเกราะแกมเบสัน'), leather: g('เกราะหนังเคลือบเงา'), chain: g('เกราะโซ่ถัก'), helm: g('หมวกเหล็ก'), kite: g('โล่ทรงว่าว'), aegis: g('โล่ตะวันประกาศิต'), boots: g('รองเท้าหนังสัตว์'), arrow: npcSlotGuess({ name: 'ลูกธนู', cat: 'กระสุน' }), shirt: g('เสื้อเชิ้ตผ้าลินิน'), trousers: g('กางเกงผ้าทอหยาบ') }; });
  ok('D: slot guess from item category and layer', D0.sword === 'weapon' && D0.gamb === 'chestIn' && D0.leather === 'chestIn' && D0.chain === 'chestOut' && D0.kite === 'shield' && D0.aegis === 'shield' && D0.boots === 'feet' && D0.arrow === 'other' && D0.shirt === 'shirt' && D0.trousers === 'legs', D0);
  const D1 = await page.evaluate(() => {
    const L = [{ name: 'ดาบ', effect: '2 PDMG (Slashing)', slot: 'weapon' }, { name: 'โซ่', effect: 'Armor 2 / 2 (Slashing) · ประเภท: ชั้นนอก (Outer)', slot: 'chestOut' }, { name: 'แกมเบสัน', effect: 'Armor 1 / 2 (Blunt)', slot: 'chestIn' }, { name: 'เข็มขัดโซ่', effect: 'Main Armor 3 ที่ลำตัว Armor 3', slot: 'waist' }, { name: 'ถุงมือ', effect: 'Armor 1 / 0', slot: 'hands' }, { name: 'โล่บัคเลอร์ (Buckler)', effect: 'เมื่อใช้คู่กับอาวุธมือเดียว +1 Parry Dice', slot: 'shield' }];
    const clean = npcEquipClean([...Array(20)].map((_, i) => ({ name: ' x' + i + ' ', effect: 'e', slot: i % 2 ? 'weapon' : 'nope', weight: '1.234' })).concat([{ name: '' }, null]));
    return { armor: npcArmor(L), pd: npcParryDice(L), pdNoWeapon: npcParryDice(L.filter(e => e.slot !== 'weapon')), pdKite: npcParryDice([{ name: 'โล่ทรงว่าว (Kite Shield)', effect: '+1 Parry Dice · ...', slot: 'shield' }]), clean: clean.length, first: clean[0], none: npcEquipClean([]), bad: npcEquipClean('x') };
  });
  ok('D: armour per part uses the sheet rules', D1.armor.torso === '3/2 (Slashing/Blunt)' && D1.armor.armL === '1' && D1.armor.armR === '1' && D1.armor.head === '' && D1.armor.legL === '', D1.armor);
  ok('D: parry dice counts shields and the buckler with a weapon', D1.pd === 1 && D1.pdNoWeapon === 0 && D1.pdKite === 1, D1);
  ok('D: equipment list is cleaned and capped', D1.clean === 16 && D1.first.name === 'x0' && D1.first.slot === 'other' && D1.first.weight === 1.23 && D1.none === null && D1.bad === null, D1);
  // ตัวแก้ไขในคลัง: เลือกจากคลังไอเทม แล้วค่าบนโต๊ะขึ้นตาม
  const nid = await page.evaluate(async () => { const it = NpcLib.newItem('npc'); it.name = 'ทหารรับจ้างถือหอก'; it.mods = { STR: 4 }; await NpcLib.save(it); return it.id; });
  await page.goto(url + '#npcedit-' + nid); await wait(500);
  ok('D: editor shows the equipment card', await page.evaluate(() => !!document.querySelector('.npceqcard .npceq-add')));
  await page.click('.npceq-add'); await wait(200);
  await page.fill('.npceqpick input[type=search]', 'หอกเหล็ก'); await wait(150);
  await page.click('.npceqpick .gift:has-text("หอกเหล็ก (Steel Spear)") button'); await wait(100);
  await page.fill('.npceqpick input[type=search]', 'เกราะโซ่ถัก'); await wait(150);
  await page.click('.npceqpick .gift:has-text("เกราะโซ่ถัก") button'); await wait(100);
  await page.fill('.npceqpick input[type=search]', 'แกมเบสัน'); await wait(150);
  await page.click('.npceqpick .gift:has-text("เสื้อบุเกราะแกมเบสัน (Field Gambeson)") button'); await wait(100);
  await page.fill('.npceqpick input[type=search]', 'โล่ทรงว่าว'); await wait(150);
  await page.click('.npceqpick .gift:has-text("โล่ทรงว่าว") button'); await wait(100);
  const D2note = await page.evaluate(() => document.querySelector('.npceqpick .npceq-added').textContent);
  await page.evaluate(() => modal(null)); await wait(150);
  const D2 = await page.evaluate((id) => { const it = NpcLib.get(id); return { eq: (it.equip || []).map(e => e.slot + ':' + e.name.split(' (')[0]), rows: document.querySelectorAll('.npceqcard .npceq-row').length, w: [...document.querySelectorAll('.npceqcard .npceq-w')].map(x => x.textContent),
    pd: [...document.querySelectorAll('.npceqcard .npceq-sum .tag')].map(t => t.textContent), torso: [...document.querySelectorAll('.npceqcard .npceq-armor tr')].map(tr => tr.textContent), saveBtn: document.querySelector('.libsave').textContent, meta: [...document.querySelectorAll('.npceqcard ~ * .tag, .card .tag')].map(t => t.textContent).filter(t => /อาวุธ/.test(t)) }; }, nid);
  ok('D: picker adds items with guessed slots', D2note.includes('เลือกต่อได้เลย') && D2.eq.join('|') === 'weapon:หอกเหล็ก|chestOut:เกราะโซ่ถัก|chestIn:เสื้อบุเกราะแกมเบสัน|shield:โล่ทรงว่าว' && D2.rows === 4, D2);
  ok('D: summary shows damage with Might, parry dice and torso armour', D2.w.some(x => /หอกเหล็ก 2 PDMG \+ Might \+3 = 5/.test(x)) && D2.pd.includes('Parry Dice 1') && D2.torso.some(x => /ลำตัว.*3\/2 \(Slashing\/Blunt\)หัก Slashing\/Blunt 5 · อื่น ๆ 3/.test(x)), D2);
  ok('D: editing marks the item unsaved and tags the preview', /•/.test(D2.saveBtn) && D2.meta.some(t => /⚔ อาวุธ 1 · สวมใส่ 3/.test(t)), D2);
  await page.fill('input[data-f="mod-STR"]', '0'); await wait(150);
  const D3 = await page.evaluate(() => [...document.querySelectorAll('.npceqcard .npceq-w')].map(x => x.textContent));
  ok('D: summary follows the STR modifier', D3.some(x => /2 PDMG \+ Might \+1 = 3/.test(x)), D3);
  await page.selectOption('.npceqcard .npceq-row[data-slot="chestIn"] select', 'other'); await wait(150);
  const D4 = await page.evaluate((id) => ({ slot: NpcLib.get(id).equip[2].slot, torso: [...document.querySelectorAll('.npceqcard .npceq-armor tr')].map(tr => tr.textContent).find(t => /ลำตัว/.test(t)) }), nid);
  ok('D: changing a slot recomputes armour', D4.slot === 'other' && /2\/2 \(Slashing\)/.test(D4.torso) && !/Blunt/.test(D4.torso), D4);
  await page.selectOption('.npceqcard .npceq-row[data-slot="other"] select', 'chestIn'); await wait(100);
  await page.click('.npceqcard .npceq-custombtn'); await wait(100);
  await page.fill('.npceq-custom input[placeholder^="ชื่อ"]', 'มีดสั้นขึ้นสนิม'); await page.fill('.npceq-custom input[placeholder^="คุณสมบัติ"]', '1 PDMG (Piercing)');
  await page.click('.npceq-custom button'); await wait(150);
  await page.click('.libsave'); await wait(300);
  const D5 = await page.evaluate((id) => { const it = NpcLib.get(id); const back = libClean(JSON.parse(JSON.stringify(it))); return { n: (back.equip || []).length, last: back.equip[4], stored: (JSON.parse(localStorage.getItem('kirana.npcs.v1') || '[]').find(x => x.id === id) || {}).equip }; }, nid);
  ok('D: custom item and save keep the list in the library', D5.n === 5 && D5.last.name === 'มีดสั้นขึ้นสนิม' && D5.last.slot === 'weapon' && (D5.stored || []).length === 5, D5);
  // บนโต๊ะ: วางจากคลัง แผงหมากขึ้นอาวุธและเกราะ แก้บนหมาก แล้วเก็บกลับเข้าคลัง
  await page.goto(url + '#table'); await wait(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องทดสอบ NPC'); await page.click('button:has-text("สร้างห้อง")'); await wait(500);
  const tid = await page.evaluate(async (id) => { const r = Table.room; r.map.cells = '.'.repeat(400); await placeFromLibrary(r, NpcLib.get(id), 1, false); const t = r.tokens[r.tokens.length - 1]; Table.sel = t.id; renderTable(); return t.id; }, nid);
  await wait(300);
  const D6 = await page.evaluate((tid) => { const t = Table.room.tokens.find(x => x.id === tid); const sec = document.querySelector('.npceq-tok'); return { eq: (t.equip || []).length, sec: !!sec, w: sec ? [...sec.querySelectorAll('.npceq-w')].map(x => x.textContent) : [], rows: sec ? sec.querySelectorAll('.npceq-armor tr').length : 0, hits: sec ? [...sec.querySelectorAll('.armhit')].filter(x => !x.hidden).map(x => x.textContent) : [] }; }, tid);
  ok('D: token copies the list and the GM panel shows it', D6.eq === 5 && D6.sec && D6.w.length === 2 && D6.rows >= 2 && D6.hits.some(h => /หัก Slashing\/Blunt 5 · อื่น ๆ 3/.test(h)), D6);
  await page.click('.npceq-tok .npceq-edit'); await wait(200);
  await page.click('.npceqmodal .npceq-add'); await wait(200);
  await page.fill('.npceqpick input[type=search]', 'หมวก'); await wait(150);
  const helm = await page.evaluate(() => { const g = [...document.querySelectorAll('.npceqpick .gift')].find(x => /หมวกเกราะ|Helm/i.test(x.textContent) && /ศีรษะ/.test(x.textContent) && /Armor/.test(x.textContent)); return g ? g.querySelector('b').textContent : null; });
  await page.click(`.npceqpick .gift:has-text("${helm}") button`); await wait(150);
  await page.click('.npceqpick button:has-text("กลับไปที่รายการ")'); await wait(200);
  const D7 = await page.evaluate((tid) => { const t = Table.room.tokens.find(x => x.id === tid); return { n: t.equip.length, head: t.equip.find(e => e.slot === 'head'), rows: document.querySelectorAll('.npceqmodal .npceq-row').length, headRow: [...document.querySelectorAll('.npceqmodal .npceq-armor tr')].some(tr => /ศีรษะ/.test(tr.textContent)) }; }, tid);
  ok('D: GM edits the token list from the table and comes back to it', helm && D7.n === 6 && D7.head && D7.rows === 6 && D7.headRow, { helm, D7 });
  await page.evaluate(() => modal(null));
  await page.evaluate(async (tid) => { const t = Table.room.tokens.find(x => x.id === tid); await saveTokenToLibrary(t); }, tid); await wait(200);
  const D8 = await page.evaluate((id) => (NpcLib.get(id).equip || []).length, nid);
  ok('D: saving the token back updates the library list', D8 === 6, D8);
  const D9 = await page.evaluate(() => { const r = Table.room; const pc = { id: 'pc1', name: 'ผู้เล่น', kind: 'pc', charId: 'nochar', x: 1, y: 1, hp: 5, hpMax: 5, conds: [] }; r.tokens.push(pc); Table.sel = 'pc1'; renderTable(); const pcSec = !!document.querySelector('.npceq-tok'); const as = { id: 'as1', name: 'หีบ', kind: 'asset', icon: '📦', x: 2, y: 2, hp: 0, hpMax: 0, conds: [] }; r.tokens.push(as); Table.sel = 'as1'; renderTable(); return { pcSec, assetSec: !!document.querySelector('.npceq-tok') }; });
  ok('D: players and assets do not get the NPC equipment panel', !D9.pcSec && !D9.assetSec, D9);

  // ================= E) จอมือถือ: ไม่มีอะไรล้นขอบ =================
  const m = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true });
  m.on('pageerror', e => errors.push('MOBILE ' + e.message));
  const over = {};
  for (const hsh of ['#lore', '#lore-hundredyears', '#skills', '#items-armor']){ await m.goto(url + hsh); await m.waitForTimeout(400); over[hsh] = await m.evaluate(() => document.documentElement.scrollWidth - window.innerWidth); }
  ok('E: no horizontal overflow on phones', Object.values(over).every(v => v <= 1), over);

  ok('no page errors', errors.length === 0, errors);
  console.log(`v126: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
