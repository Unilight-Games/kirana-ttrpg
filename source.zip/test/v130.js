// v1.30 (Non สั่ง 17 พ.ย. 2026): "อับเดตสารบัญเผ่าในเว็บให้คล้ายกับในสารบัญเผ่าของ Astral Sea Lore โดยเล่าให้ไหลลื่นยิ่งขึ้น"
//  และ "ผมไม่อยากให้ชื่อเผ่าไปอยู่ในหมวดเดียวกับฝ่ายและองค์กรครับ"
//  A) ข้อมูลบทความเผ่า  B) หน้าสารบัญ #races  C) บทความเผ่า  D) หน้าตำนาน  E) ลิงก์จากคลังทักษะและวงศา
//  F) ตัวช่วยสร้างตัวละคร  G) หลังบ้านแก้ตำนาน  H) จอมือถือ
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  const shot = (n) => path.resolve(__dirname, n);
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail).slice(0, 1500) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  await page.goto(url); await wait(500);

  // ================= A) ข้อมูล =================
  const A = await page.evaluate(() => {
    const races = Object.keys(LORE).filter(id => LORE[id].kind === 'race');
    const badLinks = []; const text = [];
    for (const id of races){ const a = LORE[id]; const blob = JSON.stringify([a.title, a.en, a.sub, a.lead, a.box, a.body]); text.push(blob);
      for (const m of blob.matchAll(/\[\[([a-z0-9]+)/g)) if (!LORE[m[1]]) badLinks.push(id + '→' + m[1]); }
    const all = text.join(' ');
    const kinsOk = races.every(id => ((LORE[id].game || {}).kins || []).every(k => KIN[k]));
    const kinLore = Object.keys(KIN).map(k => [k, KIN_LORE[k], KIN_LORE[k] && LORE[KIN_LORE[k]] ? LORE[KIN_LORE[k]].kind : null]);
    return { n: races.length, order: RACE_ORDER.length, orderOk: RACE_ORDER.every(id => LORE[id] && LORE[id].kind === 'race'), same: RACE_ORDER.slice().sort().join() === races.slice().sort().join(),
      moved: ['swalan','solrin','childofnight','synfray'].map(id => LORE[id].kind), church: [LORE.bloodmoon.kind, LORE.bloodmoon.title, !!LORE.bloodmoon.game],
      badLinks, kinsOk, kinLore, trinity: RACE_GROUPS.map(g => [g.id, g.members.join()]), beast: RACE_META.beastman,
      years: (all.match(/คีรันนะศักราช|ศักราชที่|\b1[0-9]{3}\b(?! เมตร)(?=\s*ปี)/g) || []),
      dashes: (all.match(/[—–]| - | -- /g) || []).length, kind: LORE_KIND.race, kOrder: LORE_KIND_ORDER.includes('race') };
  });
  ok('A: 20 race articles, all in RACE_ORDER and nothing else', A.n === 20 && A.order === 20 && A.orderOk && A.same, A);
  ok('A: Swalan, Solrin, Children of Night and Synfray left the factions', A.moved.every(k => k === 'race'), A.moved);
  ok('A: the church keeps its faction slot under a new name and hands the kin to the race', A.church[0] === 'faction' && A.church[1] === 'ศาสนจักรจันทร์โลหิต' && A.church[2] === false, A.church);
  ok('A: every link inside race articles points to an article that exists', A.badLinks.length === 0, A.badLinks);
  ok('A: every playable kin opens a race article', A.kinsOk && A.kinLore.every(([, id, kind]) => id && kind === 'race'), A.kinLore);
  ok('A: Trinity groups three races, Beastman is marked not yet playable', A.trinity.length === 1 && A.trinity[0][1] === 'lunaryn,solrin,childofnight' && A.beast && A.beast.closed === true, A);
  ok('A: no calendar years and no dash joints in race prose', A.years.length === 0 && A.dashes === 0, A);
  ok('A: race is its own kind in the codex', A.kind && A.kind[0] === 'เผ่าพันธุ์' && A.kOrder, A);

  // ================= B) หน้าสารบัญ =================
  await page.goto(url + '#races'); await wait(400);
  const B = await page.evaluate(() => {
    const cards = [...document.querySelectorAll('#v-races .race-card')];
    const g = document.querySelector('#v-races .race-group#rg-trinity');
    return { active: document.querySelector('#v-races').classList.contains('active'), h1: document.querySelector('#v-races h1').textContent,
      ledes: document.querySelectorAll('#v-races .lore-hero .lede').length,
      ids: cards.map(c => c.id.replace('race-', '')), nums: cards.map(c => c.querySelector('.race-num').textContent),
      tri: g ? [...g.querySelectorAll('.race-card')].map(c => c.id) : null,
      beast: document.querySelector('#race-beastman .race-play') ? document.querySelector('#race-beastman .race-play').textContent : '',
      rimmen: [...document.querySelectorAll('#race-rimmen .race-play button')].map(b => b.textContent),
      dragonPlay: !!document.querySelector('#race-dragon .race-play'),
      toc: [...document.querySelectorAll('#v-races .race-toc a')].map(a => a.getAttribute('href')), tocG: [...document.querySelectorAll('#v-races .race-toc-g > span')].map(s => s.textContent),
      kinChips: document.querySelectorAll('#v-races .race-aside .lore-kind button').length,
      nav: [...document.querySelectorAll('#nav-codex a')].map(a => [a.getAttribute('href'), a.classList.contains('active')]),
      facts: document.querySelector('#race-norlan .race-facts').textContent };
  });
  ok('B: the races page opens with its title and the three intro paragraphs', B.active && B.h1 === 'เผ่าพันธุ์แห่งคีรันนา' && B.ledes === 3, B);
  const ORDER = await page.evaluate(() => RACE_ORDER.join());
  ok('B: cards follow the Astral order and are numbered 01 to 20', B.ids.join() === ORDER && B.nums[0] === '01' && B.nums[19] === '20', B);
  ok('B: Trinity cards sit inside their own group', B.tri && B.tri.join() === 'race-lunaryn,race-solrin,race-childofnight', B.tri);
  ok('B: Beastman says not yet playable, Rimmen shows its kin, the dragon shows neither', /ยังไม่เปิดให้เล่น/.test(B.beast) && B.rimmen.length === 1 && !B.dragonPlay, B);
  ok('B: the contents list has 20 links and the Trinity label', B.toc.length === 20 && B.toc[0] === '#lore-dragon' && B.tocG.join() === 'ไตรมรณา', B);
  ok('B: the playable-kins box lists all 12 kins', B.kinChips === 12, B.kinChips);
  ok('B: the codex menu has the races entry and highlights it', B.nav.some(([h, act]) => h === '#races' && act) && B.nav.map(x => x[0]).join() === '#lore,#races,#skills,#items', B.nav);
  ok('B: card facts come from the info box', /ฟรอเซนเบิร์ก/.test(B.facts) && /อายุขัย/.test(B.facts), B.facts);
  await page.screenshot({ path: shot('281-races-index-v130.png'), fullPage: false });
  await page.click('#race-rimmen .race-play button'); await wait(250);
  const B2 = await page.evaluate(() => ({ modal: !document.querySelector('#modal').classList.contains('hidden'), btn: [...document.querySelectorAll('#modal button')].map(b => b.textContent) }));
  ok('B: the kin chip opens the kin window with a read-the-lore button', B2.modal && B2.btn.includes('อ่านตำนาน'), B2);
  await page.click('#modal button:has-text("อ่านตำนาน")'); await wait(350);
  ok('B: the read-the-lore button goes to the race article', await page.evaluate(() => location.hash) === '#lore-rimmen');

  // ================= C) บทความเผ่า =================
  await page.goto(url + '#lore-solrin'); await wait(350);
  const C = await page.evaluate(() => ({ crumbs: [...document.querySelectorAll('#v-lore .lore-crumbs a')].map(a => [a.getAttribute('href'), a.textContent]),
    kicker: document.querySelector('#v-lore .lore-art .kicker').textContent, h1: document.querySelector('#v-lore .lore-title').textContent,
    nav: [...document.querySelectorAll('#v-lore .lore-navbtn')].map(a => [a.getAttribute('href'), a.textContent]),
    mini: document.querySelectorAll('#v-lore .race-mini li').length, cur: document.querySelector('#v-lore .race-mini li.cur') ? document.querySelector('#v-lore .race-mini li.cur').textContent : '',
    timeline: !!document.querySelector('#v-lore .lore-mini:not(.race-mini)'),
    game: [...document.querySelectorAll('#v-lore .lore-game button')].map(b => b.textContent),
    toc: document.querySelectorAll('#v-lore .lore-intoc li').length, ul: document.querySelectorAll('#v-lore .lore-art .lore-ul li').length,
    navActive: [...document.querySelectorAll('#nav a.active')].map(a => a.getAttribute('href')) }));
  ok('C: the race article sits under the races page and its group', C.crumbs[0][0] === '#races' && C.crumbs[1] && C.crumbs[1][1] === 'ไตรมรณา' && C.kicker === 'เผ่าพันธุ์ · ไตรมรณา' && C.h1 === 'โซลริน', C);
  ok('C: previous and next walk the race order', C.nav[0][0] === '#lore-lunaryn' && C.nav[1][0] === '#lore-childofnight' && /เผ่าก่อนหน้า/.test(C.nav[0][1]), C.nav);
  ok('C: the side shows the race list in place of the timeline', C.mini === 20 && C.cur === 'โซลริน' && !C.timeline, C);
  ok('C: the article keeps its kin, its headings and the four forms of Dam an-Nar', C.game.length === 1 && C.toc >= 3 && C.ul === 4, C);
  ok('C: the races menu stays lit while reading a race', C.navActive.includes('#races'), C.navActive);
  await page.screenshot({ path: shot('282-race-article-v130.png'), fullPage: false });
  await page.goto(url + '#lore-dragon'); await wait(250);
  const C2 = await page.evaluate(() => [...document.querySelectorAll('#v-lore .lore-navbtn')].map(a => a.getAttribute('href')));
  await page.goto(url + '#lore-archon'); await wait(250);
  const C3 = await page.evaluate(() => [...document.querySelectorAll('#v-lore .lore-navbtn')].map(a => a.getAttribute('href')));
  ok('C: the first and last race lead back to the races page', C2[0] === '#races' && C2[1] === '#lore-floran' && C3[0] === '#lore-aetherian' && C3[1] === '#races', [C2, C3]);
  await page.goto(url + '#lore-bloodmoon'); await wait(250);
  const C4 = await page.evaluate(() => ({ crumbs: document.querySelector('#v-lore .lore-crumbs a').getAttribute('href'), kicker: document.querySelector('#v-lore .lore-art .kicker').textContent, h1: document.querySelector('#v-lore .lore-title').textContent,
    timeline: !!document.querySelector('#v-lore .lore-mini'), links: [...document.querySelectorAll('#v-lore .lore-infobox a')].map(a => a.getAttribute('href')) }));
  ok('C: the church stays a faction article and links to its people', C4.crumbs === '#lore' && C4.kicker === 'ฝ่ายและองค์กร' && C4.h1 === 'ศาสนจักรจันทร์โลหิต' && C4.timeline && C4.links.includes('#lore-lunaryn'), C4);

  // ================= D) หน้าตำนาน =================
  await page.goto(url + '#lore'); await wait(350);
  const D = await page.evaluate(() => { const cards = [...document.querySelectorAll('#v-lore .lore-kind')];
    const pick = (t) => cards.find(c => c.querySelector('h3').textContent.includes(t));
    const race = pick('เผ่าพันธุ์'); const fac = pick('ฝ่ายและองค์กร');
    return { first: cards[0].querySelector('h3').textContent, raceChips: race ? race.querySelectorAll('.lchip').length : 0, raceLink: race && race.querySelector('a.lore-kindlink') ? race.querySelector('a.lore-kindlink').getAttribute('href') : null,
      facIds: fac ? [...fac.querySelectorAll('.lchip')].map(a => a.getAttribute('href')) : [] }; });
  ok('D: the lore index has a races box apart from factions', /เผ่าพันธุ์/.test(D.first) && D.raceChips === 20 && D.raceLink === '#races', D);
  ok('D: no race name is left in the factions box', !D.facIds.some(x => /#lore-(swalan|solrin|childofnight|synfray|lunaryn|dwarvan|alven)$/.test(x)) && D.facIds.includes('#lore-bloodmoon'), D.facIds);
  await page.fill('#v-lore .lore-q', 'ไวโมอานา'); await wait(250);
  const D2 = await page.evaluate(() => [...document.querySelectorAll('#v-lore .lore-hit')].map(a => a.getAttribute('href')));
  ok('D: search finds race articles', D2[0] === '#lore-valain', D2);

  // ================= E) ลิงก์จากคลังทักษะและวงศา =================
  const E = await page.evaluate(() => ({ lun: skSubInfo('Lunaryn').lore, flo: skSubInfo('Floran').lore, dw: skSubInfo('Handerlaw Dwarves').lore, fl: skSubInfo('Faceless').lore,
    faceSkills: DATA.skills.filter(s => s.subcategory === 'Faceless').length, faceGame: (LORE.faceless.game || {}).skills || null }));
  ok('E: kin skill groups link to their race articles', E.lun === 'lunaryn' && E.flo === 'floran' && E.dw === 'dwarvan' && E.fl === 'faceless', E);
  ok('E: the Faceless article points at the Faceless skills that exist in the data', E.faceSkills === 0 && E.faceGame && E.faceGame[0] === 'Faceless (ไม่มีในวงศา V.2)' && (await page.evaluate(() => DATA.skills.filter(s => s.subcategory === 'Faceless (ไม่มีในวงศา V.2)').length)) === 4, E);
  await page.goto(url + '#skills-kins'); await wait(400);
  const E2 = await page.evaluate(() => [...document.querySelectorAll('#v-skills a.lchip')].map(a => a.getAttribute('href')));
  ok('E: the skills library shows race links', E2.includes('#lore-lunaryn') && E2.includes('#lore-solrin') && !E2.includes('#lore-bloodmoon'), E2);

  // ================= F) ตัวช่วยสร้างตัวละคร =================
  const F = await page.evaluate(() => { const k = KIN['night-alves']; kinDetailModal(k, { kin: null });
    const a = document.querySelector('#modal a.kin-lorelink'); const out = a ? { href: a.getAttribute('href'), target: a.getAttribute('target'), text: a.textContent, id: k.id } : null; modal(null); return out; });
  ok('F: the kin detail window links to the race article in a new tab', F && F.href === '#lore-nightalven' && F.target === '_blank' && /ไนท์เอลฟ์/.test(F.text), F);

  // ================= G) หลังบ้าน =================
  const G = await page.evaluate(() => { const s = loreSanitizeArticle(JSON.parse(JSON.stringify(LORE.valain)), 'valain'); const n = loreSanitizeArticle({ kind:'race', title:'ทดสอบ', lead:'x', body:[['p','y']] }, 'testrace');
    return { kind: s && s.kind, body: s && s.body.length === LORE.valain.body.length, ul: s && s.body.some(b => b[0] === 'ul'), base: !!LORE_BASE.articles.valain, newKind: n && n.kind, kinds: LORE_NEW_KINDS.join() }; });
  ok('G: race articles pass the editor filter whole, and new race articles are allowed', G.kind === 'race' && G.body && G.ul && G.base && G.newKind === 'race' && G.kinds.includes('race'), G);
  await page.goto(url + '#loreedit-valain'); await wait(400);
  const G2 = await page.evaluate(() => ({ form: !!document.querySelector('#v-lore .le-form'), kind: document.querySelector('#v-lore .le-form select') ? document.querySelector('#v-lore .le-form select').value : null }));
  ok('G: the editor opens a race article', G2.form && G2.kind === 'race', G2);

  // ================= H) จอมือถือ =================
  const m = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true });
  const mp = await m.newPage(); mp.on('pageerror', e => errors.push('MOBILE ' + e.message));
  await mp.goto(url + '#races'); await mp.waitForTimeout(450);
  const H = await mp.evaluate(() => ({ sw: document.scrollingElement.scrollWidth, iw: innerWidth, cards: document.querySelectorAll('#v-races .race-card').length }));
  ok('H: the races page fits a phone screen', H.cards === 20 && H.sw <= H.iw + 1, H);
  await mp.screenshot({ path: shot('283-races-mobile-v130.png') });
  await mp.goto(url + '#lore-valain'); await mp.waitForTimeout(400);
  const H2 = await mp.evaluate(() => ({ sw: document.scrollingElement.scrollWidth, iw: innerWidth }));
  ok('H: a long race article fits a phone screen', H2.sw <= H2.iw + 1, H2);
  await m.close();

  ok('no page errors', errors.length === 0, errors);
  console.log(`v130: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
