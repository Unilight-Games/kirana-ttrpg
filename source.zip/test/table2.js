const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1400, height: 1000 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(300);
  await page.evaluate(() => { const K = window.__kirana; const c = { id: 'tb1', name: 'ผู้กล้า', kin: 'solrin', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: {}, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {}, skills: [], talentPicks: {}, details: {}, starterSet: 'The Vanguard', done: true, createdAt: Date.now(), updatedAt: Date.now(), step: 8 }; K.Store.upsert(c); });
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องทดสอบ v1.3'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(300);
  await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(200);
  console.log('my sheet btn:', (await page.$$('#v-table button:has-text("📜 ชีท")')).length);
  // typing preserved across re-render
  await page.fill('input[placeholder^="พิมพ์ข้อความ"]', 'กำลังพิมพ์อยู่'); await page.evaluate(()=>renderTable()); await page.waitForTimeout(100);
  console.log('typing kept:', await page.$eval('input[placeholder^="พิมพ์ข้อความ"]', e => e.value), 'focused:', await page.evaluate(()=>document.activeElement.placeholder.startsWith('พิมพ์')));
  // start combat (GM) then render as player
  await page.click('button:has-text("เริ่มการต่อสู้")'); await page.waitForTimeout(300);
  const playerOk = await page.evaluate(()=>{ const me=Store.me; const g=Table.isGM; Store.me='other'; Table.isGM=()=>false; let ok=true; try { renderTableInner(); } catch(e){ ok='THROW '+e.message; } Store.me=me; Table.isGM=g; renderTable(); return ok; });
  console.log('player render during combat:', playerOk);
  // condition
  await page.click('.toklist .tok.npc'); await page.waitForTimeout(200);
  await page.click('.twin-tok button:has-text("+ สถานะ")'); await page.waitForTimeout(200);
  await page.selectOption('#modal select', 'Burning'); await page.fill('#modal input[type=number]', '2'); await page.click('#modal button:has-text("แปะ")'); await page.waitForTimeout(300);
  console.log('cond chips:', await page.$$eval('.twin-tok .cond', es=>es.map(e=>e.textContent)), 'grid class:', await page.$eval('.gtok.npc', e=>e.className), 'badge', await page.$eval('.gtok.npc .cbadges', e=>e.textContent));
  await page.screenshot({ path: 'test/73-conds.png' });
  await page.click('button:has-text("เทิร์นถัดไป")'); await page.waitForTimeout(200); await page.click('button:has-text("เทิร์นถัดไป")'); await page.waitForTimeout(200);
  console.log('conds after 2 rounds:', await page.evaluate(()=>JSON.stringify(Table.room.tokens.find(t=>t.kind==='npc').conds)));
  // give item (local mode applies directly)
  await page.click('.toklist .tok.pc'); await page.waitForTimeout(200);
  await page.click('.twin-tok button:has-text("ไอเทม")'); await page.waitForTimeout(200);
  await page.fill('#modal input[placeholder^="ค้นหา"]', 'เชือก'); await page.waitForTimeout(100);
  console.log('gift hits:', (await page.$$('#modal .gift')).length);
  const before = await page.evaluate(()=>(Store.get('tb1').inventory||[]).length);
  await page.click('#modal .gift button'); await page.waitForTimeout(300);
  console.log('inventory', before, '→', await page.evaluate(()=>Store.get('tb1').inventory.length), 'last:', await page.evaluate(()=>Store.get('tb1').inventory.slice(-1)[0].name));
  // sheet from room → back bar
  await page.click('#v-table button:has-text("📜 ชีท")'); await page.waitForTimeout(400);
  console.log('roombar:', !!(await page.$('.roombar')), 'wboard:', (await page.$$('.box[data-k=combat] .wslot')).length);
  await page.click('.roombar button'); await page.waitForTimeout(300); console.log('back to room:', await page.evaluate(()=>location.hash.startsWith('#room-')), 'room ok', await page.evaluate(()=>!!Table.room));
  // remove token → unshare
  await page.evaluate(()=>{ Table.sel = Table.room.tokens.find(t=>t.kind==='pc').id; renderTable(); }); await page.waitForTimeout(200);
  page.once('dialog', d => d.accept());
  await page.click('.twin-tok button[title^="เอาออกจากบอร์ด"]'); await page.waitForTimeout(300);
  console.log('roomIds after remove:', await page.evaluate(()=>JSON.stringify(Store.get('tb1').roomIds)));
  console.log('errors', errors); await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
