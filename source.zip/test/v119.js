// v1.19 (12 พ.ย. 2026): ดาวและคอมเมนต์ของแผนที่ NPC และ Asset ที่เผยแพร่
// 1) ชั้นข้อมูล: สมุดรีวิวหนึ่งเล่มต่อบัญชีในคอลเลกชัน maps (type 'reviews') อ่านด้วยคำค้นเดียว กรองเอกสารผิดรูป นับหนึ่งบัญชีหนึ่งสมุด ไม่นับรีวิวของเจ้าของผลงาน
// 2) สิทธิ์: บัญชี Google ที่ไม่ใช่เจ้าของผลงานเท่านั้น · บัญชีนิรนามอ่านได้อย่างเดียว · ผู้พัฒนาลบรีวิวของคนอื่นได้
// 3) หน้าจอ: ป้ายสรุปบนการ์ด หน้าต่างดาวและคอมเมนต์ ตัวเลือกการเรียง ปุ่มรีวิวของฉัน ทั้งหน้าแผนที่และหน้า NPC / Asset
// 4) การเรียง "ดาวสูงสุด" ใช้คะแนนถ่วง (ดาว 3 จำนวน 3 เสียงสมมติ)
// ฐานข้อมูลจำลองด้านล่างเลียน Rules ของ maps: อ่านได้เมื่อ published หรือเป็นเจ้าของ · คำค้นต้องมีเงื่อนไขที่รับประกันสิทธิ์ · เปิดเอกสารที่ไม่มีอยู่ไม่ได้ · เขียนได้เฉพาะเอกสารของตัวเอง · ผู้พัฒนาทำได้ทุกอย่าง
const { chromium } = require('playwright');
const path = require('path');
const MOCK = `
window.installMockDb = function(){
  const mem = { maps: {}, mapimages: {} }; const subs = []; const log = { queries: [], writes: [], denied: [] };
  const dev = () => !!Store.isDevUid;
  const guarded = (col) => col === 'maps' || col === 'mapimages';
  const canRead = (col, d) => dev() || (col === 'maps' && d.published === true) || d.ownerId === Store.me;
  const deny = (what) => { log.denied.push(what); const e = new Error('Missing or insufficient permissions.'); e.code = 'permission-denied'; return e; };
  const match = (d, filters) => filters.every(([f, v]) => d[f] === v);
  const queryAllowed = (col, filters) => !guarded(col) || dev() || filters.some(([f, v]) => (col === 'maps' && f === 'published' && v === true) || (f === 'ownerId' && v === Store.me));
  const snap = (col, filters) => ({ docs: Object.values(mem[col] || {}).filter(d => match(d, filters)).map(d => ({ data: () => JSON.parse(JSON.stringify(d)) })) });
  const fire = (col) => { for (const s of subs) if (s.col === col && queryAllowed(col, s.filters)) s.cb(snap(col, s.filters)); };
  const state = { failQueries: false };
  const mkQ = (col, filters) => ({ where(f, op, v){ return mkQ(col, [...filters, [f, v]]); }, limit(){ return this; }, orderBy(){ return this; },
    async get(){ log.queries.push(col + ':' + filters.map(x => x.join('=')).join('&')); if (state.failQueries) throw new Error('unavailable'); if (!queryAllowed(col, filters)) throw deny('query ' + col); return snap(col, filters); },
    onSnapshot(cb){ const s = { col, filters, cb }; subs.push(s); setTimeout(() => fire(col), 0); return () => {}; } });
  Store.db = { collection: (col) => { mem[col] = mem[col] || {}; return mkQ(col, []); },
    doc: (p) => { const [col, id] = p.split('/'); mem[col] = mem[col] || {}; return {
      async set(d){ const cur = mem[col][id]; const nd = JSON.parse(JSON.stringify(d));
        if (guarded(col) && !dev() && (cur ? cur.ownerId !== Store.me : nd.ownerId !== Store.me)) throw deny('set ' + p);
        mem[col][id] = nd; log.writes.push('set ' + p); fire(col); },
      async get(){ const d = mem[col][id]; if (guarded(col) && !dev() && (!d || !canRead(col, d))) throw deny('get ' + p); return { exists: !!d, data: () => d && JSON.parse(JSON.stringify(d)) }; },
      async delete(){ const cur = mem[col][id]; if (guarded(col) && !dev() && (!cur || cur.ownerId !== Store.me)) throw deny('delete ' + p); delete mem[col][id]; log.writes.push('delete ' + p); fire(col); } }; } };
  Store.backend = 'firebase'; Store.online = true; Store.onlineUsers = [];
  return { mem, log, subs, state };
};
window.asUser = function(uid, name, o){ o = o || {}; Store.me = uid; Store.displayName = name; Store.isDevUid = !!o.dev; Store.authUser = { uid, isAnonymous: !!o.anon };
  MapLib.unsub = []; MapLib.loaded = false; MapLib.mine = []; MapLib.pub = []; MapLib.sort = 'new'; MapLib.q = ''; NpcLib.unsub = []; NpcLib.loaded = false; NpcLib.mine = []; NpcLib.pub = []; NpcLib.images = {}; NpcLib.sort = 'new'; NpcLib.q = ''; NpcLib.type = 'all';
  ReviewLib.books = []; ReviewLib.byTarget = new Map(); ReviewLib.loaded = false; ReviewLib.failed = false; ReviewLib.at = 0; ReviewLib.p = null;
  if (window.__mock){ __mock.log.queries.length = 0; __mock.log.writes.length = 0; __mock.log.denied.length = 0; __mock.subs.length = 0; }
  try { updateOnline(); } catch(e){} };
window.seedWorld = function(){
  const mem = __mock.mem; const g = generateMap('forest', 's1'), g2 = generateMap('harbor', 's2'), g3 = generateMap('cave', 's3');
  const T = Date.UTC(2026, 10, 12, 5, 0, 0);
  mem.maps.m1 = { id: 'm1', ownerId: 'u1', ownerName: 'GM ทดสอบ', name: 'ป่าหมอกยามเช้า', desc: 'ทางเดินแคบกลางป่า มีลำธารตัดผ่าน', cells: g.cells, kind: g.kind, npcs: [], published: true, updatedAt: T + 1000 };
  mem.maps.m2 = { id: 'm2', ownerId: 'u2', ownerName: 'ลุงหมี', name: 'ท่าเรือเก่าลักซอนเนีย', desc: 'ท่าเรือร้างริมอ่าว เหมาะกับฉากซุ่มโจมตีตอนกลางคืน', cells: g2.cells, kind: g2.kind, npcs: [{ id: 'x', name: 'โจรท่าเรือ', hp: 12, x: 3, y: 3 }], published: true, updatedAt: T + 2000 };
  mem.maps.m3 = { id: 'm3', ownerId: 'u3', ownerName: 'ฟ้าใส', name: 'ถ้ำแมงมุม', desc: 'ถ้ำมืดสนิท', cells: g3.cells, kind: g3.kind, npcs: [], published: true, updatedAt: T + 3000 };
  mem.maps.mp = { id: 'mp', ownerId: 'u1', ownerName: 'GM ทดสอบ', name: 'ร่างส่วนตัว', cells: g.cells, kind: g.kind, npcs: [], published: false, updatedAt: T };
  mem.maps.n1 = { id: 'n1', type: 'npc', ownerId: 'u2', ownerName: 'ลุงหมี', name: 'อัศวินเสื้อคลุมน้ำเงิน', hp: 22, init: 1, tgh: 4, desc: 'เกราะขัดเงา ถือหอกยาว', published: true, updatedAt: T + 4000 };
  mem.maps.a1 = { id: 'a1', type: 'asset', ownerId: 'u2', ownerName: 'ลุงหมี', name: 'ประตูเหล็ก', icon: '🚪', hp: 30, desc: 'ประตูบานหนา ต้องงัดหรือหากุญแจ', published: true, updatedAt: T + 5000 };
  mem.maps['rvbook-u3'] = { id: 'rvbook-u3', type: 'reviews', published: true, ownerId: 'u3', ownerName: 'ฟ้าใส', createdAt: T, updatedAt: T + 100, items: {
    m2: { t: 'map', s: 5, x: 'ใช้เปิดแคมเปญเมื่อคืน ผู้เล่นชอบมุมซุ่มหลังลังไม้มาก ทางหนีมีสองทางพอดี', n: 'ท่าเรือเก่าลักซอนเนีย', o: 'u2', at: T + 50 },
    n1: { t: 'npc', s: 4, x: '', n: 'อัศวินเสื้อคลุมน้ำเงิน', o: 'u2', at: T + 60 },
    a1: { t: 'asset', s: 0, x: 'ใช้เป็นประตูกลได้ดี', n: 'ประตูเหล็ก', o: 'u2', at: T + 70 },
    m3: { t: 'map', s: 5, x: 'ของฉันเอง', n: 'ถ้ำแมงมุม', o: 'u3', at: T + 80 },
    gone1: { t: 'map', s: 3, x: 'ผลงานที่โดนลบไปแล้ว', n: 'แผนที่ที่หายไป', o: 'u9', at: T + 85 } } };
  mem.maps['rvbook-u4'] = { id: 'rvbook-u4', type: 'reviews', published: true, ownerId: 'u4', ownerName: 'ก้อง', createdAt: T, updatedAt: T + 200, items: {
    m2: { t: 'map', s: 4, x: '', n: 'ท่าเรือเก่าลักซอนเนีย', o: 'u2', at: T + 90 },
    m1: { t: 'map', s: 2, x: 'ทางแคบไปหน่อยสำหรับปาร์ตี้ห้าคน', n: 'ป่าหมอกยามเช้า', o: 'u1', at: T + 95, ed: T + 150 } } };
  // เอกสารปลอมและผิดรูป: ต้องไม่นับ และต้องไม่ทำให้หน้าพัง
  mem.maps['rvbook-zz'] = { id: 'rvbook-zz', type: 'reviews', published: true, ownerId: 'u9', ownerName: 'รหัสไม่ตรงบัญชี', updatedAt: T + 999, items: { m2: { s: 1, x: 'ปลอม' } } };
  mem.maps['rvbook-u8'] = { id: 'rvbook-u8', type: 'reviews', published: true, ownerId: 'u8', ownerName: { a: 1 }, updatedAt: 'x', items: { m2: { s: 99, x: { evil: true } }, '<b>': { s: 5 }, n1: 'str', a1: null, m1: { s: 'abc', x: '   ' } } };
  mem.maps['rvbook-u4~old'] = { id: 'rvbook-u4~old', type: 'reviews', published: true, ownerId: 'u4', ownerName: 'ก้อง (เล่มเก่า)', updatedAt: T + 10, items: { m2: { s: 1, x: 'เล่มเก่า ไม่ควรนับ' }, m3: { s: 1 } } };
  mem.maps['rvbook-hid'] = { id: 'rvbook-hid', type: 'reviews', published: false, ownerId: 'hid', ownerName: 'ไม่เผยแพร่', updatedAt: T, items: { m2: { s: 1 } } };
  return T;
};
`;
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const dialogs = []; page.on('dialog', d => { dialogs.push(d.type() + ':' + d.message()); d.accept(); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const shot = async (name, full) => { await page.evaluate(() => { if (typeof DiceShow !== 'undefined') DiceShow.clear(); }); await page.waitForTimeout(150); await page.screenshot({ path: path.resolve(__dirname, name), fullPage: !!full }); };
  const boot = async (hash) => { await page.goto(url + (hash || '#home')); await page.reload(); await page.waitForTimeout(600); await page.evaluate(MOCK); };
  const wait = (ms) => page.waitForTimeout(ms);

  // ================= A) ออฟไลน์: ไม่มีส่วนของรีวิวบนหน้า และฟังก์ชันล้วนทำงานถูก =================
  await page.goto(url + '#maps'); await wait(500);
  const off = await page.evaluate(async () => {
    const m = MapLib.newMap('ออฟไลน์เผยแพร่'); m.published = true; await MapLib.save(m); MapLib.tab = 'pub'; await MapLib.loadPublished(); renderMaps();
    const out = { cards: document.querySelectorAll('#v-maps .mapcard').length, chips: document.querySelectorAll('.rvchip').length, sort: document.querySelectorAll('.rvsort').length, mineBtn: document.querySelectorAll('.rvminebtn').length, blocker: ReviewLib.blocker(m).code, chip: rvChip(m), sortSel: rvSortSelect(MapLib, () => {}), saved: await ReviewLib.save(m, 5, 'x') };
    await ReviewLib.load(); out.loaded = ReviewLib.loaded && ReviewLib.books.length === 0; await MapLib.remove(m.id); MapLib.tab = 'mine';
    return out; });
  ok('offline: no review UI at all', off.cards === 1 && off.chips === 0 && off.sort === 0 && off.mineBtn === 0 && off.chip === null && off.sortSel === null, off);
  ok('offline: saving is refused', off.blocker === 'offline' && off.saved === false && off.loaded, off);
  const pure = await page.evaluate(() => {
    const good = { id: 'rvbook-u9', type: 'reviews', published: true, ownerId: 'u9', ownerName: '  คนรีวิว  ', createdAt: 2, updatedAt: 5, items: { m1: { t: 'map', s: 4, x: ' ดี ', n: 'ก', o: 'u1', at: 3 }, n1: { t: 'npc', s: 0, x: 'มีแต่ข้อความ', at: 4, ed: 6 } } };
    const out = {}; const cb = rvCleanBook(good);
    out.good = JSON.stringify(cb);
    out.reject = [null, 'x', {}, { ...good, type: 'npc' }, { ...good, published: false }, { ...good, published: 'true' }, { ...good, id: 'rvbook-zz' }, { ...good, ownerId: '' }, { ...good, ownerId: 5 }, { ...good, id: 'rvbook-u9~toolong0123456' }, { ...good, id: 'rvbook-u9~AB' }, { ...good, id: 9 }].map(x => rvCleanBook(x) === null).join();
    out.ids = [rvIsBookId('rvbook-u9', 'u9'), rvIsBookId('rvbook-u9~ab12cd34', 'u9'), rvIsBookId('rvbook-u9x', 'u9'), rvIsBookId('rvbook-u9~', 'u9'), rvIsBookId('rvbook-u9~a b', 'u9'), rvIsBookId('m1', 'u9'), rvIsBookId('rvbook-', '')].join();
    const many = {}; for (let i = 0; i < 350; i++) many['t' + i] = { s: 1 + (i % 5) };
    const bad = rvCleanBook({ id: 'rvbook-u8', type: 'reviews', published: true, ownerId: 'u8', ownerName: { a: 1 }, updatedAt: 'x', createdAt: -5, items: JSON.parse('{"ok1":{"s":99,"x":5},"ok2":{"s":-3,"x":"' + 'ก'.repeat(900) + '"},"ok3":{"s":"abc","x":"   "},"ok4":{"s":2.6,"x":null,"t":"weird","at":1e400,"ed":-1},"<script>":{"s":5},"":{"s":5},"a/b":{"s":5},"__proto__":{"s":1,"x":"proto"},"__x":{"s":2},"ok5":null,"ok6":"str","' + 'k'.repeat(65) + '":{"s":5}}') });
    out.bad = [Object.keys(bad.items).join(), bad.ownerName === '', bad.updatedAt, bad.createdAt, JSON.stringify(bad.items.ok1), bad.items.ok2.s, bad.items.ok2.x.length, JSON.stringify(bad.items.ok4), Object.getPrototypeOf(bad.items) === null, bad.items.t === undefined && bad.items.s === undefined].join('|');
    out.cap = Object.keys(rvCleanBook({ id: 'rvbook-u7', type: 'reviews', published: true, ownerId: 'u7', items: many }).items).length;
    out.arr = Object.keys(rvCleanBook({ id: 'rvbook-u7', type: 'reviews', published: true, ownerId: 'u7', items: [{ s: 5 }] }).items).length;
    out.types = [rvType({}), rvType({ type: 'map' }), rvType({ type: 'npc' }), rvType({ type: 'asset' }), rvType(null), rvTypeLabel('map'), rvTypeLabel('npc'), rvTypeLabel('asset')].join();
    out.time = [rvTime(5), rvTime('7'), rvTime(-1), rvTime(NaN), rvTime(Infinity), rvTime(9e15), rvTime(null)].join();
    out.consts = [RV_TEXT_MAX, RV_BOOK_MAX, RV_PRIOR.n, RV_PRIOR.mean, RV_SORTS.map(x => x[0]).join('/')].join();
    return out; });
  ok('a well-formed book is kept and trimmed', pure.good === '{"id":"rvbook-u9","ownerId":"u9","ownerName":"คนรีวิว","items":{"m1":{"t":"map","s":4,"x":"ดี","n":"ก","o":"u1","at":3},"n1":{"t":"npc","s":0,"x":"มีแต่ข้อความ","n":"","o":"","at":4,"ed":6}},"createdAt":2,"updatedAt":5}', pure.good);
  ok('books with the wrong type, visibility, owner or id are rejected', pure.reject === Array(12).fill('true').join(), pure.reject);
  ok('book id must be rvbook-<owner> or its fallback form', pure.ids === 'true,true,false,false,false,false,false', pure.ids);
  ok('malformed entries are coerced or dropped, never trusted', pure.bad === 'ok1,ok2,ok4|true|0|0|{"t":"map","s":5,"x":"","n":"","o":"","at":0}|0|400|{"t":"map","s":3,"x":"","n":"","o":"","at":0}|true|true', pure.bad);
  ok('a book is capped at 300 entries and an array is not a book', pure.cap === 300 && pure.arr === 0, [pure.cap, pure.arr]);
  ok('helpers and constants', pure.types === 'map,map,npc,asset,map,แผนที่,NPC,Asset' && pure.time === '5,7,0,0,0,0,0' && pure.consts === '400,300,3,3,new/top/most', [pure.types, pure.time, pure.consts]);

  // ================= B) ออนไลน์ (ฐานข้อมูลจำลอง): อ่านและรวมคะแนน =================
  await boot('#home');
  const rd = await page.evaluate(async () => {
    window.__mock = installMockDb(); window.__T = seedWorld(); asUser('u1', 'GM ทดสอบ');
    const wait = (ms) => new Promise(r => setTimeout(r, ms));
    MapLib.subscribe(() => {}); NpcLib.subscribe(() => {}); await wait(40);
    await MapLib.loadPublished(); await NpcLib.loadPublished(); await ReviewLib.load();
    const M = (id) => MapLib.pub.find(x => x.id === id), N = (id) => NpcLib.pub.find(x => x.id === id);
    const out = { queries: __mock.log.queries.slice(), denied: __mock.log.denied.slice(), books: ReviewLib.books.map(b => b.id).sort().join(), mapPub: MapLib.pub.map(m => m.id).sort().join(), libPub: NpcLib.pub.map(m => m.id).sort().join(), mapMine: MapLib.mine.map(m => m.id).sort().join(), libMine: NpcLib.mine.length };
    const S = (t) => { const s = ReviewLib.summary(t); return [s.total, s.n, s.sum, s.avg.toFixed(2), s.comments, s.dist.join('')].join('/'); };
    out.m2 = S(M('m2')); out.m1 = S(M('m1')); out.m3 = S(M('m3')); out.n1 = S(N('n1')); out.a1 = S(N('a1'));
    out.listM2 = ReviewLib.list(M('m2')).map(r => r.uid + ':' + r.s + ':' + r.name + ':' + r.bookId).join('|');
    out.u8 = JSON.stringify(ReviewLib.books.find(b => b.id === 'rvbook-u8'));
    out.blockers = [ReviewLib.blocker(M('m2')), ReviewLib.blocker(M('m1')), ReviewLib.blocker(MapLib.mine.find(x => x.id === 'mp')), ReviewLib.blocker({ id: 'a b', published: true, ownerId: 'u2' }), ReviewLib.blocker({ id: '__proto__', published: true, ownerId: 'u2' }), ReviewLib.blocker(null)].map(b => b ? b.code : 'ok').join();
    out.mine0 = [ReviewLib.myBook(), ReviewLib.mine(M('m2')), ReviewLib.myCount()].join();
    return out; });
  ok('one query loads every book', rd.queries.filter(q => q === 'maps:published=true&type=reviews').length === 1 && rd.denied.length === 0, rd.queries);
  ok('forged and malformed books are filtered out', rd.books === 'rvbook-u3,rvbook-u4,rvbook-u4~old,rvbook-u8', rd.books);
  ok('libraries ignore review books in the shared collection', rd.mapPub === 'm1,m2,m3' && rd.libPub === 'a1,n1' && rd.mapMine === 'm1,mp' && rd.libMine === 0, [rd.mapPub, rd.libPub, rd.mapMine, rd.libMine]);
  ok('summary of a map: two raters, the malformed book counts as a clamped 5', rd.m2 === '3/3/14/4.67/1/000012', rd.m2);
  ok('one account counts once: the newest book wins over the old fallback', /u4:4:ก้อง:rvbook-u4/.test(rd.listM2) && !/เล่มเก่า/.test(rd.listM2) && rd.listM2.split('|').length === 3, rd.listM2);
  ok('the owner never counts on their own work', rd.m3 === '0/0/0/0.00/0/000000', rd.m3);
  ok('comment without stars and stars without comment', rd.a1 === '1/0/0/0.00/1/000000' && rd.n1 === '1/1/4/4.00/0/000010' && rd.m1 === '1/1/2/2.00/1/001000', [rd.a1, rd.n1, rd.m1]);
  ok('blockers: other people\'s work is open, own, private, bad id and nothing are closed', rd.blockers === 'ok,own,private,badid,badid,private' && rd.mine0 === ',,0', [rd.blockers, rd.mine0]);

  // ================= C) หน้าแผนที่: ป้ายบนการ์ด หน้าต่าง ให้ดาว แก้ ลบ =================
  await page.evaluate(() => { MapLib.tab = 'pub'; location.hash = '#maps'; }); await wait(600);
  const card = () => page.evaluate(() => [...document.querySelectorAll('#v-maps .mapcard')].map(c => { const ch = c.querySelector('.rvchip'); return c.querySelector('h3').textContent + '=' + (ch ? ch.textContent.replace(/★+/g, '*') : 'none'); }));
  const c0 = await card();
  ok('cards show the average, the number of raters and the comment count', c0.join('|') === 'ถ้ำแมงมุม=☆ ยังไม่มีดาว|ท่าเรือเก่าลักซอนเนีย=*4.7(3)· 💬 1|ป่าหมอกยามเช้า=*2.0(1)· 💬 1', c0);
  const tabsUi = await page.evaluate(() => ({ sort: [...document.querySelectorAll('#v-maps .rvsort option')].map(o => o.value + ':' + o.textContent).join('|'), mine: document.querySelector('#v-maps .rvminebtn').textContent, fg: document.querySelector('#v-maps .rvchip[data-id="m2"] .rvs-fg').style.width, aria: document.querySelector('#v-maps .rvchip[data-id="m2"] .rvstars').getAttribute('aria-label') }));
  ok('search tab has the sort menu and the my-reviews button', tabsUi.sort === 'new:เรียง: ล่าสุด|top:เรียง: ดาวสูงสุด|most:เรียง: รีวิวมากสุด' && tabsUi.mine === 'รีวิวของฉัน', tabsUi);
  ok('star bar is filled in proportion and labelled', tabsUi.fg === '93.3%' && tabsUi.aria === '4.7 จาก 5 ดาว', tabsUi);
  await shot('190-review-cards-v119.png');
  await page.click('#v-maps .rvchip[data-id="m2"]'); await wait(300);
  const md0 = await page.evaluate(() => { const b = document.querySelector('#modal .rvbox'); return { head: b.querySelector('h3').textContent + '|' + b.querySelector('h3 + div').textContent, avg: b.querySelector('.rvavg b').textContent, cap: b.querySelector('.rvavg div').textContent, bars: [...b.querySelectorAll('.rvbar')].map(r => r.children[0].textContent + r.children[2].textContent + ':' + r.querySelector('i b').style.width).join('|'), form: !!b.querySelector('.rvmine'), kicker: b.querySelector('.rvmine .kicker').textContent, stars: [...b.querySelectorAll('.rvstarbtn')].map(x => x.textContent + (x.getAttribute('aria-pressed') === 'true' ? '!' : '')).join(''), picked: b.querySelector('.rvpicked').textContent, clearVis: b.querySelector('.rvclear').style.visibility, count: b.querySelector('.rvcount').textContent, save: b.querySelector('.rvsave').textContent, del: !!b.querySelector('.rvdel'), list: [...b.querySelectorAll('.rvitem')].map(i => i.dataset.uid + ':' + i.querySelector('.rvname').textContent + ':' + (i.querySelector('.rvtext') ? 'text' : 'notext') + ':' + i.querySelector('.rvdate').textContent).join('|'), mod: b.querySelectorAll('.rvmod').length, maxlength: b.querySelector('.rvtextin').getAttribute('maxlength') }; });
  ok('window header and summary', md0.head === 'ดาวและคอมเมนต์|แผนที่ "ท่าเรือเก่าลักซอนเนีย" โดย ลุงหมี' && md0.avg === '4.7' && md0.cap === '3 คนให้ดาว · 1 คอมเมนต์' && md0.bars === '5★2:67%|4★1:33%|3★0:0%|2★0:0%|1★0:0%', md0);
  ok('empty form for someone who has not reviewed yet', md0.form && md0.kicker === 'ให้ดาวและคอมเมนต์' && md0.stars === '☆☆☆☆☆' && md0.picked === 'ยังไม่ให้ดาว' && md0.clearVis === 'hidden' && md0.count === '0/400' && md0.save === 'บันทึก' && !md0.del && md0.maxlength === '400', md0);
  ok('list is newest first, with names and dates, no moderation button for a normal user', /^u4:ก้อง:notext:12\/11\/2569\|u3:ฟ้าใส:text:12\/11\/2569\|u8:ผู้เล่น:notext:$/.test(md0.list) && md0.mod === 0, md0.list);
  await shot('191-review-window-v119.png');
  // เซฟเปล่าไม่ได้
  await page.click('#modal .rvsave'); await wait(200);
  ok('saving nothing is refused', await page.evaluate(() => !__mock.mem.maps['rvbook-u1'] && /ให้ดาวอย่างน้อยหนึ่งดวง/.test(document.querySelector('#toast').textContent)));
  await page.click('#modal .rvstarbtn[data-s="3"]');
  await page.fill('#modal .rvtextin', 'แผนที่สวย แต่จุดเกิดของผู้เล่นอยู่ใกล้ศัตรูเกินไป\nลองขยับลงมาสองช่อง <img src=x onerror="window.__xss=1">'); await wait(100);
  const md1 = await page.evaluate(() => { const b = document.querySelector('#modal .rvbox'); return { stars: [...b.querySelectorAll('.rvstarbtn')].map(x => x.textContent + (x.getAttribute('aria-pressed') === 'true' ? '!' : '')).join(''), on: b.querySelectorAll('.rvstarbtn.on').length, picked: b.querySelector('.rvpicked').textContent, clearVis: b.querySelector('.rvclear').style.visibility, count: b.querySelector('.rvcount').textContent }; });
  ok('picking stars and typing updates the form in place', md1.stars === '★★★!☆☆' && md1.on === 3 && md1.picked === '3 ดาว' && md1.clearVis === 'visible' && md1.count === '105/400', md1);
  await page.click('#modal .rvclear'); const cleared = await page.evaluate(() => document.querySelector('#modal .rvpicked').textContent + '|' + document.querySelector('#modal .rvtextin').value.length);
  ok('clearing stars keeps the text', cleared === 'ยังไม่ให้ดาว|105', cleared);
  await page.click('#modal .rvstarbtn[data-s="3"]'); await shot('192-review-filled-v119.png');
  await page.click('#modal .rvsave'); await wait(400);
  const sv = await page.evaluate(() => { const d = __mock.mem.maps['rvbook-u1']; const b = document.querySelector('#modal .rvbox'); const e = d && d.items.m2;
    return { doc: d && [d.id, d.type, d.published, d.ownerId, d.ownerName, Object.keys(d.items).join(), d.createdAt > 0, d.updatedAt >= d.createdAt].join('|'), entry: e && [e.t, e.s, e.n, e.o, e.at > 0, 'ed' in e].join('|'), text: e && e.x, writes: __mock.log.writes.join(), denied: __mock.log.denied.join(), lastQ: __mock.log.queries[__mock.log.queries.length - 1],
      avg: b.querySelector('.rvavg b').textContent, cap: b.querySelector('.rvavg div').textContent, kicker: b.querySelector('.rvmine .kicker').textContent, save: b.querySelector('.rvsave').textContent, del: !!b.querySelector('.rvdel'), first: b.querySelector('.rvitem').dataset.uid + ':' + b.querySelector('.rvitem').className + ':' + b.querySelector('.rvitem .tag').textContent, firstText: b.querySelector('.rvitem .rvtext').textContent, imgs: document.querySelectorAll('#modal img').length, xss: window.__xss === undefined, toast: document.querySelector('#toast').textContent, mineBtn: document.querySelector('#v-maps .rvminebtn').textContent, chip: document.querySelector('#v-maps .rvchip[data-id="m2"]').textContent.replace(/★+/g, '*') }; });
  ok('saving writes my own book under rvbook-<uid>', sv.doc === 'rvbook-u1|reviews|true|u1|GM ทดสอบ|m2|true|true' && sv.entry === 'map|3|ท่าเรือเก่าลักซอนเนีย|u2|true|false' && sv.writes === 'set maps/rvbook-u1', [sv.doc, sv.entry, sv.writes]);
  ok('my book is found with an owner query, never by opening a missing document', sv.lastQ === 'maps:ownerId=u1&type=reviews' && sv.denied === '', [sv.lastQ, sv.denied]);
  ok('window, card and button refresh after saving', sv.avg === '4.3' && sv.cap === '4 คนให้ดาว · 2 คอมเมนต์' && sv.kicker === 'ดาวและคอมเมนต์ของคุณ' && sv.save === 'บันทึกการแก้ไข' && sv.del && sv.first === 'u1:rvitem me:ของคุณ' && /บันทึกดาวและคอมเมนต์แล้ว/.test(sv.toast) && sv.mineBtn === 'รีวิวของฉัน (1)' && sv.chip === '*4.3(4)· 💬 2', sv);
  ok('comment text is shown as text only', sv.imgs === 0 && sv.xss && /<img src=x onerror=/.test(sv.firstText) && sv.text === sv.firstText, [sv.imgs, sv.xss]);
  await shot('193-review-saved-v119.png');
  // แก้: ดาวเปลี่ยน เวลาแรกคงเดิม มี ed
  const at0 = await page.evaluate(() => __mock.mem.maps['rvbook-u1'].items.m2.at);
  await wait(15); await page.click('#modal .rvstarbtn[data-s="5"]'); await page.fill('#modal .rvtextin', 'กลับไปเล่นรอบสอง แก้จุดเกิดแล้วดีขึ้นมาก'); await page.click('#modal .rvsave'); await wait(400);
  const ed = await page.evaluate((at0) => { const e = __mock.mem.maps['rvbook-u1'].items.m2; const b = document.querySelector('#modal .rvbox'); return { e: [e.s, e.x, e.at === at0, e.ed > e.at].join('|'), avg: b.querySelector('.rvavg b').textContent, date: b.querySelector('.rvitem .rvdate').textContent, docs: Object.keys(__mock.mem.maps).filter(k => /^rvbook-u1/.test(k)).join() }; }, at0);
  ok('editing keeps the first timestamp, adds an edit mark and never makes a second book', ed.e === '5|กลับไปเล่นรอบสอง แก้จุดเกิดแล้วดีขึ้นมาก|true|true' && ed.avg === '4.8' && /\(แก้ไข\)$/.test(ed.date) && ed.docs === 'rvbook-u1', ed);
  await page.evaluate(() => modal(null));
  // ผลงานของตัวเอง
  await page.click('#v-maps .rvchip[data-id="m1"]'); await wait(300);
  const own = await page.evaluate(() => { const b = document.querySelector('#modal .rvbox'); return { blk: b.querySelector('.rvblk').dataset.code + ':' + b.querySelector('.rvblk').textContent, form: !!b.querySelector('.rvmine'), list: [...b.querySelectorAll('.rvitem')].map(i => i.querySelector('.rvname').textContent + ':' + i.querySelector('.rvtext').textContent + ':' + i.querySelector('.rvdate').textContent).join('|') }; });
  ok('the creator reads feedback but cannot rate their own work', /^own:นี่คือผลงานของคุณ/.test(own.blk) && !own.form && /^ก้อง:ทางแคบไปหน่อยสำหรับปาร์ตี้ห้าคน:.*\(แก้ไข\)$/.test(own.list), own);
  ok('saving on my own work is refused in the data layer too', await page.evaluate(async () => { const before = JSON.stringify(__mock.mem.maps['rvbook-u1']); const r = await ReviewLib.save(MapLib.pub.find(x => x.id === 'm1'), 5, 'ของฉันดีที่สุด'); return r === false && JSON.stringify(__mock.mem.maps['rvbook-u1']) === before; }));
  await shot('194-review-owner-v119.png');
  await page.evaluate(() => modal(null));
  // คลังของฉัน: ชิ้นที่เผยแพร่มีป้าย ชิ้นส่วนตัวไม่มี
  await page.click('#v-maps button:has-text("คลังของฉัน")'); await wait(400);
  const mineTab = await page.evaluate(() => ({ cards: [...document.querySelectorAll('#v-maps .mapcard')].map(c => c.querySelector('h3').textContent + '=' + (c.querySelector('.rvchip') ? 'chip' : 'none')).join('|'), sort: document.querySelectorAll('#v-maps .rvsort').length, mine: document.querySelectorAll('#v-maps .rvminebtn').length }));
  ok('my library: published work shows its rating, private work shows nothing', mineTab.cards === 'ป่าหมอกยามเช้า=chip|ร่างส่วนตัว=none' && mineTab.sort === 0 && mineTab.mine === 1, mineTab);
  // ดูตัวอย่างแผนที่มีป้ายเปิดหน้าต่างรีวิว
  await page.click('#v-maps button:has-text("ค้นหาแผนที่ที่เผยแพร่")'); await wait(500);
  await page.click('#v-maps .mapcard:has(h3:text-is("ท่าเรือเก่าลักซอนเนีย")) button:text-is("ดู")'); await wait(250);
  ok('map preview carries the rating chip', await page.evaluate(() => !!document.querySelector('#modal .rvchip[data-id="m2"]') && !document.querySelector('#modal .rvbox')));
  await page.click('#modal .rvchip'); await wait(250);
  ok('the chip in the preview opens the review window', await page.evaluate(() => document.querySelector('#modal .rvbox').dataset.id === 'm2'));
  // ลบของฉัน: เหลือศูนย์รายการ สมุดหายทั้งเล่ม
  await page.click('#modal .rvdel'); await wait(400);
  const del = await page.evaluate(() => ({ doc: !!__mock.mem.maps['rvbook-u1'], writes: __mock.log.writes.slice(-1)[0], kicker: document.querySelector('#modal .rvmine .kicker').textContent, stars: document.querySelectorAll('#modal .rvstarbtn.on').length, text: document.querySelector('#modal .rvtextin').value, avg: document.querySelector('#modal .rvavg b').textContent, mineBtn: document.querySelector('#v-maps .rvminebtn').textContent, chip: document.querySelector('#v-maps .rvchip[data-id="m2"]').textContent.replace(/★+/g, '*') }));
  ok('deleting my only review removes the whole book and resets the form', !del.doc && del.writes === 'delete maps/rvbook-u1' && del.kicker === 'ให้ดาวและคอมเมนต์' && del.stars === 0 && del.text === '' && del.avg === '4.7' && del.mineBtn === 'รีวิวของฉัน' && del.chip === '*4.7(3)· 💬 1' && dialogs.some(d => /ลบดาวและคอมเมนต์ของคุณออกจากผลงานนี้/.test(d)), del);
  await page.evaluate(() => modal(null));

  // ================= D) สิทธิ์และกรณีขอบ (ชั้นข้อมูล) =================
  const perm = await page.evaluate(async () => {
    const out = {}; const mem = __mock.mem; const wait = (ms) => new Promise(r => setTimeout(r, ms));
    const load = async () => { MapLib.subscribe(() => {}); NpcLib.subscribe(() => {}); await wait(30); await MapLib.loadPublished(); await NpcLib.loadPublished(); await ReviewLib.load(true); };
    const M = (id) => MapLib.pub.find(x => x.id === id) || NpcLib.pub.find(x => x.id === id);
    // 1) บัญชีนิรนาม: อ่านได้ ให้ดาวไม่ได้
    asUser('anon7', 'ผู้เล่น-abcd', { anon: true }); await load();
    out.anon = [ReviewLib.blocker(M('m2')).code, await ReviewLib.save(M('m2'), 5, 'นิรนาม'), ReviewLib.summary(M('m2')).n, __mock.log.writes.length, Object.keys(mem.maps).filter(k => /anon7/.test(k)).length].join('|');
    // 2) รหัสสมุดโดนคนอื่นสร้างทับไว้: ใช้รหัสสำรอง และการแก้ครั้งถัดไปเขียนลงเล่มเดิม
    mem.maps['rvbook-u5'] = { id: 'rvbook-u5', ownerId: 'ux', name: 'จองรหัสไว้แกล้ง', published: false };
    asUser('u5', 'เหยื่อ'); await load();
    const s1 = await ReviewLib.save(M('m2'), 4, 'รหัสตามแบบโดนจอง'); const ids1 = Object.keys(mem.maps).filter(k => /^rvbook-u5~/.test(k));
    const s2 = await ReviewLib.save(M('n1'), 5, ''); const ids2 = Object.keys(mem.maps).filter(k => /^rvbook-u5~/.test(k));
    out.squat = [s1, s2, ids1.length, ids2.length, ids1[0] === ids2[0], /^rvbook-u5~[a-z0-9]{8}$/.test(ids1[0]), mem.maps[ids2[0]].ownerId, Object.keys(mem.maps[ids2[0]].items).join(), mem.maps['rvbook-u5'].ownerId, __mock.log.denied.join(), ReviewLib.summary(M('m2')).n, ReviewLib.myCount()].join('|');
    out.squatId = ids2[0];
    // 3) กันทับการแก้จากอีกเครื่อง: อ่านสมุดสดก่อนเขียนทุกครั้ง
    asUser('u6', 'สองเครื่อง'); await load();
    await ReviewLib.save(M('m2'), 2, 'เครื่องแรก');
    mem.maps['rvbook-u6'].items.n1 = { t: 'npc', s: 5, x: 'เขียนจากอีกเครื่อง', n: 'อัศวินเสื้อคลุมน้ำเงิน', o: 'u2', at: 5 }; mem.maps['rvbook-u6'].updatedAt += 1;
    await ReviewLib.save(M('a1'), 0, 'เครื่องแรกอีกครั้ง');
    out.merge = Object.keys(mem.maps['rvbook-u6'].items).sort().join() + '|' + ReviewLib.myCount();
    // 4) ข้อความยาวเกินโดนตัด ช่องว่างล้วนไม่นับเป็นข้อความ ดาวนอกช่วงโดนบีบ
    await ReviewLib.save(M('m3'), 9, '  ' + 'ย'.repeat(500) + '  ');
    out.limits = [mem.maps['rvbook-u6'].items.m3.s, mem.maps['rvbook-u6'].items.m3.x.length, await ReviewLib.save(M('m1'), 0, '   \n  '), 'm1' in mem.maps['rvbook-u6'].items].join('|');
    // 5) ลบทีละรายการ: สมุดยังอยู่จนกว่าจะหมด · ลบรายการที่ไม่มีอยู่ไม่พัง
    const r1 = await ReviewLib.remove('m3'); const left = Object.keys(mem.maps['rvbook-u6'].items).sort().join(); const r2 = await ReviewLib.remove('nothing');
    out.remove = [r1, left, r2, !!mem.maps['rvbook-u6']].join('|');
    // 6) สมุดเต็ม 300 รายการ: เพิ่มใหม่ไม่ได้ แก้ของเดิมได้
    const full = {}; for (let i = 0; i < 300; i++) full['f' + i] = { t: 'map', s: 3, x: '', n: 'ชิ้น ' + i, o: 'zz', at: 1 + i };
    mem.maps['rvbook-u6'].items = full; mem.maps['rvbook-u6'].updatedAt += 1;
    const f1 = await ReviewLib.save(M('m2'), 5, ''); const toastFull = document.querySelector('#toast').textContent;
    const f2 = await ReviewLib.save({ id: 'f7', name: 'ชิ้น 7', ownerId: 'zz', published: true }, 1, 'แก้ได้');
    out.full = [f1, /สมุดรีวิวของคุณเต็มแล้ว \(300 รายการ\)/.test(toastFull), f2, Object.keys(mem.maps['rvbook-u6'].items).length, mem.maps['rvbook-u6'].items.f7.s].join('|');
    delete mem.maps['rvbook-u6'];
    // 7) โหลดไม่ได้: ไม่พัง บอกสถานะ และข้อมูลเดิมยังอยู่
    asUser('u1', 'GM ทดสอบ'); await load(); const n0 = ReviewLib.books.length; __mock.state.failQueries = true;
    await ReviewLib.load(true); out.fail = [ReviewLib.failed, ReviewLib.loaded, ReviewLib.books.length === n0, await ReviewLib.save(M('m2'), 5, 'ตอนเน็ตหลุด'), !!mem.maps['rvbook-u1']].join('|');
    asUser('u1', 'GM ทดสอบ'); await ReviewLib.load(true); out.failFresh = [ReviewLib.failed, ReviewLib.loaded, ReviewLib.at, rvChip({ id: 'm2', published: true, ownerId: 'u2' }).textContent].join('|');
    __mock.state.failQueries = false; await ReviewLib.load(true); out.recover = [ReviewLib.failed, ReviewLib.books.length > 0].join('|');
    return out; });
  ok('anonymous accounts read but cannot rate', perm.anon === 'anon|false|3|0|0', perm.anon);
  ok('a squatted book id falls back to a private id and keeps using it', /^true\|true\|1\|1\|true\|true\|u5\|m2,n1\|ux\|set maps\/rvbook-u5\|4\|2$/.test(perm.squat), perm.squat);
  ok('edits from another device are merged, not overwritten', perm.merge === 'a1,m2,n1|3', perm.merge);
  ok('limits: stars clamped, text cut at 400, blank input refused', perm.limits === '5|400|false|false', perm.limits);
  ok('removing one entry keeps the book, removing a missing entry is harmless', perm.remove === 'true|a1,m2,n1|true|true', perm.remove);
  ok('a full book refuses new entries but still edits old ones', perm.full === 'false|true|true|300|1', perm.full);
  ok('a failed load is reported and never destroys what was loaded', perm.fail === 'true|true|true|false|false' && perm.failFresh === 'true|true|0|★ โหลดดาวไม่ได้' && perm.recover === 'false|true', [perm.fail, perm.failFresh, perm.recover]);

  // ================= E) ผู้พัฒนา: ลบรีวิวของคนอื่น =================
  await page.evaluate(async () => { asUser('u1', 'Non', { dev: true }); MapLib.tab = 'pub'; location.hash = '#home'; await new Promise(r => setTimeout(r, 50)); location.hash = '#maps'; }); await wait(700);
  await page.click('#v-maps .rvchip[data-id="m2"]'); await wait(350);
  const dv0 = await page.evaluate(() => ({ mods: [...document.querySelectorAll('#modal .rvitem')].map(i => i.dataset.uid + ':' + (i.querySelector('.rvmod') ? 'mod' : 'none') + ':' + (i.querySelector('.rvname').getAttribute('title') || '')).join('|'), form: !!document.querySelector('#modal .rvmine'), u4before: JSON.stringify(__mock.mem.maps['rvbook-u4']) }));
  ok('developer sees a remove button and the account id on every review', dv0.mods === 'u5:mod:UID u5|u4:mod:UID u4|u3:mod:UID u3|u8:mod:UID u8' && dv0.form, dv0.mods);
  await page.click('#modal .rvitem[data-uid="u4"] .rvmod'); await wait(400);
  const dv1 = await page.evaluate((before) => { const b0 = JSON.parse(before), b1 = __mock.mem.maps['rvbook-u4']; return { items: Object.keys(b1.items).join(), sameStamp: b1.updatedAt === b0.updatedAt, owner: b1.ownerId + '|' + b1.ownerName, list: [...document.querySelectorAll('#modal .rvitem')].map(i => i.dataset.uid).join(), cap: document.querySelector('#modal .rvavg div').textContent, chip: document.querySelector('#v-maps .rvchip[data-id="m2"]').textContent.replace(/★+/g, '*') }; }, dv0.u4before);
  ok('developer removal edits only that entry of that person\'s book', dv1.items === 'm1' && dv1.sameStamp && dv1.owner === 'u4|ก้อง' && dv1.list === 'u5,u3,u8' && dv1.cap === '3 คนให้ดาว · 2 คอมเมนต์' && dv1.chip === '*4.7(3)· 💬 2' && dialogs.some(d => /ลบดาวและคอมเมนต์ของ "ก้อง"/.test(d)), dv1);
  await page.evaluate(() => modal(null)); await page.click('#v-maps .rvminebtn'); await wait(450);
  const dall = await page.evaluate(() => ({ rows: [...document.querySelectorAll('#modal .rvall .rvitem')].map(i => i.dataset.uid + '>' + i.dataset.tid + ':' + i.querySelector('.rvto').textContent + ':' + (i.querySelector('.rvmod') ? 'mod' : 'none')), note: document.querySelector('#modal .rvallnote').textContent, own: document.querySelectorAll('#modal .rvlist:not(.rvall) .rvitem').length, kick: [...document.querySelectorAll('#modal .kicker')].map(k => k.textContent).join() }));
  ok('developer gets one list of the newest reviews across the site', dall.kick === 'รีวิวล่าสุดทั้งเว็บ (มุมมองผู้พัฒนา)' && dall.rows.length === 9 && /^ทั้งหมด 9 รายการ$/.test(dall.note) && dall.rows.every(r => /:mod$/.test(r)) && dall.rows.includes('u3>gone1:ถึง "แผนที่ที่หายไป":mod') && dall.rows.includes('u3>m3:ถึง "ถ้ำแมงมุม":mod') && dall.own === 0, dall);
  await page.click('#modal .rvall .rvitem[data-uid="u3"][data-tid="m3"] .rvmod'); await wait(450);
  const dall2 = await page.evaluate(() => ({ items: Object.keys(__mock.mem.maps['rvbook-u3'].items).sort().join(), rows: document.querySelectorAll('#modal .rvall .rvitem').length, open: document.querySelector('#modal .rvbox').dataset.id }));
  ok('and can remove any of them from there', dall2.items === 'a1,gone1,m2,n1' && dall2.rows === 8 && dall2.open === '@mine', dall2);
  await shot('198-review-dev-list-v119.png');
  const dv2 = await page.evaluate(async (squatId) => { const mem = __mock.mem; delete mem[squatId]; const b = mem.maps[squatId]; delete b.items.n1; const r = await ReviewLib.devRemove({ bookId: squatId, tid: 'm2' }); asUser('u4', 'ก้อง'); const denied = await ReviewLib.devRemove({ bookId: 'rvbook-u3', tid: 'm2' }); return [r, !!mem.maps[squatId], denied, !!mem.maps['rvbook-u3'].items.m2].join('|'); }, perm.squatId);
  ok('removing the last entry deletes the book, and only a developer can do it', dv2 === 'true|false|false|true', dv2);
  await page.evaluate(() => modal(null));

  // ================= F) การเรียง: คะแนนถ่วงด้วยดาว 3 จำนวน 3 เสียงสมมติ =================
  const srt = await page.evaluate(async () => {
    const mem = __mock.mem; for (const k of Object.keys(mem.maps)) delete mem.maps[k];
    const g = generateMap('field', 's');
    const mk = (id, at) => { mem.maps[id] = { id, ownerId: 'own', ownerName: 'เจ้าของ', name: 'ชิ้น ' + id, cells: g.cells, kind: 'field', npcs: [], published: true, updatedAt: at }; };
    mk('A', 1); mk('B', 2); mk('C', 3); mk('D', 4); mk('E', 5); mk('F', 6);
    const bStars = [5, 5, 5, 5, 5, 5, 4, 4, 4, 4]; // รวม 46 จาก 10 คน
    for (let i = 1; i <= 10; i++){ const items = { B: { t: 'map', s: bStars[i - 1], x: '' }, E: { t: 'map', s: 2, x: '' } }; if (i <= 5) items.C = { t: 'map', s: 5, x: '' }; if (i === 1) items.A = { t: 'map', s: 5, x: '' }; if (i <= 3) items.F = { t: 'map', s: 0, x: 'คอมเมนต์อย่างเดียว ' + i }; mem.maps['rvbook-v' + i] = { id: 'rvbook-v' + i, type: 'reviews', published: true, ownerId: 'v' + i, ownerName: 'ผู้ให้ดาว ' + i, updatedAt: 100 + i, items }; }
    asUser('u1', 'GM ทดสอบ'); await MapLib.loadPublished(); await ReviewLib.load(true);
    const T = (id) => MapLib.pub.find(x => x.id === id); const out = {};
    out.scores = ['A', 'B', 'C', 'D', 'E', 'F'].map(id => id + '=' + ReviewLib.score(T(id)).toFixed(4)).join(' ');
    out.exact = [ReviewLib.score(T('A')) === 14 / 4, ReviewLib.score(T('B')) === 55 / 13, ReviewLib.score(T('C')) === 34 / 8, ReviewLib.score(T('D')) === 3, ReviewLib.score(T('E')) === 29 / 13, ReviewLib.score(T('F')) === 3].join();
    out.plain = ['A', 'B', 'C'].map(id => ReviewLib.summary(T(id)).avg.toFixed(2)).join();
    out.top = ReviewLib.sorted(MapLib.pub, 'top').map(x => x.id).join(''); out.most = ReviewLib.sorted(MapLib.pub, 'most').map(x => x.id).join(''); out.new = ReviewLib.sorted(MapLib.pub, 'new').map(x => x.id).join(''); out.other = ReviewLib.sorted(MapLib.pub, 'zzz').map(x => x.id).join('');
    out.untouched = MapLib.pub.map(x => x.id).join('');
    return out; });
  ok('weighted scores are exact', srt.scores === 'A=3.5000 B=4.2308 C=4.2500 D=3.0000 E=2.2308 F=3.0000' && srt.exact === 'true,true,true,true,true,true', srt.scores);
  ok('"top" puts proven work above a single five and unrated work above proven bad work', srt.top === 'CBAFDE' && srt.plain === '5.00,4.60,5.00', [srt.top, srt.plain]);
  ok('"most" orders by number of reviews and "new" by date, without touching the source list', srt.most === 'EBCFAD' && srt.new === 'FEDCBA' && srt.other === 'FEDCBA' && srt.untouched === 'FEDCBA', srt);
  await page.evaluate(() => { MapLib.tab = 'pub'; location.hash = '#home'; }); await wait(60); await page.evaluate(() => { location.hash = '#maps'; }); await wait(600);
  await page.selectOption('#v-maps .rvsort', 'top'); await wait(250);
  const order1 = await page.evaluate(() => [...document.querySelectorAll('#v-maps .mapcard h3')].map(x => x.textContent.slice(-1)).join('') + '|' + document.querySelector('#v-maps .rvsort').value + '|' + MapLib.sort);
  await page.fill('#v-maps input[placeholder^="ค้นหา"]', 'ชิ้น'); await wait(200);
  const order2 = await page.evaluate(() => [...document.querySelectorAll('#v-maps .mapcard h3')].map(x => x.textContent.slice(-1)).join(''));
  await page.selectOption('#v-maps .rvsort', 'most'); await wait(250);
  const order3 = await page.evaluate(() => [...document.querySelectorAll('#v-maps .mapcard h3')].map(x => x.textContent.slice(-1)).join(''));
  ok('the sort menu reorders the cards and survives searching', order1 === 'CBAFDE|top|top' && order2 === 'CBAFDE' && order3 === 'EBCFAD', [order1, order2, order3]);
  await page.evaluate(() => { MapLib.sort = 'new'; MapLib.q = ''; });

  // ================= G) รีวิวของฉัน + หน้า NPC / Asset =================
  await page.evaluate(async () => { const mem = __mock.mem; for (const k of Object.keys(mem.maps)) delete mem.maps[k]; seedWorld(); asUser('u3', 'ฟ้าใส'); NpcLib.tab = 'pub'; location.hash = '#home'; await new Promise(r => setTimeout(r, 50)); location.hash = '#npcs'; }); await wait(800);
  const np = await page.evaluate(() => ({ cards: [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.dataset.id + '=' + c.querySelector('.rvchip').textContent.replace(/★+/g, '*')).join('|'), sort: document.querySelectorAll('#v-npcs .rvsort').length, mine: document.querySelector('#v-npcs .rvminebtn').textContent }));
  ok('NPC / Asset page shows ratings, the sort menu and my count', np.cards === 'a1=☆ ยังไม่มีดาว· 💬 1|n1=*4.0(1)' && np.sort === 1 && np.mine === 'รีวิวของฉัน (5)', np);
  await shot('195-review-npcs-v119.png');
  await page.selectOption('#v-npcs .rvsort', 'top'); await wait(200);
  ok('NPC / Asset page sorts by weighted stars', await page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.dataset.id).join()) === 'n1,a1');
  await page.click('#v-npcs .typef[data-type="asset"]'); await wait(250);
  ok('type filter still works with the sort menu', await page.evaluate(() => [...document.querySelectorAll('#v-npcs .npccard')].map(c => c.dataset.id).join() + '|' + document.querySelector('#v-npcs .rvsort').value) === 'a1|top');
  await page.click('#v-npcs .typef[data-type="all"]'); await wait(250);
  await page.click('#v-npcs .npccard[data-id="n1"] button:text-is("ดู")'); await wait(250);
  ok('NPC preview carries the rating chip', await page.evaluate(() => !!document.querySelector('#modal .rvchip[data-id="n1"]')));
  await page.click('#modal .rvchip'); await wait(300);
  const nm = await page.evaluate(() => { const b = document.querySelector('#modal .rvbox'); return { head: b.querySelector('h3 + div').textContent, kicker: b.querySelector('.rvmine .kicker').textContent, stars: b.querySelectorAll('.rvstarbtn.on').length, save: b.querySelector('.rvsave').textContent, first: b.querySelector('.rvitem').className }; });
  ok('my existing review is preloaded in the window', nm.head === 'NPC "อัศวินเสื้อคลุมน้ำเงิน" โดย ลุงหมี' && nm.kicker === 'ดาวและคอมเมนต์ของคุณ' && nm.stars === 4 && nm.save === 'บันทึกการแก้ไข' && nm.first === 'rvitem me', nm);
  await page.evaluate(() => modal(null));
  await page.click('#v-npcs .rvminebtn'); await wait(450);
  const my = await page.evaluate(() => ({ title: document.querySelector('#modal .rvmybox h3').textContent, rows: [...document.querySelectorAll('#modal .rvitem')].map(i => i.dataset.tid + ':' + i.querySelector('.tag').textContent + ':' + i.querySelector('.rvname').textContent + ':' + (i.querySelector('.rvopen') ? 'edit' : 'noedit') + ':' + (i.querySelector('.rvdel') ? 'del' : 'nodel')).join('|') }));
  ok('my reviews lists everything I wrote, including work that is gone or my own', my.title === 'รีวิวของฉัน' && my.rows === 'gone1:แผนที่:แผนที่ที่หายไป:noedit:del|m3:แผนที่:ถ้ำแมงมุม:noedit:del|a1:Asset:ประตูเหล็ก:edit:del|n1:NPC:อัศวินเสื้อคลุมน้ำเงิน:edit:del|m2:แผนที่:ท่าเรือเก่าลักซอนเนีย:noedit:del', my.rows);
  await shot('196-my-reviews-v119.png');
  await page.click('#modal .rvitem[data-tid="gone1"] .rvdel'); await wait(400);
  const my2 = await page.evaluate(() => ({ items: Object.keys(__mock.mem.maps['rvbook-u3'].items).sort().join(), rows: document.querySelectorAll('#modal .rvitem').length, btn: document.querySelector('#v-npcs .rvminebtn').textContent }));
  ok('a review of work that no longer exists can still be deleted', my2.items === 'a1,m2,m3,n1' && my2.rows === 4 && my2.btn === 'รีวิวของฉัน (4)' && dialogs.some(d => /ลบดาวและคอมเมนต์ที่คุณให้ "แผนที่ที่หายไป"/.test(d)), my2);
  await page.click('#modal .rvitem[data-tid="a1"] .rvopen'); await wait(300);
  ok('"edit" jumps to that work\'s review window', await page.evaluate(() => document.querySelector('#modal .rvbox').dataset.id === 'a1' && document.querySelector('#modal .rvtextin').value === 'ใช้เป็นประตูกลได้ดี' && document.querySelectorAll('#modal .rvstarbtn.on').length === 0));
  await page.evaluate(() => modal(null));
  // จอมือถือ
  await page.setViewportSize({ width: 390, height: 844 }); await page.evaluate(() => { location.hash = '#home'; }); await wait(80); await page.evaluate(() => { NpcLib.sort = 'new'; location.hash = '#npcs'; }); await wait(700);
  await page.click('#v-npcs .rvchip[data-id="n1"]'); await wait(350);
  const mob = await page.evaluate(() => { const b = document.querySelector('#modal .box').getBoundingClientRect(); const over = [...document.querySelectorAll('#modal .rvbox *')].filter(e => e.getBoundingClientRect().right > b.right + 1).length; return { w: Math.round(b.width), over, vw: window.innerWidth }; });
  ok('review window fits a phone screen', mob.over === 0 && mob.w <= mob.vw, mob);
  await shot('197-review-mobile-v119.png');
  await page.evaluate(() => modal(null)); await page.setViewportSize({ width: 1400, height: 1000 });
  // ป้ายนอกหน้ารายการ (ดูภาพย่อจากตัวแก้ไขแผนที่): โหลดรีวิวเองแล้วเติมตัวเอง
  await page.evaluate(async () => { asUser('u2', 'ลุงหมี'); location.hash = '#home'; await new Promise(r => setTimeout(r, 50)); location.hash = '#mapedit-m2'; }); await wait(700);
  const pre0 = await page.evaluate(() => ReviewLib.loaded);
  await page.click('#v-maps button:has-text("ดูภาพย่อ")'); await wait(450);
  const pre = await page.evaluate(() => document.querySelector('#modal .rvchip').textContent.replace(/★+/g, '*'));
  ok('a chip outside the list pages loads the reviews by itself', pre0 === false && pre === '*4.7(3)· 💬 1', [pre0, pre]);
  await page.click('#modal .rvchip'); await wait(300);
  ok('the owner opening it from the editor gets the read-only window', await page.evaluate(() => document.querySelector('#modal .rvblk').dataset.code === 'own' && document.querySelectorAll('#modal .rvitem').length === 3));
  await page.evaluate(() => modal(null));

  // ================= H) นโยบายและทางเข้า =================
  await page.goto(url + '#policy'); await page.reload(); await wait(500);
  const pol = await page.evaluate(() => document.querySelector('#v-policy').textContent);
  ok('policy: what is stored and who sees it', /ดาวและคอมเมนต์: ดาวที่คุณให้และข้อความที่คุณเขียนถึงแผนที่ NPC หรือ Asset ที่คนอื่นเผยแพร่/.test(pol) && /ดาวและคอมเมนต์ที่คุณให้ ทุกคนที่เข้าสู่ระบบเห็นได้พร้อมชื่อที่แสดงของคุณ/.test(pol) && /ผู้ใช้ที่เข้าสู่ระบบด้วย Google ให้ดาวและคอมเมนต์ได้ทุกคน/.test(pol));
  ok('policy: deleting, conduct and enforcement', /แก้หรือลบดาวและคอมเมนต์ของคุณได้ทุกเมื่อ/.test(pol) && /ปุ่ม "รีวิวของฉัน"/.test(pol) && /ติชมผลงานอย่างให้เกียรติ/.test(pol) && /อย่าใช้หลายบัญชีให้ดาวผลงานของตัวเอง/.test(pol) && /ลบดาวและคอมเมนต์ (ลบข้อความในแชตกลาง )?ยกเลิกการเผยแพร่แผนที่ NPC หรือ Asset/.test(pol) && /ปรับปรุงล่าสุด \d+ พฤศจิกายน 2026/.test(pol));
  ok('nav is unchanged', await page.evaluate(() => [...document.querySelectorAll('#nav a')].map(a => a.getAttribute('href')).join()) === '#home,#create,#chars,#table,#maps,#npcs,#rules,#dev');

  console.log(`checks: ${pass} passed, ${fail} failed`);
  console.log('errors', errors);
  await browser.close();
  if (fail || errors.length) process.exit(1);
})();
