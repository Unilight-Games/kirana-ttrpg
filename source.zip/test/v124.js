// v1.24 (15 พ.ย. 2026) Non สั่งเจ็ดข้อ
//  A) ภาพที่อัปเข้าเว็บไม่เกิน 2 MB ต่อภาพ ใช้กับทุกบัญชีและทุกเครื่อง (รวมภาพที่ติดมากับ JSON นำเข้า)
//  B) พื้นหลังที่ให้สกิล (ได้รับ Skill (...)) เข้ารายการสกิลจริง · Necrobug ตัวอ่อนที่วิวัฒนาการเอง เลือก Kins Unique Skill ได้ 1
//  C) Flavor ของ Trait วงศาแยกจาก Effect
//  D) Trait พื้นหลังขึ้นชื่อ Trait ของมันเอง (ไทยก่อน อังกฤษในวงเล็บ) ไม่มีคำว่า Trait และชื่อพื้นหลังในหัวข้อ
//  E) Lunaryn ยืมศาสตราชีวะจาก Swalan: กล่องผูกไอเทมขึ้นตั้งแต่ขั้นวงศา และอยู่บนสุดของขั้นชุดเริ่มต้น · ชีทมีแถบเตือน
//  F) คลิกเช็คระยะแล้วเห็นกรอบระยะยิงแม่น ขั้นโทษ และเส้นวัดพร้อมป้ายเมตร (v1.25: โทษ −1 CV ต่อ 1 ม.)
//  G) GM ตั้งชื่อและเปลี่ยนชื่อโต๊ะได้
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  let dialogs = []; page.on('dialog', d => { dialogs.push(d.message()); d.accept(); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  const SHOTS = process.argv[2] || '';
  await page.goto(url); await wait(400);

  // ================= A) เพดานภาพ 2 MB =================
  const A = await page.evaluate(() => { const r = {}; Store.isDevUid = true; Store.isDevIp = true;
    r.devBlocked = imgUploadBlocked({ size: 2 * 1024 * 1024 + 1 }, null); r.note = imgUploadNote(); r.edge = imgUploadBlocked({ size: 2 * 1024 * 1024 }, null);
    Store.isDevUid = false; Store.isDevIp = false;
    const big = 'data:image/jpeg;base64,' + 'A'.repeat(Math.ceil(2.6 * 1024 * 1024 * 4 / 3));
    r.bigBytes = imgDataUrlBytes(big); r.bigToo = imgDataUrlTooBig(big); r.smallToo = imgDataUrlTooBig('data:image/png;base64,iVBORw0KGgo=');
    return r; });
  ok('A: developers are capped too', A.devBlocked === true && A.edge === false && A.note === 'ไฟล์ภาพไม่เกิน 2 MB', A);
  ok('A: data URL size measured', A.bigToo === true && A.smallToo === false && Math.abs(A.bigBytes - 2.6 * 1024 * 1024) < 8, A);
  await page.goto(url + '#chars'); await wait(300);
  const imp = await page.evaluate(() => { const big = 'data:image/jpeg;base64,' + 'A'.repeat(Math.ceil(2.6 * 1024 * 1024 * 4 / 3));
    const c = Object.assign(newChar(), { id: 'impbig', name: 'นำเข้าภาพใหญ่', kin: 'solrin', done: true, portrait: big });
    importChar(); const ta = document.querySelector('#modal textarea'); ta.value = JSON.stringify(c);
    [...document.querySelectorAll('#modal button')].find(b => b.textContent === 'นำเข้า').click();
    const got = Store.chars.find(x => x.name === 'นำเข้าภาพใหญ่'); return { got: !!got, portrait: !!(got && got.portrait), toast: document.querySelector('#toast').textContent }; });
  ok('A: imported JSON portrait over 2 MB is dropped with a note', imp.got && !imp.portrait && /เกินเพดาน 2 MB/.test(imp.toast), imp);

  // ================= B) สกิลจากพื้นหลัง =================
  const B = await page.evaluate(() => {
    const mk = (kin, ch, ad) => Object.assign(newChar(), { kin, childhood: ch, adulthood: ad });
    const r = {};
    r.swalan = allSkills(mk('swalan', 'C1', 'A1')).includes('Adaptive Morphology');
    r.floran = ['Controlled Pollination', 'Vine Limb', 'Volatile Photosynthesis'].map(n => allSkills(mk('floran', n === 'Vine Limb' ? 'C2' : 'C1', 'A5')).includes(n));
    const nb = allSkills(mk('necrobug', 'C1', 'A1')); r.necroC1 = nb.includes('Scythe Claw') && nb.includes('Carapace Cracker');
    const sw2 = mk('swalan', 'C2', 'A1'); r.noGrant = !allSkills(sw2).includes('Adaptive Morphology');
    const c5 = mk('necrobug', 'C5', 'A1'); r.missing = bgPickMissing(c5) && bgPickMissing(c5).code; r.opts = bgPickOptions(c5, findBg(KIN.necrobug, 'C5')).map(s => s.nameEn);
    c5.bgSkillPick = { 'bg:C5': 'Warning Tremor' }; r.picked = allSkills(c5).includes('Warning Tremor'); r.missing2 = bgPickMissing(c5);
    c5.bgSkillPick = { 'bg:C5': 'Fleshforge' }; r.foreign = !allSkills(c5).includes('Fleshforge') && !!bgPickMissing(c5);
    const grants = DATA.kins.flatMap(k => ['childhood','specialChildhood','adulthood','specialAdulthood'].flatMap(g => (k[g]||[]).filter(b => b.grantSkills || b.grantPick).map(b => k.id + ' ' + b.code)));
    r.grants = grants; r.unknown = DATA.kins.flatMap(k => ['childhood','adulthood'].flatMap(g => (k[g]||[]).flatMap(b => (b.grantSkills||[]).filter(n => !SKILL_BY_NAME[n]))));
    return r; });
  ok('B: Swalan Living Weapon grants Adaptive Morphology', B.swalan, B);
  ok('B: Floran backgrounds grant their skills', B.floran.every(Boolean), B.floran);
  ok('B: Necrobug Warrior Path grants both skills', B.necroC1, B);
  ok('B: other backgrounds grant nothing', B.noGrant, B);
  ok('B: Necrobug Self Evolution needs a Kins Unique pick', B.missing === 'C5' && B.opts.length === 10 && B.opts.includes('Warning Tremor'), B);
  ok('B: the pick becomes a skill and clears the blocker', B.picked && !B.missing2, B);
  ok('B: a pick from another kin is ignored', B.foreign, B);
  ok('B: six granting backgrounds, all skills known', B.grants.length === 6 && B.unknown.length === 0, B);
  // วิซาร์ด: การ์ด C5 มีกล่องเลือก ขั้นพื้นหลังติดจนกว่าจะเลือก
  await page.evaluate(() => { startWizard(null); selectKin(W.char, 'necrobug'); W.char.childhood = 'C5'; W.char.adulthood = 'A1'; W.char.choiceStats = ['STR','AGI','VIT','PER']; W.step = 1; renderWizard(); });
  await page.goto(url + '#wizard'); await wait(400);
  const Bw = await page.evaluate(() => ({ box: document.querySelectorAll('#v-create .bgpick').length, cards: document.querySelectorAll('#v-create .bgpick .sk').length, blocker: stepBlocker(1), grantCards: document.querySelectorAll('#v-create .bggrant').length }));
  ok('B: wizard shows the Kins Unique pick box under the chosen card', Bw.box === 1 && Bw.cards === 10, Bw);
  ok('B: background step blocked until the pick', /Kins Unique Skill 1 สกิล/.test(Bw.blocker || ''), Bw);
  await page.click('#v-create .bgpick .sk:has-text("Warning Tremor")'); await wait(250);
  const Bw2 = await page.evaluate(() => ({ pick: (W.char.bgSkillPick||{})['bg:C5'], blocker: stepBlocker(1), side: [...document.querySelectorAll('#v-create .side .tag, #v-create .tag')].some(t => /ได้รับสกิล/.test(t.textContent)) }));
  ok('B: clicking a card picks it and unblocks', Bw2.pick === 'Warning Tremor' && !Bw2.blocker, Bw2);
  await page.evaluate(() => { W.char.childhood = 'C1'; W.step = 1; renderWizard(); }); await wait(250);
  ok('B: Warrior Path card lists the two granted skills', await page.evaluate(() => document.querySelectorAll('#v-create .card.sel .bggrant').length) === 2);

  // ================= C) Flavor ของ Trait วงศา =================
  const C = await page.evaluate(() => {
    const all = DATA.kins.flatMap(k => ['traits','benefits','hindrances'].flatMap(g => (k[g]||[]).map(t => ({ k: k.id, g, t }))));
    const fl = all.filter(x => x.t.flavor);
    const res = KIN.solrin.traits.find(t => t.nameEn === 'Resilient'); const ash = KIN.solrin.hindrances.find(t => t.nameEn === 'Ashes of Wrath');
    const furn = KIN.norlan.hindrances.find(t => t.nameEn === 'Caloric Furnace');
    return { n: fl.length, overlap: fl.filter(x => x.t.text.includes(x.t.flavor)).length, empty: fl.filter(x => !x.t.text.trim()).length,
      res: [res.flavor, res.text.slice(0, 20)], ash: ash.text, furn: furn.text.slice(0, 13), survivors: all.filter(x => x.t.nameEn === "Survivor's Legacy" && x.t.flavor).length }; });
  ok('C: 28 kin traits carry flavor, none left inside the effect', C.n === 28 && C.overlap === 0 && C.empty === 0, C);
  ok('C: Resilient split', C.res[0] === 'ร่างกายของคุณถูกปรับให้ทนทานต่อสภาพอากาศอันสุดขั้วได้ดีเยี่ยม' && C.res[1].startsWith('คุณได้รับ Advantage'), C.res);
  ok('C: mid-sentence flavor lifted and the effect rejoined', C.ash === 'หลังจากผลของความสามารถ โทสะสุริยัน (Sun\'s Fury) สิ้นสุดลง คุณจะได้รับสภาวะ เหนื่อยล้า (Exhaustion) 1 ระดับทันที', C.ash);
  ok('C: joining word at the seam dropped', C.furn === 'เมื่อทำการพัก', C.furn);
  ok('C: Survivor\'s Legacy flavor on all four human kins', C.survivors === 4, C);

  // ================= D) ชื่อ Trait พื้นหลัง =================
  const D = await page.evaluate(() => {
    const bgs = DATA.kins.flatMap(k => ['childhood','specialChildhood','adulthood','specialAdulthood'].flatMap(g => (k[g]||[]).map(b => ({ k: k.id, b }))));
    const named = bgs.filter(x => x.b.traitEn);
    const th = named.map(x => x.b.traitTh);
    return { n: named.length, total: bgs.length, label: bgs.filter(x => /Trait\s*\(/.test(x.b.text || '')).length, dup: th.filter((t, i) => th.indexOf(t) !== i),
      thaiFirst: named.every(x => /^[฀-๿]/.test(x.b.traitTh)), a7: (() => { const b = findBg(KIN.lunaryn, 'A7'); return [b.note, bgTraitLabel(b), b.text.slice(0, 8)]; })(),
      alpha: bgTraitLabel(findBg(KIN.orcarim, 'C5')), unstop: findBg(KIN.orcarim, 'A4').traitEn }; });
  ok('D: 138 background traits named, no Trait label left in text', D.n === 138 && D.total === 144 && D.label === 0, D);
  ok('D: Thai names unique and Thai-first', D.dup.length === 0 && D.thaiFirst, D);
  ok('D: female-only note kept apart from the effect', D.a7[0] === 'เลือกได้เฉพาะเพศหญิง' && D.a7[1] === 'ญาณกายวิภาค (Anatomical Insight)' && D.a7[2] === '1 ครั้งต', D.a7);
  ok('D: existing Thai name kept, English spelling fixed', D.alpha === "ท้าทายจ่าฝูง (Alpha's Challenge)" && D.unstop === 'The Unstoppable', D);
  // ชีท: Solrin + Inner Flame (C2) + Dazzling Display (A6)
  await page.evaluate(() => { Store.upsert(Object.assign(newChar(), { id: 'v124s', name: 'ทดสอบเทรต', kin: 'solrin', childhood: 'C2', adulthood: 'A6', size: 'Medium', done: true, step: 7, starterSet: 'The Sailor' })); });
  await page.goto(url + '#sheet-v124s'); await wait(600);
  const Ds = await page.evaluate(() => { const box = document.querySelector('.traitbox[data-k="trait"]'); const items = [...box.querySelectorAll('.titem')];
    const heads = items.map(i => i.querySelector('.tag').textContent); const srcs = items.map(i => { const m = i.querySelector('.muted'); return m ? [m.textContent.trim(), m.title] : null; });
    return { heads, srcs, flav: [...box.querySelectorAll('.tflavor')].map(x => x.textContent.slice(0, 20)), descs: items.map(i => i.querySelector('.desc').textContent.slice(0, 12)) }; });
  ok('D: sheet heads background traits with their own names', Ds.heads.includes('เปลวไฟภายใน (Inner Flame)') && Ds.heads.includes('การแสดงตระการตา (Dazzling Display)'), Ds.heads);
  ok('D: background names gone from the heads, kept in the tooltip', !Ds.heads.some(h => /^Trait|ไฟในจิตวิญญาณ/.test(h)) && Ds.srcs.some(s => s && s[0] === 'วัยเด็ก' && /^พื้นหลังวัยเด็ก: /.test(s[1])), Ds.srcs);
  ok('D: no description starts with Trait (', !Ds.descs.some(d => /^Trait/.test(d)), Ds.descs);
  ok('D/C: kin flavor shows in the sheet', Ds.flav.some(f => f.startsWith('ร่างกายของคุณถูกปรับ')), Ds.flav);
  if (SHOTS) { const el = await page.$('.traitbox[data-k="trait"]'); if (el) await el.screenshot({ path: path.join(SHOTS, 'v124_traits.png') }); }
  // วิซาร์ด: การ์ดพื้นหลังมีบรรทัด Trait
  await page.evaluate(() => { startWizard(null); selectKin(W.char, 'lunaryn'); W.step = 1; renderWizard(); }); await page.goto(url + '#wizard'); await wait(400);
  const Dw = await page.evaluate(() => ({ traitRows: document.querySelectorAll('#v-create .bgtrait').length, notes: [...document.querySelectorAll('#v-create .bgnote')].map(n => n.textContent), flavor: document.querySelectorAll('#v-create .card.pick .flavor').length }));
  ok('D: wizard cards show the trait name row and the female-only note', Dw.traitRows >= 20 && Dw.notes.includes('เลือกได้เฉพาะเพศหญิง') && Dw.flavor >= 2, Dw);

  // ================= E) ศาสตราชีวะของ Lunaryn ที่ยืมจาก Swalan =================
  await page.evaluate(() => { startWizard(null); selectKin(W.char, 'lunaryn'); const c = W.char; c.evolver = { kin: 'swalan', pick: 'S:ศาสตราชีวะ (Fleshforge)', hindrance: KIN.swalan.hindrances[0].nameEn }; W.step = 0; renderWizard(); });
  await page.goto(url + '#wizard'); await wait(400);
  const E0 = await page.evaluate(() => ({ evoff: document.querySelectorAll('#v-create .evoff.ffbox').length, pickBtn: !!document.querySelector('#v-create .evoff .ffpick'), side: [...document.querySelectorAll('#v-create .tag')].some(t => /ศาสตราชีวะ: ยังไม่ได้เลือกไอเทม/.test(t.textContent)) }));
  ok('E: binding box shows right in the kin step', E0.evoff === 1 && E0.pickBtn, E0);
  ok('E: side panel reminds that no item is bound', E0.side, E0);
  await page.evaluate(() => { W.step = 7; W.char.starterSet = null; renderWizard(); }); await wait(300);
  const E1 = await page.evaluate(() => { const body = document.querySelector('#v-create .ffbox'); const grid = document.querySelector('#v-create .grid.two'); return { ff: !!body, before: !!(body && grid && (body.compareDocumentPosition(grid) & Node.DOCUMENT_POSITION_FOLLOWING)), blocker: stepBlocker(7) }; });
  ok('E: step 8 puts the binding box above the starter sets', E1.ff && E1.before, E1);
  await page.evaluate(() => { W.char.starterSet = 'The Wanderer'; renderWizard(); }); await wait(200);
  ok('E: finishing blocked until an item is bound', /ศาสตราชีวะ/.test(await page.evaluate(() => stepBlocker(7)) || ''));
  await page.evaluate(() => { setFleshforge(W.char, { item: 'มีดพราน (Hunting Knife)', effect: '', custom: false, cat: 'อาวุธ' }, { onChange: renderWizard }); }); await wait(200);
  ok('E: bound item clears the blocker', !(await page.evaluate(() => stepBlocker(7))));
  // เปลี่ยนวงศาหลังเลือกของแล้ว ต้องถาม
  dialogs = []; await page.evaluate(() => { W.char.childhood = 'C1'; selectKin(W.char, 'solrin'); }); await wait(200);
  ok('E: switching kin with choices asks first', dialogs.length === 1 && /ถูกล้าง/.test(dialogs[0]), dialogs);
  // ชีท: แถบเตือนเมื่อยังไม่ผูก และกล่องไปต่อท้ายผังจัดเอง
  await page.evaluate(() => { Store.upsert(Object.assign(newChar(), { id: 'v124f', name: 'ลูนาร์ยืมร่าง', kin: 'lunaryn', childhood: 'C1', adulthood: 'A1', size: 'Medium', done: true, step: 7, starterSet: 'The Wanderer', evolver: { kin: 'swalan', pick: 'S:ศาสตราชีวะ (Fleshforge)', hindrance: 'Mana Hunger' } })); });
  await page.goto(url + '#sheet-v124f'); await wait(600);
  const Es = await page.evaluate(() => ({ nag: document.querySelectorAll('.ffnag').length, box: document.querySelectorAll('.box[data-k="ff"]').length }));
  ok('E: sheet shows the reminder bar and the binding box', Es.nag === 1 && Es.box === 1, Es);

  // ================= F) ระยะยิงบนกระดาน =================
  await page.goto(url + '#table'); await wait(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องวัดระยะ'); await page.click('button:has-text("สร้างห้อง")'); await wait(400);
  await page.evaluate(() => { const r = Table.room; r.map.cells = '.'.repeat(400); const mk = (id, name, x, y, lv) => ({ id, name, kind: 'npc', x, y, hp: 5, hpMax: 5, hidden: false, conds: [], rangeLv: lv });
    r.tokens.push(mk('ta', 'นักธนู', 2, 2, 0), mk('tb', 'เป้า', 9, 4, 0), mk('tc', 'ประชิด', 3, 3, 0)); Table.save(); });
  await wait(300);
  await page.click('.cell[data-x="2"][data-y="2"] .gtok'); await wait(200);
  const F0 = await page.evaluate(() => ({ svg: document.querySelectorAll('.gridwrap .rngsvg').length, rings: [...document.querySelectorAll('.rngsvg .rr')].map(e => e.getAttribute('class')), labels: [...document.querySelectorAll('.rngsvg .rl')].map(e => e.textContent), p1: document.querySelectorAll('.cell.rng-p1').length, title: document.querySelector('.cell[data-x="9"][data-y="4"]').title }));
  ok('F: selecting a token draws the range frames', F0.svg === 1 && F0.rings.includes('rr eng') && F0.rings.includes('rr near'), F0);
  ok('F: frames labelled in metres with CV steps', F0.labels.includes('10 ม. · ยิงแม่น') && F0.labels.includes('−10 CV ที่ 20 ม.'), F0.labels);
  ok('F: cells past the accurate range shade by penalty step', F0.p1 > 0, F0.p1);
  ok('F: hovering a cell tells distance and shot penalty', /ห่าง นักธนู 7 ช่อง ~14 ม\. เขตไกล · ยิง −4 CV/.test(F0.title), F0.title);
  await page.click('.cell[data-x="9"][data-y="4"] .gtok'); await wait(250);
  const F1 = await page.evaluate(() => ({ m: Table.measure, sel: Table.sel, line: document.querySelectorAll('.rngsvg .ruler').length, lbl: (document.querySelector('.rngsvg .rulerlbl') || {}).textContent, toast: document.querySelector('#toast').textContent }));
  ok('F: clicking a second token measures from the first', F1.m && F1.m.a === 'ta' && F1.m.b === 'tb' && F1.sel === 'tb' && F1.line === 1, F1);
  ok('F: ruler label gives metres, zone and penalty', F1.lbl === '14 ม. · เขตไกล · ยิง −4 CV', F1.lbl);
  ok('F: toast repeats the shot penalty', /ยิง −4 CV \(เกินระยะแม่น 10 ม\. มา 4 ม\.\)/.test(F1.toast), F1.toast);
  if (SHOTS) { const el = await page.$('.gridwrap'); if (el) await el.screenshot({ path: path.join(SHOTS, 'v124_range.png') }); }
  // NPC ระดับ 1 ระยะแม่น 20 ม.
  await page.evaluate(() => { Table.room.tokens.find(t => t.id === 'ta').rangeLv = 1; renderTable(); }); await wait(200);
  ok('F: Range level 1 moves the accurate frame to 20 m', await page.evaluate(() => [...document.querySelectorAll('.rngsvg .rl')].some(e => e.textContent === 'ยิงแม่น 20 ม.') && (document.querySelector('.rngsvg .rulerlbl') || {}).textContent === '14 ม. · เขตไกล · ยิงแม่น'));
  await page.click('.cell[data-x="15"][data-y="15"]'); await wait(200);
  ok('F: clicking an empty cell clears the measure', await page.evaluate(() => !Table.measure && !Table.sel && !document.querySelector('.rngsvg')));
  await page.click('.cell[data-x="9"][data-y="4"] .gtok'); await wait(200);
  ok('F: GM sees the NPC Range level selector', await page.evaluate(() => !!document.querySelector('select.rnglv')));
  ok('F: helpers', await page.evaluate(() => rangeAccM(0) === 10 && rangeAccM(1) === 20 && rangePenalty(10, 10) === 0 && rangePenalty(12, 10) === 2 && rangePenalty(20, 10) === 10 && rangePenalty(22, 10) === 12));

  // ================= G) ชื่อโต๊ะ =================
  const G = await page.evaluate(() => { const r = Table.room; const out = {}; out.btn = [...document.querySelectorAll('.stephead button')].some(b => b.textContent === '✏️ ชื่อโต๊ะ');
    out.empty = renameRoom(r, '   '); out.same = renameRoom(r, 'ห้องวัดระยะ'); out.ok = renameRoom(r, '  โต๊ะ   คืนจันทร์โลหิต  ');
    out.name = r.name; out.chat = Table.chat[0] && Table.chat[0].text; out.lobby = lobbyDoc(r).name; out.long = cleanRoomName('ก'.repeat(80)).length;
    out.local = (loadLocalRooms().find(x => x.id === r.id) || {}).name; return out; });
  await wait(200);
  ok('G: GM has a rename button', G.btn, G);
  ok('G: blank and unchanged names do nothing', G.empty === 'empty' && G.same === 'same', G);
  ok('G: rename trims spaces, saves, tells the chat and the lobby', G.ok === 'ok' && G.name === 'โต๊ะ คืนจันทร์โลหิต' && /เปลี่ยนชื่อโต๊ะจาก "ห้องวัดระยะ" เป็น "โต๊ะ คืนจันทร์โลหิต"/.test(G.chat) && G.lobby === G.name && G.local === G.name && G.long === 60, G);
  ok('G: header shows the new name', await page.evaluate(() => document.querySelector('.stephead h2.room-name').textContent) === 'โต๊ะ คืนจันทร์โลหิต');
  await page.click('.stephead h2.room-name'); await wait(150);
  ok('G: clicking the title opens the rename box', await page.evaluate(() => !document.querySelector('#modal').classList.contains('hidden') && document.querySelector('#modal input').value === 'โต๊ะ คืนจันทร์โลหิต'));
  await page.fill('#modal input', 'โต๊ะสุดท้าย'); await page.keyboard.press('Enter'); await wait(250);
  ok('G: Enter saves', await page.evaluate(() => Table.room.name === 'โต๊ะสุดท้าย' && document.querySelector('#modal').classList.contains('hidden')));

  ok('no page errors', errors.length === 0, errors);
  console.log(`v124: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
