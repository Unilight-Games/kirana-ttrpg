// v1.5: popup detail on top, stackable/bound conditions + devoured, light & visibility, full item catalog, map library, policy page, chars search
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type()==='error' && !/Failed to load resource/.test(m.text())) errors.push('CONSOLE ' + m.text()); });
  page.on('dialog', d => d.accept(d.type()==='prompt' ? 'แผนที่ทดสอบจากห้อง' : undefined));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url); await page.waitForTimeout(400);
  // ---- character with portrait + night vision kin (nightkin) ----
  await page.evaluate(() => { const K = window.__kirana; const cv = document.createElement('canvas'); cv.width = cv.height = 60; const ctx = cv.getContext('2d'); ctx.fillStyle = '#2a6'; ctx.fillRect(0,0,60,60);
    const mk = (id, name, kin) => ({ id, name, kin, size:'Medium', childhood:'C1', adulthood:'A1', extra:{}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, portrait: cv.toDataURL(), starterSet:'The Vanguard' });
    K.Store.upsert(mk('nk1', 'ราตรี', 'nightkin')); K.Store.upsert(mk('lu1', 'ลูน่า', 'lunaryn')); });
  // ---- #chars: portrait + search ----
  await page.goto(url + '#chars'); await page.waitForTimeout(300);
  console.log('chars portraits:', (await page.$$('.charcard img.portrait')).length, 'cards:', (await page.$$('.charcard')).length);
  await page.fill('.charsearch', 'ราตรี'); await page.waitForTimeout(100);
  console.log('after search cards:', (await page.$$('.charcard')).length, 'name:', await page.$eval('.charcard h3', e => e.textContent));
  await page.fill('.charsearch', 'ไม่มีแน่'); await page.waitForTimeout(100);
  console.log('no match msg:', await page.$eval('#v-chars .card.dim', e => e.textContent));
  await page.fill('.charsearch', ''); await page.waitForTimeout(100);
  // ---- HUD bag: detail appears above grid ----
  await page.goto(url + '#sheet-nk1'); await page.waitForTimeout(500);
  await page.click('.hud-btn[title="กระเป๋า"]'); await page.waitForTimeout(200);
  await page.click('.hud-grid .tile'); await page.waitForTimeout(200);
  const order = await page.evaluate(() => { const b = document.querySelector('.hud-win.bag .hud-body'); const kids = [...b.children].map(e => e.className.split(' ')[0]); return kids.join(' > '); });
  console.log('bag body order:', order, '| detail top:', !!(await page.$('.hud-detail-host .hud-detail.top')));
  await page.click('.hud-btn[title="ถุงย่าม"]'); await page.waitForTimeout(200);
  console.log('pouch kicker:', await page.$eval('.hud-win.pouch .kicker', e => e.textContent));
  // ---- room ----
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้อง v1.5'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.selectOption('#v-table select', 'nk1'); await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(400);
  await page.fill('input[placeholder="ชื่อ NPC/ศัตรู"]', 'หนอนยักษ์'); await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(300);
  const toks = await page.evaluate(() => Table.room.tokens.map(t => ({ name: t.name, kind: t.kind, nv: t.nv })));
  console.log('tokens:', JSON.stringify(toks));
  // light label + control
  console.log('light select:', !!(await page.$('select[title^="ระดับแสง"]')), 'library btn:', !!(await page.$('button:has-text("คลังแผนที่")')));
  // ---- conditions: stackable ----
  await page.evaluate(() => { const r = Table.room; const pc = r.tokens.find(t => t.kind==='pc'); applyCond(pc, r, 'Bleeding', {lv: 2}); });
  await page.waitForTimeout(200);
  console.log('bleeding chip:', await page.$eval('.toklist .cond.c-bleeding .cl', e => e.textContent), 'has +/-:', (await page.$$('.toklist .cond.c-bleeding .cadj')).length);
  await page.click('.toklist .cond.c-bleeding .cadj[title^="เพิ่ม"]'); await page.waitForTimeout(200);
  console.log('after +:', await page.evaluate(() => Table.room.tokens.find(t=>t.kind==='pc').conds[0].lv), 'badge:', await page.$eval('.gtok.pc .cbadges span', e => e.textContent));
  // bound: Grappled requires source → moveBlocked
  const blocked = await page.evaluate(() => { const r = Table.room; const pc = r.tokens.find(t=>t.kind==='pc'), npc = r.tokens.find(t=>t.kind==='npc'); npc.x = pc.x; npc.y = Math.max(0, pc.y-1); applyCond(pc, r, 'Grappled', {by: npc}); const far = {x: (pc.x+5)%20, y: (pc.y+5)%20}; return { chip: condLabel(pc.conds.find(c=>c.id==='Grappled'), r), blocked: moveBlocked(r, pc, far), adjacent: moveBlocked(r, pc, {x: npc.x, y: Math.min(19, npc.y+1)}) }; });
  console.log('grappled:', JSON.stringify(blocked));
  // devoured: pc inside npc, follows, released adjacent
  const dev = await page.evaluate(() => { const r = Table.room; const pc = r.tokens.find(t=>t.kind==='pc'), npc = r.tokens.find(t=>t.kind==='npc'); pc.conds = []; applyCond(pc, r, 'Devoured', {by: npc}); const inside = pc.inside === npc.id && pc.x===npc.x && pc.y===npc.y; npc.x = 3; npc.y = 3; syncDevoured(r, npc); const follow = pc.x===3 && pc.y===3; return { inside, follow, blockedMsg: moveBlocked(r, pc, {x:4,y:4}) }; });
  await page.waitForTimeout(250);
  console.log('devoured:', JSON.stringify(dev), '| pc on grid:', (await page.$$('.gtok.pc')).length, 'devbadge:', await page.$eval('.gtok.npc .devbadge', e => e.textContent).catch(()=>null), 'row tag:', await page.$eval('.toklist .tag.neg', e => e.textContent).catch(()=>null));
  await page.click('.toklist .cond.c-devoured .cl'); await page.waitForTimeout(250);
  const rel = await page.evaluate(() => { const r = Table.room; const pc = r.tokens.find(t=>t.kind==='pc'), npc = r.tokens.find(t=>t.kind==='npc'); return { inside: pc.inside, dist: cellDist(pc, npc), conds: pc.conds.length }; });
  console.log('released:', JSON.stringify(rel), 'pc on grid:', (await page.$$('.gtok.pc')).length, 'last sys:', await page.evaluate(() => Table.chat[0].text));
  // detachToken: NPC removed while PC frightened by it
  const det = await page.evaluate(() => { const r = Table.room; const pc = r.tokens.find(t=>t.kind==='pc'), npc = r.tokens.find(t=>t.kind==='npc'); applyCond(pc, r, 'Frightened', {by: npc}); const before = pc.conds.length; detachToken(r, npc); return { before, after: pc.conds.length }; });
  console.log('detach clears bound conds:', JSON.stringify(det));
  // ---- light / visibility (pure function) ----
  const vis = await page.evaluate(() => { const r = JSON.parse(JSON.stringify(Table.room)); r.tokens = [{id:'a', ownerId:'p1', x:5, y:5, nv:false}, {id:'b', ownerId:'gm', x:15, y:15, nv:false}]; r.map.cells = '.'.repeat(400);
    const out = {}; r.light='low'; out.low = computeVisibility(r, 'p1'); r.light='dim'; out.dim = computeVisibility(r, 'p1').size; r.light='dark'; out.dark = computeVisibility(r, 'p1').size; out.darkSeesB = computeVisibility(r, 'p1').has('15,15');
    r.tokens[0].nv = true; out.darkNV = computeVisibility(r, 'p1').size; r.tokens[0].nv = false; r.tokens[1].torch = true; out.darkTorch = computeVisibility(r, 'p1').has('15,15'); r.tokens[1].torch = false; r.light='abyss'; out.abyss = computeVisibility(r, 'p1').size; out.nobody = computeVisibility(r, 'zz'); out.nvKin = charHasNightVision(window.__kirana.Store.get('nk1')); out.nvLun = charHasNightVision(window.__kirana.Store.get('lu1')); return out; });
  console.log('visibility:', JSON.stringify(vis));
  // fog rendering as non-GM: fake me
  const fog = await page.evaluate(() => { const r = Table.room; r.light = 'dark'; const pc = r.tokens.find(t=>t.kind==='pc'); pc.x = 10; pc.y = 10; pc.nv = false; const me = window.__kirana.Store.me; window.__kirana.Store.me = 'someone'; pc.ownerId = 'someone'; const gm = Table.isGM; Table.isGM = () => false; renderTable(); const fogs = document.querySelectorAll('.cell.fog').length; const dark = !!document.querySelector('.gridmap.dark-scene'); Table.isGM = gm; window.__kirana.Store.me = me; pc.ownerId = me || 'local'; r.light = 'low'; renderTable(); return { fogs, dark }; });
  console.log('fog cells (dark, no NV at 10,10):', JSON.stringify(fog), 'expect 391');
  // ---- item catalog ----
  const cat = await page.evaluate(() => { const c = itemCatalog(); return { n: c.length, cats: itemCats().length, sample: c.find(i=>/Katar/.test(i.name)) && c.find(i=>/Katar/.test(i.name)).price, hasSetItem: c.some(i=>i.src==='ชุดยังชีพ') }; });
  console.log('catalog:', JSON.stringify(cat));
  await page.evaluate(() => { const r = Table.room; const pc = r.tokens.find(t=>t.kind==='pc'); giveItemModal(pc, r); });
  await page.waitForTimeout(200);
  console.log('gift modal cat select options:', (await page.$$('#modal select option')).length, 'list rows:', (await page.$$('#modal .gift')).length);
  await page.selectOption('#modal select', 'โล่'); await page.waitForTimeout(150);
  console.log('shields rows:', (await page.$$('#modal .gift')).length, 'first:', await page.$eval('#modal .gift b', e => e.textContent));
  await page.evaluate(() => modal(null));
  // ---- save room map to library, then maps page ----
  await page.click('button:has-text("เก็บเข้าคลัง")'); await page.waitForTimeout(300);
  console.log('toast:', await page.$eval('#toast', e => e.textContent));
  await page.goto(url + '#maps'); await page.waitForTimeout(400);
  console.log('maps page cards:', (await page.$$('.mapcard')).length, 'thumb:', !!(await page.$('.mapcard canvas.mapthumb')), 'title:', await page.$eval('#v-maps h2', e => e.textContent));
  await page.click('button:has-text("+ สร้างแผนที่ใหม่")'); await page.waitForTimeout(400);
  console.log('editor hash:', await page.evaluate(() => location.hash.slice(0,9)), 'grid cells:', (await page.$$('#v-maps .gridmap .cell')).length, 'palette:', (await page.$$('.palette .pal')).length);
  await page.fill('#v-maps input[placeholder^="ชื่อแผนที่"]', 'ถ้ำทดสอบ'); await page.waitForTimeout(50);
  await page.click('.palette .pal[title="ลาวา (อันตราย)"]'); await page.waitForTimeout(100);
  await page.dispatchEvent('#v-maps .cell[data-x="2"][data-y="2"]', 'pointerdown'); await page.waitForTimeout(100);
  await page.click('.palette .pal:has-text("วาง NPC")'); await page.waitForTimeout(100);
  await page.fill('#v-maps input[placeholder="ชื่อ NPC"]', 'ค้างคาว'); await page.dispatchEvent('#v-maps .cell[data-x="5"][data-y="5"]', 'pointerdown'); await page.waitForTimeout(150);
  await page.selectOption('#v-maps select >> nth=1', 'dark'); await page.waitForTimeout(100);
  const ed = await page.evaluate(() => { const id = location.hash.slice(9); const m = MapLib.get(id); return { cell22: mapCell(m, 2, 2), npcs: m.npcs.map(n=>n.name+'@'+n.x+','+n.y), light: m.light, name: m.name }; });
  console.log('editor state:', JSON.stringify(ed));
  await page.click('#v-maps button:has-text("บันทึก")'); await page.waitForTimeout(200);
  await page.click('#v-maps button:has-text("เผยแพร่")'); await page.waitForTimeout(200);
  const saved = await page.evaluate(() => MapLib.loadLocal().map(m => ({ name: m.name, published: m.published, npcs: m.npcs.length })));
  console.log('local maps:', JSON.stringify(saved));
  await page.goto(url + '#maps'); await page.waitForTimeout(300);
  console.log('cards now:', (await page.$$('.mapcard')).length, 'published tag:', (await page.$$('.mapcard .tag.ok')).length);
  await page.click('button:has-text("ค้นหาแผนที่ที่เผยแพร่")'); await page.waitForTimeout(300);
  console.log('published tab cards:', (await page.$$('.mapcard')).length);
  // load into room
  const rid = await page.evaluate(() => loadLocalRooms()[0].id);
  await page.goto(url + '#room-' + rid); await page.waitForTimeout(400);
  const before = await page.evaluate(() => Table.room.tokens.length);
  await page.click('button:has-text("คลังแผนที่")'); await page.waitForTimeout(300);
  console.log('picker rows:', (await page.$$('#modal .gift')).length);
  await page.click('#modal .gift:has-text("ถ้ำทดสอบ") button:has-text("โหลด")'); await page.waitForTimeout(400);
  const loaded = await page.evaluate(() => { const r = Table.room; return { cell22: mapCell(r.map, 2, 2), light: r.light, tokens: r.tokens.length, npcHidden: r.tokens.filter(t=>t.kind==='npc').every(t=>t.hidden), seed: r.map.seed.slice(0,4), chat: Table.chat.find(m=>/โหลดแผนที่/.test(m.text)) && Table.chat.find(m=>/โหลดแผนที่/.test(m.text)).text }; });
  console.log('room after load:', JSON.stringify(loaded), 'tokens before', before);
  // ---- policy page ----
  await page.goto(url + '#policy'); await page.waitForTimeout(300);
  console.log('policy sections:', (await page.$$('.policy-sec')).length, 'toc:', (await page.$$('.policy-toc .toc-i')).length, 'h2:', await page.$eval('#v-policy h2', e => e.textContent.slice(0,40)));
  // ---- tutorial still 12 lessons, light mention ----
  const tut = await page.evaluate(() => ({ n: LESSONS.length, lines: LESSONS.reduce((a,l)=>a+l.lines.length,0), light: LESSONS.some(l => l.lines.some(x => /แสงในฉาก/.test(x[1]))) }));
  console.log('tutorial:', JSON.stringify(tut));
  await page.screenshot({ path: path.resolve(__dirname, '80-policy.png'), fullPage: false });
  await page.goto(url + '#maps'); await page.waitForTimeout(400); await page.screenshot({ path: path.resolve(__dirname, '81-maps.png') });
  console.log('errors', errors);
  await browser.close();
})();
