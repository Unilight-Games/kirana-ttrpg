// v1.22 (13 พ.ย. 2026)
//  A) ชุดเริ่มต้นเพิ่ม 14 ชุด (รวม 31) · แถว "และ" มาคู่กับทางเลือกในแถวบน · คาตานะย้ายลงระดับ 2 · อาวุธระดับ 1-2 เพิ่ม 16 ชิ้นในคลังไอเทม
//  B) ของหลายชิ้น (× n) เก็บน้ำหนักต่อชิ้น (เสบียง 5 หน่วยหนัก 2 กก. ไม่ใช่ 10) · เข็มขัดโซ่กับผ้าคาดเอวมาแทนเข็มขัดหนัง
//  C) Parry Dice ที่มีเงื่อนไขไม่บวกเอง · ดาบข้างกายคู่กริช กาตาร์ (AGI > STR) และบัคเลอร์คิดให้ · ช่องสวมของชิ้นใหม่
//  D) Non สั่ง: ผู้เล่นที่ไม่ใช่ผู้พัฒนาอัปภาพได้ไม่เกิน 2 MB ต่อภาพ
//  E) Non เคาะ: ระยะเคลื่อนที่ต่อ Action คือความเร็วของตัวละคร ไม่ได้คงที่ตามเขต (ข้อความกฎ ป้ายบนชีท จุดบอกช่องที่เดินถึง บันทึกการเดินระหว่างต่อสู้)
// แชทเก็บข้อความใหม่ไว้หน้าสุด (Table.chat.unshift)
// ใช้: node test/v122.js [โฟลเดอร์รูปทดสอบที่มี big.png (> 2 MB) และ small.png (< 2 MB)]
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const IMG = process.argv[2] || path.resolve(__dirname, 'img');
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const wait = (ms) => page.waitForTimeout(ms);
  const html = fs.readFileSync(path.resolve(__dirname, '../dist/index.html'), 'utf8');
  await page.goto(url); await wait(400);

  // ================= A) ชุดเริ่มต้นและคลังไอเทม =================
  const A = await page.evaluate(() => {
    const S = DATA.sets; const by = (n) => S.sets.find(s => s.nameEn === n);
    const duel = by('The Duelist'); const g = setItemGroups(duel); const mk = by('The Marksman');
    const pick = (set, picks) => chosenSetItems({ starterPicks: picks }, set).map(i => i.name);
    const names = ['The Duelist','The Sailor','The Templar','The Monster Hunter','The Frontier Rifleman','The Trench Raider','The Miner','The Levy','The Homesteader','The Stalker','The Tribal Warrior','The Pit Fighter','The Watchman','The Marksman'];
    const weapons = ['Pitchfork','Sledgehammer','Obsidian Knife','Boomerang','Leather Sling','Pike','Bayonet','Sword Cane','Sidesword','War Scythe','Ikakalaka','Bonesaw','Recurve Bow','Harpoon','Ricoch','Baladium Grenade'];
    const item = (en) => DATA.items.find(i => i.name.includes('(' + en + ')'));
    const kat = item('Katana');
    // ทุกไอเทมในชุดใหม่ต้องจับคู่กับคลังไอเทมได้ (ชื่อตรงกับ Item All)
    const unmatched = names.flatMap(n => by(n).items.map(i => ({ it: Object.assign({}, i, { cat: 'ชุดเริ่มต้น', name: cleanAltName(i.name).replace(/\s*×\s*\d+/, '') }), n }))).filter(x => !catalogTwin(x.it)).map(x => x.n + ': ' + x.it.name);
    const sumOpt = setOptionSummary(g[0].items[1]);
    return { n: S.sets.length, newOk: names.every(n => by(n)), rule1: S.rules[0], katRule: S.rules.some(r => /คาตานะ/.test(r)),
      duelGroups: g.length, duelOpts: g[0].items.length, duelBundle: g[0].items.map(o => (o.bundle || []).map(b => cleanAltName(b.name)).join('+')),
      duel0: pick(duel, {}), duel1: pick(duel, { 0: 1 }), duel2: pick(duel, { 0: 2 }), mk1: pick(mk, { 0: 1 }),
      sumOpt, weaponsIn: weapons.filter(w => item(w)).length, katSub: kat && kat.sub, katCat: kat && kat.cat,
      samuraiFlags: by('The Samurai').items[0].flags, unmatched,
      archTank: DATA.meta.archetypes.find(a => a.id === 'Tank').sets, glMan: DATA.glossary.Maneuver.text, glFar: DATA.glossary['Far Zone'].text };
  });
  ok('31 starter sets incl. the 14 new ones', A.n === 31 && A.newOk, A.n);
  ok('rule 1 says 31 sets and the katana exception is gone', /จาก 31 ชุด/.test(A.rule1) && !A.katRule, A.rule1);
  ok('Duelist: one choice group of 3 options, bundles on 2 and 3', A.duelOpts === 3 && A.duelBundle.join('|') === '|กริชรอนเดล (Rondel Dagger)|โล่บัคเลอร์ (Buckler)', A.duelBundle);
  ok('chosen items follow the pick and carry the bundle', A.duel0[0] === 'ดาบเซเบอร์/เรเปียร์ (Sabre/Rapier)' && !A.duel0.some(n => /Rondel|Buckler/.test(n)) && A.duel1.slice(0, 2).join('|') === 'ดาบข้างกาย (Sidesword)|กริชรอนเดล (Rondel Dagger)' && A.duel2.slice(0, 2).join('|') === 'ไม้เท้าซ่อนดาบ (Sword Cane)|โล่บัคเลอร์ (Buckler)' && A.duel1.length === A.duel0.length + 1, [A.duel0, A.duel1, A.duel2]);
  ok('Marksman bow branch brings arrows', A.mk1.slice(0, 2).join('|') === 'ธนูโค้งกลับ (Recurve Bow)|หัวศรมาตรฐาน (Standard Arrow) 1 ซอง', A.mk1);
  ok('option summary sums the bundle', A.sumOpt.name === 'ดาบข้างกาย (Sidesword) + กริชรอนเดล (Rondel Dagger)' && A.sumOpt.price === 19 && A.sumOpt.weight === 2.3 && A.sumOpt.reqs.length === 1 && A.sumOpt.reqs[0].label === 'STR 8', A.sumOpt);
  ok('16 new tier 1-2 weapons are in the item catalog', A.weaponsIn === 16, A.weaponsIn);
  ok('katana is a tier 2 melee weapon now', /ระดับอาวุธ 2/.test(A.katSub) && A.katCat === 'อาวุธประชิด' && A.samuraiFlags.length === 0, [A.katSub, A.samuraiFlags]);
  ok('every new set item matches an Item All entry', A.unmatched.length === 0, A.unmatched);
  ok('recommendation lists grew, first pick unchanged', A.archTank.join('|') === 'The Vanguard|The Templar|The Priest|The Miner', A.archTank);
  ok('glossary: Maneuver and Far Zone follow the speed ruling', /ความเร็วของตัวละคร/.test(A.glMan) && /ไม่ได้คงที่ตามเขต/.test(A.glMan) && !/Swift \+ 1 AP/.test(A.glFar), [A.glMan, A.glFar]);

  // วิซาร์ดขั้นที่ 8: ตัวเลือกแบบชุด + คำพูดของเนเมสไซอาร์
  await page.evaluate(() => { location.hash = '#wizard'; }); await wait(300);
  await page.evaluate(() => { startWizard(null); selectKin(W.char, 'solrin'); W.step = 7; W.char.starterSet = null; renderWizard(); }); await wait(400);
  const coach0 = await page.evaluate(() => document.body.innerText.includes('สามสิบเอ็ดชุด ทุกชุดได้ชุดยังชีพกับ 15 เกรฟเท่ากัน'));
  ok('Nemessiah counts thirty-one sets', coach0);
  await page.evaluate(() => { W.char.starterSet = 'The Duelist'; renderWizard(); }); await wait(400);
  const wz = await page.evaluate(() => ({ opts: [...document.querySelectorAll('.altpick .opt')].map(o => o.querySelector('b').textContent + ' | ' + o.querySelector('.dim').textContent),
    cards: document.querySelectorAll('.card.pick').length }));
  ok('wizard shows 31 set cards', wz.cards === 31, wz.cards);
  ok('wizard picker labels bundles with summed price and weight', wz.opts.length === 3 && wz.opts[1] === 'ดาบข้างกาย (Sidesword) + กริชรอนเดล (Rondel Dagger) | ราคา 19 · 2.3 กก.' && wz.opts[2] === 'ไม้เท้าซ่อนดาบ (Sword Cane) + โล่บัคเลอร์ (Buckler) | ราคา 21 · 1.9 กก.', wz.opts);
  await page.evaluate(() => { W.char.starterSet = 'The Marksman'; W.char.starterPicks = { 0: 1 }; renderWizard(); }); await wait(400);
  const coachW = await page.evaluate(() => /น้ำหนัก 6\.9 กิโลกรัม/.test(document.body.innerText));
  ok('coach reads the weight of the chosen branch', coachW);

  // ================= B) น้ำหนักต่อชิ้น เข็มขัด และช่องสวม =================
  const B = await page.evaluate(() => {
    const mk = (set, picks, kin) => { const c = Object.assign(newChar(), { id: 'b' + set.replace(/\W/g, ''), name: 'x', kin: kin || 'solrin', size: 'Medium', starterSet: set, starterPicks: picks || {} }); const d = compute(c); ensureSheetState(c, d); return c; }; // ensureSheetState สวมของให้เองครั้งแรก
    const wan = mk('The Wanderer'); const ration = wan.inventory.find(r => /Ration/.test(r.name));
    const pit = mk('The Pit Fighter'); const con = mk('The Convict'); const tr = mk('The Trench Raider'); const rif = mk('The Frontier Rifleman'); const st = mk('The Stalker'); const tw = mk('The Tribal Warrior');
    const belt = (c) => [...c.inventory, ...Object.values(c.equip)].some(r => /Simple Leather Belt/.test(r.name));
    const old = { inventory: [{ name: 'เสบียง (Ration)', qty: 5, weight: 2 }, { name: 'น้ำมนตร์ (Holy Water)', qty: 2, weight: 1 }, { name: 'เสบียง (Ration)', qty: 1, weight: 0.4 }], equip: { weapon1: { name: 'ขวานเล็ก (Hatchet)', effect: 'x', weight: 2 } } };
    const ch = migrateStackWeights(old); const again = migrateStackWeights(old);
    return { ration: ration && [ration.qty, ration.weight], bag: Math.round(listWeight(wan.inventory) * 100) / 100,
      pitBelt: belt(pit), conBelt: belt(con), pitWaist: pit.equip.waist && pit.equip.waist.name, pitHands: pit.equip.hands && pit.equip.hands.name, pitW1: pit.equip.weapon1 && pit.equip.weapon1.name,
      molotov: (tr.inventory.find(r => /Molotov/.test(r.name)) || {}), rifW: [rif.equip.weapon1 && rif.equip.weapon1.name, rif.equip.weapon2 && rif.equip.weapon2.name],
      stalkW: [st.equip.weapon1 && st.equip.weapon1.name, st.equip.weapon2 && st.equip.weapon2.name], darts: st.inventory.filter(r => /Dart/.test(r.name)).length,
      ricoch: (tw.inventory.find(r => /Ricoch/.test(r.name)) || {}), twW1: tw.equip.weapon1 && tw.equip.weapon1.name,
      migr: [ch, again, old.inventory.map(r => r.weight).join(','), old.equip.weapon1.weight] };
  });
  ok('rations: 5 × 0.4 kg (not 5 × 2 kg)', B.ration && B.ration[0] === 5 && B.ration[1] === 0.4, B.ration);
  ok('wanderer bag weight is realistic', B.bag < 4, B.bag);
  ok('belt swap: Pit Fighter and Convict get no leather belt', !B.pitBelt && !B.conBelt, [B.pitBelt, B.conBelt]);
  ok('Pit Fighter wears sash, hand wraps and katar', /Brawler's Sash/.test(B.pitWaist) && /Hand Wrap/.test(B.pitHands) && /Katar/.test(B.pitW1), [B.pitWaist, B.pitHands, B.pitW1]);
  ok('molotov stack: 2 × 0.2 kg', B.molotov.qty === 2 && B.molotov.weight === 0.2, B.molotov);
  ok('musket goes to the weapon slot, bayonet second', /Mana Musket/.test(B.rifW[0] || '') && /Bayonet/.test(B.rifW[1] || ''), B.rifW);
  ok('darts stay in the bag, blowgun and knife are the weapons', /Blowgun/.test(B.stalkW[0] || '') && /Obsidian/.test(B.stalkW[1] || '') && B.darts === 2, [B.stalkW, B.darts]);
  ok('ricoch stack of 3 at 0.3 kg each, sword is the main weapon', /Ikakalaka/.test(B.twW1 || '') && (B.ricoch.qty + (/Ricoch/.test(B.twW1 || '') ? 1 : 0)) >= 2 && B.ricoch.weight === 0.3, [B.twW1, B.ricoch]);
  ok('old characters: stack totals become unit weights once', B.migr[0] === true && B.migr[1] === false && B.migr[2] === '0.4,0.5,0.4' && B.migr[3] === 1, B.migr);

  // ================= C) Parry Dice =================
  const C = await page.evaluate(() => {
    const get = (en) => { const i = DATA.items.find(x => x.name.includes('(' + en + ')')); return { name: i.name, effect: i.effect, weight: i.weight }; };
    const run = (equip, extra) => { const c = Object.assign(newChar(), { kin: 'solrin', size: 'Medium' }, extra || {}); c.equip = equip; recalcParry(c); return c.current.parryBonus; };
    return { ssDagger: run({ weapon1: get('Sidesword'), weapon2: get('Rondel Dagger') }), ssAlone: run({ weapon1: get('Sidesword') }), ssMachete: run({ weapon1: get('Sidesword'), weapon2: get('Machete') }),
      ssShield: run({ weapon1: get('Sidesword'), weapon2: get('Rondel Dagger'), shield: get('Heater Shield') }), cutlass: run({ weapon1: get('Hanger/Cutlass') }), sabre: run({ weapon1: get('Sabre/Rapier') }),
      buckler: run({ weapon1: get('Hunting Knife'), shield: get('Buckler') }), katarStr: run({ weapon1: get('Katar') }), katarAgi: run({ weapon1: get('Katar') }, { extra: { AGI: 6 } }),
      slots: [itemSlot('ปืนคาบศิลามานา (Mana Musket)', get('Mana Musket').effect), itemSlot("ผ้าพันมือนักสู้ (Brawler's Hand Wrap)", 'Armor 1/2 (Blunt) ที่มือ'), itemSlot("ผ้าคาดเอวของนักสู้ (Brawler's Sash)", 'x'), itemSlot('ลูกดอกมาตรฐาน (Standard Dart) 1 ซอง', '1 PDMG (Piercing)'), itemSlot('ปืนเป่าลูกดอก (Blowgun)', '0 PDMG (Piercing)')] };
  });
  ok('sidesword + dagger in the off hand: +1 Parry Dice', C.ssDagger === 1 && C.ssAlone === 0 && C.ssMachete === 0, [C.ssDagger, C.ssAlone, C.ssMachete]);
  ok('sidesword bonus does not stack with a shield', C.ssShield === 1, C.ssShield);
  ok('cutlass bonus needs 2 enemies, so not automatic', C.cutlass === 0, C.cutlass);
  ok('sabre and buckler keep +1', C.sabre === 1 && C.buckler === 1, [C.sabre, C.buckler]);
  ok('katar: +1 only when AGI is higher than STR', C.katarAgi === 1 && C.katarStr === 0, [C.katarStr, C.katarAgi]);
  ok('slots: musket weapon, hand wrap hands, sash waist, darts none, blowgun weapon', C.slots.join(',') === 'weapon,hands,waist,,weapon', C.slots);

  // ================= D) เพดานไฟล์ภาพ 2 MB =================
  const D = await page.evaluate(() => { const r = {}; Store.isDevUid = false; Store.isDevIp = false; r.note = imgUploadNote(); r.big = imgUploadBlocked({ size: 2 * 1024 * 1024 + 1 }, null); r.edge = imgUploadBlocked({ size: 2 * 1024 * 1024 }, null);
    Store.isDevIp = true; r.devIp = imgUploadBlocked({ size: 9e6 }, null); r.devNote = imgUploadNote(); Store.isDevIp = false; Store.isDevUid = true; r.devUid = imgUploadBlocked({ size: 9e6 }, null); Store.isDevUid = false; return r; });
  ok('2 MB cap: over blocked, exactly 2 MiB allowed, developers exempt', D.big === true && D.edge === false && D.devIp === false && D.devUid === false && D.note === 'ไฟล์ภาพไม่เกิน 2 MB' && D.devNote === '', D);
  const big = path.join(IMG, 'big.png'), small = path.join(IMG, 'small.png');
  if (fs.existsSync(big) && fs.existsSync(small)){
    await page.evaluate(() => { const K = window.__kirana; K.Store.upsert(Object.assign(newChar(), { id: 'pic', name: 'รูป', kin: 'solrin', size: 'Medium', done: true, step: 7, starterSet: 'The Sailor' })); });
    await page.goto(url + '#sheet-pic'); await wait(500);
    const inp = '.box[data-k="portrait"] input[type=file]';
    const hint = await page.evaluate(() => (document.querySelector('.portrait') || {}).title || '');
    ok('portrait hint names the cap', /ไม่เกิน 2 MB/.test(hint), hint);
    await page.setInputFiles(inp, big); await wait(700);
    const r1 = await page.evaluate(() => ({ portrait: !!Store.get('pic').portrait, toast: document.querySelector('#toast').textContent }));
    ok('player: 3.5 MB portrait refused with a toast', !r1.portrait && /เกินเพดาน 2 MB/.test(r1.toast) && /3\.5 MB/.test(r1.toast), r1);
    await page.setInputFiles(inp, small); await wait(900);
    const r2 = await page.evaluate(() => !!Store.get('pic').portrait);
    ok('player: small portrait accepted', r2);
    await page.evaluate(() => { const c = Store.get('pic'); c.portrait = null; Store.upsert(c); }); await page.goto(url + '#home'); await wait(200); await page.goto(url + '#sheet-pic'); await wait(500);
    await page.evaluate(() => { Store.isDevUid = true; });
    await page.setInputFiles(inp, big); await wait(1200);
    const r3 = await page.evaluate(() => { const v = !!Store.get('pic').portrait; Store.isDevUid = false; return v; });
    ok('developer: 3.5 MB portrait accepted', r3);
  } else console.log('ข้ามการอัปไฟล์จริง: ไม่พบ big.png/small.png ใน', IMG);
  ok('map and NPC image inputs check the cap', /imgFile\.onchange = async \(e\)=>\{ const f = e\.target\.files\[0\]; if \(!f\) return; if \(imgUploadBlocked\(f, e\.target\)\) return; try \{ const res = await shrinkMapImage/.test(html) && /if \(imgUploadBlocked\(f, e\.target\)\) return; try \{ const res = await shrinkTokenImage/.test(html));

  // ================= E) ระยะเคลื่อนที่ = ความเร็วของตัวละคร =================
  const E0 = await page.evaluate(() => { const c = Object.assign(newChar(), { kin: 'solrin', size: 'Medium', extra: { AGI: 4 } }); const d = compute(c); const ms = moveSpeed(c, d);
    const pr = moveSpeed(c, d, [{ id: 'Prone' }]); const ex = moveSpeed(c, d, [{ id: 'Exhaustion', lv: 2 }]); const dw = moveSpeed(Object.assign(newChar(), { kin: 'handerlaw-dwarves', size: 'Small' }), null);
    return { agi: d.mod.AGI, ms, pr, ex, dw, txt: moveSpeedText(ms, true) }; });
  ok('speed: Dash = kin Dash, Run = kin run + AGI Mod', E0.ms.dash === 2 && E0.ms.run === 5 + E0.agi && E0.ms.dashCells === 1 && E0.ms.runCells === Math.floor((5 + E0.agi) / 2), E0);
  ok('prone crawls 1 m, exhaustion 2 halves', E0.pr.dash === 1 && E0.pr.run === null && E0.pr.dashCells === 0 && E0.ex.dash === 1 && E0.ex.run === (5 + E0.agi) / 2, [E0.pr, E0.ex]);
  ok('dwarf: Dash 1 m (no full cell), Run 3 m + AGI', E0.dw.dash === 1 && E0.dw.dashCells === 0, E0.dw);
  ok('speed text', /^Dash 2 ม\. \(1 ช่อง\) ใช้ 1 Swift · Run \d+ ม\. \(\d+ ช่อง\) ใช้ 1 Swift \+ 1 AP$/.test(E0.txt), E0.txt);

  await page.evaluate(() => { const K = window.__kirana; K.Store.upsert(Object.assign(newChar(), { id: 'mv', name: 'นักวิ่ง', kin: 'solrin', size: 'Medium', extra: { AGI: 4 }, done: true, step: 7, starterSet: 'The Sailor' })); });
  await page.goto(url + '#sheet-mv'); await wait(500);
  const sheetSpeed = await page.evaluate(() => { const k = [...document.querySelectorAll('.idgrid .k')].find(k => /Speed/.test(k.textContent)); return k ? k.nextElementSibling.textContent : ''; });
  ok('sheet shows Dash and Run per Maneuver', /^Dash 2 ม\. ใช้ 1 Swift · Run \d+ ม\. ใช้ 1 Swift \+ 1 AP$/.test(sheetSpeed), sheetSpeed);
  await page.goto(url + '#table'); await wait(400);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้องวิ่ง'); await page.click('button:has-text("สร้างห้อง")'); await wait(500);
  const E1 = await page.evaluate(() => {
    const r = Table.room;
    r.tokens = []; let t = { id: 'tk-mv', charId: 'mv', ownerId: Store.me, name: 'นักวิ่ง', x: 5, y: 5, hp: 10, conds: [] }; r.tokens.push(t);
    for (let y = 0; y < 20; y++) for (let x = 0; x < 20; x++) setMapCell(r.map, x, y, '.');
    t.x = 5; t.y = 5; setMapCell(r.map, 6, 5, '#'); setMapCell(r.map, 4, 5, 'w'); r.light = 'bright'; Table.save();
    Table.sel = t.id; renderTable();
    const cls = (c) => [...document.querySelectorAll('.gridmap .cell.' + c)].map(e => e.dataset.x + ',' + e.dataset.y);
    const ms = tokenMoveSpeed(t); const dash = cls('mv-dash'), run = cls('mv-run');
    const row = (document.querySelector('.moverow') || {}).textContent || '';
    t.conds = [{ id: 'Prone', at: Date.now() }]; renderTable(); const prone = cls('mv-dash').length + cls('mv-run').length; t.conds = []; renderTable();
    return { ms, dash, run, row, prone };
  });
  ok('reach dots: 6 dash cells (wall blocked, shallow water costs 2)', E1.dash.length === 6 && !E1.dash.includes('6,5') && !E1.dash.includes('4,5') && E1.run.includes('4,5') && !E1.run.includes('6,5'), [E1.dash, E1.ms]);
  ok('run dots reach runCells away and no further', E1.ms.runCells >= 2 && E1.run.every(k => { const [x, y] = k.split(',').map(Number); return Math.max(Math.abs(x - 5), Math.abs(y - 5)) <= E1.ms.runCells; }) && E1.run.some(k => { const [x, y] = k.split(',').map(Number); return Math.max(Math.abs(x - 5), Math.abs(y - 5)) === E1.ms.runCells; }), [E1.ms.runCells, E1.run.length]);
  ok('token panel shows movement per Maneuver', /🏃 เคลื่อนที่: Dash 2 ม\. \(1 ช่อง\) ใช้ 1 Swift · Run \d+ ม\. \(\d+ ช่อง\)/.test(E1.row), E1.row);
  ok('prone token shows no reach dots', E1.prone === 0, E1.prone);
  const E2 = await page.evaluate(() => {
    const r = Table.room; const t = r.tokens.find(x => x.charId === 'mv'); r.enc = Object.assign(r.enc || {}, { active: true, order: [t.id], turnIdx: 0 }); t.x = 5; t.y = 5; Table.save();
    tryMoveToken(r, t, 5, 6, true, null); const a = Table.chat.find(m => m.kind === 'sys').text;
    tryMoveToken(r, t, 5, 6 + 2, true, null); const b = Table.chat.find(m => m.kind === 'sys').text;
    tryMoveToken(r, t, 5, 18, true, null); const c = Table.chat.find(m => m.kind === 'sys').text;
    r.enc.active = false; tryMoveToken(r, t, 5, 17, true, null); const d = Table.chat.find(m => m.kind === 'sys').text;
    return [a, b, c, d]; });
  ok('combat move log: Dash, Run, too far', /ระยะ Dash/.test(E2[0]) && /ระยะ Run/.test(E2[1]) && /ไกลกว่า 1 Maneuver/.test(E2[2]) && !/ระยะ|Maneuver/.test(E2[3]), E2);
  const helpTxt = await page.evaluate(() => document.body.innerText);
  ok('room help uses speed, not fixed zone costs', /ระยะที่เดินได้ต่อ 1 Maneuver คือความเร็วของตัวละคร/.test(helpTxt) && !/จากใกล้เคียงเข้าปะทะใช้ 1 Swift/.test(helpTxt));
  await page.goto(url + '#rules'); await wait(300);
  const rules = await page.evaluate(() => document.body.innerText);
  ok('rules page: movement by speed, far zone has no fixed cost', /ระยะต่อหนึ่งครั้งคือความเร็วของตัวละคร/.test(rules) && !/เคลื่อนที่ไปต้องใช้ Swift \+ 1 AP/.test(rules) && !/วิ่งเข้าร่วมวงได้ทันที/.test(rules), rules.slice(0, 80));
  ok('tutorial line and figure follow the ruling', html.includes('เดินได้ไกลแค่ไหนต่อหนึ่ง Maneuver ขึ้นกับความเร็วของเจ้าเอง') && !html.includes('จากใกล้เคียงเข้าปะทะใช้หนึ่ง Swift') && html.includes("figTitle('ระยะต่อหนึ่ง Maneuver = ความเร็วของตัวละคร')"));

  console.log(`v122: ${pass} passed, ${fail} failed`);
  console.log('errors', errors);
  await browser.close();
  process.exit(fail || errors.length ? 1 : 0);
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
