// v1.22.1 (13 พ.ย. 2026) Non สั่ง: "ลบ Sling Shot เปลี่ยนเป็น สลิงหนัง (Leather Sling)"
//  A) คลังไอเทมกับชุดเริ่มต้นไม่มีหนังยางเหวี่ยงหินแล้ว · The Wanderer ได้สลิงหนัง หมึกกับปากกาขนนก และกระดาษ 1 แผ่น (มูลค่า 50) · หมายเหตุของ The Hunter ชี้สลิงหนัง
//  B) ตัวละครเดิมที่ถือหนังยางเหวี่ยงหินได้สลิงหนังแทน: ชื่อ ข้อความเอฟเฟกต์ และน้ำหนัก 0.3 → 0.2 กก. (น้ำหนักหรือข้อความที่ผู้เล่นแก้เองไม่ถูกแตะ)
//  C) สำเนาชีทของผู้เล่นคนอื่นในห้อง (หน้าต่างค่าการต่อสู้ของ GM) ย้ายชื่อในหน่วยความจำด้วย
// ใช้: node test/v1221.js
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  await page.goto(url); await page.waitForTimeout(400);

  const R = await page.evaluate(() => {
    const SS = 'หนังยางเหวี่ยงหิน (Sling Shot)', LS = 'สลิงหนัง (Leather Sling)';
    const by = (n) => DATA.sets.sets.find(s => s.nameEn === n);
    const wan = by('The Wanderer'), hun = by('The Hunter'), cat = DATA.items.find(i => i.name === LS);
    const txt = JSON.stringify(DATA.items) + JSON.stringify(DATA.sets);
    const r = { oldLeft: /Sling Shot|หนังยางเหวี่ยงหิน/.test(txt), cat: cat && [cat.price, cat.weight, cat.sub],
      ranged: DATA.items.filter(i => i.cat === 'อาวุธระยะไกล').length,
      catalog: itemCatalog().filter(i => /Sling Shot|หนังยางเหวี่ยงหิน/.test(i.name)).length,
      wanItems: wan.items.map(i => cleanAltName(i.name)), wanTotal: [wan.total, wan.totalWeight], wanDesc: wan.desc, hunNote: hun.notes,
      ren: [DATA.meta.itemRenames[SS], JSON.stringify(DATA.meta.itemRenameWeights)] };
    // ตัวละครใหม่ชุด The Wanderer
    const nw = Object.assign(newChar(), { id: 'nw', name: 'ใหม่', kin: 'solrin', size: 'Medium', starterSet: 'The Wanderer', starterPicks: {} });
    ensureSheetState(nw, compute(nw));
    const nwAll = [...nw.inventory, ...Object.values(nw.equip)];
    const sl = nwAll.find(o => o.name === LS);
    r.newSling = sl && [sl.weight, sl.effect === wan.items.find(i => i.name === LS).effect];
    r.newKit = ['หมึกและปากกาขนนก (Ink & Quill)', 'กระดาษ (Paper)'].map(n => !!nwAll.find(o => o.name === n));
    r.newW1 = nw.equip.weapon1 && nw.equip.weapon1.name;
    // ตัวละครเดิม (v1.22): หนังยางเหวี่ยงหินจากชุดในกระเป๋า อีกอันสวมในมือ (ข้อความจากคลัง) และอีกอันที่ผู้เล่นแก้น้ำหนักกับข้อความเอง
    const setTxt = '1 Might (Blunt), Armor Penetrate · หินหมดหาใหม่ได้ด้วย PER Check (DC 7) (Swift)';
    const catTxt = '1 Might (Blunt), Armor Penetrate. Ammo (หิน/กระสุนดินเผา): หากไม่มีกระสุน สามารถหาหินที่เหมาะสม จากสภาพแวดล้อมที่เอื้ออำนวยได้ด้วยการทอย PER Check (DC 7) (Swift Action) · ชนิด: อาวุธปา';
    const oldTxt = '1 Might (Blunt), Armor Penetrate · หินหมดหาใหม่ได้ด้วย 7 PER Check (Swift)'; // ข้อความของชุดรุ่นก่อน v1.20
    const mkOld = (id) => Object.assign(newChar(), { id, name: 'เก่า', kin: 'solrin', size: 'Medium', starterSet: 'The Wanderer', starterPicks: {}, equipAuto: true,
      inventory: [{ name: SS, effect: setTxt, qty: 1, weight: 0.3 }, { name: SS, effect: 'หนังยางของพ่อ', qty: 1, weight: 0.5 }, { name: SS, effect: oldTxt, qty: 2, weight: 0.3 }],
      equip: { weapon2: { name: SS, effect: catTxt, weight: 0.3 } } });
    const old = mkOld('old'); ensureSheetState(old, compute(old));
    const all = [...old.inventory, ...Object.values(old.equip)];
    const find = (pred) => all.find(pred) || {};
    const setNew = wan.items.find(i => i.name === LS).effect;
    r.old = { left: all.filter(o => o.name === SS).length, fromSet: find(o => o.qty === 1 && o.effect === setNew).weight, fromCat: (old.equip.weapon2 || {}),
      custom: find(o => o.effect === 'หนังยางของพ่อ'), older: find(o => o.qty === 2), setNew, catNew: cat.effect };
    // ครั้งที่สองไม่มีอะไรต้องแก้
    r.again = migrateNames(old);
    // C) สำเนาชีทของคนอื่นในห้อง: Store.me ไม่ใช่เจ้าของ
    const meBefore = Store.me; Store.me = 'gm-uid';
    const other = mkOld('other'); other.ownerId = 'player-uid';
    let err = null; try { combatPanel(other, { id: 't1', charId: 'other' }, true); } catch (e) { err = String(e); }
    Store.me = meBefore;
    r.room = { err, names: [...other.inventory, ...Object.values(other.equip)].map(o => o.name + '@' + o.weight) };
    return r;
  });
  const LS = 'สลิงหนัง (Leather Sling)';
  ok('no Sling Shot left in items or sets', R.oldLeft === false && R.catalog === 0, [R.oldLeft, R.catalog]);
  ok('Leather Sling stays a tier 1 ranged weapon at 3 gold 0.2 kg', R.cat && R.cat[0] === '3 เกรฟ' && R.cat[1] === 0.2 && /ระดับอาวุธ 1/.test(R.cat[2]), R.cat);
  ok('ranged weapon count drops by one (21 → 20)', R.ranged === 20, R.ranged);
  ok('Wanderer: staff, leather sling, boots, ring, ropes, ink & quill, paper', R.wanItems.join('|') === "พลองไม้ (Quarter Staff)|สลิงหนัง (Leather Sling)|รองเท้าบูทนักเดินทาง (Traveler's Boots)|แหวนเข็มทิศ (Compass Ring)|เชือก (Ropes)|หมึกและปากกาขนนก (Ink & Quill)|กระดาษ (Paper)", R.wanItems);
  ok('Wanderer value 50, items 4.6 kg', String(R.wanTotal[0]) === '50' && String(R.wanTotal[1]) === '4.6', R.wanTotal);
  ok('Wanderer description and Hunter note name the leather sling', /สลิงหนัง/.test(R.wanDesc) && /สลิงหนัง \(Leather Sling\)/.test(R.hunNote), [R.wanDesc, R.hunNote]);
  ok('rename table: Sling Shot → Leather Sling, 0.3 → 0.2 kg', R.ren[0] === LS && R.ren[1] === JSON.stringify({ 'หนังยางเหวี่ยงหิน (Sling Shot)': [0.3, 0.2] }), R.ren);
  ok('new Wanderer gets the sling at 0.2 kg with the set text, plus ink and paper', R.newSling && R.newSling[0] === 0.2 && R.newSling[1] === true && R.newKit.every(Boolean), [R.newSling, R.newKit]);
  ok('new Wanderer still holds the staff first', /Quarter Staff/.test(R.newW1 || ''), R.newW1);
  ok('old character: every Sling Shot renamed', R.old.left === 0, R.old.left);
  ok('old character: set copy gets the new set text and 0.2 kg', R.old.fromSet === 0.2, R.old);
  ok('old character: equipped copy gets the catalog text and 0.2 kg', R.old.fromCat.name === LS && R.old.fromCat.effect === R.old.catNew && R.old.fromCat.weight === 0.2, R.old.fromCat);
  ok('old character: pre-v1.20 set text also moves, per-unit weight fixed for a stack of 2', R.old.older.name === LS && R.old.older.effect === R.old.setNew && R.old.older.weight === 0.2, R.old.older);
  ok('old character: player-edited copy keeps its own text and weight', R.old.custom.name === LS && R.old.custom.effect === 'หนังยางของพ่อ' && R.old.custom.weight === 0.5, R.old.custom);
  ok('migration runs once', R.again === false, R.again);
  ok('GM view of another player\'s copy shows the leather sling', !R.room.err && R.room.names.every(n => n.startsWith(LS + '@')) && R.room.names.filter(n => n.endsWith('@0.2')).length === 3, R.room);

  ok('no page errors', errors.length === 0, errors);
  console.log(`v1.22.1: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
