// v1.31.1 (Non เคาะ 17 พ.ย. 2026): "เรื่อง Tripod Gait เอาตามที่คุณแนะนำได้เลยครับ"
//  เนโครบัคเดินด้วยสี่ขา ยกทีละข้างให้อีกสามขาค้ำ · Alternating Tripod Gait เป็นท่าวิ่งหกขาตอนวางขาคู่หน้าลงพื้น
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 })).newPage();
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail).slice(0, 1500) : ''); } };
  await page.goto(url); await page.waitForTimeout(500);
  const T = await page.evaluate(() => LORE.necrobug.body.map(b => typeof b[1] === 'string' ? b[1] : '').find(s => s.includes('Tripod Gait')) || '');
  ok('walking: one leg at a time with three bracing', T.includes('ยามเดินจะยกขาทีละข้างโดยมีอีกสามขาค้ำพื้นไว้เสมอ') && T.includes('ใช้ขาทั้งสี่ถ่ายน้ำหนัก'), T);
  ok('tripod gait belongs to the six-limb sprint', T.includes('วางขาคู่หน้าลงพื้น แล้ววิ่งด้วยหกขาแบบ Alternating Tripod Gait') && T.indexOf('Tripod Gait') > T.indexOf('เมื่อเร่งความเร็ว') && !T.includes('ขาหลายข้างสลับกันแบบ'), T);
  await page.goto(url + '#lore-necrobug'); await page.waitForTimeout(400);
  const page_ = await page.evaluate(() => document.querySelector('#v-lore').textContent);
  ok('the Necrobug page shows the new gait text', page_.includes('ยกขาสลับกันทีละสามขา') && page_.includes('อีกสามขาค้ำพื้น'), null);
  ok('no page errors', errors.length === 0, errors);
  console.log(`v1311: ${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
