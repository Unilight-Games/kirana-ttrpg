const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('console', m => { if (m.type()==='warning' || m.type()==='error') errors.push(m.type()+' '+m.text()); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url + '#create'); await page.waitForTimeout(500);
  // render every figure type into a grid for review
  const names = await page.evaluate(() => Object.keys(FIGS));
  console.log('figures:', names.length);
  const missing = await page.evaluate(() => { const out=[]; for (const k of Object.keys(FIGS)){ const n = vnFigure(k); if (!n) out.push(k); } return out; });
  console.log('failed to render:', missing);
  // walk all lines of all chapters, verifying each referenced fig renders, and shoot a few
  const shots = { 'dice':2, 'stats':1, 'pers':1, 'create':1, 'sheet':0, 'combat':3, 'attack':4, 'mind':0, 'ip':3, 'online':3 };
  for (let ch=0; ch<12; ch++){
    const n = await page.evaluate((ch)=>{ Tutor.ch=ch; Tutor.ln=0; tutorSave(); renderTutorial(); return LESSONS[ch].lines.length; }, ch);
    for (let ln=0; ln<n; ln++){
      await page.evaluate((ln)=>{ Tutor.ln=ln; tutorSave(); renderTutorial(); }, ln);
      const id = await page.evaluate(()=>LESSONS[Tutor.ch].id);
      if (shots[id] === ln){ await page.waitForTimeout(1500); await page.screenshot({ path: `test/6${ch}-fig-${id}.png` }); }
    }
  }
  await page.setViewportSize({ width: 400, height: 800 }); await page.evaluate(()=>{ Tutor.ch=6; Tutor.ln=3; renderTutorial(); }); await page.waitForTimeout(1500); await page.screenshot({ path: 'test/69-fig-mobile.png' });
  console.log('errors', errors.filter(e=>!/ERR_FILE|ERR_TUNNEL/.test(e)));
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
