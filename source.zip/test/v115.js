// v1.15 (ผู้ใช้เคาะ 11 พ.ย. 2026 ข้อ 1 ถึง 7):
// 1) ทอยโจมตี: Advantage ผู้โจมตีเลือก 2 ลูก · Disadvantage ฝ่ายรับเลือกให้ · Parry สูงสุด 4 ลูก · อาวุธที่ STR ไม่ถึงติด Disadvantage
// 2) การพัก (Recovery = ค่าสูงสุด) · รักษาแผล · Toughness ติดลบและตารางบาดแผลฉกรรจ์ · เกราะรับหมดไม่เสีย Toughness
// 3) ตำแหน่งที่โดน: แขนซ้าย 10 ขาซ้าย 5   4) เขตไกลไม่ติด Disadvantage   5) Fleshforge ห้ามกระสุน ลูกศร อุปกรณ์เวท ของเกิน 30 เกรฟ
// 6) Twinborn: Toughness และเกราะแยกร่าง สภาวะทางจิตใจติดพร้อมกัน   7) Perfect Evade สำเร็จเสมอ · ตัวปรับ CV ไม่ขยับตำแหน่ง
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('dialog', d => d.accept());
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  let pass = 0, fail = 0;
  const ok = (name, cond, detail) => { if (cond) pass++; else { fail++; console.log('FAIL:', name, detail !== undefined ? JSON.stringify(detail) : ''); } };
  const unlock = () => page.evaluate(() => { Table.rolling = false; Table.rollLock = null; updateRollLockUI(); });
  const shot = async (name) => { await page.evaluate(() => { if (typeof DiceShow !== 'undefined') DiceShow.clear(); }); await page.waitForTimeout(150); await page.screenshot({ path: path.resolve(__dirname, name) }); };
  await page.goto(url); await page.waitForTimeout(400);

  // ================= A) ข้อมูลกฎ =================
  const data = await page.evaluate(() => {
    const all = JSON.stringify(DATA); const G = GLOSSARY; const g = (k) => (G[k] || {}).text || '';
    const know = (id) => DATA.knowledge.find(x => x.id === id);
    const ff = DATA.skills.find(x => x.nameEn === 'Fleshforge');
    const tw = DATA.kins.find(k => k.id === 'lunaryn').specialChildhood.find(x => x.nameEn === 'Twinborn');
    const W = DATA.meta.wounds || {};
    return {
      hit: [2,3,4,5,6,7,8,9,10,11,12].map(n => hitPart(n)).join(','),
      metaHit: DATA.meta.hitLocation,
      gHit: g('Hit Location'), gAdv: g('Advantage'), gDis: g('Disadvantage'), gRec: g('Recovery'), gTreat: g('Treat Wound'), gFar: g('Far Zone'), gEvade: g('Evade'), gParry: g('Parry'), gTough: g('Toughness'), gRange: g('Range Attack'), gShort: g('Short Rest'), gLong: g('Long Rest'), gPerfect: g('Perfect Parry / Perfect Evade') || g('Perfect Parry'),
      oldPenalty: /-1 CV Per less/.test(all), strDis: (all.match(/หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage/g) || []).length,
      strDisItems: DATA.items.filter(i => /หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage/.test(i.effect || '')).length,
      rangeLv: [0,1,2,3].map(l => /นับทุก 10 เมตรที่เริ่มนับ/.test(know('range').levels[l].text)),
      medical1: know('medical').levels[1].text, surgical: (know('medical').levels[1].proficiencies.find(p => p.name === 'Surgical Trainee') || {}).text || '',
      ffText: ff.extra.join(' '), twText: tw.text,
      wounds: Object.fromEntries(Object.entries(W).map(([k, rows]) => [k, rows.flatMap(r => r.faces).sort().join('')])),
      woundKinds: Object.keys(WOUND_KIND).map(p => p + ':' + woundRows(p).length).join(','),
      torn: (W.arm || []).find(r => /Torn Ligaments/.test(r.name)) || null,
    };
  });
  ok('hit map', data.hit === 'head,head,armR,legL,torso,torso,torso,legR,armL,head,head', data.hit);
  ok('meta hit text', /\[10 = แขนซ้าย\] \[5 = ขาซ้าย\]/.test(data.metaHit) && /แขนเลขคู่ ขาเลขคี่/.test(data.metaHit), data.metaHit);
  ok('glossary hit', /\[10 = แขนซ้าย\] \[5 = ขาซ้าย\]/.test(data.gHit) && /Focus \(Precise\)/.test(data.gHit), data.gHit);
  ok('glossary advantage', /ผู้โจมตีเลือก 2 ลูกเอง/.test(data.gAdv), data.gAdv);
  ok('glossary disadvantage', /ฝ่ายรับเป็นผู้เลือก 2 ลูกให้/.test(data.gDis) && /GM เลือก/.test(data.gDis), data.gDis);
  ok('glossary recovery', /Max HP/.test(data.gRec) && /Max MP/.test(data.gRec), data.gRec);
  ok('glossary treat wound', /Medical Check \(DC 8\)/.test(data.gTreat) && /Surgical Trainee เป็น 2 หน่วย/.test(data.gTreat), data.gTreat);
  ok('glossary far zone', /ไม่ติด Disadvantage เพราะระยะ/.test(data.gFar) && /นับทุก 10 เมตรที่เริ่มนับ/.test(data.gFar), data.gFar);
  ok('glossary evade', /นับว่าหลบสำเร็จเสมอ/.test(data.gEvade), data.gEvade);
  ok('glossary parry', /สูงสุด 4 ลูก/.test(data.gParry) && /Focus \(Precise\)/.test(data.gParry), data.gParry);
  ok('glossary toughness', /ติดลบถึงค่าเต็ม/.test(data.gTough) && /ไม่เสีย Toughness/.test(data.gTough), data.gTough);
  ok('glossary range attack', /ที่กำบัง/.test(data.gRange) && !/เขตไกล.{0,12}Disadvantage/.test(data.gRange), data.gRange);
  ok('glossary rests', /ครึ่งหนึ่งของค่าสูงสุด/.test(data.gShort) && /ฟื้น HP และ MP เต็ม/.test(data.gLong) && /Treat Wound/.test(data.gLong), [data.gShort, data.gLong]);
  ok('glossary perfect evade', /Perfect Evade นับว่าหลบสำเร็จเสมอ/.test(data.gPerfect), data.gPerfect);
  ok('STR penalty → Disadvantage on 11 weapons', !data.oldPenalty && data.strDisItems === 11, [data.oldPenalty, data.strDisItems, data.strDis]);
  ok('range rounding text', data.rangeLv.every(Boolean), data.rangeLv);
  ok('medical L1 treat wound', /รักษาแผล \(Treat Wound\) ระหว่างการพักยาว/.test(data.medical1), data.medical1);
  ok('surgical trainee 2', /ฟื้น Toughness เป็น 2 หน่วย/.test(data.surgical), data.surgical);
  ok('fleshforge rule text', /กระสุน ลูกศร อุปกรณ์เวท หรือของที่มีราคามากกว่า 30 เกรฟ/.test(data.ffText), data.ffText.slice(0, 200));
  ok('twinborn rule text', /Attack of Opportunity ทำได้รวมกัน 1 ครั้งต่อรอบ/.test(data.twText) && /อีกร่างเข้าสู่สภาวะใกล้ตายทันที/.test(data.twText) && /HP Toughness เกราะ และกระเป๋าเป็นของตัวเอง/.test(data.twText) && /กินเสบียงสองอัตราต่อการพัก/.test(data.twText) && /แต่ละร่างได้ Action ครบชุดในฉากของตัวเอง/.test(data.twText));
  ok('wound tables cover 1-6', ['head','arm','leg','torso'].every(k => data.wounds[k] === '123456'), data.wounds);
  ok('wound kinds', data.woundKinds === 'head:5,torso:4,armL:4,armR:4,legL:4,legR:4', data.woundKinds);
  ok('torn ligaments → Disadvantage', data.torn && /Disadvantage/.test(data.torn.text) && !/-1 CV|\\-1 CV/.test(data.torn.text), data.torn);

  // ================= B) ฟังก์ชันแกน =================
  const core = await page.evaluate(() => {
    const P = (t) => { const p = parseRollCommand(t); return [p.kind, p.n, p.diceGiven, p.mode, p.dc, p.cv, p.cvMod, p.loc, p.mod, p.label].join('|'); };
    const mk = (a, b) => ({dice:[a,b], kept:[a,b], keptIdx:[0,1], sum:a+b, crit:null, double:a===b, mode:'normal'});
    const J = (total, dc, kind, o) => judgeDefense(total, dc, kind, o);
    return {
      parse: ['attack cv+2 หัว', 'attack 3 adv', 'evade dc 7 cv 9', 'parry dc 7 แขนซ้าย', 'โจมตี cv -1 ขาขวา dis', '2d6+1 cv', 'attack +1 cv+2', 'หลบ dc 9 cv9'].map(P),
      evFailCv: J(8, 7, 'evade', {sum:8, cv:9}), evOkCv: J(9, 7, 'evade', {sum:8, cv:9}), evPerfectLow: J(4, 7, 'evade', {sum:7, cv:9}), evPlain: J(8, 9, 'evade', {sum:8}),
      paAimOk: J(4, 7, 'parry', {sum:4, loc:'legR'}), paAimFail: J(6, 7, 'parry', {sum:6, loc:'legR'}), paAimPerfect: J(7, 7, 'parry', {sum:7, loc:'legR'}), paNoAim: J(6, 7, 'parry', {sum:6}),
      pdc: [[0,false],[1,false],[2,false],[3,false],[1,true],[2,true],[5,true],[-1,false]].map(([p, a]) => parryDiceCount(p, a)).join(','),
      av1: attackVerdict(mk(4,4), {cvMod:2}), av2: attackVerdict(mk(6,4), {cvMod:-1, loc:'head'}), av3: attackVerdict(mk(2,3), {}),
      doAtk: (() => { const e = doRoll({label:'Attack', kind:'attack', r: mk(6,4), mod:2, atk:{loc:'head', pick:'atk'}}); return {total: e.total, judge: e.judge.text, atk: e.atk}; })(),
      doEv: (() => { const e = doRoll({label:'Evade', kind:'evade', r: mk(3,4), mod:-3, dc:7, def:{cv:9}}); return {total: e.total, judge: e.judge, def: e.def}; })(),
      pairs: [dicePairs([1,2,3]).length, dicePairs([1,2,3,4]).length, dicePairs([6,6,1]).filter(p => p.double).length],
      pick: rollFromPick([5,2,6], 0, 2, 'dis'),
      tf: [toughFloor(3), toughFloor(null)], ts: [toughState('armL', 3, 3), toughState('armL', 0, 3), toughState('armL', -2, 3), toughState('armL', -3, 3), toughState('head', -3, 3), toughState('torso', -4, 3), toughState('legR', null, 3)].join(','),
      tst: ['lost','mortal','wound',''].map(toughStateText).join(','),
      rest: [restGain(13,'short'), restGain(13,'long',0), restGain(13,'long',1), restGain(13,'long',2), restGain(0,'long',0), restGain(7,'short')].join(','),
      wound: (() => { const seen = new Set(); for (let i = 0; i < 300; i++){ const r = rollWound('armL'); if (!r.row || !r.row.faces.includes(r.die)) return 'bad'; seen.add(r.die); } return seen.size; })(),
      help: ROLL_HELP.filter(([k]) => /attack/.test(k)).length,
      wstr: [weaponStrNeed('(STR 12: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage) 2 PDMG'), weaponStrNeed('(ต้องการ STR 8) 2 PDMG'), weaponStrShort('(STR 12: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage) 2 PDMG', {raw:{STR:11}}), weaponStrShort('(STR 12: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage) 2 PDMG', {raw:{STR:12}}), weaponPropsText('(STR 12: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage) 2 PDMG (Blunt)')],
    };
  });
  ok('parse attack cv+2 head', core.parse[0] === 'attack|2|false|normal||' + '|2|head|0|', core.parse[0]);
  ok('parse attack 3 adv', core.parse[1] === 'attack|3|true|adv|||0||0|', core.parse[1]);
  ok('parse evade dc 7 cv 9', core.parse[2] === 'evade|2|false|normal|7|9|0||0|', core.parse[2]);
  ok('parse parry dc 7 armL', core.parse[3] === 'parry|2|false|normal|7||0|armL|0|', core.parse[3]);
  ok('parse thai attack', core.parse[4] === 'attack|2|false|dis|||-1|legR|0|', core.parse[4]);
  ok('parse non-combat keeps cv as label', core.parse[5] === '|2|true|normal|||0||1|cv', core.parse[5]);
  ok('parse attack +1 cv+2', core.parse[6] === 'attack|2|false|normal|||2||1|', core.parse[6]);
  ok('parse หลบ dc 9 cv9', core.parse[7] === 'evade|2|false|normal|9|9|0||0|', core.parse[7]);
  ok('evade vs CV fail', core.evFailCv.cls === 'res-fail' && /ต่ำกว่า CV 9/.test(core.evFailCv.text) && /โดนลำตัว/.test(core.evFailCv.text), core.evFailCv);
  ok('evade vs CV ok', core.evOkCv.cls === 'res-full' && /ถึง CV 9/.test(core.evOkCv.text), core.evOkCv);
  ok('perfect evade always succeeds', core.evPerfectLow.cls === 'res-crit' && /Perfect Evade/.test(core.evPerfectLow.text), core.evPerfectLow);
  ok('evade plain text unchanged', core.evPlain.text === 'Evade ไม่สำเร็จ (8 ต่ำกว่า 9) โดนขาขวา', core.evPlain);
  ok('parry aimed uses declared group', core.paAimOk.cls === 'res-full' && /ขาขวา/.test(core.paAimOk.text) && core.paAimFail.cls === 'res-fail' && core.paAimPerfect.cls === 'res-crit' && core.paNoAim.cls === 'res-full', [core.paAimOk, core.paAimFail, core.paAimPerfect, core.paNoAim]);
  ok('parry dice cap 4', core.pdc === '2,3,4,4,4,4,4,2', core.pdc);
  ok('attack verdict perfect + cv mod', core.av1.text === 'Perfect Strike (คู่ 4) · CV 10 (เต๋า 8 +2) · ลำตัว' && core.av1.cls === 'res-crit' && core.av1.cv === 10 && core.av1.part === 'torso', core.av1);
  ok('attack verdict aimed', core.av2.text === 'CV 9 (เต๋า 10 -1) · ศีรษะ (เล็ง)' && core.av2.part === 'head' && core.av2.precise === true, core.av2);
  ok('attack verdict plain', core.av3.text === 'CV 5 · ขาซ้าย', core.av3);
  ok('doRoll attack', core.doAtk.total === 12 && core.doAtk.atk.sum === 10 && core.doAtk.atk.cv === 12 && core.doAtk.atk.part === 'head' && core.doAtk.atk.precise && core.doAtk.atk.pick === 'atk', core.doAtk);
  ok('doRoll evade perfect', core.doEv.total === 4 && core.doEv.judge.cls === 'res-crit' && core.doEv.def.cv === 9, core.doEv);
  ok('dice pairs', core.pairs.join() === '3,6,1', core.pairs);
  ok('rollFromPick', core.pick.sum === 11 && core.pick.keptIdx.join() === '0,2' && core.pick.mode === 'dis' && core.pick.chosen && core.pick.crit === null, core.pick);
  ok('tough floor + states', core.tf.join() === '-3,0' && core.ts === ',wound,wound,lost,mortal,mortal,', [core.tf, core.ts]);
  ok('tough state text', core.tst === 'ขาด,Mortal Wound,บาดแผลฉกรรจ์,', core.tst);
  ok('rest gain', core.rest === '6,13,6,13,0,3', core.rest);
  ok('rollWound', core.wound === 6, core.wound);
  ok('help rows for attack', core.help >= 2, core.help);
  ok('weapon STR helpers', JSON.stringify(core.wstr) === JSON.stringify([12, 0, true, false, '2 PDMG (Blunt)']), core.wstr);

  // ================= C) แผงทอยในชีท (ไม่อยู่ในห้อง) =================
  await page.evaluate(() => { const K = window.__kirana; const kin = DATA.kins.find(k => k.id === 'lunaryn');
    K.Store.upsert({ id:'a15', name:'นักดาบ', kin:'lunaryn', size:'Medium', childhood:kin.childhood[0].code, adulthood:kin.adulthood[0].code, extra:{STR:3,VIT:3,PER:4}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' }); });
  await page.goto(url + '#sheet-a15'); await page.waitForTimeout(900);
  const base = await page.evaluate(() => { const d = compute(window.__kirana.Store.get('a15')); return {sight: d.sight, pd: d.parryDice, hp: d.hp, mp: d.mp, tough: d.toughness, reflex: d.reflex}; });
  console.log('fixture:', JSON.stringify(base));
  ok('no stray null text on sheet', !(await page.$eval('#v-sheet', e => /\bnull\b|\bundefined\b|\bfalse\b/.test(e.textContent))));
  await page.click('.hud-btn[title="ทอยเต๋า"]'); await page.waitForTimeout(300);
  const DP = '.hud-win.dice .dicepanel';
  ok('combat option rows', (await page.$$(DP + ' .combatopts')).length === 2 && !!(await page.$(DP + ' .atkdice')) && !!(await page.$(DP + ' .cvmod')) && !!(await page.$(DP + ' .aimsel')) && !!(await page.$(DP + ' .defcv')) && !!(await page.$(DP + ' .defloc')));
  ok('no last-attack button outside a room', !(await page.$(DP + ' .lastatk')));
  ok('parry button label', (await page.$eval(DP + ' .rollbtn:has-text("Parry")', e => e.textContent)) === `Parry ${Math.min(4, 2 + base.pd)}d6`);
  await shot('140-dice-v115.png');
  const last = () => page.evaluate(() => { const e = RollLog.entries[0]; return e ? {label: e.label, kind: e.kind, mode: e.mode, dice: e.r.dice.length, kept: e.r.kept, sum: e.r.sum, chosen: !!e.r.chosen, crit: e.r.crit, total: e.total, mod: e.mod, judge: e.judge.text, cls: e.judge.cls, atk: e.atk || null, def: e.def || null, dc: e.dc} : null; });
  const pick2 = async (i, j) => { await page.waitForSelector('.pickbox .pickdie', {timeout: 5000}); const dies = await page.$$('.pickbox .pickdie'); await dies[i == null ? 0 : i].click(); await dies[j == null ? dies.length - 1 : j].click(); await page.click('.pickbox button:has-text("ใช้ 2 ลูกนี้")'); await page.waitForTimeout(250); await unlock(); };
  // โจมตีปกติ 2 ลูก: ไม่มีตัวเลือก
  await page.click(DP + ' .rollbtn:has-text("Attack")'); await page.waitForTimeout(250);
  let e = await last();
  ok('plain attack', e.kind === 'attack' && e.dice === 2 && !e.chosen && e.atk && e.atk.cv === e.sum && e.atk.part === (await page.evaluate((s) => hitPart(s), e.sum)) && /^(Perfect Strike .* · )?CV \d+ · /.test(e.judge), e);
  // Combat Dice 3 ลูก: ผู้โจมตีเลือกเอง
  await page.selectOption(DP + ' .atkdice', '3'); await page.click(DP + ' .rollbtn:has-text("Attack")');
  await page.waitForSelector('.pickbox h3'); const t3 = await page.$eval('.pickbox h3', x => x.textContent); const n3 = (await page.$$('.pickbox .pickdie')).length; const hint3 = await page.$eval('.pickbox .desc', x => x.textContent);
  await (await page.$$('.pickbox .pickdie'))[0].click(); await (await page.$$('.pickbox .pickdie'))[1].click(); const live3 = await page.$eval('.pickbox .picklive', x => x.textContent);
  await (await page.$$('.pickbox .pickdie'))[1].click(); await (await page.$$('.pickbox .pickdie'))[0].click(); await pick2(0, 2); e = await last();
  ok('combat dice 3 → attacker picks', t3 === 'โจมตี: ทอย 3d6 เลือก 2 ลูก' && n3 === 3 && /ผู้โจมตีเลือกเอง/.test(hint3) && /ผลรวม \d+/.test(live3) && /CV \d+/.test(live3) && e.dice === 3 && e.chosen && e.atk.pick === 'atk' && e.crit === null && e.kept.length === 2, {t3, n3, live3, e});
  // Advantage + Combat Dice 4 = 5 ลูก
  await page.selectOption(DP + ' .atkdice', '4'); await page.click(DP + ' button[data-m="adv"]'); await page.click(DP + ' .rollbtn:has-text("Attack")');
  await page.waitForSelector('.pickbox h3'); const t5 = await page.$eval('.pickbox h3', x => x.textContent); const n5 = (await page.$$('.pickbox .pickdie')).length; await pick2(); e = await last();
  ok('advantage + 4 combat dice = 5 dice', t5 === 'โจมตี: ทอย 5d6 เลือก 2 ลูก' && n5 === 5 && e.mode === 'adv' && e.dice === 5 && e.atk.pick === 'atk', {t5, n5, e});
  // ตัวปรับ CV และ Focus (Precise): ตำแหน่งตามที่เล็ง ไม่ตามเต๋า · CV บวก Sight
  await page.selectOption(DP + ' .atkdice', '2'); await page.click(DP + ' button[data-m="normal"]'); await page.fill(DP + ' .cvmod', '2'); await page.selectOption(DP + ' .aimsel', 'head');
  await page.click(DP + ' .rollbtn:has-text("Attack")'); await page.waitForTimeout(250); e = await last();
  ok('cv modifier + Focus (Precise)', e.atk.part === 'head' && e.atk.precise && e.atk.cvMod === 2 + base.sight && e.atk.cv === e.sum + 2 + base.sight && e.total === e.atk.cv && /ศีรษะ \(เล็ง\)/.test(e.judge) && /Focus \(Precise\) ศีรษะ/.test(e.label), e);
  // Disadvantage นอกห้อง: ตัวเลือกในเครื่องเดียวกัน ป้าย "ฝ่ายรับเลือก"
  await page.fill(DP + ' .cvmod', ''); await page.selectOption(DP + ' .aimsel', ''); await page.click(DP + ' button[data-m="dis"]'); await page.click(DP + ' .rollbtn:has-text("Attack")');
  await page.waitForSelector('.pickbox h3'); const td = await page.$eval('.pickbox h3', x => x.textContent); const hintd = await page.$eval('.pickbox .desc', x => x.textContent); await shot('141-pick-defender.png'); await pick2(); e = await last();
  ok('disadvantage → defender picks (local)', td === 'โจมตี (Disadvantage): ฝ่ายรับเลือก 2 จาก 3 ลูก' && /ฝ่ายรับ \(หรือ GM\) เป็นคนเลือก 2 ลูก/.test(hintd) && e.mode === 'dis' && e.atk.pick === 'def' && e.dice === 3 && /Disadvantage: ฝ่ายรับเลือก/.test(e.label), {td, e});
  ok('log tag ฝ่ายรับเลือก', await page.$eval('.hud-win.dice .log .e', x => /ฝ่ายรับเลือก/.test(x.textContent)));
  // ป้องกัน: ผลรวมเต๋าของผู้โจมตี 7 CV 9 → Evade เทียบกับ CV
  await page.click(DP + ' button[data-m="normal"]'); await page.fill(DP + ' input[placeholder^="DC"]', '7'); await page.fill(DP + ' .defcv', '9'); await page.selectOption(DP + ' .defloc', 'legR');
  await page.click(DP + ' .rollbtn:has-text("Evade")'); await page.waitForTimeout(250); e = await last();
  ok('evade with dc 7 cv 9 aimed legR', e.kind === 'evade' && e.dc === 7 && e.def && e.def.cv === 9 && e.def.loc === 'legR' && (e.cls === 'res-crit' ? e.sum === 7 : (e.total >= 9 ? /ถึง CV 9/.test(e.judge) : /ต่ำกว่า CV 9\) โดนขาขวา/.test(e.judge))), e);
  ok('log tags CV + aim', await page.$eval('.hud-win.dice .log .e', x => /โจมตีมา 7/.test(x.textContent) && /CV 9/.test(x.textContent) && /เล็งขาขวา/.test(x.textContent)));
  await page.evaluate(() => modal(null)); await page.click('.hud-x'); await page.waitForTimeout(200);

  // ================= D) กล่อง Toughness ในชีท: ติดลบ สถานะ ตารางบาดแผล =================
  const TB = '#v-sheet .box[data-k="tough"]';
  const toughRow = async (part) => page.evaluate((part) => { const g = document.querySelector('#v-sheet .box[data-k="tough"] .body2'); const kids = [...g.children].slice(3); const idx = DATA.meta.bodyParts.findIndex(p => p[0] === part); const lab = kids[idx*3], ctl = kids[idx*3+1]; return {text: ctl.querySelector('b').textContent, state: (lab.querySelector('.tstate') || {}).textContent || '', wbtn: !!lab.querySelector('.woundbtn')}; }, part);
  const minus = async (part, times) => { for (let i = 0; i < times; i++){ await page.evaluate((part) => { const g = document.querySelector('#v-sheet .box[data-k="tough"] .body2'); const kids = [...g.children].slice(3); const idx = DATA.meta.bodyParts.findIndex(p => p[0] === part); kids[idx*3+1].querySelector('button').click(); }, part); await page.waitForTimeout(120); } };
  const plus = async (part, times) => { for (let i = 0; i < times; i++){ await page.evaluate((part) => { const g = document.querySelector('#v-sheet .box[data-k="tough"] .body2'); const kids = [...g.children].slice(3); const idx = DATA.meta.bodyParts.findIndex(p => p[0] === part); kids[idx*3+1].querySelectorAll('button')[1].click(); }, part); await page.waitForTimeout(120); } };
  const T = base.tough;
  await minus('armL', T); let row = await toughRow('armL');
  ok('toughness 0 → wound state + button', row.text === `0/${T}` && row.state === 'บาดแผลฉกรรจ์' && row.wbtn, row);
  ok('toast at 0', /เหลือ Toughness 0/.test(await page.$eval('#toast', x => x.textContent)));
  await page.click(TB + ' .woundbtn[data-part="armL"]'); await page.waitForTimeout(300);
  const wm = await page.evaluate(() => { const m = document.querySelector('.woundmodal'); return m ? {title: m.querySelector('h3').textContent, die: +m.querySelector('.woundroll').textContent, rows: m.querySelectorAll('tbody tr').length, hit: m.querySelectorAll('tr.woundhit').length, hitName: (m.querySelector('tr.woundhit b') || {}).textContent} : null; });
  const w1 = await page.evaluate(() => window.__kirana.Store.get('a15').current.wounds);
  ok('wound modal', wm && /บาดแผลฉกรรจ์: แขนซ้ายของ นักดาบ/.test(wm.title) && wm.die >= 1 && wm.die <= 6 && wm.rows === 4 && wm.hit === 1, wm);
  ok('wound recorded', w1.length === 1 && w1[0].part === 'armL' && w1[0].body === 'A' && w1[0].die === wm.die && w1[0].name === wm.hitName, w1);
  await shot('142-wound-modal.png');
  await page.evaluate(() => modal(null)); await page.waitForTimeout(200);
  ok('wound list on sheet', (await page.$$(TB + ' .woundlist .wound')).length === 1 && /แขนซ้าย: /.test(await page.$eval(TB + ' .woundlist .wound b', x => x.textContent)));
  await minus('armL', T + 2); row = await toughRow('armL');
  ok('toast at −max (limb)', /Toughness ของแขนซ้ายติดลบถึงค่าเต็ม ส่วนนี้ขาด/.test(await page.$eval('#toast', x => x.textContent)), await page.$eval('#toast', x => x.textContent));
  ok('negative down to −max only (limb lost)', row.text === `${-T}/${T}` && row.state === 'ขาด' && !row.wbtn, row);
  await minus('head', T * 2); row = await toughRow('head');
  ok('toast at −max (head)', /Toughness ของศีรษะติดลบถึงค่าเต็ม ให้ผลเท่ากับ Mortal Wound/.test(await page.$eval('#toast', x => x.textContent)), await page.$eval('#toast', x => x.textContent));
  ok('head at −max = Mortal Wound', row.text === `${-T}/${T}` && row.state === 'Mortal Wound', row);
  await shot('143-tough-negative.png');
  await page.click(TB + ' .woundlist .wound button'); await page.waitForTimeout(200);
  ok('wound removable', (await page.$$(TB + ' .woundlist .wound')).length === 0 && (await page.evaluate(() => window.__kirana.Store.get('a15').current.wounds.length)) === 0);
  await plus('head', T * 2 + 1); row = await toughRow('head');
  ok('plus caps at max', row.text === `${T}/${T}` && row.state === '', row);
  ok('note mentions armor rule', /เกราะที่หักความเสียหายกายภาพจนเหลือ 0 ทำให้ส่วนนั้นไม่เสีย Toughness/.test(await page.$eval(TB + ' .hitnote', x => x.textContent)));

  // อาวุธที่ STR ไม่ถึง: ป้ายเตือนบนสายคาดอาวุธ (ข้อ 1ค)
  const wst = await page.evaluate(() => { const K = window.__kirana; const c = K.Store.get('a15'); const str = compute(c).raw.STR; const keep = c.equip.weapon1;
    c.equip.weapon1 = {name:'Steel Club (กระบองเหล็ก)', effect:`(STR ${str + 1}: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage) 2 PDMG Guard Break`, weight:3}; K.Store.upsert(c); renderSheet('a15');
    const a = [...document.querySelectorAll('#v-sheet .wslot .strreq')].map(x => x.className + '|' + x.textContent); const ef = document.querySelector('#v-sheet .wslot .ef').textContent;
    c.equip.weapon1.effect = `(STR ${str}: หาก STR ไม่ถึง โจมตีด้วยอาวุธนี้ติด Disadvantage) 2 PDMG Guard Break`; K.Store.upsert(c); renderSheet('a15');
    const b = [...document.querySelectorAll('#v-sheet .wslot .strreq')].map(x => x.className + '|' + x.textContent);
    c.equip.weapon1 = keep; K.Store.upsert(c); renderSheet('a15'); return {str, a, b, ef}; });
  ok('weapon STR warning on the belt', wst.a.length === 1 && wst.a[0] === `strreq short|STR ${wst.str + 1} ไม่ถึง: โจมตีติด Disadvantage` && wst.b[0] === `strreq|ต้องมี STR ${wst.str}` && /^2 PDMG\s+2 PDMG Guard Break/.test(wst.ef), wst);

  // ================= E) การพัก =================
  const setCur = (o) => page.evaluate((o) => { const K = window.__kirana; const c = K.Store.get('a15'); Object.assign(c.current, o.cur || {}); if (o.tough) Object.assign(c.current.tough, o.tough); if (o.rations != null){ c.inventory = c.inventory.filter(x => !/เสบียง|Ration/i.test(x.name)); if (o.rations > 0) c.inventory.push({name:'เสบียง (Ration)', effect:'', qty:o.rations, weight:0.5}); } K.Store.upsert(c); renderSheet('a15'); }, o);
  const curOf = () => page.evaluate(() => { const c = window.__kirana.Store.get('a15'); return {hp: c.current.hp, mp: c.current.mp, tough: Object.assign({}, c.current.tough), rations: c.inventory.filter(x => /เสบียง|Ration/i.test(x.name)).reduce((a, x) => a + (x.qty || 1), 0), ip: c.current.ip || 0}; });
  ok('rest buttons', (await page.$$('#v-sheet .restrow .restbtn')).length === 2);
  // พักสั้น: ฟื้นครึ่งหนึ่งของค่าสูงสุด (ปัดลง) กินเสบียง 1
  await setCur({cur:{hp:1, mp:0}, tough:{armL:-T, head:T}, rations:3}); await page.waitForTimeout(200);
  await page.click('#v-sheet .restbtn[data-rest="short"]'); await page.waitForTimeout(300);
  const rs = await page.evaluate(() => { const m = document.querySelector('.restmodal'); return {title: m.querySelector('h3').textContent, cols: m.querySelectorAll('thead th').length, watch: !!m.querySelector('.restwatch'), treat: !!m.querySelector('.resttreat'), eat: m.querySelector('.resteat').checked, hpCell: m.querySelector('table.t td.num').textContent}; });
  ok('short rest modal', /พักสั้น/.test(rs.title) && rs.cols === 2 && !rs.watch && !rs.treat && rs.eat && rs.hpCell === `1 → ${Math.min(base.hp, 1 + Math.floor(base.hp/2))}`, rs);
  await page.click('.restmodal .restok'); await page.waitForTimeout(300); let cu = await curOf();
  ok('short rest result', cu.hp === Math.min(base.hp, 1 + Math.floor(base.hp/2)) && cu.mp === Math.min(base.mp, Math.floor(base.mp/2)) && cu.tough.armL === -T && cu.rations === 2, cu);
  ok('rest toast', /นักดาบ พักสั้น: HP 1 เป็น/.test(await page.$eval('#toast', x => x.textContent)));
  // พักยาว: ฟื้นเต็ม + Toughness 1 หน่วย + รักษาแผล +2
  await setCur({cur:{hp:1, mp:0}, tough:{armL:-T, legR:0}, rations:2}); await page.waitForTimeout(200);
  await page.click('#v-sheet .restbtn[data-rest="long"]'); await page.waitForTimeout(300);
  const rl = await page.evaluate(() => { const m = document.querySelector('.restmodal'); const sels = [...m.querySelectorAll('table.t select')]; return {title: m.querySelector('h3').textContent, cols: m.querySelectorAll('thead th').length, watch: !!m.querySelector('.restwatch'), selects: sels.length, opts: [...sels[0].options].map(o => o.textContent)}; });
  ok('long rest modal', /พักยาว/.test(rl.title) && rl.cols === 4 && rl.watch && rl.selects === 3 && rl.opts.length === 2 && rl.opts[0] === `แขนซ้าย (${-T}/${T})`, rl);
  await shot('144-long-rest.png');
  await page.evaluate(() => { const m = document.querySelector('.restmodal'); const sels = [...m.querySelectorAll('table.t select')]; const set = (el, v) => { el.value = v; el.dispatchEvent(new Event('change', {bubbles:true})); }; set(sels[0], 'armL'); set(sels[1], '2'); set(sels[2], 'legR'); });
  await page.click('.restmodal .restok'); await page.waitForTimeout(300); cu = await curOf();
  ok('long rest result', cu.hp === base.hp && cu.mp === base.mp && cu.tough.armL === -T + 1 && cu.tough.legR === Math.min(T, 2) && cu.rations === 1, cu);
  // เฝ้ายามคนเดียว: ฟื้นครึ่งเดียว ไม่ฟื้น Toughness จากการพัก (รักษาแผลยังรับได้) ไม่มีเสบียง = ไม่หัก
  await setCur({cur:{hp:1, mp:0, ip:0}, tough:{armL:-T, legR:0}, rations:0}); await page.waitForTimeout(200);
  await page.click('#v-sheet .restbtn[data-rest="long"]'); await page.waitForTimeout(300);
  await page.selectOption('.restmodal .restwatch', '1'); await page.waitForTimeout(200);
  const rw = await page.evaluate(() => { const m = document.querySelector('.restmodal'); return {hpCell: m.querySelector('table.t td.num').textContent, note: /ผู้เฝ้ายามไม่ฟื้น/.test(m.textContent), eatDisabled: m.querySelector('.resteat').disabled, eat: m.querySelector('.resteat').checked}; });
  ok('watch alone preview', rw.hpCell === `1 → ${Math.min(base.hp, 1 + Math.floor(base.hp/2))}` && rw.note && rw.eatDisabled && !rw.eat, rw);
  await page.evaluate(() => { const m = document.querySelector('.restmodal'); const set = (el, v) => { el.value = v; el.dispatchEvent(new Event('change', {bubbles:true})); }; set(m.querySelector('.resttreat'), '1'); });
  await page.click('.restmodal .restok'); await page.waitForTimeout(300); cu = await curOf(); const toastW = await page.$eval('#toast', x => x.textContent);
  ok('watch alone result', cu.hp === Math.min(base.hp, 1 + Math.floor(base.hp/2)) && cu.mp === Math.floor(base.mp/2) && cu.tough.armL === -T + 1 && cu.tough.legR === 0 && cu.rations === 0 && /เฝ้ายามทอย 2d6 ได้/.test(toastW) && cu.ip === (/รับ 1 IP/.test(toastW) ? 1 : 0), {cu, toastW});

  // ================= F) Fleshforge =================
  const ff = await page.evaluate(() => { const all = itemCatalog(); const okk = fleshforgeCatalog(); const by = (re) => all.find(i => re.test(i.name));
    const why = (re) => { const it = by(re); return it ? fleshforgeWhyNot(it) : 'ไม่พบ'; };
    return { all: all.length, allowed: okk.length, maxPrice: Math.max(...okk.map(i => itemPrice(i) || 0)), noPrice: okk.filter(i => itemPrice(i) == null).length,
      badCats: [...new Set(okk.map(i => i.cat))].filter(c => ['กระสุน','ไอเทมเวทมนตร์','อาวุธเวทมนตร์','วัตถุดิบอาหาร','วัตถุดิบเล่นแร่แปรธาตุ','เสบียงและเครื่องดื่ม'].includes(c)),
      arrow: why(/Standard Arrow/), bullet: why(/Standard Bullet/), staff: why(/Sorcery Staff/), holy: why(/Holy Symbol/), ring: why(/Mana Stone Ring/),
      starterStaff: (() => { const hits = all.filter(i => /Sorcery Staff/.test(i.name)); return hits.length === 1 && hits[0].cat !== 'ชุดเริ่มต้น' ? fleshforgeWhyNot(hits[0]) : 'ชื่อซ้ำ ' + hits.length; })(), /* v1.16: คลังหลักขึ้นชื่อไทยก่อนแล้ว ไม้เท้าในชุดเริ่มต้นจึงรวมเป็นรายการเดียวกับคลัง */ starterBullet: fleshforgeWhyNot(all.find(i => i.cat === 'ชุดเริ่มต้น' && /Standard Bullet/.test(i.name))), starterArrow: fleshforgeWhyNot(all.find(i => i.cat === 'ชุดเริ่มต้น' && /Standard Arrow/.test(i.name))),
      pricey: all.filter(i => (itemPrice(i) || 0) > 30 && !['กระสุน','ไอเทมเวทมนตร์','อาวุธเวทมนตร์','วัตถุดิบอาหาร','วัตถุดิบเล่นแร่แปรธาตุ','เสบียงและเครื่องดื่ม'].includes(i.cat)).map(i => fleshforgeWhyNot(i)).every(w => /เกิน 30 เกรฟ/.test(w) || /อุปกรณ์เวท|กระสุน|วัตถุดิบ/.test(w)),
      okSword: why(/\(Arming Sword\)$/), okKatana: why(/\(Katana\)$/), okGreat: why(/\(Greatsword\)$/), price: [itemPrice({price:'30 เกรฟ'}), itemPrice({price:'1,250 เกรฟ'}), itemPrice({price:''}), itemPrice({price:7})],
      issue: fleshforgeIssue({fleshforge:{item:'Sorcery Staff (ไม้เท้าเวท)'}}), issueOk: fleshforgeIssue({fleshforge:{item:'Arming Sword (ดาบสั้น)'}}), issueCustom: fleshforgeIssue({fleshforge:{item:'Sorcery Staff (ไม้เท้าเวท)', custom:true}}), rule: FF_RULE_TEXT }; });
  ok('fleshforge catalog filter', ff.maxPrice === 30 && ff.noPrice === 0 && ff.badCats.length === 0 && ff.allowed < ff.all, ff);
  ok('fleshforge blocks ammo', ff.arrow === 'เป็นกระสุนหรือลูกศร' && ff.bullet === 'เป็นกระสุนหรือลูกศร', [ff.arrow, ff.bullet]);
  ok('fleshforge blocks magic gear', ff.staff === 'เป็นอุปกรณ์เวท' && ff.holy === 'เป็นอุปกรณ์เวท' && ff.ring === 'เป็นอุปกรณ์เวท', [ff.staff, ff.holy, ff.ring]);
  ok('fleshforge starter-set copies follow the main catalog', ff.starterStaff === 'เป็นอุปกรณ์เวท' && ff.starterBullet === 'เป็นกระสุนหรือลูกศร' && ff.starterArrow === 'เป็นกระสุนหรือลูกศร', [ff.starterStaff, ff.starterBullet, ff.starterArrow]);
  ok('fleshforge blocks > 30 เกรฟ', ff.pricey, ff.pricey);
  ok('fleshforge allows ≤ 30', ff.okSword === '' && ff.okKatana === '' && ff.okGreat === '', [ff.okSword, ff.okKatana, ff.okGreat]);
  ok('itemPrice', ff.price.join() === '30,1250,,7', ff.price);
  ok('fleshforge issue for old bindings', ff.issue === 'เป็นอุปกรณ์เวท' && ff.issueOk === '' && ff.issueCustom === '', [ff.issue, ff.issueOk, ff.issueCustom]);
  // UI: ผูกของที่ไม่ผ่านเกณฑ์ไว้ก่อน → ป้ายเตือนในชีท · ค้นคลังไม่เจอกระสุนและไม้เท้าเวท
  await page.evaluate(() => { const K = window.__kirana; const sw = DATA.kins.find(k => k.id === 'swalan');
    K.Store.upsert({ id:'ff15', name:'สวาลานเก่า', kin:'swalan', size:'Medium', childhood:sw.childhood[0].code, adulthood:sw.adulthood[0].code, extra:{VIT:7}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard', talent: DATA.talents[0].nameEn || DATA.talents[0].name, fleshforge:{item:'Sorcery Staff (ไม้เท้าเวท)', effect:'ลด 1 MP', custom:false, cat:'อาวุธเวทมนตร์'} }); });
  await page.goto(url + '#sheet-ff15'); await page.waitForTimeout(900);
  ok('sheet warns about a binding that no longer qualifies', await page.evaluate(() => { const el = document.querySelector('#v-sheet .ffissue'); return !!el && /อุปกรณ์เวท/.test(el.textContent + ' ' + el.title); }), await page.evaluate(() => (document.querySelector('#v-sheet .ffbox') || {}).textContent));
  await page.evaluate(() => { const K = window.__kirana; const c = K.Store.get('ff15'); c.fleshforge = null; c.done = false; K.Store.upsert(c); startWizard(c); W.step = 7; }); await page.goto(url + '#wizard'); await page.waitForTimeout(500);
  await page.click('#v-create .ffbox .ffpick'); await page.waitForTimeout(300);
  const search = async (q) => { await page.fill('.ffmodal .ffsearch', q); await page.waitForTimeout(200); return page.$$eval('.ffmodal .fflist .gift b', es => es.map(x => x.textContent)); };
  const sStaff = await search('Sorcery Staff'), sArrow = await search('Arrow'), sSword = await search('Arming Sword');
  ok('catalog modal hides magic and ammo', sStaff.length === 0 && sArrow.length === 0 && sSword.length >= 1, {sStaff, sArrow, sSword});
  ok('catalog modal shows the rule and prices', await page.evaluate(() => { const m = document.querySelector('.ffmodal'); return /ราคาเกิน 30 เกรฟ/.test(m.textContent) && /\d เกรฟ/.test((m.querySelector('.fflist .gift') || {}).textContent || ''); }));
  await shot('145-fleshforge-v115.png');
  await page.evaluate(() => modal(null));

  // ================= G) คำแนะนำ Toughness ในวิซาร์ด =================
  const hint = await page.evaluate(() => [toughnessHint({raw:{VIT:9, STR:9}}), toughnessHint({raw:{VIT:10, STR:9}}), toughnessHint({raw:{VIT:10, STR:10}}), toughnessHint({raw:{VIT:9, STR:8}}), toughnessHint({raw:{VIT:14, STR:14}})]);
  ok('toughness hint', /เพิ่มอีก 2 แต้ม/.test(hint[0]) && /เพิ่มอีก 1 แต้ม/.test(hint[1]) && hint[2] === '' && hint[3] === '' && /ผลรวม VIT \+ STR ตอนนี้ 28 เพิ่มอีก 2 แต้ม/.test(hint[4]), hint);

  // ================= H) หน้ากฎและบทสอน =================
  await page.goto(url + '#rules'); await page.waitForTimeout(500);
  const rules = await page.$eval('#v-rules', x => x.textContent);
  ok('rules page lines', /ฝ่ายรับ/.test(rules) && /สูงสุด 4 ลูก/.test(rules) && /Perfect Evade/.test(rules) && /Treat Wound|รักษาแผล/.test(rules) && /ติดลบ/.test(rules) && !/ไกล หรือมีกำบัง/.test(rules), rules.length);
  const tut = await page.evaluate(() => JSON.stringify(LESSONS));
  ok('tutorial lines', /สิบคือแขนซ้าย ห้าคือขาซ้าย/.test(tut) && /แขนเลขคู่ ขาเลขคี่/.test(tut) && !/ห้าคือแขนซ้าย/.test(tut), tut.length);
  const figs = await page.evaluate(() => { const out = {}; for (const k of ['advdis','weapon','attack','parry','hitloc','damage','wound']){ try { const el = FIGS[k](); out[k] = el.textContent; } catch (e){ out[k] = 'ERR ' + e.message; } } return out; });
  ok('figures updated', /ฝ่ายรับเลือกสองลูกให้/.test(figs.advdis) && /เป้ามีที่กำบัง/.test(figs.weapon) && !/ไกล หรือมีกำบัง/.test(figs.weapon) && /ฝ่ายรับเห็นผลแล้วประกาศ/.test(figs.attack) && /สูงสุด 4 ลูก/.test(figs.parry) && /แขนเลขคู่ ขาเลขคี่/.test(figs.hitloc) && /เว้นแต่เกราะรับความเสียหายกายภาพไว้ได้หมด/.test(figs.damage) && /Mortal Wound/.test(figs.wound), figs);

  // ================= I) ห้อง (โหมดในเครื่อง): โจมตีให้ฝ่ายรับเลือก · คำสั่งแชต · Toughness บนหมาก =================
  await page.evaluate(() => { const K = window.__kirana; const c = K.Store.get('a15'); c.current.hp = compute(c).hp; c.current.mp = compute(c).mp; for (const [k] of DATA.meta.bodyParts) c.current.tough[k] = compute(c).toughness; c.current.wounds = []; c.current.at = Date.now(); K.Store.upsert(c); });
  await page.evaluate(() => { const K = window.__kirana; const kin = DATA.kins.find(k => k.id === 'lunaryn');
    K.Store.upsert({ id:'tw15', name:'ลูน่า', kin:'lunaryn', size:'Medium', childhood:'CS2', adulthood:kin.adulthood[0].code, extra:{STR:3,VIT:3,AGI:2}, personality:{}, choiceStats:[], kslots:{}, skillSlots:{}, grants:[], knowledge:{}, prof:{}, skills:[], details:{}, done:true, step:7, starterSet:'The Vanguard' }); });
  await page.goto(url + '#table'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ห้อง v115'); await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.selectOption('#v-table select', 'a15'); await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(500);
  const say = async (t) => { await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', t); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter'); await page.waitForTimeout(300); };
  const chat0 = () => page.evaluate(() => { const m = Table.chat[0]; return m ? {kind: m.kind, who: m.who, text: m.text, dice: m.kind === 'pick' ? m.dice : (m.roll ? m.roll.dice : null), kept: m.roll ? m.roll.kept : null, mode: m.roll ? m.roll.mode : null, mod: m.mod, total: m.total, judge: (m.judge || {}).text, atk: m.atk || null, def: m.def || null, dc: m.dc, cvMod: m.cvMod, loc: m.loc, pickOf: m.pickOf || null, id: m.id, gmOnly: !!m.gmOnly} : null; });
  await page.selectOption('#chat-who', 'a15'); await page.waitForTimeout(100);
  // /r attack cv+2 หัว
  await say('/r attack cv+2 หัว'); await unlock(); let m = await chat0();
  ok('/r attack cv+2 หัว', m.kind === 'roll' && m.atk && m.atk.part === 'head' && m.atk.precise && m.atk.cvMod === 2 + base.sight && m.total === m.atk.cv && /Focus \(Precise\) ศีรษะ/.test(m.text) && /ศีรษะ \(เล็ง\)/.test(m.judge), m);
  // /attack ทางลัด + Advantage → เลือกเอง
  await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', '/adv r attack'); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter'); await pick2(); m = await chat0();
  ok('/adv r attack → attacker picks from 3', m.kind === 'roll' && m.dice.length === 3 && m.mode === 'adv' && m.atk.pick === 'atk' && /3d6 เลือก 2 Advantage/.test(m.text), m);
  await say('/attack'); await unlock(); m = await chat0();
  ok('/attack shortcut', m.kind === 'roll' && m.atk && m.dice.length === 2 && /^Attack Roll \(2d6\)$/.test(m.text), m);
  // /dis r attack → ข้อความรอเลือก
  await say('/dis r attack cv+1'); await unlock(); m = await chat0();
  ok('/dis r attack posts a pick message', m.kind === 'pick' && m.dice.length === 3 && m.cvMod === 1 && !m.loc && /Disadvantage/.test(m.text), m);
  const pickId = m.id;
  const pm = await page.evaluate(() => { const el = document.querySelector('#chatlog .pickmsg'); return el ? {dice: el.querySelectorAll('.die').length, btn: !!el.querySelector('.pickbtn'), text: el.textContent} : null; });
  ok('pick message UI', pm && pm.dice === 3 && pm.btn && /ตัวปรับ CV \+1/.test(pm.text), pm);
  ok('lastAttack ignores the pending pick', await page.evaluate(() => { const la = Table.lastAttack(); const prev = Table.chat.find(x => x.kind === 'roll' && x.atk); return !!la && !!prev && la.ts === prev.ts && la.sum === prev.atk.sum && Table.chat[0].kind === 'pick' && la.ts <= Table.chat[0].ts; }));
  await shot('146-pick-message.png');
  await page.click('#chatlog .pickmsg .pickbtn'); await page.waitForSelector('.pickbox h3'); const pt = await page.$eval('.pickbox h3', x => x.textContent); await pick2(0, 1); m = await chat0();
  const picked = await page.evaluate((id) => { const pk = Table.chat.find(x => x.id === id); return {dice: pk.dice, done: Table.pickDone(pk)}; }, pickId);
  ok('defender resolves the pick', /เลือก 2 จาก 3 ลูกให้ผู้โจมตี/.test(pt) && m.kind === 'roll' && m.pickOf === pickId && m.atk.pick === 'def' && m.mode === 'dis' && m.kept.join() === picked.dice.slice(0, 2).join() && m.total === m.kept[0] + m.kept[1] + 1 && m.atk.cv === m.total && m.id === 'pick-' + pickId && picked.done, {pt, m, picked});
  const pm2 = await page.evaluate(() => { const el = document.querySelector('#chatlog .pickmsg'); const res = [...document.querySelectorAll('#chatlog .e')].find(x => /ฝ่ายรับเลือก/.test(x.textContent)); return {done: el.classList.contains('done'), btn: !!el.querySelector('.pickbtn'), text: el.textContent, resTag: !!res}; });
  ok('pick message closes', pm2.done && !pm2.btn && /เลือกแล้ว/.test(pm2.text) && pm2.resTag, pm2);
  ok('second resolve refused', await page.evaluate((id) => { const before = Table.chat.length; Table.resolvePick(Table.chat.find(x => x.id === id)); return Table.chat.length === before && document.getElementById('modal').classList.contains('hidden'); }, pickId));
  // lastAttack + ปุ่มเติมช่องป้องกันในแผงทอยของห้อง
  const la = await page.evaluate(() => Table.lastAttack());
  ok('lastAttack', la && la.sum === m.atk.sum && la.cv === m.atk.cv && la.who === 'นักดาบ', la);
  await page.click('#twins .rdock .hud-btn'); await page.waitForTimeout(300);
  const RD = '#twins .twin-dice';
  ok('room dice dock has last-attack button', !!(await page.$(RD + ' .lastatk')) && !!(await page.$(RD + ' .atkdice')));
  await page.click(RD + ' .lastatk'); await page.waitForTimeout(200);
  const filled = await page.evaluate(() => { const p = document.querySelector('#twins .twin-dice'); return {dc: p.querySelector('input[placeholder^="DC"]').value, cv: p.querySelector('.defcv').value, loc: p.querySelector('.defloc').value}; });
  ok('last attack fills the defence fields', filled.dc === String(la.sum) && filled.cv === String(la.cv) && filled.loc === '', {filled, la});
  await shot('147-room-dice-v115.png');
  // แผงทอยของห้อง: Disadvantage → โพสต์ให้ฝ่ายรับเลือก ไม่เปิดตัวเลือกเอง
  await page.click(RD + ' button[data-m="dis"]'); await page.click(RD + ' .rollbtn:has-text("Attack 2d6")'); await page.waitForTimeout(300); await unlock(); m = await chat0();
  ok('dock disadvantage attack posts a pick', m.kind === 'pick' && m.dice.length === 3 && m.who === 'นักดาบ' && (await page.evaluate(() => document.getElementById('modal').classList.contains('hidden'))), m);
  await page.click(RD + ' button[data-m="normal"]');
  // /r evade dc 7 cv 9 · /r parry 6 dc 9 (สูงสุด 4 ลูก)
  await say('/r evade dc 7 cv 9'); await unlock(); m = await chat0();
  ok('/r evade dc 7 cv 9', m.kind === 'roll' && m.dc === 7 && m.def && m.def.cv === 9 && (/Perfect Evade/.test(m.judge) || /CV 9/.test(m.judge)), m);
  ok('chat tags CV', await page.evaluate(() => { const el = document.querySelector('#chatlog .e'); return /โจมตีมา 7/.test(el.textContent) && /CV 9/.test(el.textContent); }));
  await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', '/r parry 6 dc 9'); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter');
  await page.waitForSelector('.pickbox h3'); const pn = (await page.$$('.pickbox .pickdie')).length; await pick2(); m = await chat0();
  ok('/r parry 6 capped at 4 dice', pn === 4 && m.dice.length === 4 && /สูงสุด 4 ลูก/.test(m.text), {pn, m});
  await page.fill('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', '/r parry dc 7 ขาขวา 3'); await page.press('#v-table .chat input[placeholder^="พิมพ์ข้อความ"]', 'Enter');
  await page.waitForSelector('.pickbox .desc'); const ph = await page.$eval('.pickbox .desc', x => x.textContent); await pick2(); m = await chat0();
  ok('/r parry aimed', /ขาขวา ที่ผู้โจมตีเล็ง/.test(ph) && /9 หรือ 4/.test(ph) && m.def && m.def.loc === 'legR', {ph, m});
  // Toughness บนหมาก: ลดถึง 0 → ประกาศ · ทอยบาดแผล → ลงชีท · ติดลบถึงค่าเต็ม → ประกาศ
  await page.evaluate(() => { const r = Table.room; const t = r.tokens.find(x => x.charId === 'a15'); Table.sel = t.id; renderTable(); }); await page.waitForTimeout(400);
  const tokMinus = async (part, n) => { for (let i = 0; i < n; i++){ await page.evaluate((part) => { const idx = DATA.meta.bodyParts.findIndex(p => p[0] === part); document.querySelectorAll('.combat-panel .cp-t tbody tr, .combat-panel .cp-t tr')[0]; const rows = [...document.querySelectorAll('.combat-panel .cp-t tr')].filter(tr => tr.querySelector('td')); rows[idx].querySelector('.tadj').click(); }, part); await page.waitForTimeout(250); } };
  await tokMinus('legL', T);
  let ts = await page.evaluate(() => { const t = Table.room.tokens.find(x => x.charId === 'a15'); const c = window.__kirana.Store.get('a15'); const idx = DATA.meta.bodyParts.findIndex(p => p[0] === 'legL'); const rows = [...document.querySelectorAll('.combat-panel .cp-t tr')].filter(tr => tr.querySelector('td')); return {tok: t.tough.legL, sheet: c.current.tough.legL, sys: Table.chat.find(x => x.kind === 'sys').text, chip: (rows[idx].querySelector('.tstate') || {}).textContent, wbtn: !!rows[idx].querySelector('.woundbtn')}; });
  ok('token toughness to 0', ts.tok === 0 && ts.sheet === 0 && /ขาซ้ายเหลือ Toughness 0 ทอยตารางบาดแผลฉกรรจ์/.test(ts.sys) && ts.chip === 'บาดแผลฉกรรจ์' && ts.wbtn, ts);
  await page.click('.combat-panel .woundbtn[data-part="legL"]'); await page.waitForTimeout(500);
  ts = await page.evaluate(() => { const t = Table.room.tokens.find(x => x.charId === 'a15'); const c = window.__kirana.Store.get('a15'); return {tok: (t.wounds || []).map(w => w.part + ':' + w.die + ':' + w.name), sheet: (c.current.wounds || []).map(w => w.part + ':' + w.die + ':' + w.name + ':' + w.body), sys: Table.chat.find(x => x.kind === 'sys').text, list: document.querySelectorAll('.combat-panel .woundlist .wound').length}; });
  ok('token wound roll syncs to the sheet', ts.tok.length === 1 && ts.sheet.length === 1 && ts.sheet[0] === ts.tok[0] + ':A' && /บาดแผลฉกรรจ์ที่ขาซ้าย ทอย 1d6 ได้ [1-6]/.test(ts.sys) && ts.list === 1, ts);
  await tokMinus('legL', T + 1);
  ts = await page.evaluate(() => { const t = Table.room.tokens.find(x => x.charId === 'a15'); const c = window.__kirana.Store.get('a15'); const idx = DATA.meta.bodyParts.findIndex(p => p[0] === 'legL'); const rows = [...document.querySelectorAll('.combat-panel .cp-t tr')].filter(tr => tr.querySelector('td')); return {tok: t.tough.legL, sheet: c.current.tough.legL, sys: Table.chat.filter(x => x.kind === 'sys').slice(0, 2).map(x => x.text), chip: (rows[idx].querySelector('.tstate') || {}).textContent, cell: rows[idx].children[1].textContent}; });
  ok('token toughness floor at −max', ts.tok === -T && ts.sheet === -T && ts.sys.some(s => /Toughness ของขาซ้ายติดลบถึงค่าเต็ม ส่วนนี้ขาด/.test(s)) && ts.chip === 'ขาด', ts);
  await shot('148-token-tough-v115.png');
  // ลบบาดแผลจากชีท → หมากตาม
  await page.evaluate(() => { const K = window.__kirana; const c = K.Store.get('a15'); c.current.wounds = []; c.current.at = Date.now() + 5; K.Store.upsert(c); pushVitalsFromSheet(c); }); await page.waitForTimeout(300);
  ok('sheet wound removal reaches the token', await page.evaluate(() => (Table.room.tokens.find(x => x.charId === 'a15').wounds || []).length === 0));

  // ================= J) Twinborn: Toughness / เกราะ / การพัก / สภาวะจิตใจ =================
  await page.selectOption('#v-table select', 'tw15'); await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(500);
  const tw = await page.evaluate(() => { const r = Table.room; const a = r.tokens.find(t => t.charId === 'tw15' && t.body === 'A'), b = r.tokens.find(t => t.charId === 'tw15' && t.body === 'B'); const c = window.__kirana.Store.get('tw15');
    applyCond(a, r, 'Frightened', {}); const both = [a, b].map(t => (t.conds || []).map(x => x.id).join());
    applyCond(b, r, 'Prone', {}); const prone = [a, b].map(t => (t.conds || []).some(x => x.id === 'Prone'));
    removeCond(b, r, b.conds.find(x => x.id === 'Frightened')); const after = [a, b].map(t => (t.conds || []).some(x => x.id === 'Frightened'));
    return {hasBoth: !!a && !!b, tough2: !!c.current.tough2, armor2: !!c.armor2, both, prone, after}; });
  ok('twin mental condition mirrors, physical does not', tw.hasBoth && tw.both[0] === 'Frightened' && tw.both[1] === 'Frightened' && tw.prone[0] === false && tw.prone[1] === true && tw.after.every(x => x === false), tw);
  await page.evaluate(() => { const r = Table.room; const b = r.tokens.find(t => t.charId === 'tw15' && t.body === 'B'); Table.sel = b.id; renderTable(); }); await page.waitForTimeout(400);
  await tokMinus('torso', 2);
  const tb2 = await page.evaluate(() => { const r = Table.room; const a = r.tokens.find(t => t.charId === 'tw15' && t.body === 'A'), b = r.tokens.find(t => t.charId === 'tw15' && t.body === 'B'); const c = window.__kirana.Store.get('tw15'); const d = compute(c); return {max: d.toughness, a: (a.tough || {}).torso ?? c.current.tough.torso, b: b.tough.torso, sheetA: c.current.tough.torso, sheetB: c.current.tough2.torso}; });
  ok('twin toughness is per body', tb2.b === tb2.max - 2 && tb2.sheetB === tb2.b && tb2.a === tb2.max && tb2.sheetA === tb2.max, tb2);
  await page.goto(url + '#sheet-tw15'); await page.waitForTimeout(900);
  ok('no stray null text on twin sheet', !(await page.$eval('#v-sheet', x => /\bnull\b|\bundefined\b|\bfalse\b/.test(x.textContent))));
  const tabs = await page.$$eval(TB + ' .toughtabs .bagtab', es => es.map(x => x.textContent));
  ok('twin toughness tabs', tabs.length === 2, tabs);
  const aTorso = (await toughRow('torso')).text;
  await page.click(TB + ' .toughtabs .bagtab[data-tbody="B"]'); await page.waitForTimeout(300);
  const bTorso = (await toughRow('torso')).text; const bHasAuto = await page.$$eval(TB + ' button', bs => bs.some(b => /จากของสวมใส่/.test(b.textContent)));
  ok('twin body B shows its own values', aTorso === `${tb2.max}/${tb2.max}` && bTorso === `${tb2.max - 2}/${tb2.max}` && !bHasAuto, {aTorso, bTorso, bHasAuto});
  await page.evaluate(() => { const g = document.querySelector('#v-sheet .box[data-k="tough"] .body2'); const inp = g.querySelectorAll('input')[0]; inp.value = '2/1 หมวกเหล็กของร่าง B'; inp.dispatchEvent(new Event('change', {bubbles:true})); }); await page.waitForTimeout(200);
  const arm = await page.evaluate(() => { const c = window.__kirana.Store.get('tw15'); return {a: c.armor.head || '', b: c.armor2.head || ''}; });
  ok('twin armor notes are per body', arm.b === '2/1 หมวกเหล็กของร่าง B' && arm.a !== arm.b, arm);
  ok('twin rules list', (await page.$$('#v-sheet .twinbox .twinrules li')).length === 5);
  await shot('149-twin-sheet-v115.png');
  // พักยาวของแฝด: สองแถว กินเสบียงสองอัตรา ฟื้น Toughness แยกร่าง
  await page.evaluate(() => { const K = window.__kirana; const c = K.Store.get('tw15'); c.current.hp = 2; c.current.hp2 = 3; c.current.mp = 0; c.current.tough.armR = 0; c.inventory = c.inventory.filter(x => !/เสบียง|Ration/i.test(x.name)); c.inventory.push({name:'เสบียง (Ration)', effect:'', qty:1, weight:0.5}); c.inventory2 = (c.inventory2 || []).filter(x => !/เสบียง|Ration/i.test(x.name)); c.inventory2.push({name:'เสบียง (Ration)', effect:'', qty:2, weight:0.5}); K.Store.upsert(c); renderSheet('tw15'); }); await page.waitForTimeout(300);
  await page.click('#v-sheet .restbtn[data-rest="long"]'); await page.waitForTimeout(300);
  const tr = await page.evaluate(() => { const m = document.querySelector('.restmodal'); return {rows: [...m.querySelectorAll('table.t tr')].filter(r => r.querySelector('td')).length, eatLabel: m.querySelector('.resteat').parentElement.textContent, eat: m.querySelector('.resteat').checked, names: [...m.querySelectorAll('table.t td:first-child')].map(x => x.textContent)}; });
  ok('twin rest modal', tr.rows === 2 && /2 อัตรา \(มีอยู่ 3\)/.test(tr.eatLabel) && tr.eat, tr);
  await page.click('.restmodal .restok'); await page.waitForTimeout(300);
  const tr2 = await page.evaluate(() => { const c = window.__kirana.Store.get('tw15'); const d = compute(c); const rations = [...c.inventory, ...c.inventory2].filter(x => /เสบียง|Ration/i.test(x.name)).reduce((a, x) => a + (x.qty || 1), 0); return {hp: c.current.hp, hp2: c.current.hp2, mp: c.current.mp, max: d.hp, mpMax: d.mp, armR: c.current.tough.armR, torsoB: c.current.tough2.torso, tmax: d.toughness, rations}; });
  ok('twin rest result', tr2.hp === tr2.max && tr2.hp2 === tr2.max && tr2.mp === tr2.mpMax && tr2.armR === 1 && tr2.torsoB === tr2.tmax - 1 && tr2.rations === 1, tr2);
  // ชีทย่อ (แชร์เฉพาะค่าหลัก) ของแฝดมีคอลัมน์สองร่าง
  const mini = await page.evaluate(() => { const c = window.__kirana.Store.get('tw15'); const copy = roomCopyOf(Object.assign({}, c, {shareMode:'min'})); const el = renderMinSheet(copy); return {ths: [...el.querySelectorAll('th')].map(x => x.textContent), tough2: !!copy.current.tough2, armor2: (copy.armor2 || {}).head || ''}; });
  ok('min sheet shows both bodies', mini.ths.length === 5 && /ร่าง B/.test(mini.ths[3]) && mini.tough2 && mini.armor2 === '2/1 หมวกเหล็กของร่าง B', mini);

  console.log(`checks: ${pass} passed, ${fail} failed`);
  console.log('errors', errors);
  await browser.close();
  if (fail || errors.length) process.exit(1);
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
