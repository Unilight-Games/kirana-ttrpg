/* ===== Character list + sheet + dice ===== */
function renderChars(){
  const root = clear($('#v-chars'));
  root.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:'ตัวละครของฉัน'}), h('p',{text: Store.online ? 'ตัวละครที่บันทึกบนเว็บจะเห็นร่วมกันทั้งโต๊ะ (GM เปิดชีทผู้เล่นได้)' : 'บันทึกไว้ในเบราว์เซอร์นี้ ส่งออกเป็น JSON เพื่อย้ายเครื่องได้'})),
    h('div',{class:'row'}, h('button',{class:'primary',onclick:()=>{ startWizard(null); location.hash='#create'; },text:'+ สร้างตัวละครใหม่'}), h('button',{onclick:importChar,text:'นำเข้า JSON'}))));
  const mine = Store.chars.filter(c=>!Store.me || !c.ownerId || c.ownerId===Store.me);
  const others = Store.chars.filter(c=>Store.me && c.ownerId && c.ownerId!==Store.me);
  const list=(arr)=>h('div',{class:'grid two'}, arr.map(c=>{ const d=compute(c); const kin=c.kin?KIN[c.kin]:null;
    return h('div',{class:'card'}, h('h3',null, c.name||'(ยังไม่ตั้งชื่อ)', h('span',{class:'en',text: kin? kin.name : 'ร่าง'})),
      h('div',{class:'gives'}, c.done? tag('พร้อมเล่น','ok') : tag(`ร่าง ขั้น ${(c.step||0)+1}/8`,'warn'), c.starterSet? tag(c.starterSet,'prop'):null, c.talent? tag('Talent '+c.talent):null),
      kin? h('div',{class:'statgrid'}, STATS.map(s=>h('div',{class:'statbox'}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:d.raw[s]}), h('div',{class:'m num',text:signed(d.mod[s])})))) : null,
      h('div',{class:'row',style:'margin-top:8px'}, c.done? h('button',{class:'primary small',onclick:()=>{location.hash='#sheet-'+c.id;},text:'เปิดชีท'}):null, h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#create'; },text:c.done?'แก้ไขในวิซาร์ด':'ทำต่อ'}), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}), h('button',{class:'small ghost',onclick:()=>{ if(confirm(`ลบ ${c.name||'ตัวละครนี้'}?`)) Store.remove(c.id); renderChars(); },text:'ลบ'})));
  }));
  if (!mine.length && !others.length) root.append(h('div',{class:'card',text:'ยังไม่มีตัวละคร เริ่มจากปุ่มสร้างตัวละครใหม่'}));
  if (mine.length) root.append(list(mine));
  if (others.length){ root.append(h('h3',{style:'margin:18px 0 8px',text:'ตัวละครของผู้เล่นคนอื่นในโต๊ะ'})); root.append(list(others)); }
}
function exportChar(c){
  const txt = JSON.stringify(c, null, 1);
  const ta = h('textarea',{style:'min-height:300px;font-family:monospace;font-size:12px'}); ta.value = txt;
  modal(h('div',null, h('h3',{text:'ส่งออกตัวละคร (คัดลอกข้อความนี้ไปเก็บ)'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ navigator.clipboard.writeText(txt).then(()=>toast('คัดลอกแล้ว')).catch(()=>toast('คัดลอกไม่ได้ เลือกข้อความแล้วคัดลอกเอง')); },text:'คัดลอก'}))));
}
function importChar(){
  const ta = h('textarea',{style:'min-height:240px;font-family:monospace;font-size:12px',placeholder:'วาง JSON ของตัวละครที่นี่'});
  modal(h('div',null, h('h3',{text:'นำเข้าตัวละคร'}), ta, h('div',{class:'row',style:'margin-top:8px'}, h('button',{class:'primary',onclick:()=>{ try{ const c=JSON.parse(ta.value); if(!c || !c.id || !('kin' in c)) throw new Error('bad'); if (Store.get(c.id)) c.id = uid(); c.ownerId = Store.me||null; Store.upsert(c); modal(null); renderChars(); toast('นำเข้าแล้ว'); } catch(e){ toast('อ่าน JSON ไม่ได้'); } },text:'นำเข้า'}))));
}

/* ---- Dice panel (ใช้ร่วมกันทั้งชีทและโต๊ะ) ---- */
const RollLog = { entries: [], add(e){ this.entries.unshift(e); if (this.entries.length>60) this.entries.pop(); } };
function doRoll({label, mod=0, persSide=null, c=null, dc=null, mode='normal', kind='check'}){
  const r = roll2d6(mode);
  let pm = 0; if (persSide && c) pm = persMod(c, persSide);
  const total = r.sum + mod + pm;
  const j = kind==='luck' ? (total>=8 ? {cls:'res-full',text:'โชคเข้าข้าง (8+)'} : {cls:'res-fail',text:'โชคไม่เข้าข้าง'}) : (kind==='attack' ? {cls: r.double?'res-crit':'res-part', text: r.double? `Perfect Strike (คู่ ${r.kept[0]})` : `CV ${r.sum}`} : judge(total, r, dc));
  const e = {ts:Date.now(), label, r, mod, pm, persSide, total, judge:j, mode, dc, kind, who: c? c.name : ''};
  RollLog.add(e);
  return e;
}
function rollEntryEl(e){
  const parts = [`2d6 ${e.r.kept[0]}+${e.r.kept[1]}`]; if (e.mod) parts.push(`Mod ${signed(e.mod)}`); if (e.pm) parts.push(`${e.persSide} ${signed(e.pm)}`);
  return h('div',{class:'e'}, h('div',{class:'row',style:'gap:6px'}, e.who? h('span',{class:'who',text:e.who}):null, h('b',{text:e.label}), e.mode!=='normal'? tag(e.mode==='adv'?'Advantage':'Disadvantage', e.mode==='adv'?'ok':'neg'):null, e.dc!=null? tag('DC '+e.dc):null),
    h('div',{class:'row',style:'gap:8px;margin-top:2px'}, renderDice(e.r), h('span',{class:'dim num',text:parts.join(' ')}), h('b',{class:'num',text:'= '+e.total}), h('span',{class:e.judge.cls,text:e.judge.text})));
}
function dicePanel(c, onRoll){
  const st = {mode:'normal', pers:'', dc:''};
  const box = h('div',{class:'card'});
  const modeBtns = h('div',{class:'row'}, ['normal','adv','dis'].map(m=>h('button',{class:'small'+(st.mode===m?' primary':''), onclick:(e)=>{ st.mode=m; for (const b of modeBtns.children) b.classList.toggle('primary', b.dataset.m===m); }, dataset:{m}, text: m==='normal'?'ปกติ 2d6':m==='adv'?'Advantage 3d6↑':'Disadvantage 3d6↓'})));
  const persSel = h('select',{onchange:(e)=>{st.pers=e.target.value;}}, h('option',{value:'',text:'ไม่บวกบุคลิกภาพ'}), DATA.meta.personality.flatMap(ax=>[ax.left, ax.right]).map(s=>h('option',{value:s, text: c? `${s} (${signed(persMod(c,s))})` : s})));
  const dcInp = h('input',{type:'number',placeholder:'DC (ว่าง = Degrees)',style:'width:150px',oninput:(e)=>{st.dc=e.target.value;}});
  box.append(h('h3',{text:'ทอยเต๋า'}), h('div',{class:'row',style:'margin:8px 0'}, modeBtns), h('div',{class:'row',style:'margin-bottom:8px'}, persSel, dcInp));
  const log = h('div',{class:'log'});
  const refresh = ()=>{ clear(log); if(!RollLog.entries.length) log.append(h('div',{class:'dim',text:'ยังไม่มีการทอย'})); for (const e of RollLog.entries.slice(0,30)) log.append(rollEntryEl(e)); };
  const fire = (label, mod, kind)=>{ const e = doRoll({label, mod, persSide: st.pers||null, c, dc: st.dc===''?null:+st.dc, mode: st.mode, kind}); refresh(); if (onRoll) onRoll(e); };
  if (c){ const d = compute(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, STATS.map(s=>h('button',{class:'small rollbtn',onclick:()=>fire(`${s} Check`, d.mod[s]), text:`${s} ${signed(d.mod[s])}`}))));
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small',onclick:()=>fire('Initiative', d.initiative),text:`Initiative ${signed(d.initiative)}`}), h('button',{class:'small',onclick:()=>fire('Attack Roll (Combat Dice)', 0, 'attack'),text:'Attack 2d6 (CV)'}), h('button',{class:'small',onclick:()=>fire('Parry', d.parryDice, 'attack'),text:'Parry 2d6'}), h('button',{class:'small',onclick:()=>fire('Evade (Reflex)', d.reflex),text:`Evade ${signed(d.reflex)}`}), h('button',{class:'small',onclick:()=>fire('Fortitude ST', d.fortitude),text:`Fortitude ${signed(d.fortitude)}`}), h('button',{class:'small',onclick:()=>fire('Will ST', d.will),text:`Will ${signed(d.will)}`}), h('button',{class:'small',onclick:()=>fire('Luck Saving Throw', 0, 'luck'),text:'Luck (8+)'})));
    const kl = knowledgeLevels(c);
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, DATA.knowledge.map(k=>{ const profs = Object.values(c.kslots||{}).filter(s=>s&&s.id===k.id&&s.prof&&!s.prof.startsWith('(')).length; return h('button',{class:'small ghost',onclick:()=>fire(`${k.nameEn} Check`, profs),text:`${k.nameEn} +${profs}`}); })));
  } else {
    box.append(h('div',{class:'row',style:'margin-bottom:6px'}, h('button',{class:'small',onclick:()=>fire('2d6',0),text:'ทอย 2d6'}), h('button',{class:'small',onclick:()=>fire('Luck Saving Throw',0,'luck'),text:'Luck (8+)'}), h('button',{class:'small',onclick:()=>fire('Attack Roll',0,'attack'),text:'Attack 2d6'})));
  }
  const custom = h('input',{type:'number',placeholder:'Mod',style:'width:80px'});
  box.append(h('div',{class:'row',style:'margin-bottom:8px'}, custom, h('button',{class:'small',onclick:()=>fire('ทอยกำหนดเอง', +custom.value||0),text:'ทอย 2d6 + Mod'})));
  box.append(log); refresh();
  return box;
}

/* ---- Sheet ---- */
function renderSheet(id){
  const root = clear($('#v-sheet'));
  const c = Store.get(id);
  if (!c){ root.append(h('div',{class:'card',text:'ไม่พบตัวละครนี้'})); return; }
  const d = compute(c); const kin = KIN[c.kin];
  c.current = c.current || {hp:d.hp, mp:d.mp, sanity:d.sanity, tough:Object.fromEntries(DATA.meta.bodyParts.map(([k])=>[k,d.toughness])), ap:3, ip:0, money:15};
  const cur = c.current;
  const save = ()=>{ Store.upsert(c); };
  const main = h('div');
  main.append(h('div',{class:'stephead'}, h('div',null, h('h2',{text:c.name}), h('p',{text:`${kin.name} · ${d.size} · ${kin.archetype}` + (c.starterSet? ` · ${c.starterSet}`:'')})),
    h('div',{class:'row'}, h('button',{class:'small',onclick:()=>{ startWizard(c); location.hash='#create'; },text:'แก้ไข'}), h('button',{class:'small ghost',onclick:()=>exportChar(c),text:'ส่งออก JSON'}))));
  // stats
  main.append(h('div',{class:'statgrid'}, STATS.map(s=>h('div',{class:'statbox'}, h('div',{class:'k',text:s}), h('div',{class:'v num',text:d.raw[s]}), h('div',{class:'m num',text:'Mod '+signed(d.mod[s])})))));
  // resources
  const res = h('div',{class:'res'});
  const resBox=(k, key, max, cls)=>{ const v=cur[key]; return h('div',{class:'r'}, h('div',{class:'k',text:k}), h('div',{class:'v num'}, v, h('small',{text:'/ '+max})), h('div',{class:'bar '+cls}, h('i',{style:`width:${Math.max(0,Math.min(100, v/max*100))}%`})), h('div',{class:'row',style:'margin-top:6px;gap:4px'}, h('button',{class:'small',onclick:()=>{cur[key]=v-1; save(); renderSheet(id);},text:'−'}), h('button',{class:'small',onclick:()=>{cur[key]=Math.min(max,v+1); save(); renderSheet(id);},text:'+'}), h('button',{class:'small ghost',onclick:()=>{cur[key]=max; save(); renderSheet(id);},text:'เต็ม'}))); };
  res.append(resBox('HP','hp',d.hp,'hp'), resBox('MP','mp',d.mp,''), resBox('Sanity','sanity',d.sanity,'san'));
  res.append(h('div',{class:'r'}, h('div',{class:'k',text:'Insight Point (IP)'}), h('div',{class:'v num',text:cur.ip||0}), h('div',{class:'row',style:'margin-top:6px;gap:4px'}, h('button',{class:'small',onclick:()=>{cur.ip=Math.max(0,(cur.ip||0)-1); save(); renderSheet(id);},text:'−'}), h('button',{class:'small',onclick:()=>{cur.ip=(cur.ip||0)+1; save(); renderSheet(id);},text:'+'}))));
  res.append(h('div',{class:'r'}, h('div',{class:'k',text:'เงิน (เกรฟ)'}), h('div',{class:'v num',text:cur.money||0}), h('div',{class:'row',style:'margin-top:6px;gap:4px'}, h('input',{type:'number',style:'width:80px',value:cur.money||0,onchange:(e)=>{cur.money=+e.target.value||0; save();}}))));
  main.append(h('h3',{style:'margin-top:14px',text:'ทรัพยากร'}), res);
  // body toughness
  const body = h('div',{class:'body'});
  for (const [k,label] of DATA.meta.bodyParts){ const v = cur.tough[k] ?? d.toughness; body.append(h('div',{class:'p'}, label, h('b',{class:'num',style: v<=0?'color:var(--bad)':''},v,h('small',{class:'dim',text:' /'+d.toughness})), h('div',{class:'row',style:'justify-content:center;gap:4px'}, h('button',{class:'small',onclick:()=>{cur.tough[k]=v-1; save(); renderSheet(id);},text:'−'}), h('button',{class:'small',onclick:()=>{cur.tough[k]=Math.min(d.toughness,v+1); save(); renderSheet(id);},text:'+'})))); }
  main.append(h('h3',{style:'margin-top:14px'}, 'Toughness ตามอวัยวะ ', h('span',{class:'dim',style:'font-size:13px;font-weight:400;font-family:var(--font-body)',text:'หมด = ใช้อวัยวะไม่ได้ ติดลบถึงค่าเต็ม = เสียอวัยวะ'})), body, h('p',{class:'dim',style:'font-size:12px',text:'Hit Location: '+DATA.meta.hitLocation}));
  // secondary
  const sec = h('div',{class:'gives',style:'margin-top:10px'}, tag(`Passive PER ${d.passivePer}`), tag(`Initiative ${signed(d.initiative)}`,'prop'), tag(`Reflex ${signed(d.reflex)}`,'prop'), tag(`Might ${signed(d.might)}`,'prop'), tag(`Sight ${signed(d.sight)}`,'prop'), tag(`Fortitude ${signed(d.fortitude)}`,'prop'), tag(`Will ${signed(d.will)}`,'prop'), tag(`Parry Dice ${d.parryDice}`,'prop'), tag(`แบกได้ ${d.capacity} กก.`), tag(kin.speed));
  main.append(h('h3',{style:'margin-top:14px'}, 'ค่าพลังรอง ', tag('เสนอ','prop')), sec);
  // personality
  main.append(h('h3',{style:'margin-top:14px',text:'บุคลิกภาพ'}), h('div',{class:'gives'}, DATA.meta.personality.map(ax=>{ const p=c.personality[ax.id]; if(!p||p.value==null) return tag(`${ax.left}/${ax.right} 0`); const l = p.side==='left'?p.value:-p.value; return tag(`${ax.left} ${signed(l)} / ${ax.right} ${signed(-l)}`, l>0?'stat':(l<0?'neg':'')); })));
  // traits etc.
  const sect=(title, items, cls)=>{ if(!items.length) return; main.append(h('h3',{style:'margin-top:14px',text:title})); const box=h('div',{class:'card'}); for (const it of items) box.append(h('div',{style:'margin:4px 0'}, tag(it.name + (it.nameEn?` (${it.nameEn})`:''), cls), ' ', h('span',{class:'desc',text:it.text}))); main.append(box); };
  sect('Benefits ของวงศา', kin.benefits, 'prop'); sect('Traits', kin.traits, 'ok'); sect('Hindrances', kin.hindrances, 'neg');
  if (c.evolver && c.evolver.kin){ const ek=KIN[c.evolver.kin]; const pick = c.evolver.pick||''; const tr = pick.startsWith('T:') ? ek.traits.find(t=>t.nameEn===pick.slice(2)) : null; const hd = ek.hindrances.find(x=>x.nameEn===c.evolver.hindrance); main.append(h('h3',{style:'margin-top:14px',text:`Descendants of Evolver (ยืมจาก ${ek.name})`}), h('div',{class:'card'}, tr? h('div',null, tag(`${tr.name} (${tr.nameEn})`,'ok'),' ',h('span',{class:'desc',text:tr.text})) : h('div',null, tag(pick.slice(2),'stat')), hd? h('div',{style:'margin-top:4px'}, tag(`${hd.name} (${hd.nameEn})`,'neg'),' ',h('span',{class:'desc',text:hd.text})):null)); }
  const bgs = [findBg(kin,c.childhood), findBg(kin,c.adulthood)].filter(Boolean);
  main.append(h('h3',{style:'margin-top:14px',text:'พื้นหลัง'}), h('div',{class:'grid two'}, bgs.map(b=>h('div',{class:'card'}, h('h4',null, b.name, ' ', h('span',{class:'dim',text:b.nameEn})), h('div',{class:'gives'}, Object.entries(b.stats).map(([k,v])=>tag(`${signed(v)} ${k}`,'stat'))), h('div',{class:'desc',text:b.text})))));
  if (c.adaptation) main.append(h('div',{class:'gives'}, tag('Adaptation: '+c.adaptation,'ok')));
  // knowledge
  const kl = knowledgeLevels(c);
  const kt = h('table',{class:'t'}, h('thead',null, h('tr',null, h('th',{text:'Knowledge'}), h('th',{text:'Lv'}), h('th',{text:'Proficiency'}), h('th',{text:'สิ่งที่ทำได้'}))));
  for (const k of DATA.knowledge){ const profs = Object.values(c.kslots||{}).filter(s=>s&&s.id===k.id&&s.prof).map(s=>s.prof); const lv = kl[k.id]; const texts = []; for (let i=0;i<=lv;i++){ const L=k.levels[String(i)]; if (L && L.text) texts.push(`Lv${i}: ${L.text}`); } const profTexts = profs.map(p=>{ for (const L of Object.values(k.levels)){ const f=L.proficiencies.find(x=>x.name===p); if (f) return `${p}: ${f.text}`; } return p; });
    kt.append(h('tr',null, h('td',null, h('b',{text:k.nameEn}), ' ', h('span',{class:'dim',text:k.nameTh})), h('td',{class:'num',text:lv}), h('td',{text:profs.filter(p=>!p.startsWith('(')).join(', ')||'—'}), h('td',{class:'dim',style:'font-size:12px'}, texts.map(t=>h('div',{text:t})), profTexts.filter(t=>!t.startsWith('(')).map(t=>h('div',{style:'color:var(--mana)',text:t}))))); }
  main.append(h('h3',{style:'margin-top:14px',text:'ความรู้ (Knowledge Check = 2d6 + จำนวน Proficiency)'}), h('div',{class:'tablewrap'}, kt));
  // skills
  const sks = allSkills(c);
  main.append(h('h3',{style:'margin-top:14px',text:`ทักษะและเวทมนตร์ (${sks.length})`}), h('div',{class:'grid'}, sks.map(n=>{ const sk=SKILL_BY_NAME[n]; return sk? skillCard(sk,false,()=>{}) : h('div',{class:'sk'}, h('b',{text:n})); })));
  if (c.talent) main.append(h('div',{class:'gives',style:'margin-top:6px'}, tag('Talent: '+DATA.talents.find(t=>t.key===c.talent).label,'prop')));
  // starter set
  if (c.starterSet){ const s = DATA.sets.sets.find(x=>x.nameEn===c.starterSet); if (s){ const tb = h('table',{class:'t'}, h('thead',null, h('tr',null, h('th',{text:'ไอเทม'}), h('th',{text:'กก.'}), h('th',{text:'ทำอะไรให้'})))); for (const i of [...s.items, ...DATA.sets.common.items]) tb.append(h('tr',null, h('td',{text:i.name}), h('td',{class:'num',text:i.weight}), h('td',{class:'dim',text:i.effect}))); main.append(h('h3',{style:'margin-top:14px',text:`สัมภาระ: ${s.nameEn} + ชุดยังชีพ`}), h('div',{class:'tablewrap'}, tb)); } }
  // details
  const det = h('div',{class:'card'});
  for (const [k,label] of [['likes','ชอบ'],['dislikes','ไม่ชอบ'],['fears','กลัว'],['backstory','เรื่องราว'],['appearance','รูปลักษณ์'],['signature','เอกลักษณ์']]) if (c.details[k]) det.append(h('div',{style:'margin:4px 0'}, h('b',{text:label+': '}), h('span',{class:'desc',text:c.details[k]})));
  const notes = h('textarea',{placeholder:'บันทึกระหว่างเล่น',oninput:(e)=>{c.notes=e.target.value;},onblur:save}); notes.value=c.notes||'';
  det.append(h('div',{style:'margin-top:8px'}, h('label',{text:'บันทึก'}), notes));
  main.append(h('h3',{style:'margin-top:14px',text:'รายละเอียด'}), det);
  root.append(h('div',{class:'sheet'}, main, h('aside',{class:'side'}, dicePanel(c, (e)=>{ if (Table.roomId) Table.postRoll(e, c); }))));
}
