'use strict';
/* ===== Kirana TTRPG Online — core ===== */
const DATA = JSON.parse(document.getElementById('kirana-data').textContent);
const STATS = ['STR','AGI','VIT','PER','INF','INT'];
const KIN = Object.fromEntries(DATA.kins.map(k => [k.id, k]));
const KNOW = Object.fromEntries(DATA.knowledge.map(k => [k.id, k]));
const SKILL_BY_NAME = Object.fromEntries(DATA.skills.map(s => [s.nameEn, s]));

/* ---- DOM helpers (textContent only: ข้อมูลจาก db ถือว่าไม่น่าไว้ใจเสมอ) ---- */
function h(tag, attrs, ...kids){
  const e = document.createElement(tag);
  if (attrs) for (const [k,v] of Object.entries(attrs)){
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(e.dataset, v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)){
    if (kid == null || kid === false) continue;
    e.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return e;
}
const $ = (sel, root=document) => root.querySelector(sel);
function clear(e){ while (e.firstChild) e.removeChild(e.firstChild); return e; }
function tag(text, cls){ return h('span', {class:'tag' + (cls ? ' ' + cls : ''), text}); }
function signed(n){ return (n > 0 ? '+' : '') + n; }
function uid(){ const a='abcdefghijkmnpqrstuvwxyz23456789'; let s=''; const r=crypto.getRandomValues(new Uint8Array(12)); for (const b of r) s+=a[b%a.length]; return s; }
let toastT=null;
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.remove('hidden'); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.add('hidden'), 3200); }
function modal(content){ const m=$('#modal'); clear(m); if(!content){ m.classList.add('hidden'); return; }
  const box=h('div',{class:'box'}, content, h('div',{class:'row',style:'justify-content:flex-end;margin-top:12px'}, h('button',{onclick:()=>modal(null),text:'ปิด'})));
  m.append(box); m.classList.remove('hidden'); m.onclick=(ev)=>{ if(ev.target===m) modal(null); }; }

/* ---- Dice: 2d6 ตามไฟล์แกน, Advantage/Disadvantage = 3d6 เก็บ 2 ดี/แย่ ---- */
function rollD6(){ return 1 + (crypto.getRandomValues(new Uint8Array(1))[0] % 6); }
function roll2d6(mode='normal'){
  const n = mode === 'normal' ? 2 : 3;
  const dice = Array.from({length:n}, rollD6);
  let kept;
  if (mode === 'adv') kept = [...dice].sort((a,b)=>b-a).slice(0,2);
  else if (mode === 'dis') kept = [...dice].sort((a,b)=>a-b).slice(0,2);
  else kept = dice.slice();
  // mark which indexes were dropped (one die only)
  const keptIdx = [];
  const pool = kept.slice();
  dice.forEach((d,i)=>{ const j = pool.indexOf(d); if (j>=0){ pool.splice(j,1); keptIdx.push(i);} });
  const sum = kept[0]+kept[1];
  const crit = kept[0]===6 && kept[1]===6 ? 'success' : (kept[0]===1 && kept[1]===1 ? 'failure' : null);
  const dbl = kept[0]===kept[1];
  return {dice, kept, keptIdx, sum, crit, double: dbl, mode};
}
/* Degrees of success (ไม่มี DC): 10+ Full, 7-9 Partial, 6- Failure. มี DC: ถึง DC = สำเร็จ. Critical ตัดสินทันทีทั้งสองแบบ */
function judge(total, r, dc){
  if (r.crit === 'success') return {cls:'res-crit', text:'Critical Success [6,6] ผ่านทันที'};
  if (r.crit === 'failure') return {cls:'res-crit', text:'Critical Failure [1,1] ล้มเหลวทันที'};
  if (dc != null) return total >= dc ? {cls:'res-full', text:`สำเร็จ (ถึง DC ${dc})`} : {cls:'res-fail', text:`ล้มเหลว (DC ${dc})`};
  if (total >= 10) return {cls:'res-full', text:'Full Success'};
  if (total >= 7) return {cls:'res-part', text:'Partial Success (สำเร็จแต่มีราคา)'};
  return {cls:'res-fail', text:'Failure'};
}
function renderDice(r){
  return h('span', {class:'inline-roll'}, r.dice.map((d,i)=>h('span',{class:'die' + (r.keptIdx.includes(i)?'':' drop'), text:d})));
}

/* ---- Character model & computation ---- */
function newChar(){
  return { id: uid(), name:'', kin:null, size:null, childhood:null, adulthood:null, evolver:{kin:null, pick:null, hindrance:null},
    personality:{}, extra:{}, choiceStats:[], talent:null, talentPicks:{}, knowledge:{}, prof:{}, skills:[], grants:[],
    adaptation:null, starterSet:null, details:{likes:'',dislikes:'',fears:'',backstory:'',appearance:'',signature:''},
    current:null, notes:'', createdAt:Date.now(), updatedAt:Date.now(), ownerId:null, step:0 };
}
const modOf = v => Math.max(-5, Math.min(5, Math.floor(v/2) - 5));

function findBg(kin, code){
  if (!kin || !code) return null;
  for (const list of ['childhood','specialChildhood','adulthood','specialAdulthood'])
    for (const b of kin[list]) if (b.code === code) return b;
  return null;
}
function compute(c){
  const kin = c.kin ? KIN[c.kin] : null;
  const raw = Object.fromEntries(STATS.map(s=>[s, kin ? (kin.raw[s]||0) : 0]));
  const from = Object.fromEntries(STATS.map(s=>[s, []]));
  const addStats = (obj, label) => { for (const [k,v] of Object.entries(obj||{})) if (STATS.includes(k)) { raw[k]+=v; from[k].push(`${label} ${signed(v)}`); } };
  const ch = findBg(kin, c.childhood), ad = findBg(kin, c.adulthood);
  if (ch) addStats(ch.stats, 'วัยเด็ก');
  if (ad) addStats(ad.stats, 'วัยผู้ใหญ่');
  for (const s of c.choiceStats||[]) { raw[s]+=1; from[s].push('พื้นหลัง (เลือก) +1'); }
  for (const [k,v] of Object.entries(c.extra||{})) if (v) { raw[k]+=v; from[k].push(`Extra ${signed(v)}`); }
  const mod = Object.fromEntries(STATS.map(s=>[s, modOf(raw[s])]));
  const extraTotal = kin ? kin.extra : 0;
  const extraUsed = Object.values(c.extra||{}).reduce((a,b)=>a+(b||0),0);
  const size = c.size || (kin ? kin.sizes[0] : 'Medium');
  let capMult = {Small:3, Medium:3, Large:4, Huge:5}[size] || 3;
  let capNote = size==='Small' ? 'ไฟล์แกนไม่ระบุ Small ใช้ตัวคูณของ Medium' : '';
  if (kin && kin.id==='handerlaw-dwarves') { capMult = 4; capNote = 'Powerful Build: นับขนาดใหญ่ขึ้นหนึ่งขั้นเรื่องการแบก (Small→Medium คือ ×3 ตามไฟล์แกน แต่ Trait บอกให้ใหญ่ขึ้นหนึ่งขั้น จึงใช้ ×4 ติดป้ายเสนอ)'; }
  const tough = Math.floor((raw.VIT + raw.STR)/10) + 1;
  const d = {
    raw, mod, from, extraTotal, extraUsed, extraLeft: extraTotal - extraUsed, size,
    hp: 10 + mod.VIT + mod.STR,
    mp: 10 + mod.INF + mod.INT,
    sanity: 5 + mod.INF,
    toughness: tough,
    passivePer: 7 + mod.PER,
    capacity: raw.STR * capMult, capMult, capNote,
    // (เสนอ) ค่าพลังรอง: ไฟล์แกน V.2 ไม่มีตาราง ใช้สูตรฝั่ง Bestiary + ข้อเสนอ 6 ก.ย. 2026
    fortitude: mod.VIT, will: mod.PER, reflex: Math.floor(mod.AGI/2)+1, sight: Math.floor(mod.PER/2)+1,
    might: Math.floor(mod.STR/2)+1, initiative: mod.PER, parryDice: 0, combatDice: '2d6',
    speed: kin ? kin.speed : '',
    highest: [], knowledgeMods: {},
  };
  const best = Math.max(...STATS.map(s=>mod[s]));
  d.highest = STATS.filter(s=>mod[s]===best);
  for (const k of DATA.knowledge){ const lvl = c.knowledge[k.id]||0; const profs = (c.prof[k.id]||[]).length; d.knowledgeMods[k.id] = {level: lvl, prof: Math.max(lvl, profs)}; }
  return d;
}
function personalityValue(c, axisId){ const p = c.personality[axisId]; if (!p || p.value==null) return null; return p; }
/* คู่บุคลิกภาพ: ฝั่งที่เลือกเป็นบวก ฝั่งตรงข้ามติดลบเท่ากัน */
function persMod(c, side){ // side = 'Logic' etc.
  for (const ax of DATA.meta.personality){
    const p = c.personality[ax.id]; if (!p || p.value==null) continue;
    if (ax.left === side) return p.side==='left' ? p.value : -p.value;
    if (ax.right === side) return p.side==='right' ? p.value : -p.value;
  }
  return 0;
}
function budgetState(c){
  const used = []; for (const ax of DATA.meta.personality){ const p=c.personality[ax.id]; if (p && p.value!=null) used.push(p.value); }
  const pool = DATA.meta.personalityBudget.slice();
  const left = pool.slice(); for (const v of used){ const i=left.indexOf(v); if(i>=0) left.splice(i,1); }
  return {used, left};
}

/* ---- Storage: localStorage เสมอ + db เมื่อมี ---- */
const LS_KEY = 'kirana.chars.v1';
function loadLocal(){ try { return JSON.parse(localStorage.getItem(LS_KEY)||'[]'); } catch(e){ return []; } }
function saveLocal(list){ try { localStorage.setItem(LS_KEY, JSON.stringify(list)); } catch(e){} }
const Store = {
  chars: loadLocal(), db:null, user:null, room:null, me:null, isOwner:false, canWrite:null, online:false, backend:null,
  listeners: new Set(),
  notify(){ for (const f of this.listeners) try{ f(); }catch(e){ console.error(e);} },
  upsert(c){ c.updatedAt = Date.now(); const i=this.chars.findIndex(x=>x.id===c.id); if(i>=0) this.chars[i]=c; else this.chars.push(c); saveLocal(this.chars); this.notify();
    if (this.db && this.me && this.canWrite!==false){ const copy = JSON.parse(JSON.stringify(c)); copy.ownerId = copy.ownerId || this.me; this.db.doc('chars/'+c.id).set(copy).catch(e=>console.warn('db set', e)); } },
  remove(id){ this.chars = this.chars.filter(x=>x.id!==id); saveLocal(this.chars); this.notify(); if (this.db) this.db.doc('chars/'+id).delete().catch(()=>{}); },
  get(id){ return this.chars.find(x=>x.id===id) || null; },
};
async function initCapabilities(){
  if (window.claude && window.claude.use){
    try {
      const [db, user, room] = await Promise.all([claude.use('db'), claude.use('user'), claude.use('room')]);
      Store.db = db; Store.user = user; Store.room = room; Store.backend = 'claude';
      if (user){ try { Store.me = await user.id(); } catch(e){} try { Store.isOwner = !!user.isOwner(); } catch(e){} try { Store.canWrite = user.can('data.write'); } catch(e){} }
    } catch(e){ console.warn('capabilities', e); }
  } else if (window.KIRANA_FIREBASE && window.KIRANA_FIREBASE.projectId){
    try { await initFirebase(window.KIRANA_FIREBASE); } catch(e){ console.warn('firebase', e); toast('เชื่อมต่อ Firebase ไม่ได้: ' + (e && e.message ? e.message : e)); }
  }
  if (Store.db){
    Store.online = true;
    // ตัวละครที่แชร์ในโต๊ะเดียวกัน: ทุกคนอ่านได้ (GM ต้องเห็นชีทผู้เล่น)
    try {
      Store.db.collection('chars').onSnapshot(snap => {
        const docs = snapDocs(snap);
        let changed=false;
        for (const d of docs){ if(!d || !d.id) continue; const i=Store.chars.findIndex(x=>x.id===d.id); if(i<0){ Store.chars.push(d); changed=true; } else if ((d.updatedAt||0) > (Store.chars[i].updatedAt||0)){ Store.chars[i]=d; changed=true; } }
        if (changed){ saveLocal(Store.chars); Store.notify(); }
      }, err => console.warn('chars snapshot', err));
    } catch(e){ console.warn(e); }
  }
  updateOnline();
}
/* ---- Firebase backend (GitHub Pages): Firestore + Anonymous auth ห่อให้หน้าตาเหมือน db/user/room ของ claude.ai ---- */
async function initFirebase(cfg){
  const V = cfg.sdkVersion || '11.0.1';
  const base = `https://www.gstatic.com/firebasejs/${V}/`;
  const [{initializeApp}, A, F] = await Promise.all([import(base+'firebase-app.js'), import(base+'firebase-auth.js'), import(base+'firebase-firestore.js')]);
  const app = initializeApp(cfg);
  const auth = A.getAuth(app);
  const fdb = F.getFirestore(app);
  const uid = await new Promise((res, rej) => {
    const stop = A.onAuthStateChanged(auth, u => { if (u){ stop(); res(u.uid); } }, rej);
    A.signInAnonymously(auth).catch(rej);
    setTimeout(()=>rej(new Error('auth timeout')), 15000);
  });
  const plain = o => JSON.parse(JSON.stringify(o)); // Firestore ไม่รับ undefined
  const wrapDoc = snap => ({ exists: snap.exists(), id: snap.id, data: () => snap.data() });
  const docRef = path => { const ref = F.doc(fdb, path); return {
    set: d => F.setDoc(ref, plain(d)), update: d => F.updateDoc(ref, plain(d)), delete: () => F.deleteDoc(ref), get: async () => wrapDoc(await F.getDoc(ref)),
    onSnapshot: (ok, err) => F.onSnapshot(ref, s => ok(wrapDoc(s)), err) }; };
  const coll = (path, cons=[]) => ({
    orderBy: (f, d) => coll(path, [...cons, F.orderBy(f, d||'asc')]), limit: n => coll(path, [...cons, F.limit(n)]), where: (a, op, v) => coll(path, [...cons, F.where(a, op, v)]),
    doc: id => docRef(path + '/' + id),
    onSnapshot: (ok, err) => F.onSnapshot(cons.length ? F.query(F.collection(fdb, path), ...cons) : F.collection(fdb, path), s => ok({ docs: s.docs.map(wrapDoc) }), err) });
  Store.db = { doc: docRef, collection: coll };
  Store.user = { id: async () => uid, isOwner: () => false, canEdit: () => false, can: () => true };
  Store.me = uid; Store.canWrite = true; Store.backend = 'firebase';
  // presence ผ่าน Firestore: rooms/<id>/presence/<uid> อัปเดตทุก 40 วิ ถือว่าออนไลน์ถ้าไม่เกิน 100 วิ
  Store.room = { join: async (name) => {
    const path = 'rooms/' + name.replace(/^kirana-/, '') + '/presence';
    let state = {}; let timer = null; let unsub = null;
    const push = () => F.setDoc(F.doc(fdb, path + '/' + uid), plain({ ...state, at: Date.now() })).catch(()=>{});
    return {
      presence: (patch) => { state = { ...state, ...patch }; push(); if (!timer) timer = setInterval(push, 40000); },
      onPeers: (fn) => { unsub = F.onSnapshot(F.collection(fdb, path), s => { const now = Date.now(); fn(s.docs.map(d => d.data()).filter(p => p && (now - (p.at||0)) < 100000)); }, ()=>{}); },
      leave: () => { if (timer) clearInterval(timer); if (unsub) unsub(); F.deleteDoc(F.doc(fdb, path + '/' + uid)).catch(()=>{}); },
      emit: () => {}, on: () => {} };
  } };
}
function snapDocs(snap){
  if (!snap) return [];
  if (Array.isArray(snap)) return snap.map(x => x && x.data ? (typeof x.data==='function' ? x.data() : x.data) : x);
  if (snap.docs) return snap.docs.map(x => x && typeof x.data==='function' ? x.data() : (x.data||x));
  if (typeof snap.forEach==='function'){ const out=[]; snap.forEach(x=>out.push(typeof x.data==='function'?x.data():(x.data||x))); return out; }
  return [];
}
function docData(d){ if(!d) return null; if (typeof d.data==='function') return d.exists===false ? null : d.data(); return d.data||d; }
function updateOnline(){
  const o = $('#online'); clear(o);
  const dot = h('span', {class:'dot' + (Store.online ? ' on' : '')});
  let txt = Store.online ? (Store.backend==='firebase' ? 'ออนไลน์: ซิงก์ผ่าน Firebase' : 'ออนไลน์: ตัวละครและโต๊ะเล่นซิงก์ผ่านเว็บ') : 'โหมดออฟไลน์ (บันทึกในเครื่องนี้)';
  if (Store.online && Store.canWrite === false) txt = 'ออนไลน์แบบอ่านอย่างเดียว (ขอสิทธิ์ Contributor จากเจ้าของเพจเพื่อบันทึก)';
  o.append(dot, txt);
}
