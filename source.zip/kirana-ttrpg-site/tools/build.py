import json, pathlib
root = pathlib.Path(__file__).parent
src = root.parent / "src"
data = open(root / "data.json", encoding="utf-8").read()
# JSON inside <script type=application/json>: escape closing tags
data = data.replace("</", "<\\/")
app = "\n".join(open(src / f, encoding="utf-8").read() for f in ["core.js", "wizard.js", "sheet.js", "table.js", "main.js"])
assert "</script" not in app
html = open(src / "shell.html", encoding="utf-8").read().replace("__DATA__", data).replace("__APP__", app)
out = root.parent / "index.html"
out.parent.mkdir(exist_ok=True)
out.write_text(html, encoding="utf-8")
print(out, len(html.encode("utf-8")), "bytes")
