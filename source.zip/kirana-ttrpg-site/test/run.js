const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE ' + m.text()); });
  const url = 'file://' + path.resolve(__dirname, '../dist/index.html');
  await page.goto(url);
  await page.waitForTimeout(500);
  await page.screenshot({ path: 'test/01-home.png' });

  // compute math check: Lunaryn base
  const calc = await page.evaluate(() => {
    const K = window.__kirana;
    const c = { id: 'x', kin: 'lunaryn', size: 'Medium', childhood: 'C1', adulthood: 'A1', extra: { INT: 4, INF: 2, VIT: 8 }, personality: {}, choiceStats: [], kslots: {}, skillSlots: {}, grants: [], knowledge: {}, prof: {} };
    const d = K.compute(c);
    return { raw: d.raw, mod: d.mod, hp: d.hp, mp: d.mp, san: d.sanity, tough: d.toughness, cap: d.capacity, left: d.extraLeft, highest: d.highest, reflex: d.reflex, might: d.might, sight: d.sight, ppr: d.passivePer };
  });
  console.log('compute', JSON.stringify(calc));
  // expected: Lunaryn 7/7/8/8/10/10 +C1(+2 INT,+1 AGI) +A1(+2 STR,+1 VIT) + extra INT4 INF2 VIT8
  // STR 9 AGI 8 VIT 17 PER 8 INF 12 INT 16 → mod -1,-1,3,-1,1,3 ; HP 10+3-1=12 ; MP 10+1+3=14 ; San 6 ; Tough (17+9)/10+1 = 3 ; cap 27
  const exp = { STR: 9, AGI: 8, VIT: 17, PER: 8, INF: 12, INT: 16 };
  for (const k in exp) if (calc.raw[k] !== exp[k]) console.log('MISMATCH raw', k, calc.raw[k], exp[k]);
  if (calc.hp !== 12 || calc.mp !== 14 || calc.san !== 6 || calc.tough !== 3 || calc.cap !== 27 || calc.left !== 0) console.log('MISMATCH derived', calc);
  if (calc.ppr !== 6) console.log('MISMATCH passive PER', calc.ppr);

  // dice distribution sanity
  const dice = await page.evaluate(() => { const K = window.__kirana; let s = 0, crit = 0, adv = 0; const N = 20000; for (let i = 0; i < N; i++) { const r = K.roll2d6('normal'); s += r.sum; if (r.crit === 'success') crit++; const a = K.roll2d6('adv'); adv += a.sum; } return { mean: s / N, critRate: crit / N, advMean: adv / N }; });
  console.log('dice', JSON.stringify(dice), '(expect mean 7, crit ~0.028, adv mean ~8.46)');

  // walk the wizard through the UI
  await page.click('a[href="#create"]');
  await page.click('text=เริ่มสร้างตัวละคร');
  await page.waitForTimeout(200);
  await page.click('.card.pick:has-text("Nightkin")');
  await page.waitForTimeout(200);
  await page.screenshot({ path: 'test/02-kin.png', fullPage: false });
  await page.click('text=ขั้นต่อไป →');
  await page.waitForTimeout(200);
  const bgCards = await page.$$('.card.pick');
  await bgCards[0].click(); await page.waitForTimeout(100);
  const bgCards2 = await page.$$('.card.pick');
  await bgCards2[5].click(); await page.waitForTimeout(100);
  await page.screenshot({ path: 'test/03-bg.png' });
  await page.click('text=ขั้นต่อไป →'); await page.waitForTimeout(200);
  // personality: set values via selects
  const vals = [3, 2, 2, 1, 1, 0];
  for (let i = 0; i < 6; i++) { const sels = await page.$$('.axis select'); await sels[i].selectOption(String(vals[i])); await page.waitForTimeout(80); }
  await page.screenshot({ path: 'test/04-pers.png' });
  await page.click('text=ขั้นต่อไป →'); await page.waitForTimeout(200);
  // extra: click + on INT until 0 left
  for (let i = 0; i < 14; i++) { const plus = await page.$$('.alloc .box .ctl button:nth-child(3)'); const idx = i % 2 === 0 ? 1 : 3; if (!(await plus[idx].isDisabled())) await plus[idx].click(); else await plus[0].click(); await page.waitForTimeout(40); }
  await page.screenshot({ path: 'test/05-extra.png' });
  await page.click('text=ขั้นต่อไป →'); await page.waitForTimeout(300);
  const talentCards = await page.$$('.card.pick:not(.disabled)');
  console.log('eligible talents', talentCards.length);
  await talentCards[0].click(); await page.waitForTimeout(300);
  await page.screenshot({ path: 'test/06-talent.png', fullPage: true });
  // pick skills in first skill picker if any
  const skCards = await page.$$('.sklist .sk:not(.sel)');
  if (skCards.length) { await skCards[0].click(); await page.waitForTimeout(150); const sk2 = await page.$$('.sklist .sk:not(.sel):not(.disabled)'); if (sk2.length) await sk2[0].click(); }
  await page.waitForTimeout(200);
  for (let it = 0; it < 10; it++) {
    const pend = await page.$$('.card:has(.tag.warn) ');
    let acted = false;
    for (const card of pend) {
      const btn = await card.$('.row button:not([disabled]):not(.primary)');
      if (btn && !(await card.$('.infobox'))) { await btn.click(); acted = true; break; }
      const prof = await card.$('.sk:not(.sel)');
      if (prof && await card.$('.infobox')) { await prof.click(); acted = true; break; }
    }
    await page.waitForTimeout(150);
    if (!acted) break;
  }
  await page.screenshot({ path: 'test/06b-talent-filled.png', fullPage: true });
  await page.click('text=ขั้นต่อไป →'); await page.waitForTimeout(200);
  console.log('after step5 hash/step title:', await page.$eval('.stephead h2', e => e.textContent));
  await page.screenshot({ path: 'test/07-calc.png', fullPage: true });
  await page.click('text=ขั้นต่อไป →'); await page.waitForTimeout(200);
  await page.fill('input[placeholder^="ชื่อตัวละคร"]', 'เคียร่า');
  await page.click('text=ขั้นต่อไป →'); await page.waitForTimeout(200);
  const sets = await page.$$('.card.pick');
  await sets[2].click(); await page.waitForTimeout(200);
  await page.screenshot({ path: 'test/08-set.png', fullPage: true });
  await page.click('text=เสร็จสิ้น บันทึกตัวละคร'); await page.waitForTimeout(500);
  console.log('hash after finish', await page.evaluate(() => location.hash));
  await page.screenshot({ path: 'test/09-sheet.png', fullPage: true });
  // roll from sheet
  await page.click('.sheet aside button:has-text("PER")'); await page.waitForTimeout(100);
  await page.click('.sheet aside button:has-text("Luck")'); await page.waitForTimeout(100);
  const logTxt = await page.$eval('.sheet aside .log', e => e.textContent.slice(0, 200));
  console.log('log', logTxt);
  // table local mode
  await page.click('a[href="#table"]'); await page.waitForTimeout(200);
  await page.fill('input[placeholder^="ชื่อห้อง"]', 'ทดสอบ');
  await page.click('button:has-text("สร้างห้อง")'); await page.waitForTimeout(400);
  await page.click('button:has-text("วางตัวละครลงบอร์ด")'); await page.waitForTimeout(200);
  await page.click('button:has-text("+ NPC")'); await page.waitForTimeout(200);
  await page.click('button:has-text("เริ่มการต่อสู้")'); await page.waitForTimeout(300);
  await page.fill('input[placeholder^="พิมพ์ข้อความ"]', '/r 2d6+2 แทงสวน');
  await page.keyboard.press('Enter'); await page.waitForTimeout(200);
  await page.fill('input[placeholder^="พิมพ์ข้อความ"]', 'สวัสดีโต๊ะ');
  await page.keyboard.press('Enter'); await page.waitForTimeout(200);
  await page.click('button:has-text("+ นาฬิกา")'); await page.waitForTimeout(200);
  await page.screenshot({ path: 'test/10-table.png', fullPage: true });
  await page.click('button:has-text("เทิร์นถัดไป")'); await page.waitForTimeout(200);
  // chars list & rules
  await page.click('a[href="#chars"]'); await page.waitForTimeout(200);
  await page.screenshot({ path: 'test/11-chars.png' });
  await page.click('a[href="#rules"]'); await page.waitForTimeout(200);
  await page.screenshot({ path: 'test/12-rules.png', fullPage: true });
  // mobile
  await page.setViewportSize({ width: 400, height: 800 });
  await page.goto(url + '#create'); await page.waitForTimeout(400);
  await page.screenshot({ path: 'test/13-mobile.png', fullPage: false });
  console.log('errors', errors);
  await browser.close();
})().catch(e => { console.error('TEST FAIL', e); process.exit(1); });
